package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.ParametrizacaoDomicilioBancarioDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoDomicilioBancarioManutencaoRequestDTO;
import br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoBoasVindasServiceRemote;
import br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoDomicilioBancarioServiceRemote;
import br.com.cielo.dashboard.service.IParametrizacaoDomicilioBancarioService;

@Service
public class ParametrizacaoDomicilioBancarioServiceImpl implements IParametrizacaoDomicilioBancarioService {

	@Resource(mappedName="ParametrizacaoDomicilioBancarioService#br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoDomicilioBancarioServiceRemote")
	private ParametrizacaoDomicilioBancarioServiceRemote parametrizacaoDomicilioBancarioService;
	
	
	@Override
	public List<ParametrizacaoDomicilioBancarioDTO> consultar(List<Integer> codigosFerramenta,
			List<Integer> codigosSolucaoCaptura) {
		return parametrizacaoDomicilioBancarioService.consultar(codigosFerramenta, codigosSolucaoCaptura);
	}

	@Override
	public void atualizar(ParametrizacaoDomicilioBancarioManutencaoRequestDTO manutencoes) {
		parametrizacaoDomicilioBancarioService.atualizar(manutencoes);
	}

}
