/**
 * 
 */
package br.com.cielo.dashboard.controller;

import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.credenciamento.dto.DominioRetornoInstalacaoDTO;
import br.com.cielo.credenciamento.dto.FerramentaDTO;
import br.com.cielo.credenciamento.enums.FerramentaEnum;
import br.com.cielo.credenciamento.enums.SituacaoPropostaEnum;
import br.com.cielo.credenciamento.enums.TipoPerfilUsuarioSmart;
import br.com.cielo.dashboard.dto.ConsultarPropostaDTO;
import br.com.cielo.dashboard.model.Bancos;
import br.com.cielo.dashboard.model.Critica;
import br.com.cielo.dashboard.model.Etapa;
import br.com.cielo.dashboard.model.Ferramenta;
import br.com.cielo.dashboard.model.OfertasInteract;
import br.com.cielo.dashboard.model.Proposta;
import br.com.cielo.dashboard.model.SolucaoCaptura;
import br.com.cielo.dashboard.model.Status;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IConsultarBancosService;
import br.com.cielo.dashboard.service.IConsultarCriticasService;
import br.com.cielo.dashboard.service.IConsultarEtapasService;
import br.com.cielo.dashboard.service.IConsultarMotivoInstalacaoService;
import br.com.cielo.dashboard.service.IConsultarPropostaService;
import br.com.cielo.dashboard.service.IConsultarStatusService;
import br.com.cielo.dashboard.service.IFerramentaService;
import br.com.cielo.dashboard.service.IOfertasService;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author dcarneiro
 *
 */
@Controller
@Scope(value=WebApplicationContext.SCOPE_REQUEST)
public class ConsultarPropostaController {

	private static final Logger LOG = LogManager.getLogger(ConsultarPropostaController.class);

	@Autowired
	private IConsultarEtapasService consultarEtapaService;

	@Autowired
	private IConsultarStatusService consultarStatusService;

	@Autowired
	private IConsultarPropostaService consultarPropostaService;

	@Autowired
	private IConsultarCriticasService criticaService;

	@Autowired
	private IConsultarBancosService consultarBancosService;
	
	@Autowired
	private IConsultarMotivoInstalacaoService consultarMotivoInstalacaoService;
	
	@Autowired
	private IFerramentaService ferramentaService;
	
	@Autowired
	private IOfertasService ofertasService;

	@RequestMapping("/initProposta")
	@Secured(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA)
	public String init(HttpSession session, Model model, Authentication authentication) {
		LOG.info("INICIANDO A CONSULTA PROPOSTA");
		
		/* ZERANDO SESSÃO */
		session = DashboardUtils.removerAllAtributosSession(session);
		
		ConsultarPropostaDTO consultarPropostaDto = initialize();
		carregarServicos(session, model, authentication);
		model.addAttribute("consultar_proposta", consultarPropostaDto);
		return NavigationDashBoard.CONSULTAR_PROPOSTA;
	}
	
	/**
	 * 
	 * @param consultar
	 * @param bindingResult
	 * @param session
	 * @param model
	 * @param authentication
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping("/consultarListaProposta")
	@PreAuthorize("hasRole('ROLE_CRD_CONSULTA_PROPOSTA_LISTA') "
			+ "and @customMethodSecurityExpression.hasAnyRoleBanco() "
			+ "and @customMethodSecurityExpression.hasAnyRoleFerramenta()"
			+ "and @customMethodSecurityExpression.consultaPropostaPermitida(#consultar)")
	public String consultar(@ModelAttribute("consultar_proposta") @Valid ConsultarPropostaDTO consultar,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication) throws ParseException {
		
		//CARREGA ATRIBUTOS DA SESSÃO
		model = carregarAtributosSession(session, model);
		
		/* SE NÚMERO DA PROPOSTA E NÚMERO DO EC NÃO ESTIVEM AMBOS PREENCHIDOS, PERIODO É OBRIGATORIO. */
		if (!DashboardUtils.isNotNullOrEmpty(consultar.getNumeroProposta())
				&& !DashboardUtils.isNotNullOrEmpty(consultar.getNumeroEstabelecimentoComercial())) {

			/* CONSISTENCIA PERIODO */
			if (bindingResult.hasErrors()) {
				model.addAttribute("error", "Período Obrigatório!");
				return NavigationDashBoard.CONSULTAR_PROPOSTA;
			}
		}		
		/* SE O USUÁRIO NÃO TEM PERMISSÃO PARA VISUALIZAR TODAS AS FERRAMENTAS E NÃO SELECIONOU NENHUM FILTRO DE FERRAMENTA NA TELA
		 * ENTÃO LIMITAR O FILTRO COM BASE NAS SUAS PERMISSÕES. */
		if (!(SecurityRole.findRole(authentication, SecurityRole.ROLE_CRD_FERRAMENTA_TODAS)) 
				&& (consultar.getCodigoFerramenta().length == 0)) {
			
			List<Integer> listaFerramentasPermitidas = SecurityRole.converteListaRolesFerramentaParaListaCodigoFerramenta(authentication);
			Integer[] arrFerramentasPermitidas = listaFerramentasPermitidas.toArray(new Integer[listaFerramentasPermitidas.size()]);
			consultar.setCodigoFerramenta(arrFerramentasPermitidas);
		}		
		/* IDEM ACIMA, PARA BANCOS.*/
		if (!(SecurityRole.findRole(authentication, SecurityRole.ROLE_CRD_BANCO_TODOS)) 
				&& (consultar.getCodigoBanco().length == 0)) {
			
			List<Integer> listaBancosPermitidos = SecurityRole.converteListaRolesBancoParaListaCodigoBanco(authentication);
			Integer[] arrBancosPermitidos = listaBancosPermitidos.toArray(new Integer[listaBancosPermitidos.size()]);
			consultar.setCodigoBanco(arrBancosPermitidos);
		}
		
		//TRATAMENTO CODIGO PERFIL SMART, RELEASE 05 - SMART
		// O USUARIO POSSUI ACESSO SOMENTE A FERRAMENTA SMART
		Optional<Integer> codPerfilSmart = Optional.ofNullable(null);
		Boolean isSmart = isUsuarioSmart(consultar.getCodigoFerramenta()).isPresent();
		if(isSmart){			
			//RECUPERAMOS O DOMINIO PARA O PERFIL SMART
			codPerfilSmart = Optional.of(SecurityRole.getDominioPerfilUsuarioSmart(authentication));
		}
		//EXECUTAMOS A CONSULTA DA(S) PROPOSTA(S)
		model.addAttribute("listProposta", consultarPropostaAllFilter(consultar, session, isSmart, codPerfilSmart));
		return NavigationDashBoard.CONSULTAR_PROPOSTA;
	}
	
	/**
	 * Metodo responsavel por verificar se o usuario possui acesso somente a ferramenta smart
	 * @param arrFerramentasPermitidas
	 * @return
	 */
	private Optional<Integer> isUsuarioSmart(Integer[] arrFerramentasPermitidas) {
		return Arrays.asList(arrFerramentasPermitidas).stream().filter(codigo -> FerramentaEnum.SMART.getCodigo().equals(codigo)).findFirst();
	}

	/**
	 * Carregando combos para tela de filtro
	 * 
	 * @param session
	 * @param model
	 */
	private void carregarServicos(HttpSession session, Model model, Authentication authentication) {
		getConsultarBancos(model, session, authentication);
		getConsultarTodasEtapas(model, session);
		getConsultarStatus(model, session);
		getConsultarCriticaEtapa(model, session);
		getFerramentas(model, session, authentication);
		obterListaOfertas(model, session);
	}

	/**
	 * Carrega ferramentas a serem exibidas no filtro de selação de ferramentas
	 * 
	 * @param model
	 * @param session
	 */
    private void getFerramentas(Model model, HttpSession session, Authentication authentication) {
    	
		List<FerramentaDTO> listaFerramentasDTO = ferramentaService.getFerramentasPorIntervaloDeCodigo(2, 89);
		List<Ferramenta> listaFerramentas = new ArrayList<Ferramenta>();
		List<Integer> listaCodigoFerramentasPermitidas = SecurityRole.converteListaRolesFerramentaParaListaCodigoFerramenta(authentication);
		
		for (FerramentaDTO ferramentaDTO : listaFerramentasDTO) {
			
			Ferramenta ferramenta = new Ferramenta();
			ferramenta.setCodigo(ferramentaDTO.getCodigo());
			ferramenta.setDescricao(ferramentaDTO.getDescricao());
			if ((listaCodigoFerramentasPermitidas.contains(ferramenta.getCodigo()))
					|| (listaCodigoFerramentasPermitidas.contains(0))) {
				listaFerramentas.add(ferramenta);
			}
			
		}
		
		session.setAttribute("listaFerramentas", listaFerramentas);
		model.addAttribute("listaFerramentas", listaFerramentas);
	}

	/**
	 * Método: Carregar os atributos utilizados na tela de fintro da proposta
	 * 
	 * @param session
	 * @param model
	 * @return
	 */
	private Model carregarAtributosSession(HttpSession session, Model model) {
		model.addAttribute("listaEtapa", session.getAttribute("listaEtapa"));
		model.addAttribute("listaStatus", session.getAttribute("listaStatus"));
		model.addAttribute("listaCriticaEtapa", session.getAttribute("listaCriticaEtapa"));
		model.addAttribute("listaBancos", session.getAttribute("listaBancos"));
		model.addAttribute("listaFerramentas", session.getAttribute("listaFerramentas"));
		model.addAttribute("listaOfertas", session.getAttribute("listaOfertas"));
		if (DashboardUtils.isNotNullOrEmpty(session.getAttribute("listProposta"))) {
			model.addAttribute("listProposta", session.getAttribute("listProposta"));
		}
		return model;
	}

	/**
	 * Método: realiza chamda contendo varios filtros selecionados menos
	 * proposta e EC.
	 * 
	 * @param consultar
	 * @throws ParseException
	 */
	private List<Proposta> consultarPropostaAllFilter(ConsultarPropostaDTO consultar, HttpSession session, Boolean isSmart, Optional<Integer> codPerfilSmart)
			throws ParseException {
		
		List<Object[]> retornoConsulta = new ArrayList<Object[]>();
		
		String dataInicio = DashboardUtils.isNotNullOrEmpty(consultar.getPeriodoInicial())
				? consultar.getPeriodoInicial().split("to")[0] : DashboardUtils.EMPTY;

		String dataFim = DashboardUtils.isNotNullOrEmpty(consultar.getPeriodoInicial())
				? consultar.getPeriodoInicial().split("to")[1] : DashboardUtils.EMPTY;

		if (DashboardUtils.isNotNullOrEmpty(consultar.getNumeroProposta())
				|| DashboardUtils.isNotNullOrEmpty(consultar.getNumeroEstabelecimentoComercial())) {

			Object[] ret = consultarPropostaService.getProposta(consultar.getNumeroProposta(),
					consultar.getNumeroEstabelecimentoComercial(), consultar.getCodigoProducao(),
					consultar.getCodigoEtapa(), consultar.getCodigoStatus(), dataInicio, dataFim, isSmart, codPerfilSmart);
			
			if (DashboardUtils.isNotNullOrEmpty(ret)) {
				retornoConsulta.add(ret);
			}
		} else {
			retornoConsulta = consultarPropostaService.getPropostaAllFilter(consultar.getCodigoFerramenta(),consultar.getCodigoBanco(), consultar.getCodigoSolucaoCaptura(), 
					consultar.getCodigoProducao(), consultar.getMotivoCancelamento(), consultar.getCriticaEtapa(), consultar.getCodigoEtapa(),
					consultar.getCodigoStatus(), dataInicio, dataFim, consultar.getSituacaoProposta(),DashboardUtils.obterCorpoCpfCnpj(consultar.getCpfCnpj()), 
					consultar.getCodigoOferta(), isSmart, codPerfilSmart,Optional.ofNullable(consultar.getIndEntregaMaquinas()));
		}
		/* REMOVENDO ATRIBUTOS DA SESSÃO */
		DashboardUtils.removerAtributoToSession(session, "listProposta");

		return complementaPropostaListObject(retornoConsulta, session);
	}

	/**
	 * Método: Obtem descricao das etapas com os dados em session
	 * 
	 * @param etapa
	 * @param session
	 * @return DescricaoEtapa
	 */
	@SuppressWarnings("unchecked")
	private String returnDescricaoEtapa(String etapa, HttpSession session) {
		List<Etapa> list = (List<Etapa>) session.getAttribute("listaEtapa");
		for (Etapa et : list) {
			if (et.getCodigo().equals(Integer.parseInt(etapa))) {
				return et.getDescricao();
			}
		}
		return DashboardUtils.EMPTY;
	}

	/**
	 * Método:Initialize
	 * 
	 * @return
	 */
	public ConsultarPropostaDTO initialize() {
		ConsultarPropostaDTO consultarPropostaDto = new ConsultarPropostaDTO();
		consultarPropostaDto.setEtapa(new ArrayList<Etapa>());
		consultarPropostaDto.setStatus(new ArrayList<Status>());
		consultarPropostaDto.setSolucaoCaptura(new ArrayList<SolucaoCaptura>());
		return consultarPropostaDto;
	}

	/**
	 * 
	 * @return
	 */
	private void getConsultarTodasEtapas(Model model, HttpSession session) {
		List<Object> retornoEtapa = consultarEtapaService.getListaEtapas();
		List<Etapa> listaEtapa = new ArrayList<Etapa>();

		for (int i = 0; i < retornoEtapa.size(); i++) {
			Object[] obj = (Object[]) retornoEtapa.get(i);
			Etapa et = new Etapa();
			et.setCodigo(Integer.parseInt(String.valueOf(obj[0])));
			et.setDescricao(String.valueOf(obj[1]));
			listaEtapa.add(et);
		}
		session.setAttribute("listaEtapa", listaEtapa);
		model.addAttribute("listaEtapa", listaEtapa);
	}

	/**
	 * 
	 * @param model
	 * @param session
	 */
	private void getConsultarBancos(Model model, HttpSession session, Authentication authentication) {
		
		List<Object[]> retorno = consultarBancosService.getListarBancosDomiciliosParametrizados();
		List<Bancos> listaBancos = new ArrayList<Bancos>();
		List<Integer> listaCodigoBancosPermitidos = SecurityRole.converteListaRolesBancoParaListaCodigoBanco(authentication);
		
		for (int i = 0; i < retorno.size(); i++) {
			Object[] obj = (Object[]) retorno.get(i);
			Bancos bc = new Bancos();
			bc.setCodigoBanco(Integer.parseInt(String.valueOf(obj[0])));
			bc.setDescricaoBanco(String.valueOf(obj[1]));
			if ((listaCodigoBancosPermitidos.contains(bc.getCodigoBanco())) 
					|| (listaCodigoBancosPermitidos.contains(0)) ) {
				listaBancos.add(bc);
			}
		}
		
		session.setAttribute("listaBancos", listaBancos);
		model.addAttribute("listaBancos", listaBancos);
	}

	/**
	 * 
	 * @param model
	 * @param session
	 */
	private void getConsultarStatus(Model model, HttpSession session) {
		List<Object> retornoStatus = consultarStatusService.getListaStatus();
		List<Status> listaStatus = new ArrayList<Status>();
		for (int i = 0; i < retornoStatus.size(); i++) {
			Object[] obj = (Object[]) retornoStatus.get(i);
			Status et = new Status();
			et.setCodigo(Integer.parseInt(String.valueOf(obj[0])));
			et.setDescricao(String.valueOf(obj[1]));
			listaStatus.add(et);
		}
		session.setAttribute("listaStatus", listaStatus);
		model.addAttribute("listaStatus", listaStatus);
	}

	/**
	 * Método: popula o objecto de critica da etapa
	 * 
	 * @param model
	 * @param session
	 */
	private void getConsultarCriticaEtapa(Model model, HttpSession session) {
		List<Object> retornoCritica = criticaService.getListarCriticas();
		List<Critica> lista = new ArrayList<Critica>();
		for (int i = 0; i < retornoCritica.size(); i++) {
			Object[] obj = (Object[]) retornoCritica.get(i);
			Critica et = new Critica();
			et.setCodigo(Integer.parseInt(String.valueOf(obj[0])));
			et.setDescricao(String.valueOf(obj[1]));
			et.setEtapa(String.valueOf(obj[2]));

			lista.add(et);
		}
		session.setAttribute("listaCriticaEtapa", lista);
		model.addAttribute("listaCriticaEtapa", lista);
	}

	/**
	 * Método: Popula Lista das propostas pesquisadas no CRD
	 * 
	 * @param retornoConsulta
	 * @param session
	 * @return
	 * @throws ParseException
	 */
	private List<Proposta> complementaPropostaListObject(List<Object[]> retornoConsulta, HttpSession session)
			throws ParseException {

		List<Proposta> listProposta = new ArrayList<Proposta>();
		for (int i = 0; i < retornoConsulta.size(); i++) {

			if (verificarPropostaExistente(retornoConsulta, listProposta, i)) {
				continue;
			}
			Proposta proposta = new Proposta();

			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[3])) {
				proposta.setCodigoEtapa(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[3])));
				proposta.setEtapa(returnDescricaoEtapa(String.valueOf(retornoConsulta.get(i)[3]), session));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[4])) {
				Date dataInclusaoRegistroDate = (Date) retornoConsulta.get(i)[4];
				proposta.setDataInclusaoRegistroDate(dataInclusaoRegistroDate);
				proposta.setDataInclusaoRegistro(DashboardUtils.convertDateToString(String.valueOf(retornoConsulta.get(i)[4])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[5])) {
				proposta.setFerramenta(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[5])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[6])) {
				proposta.setBanco(StringUtils.leftPad(String.valueOf(retornoConsulta.get(i)[6]), 3, "0"));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[7])) {
				proposta.setSolucaoCaptura(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[7])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[8])) {
				proposta.setSituacaoEtapa(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[8])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[9])) {
				proposta.setProposta(Long.parseLong(String.valueOf(retornoConsulta.get(i)[9])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[10])) {
				proposta.setCampoCpfCnpj(
						DashboardUtils.formatCpf(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[10])),
								Integer.parseInt(String.valueOf(retornoConsulta.get(i)[11]))));
			} else {
				proposta.setCampoCpfCnpj(
						DashboardUtils.formatCnpj(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[12])),
								Integer.parseInt(String.valueOf(retornoConsulta.get(i)[13])),
								Integer.parseInt(String.valueOf(retornoConsulta.get(i)[14]))));
			}

			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[15])) {
				proposta.setEstabelecimentoComercial(Long.parseLong(String.valueOf(retornoConsulta.get(i)[15])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[16])) {
				proposta.setCodigoAfiliacao(Long.parseLong(String.valueOf(retornoConsulta.get(i)[16])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[17])) {
				String motivoCancelamento = String.valueOf(retornoConsulta.get(i)[17]);
				proposta.setMotivoCancelamento(motivoCancelamento);
				DominioRetornoInstalacaoDTO dominioRetornoInstalacaoDTO = consultarMotivoInstalacaoService.getDominioById(Integer.parseInt(motivoCancelamento)); 
				proposta.setDescricaoMotivoCancelamento(dominioRetornoInstalacaoDTO.getDescricao());
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[18])) {
				proposta.setRazaoSocial(String.valueOf(retornoConsulta.get(i)[18]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[19])) {
				proposta.setNomeFantasia(String.valueOf(retornoConsulta.get(i)[19]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[20])) {
				proposta.setMccAcatado(String.valueOf(retornoConsulta.get(i)[20]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[21])) {
				proposta.setSituacaoProposta(
						obtemDescricaoSituacaoProposta(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[21]))));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[22])) {
				proposta.setEtapaConcatenadas(String.valueOf(retornoConsulta.get(i)[22]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[23])) {
				proposta.setCriticasConcatenadasComRessalvas(String.valueOf(retornoConsulta.get(i)[23]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[24])) {
				proposta.setCriticasConcatenadasSemRessalvas(String.valueOf(retornoConsulta.get(i)[24]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[25])) {
				proposta.setBancoDescricao(String.valueOf(retornoConsulta.get(i)[25]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[26])) {
				proposta.setTipoConta(String.valueOf(retornoConsulta.get(i)[26]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[27])) {
				proposta.setCodigoTipoPacoteComercioEletronico(String.valueOf(retornoConsulta.get(i)[27]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[28])) {
				proposta.setDescricaoTipoPlanoCielo(String.valueOf(retornoConsulta.get(i)[28]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[29])) {
				proposta.setValorFatMedioMensal(new BigDecimal(String.valueOf(retornoConsulta.get(i)[29])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[30])) {
				proposta.setQuantidadeDiasLiquidacao(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[30])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[31])) {
				proposta.setIndicadorPropostaAgro(String.valueOf(retornoConsulta.get(i)[31]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[32])) {
				proposta.setCodigoAgencia(String.valueOf(retornoConsulta.get(i)[32]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[33])) {
				proposta.setIndicadorClienteMultivan(String.valueOf(retornoConsulta.get(i)[33]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[34])) {
				proposta.setDataCadastroEc(DashboardUtils.convertDateToString(String.valueOf(retornoConsulta.get(i)[34])));
			}	
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[35])) {
				proposta.setIndOfertaAssociada(String.valueOf(retornoConsulta.get(i)[35]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[36])) {
				proposta.setIndAceiteOferta(String.valueOf(retornoConsulta.get(i)[36]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[37])) {
				proposta.setNivelOferta(String.valueOf(retornoConsulta.get(i)[37]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[38])) {
				proposta.setCodigoOferta(String.valueOf(retornoConsulta.get(i)[38]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[39])) {
				proposta.setCodigoOfertaCombo(String.valueOf(retornoConsulta.get(i)[39]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[40])) {
				proposta.setLoginUsuarioOperador(String.valueOf(retornoConsulta.get(i)[40]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[41])) {
				proposta.setDataAtivacaoEc(DashboardUtils.convertDateToString(String.valueOf(retornoConsulta.get(i)[41])));
			}
			//RL05 - SPRINT02 SMART
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[42])) {
				proposta.setNumEcCadeiaForcada(Long.parseLong(String.valueOf(retornoConsulta.get(i)[42])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[43])) {
				proposta.setNumEcEspelho(Long.parseLong(String.valueOf(retornoConsulta.get(i)[43])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[44])) {
				proposta.setIndEspelhamentoTaxa(String.valueOf(retornoConsulta.get(i)[44]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[45])) {
				proposta.setNomeExecutivo(String.valueOf(retornoConsulta.get(i)[45]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[46])) {
				proposta.setIndEntregaMaquina(String.valueOf(retornoConsulta.get(i)[46]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[47])) {
				proposta.setPerfilSmart(TipoPerfilUsuarioSmart.getTipoPerfil(Integer.valueOf(String.valueOf(retornoConsulta.get(i)[47]))).get().name());
				
			}

			listProposta.add(proposta);
		}
		if (!listProposta.isEmpty()) {
			session.setAttribute("listProposta", listProposta);
		}
		return listProposta;
	}

	private String obtemDescricaoSituacaoProposta(Integer situacaoProposta) {
		for (SituacaoPropostaEnum situacao : SituacaoPropostaEnum.values()) {
			if (situacao.getCodigoSituacaoProposta().equals(situacaoProposta)) {
				return situacao.getDescricao();
			}
		}
		return DashboardUtils.EMPTY;
	}

	/**
	 * @param retornoConsulta
	 * @param listProposta
	 * @param i
	 */
	private Boolean verificarPropostaExistente(List<Object[]> retornoConsulta, List<Proposta> listProposta, int i) {
		for (Proposta proposta : listProposta) {
			if (proposta.getProposta().equals(Long.parseLong(String.valueOf(retornoConsulta.get(i)[9])))) {
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/exportRelatorioProposta")
	@Secured(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR)
	public void exportRelatorio(@ModelAttribute("consultar_proposta") @Valid ConsultarPropostaDTO consultar,
			BindingResult bindingResult, HttpSession session, Model model, HttpServletResponse response)
			throws Exception {
		
		XSSFWorkbook wb = new XSSFWorkbook();
		String[] hearders = new String[] {"PROPOSTA"
										, "NUMERO EC"
										, "CPF/CNPJ"
										, "DATA ABERTURA DA PROPOSTA"
										, "DATA CADASTRO"
										, "DATA ATIVAÇÃO"
										, "SITUAÇÃO PROPOSTA"
										, "MCC ACATADO"
										, "FERRAMENTA"
										, "BANCO DOMICÍLIO"
										, "AGÊNCIA"
										, "TIPO DE CONTA"
										, "SOLUCAO DE CAPTURA"
										, "ETAPA ATUAL"
										, "STATUS ETAPA ATUAL"
										, "ETAPAS ANTERIORES"
										, "CODIGO PRODUCAO"
										, "RAZÃO SOCIAL"
										, "NOME FANTASIA"
										, "CRÍTICA COM RESSALVA"
										, "CRÍTICA SEM RESSALVA"
										, "CÓDIGO MOTIVO CANCELAMENTO"
										, "DESCRIÇÃO MOTIVO CANCELAMENTO"
										, "PACOTE E-COMMERCE"
										, "PLANO CIELO"
										, "VALOR FATURAMENTO"
										, "QTDE DIAS LIQUIDAÇÃO"
										, "INDICADOR AGRO"
										, "INDICADOR MULTIVAN"
										, "INDICADOR OFERTA ASSOCIADA"
										, "INDICADOR ACEITE OFERTA"
										, "NIVEL OFERTA"
										, "CODIGO OFERTA"
										, "CODIGO COMBO OFERTA ALUGUEL"
										, "LOGIN USUÁRIO OPERADOR"										
										, "NUMERO EC CADEIA FORÇADA"
										, "NUMERO EC ESPELHO"
										, "INDICADOR ESPELHAMENTO TAXA"
										, "NOME EXECUTIVO"
										, "PERFIL SMART"
										, "INDICADOR ENTREGA MAQUINA"};
		try {
			List<Proposta> object = new ArrayList<Proposta>();
			List<Etapa> etapas = new ArrayList<Etapa>();
			List<Critica> critica = new ArrayList<Critica>();
			object = (List<Proposta>) session.getAttribute("listProposta");
			etapas = (List<Etapa>) session.getAttribute("listaEtapa");
			critica = (List<Critica>) session.getAttribute("listaCriticaEtapa");

			XSSFSheet sheet = wb.createSheet();
			XSSFRow row = sheet.createRow(0);

			/* create style */
			XSSFCellStyle style = wb.createCellStyle();
			XSSFFont font = wb.createFont();
			font.setBold(Boolean.TRUE);
			font.setFontHeightInPoints((short) 12);
			style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setFont(font);
			
			for (int i = 0; i < hearders.length; i++) {
				XSSFCell cell = row.createCell(i);
				cell.setCellValue(hearders[i]);
				cell.setCellStyle(style);
				sheet.setColumnWidth(i, i == 0 || i == 1 ? 2500 : 6000);
			}
			
			/*
			 * Formato de data
			 */
			XSSFCellStyle cellStyleData = wb.createCellStyle();
			XSSFCreationHelper createHelper = wb.getCreationHelper();
			cellStyleData.setDataFormat(createHelper.createDataFormat().getFormat("dd/MM/yyyy"));

			if (!object.isEmpty()) {
				for (int i = 0; i < object.size(); i++) {
					
					XSSFRow rowConteudo = sheet.createRow(i + 1);
					
					rowConteudo.createCell((int) 0).setCellValue(object.get(i).getProposta());
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getEstabelecimentoComercial())) {
						rowConteudo.createCell((int) 1).setCellValue(object.get(i).getEstabelecimentoComercial());
					} else {
						rowConteudo.createCell((int) 1).setCellValue(DashboardUtils.EMPTY);
					}
					rowConteudo.createCell((int) 2).setCellValue(object.get(i).getCampoCpfCnpj());
					
					
					XSSFCell cellDataInclusaoRegistro = rowConteudo.createCell((int) 3);
					cellDataInclusaoRegistro.setCellValue(object.get(i).getDataInclusaoRegistro());
					cellDataInclusaoRegistro.setCellStyle(cellStyleData);
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getDataCadastroEc())) {
						XSSFCell cellDataCadastroEc = rowConteudo.createCell((int) 4);
						cellDataCadastroEc.setCellValue(object.get(i).getDataCadastroEc());
						cellDataCadastroEc.setCellStyle(cellStyleData);
					} else {
						rowConteudo.createCell((int) 4).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getDataAtivacaoEc())) {
						XSSFCell cellDataAtivacaoEc = rowConteudo.createCell((int) 5);
						cellDataAtivacaoEc.setCellValue(object.get(i).getDataAtivacaoEc());
						cellDataAtivacaoEc.setCellStyle(cellStyleData);
					} else {
						rowConteudo.createCell((int) 5).setCellValue(DashboardUtils.EMPTY);
					}
					
					rowConteudo.createCell((int) 6).setCellValue(object.get(i).getSituacaoProposta());
					rowConteudo.createCell((int) 7).setCellValue(object.get(i).getMccValidado());

					rowConteudo.createCell((int) 8).setCellValue(object.get(i).getFerramentaDescricao());
					rowConteudo.createCell((int) 9).setCellValue(object.get(i).getBancoDescricao());
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getCodigoAgencia())) {
						rowConteudo.createCell((int) 10).setCellValue(object.get(i).getCodigoAgencia());
					} else {
						rowConteudo.createCell((int) 10).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getTipoContaDescricao())) {
						rowConteudo.createCell((int) 11).setCellValue(object.get(i).getTipoContaDescricao());
					} else {
						rowConteudo.createCell((int) 11).setCellValue(DashboardUtils.EMPTY);
					}
					
					rowConteudo.createCell((int) 12).setCellValue(object.get(i).getSolucaoCapturaDescricao());
					rowConteudo.createCell((int) 13).setCellValue(object.get(i).getEtapa());
					rowConteudo.createCell((int) 14).setCellValue(object.get(i).getStatusDescricao());

					rowConteudo.createCell((int) 15).setCellValue(
							mostrarEtapasConcatenadasNoRelatorio(object.get(i).getEtapaConcatenadas(), etapas));

					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getCodigoAfiliacao())) {
						rowConteudo.createCell((int) 16).setCellValue(object.get(i).getCodigoAfiliacao());
					} else {
						rowConteudo.createCell((int) 16).setCellValue(DashboardUtils.EMPTY);
					}
					rowConteudo.createCell((int) 17).setCellValue(object.get(i).getRazaoSocial());
					rowConteudo.createCell((int) 18).setCellValue(object.get(i).getNomeFantasia());

					rowConteudo.createCell((int) 19).setCellValue(mostrarCriticasConcatenadasNoRelatorio(
							object.get(i).getCriticasConcatenadasComRessalvas(), critica,
							Integer.parseInt(String.valueOf(object.get(i).getCodigoEtapa()))));

					rowConteudo.createCell((int) 20).setCellValue(mostrarCriticasConcatenadasNoRelatorio(
							object.get(i).getCriticasConcatenadasSemRessalvas(), critica,
							Integer.parseInt(String.valueOf(object.get(i).getCodigoEtapa()))));

					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getMotivoCancelamento())) {
						rowConteudo.createCell((int) 21).setCellValue(object.get(i).getMotivoCancelamento());
					} else {
						rowConteudo.createCell((int) 21).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getDescricaoMotivoCancelamento())) {
						rowConteudo.createCell((int) 22).setCellValue(object.get(i).getDescricaoMotivoCancelamento());
					} else {
						rowConteudo.createCell((int) 22).setCellValue(DashboardUtils.EMPTY);
					}
					
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getTipoPacoteComercioEletronicoDescricao())) {
						rowConteudo.createCell((int) 23).setCellValue(object.get(i).getTipoPacoteComercioEletronicoDescricao());
					} else {
						rowConteudo.createCell((int) 23).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getDescricaoTipoPlanoCielo())) {
						rowConteudo.createCell((int) 24).setCellValue(object.get(i).getDescricaoTipoPlanoCielo());
					} else {
						rowConteudo.createCell((int) 24).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getValorFatMedioMensal())) {
						rowConteudo.createCell((int) 25).setCellValue(DashboardUtils.formatBigDecimalToString(object.get(i).getValorFatMedioMensal()));
					} else {
						rowConteudo.createCell((int) 25).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getQuantidadeDiasLiquidacao())) {
						rowConteudo.createCell((int) 26).setCellValue(object.get(i).getQuantidadeDiasLiquidacao());
					} else {
						rowConteudo.createCell((int) 26).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getIndicadorPropostaAgro())) {
						rowConteudo.createCell((int) 27).setCellValue(object.get(i).getIndicadorPropostaAgro());
					} else {
						rowConteudo.createCell((int) 27).setCellValue(DashboardUtils.EMPTY);
					}
					
					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getIndicadorClienteMultivan())) {
						rowConteudo.createCell((int) 28).setCellValue(object.get(i).getIndicadorClienteMultivan());
					} else {
						rowConteudo.createCell((int) 28).setCellValue(DashboardUtils.EMPTY);
					}
					//OFERTAS
					String indOfertaAssociada = object.get(i).getIndOfertaAssociada();
					rowConteudo.createCell((int) 29).setCellValue(DashboardUtils.isNotNullOrEmpty(indOfertaAssociada) ? indOfertaAssociada : DashboardUtils.EMPTY);
					String indAceiteOferta = object.get(i).getIndAceiteOferta();
					rowConteudo.createCell((int) 30).setCellValue(DashboardUtils.isNotNullOrEmpty(indAceiteOferta) ? indAceiteOferta : DashboardUtils.EMPTY);
					String nivelOferta = object.get(i).getNivelOferta();
					rowConteudo.createCell((int) 31).setCellValue(DashboardUtils.isNotNullOrEmpty(nivelOferta) ? nivelOferta : DashboardUtils.EMPTY);
					String codigoOferta = object.get(i).getCodigoOferta();
					rowConteudo.createCell((int) 32).setCellValue(DashboardUtils.isNotNullOrEmpty(codigoOferta) ? codigoOferta : DashboardUtils.EMPTY);
					String codigoComboOferta = object.get(i).getCodigoOfertaCombo();
					rowConteudo.createCell((int) 33).setCellValue(DashboardUtils.isNotNullOrEmpty(codigoComboOferta)? codigoComboOferta : DashboardUtils.EMPTY);

					if (DashboardUtils.isNotNullOrEmpty(object.get(i).getLoginUsuarioOperador())) {
						rowConteudo.createCell((int) 34).setCellValue(object.get(i).getLoginUsuarioOperador());
					} else {
						rowConteudo.createCell((int) 34).setCellValue(DashboardUtils.EMPTY);
					}
					//RL05 SPRINT02-SMART
					Long numEcCadeiaForcada = object.get(i).getNumEcCadeiaForcada();
					rowConteudo.createCell((int) 35).setCellValue(DashboardUtils.isNotNullOrEmpty(numEcCadeiaForcada)? numEcCadeiaForcada.toString() : DashboardUtils.EMPTY);
					Long numEcEspelho = object.get(i).getNumEcEspelho();
					rowConteudo.createCell((int) 36).setCellValue(DashboardUtils.isNotNullOrEmpty(numEcEspelho)? numEcEspelho.toString() : DashboardUtils.EMPTY);
					String indEspelhamentoTaxa = object.get(i).getIndEspelhamentoTaxa();					
					rowConteudo.createCell((int) 37).setCellValue(DashboardUtils.isNotNullOrEmpty(indEspelhamentoTaxa) ? indEspelhamentoTaxa : DashboardUtils.EMPTY);
					String nomeExecutivo = object.get(i).getNomeExecutivo();					
					rowConteudo.createCell((int) 38).setCellValue(DashboardUtils.isNotNullOrEmpty(nomeExecutivo) ? nomeExecutivo : DashboardUtils.EMPTY);
					String perfilSmart = object.get(i).getPerfilSmart();					
					rowConteudo.createCell((int) 39).setCellValue(DashboardUtils.isNotNullOrEmpty(perfilSmart) ? perfilSmart : DashboardUtils.EMPTY);
					String indEntregaMaquina = object.get(i).getIndEntregaMaquina();					
					rowConteudo.createCell((int) 40).setCellValue(DashboardUtils.isNotNullOrEmpty(indEntregaMaquina) ? indEntregaMaquina : DashboardUtils.EMPTY);

				}
			}
			DashboardUtils.contentTypeForBrowser(response, wb, "RELATORIO_PROPOSTA");
		} catch (Exception e) {
			LOG.error("ERRO AO GERAR RELATORIO DE REMESSAS");
			throw e;
		}
		
	}

	private String mostrarEtapasConcatenadasNoRelatorio(String etapasConcetenadas, List<Etapa> et) {
		if (!DashboardUtils.isNotNullOrEmpty(etapasConcetenadas))
			return DashboardUtils.EMPTY;
		String retornoFormatado = DashboardUtils.EMPTY;
		String[] ec = etapasConcetenadas.split(",");
		for (String string : ec) {
			String retorno = obterEtapasParaMontarRelatorio(string, et);
			if (retornoFormatado.equals(DashboardUtils.EMPTY)) {
				retornoFormatado = retorno;
			} else {
				retornoFormatado += DashboardUtils.SEPARADOR_RELATORIO + retorno;
			}
		}
		return retornoFormatado;
	}

	private String obterEtapasParaMontarRelatorio(String codigo, List<Etapa> et) {
		for (Etapa etapa : et) {
			if (DashboardUtils.isNotNullOrEmpty(codigo) && Integer.parseInt(codigo) == etapa.getCodigo()) {
				return etapa.getDescricao();
			}
		}
		return DashboardUtils.EMPTY;
	}

	private String mostrarCriticasConcatenadasNoRelatorio(String criticasConcetenadas, List<Critica> crit,
			Integer etapa) {
		if (!DashboardUtils.isNotNullOrEmpty(criticasConcetenadas))
			return DashboardUtils.EMPTY;
		String retornoFormatado = DashboardUtils.EMPTY;
		String[] ec = criticasConcetenadas.split(",");
		for (String string : ec) {
			String retorno = obterCriticasParaMontarRelatorio(string, crit, etapa);
			if (retornoFormatado.equals(DashboardUtils.EMPTY)) {
				retornoFormatado = retorno;
			} else {
				retornoFormatado += DashboardUtils.SEPARADOR_RELATORIO + retorno;
			}
		}
		return retornoFormatado;
	}

	private String obterCriticasParaMontarRelatorio(String codigo, List<Critica> crit, Integer etapa) {
		for (Critica critica : crit) {
			if (DashboardUtils.isNotNullOrEmpty(codigo) && Integer.parseInt(codigo) == critica.getCodigo()) {
				if (critica.getCodigo().equals(9) || critica.getCodigo().equals(73)) {
					for (int i = 0; i < crit.size(); i++) {
						if (crit.get(i).getCodigo() == critica.getCodigo()
								&& crit.get(i).getEtapa().equals(String.valueOf(etapa))) {
							return crit.get(i).getDescricao();
						}
					}
				} else {
					return critica.getDescricao();
				}
			}
		}
		return DashboardUtils.EMPTY;
	}

	/**
	 * Avança para tela de detalhe da proposta
	 * 
	 * @param numeroProposta
	 * @param session
	 * @return
	 */
	@RequestMapping("redirecionarConsultaDetalheProposta/{numeroProposta}")
	public String redirecionarConsultaDetalheProposta(@PathVariable Long numeroProposta, HttpSession session) {
		session.setAttribute("numeroProposta", numeroProposta);
		return "redirect:/initDetalheProposta";
	}

	/**
	 * Método: retorno da tela de detalhe da proposta
	 * 
	 * @param consultar
	 * @param bindingResult
	 * @param session
	 * @param model
	 * @return
	 */
	@RequestMapping("/historyBackProposta")
	@Secured(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA)
	public String historyBackFromConsultaProposta(
			@ModelAttribute("consultar_proposta") @Valid ConsultarPropostaDTO consultar, BindingResult bindingResult,
			HttpSession session, Model model, Authentication authentication) {
		carregarServicos(session, model, authentication);
		model = carregarAtributosSession(session, model);
		/* REMOVENDO ATRIBUTO DESNECESSARIO DA SESSAO */
		DashboardUtils.removerAtributoToSession(session, "numeroProposta");
		return NavigationDashBoard.CONSULTAR_PROPOSTA;
	}
	
	/**
	 * Método responsavel por popular as informações da combo de ofertas
	 * @return
	 */
	private void obterListaOfertas(Model model, HttpSession session) {		
		try{			
			Optional<List<OfertasInteract>> listaOfertas = ofertasService.consultarListaOfertas();
			if(listaOfertas.isPresent()){
				session.setAttribute("listaOfertas", listaOfertas.get());
				model.addAttribute("listaOfertas", listaOfertas.get());	
				
			}else{
				//TODO ASSUMIMOS O MOCK CASO NAO HAJA REGISTROS, ASSIM QUE O SERVIÇO ESTIVER OK, RETIRAR ESSE 'ELSE'
				LOG.info("LISTA DE OFERTAS (EMPTY), ASSUMINDO MOCK ...");
				assumirMock(model, session);
			}
		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO NA CONSULTA DA LISTA DE OFERTAS, ASSUMINDO MOCK ...");
			assumirMock(model, session);
		}
	}

	/**
	 * TODO Método auxiliar 'mock' deve ser removido assim que o serviço estiver ok
	 * 
	 * @param model
	 * @param session
	 */
	private void assumirMock(Model model, HttpSession session) {
		// TODO Auto-generated method stub
		List<OfertasInteract> listaOfertas = new ArrayList<>();
		listaOfertas.add(new OfertasInteract("000005050","ARV + Taxa de Credenciamento"));
		listaOfertas.add(new OfertasInteract("000005052","ARV"));
		listaOfertas.add(new OfertasInteract("000005054","Desconto Aluguel"));
		listaOfertas.add(new OfertasInteract("000005056","MDR"));
		session.setAttribute("listaOfertas", listaOfertas);
		model.addAttribute("listaOfertas", listaOfertas);		
	}

}
