package br.com.cielo.dashboard.service;

import java.util.List;

import br.com.cielo.credenciamento.dto.TipoPlanoCieloDTO;

public interface ITipoPlanoCieloService {
	
	List<TipoPlanoCieloDTO> getTiposPlanoCielo();
	
}
