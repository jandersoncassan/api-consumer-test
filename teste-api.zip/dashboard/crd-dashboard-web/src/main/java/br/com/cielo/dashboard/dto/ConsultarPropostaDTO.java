/**
 * 
 */
package br.com.cielo.dashboard.dto;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import br.com.cielo.dashboard.model.Bancos;
import br.com.cielo.dashboard.model.Etapa;
import br.com.cielo.dashboard.model.Ferramenta;
import br.com.cielo.dashboard.model.SolucaoCaptura;
import br.com.cielo.dashboard.model.Status;

/**
 * @author dcarneiro
 *
 */
public class ConsultarPropostaDTO {

	private Long numeroProposta;
	private String cpfCnpj;
	private List<Etapa> etapa;
	private List<Status> status;
	private Bancos bancos;
	private Integer codigoProducao;
	@NotEmpty(message="{campo.perido.inicial}")
	private String periodoInicial;
	//@NotEmpty(message="{campo.perido.final}")
	private String periodoFinal;
	private Ferramenta ferramenta;
	private String motivoCancelamento;
	private List<SolucaoCaptura> solucaoCaptura;
	private Long numeroEstabelecimentoComercial;
	private String criticaEtapa;
	
	private Integer[] codigoSolucaoCaptura;
	private Integer[] codigoEtapa;
	private Integer[] codigoStatus;
	private Integer[] codigoFerramenta;
	private Integer[] codigoBanco;
	private Integer[] situacaoProposta;
	
	private String codigoOferta;
	
	private String indEntregaMaquinas;
	
	/**
	 * @return the numeroProposta
	 */
	public Long getNumeroProposta() {
		return numeroProposta;
	}
	/**
	 * @param numeroProposta the numeroProposta to set
	 */
	public void setNumeroProposta(Long numeroProposta) {
		this.numeroProposta = numeroProposta;
	}
	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}
	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	/**
	 * @return the etapa
	 */
	public List<Etapa> getEtapa() {
		return etapa;
	}
	/**
	 * @param etapa the etapa to set
	 */
	public void setEtapa(List<Etapa> etapa) {
		this.etapa = etapa;
	}
	/**
	 * @return the status
	 */
	public List<Status> getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(List<Status> status) {
		this.status = status;
	}
	/**
	 * @return the bancos
	 */
	public Bancos getBancos() {
		return bancos;
	}
	/**
	 * @param bancos the bancos to set
	 */
	public void setBancos(Bancos bancos) {
		this.bancos = bancos;
	}
	/**
	 * @return the codigoProducao
	 */
	public Integer getCodigoProducao() {
		return codigoProducao;
	}
	/**
	 * @param codigoProducao the codigoProducao to set
	 */
	public void setCodigoProducao(Integer codigoProducao) {
		this.codigoProducao = codigoProducao;
	}
	/**
	 * @return the periodoInicial
	 */
	public String getPeriodoInicial() {
		return periodoInicial;
	}
	/**
	 * @param periodoInicial the periodoInicial to set
	 */
	public void setPeriodoInicial(String periodoInicial) {
		this.periodoInicial = periodoInicial;
	}
	/**
	 * @return the periodoFinal
	 */
	public String getPeriodoFinal() {
		return periodoFinal;
	}
	/**
	 * @param periodoFinal the periodoFinal to set
	 */
	public void setPeriodoFinal(String periodoFinal) {
		this.periodoFinal = periodoFinal;
	}
	/**
	 * @return the ferramenta
	 */
	public Ferramenta getFerramenta() {
		return ferramenta;
	}
	/**
	 * @param ferramenta the ferramenta to set
	 */
	public void setFerramenta(Ferramenta ferramenta) {
		this.ferramenta = ferramenta;
	}
	/**
	 * @return the motivoCancelamento
	 */
	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}
	/**
	 * @param motivoCancelamento the motivoCancelamento to set
	 */
	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}
	/**
	 * @return the solucaoCaptura
	 */
	public List<SolucaoCaptura> getSolucaoCaptura() {
		return solucaoCaptura;
	}
	/**
	 * @param solucaoCaptura the solucaoCaptura to set
	 */
	public void setSolucaoCaptura(List<SolucaoCaptura> solucaoCaptura) {
		this.solucaoCaptura = solucaoCaptura;
	}
	/**
	 * @return the numeroEstabelecimentoComercial
	 */
	public Long getNumeroEstabelecimentoComercial() {
		return numeroEstabelecimentoComercial;
	}
	/**
	 * @param numeroEstabelecimentoComercial the numeroEstabelecimentoComercial to set
	 */
	public void setNumeroEstabelecimentoComercial(Long numeroEstabelecimentoComercial) {
		this.numeroEstabelecimentoComercial = numeroEstabelecimentoComercial;
	}
	/**
	 * @return the criticaEtapa
	 */
	public String getCriticaEtapa() {
		return criticaEtapa;
	}
	/**
	 * @param criticaEtapa the criticaEtapa to set
	 */
	public void setCriticaEtapa(String criticaEtapa) {
		this.criticaEtapa = criticaEtapa;
	}
	/**
	 * @return the codigoSolucaoCaptura
	 */
	public Integer[] getCodigoSolucaoCaptura() {
		return codigoSolucaoCaptura;
	}
	/**
	 * @param codigoSolucaoCaptura the codigoSolucaoCaptura to set
	 */
	public void setCodigoSolucaoCaptura(Integer[] codigoSolucaoCaptura) {
		this.codigoSolucaoCaptura = codigoSolucaoCaptura;
	}
	/**
	 * @return the codigoEtapa
	 */
	public Integer[] getCodigoEtapa() {
		return codigoEtapa;
	}
	/**
	 * @param codigoEtapa the codigoEtapa to set
	 */
	public void setCodigoEtapa(Integer[] codigoEtapa) {
		this.codigoEtapa = codigoEtapa;
	}
	/**
	 * @return the codigoStatus
	 */
	public Integer[] getCodigoStatus() {
		return codigoStatus;
	}
	/**
	 * @param codigoStatus the codigoStatus to set
	 */
	public void setCodigoStatus(Integer[] codigoStatus) {
		this.codigoStatus = codigoStatus;
	}
	/**
	 * @return the codigoFerramenta
	 */
	public Integer[] getCodigoFerramenta() {
		return codigoFerramenta;
	}
	/**
	 * @param codigoFerramenta the codigoFerramenta to set
	 */
	public void setCodigoFerramenta(Integer[] codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
	}
	/**
	 * @return the codigoBanco
	 */
	public Integer[] getCodigoBanco() {
		return codigoBanco;
	}
	/**
	 * @param codigoBanco the codigoBanco to set
	 */
	public void setCodigoBanco(Integer[] codigoBanco) {
		this.codigoBanco = codigoBanco;
	}
	/**
	 * @return the situacaoProposta
	 */
	public Integer[] getSituacaoProposta() {
		return situacaoProposta;
	}
	/**
	 * @param situacaoProposta the situacaoProposta to set
	 */
	public void setSituacaoProposta(Integer[] situacaoProposta) {
		this.situacaoProposta = situacaoProposta;
	}
	/**
	 * @return the codigoOferta
	 */
	public String getCodigoOferta() {
		return codigoOferta;
	}
	/**
	 * @param codigoOferta the codigoOferta to set
	 */
	public void setCodigoOferta(String codigoOferta) {
		this.codigoOferta = codigoOferta;
	}
	/**
	 * @return the indEntregaMaquinas
	 */
	public String getIndEntregaMaquinas() {
		return indEntregaMaquinas;
	}
	/**
	 * @param indEntregaMaquinas the indEntregaMaquinas to set
	 */
	public void setIndEntregaMaquinas(String indEntregaMaquinas) {
		this.indEntregaMaquinas = indEntregaMaquinas;
	}

	
}
