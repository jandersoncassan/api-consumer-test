/**
 * 
 */
package br.com.cielo.dashboard.dto;

import java.io.Serializable;

/**
 * @author dcarneiro
 *
 */
public class ProdutosDTO implements Serializable{

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;

	private Integer codigo;
	private String descricao;
	private String quantidadeParcelas;
	private String quantidadeDiasLiquidacao;
	private String indicadorHabilitacao;
	private String codigoErro;
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the quantidadeParcelas
	 */
	public String getQuantidadeParcelas() {
		return quantidadeParcelas;
	}
	/**
	 * @param quantidadeParcelas the quantidadeParcelas to set
	 */
	public void setQuantidadeParcelas(String quantidadeParcelas) {
		this.quantidadeParcelas = quantidadeParcelas;
	}
	/**
	 * @return the quantidadeDiasLiquidacao
	 */
	public String getQuantidadeDiasLiquidacao() {
		return quantidadeDiasLiquidacao;
	}
	/**
	 * @param quantidadeDiasLiquidacao the quantidadeDiasLiquidacao to set
	 */
	public void setQuantidadeDiasLiquidacao(String quantidadeDiasLiquidacao) {
		this.quantidadeDiasLiquidacao = quantidadeDiasLiquidacao;
	}
	/**
	 * @return the indicadorHabilitacao
	 */
	public String getIndicadorHabilitacao() {
		return indicadorHabilitacao;
	}
	/**
	 * @param indicadorHabilitacao the indicadorHabilitacao to set
	 */
	public void setIndicadorHabilitacao(String indicadorHabilitacao) {
		this.indicadorHabilitacao = indicadorHabilitacao;
	}
	/**
	 * @return the codigoErro
	 */
	public String getCodigoErro() {
		return codigoErro;
	}
	/**
	 * @param codigoErro the codigoErro to set
	 */
	public void setCodigoErro(String codigoErro) {
		this.codigoErro = codigoErro;
	}
}
