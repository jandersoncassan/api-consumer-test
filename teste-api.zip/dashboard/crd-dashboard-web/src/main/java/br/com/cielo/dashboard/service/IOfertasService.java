package br.com.cielo.dashboard.service;

import java.util.List;
import java.util.Optional;

import br.com.cielo.dashboard.model.ConsultaOfertas;
import br.com.cielo.dashboard.model.Oferta;
import br.com.cielo.dashboard.model.OfertasInteract;

/**
 * Interface responsavel pela consulta de ofertas de credenciamento
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 *
 */
public interface IOfertasService {

	/**
	 * Método responsavel por efetuar a consulta das ofertas cadastradas
	 * @param infoOfertas
	 * @return
	 */
	Optional<List<Oferta>> consultarOfertas(ConsultaOfertas infoOfertas);
	
	/**
	 * Método responsavel por efetuar a consulta das ofertas cadastradas
	 * @param infoOfertas
	 * @return
	 */
	Optional<List<OfertasInteract>> consultarListaOfertas();

}
