/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarProprietariosService {
	/**
	 * Método: Obtem lista de proprietarios relacionados a proposta
	 * @param proposta
	 * @return
	 */
	List<Object[]> getListarProprietariosByProposta(final Long proposta);
}
