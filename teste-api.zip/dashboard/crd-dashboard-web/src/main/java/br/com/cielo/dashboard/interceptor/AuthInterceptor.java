package br.com.cielo.dashboard.interceptor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * Classe Interceptor para validação da sessão do usuário
 * @author @Cielo
 * @since 1.0.0
 */
public class AuthInterceptor extends HandlerInterceptorAdapter {
	
	private static final String REGEX_END_WITH_URI="^(\\/crd-)+(.)*(web|web/|\\/welcome|\\/processLogin|\\/logout|\\/initWelcome)$";
	private static final String REGEX_CONTAINS_URI=".*\\/resources.*";

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		String uri = request.getRequestURI();	
		
		tratarUriProcess(uri, request, response);
		
		if(isEndsWithOrContains(uri)){
			return Boolean.TRUE;
		}	
			return validarUsuarioLogado(request, response);
	}
	
	private void tratarUriProcess(String uri, HttpServletRequest request, HttpServletResponse response) throws ServletException{
		if(uri.matches("^(\\/crd-)+(.)*(web|web/)")){
			request.getSession().invalidate();
			request.logout();
		}
	}


	/**
	 * Método responsavel por verificar se o usuário está logado na aplicação
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	private Boolean validarUsuarioLogado(HttpServletRequest request, HttpServletResponse response) throws IOException{
		HttpSession session = request.getSession(false);
		if(session != null && !session.isNew()) {
			return Boolean.TRUE;
		}
		//response.sendRedirect(INITIAL_PAGE);
		response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		return Boolean.FALSE;
	}
	
	/**
	 * Método responsavel pela validação da URI (endsWith e contains)
	 * @param uri
	 * @return Boolean
	 */
	private Boolean isEndsWithOrContains(String uri){
		return(isEndsWith(uri) || isContains(uri));
	}
	
	/**
	 * Método responsavel pela validação se a URI é terminada com alguns contextos que não devem ser tratados no controle de sessão
	 * @param uri
	 * @return Boolean
	 */
	private Boolean isEndsWith(String uri){
		return(uri.matches(REGEX_END_WITH_URI));
	}
	/**
	 * Método responsavel por verificar se a URI contains alguns contextos  que não devem ser tratados no controle de sessão
	 * @param uri
	 * @return
	 */
	private static Boolean isContains(String uri){
		return(uri.matches(REGEX_CONTAINS_URI));
	}


}
