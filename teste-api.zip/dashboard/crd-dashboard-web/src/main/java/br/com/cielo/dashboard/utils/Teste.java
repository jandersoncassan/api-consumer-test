package br.com.cielo.dashboard.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class Teste {

	static final String DATEFORMAT = "yyyy-MM-dd";

	public static void main(String[] args) throws Exception {
		GetUTCdatetimeAsDate();
	}

	public static Date GetUTCdatetimeAsDate() {
		// note: doesn't check for null
		return StringDateToDate(GetUTCdatetimeAsString(new Date()));
	}

	public static String GetUTCdatetimeAsString(Date d) {
		final SimpleDateFormat sdf = new SimpleDateFormat(DATEFORMAT);
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		final String utcTime = sdf.format(d);
		System.out.println("UTC " + utcTime);
		return utcTime;
	}

	public static Date StringDateToDate(String StrDate) {
		Date dateToReturn = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat(DATEFORMAT);

		try {
			dateToReturn = (Date) dateFormat.parse(StrDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.println(dateToReturn);
		return dateToReturn;
	}

}
