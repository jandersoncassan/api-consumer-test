package br.com.cielo.dashboard.service;

import br.com.cielo.dashboard.dto.InfoUsuarioLdapDTO;
import br.com.cielo.dashboard.model.Usuario;

/**
 * Interface responsavel pelas operações de autorizar/autenticar LDAP
 * @author @Cielo
 * @since 1.0.0
 */
public interface LdapService {

	/**
	 * Método responsavel pela autenticação / autorização do usuário no LDAP
	 * @param usuario
	 * @return InfoUsuarioLdapDTO
	 */
	InfoUsuarioLdapDTO autenticarUsuario(Usuario usuario);
	
}
