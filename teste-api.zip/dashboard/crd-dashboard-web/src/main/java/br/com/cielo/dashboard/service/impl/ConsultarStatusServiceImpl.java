package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarStatusServiceRemote;
import br.com.cielo.dashboard.service.IConsultarStatusService;

/**
 * 
 * @author dcarneiro
 *
 */
@Service
public class ConsultarStatusServiceImpl implements IConsultarStatusService{

	private static final Logger LOG = LogManager.getLogger(LdapServiceImpl.class);
	
	@Resource(mappedName = "ConsultarStatusService#br.com.cielo.credenciamento.service.dashboard.ConsultarStatusServiceRemote")
	private ConsultarStatusServiceRemote consultarStatusServiceRemote;
	
	@Override
	public List<Object> getListaStatus() {
		LOG.info("REALIZANDO CONSULTA DAS ETAPAS DO CREDENCIAMENTO");
		return consultarStatusServiceRemote.getListaStatus();
	}

}
