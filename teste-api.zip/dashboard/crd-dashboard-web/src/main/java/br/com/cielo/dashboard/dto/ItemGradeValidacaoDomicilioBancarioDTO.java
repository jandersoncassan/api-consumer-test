package br.com.cielo.dashboard.dto;

import java.io.Serializable;

public class ItemGradeValidacaoDomicilioBancarioDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Integer codigoFerramenta;
	private String descricaoFerramenta;
	private Integer codigoSolucaoCaptura;
	private String descricaoSolucaoCaptura;
	private String codigoSituacaoCadastral;
	private String idValidacaoDomicilioBancario;
	
	
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
		atualizarIdValidacaoDomicilioBancario();
	}
	public String getDescricaoFerramenta() {
		return descricaoFerramenta;
	}
	public void setDescricaoFerramenta(String descricaoFerramenta) {
		this.descricaoFerramenta = descricaoFerramenta;
	}
	public Integer getCodigoSolucaoCaptura() {
		return codigoSolucaoCaptura;
	}
	public void setCodigoSolucaoCaptura(Integer codigoSolucaoCaptura) {
		this.codigoSolucaoCaptura = codigoSolucaoCaptura;
		atualizarIdValidacaoDomicilioBancario();
	}
	public String getDescricaoSolucaoCaptura() {
		return descricaoSolucaoCaptura;
	}
	public void setDescricaoSolucaoCaptura(String descricaoSolucaoCaptura) {
		this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
	}
	public String getCodigoSituacaoCadastral() {
		return codigoSituacaoCadastral;
	}
	public void setCodigoSituacaoCadastral(String codigoSituacaoCadastral) {
		this.codigoSituacaoCadastral = codigoSituacaoCadastral;
	}
	
	public String getIdValidacaoDomicilioBancario(){
		return this.idValidacaoDomicilioBancario;
	}
	
	private void atualizarIdValidacaoDomicilioBancario(){
		this.idValidacaoDomicilioBancario = this.codigoFerramenta + "_" + this.codigoSolucaoCaptura;
	}
}
