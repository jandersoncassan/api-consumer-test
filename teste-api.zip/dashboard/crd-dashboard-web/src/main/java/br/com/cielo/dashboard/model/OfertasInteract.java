package br.com.cielo.dashboard.model;

/**
 * Classe responsavel pelo dominio de ofertas de credenciamento disponiveis no Interact
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 */
public class OfertasInteract {

	private String codigo;
	private String descricao;
	
	public OfertasInteract(){}
	
	public OfertasInteract(String codigo, String descricao){
		this.codigo = codigo;
		this.descricao = descricao;
	}
	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
