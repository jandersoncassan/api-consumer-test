package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.MccDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccManutencaoRequestDTO;
import br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoMccServiceRemote;
import br.com.cielo.dashboard.service.IParametrizacaoMCCService;

@Service
public class ParametrizacaoMCCServiceImpl implements IParametrizacaoMCCService {
	
	@Resource(mappedName="ParametrizacaoMccService#br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoMccServiceRemote")
	private ParametrizacaoMccServiceRemote parametrizacaoMCCServiceRemote;
	
	
	@Override
	public List<MccDTO> getListaDominiosMcc() {
		return parametrizacaoMCCServiceRemote.getListaDominiosMcc();
	}

	@Override
	public boolean verificarMccValido(Integer codigoMcc, String tipoPessoa, Integer codigoFerramenta) {
		return parametrizacaoMCCServiceRemote.verificarMccValido(codigoMcc, tipoPessoa, codigoFerramenta);
	}

	@Override
	public List<ParametrizacaoMccDTO> filtrarParametrizacao(List<Integer> codigosMcc, List<String> tiposPessoa,
			List<Integer> codigosFerramenta) {
		return parametrizacaoMCCServiceRemote.filtrarParametrizacao(codigosMcc, tiposPessoa, codigosFerramenta);
	}

	@Override
	public void atualizarParametrizacao(ParametrizacaoMccManutencaoRequestDTO request) {
		parametrizacaoMCCServiceRemote.atualizarParametrizacao(request);		
	}
}
