/**
 * 
 */
package br.com.cielo.dashboard.utils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.Formatter;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author dcarneiro
 *
 */
public class DashboardUtils {

	private static final Logger LOG = LogManager.getLogger(DashboardUtils.class);
	
	private static final ObjectMapper objectMapper = new ObjectMapper();

	
	public static final String PATTERN_YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
	public static final String PATTERN_DD_MM_YYYY_HH_MM_SS = "dd/MM/yyyy HH:mm:ss";
	public static final String PATTERN_DD_MM_YYYY = "dd/MM/yyyy";
	public static final String PATTERN_YYYY_MM_DD = "yyyy-MM-dd";
	public static final String PATTERN_MM_YYYY = "MM/yyyy";
	public static final String PATTERN_YYYY = "yyyy";

	public static final String N = "N";
	public static final String BANCO_ON_LINE = "Bancos On-line";
	public static final String BANCO_BATCH = "Bancos Batch";
	public static final String SITE = "Site";
    public static final String VENDING_MACHINE = "Vending Machine";
    public static final String DESENVOLVEDORES_LIO = "Desenvolvedores Lio";	
    public static final String CENTRAL = "Central";
    public static final String SMART = "Smart";
    public static final String FEIRAS = "Feiras";
	public static final String BRADESCO = "Bradesco";
	public static final String CEF = "CAIXA";
	public static final String BB = "Banco do Brasil";
	public static final String S = "S";
	public static final String PROCESSADO = "Processado";
	public static final String ENVIADO = "Enviado";
	public static final String EM_PROCESSAMENTO = "Em Processamento";
	public static final String REJEITADO = "Rejeitado";
	public static final String EMPTY = "";
	public static final String REGEX_FORMAT_CPF = "(\\d{3})(\\d{3})(\\d{3})(\\d{2})";
	public static final String REGEX_FORMAT_CNPJ = "(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})";
	public static final String REGEX_FORMAT_CPF_APRESENTACAO = "$1.$2.$3-$4";
	public static final String REGEX_FORMAT_CNPJ_APRESENTACAO = "$1.$2.$3/$4-$5";
	public static final String LOCAL_DATE_FORMAT = "d/MM/uuuu";
	public static final String SIM = "Sim";
	public static final String NAO = "Não";
	public static final String FISICA = "F";
	public static final String NULL = "null";
	public static final String SEPARADOR_RELATORIO = " @ ";
	public static final String SRING_ZERO = "0";
	public static final String STRING_EMPTY = "";	

	/* SERVICES OSB SOAP*/
	public static final String USER = "soap.header.id";
	public static final String PASSWORD = "soap.header.senha";	
	
	public static final String ENDPOINT_CONSULTAR_OFERTAS_INTERACT = "endpoint.consultar.ofertas.interact";
	public static final String ENDPOINT_CONSULTAR_LISTA_OFERTAS = "endpoint.consultar.lista.ofertas";
	
	/**
	 * Método: Formatar Data String
	 * 
	 * @param data
	 * @return
	 * @throws ParseException
	 */
	public static String convertStringToDate(String data) throws ParseException {
		DateFormat oldFormatter = new SimpleDateFormat(PATTERN_YYYY_MM_DD_HH_MM_SS);
		DateFormat newFormatter = new SimpleDateFormat(PATTERN_DD_MM_YYYY_HH_MM_SS);
		Date oldDate = (Date) oldFormatter.parse(data);
		return newFormatter.format(oldDate);
	}

	/**
	 * Método: Formatar Data String
	 * 
	 * @param data
	 * @return
	 * @throws ParseException
	 */
	public static String convertDateToString(String data) throws ParseException {
		DateFormat oldFormatter = new SimpleDateFormat(PATTERN_YYYY_MM_DD_HH_MM_SS);
		DateFormat newFormatter = new SimpleDateFormat(PATTERN_DD_MM_YYYY);
		Date oldDate = (Date) oldFormatter.parse(data);
		return newFormatter.format(oldDate);
	}

	/**
	 * Metodo: Converte String to Date
	 * 
	 * @param d
	 * @return {DATE}
	 */
	public static String convertDataSimples(Date date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(PATTERN_DD_MM_YYYY);
		return simpleDateFormat.format(date);
	}
	/**
	 * Metodo: Converte String to Date
	 * 
	 * @param d
	 * @return {DATE}
	 */
	public static String convertDataSimplesPattern_MM_YYYY(Date date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(PATTERN_MM_YYYY);
		return simpleDateFormat.format(date);
	}
	
	/**
	 * Metodo: Converte String to Date
	 * 
	 * @param d
	 * @return {DATE}
	 */
	public static String convertDataSimplesPattern_YYYY(Date date) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(PATTERN_YYYY);
		return simpleDateFormat.format(date);
	}
	/**
	 * Método: Utilizado para popular as datas para pesquisa no dashboard mensal.
	 * Pesquisa será com mes hoje (-6)
	 * @return
	 */
	public static List<String> calcularMesAnoParaPesquisaDashboard(){
		List<String> listaDatas = new ArrayList<String>();
		for(int i=0;i<=6;i++){
			Calendar dat = Calendar.getInstance();
			dat.add(Calendar.MONTH,-i);
			listaDatas.add(DashboardUtils.convertDataSimplesPattern_MM_YYYY(dat.getTime()));
		}
		return listaDatas;
	}
	
	/**
	 * Método: Utilizado para popular as datas para pesquisa no dashboard anual.
	 * @return
	 */
	public static List<String> calcularAnoParaPesquisaDashboard(){
		List<String> listaDatas = new ArrayList<String>();
		for(int i=0;i<=1;i++){
			Calendar dat = Calendar.getInstance();
			dat.add(Calendar.YEAR,-i);
			listaDatas.add(DashboardUtils.convertDataSimplesPattern_YYYY(dat.getTime()));
		}
		return listaDatas;
	}
	
	/**
	 * @param response
	 * @param wb
	 * @throws IOException
	 */
	public static void contentTypeForBrowser(HttpServletResponse response, XSSFWorkbook wb, String nomeRelatorio)
			throws IOException {
		ByteArrayOutputStream outByteStream = new ByteArrayOutputStream();
		wb.write(outByteStream);
		byte[] outArray = outByteStream.toByteArray();
		response.setContentType("application/ms-excel");
		response.setContentLength(outArray.length);
		response.setHeader("Expires:", "0"); // eliminates browser caching
		response.setHeader("Content-Disposition",
				"attachment; filename=" + nomeRelatorio + "_" + convertDataSimples(new Date()) + "_.xls");
		OutputStream outStream = response.getOutputStream();
		outStream.write(outArray);
		outStream.flush();
	}

	/**
	 * 
	 * @param object
	 * @return
	 */
	public static Boolean isNotNullOrEmpty(Object object) {
		if (object != null && !object.equals(EMPTY)) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}
	
    /**
     * Método: Validar List se for null ou vazia
     * 
     * @param object
     * @return Boolean
     */
    public static Boolean isListEmptyOrNull(final List<?> object) {

        Boolean valid = Boolean.FALSE;

        if (null == object || object.isEmpty()) {
            valid = Boolean.TRUE;
        }
        return valid;
    }
	/**
	 * Método: Formata Numero gerais
	 * 
	 * @param valor
	 * @param quantidade
	 * @return String
	 */
	public static String addZerosEsquerdaComplemento(final String valor, final Integer quantidade) {
		return StringUtils.leftPad(valor, quantidade, '0');
	}

	/**
	 * Método: FORMATA CPF PARA APRESENTAÇÃO
	 * 
	 * @param cpf
	 * @param digito
	 * @return
	 */
	public static String formatCpf(Integer cpf, Integer digito) {
		String corpoCpf = addZerosEsquerdaComplemento(cpf.toString(), 9);
		String digitoCpf = addZerosEsquerdaComplemento(digito.toString(), 2);
		String ret = DashboardUtils.EMPTY;
		Pattern pattern = Pattern.compile(REGEX_FORMAT_CPF);
		Matcher matcher = pattern.matcher(corpoCpf.concat(digitoCpf));
		try {
			if (matcher.matches())
				ret = matcher.replaceAll(REGEX_FORMAT_CPF_APRESENTACAO);
		} catch (Exception e) {
		}
		return ret;
	}

	/**
	 * Método: FORMATA CNPJ PARA APRESENTAÇÃO
	 * 
	 * @param CNPJ
	 * @param Filial
	 * @param digito
	 * @return
	 */
	public static String formatCnpj(Integer cnpj, Integer filial, Integer digito) {
		String corpoCnpj = addZerosEsquerdaComplemento(cnpj.toString(), 8);
		String filiaCnpj = addZerosEsquerdaComplemento(filial.toString(), 4);
		String digitoCnpj = addZerosEsquerdaComplemento(digito.toString(), 2);
		String ret = DashboardUtils.EMPTY;
		Pattern pattern = Pattern.compile(REGEX_FORMAT_CNPJ);
		Matcher matcher = pattern.matcher(corpoCnpj.concat(filiaCnpj).concat(digitoCnpj));
		try {
			if (matcher.matches())
				ret = matcher.replaceAll(REGEX_FORMAT_CNPJ_APRESENTACAO);
		} catch (Exception e) {
		}
		return ret;
	}

	/**
	 * 
	 * @param session
	 * @return
	 */
	public static HttpSession removerAllAtributosSession(HttpSession session) {
		Enumeration<String> sessionAttr = session.getAttributeNames();

		while (sessionAttr.hasMoreElements()) {
			String attrName = ((Enumeration<String>) sessionAttr).nextElement();
			if (attrName.indexOf("\\__\\") != 0 && !attrName.equalsIgnoreCase("username")) {
				session.removeAttribute(attrName);
			}
		}
		return session;
	}
	
	/**
	 * 
	 * @param session
	 * @return
	 */
	public static HttpSession removerAtributoToSession(HttpSession session, String atributo) {
		if (isNotNullOrEmpty(session.getAttribute(atributo))) {
			session.removeAttribute(atributo);
		}
		return session;
	}

	/**
	 * 
	 * @param codigoFerramenta
	 * @return
	 */
	public static String descricaFerramenta(final String codigoFerramenta) {
		String ferramenta;
		switch (codigoFerramenta) {
		case "1":
			ferramenta = BANCO_BATCH;
			break;
		case "2":
			ferramenta = BANCO_ON_LINE;
			break;
		case "3":
			ferramenta = SITE;
			break;
        case "4":
            ferramenta = CENTRAL;
            break;
        case "5":
            ferramenta = VENDING_MACHINE;
            break;
        case "6":
            ferramenta = DESENVOLVEDORES_LIO;
            break;
        case "7":
            ferramenta = SMART;
            break;
        case "8":
            ferramenta = FEIRAS;
            break;

        default:
			ferramenta = EMPTY;
			break;
		}
		return ferramenta;
	}

	/**
	 * Método: Formata CEP
	 * 
	 * @param cep
	 * @return
	 */
	public static String formatCep(final String cep) {
		String cepComZeros = addZerosEsquerdaComplemento(cep, 8);
		Pattern pattern = Pattern.compile("(\\d{5})(\\d{3})");
		Matcher matcher = pattern.matcher(cepComZeros);
		if (matcher.matches()) {
			return matcher.replaceAll("$1-$2");
		}
		return EMPTY;
	}

	/**
	 * Método: Formatar Telefone
	 * 
	 * @param cep
	 * @return
	 */
	public static String formatTelefone(final String telefone) {
		Pattern pattern = Pattern.compile("(\\d{0,5})(\\d{4})");
		Matcher matcher = pattern.matcher(telefone);
		if (matcher.matches()) {
			return matcher.replaceAll("$1-$2");
		}
		return EMPTY;
	}

	/**
	 * 
	 * @param valor
	 * @return
	 */
	public static String obterCorpoCpfCnpj(String valor) {
		String corpo = DashboardUtils.EMPTY;
		if (!isNotNullOrEmpty(valor)) {
			return corpo;
		}
		if (valor.length() <= 14) {
			corpo = valor.split("-")[0].replace(".", "");
		} else {
			corpo = valor.split("/")[0].replace(".", "");
		}
		return corpo;
	}

	public static BindingResultClear clearFormFieldValues(BindingResult result, Model model, String... fieldsToClear) {
		final BindingResultClear configuredBindingResult = new BindingResultClear(result);
		for (String fieldToClear : fieldsToClear) {
			configuredBindingResult.clearFieldValueFor(fieldToClear);
		}
		return configuredBindingResult;
	}

	/**
	 * Otem as datas correntes do Mês
	 * 
	 * @return
	 */
	public static List<LocalDate> obtemDiasMes() {
		Calendar c = Calendar.getInstance();
		int ano = c.get(Calendar.YEAR);
		int mes = c.get(Calendar.MONTH);
		YearMonth anoMes = YearMonth.of(ano, mes + 1);

		List<LocalDate> listaDosDiasUteisDoMes = Stream.iterate(anoMes.atDay(1), data -> data.plusDays(1))
				.limit(c.get(Calendar.DAY_OF_MONTH)).collect(Collectors.toList());
		return listaDosDiasUteisDoMes;
	}

	/**
	 * 
	 * @param local
	 * @return
	 */
	public static String formatLocalDate(LocalDate local) {
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern(LOCAL_DATE_FORMAT);
		return local.format(formatters);
	}

	/**
	 * 
	 * @param d
	 * @return
	 */
	public static String uTCdatetimeAsString(Date d) {
		final SimpleDateFormat sdf = new SimpleDateFormat(PATTERN_YYYY_MM_DD);
		sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
		final String utcTime = sdf.format(d);
		System.out.println("UTC " + utcTime);
		return utcTime;
	}
	/**
	 * 
	 * @param num
	 * @return
	 */
	@SuppressWarnings("resource")
	public static String formatNumber(String num) {
		Formatter formatter = new Formatter();
		return formatter.format("%,d", Integer.parseInt(num)).toString();
	}
	
	/**
	 * 
	 * @param n
	 * @return
	 */
	public static String formatBigDecimalToString(BigDecimal n) {
		Locale meuLocal = new Locale( "pt", "BR" ); 
		NumberFormat nf = NumberFormat.getCurrencyInstance( meuLocal ); 
	    return nf.format(n);
	}
	
    /**
     * Método responsavel por gerar o json
     * 
     * @param object
     * @return byte[]
     * @throws IllegalArgumentException
     */
    public static byte[] deflate(String operacao, Object object) throws IllegalArgumentException {

        byte[] bytes = null;
        String json = objectToString(object);
        bytes = json.getBytes();
        printLog(operacao, new String(bytes));
        return bytes;
    }
    
    /**
     * Método responsavel por devolver o json do object proposta
     * 
     * @param object
     * @return
     */
    private static String objectToString(Object object) {
    	try {
			return objectMapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			LOG.error("ERRO AO TRANSFORMAR O OBJECT EM JSON : {}", e);
			return STRING_EMPTY;
		}
    }

    /**
     * Print das informações de log
     * 
     * @param operacao
     * @param mensagem
     */
    private static void printLog(String operacao, String mensagem) {
        LOG.info("-=-=-=-=-=-=-=-=>".concat(operacao).concat(" PAYLOAD : {}"), mensagem);
    }

}
