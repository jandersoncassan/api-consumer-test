package br.com.cielo.dashboard.dto;

import java.io.Serializable;
import java.util.List;

import br.com.cielo.dashboard.dto.ItemGradeParametrizacaoBoasVindasDTO;

public class ParametrizacaoBoasVindasAuxiliarDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<ItemGradeParametrizacaoBoasVindasDTO> parametrizacoesBoasVindas;
	private List<String> itensAtivos;
	
	public List<ItemGradeParametrizacaoBoasVindasDTO> getParametrizacoesBoasVindas() {
		return parametrizacoesBoasVindas;
	}
	public void setParametrizacoesBoasVindas(List<ItemGradeParametrizacaoBoasVindasDTO> parametrizacoesBoasVindas) {
		this.parametrizacoesBoasVindas = parametrizacoesBoasVindas;
	}
	public List<String> getItensAtivos() {
		return itensAtivos;
	}
	public void setItensAtivos(List<String> itensAtivos) {
		this.itensAtivos = itensAtivos;
	}
	
}
