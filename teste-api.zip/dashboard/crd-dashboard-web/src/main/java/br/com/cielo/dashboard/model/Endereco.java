/**
 * 
 */
package br.com.cielo.dashboard.model;

import java.io.Serializable;

/**
 * @author dcarneiro
 *
 */
public class Endereco implements Serializable {

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;
	
	private String tipoEndereco;
	private String logradouro;
	private String complementoLogradouro;
	private String cidade;
	private String estado;
	private String cep;
	private String numeroLogradouro;
	/**
	 * @return the tipoEndereco
	 */
	public String getTipoEndereco() {
		return tipoEndereco;
	}
	/**
	 * @param tipoEndereco the tipoEndereco to set
	 */
	public void setTipoEndereco(String tipoEndereco) {
		this.tipoEndereco = tipoEndereco;
	}
	/**
	 * @return the logradouro
	 */
	public String getLogradouro() {
		return logradouro;
	}
	/**
	 * @param logradouro the logradouro to set
	 */
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	/**
	 * @return the complementoLogradouro
	 */
	public String getComplementoLogradouro() {
		return complementoLogradouro;
	}
	/**
	 * @param complementoLogradouro the complementoLogradouro to set
	 */
	public void setComplementoLogradouro(String complementoLogradouro) {
		this.complementoLogradouro = complementoLogradouro;
	}
	/**
	 * @return the cidade
	 */
	public String getCidade() {
		return cidade;
	}
	/**
	 * @param cidade the cidade to set
	 */
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}
	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}
	/**
	 * @return the cep
	 */
	public String getCep() {
		return cep;
	}
	/**
	 * @param cep the cep to set
	 */
	public void setCep(String cep) {
		this.cep = cep;
	}
	/**
	 * @return the numeroLogradouro
	 */
	public String getNumeroLogradouro() {
		return numeroLogradouro;
	}
	/**
	 * @param numeroLogradouro the numeroLogradouro to set
	 */
	public void setNumeroLogradouro(String numeroLogradouro) {
		this.numeroLogradouro = numeroLogradouro;
	}
}
