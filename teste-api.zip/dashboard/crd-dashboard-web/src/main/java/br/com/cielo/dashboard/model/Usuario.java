package br.com.cielo.dashboard.model;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;

public class Usuario {

	@NotEmpty(message="{campo.usuario.login}")
	private String login;
	
	@NotEmpty(message="{campo.usuario.senha}")
	private String senha;
	
	private String nome;
	
	private List<String> listaRoles = new ArrayList<>();
	
	private List<GrantedAuthority> listaAuthorities = new ArrayList<>();
	
	/**
	 * @return the login
	 */
	public String getLogin() {
		return login;
	}
	
	/**
	 * @param login the login to set
	 */
	public void setLogin(String login) {
		this.login = login;
	}
	
	/**
	 * @return the senha
	 */
	public String getSenha() {
		return senha;
	}
	
	/**
	 * @param senha the senha to set
	 */
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public void addRole(String role) {
		this.listaRoles.add(role);
	}
	
	public boolean removeRole(String role) {
		return this.listaRoles.remove(role);
	}
	
	public boolean findRole(String role) {
		return this.listaRoles.contains(role);
	}

	public List<String> getListaRoles() {
		return listaRoles;
	}

	public void setListaRoles(List<String> listaRoles) {
		this.listaRoles = listaRoles;
	}
	
	public List<GrantedAuthority> getListaAuthorities() {
        this.listaAuthorities = new ArrayList<>();
        
		for (String role : this.listaRoles) {
            this.listaAuthorities.add(new SimpleGrantedAuthority(role));
        }
        return this.listaAuthorities;
    }

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}
	
}
