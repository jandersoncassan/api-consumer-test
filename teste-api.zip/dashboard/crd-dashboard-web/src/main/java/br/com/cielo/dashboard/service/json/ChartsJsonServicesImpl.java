/**
 * 
 */
package br.com.cielo.dashboard.service.json;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.cielo.credenciamento.service.dashboard.ChartServiceRemote;

/**
 * @author dcarneiro
 *
 */

@RestController
public class ChartsJsonServicesImpl  {
	
	private static final Logger LOG = LogManager.getLogger(ChartsJsonServicesImpl.class);

	@Resource(mappedName = "ChartService#br.com.cielo.credenciamento.service.dashboard.ChartServiceRemote")
	private ChartServiceRemote serviceRemote;

	@RequestMapping(value = "/ferramentaBancosSucesso/{mesAno}" , method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findSucesso(@PathVariable("mesAno") String mesAno) throws Throwable {
		List<Object[]> retorno = new ArrayList<Object[]>();
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		retorno.addAll(serviceRemote.getDadosPorBancos(0,mesAnoFormat));
		retorno.addAll(serviceRemote.getDadosPorFerramenta(0, mesAnoFormat));
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/ferramentaBancosRejeitado/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findRejeitados(@PathVariable("mesAno") String mesAno) throws Throwable {
		List<Object[]> retorno = new ArrayList<Object[]>();
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		retorno.addAll(serviceRemote.getDadosPorBancos(1,mesAnoFormat));
		retorno.addAll(serviceRemote.getDadosPorFerramenta(1, mesAnoFormat));
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/ferramentaBancosRejeitadoFalha/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findRejeitadosFalha(@PathVariable("mesAno") String mesAno) throws Throwable {
		List<Object[]> retorno = new ArrayList<Object[]>();
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		retorno.addAll(serviceRemote.getDadosPorBancos(2,mesAnoFormat));
		retorno.addAll(serviceRemote.getDadosPorFerramenta(2, mesAnoFormat));
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/solicitacao/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findSolicitacaoTotalOrSucesso(@PathVariable("mesAno") String mesAno
																	   ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(11,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/instalacao/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findInstalacaoTotalOrSucesso(@PathVariable("mesAno") String mesAno
																	  ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(12,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/notificacao/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findNotificacaoTotalOrSucesso(@PathVariable("mesAno") String mesAno
																	   ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(15,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/ativacao/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findAtivacaoTotalOrSucesso(@PathVariable("mesAno") String mesAno
																	,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(14,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/desbloqueio/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findDesbloqueioTotalOrSucesso(@PathVariable("mesAno") String mesAno
																	   ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(24,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/ted/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findTedTotalOrSucesso(@PathVariable("mesAno") String mesAno
															   ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(23,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/cadastroEc/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findCadastroEc(@PathVariable("mesAno") String mesAno
															   ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(5,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/habilitacaoProdutos/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findHabilitacaoProdutos(@PathVariable("mesAno") String mesAno
															   ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(6,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/geracaoNumeroLogico/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findGeracaoNumeroLogico(@PathVariable("mesAno") String mesAno
															   ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getGraficoTotalEtapasSucesso(9,mesAnoFormat, arrayCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/ofertasRascunhos/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findOfertasRascunhos(@PathVariable("mesAno") String mesAno) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getInfoOfertasRascunhos(mesAnoFormat);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/ofertasRejeitados/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findOfertasRejeitados(@PathVariable("mesAno") String mesAno) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getInfoOfertasRejeitados(mesAnoFormat);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}

	@RequestMapping(value = "/ofertasPropostas/{mesAno}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findOfertasPropostas(@PathVariable("mesAno") String mesAno) throws Throwable {
		String mesAnoFormat = mesAno.substring(0 , 2).concat("/")+mesAno.substring(2 , mesAno.length());
		List<Object[]> retorno = serviceRemote.getInfoOfertasPropostas(mesAnoFormat);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/tempoAtivacaoD7_D60/{ano}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findTempoAtivacaoD7_D60(@PathVariable(value = "ano") String ano
														   		 ,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta
														   		 ,@RequestParam(value = "blacklistCodigoFerramenta", required = false) Integer[] blacklistCodigoFerramenta) throws Throwable {
		LOG.debug("Entrando no método findTempoAtivacaoD7_D60");
		LOG.debug("Ano: "+ ano);
		LOG.debug("Array de ferramentas: "+ arrayCodigoFerramenta);
		LOG.debug("Blacklist de ferramentas: "+ blacklistCodigoFerramenta);
		List<Object[]> retorno = serviceRemote.getTempoAtivacaoD7_D60(ano, arrayCodigoFerramenta, blacklistCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value = "/tempoAtivacaoD0_D7/{ano}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Object[]>> findTempoAtivacaoD0_D7(@PathVariable(value = "ano") String ano
														   		,@RequestParam(value = "arrayCodigoFerramenta", required = false) Integer[] arrayCodigoFerramenta
														   		,@RequestParam(value = "blacklistCodigoFerramenta", required = false) Integer[] blacklistCodigoFerramenta) throws Throwable {
		LOG.debug("Entrando no método findTempoAtivacaoD0_D7");
		LOG.debug("Ano: "+ ano);
		LOG.debug("Array de ferramentas: "+ arrayCodigoFerramenta);
		LOG.debug("Blacklist de ferramentas: "+ blacklistCodigoFerramenta);
		List<Object[]> retorno = serviceRemote.getTempoAtivacaoD0_D7(ano, arrayCodigoFerramenta, blacklistCodigoFerramenta);
		return new ResponseEntity<List<Object[]>>(retorno, HttpStatus.ACCEPTED);
	}
	
}
