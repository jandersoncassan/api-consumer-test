/**
 * 
 */
package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.com.cielo.credenciamento.dto.FerramentaDTO;
import br.com.cielo.dashboard.dto.DashBoardAnualDTO;
import br.com.cielo.dashboard.model.Ferramenta;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IFerramentaService;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author persona
 *
 */
@Controller
public class DashBoardAnualController {
private static final Logger LOG = LogManager.getLogger(DashBoardAnualController.class);
	
	@Autowired
	private IFerramentaService ferramentaService;
	
	@RequestMapping(value="/initDashBoardAnual") 
	@Secured(SecurityRole.ROLE_CRD_DASHBOARD_VER)
	public String initDashBoardAnual(Model model) throws IOException {
		LOG.info("INIT PAGE DASHBOARD_ANUAL");
		DashBoardAnualDTO dashboardAnualDTO = new DashBoardAnualDTO();
		dashboardAnualDTO.setDataReferenciaPesquisa(String.valueOf(Calendar.getInstance().get(Calendar.YEAR))); // ano atual
		dashboardAnualDTO.setFerramentaPesquisa(new ArrayList<Integer>()); // lista vazia
		dashboardAnualDTO.setListaAnos(DashboardUtils.calcularAnoParaPesquisaDashboard());
		dashboardAnualDTO.setListaFerramentas(getFerramentas());
		model.addAttribute("dashboardAnualDTO",dashboardAnualDTO);
		return NavigationDashBoard.DASHBOARD_ANUAL;
	}
	
	/**
	 * 
	 * @param dashBoardDto
	 * @param bindingResult
	 * @param model
	 * @param session
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/realizarPesquisaDashPorAnoReferencia/{dataPesquisa}")
	@Secured(SecurityRole.ROLE_CRD_DASHBOARD_VER)
	public String realizarPesquisaDashPorAnoReferencia( @RequestParam("ferramentaPesquisa") List<Integer> ferramentaPesquisa
													  , @PathVariable("dataPesquisa") String dataReferenciaPesquisa 
													  , Model model) {
		LOG.info("LOAD DASH POR DATA REFERENCIA .. {}", dataReferenciaPesquisa);
		LOG.info("LOAD DASH POR FERRAMENTA .. {}", ferramentaPesquisa);
		
		DashBoardAnualDTO dashboardAnualDTO = new DashBoardAnualDTO();
		dashboardAnualDTO.setDataReferenciaPesquisa(dataReferenciaPesquisa);
		dashboardAnualDTO.setFerramentaPesquisa(ferramentaPesquisa);
		dashboardAnualDTO.setListaAnos(DashboardUtils.calcularAnoParaPesquisaDashboard());
		dashboardAnualDTO.setListaFerramentas(getFerramentas());
		model.addAttribute("dashboardAnualDTO",dashboardAnualDTO);
		return NavigationDashBoard.DASHBOARD_ANUAL;
	}
	
	
	private List<Ferramenta> getFerramentas() {
		List<FerramentaDTO> listaFerramentasDTO = ferramentaService.getFerramentasPorIntervaloDeCodigo(2, 89);
		List<Ferramenta> listaFerramentas = new ArrayList<Ferramenta>();
		
		for (FerramentaDTO ferramentaDTO : listaFerramentasDTO) {
			
			Ferramenta ferramenta = new Ferramenta();
			ferramenta.setCodigo(ferramentaDTO.getCodigo());
			ferramenta.setDescricao(ferramentaDTO.getDescricao());
			listaFerramentas.add(ferramenta);
		}
		
		return listaFerramentas;
	}
}
