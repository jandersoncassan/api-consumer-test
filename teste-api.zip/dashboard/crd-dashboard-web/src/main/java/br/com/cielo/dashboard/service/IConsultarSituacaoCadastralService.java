package br.com.cielo.dashboard.service;

import java.util.List;

import br.com.cielo.credenciamento.dto.SituacaoCadastralDTO;

public interface IConsultarSituacaoCadastralService {
	public List<SituacaoCadastralDTO> listarSituacaoCadastral();
}
