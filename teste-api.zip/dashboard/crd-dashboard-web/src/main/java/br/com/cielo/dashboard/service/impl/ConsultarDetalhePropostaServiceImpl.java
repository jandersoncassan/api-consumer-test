/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarDetalhePropostaServiceRemote;
import br.com.cielo.dashboard.service.IConsultarDetalhePropostaService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarDetalhePropostaServiceImpl implements IConsultarDetalhePropostaService{

	@Resource(mappedName = "ConsultarDetalhePropostaService#br.com.cielo.credenciamento.service.dashboard.ConsultarDetalhePropostaServiceRemote")	
	private ConsultarDetalhePropostaServiceRemote consultarDetalhePropostaRemote;
	/**
	 * @param numeroProposta
	 * @return
	 */
	public Object[] getDetalheProposta(Long numeroProposta) {
		return consultarDetalhePropostaRemote.getDetalheProposta(numeroProposta);
	}
}
