package br.com.cielo.dashboard.dto;

public class ItemGradeConfirmacaoSolucaoCapturaPermitidaDTO {
	private String descricaoFerramenta;
	private String descricaoSolucaoCaptura;
	private String descricaoTipoPlano;
	private String indicadorMei;
	private String tipoPessoa;
	private String tipoManutencao;
	
	
	public String getDescricaoFerramenta() {
		return descricaoFerramenta;
	}
	public void setDescricaoFerramenta(String descricaoFerramenta) {
		this.descricaoFerramenta = descricaoFerramenta;
	}
	public String getDescricaoSolucaoCaptura() {
		return descricaoSolucaoCaptura;
	}
	public void setDescricaoSolucaoCaptura(String descricaoSolucaoCaptura) {
		this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
	}
	public String getDescricaoTipoPlano() {
		return descricaoTipoPlano;
	}
	public void setDescricaoTipoPlano(String descricaoTipoPlano) {
		this.descricaoTipoPlano = descricaoTipoPlano;
	}
	public String getTipoManutencao() {
		return tipoManutencao;
	}
	public void setTipoManutencao(String tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}
	public String getIndicadorMei() {
		return indicadorMei;
	}
	public void setIndicadorMei(String indicadorMei) {
		this.indicadorMei = indicadorMei;
	}
	public String getTipoPessoa() {
		return tipoPessoa;
	}
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}
}
