/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarRemessasProcessadasServiceRemote;
import br.com.cielo.dashboard.service.IConsultarRemessasProcessadasService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarRemessasProcessadasServiceImpl implements IConsultarRemessasProcessadasService{

	@Resource(mappedName = "ConsultarRemessasProcessadasService#br.com.cielo.credenciamento.service.dashboard.ConsultarRemessasProcessadasServiceRemote")
	private ConsultarRemessasProcessadasServiceRemote consultarRemessasProcessadasRemote;
	
	/**
	 * Método:Consultar Remessas Processadas
	 * @param codigoBanco
	 * @param periodoInicial
	 * @param periodoFinal
	 * @return Object
	 */
	public List<Object> getConsultarRemessasProcessadas(Integer codigoBanco, Integer codigoStatus, String periodoInicial,
			String periodoFinal) {
		return consultarRemessasProcessadasRemote.getListaRemessasProcessadas(codigoBanco, codigoStatus, periodoInicial, periodoFinal);
	}

	@Override
	public List<Object> getConsultarRejeitado(Integer codigoBanco, String periodoInicial, String periodoFinal) {
		return consultarRemessasProcessadasRemote.getConsultarRejeitado(codigoBanco, periodoInicial, periodoFinal);
	}
}
