/**
 * 
 */
package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import br.com.cielo.credenciamento.dto.FerramentaDTO;
import br.com.cielo.dashboard.dto.DashBoardEtapasDTO;
import br.com.cielo.dashboard.model.Ferramenta;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IFerramentaService;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author persona
 *
 */
@Controller
public class DashBoardEtapaController {

	private static final Logger LOG = LogManager.getLogger(DashBoardEtapaController.class);
	
	@Autowired
	private IFerramentaService ferramentaService;
	
	@RequestMapping(value="/initDashBoardEtapas") 
	@Secured(SecurityRole.ROLE_CRD_DASHBOARD_VER)
	public String initDashBoardEtapas(Model model) throws IOException {
		LOG.info("INIT PAGE DASHBOARD_ETAPAS");
		String dataReferenciaPesquisa = new SimpleDateFormat(DashboardUtils.PATTERN_MM_YYYY).format(new Date());
		DashBoardEtapasDTO dashboardEtapasDTO = new DashBoardEtapasDTO();
		dashboardEtapasDTO.setDataReferenciaPesquisa(dataReferenciaPesquisa); 
		dashboardEtapasDTO.setFerramentaPesquisa(new ArrayList<Integer>());
		dashboardEtapasDTO.setListaMeses(DashboardUtils.calcularMesAnoParaPesquisaDashboard());
		dashboardEtapasDTO.setListaFerramentas(getFerramentas());
		model.addAttribute("dashboardEtapasDTO",dashboardEtapasDTO);
		return NavigationDashBoard.DASHBOARD_ETAPAS;
	}

	/**
	 * 
	 * @param dashBoardDto
	 * @param bindingResult
	 * @param model
	 * @param session
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/realizarPesquisaDashPorEtapas/{dataPesquisa}")
	@Secured(SecurityRole.ROLE_CRD_DASHBOARD_VER)
	public String realizarPesquisaDashPorAnoReferencia( @RequestParam("ferramentaPesquisa") List<Integer> ferramentaPesquisa
													  , @PathVariable("dataPesquisa") String dataReferenciaPesquisa 
													  , Model model) {
		LOG.info("LOAD DASH POR DATA REFERENCIA .. {}", dataReferenciaPesquisa);
		LOG.info("LOAD DASH POR FERRAMENTA .. {}", ferramentaPesquisa);
		
		DashBoardEtapasDTO dashboardEtapasDTO = new DashBoardEtapasDTO();
		dashboardEtapasDTO.setDataReferenciaPesquisa(tratarDataPesquisa(dataReferenciaPesquisa));
		dashboardEtapasDTO.setFerramentaPesquisa(ferramentaPesquisa);
		dashboardEtapasDTO.setListaMeses(DashboardUtils.calcularMesAnoParaPesquisaDashboard());
		dashboardEtapasDTO.setListaFerramentas(getFerramentas());
		model.addAttribute("dashboardEtapasDTO",dashboardEtapasDTO);
		return NavigationDashBoard.DASHBOARD_ETAPAS;
	}
	
	
	private List<Ferramenta> getFerramentas() {
		List<FerramentaDTO> listaFerramentasDTO = ferramentaService.getFerramentasPorIntervaloDeCodigo(2, 89);
		List<Ferramenta> listaFerramentas = new ArrayList<Ferramenta>();
		
		for (FerramentaDTO ferramentaDTO : listaFerramentasDTO) {
			
			Ferramenta ferramenta = new Ferramenta();
			ferramenta.setCodigo(ferramentaDTO.getCodigo());
			ferramenta.setDescricao(ferramentaDTO.getDescricao());
			listaFerramentas.add(ferramenta);
		}
		
		return listaFerramentas;
	}

	/**
	 * Método responsavel por formatar a data no padrão de pesquisa mm/yyyy
	 * 
	 * @param dataPesquisa
	 * @return
	 */
	private String tratarDataPesquisa(String dataPesquisa) {
		dataPesquisa = dataPesquisa.substring(0,2).concat("/").concat(dataPesquisa.substring(2));
		return dataPesquisa;
	}
	
}
