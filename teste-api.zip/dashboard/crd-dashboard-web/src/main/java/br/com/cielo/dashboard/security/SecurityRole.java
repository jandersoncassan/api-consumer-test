package br.com.cielo.dashboard.security;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

import br.com.cielo.credenciamento.enums.BancosEnum;
import br.com.cielo.credenciamento.enums.FerramentaEnum;
import br.com.cielo.credenciamento.enums.TipoPerfilUsuarioSmart;

public class SecurityRole {
	
	private static final Logger LOG = LogManager.getLogger(SecurityRole.class);
	
	public static final String ROLE_CRD_DASHBOARD_VER = "ROLE_CRD_DASHBOARD_VER";
	public static final String ROLE_CRD_DASHBOARD_EXPORTAR = "ROLE_CRD_DASHBOARD_EXPORTAR";
    public static final String ROLE_CRD_DASHBOARD_TV = "ROLE_CRD_DASHBOARD_TV_VER";
	public static final String ROLE_CRD_CONSULTA_PROPOSTA_LISTA = "ROLE_CRD_CONSULTA_PROPOSTA_LISTA";
	public static final String ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR = "ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR";
	public static final String ROLE_CRD_CONSULTA_REMESSA_LISTA = "ROLE_CRD_CONSULTA_REMESSA_LISTA";
	public static final String ROLE_CRD_CONSULTA_REMESSA_EXPORTAR = "ROLE_CRD_CONSULTA_REMESSA_EXPORTAR";
	public static final String ROLE_CRD_CONSULTA_PROPOSTA_USUARIO_UNICO="ROLE_CRD_CONSULTA_PROPOSTA_USUARIO_UNICO";
	public static final String ROLE_CRD_SIMULADOR = "ROLE_CRD_SIMULADOR";
	public static final String ROLE_CRD_CREDENCIAMENTO_CENTRAL = "ROLE_CRD_CREDENCIAMENTO_CENTRAL";
	public static final String ROLE_CRD_CREDENCIAMENTO_FEIRA = "ROLE_CRD_CREDENCIAMENTO_FEIRA";
	public static final String ROLE_CRD_CREDENCIAMENTO_SMART = "ROLE_CRD_CREDENCIAMENTO_SMART";
	public static final String ROLE_CRD_CONSULTA_OFERTAS = "ROLE_CRD_CONSULTA_OFERTAS";
	public static final String ROLE_CRD_BANCO_TODOS = "ROLE_CRD_BANCO_TODOS";
	public static final String ROLE_CRD_BANCO_001 = "ROLE_CRD_BANCO_001";
	public static final String ROLE_CRD_BANCO_104 = "ROLE_CRD_BANCO_104";
	public static final String ROLE_CRD_BANCO_237 = "ROLE_CRD_BANCO_237";
	public static final String ROLE_CRD_FERRAMENTA_TODAS = "ROLE_CRD_FERRAMENTA_TODAS";
	public static final String ROLE_CRD_FERRAMENTA_BANCO = "ROLE_CRD_FERRAMENTA_BANCO";
	public static final String ROLE_CRD_FERRAMENTA_SITE = "ROLE_CRD_FERRAMENTA_SITE";
	public static final String ROLE_CRD_FERRAMENTA_CENTRAL = "ROLE_CRD_FERRAMENTA_CENTRAL";
	public static final String ROLE_CRD_FERRAMENTA_VENDING_MACHIME = "ROLE_CRD_FERRAMENTA_VENDING_MACHIME";
	public static final String ROLE_CRD_FERRAMENTA_DESENV_LIO = "ROLE_CRD_FERRAMENTA_DESENV_LIO";
	public static final String ROLE_CRD_FERRAMENTA_SMART="ROLE_CRD_FERRAMENTA_SMART";
	public static final String ROLE_CRD_FERRAMENTA_FEIRAS="ROLE_CRD_FERRAMENTA_FEIRAS";
	public static final String ROLE_CRD_TIPO_USUARIO_ISO="ROLE_CRD_TIPO_USUARIO_ISO";
	public static final String ROLE_CRD_TIPO_USUARIO_DDN="ROLE_CRD_TIPO_USUARIO_DDN";
	public static final String ROLE_CRD_TIPO_USUARIO_COMERCIAL="ROLE_CRD_TIPO_USUARIO_COMERCIAL";	
	public static final String ROLE_CRD_PARAMETRIZACAO_CONSULTAR = "ROLE_CRD_PARAMETRIZACAO_CONSULTAR";
	public static final String ROLE_CRD_PARAMETRIZACAO_ATUALIZAR = "ROLE_CRD_PARAMETRIZACAO_ATUALIZAR";
	public static final String ROLE_CRD_PARAMETRIZACAO_EXPORTAR = "ROLE_CRD_PARAMETRIZACAO_EXPORTAR";
	
	/**
	 * 
	 * @param authentication
	 * @return
	 */
	public static List<String> getRoles(Authentication authentication) {
		
		List<String> authorities = new ArrayList<>();
		
		for (GrantedAuthority grantedAuthority : authentication.getAuthorities()) {
			authorities.add(grantedAuthority.getAuthority());
		}
		
		LOG.debug("Lista de authorities: " + authorities);
		
	    return authorities;
	}
	
	/**
	 * 
	 * @param authentication
	 * @param searchValue
	 * @return
	 */
	public static boolean findRole (Authentication authentication, String searchValue) {
		
		List<String> authorities = SecurityRole.getRoles (authentication);
		
         for (String authority : authorities) {
             if(authority.contains(searchValue)) {
                 return true;
             }
         }
         
         return false;
	}
	
	
	public static List<Integer> converteListaRolesBancoParaListaCodigoBanco (Authentication authentication) {
		
		LOG.debug("Iniciando converteListaRolesBancoParaListaCodigoBanco");
		
		List<String> authorities = SecurityRole.getRoles (authentication);
		List<Integer> listaCodigoBanco  = new ArrayList<Integer>();
		
		/**
		 * Traduz a lista de authorities em uma lista de códigos de bancos e ferramentas.
		 */
		for (String authority : authorities) {
			switch(authority) {
				case SecurityRole.ROLE_CRD_BANCO_TODOS:
					listaCodigoBanco.add(0);
					break;
				case SecurityRole.ROLE_CRD_BANCO_001:
					listaCodigoBanco.add(BancosEnum.BB.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_BANCO_104:
					listaCodigoBanco.add(BancosEnum.CEF.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_BANCO_237:
					listaCodigoBanco.add(BancosEnum.BRADESCO.getCodigo());
					break;
			}
		}
		
		LOG.debug("listaCodigoBanco = " + listaCodigoBanco);
		
		return listaCodigoBanco;
	}
	
	public static List<Integer> converteListaRolesFerramentaParaListaCodigoFerramenta (Authentication authentication) {
		
		LOG.debug("Iniciando converteListaRolesFerramentaParaListaCodigoFerramenta");
		
		List<String> authorities = SecurityRole.getRoles (authentication);
		List<Integer> listaCodigoFerramenta  = new ArrayList<Integer>();
		
		/**
		 * Traduz a lista de authorities em uma lista de códigos de bancos e ferramentas.
		 */
		for (String authority : authorities) {
			switch(authority) {
				case SecurityRole.ROLE_CRD_FERRAMENTA_TODAS:
					listaCodigoFerramenta.add(0);
					break;
				case SecurityRole.ROLE_CRD_FERRAMENTA_BANCO:
					listaCodigoFerramenta.add(FerramentaEnum.BANCOS.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_FERRAMENTA_CENTRAL:
					listaCodigoFerramenta.add(FerramentaEnum.CENTRAL.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_FERRAMENTA_DESENV_LIO:
					listaCodigoFerramenta.add(FerramentaEnum.DESENVOLVEDORES_LIO.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_FERRAMENTA_SITE:
					listaCodigoFerramenta.add(FerramentaEnum.SITE_CIELO.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_FERRAMENTA_VENDING_MACHIME:
					listaCodigoFerramenta.add(FerramentaEnum.VENDING_MACHINE.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_FERRAMENTA_FEIRAS:
					listaCodigoFerramenta.add(FerramentaEnum.FEIRAS.getCodigo());
					break;
				case SecurityRole.ROLE_CRD_FERRAMENTA_SMART:
					listaCodigoFerramenta.add(FerramentaEnum.SMART.getCodigo());
					break;

			}
		}
		
		LOG.debug("listaCodigoFerramenta = " + listaCodigoFerramenta);
		
		return listaCodigoFerramenta;
	}

	/**
	 * Método responsavel por deveolver o dominio do perfil usuario smart
	 * @param authentication
	 * @return
	 */
	public static Integer getDominioPerfilUsuarioSmart(Authentication authentication){
		String rolePerfil = getRolePerfilSmart(authentication);
		return TipoPerfilUsuarioSmart.getCodigoPerfil(rolePerfil);
	}
	
	/**
	 * Método responsavel por obter o tipo de perfil para usuarios smart
	 * @param authentication
	 */
	private static String getRolePerfilSmart(Authentication authentication) {
		
		List<String> roles = SecurityRole.getRoles (authentication);
		
		for (String role : roles) {
			Optional<String> rolePerfil = getRoleSmart(role);
			if(rolePerfil.isPresent())
				return rolePerfil.get();			
		}	
		return TipoPerfilUsuarioSmart.INVALIDO.name();
	}
	
	/**
	 * Roles cadastradas no LDAP
	 * @param role
	 * @return
	 */
	private static Optional<String> getRoleSmart(String role){
		List<String> rolesPerfilSmart = Arrays.asList(ROLE_CRD_TIPO_USUARIO_ISO, ROLE_CRD_TIPO_USUARIO_DDN, ROLE_CRD_TIPO_USUARIO_COMERCIAL);
		return rolesPerfilSmart.stream().filter(rl -> role.equals(rl)).findFirst();
	}
}
