package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.cielo.credenciamento.dto.FerramentaDTO;
import br.com.cielo.dashboard.dto.DashBoardAnualDTO;
import br.com.cielo.dashboard.dto.DashBoardMensalDTO;
import br.com.cielo.dashboard.model.Ferramenta;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.ICardsService;
import br.com.cielo.dashboard.service.IFerramentaService;
import br.com.cielo.dashboard.utils.DashboardUtils;

@Controller
public class DashBoardTelevisaoController {
    private static final Logger LOG = LogManager.getLogger(DashBoardTelevisaoController.class);

    @Autowired
    private IFerramentaService ferramentaService;

    @Autowired
    private ICardsService cardsService;

    @RequestMapping(value = "/initDashBoardTv")
    @Secured(SecurityRole.ROLE_CRD_DASHBOARD_TV)
    public String initDashBoardTv(Model model) throws IOException {
        LOG.info("INIT PAGE DASHBOARD_TV");
        try {
            DashBoardAnualDTO dashboardAnualDTO = new DashBoardAnualDTO();
            dashboardAnualDTO.setDataReferenciaPesquisa(String.valueOf(Calendar.getInstance().get(Calendar.YEAR))); // ano
                                                                                                                    // atual
            dashboardAnualDTO.setFerramentaPesquisa(new ArrayList<Integer>()); // lista vazia
            dashboardAnualDTO.setListaAnos(DashboardUtils.calcularAnoParaPesquisaDashboard());
            dashboardAnualDTO.setListaFerramentas(getFerramentas());
            model.addAttribute("dashboardAnualDTO", dashboardAnualDTO);

            String dataReferenciaPesquisa = new SimpleDateFormat(DashboardUtils.PATTERN_MM_YYYY).format(new Date());
            DashBoardMensalDTO dashboardMensalDTO = new DashBoardMensalDTO();
            dashboardMensalDTO.setDataReferenciaPesquisa(dataReferenciaPesquisa);
            dashboardMensalDTO.setListaMeses(DashboardUtils.calcularMesAnoParaPesquisaDashboard());
            // OBTER CARDS
            dashboardMensalDTO = obterCards(dashboardMensalDTO);
            model.addAttribute("dashboardMensalDTO", dashboardMensalDTO);
        } catch (Exception ex) {
            LOG.error("ERROR PAGE DASHBOARD_TV ", ex);
        }
        return NavigationDashBoard.DASHBOARD_TV;
    }

    private List<Ferramenta> getFerramentas() {
        List<FerramentaDTO> listaFerramentasDTO = ferramentaService.getFerramentasPorIntervaloDeCodigo(2, 89);
        List<Ferramenta> listaFerramentas = new ArrayList<Ferramenta>();

        for (FerramentaDTO ferramentaDTO : listaFerramentasDTO) {

            Ferramenta ferramenta = new Ferramenta();
            ferramenta.setCodigo(ferramentaDTO.getCodigo());
            ferramenta.setDescricao(ferramentaDTO.getDescricao());
            listaFerramentas.add(ferramenta);
        }

        return listaFerramentas;
    }

    public DashBoardMensalDTO obterCards(DashBoardMensalDTO dashBoardMensalDTO) {
        List<Object> retorno = cardsService.getCardsPrincipal(dashBoardMensalDTO.getDataReferenciaPesquisa());
        if (DashboardUtils.isNotNullOrEmpty(retorno)) {
            dashBoardMensalDTO
                    .setCredenciamento(DashboardUtils.formatNumber(DashboardUtils.isNotNullOrEmpty(retorno.get(0))
                            ? retorno.get(0).toString()
                            : DashboardUtils.SRING_ZERO));
            dashBoardMensalDTO.setInstalacao(DashboardUtils.formatNumber(DashboardUtils.isNotNullOrEmpty(retorno.get(0))
                    ? retorno.get(1).toString()
                    : DashboardUtils.SRING_ZERO));
            dashBoardMensalDTO.setAtivacao(DashboardUtils.formatNumber(DashboardUtils.isNotNullOrEmpty(retorno.get(0))
                    ? retorno.get(2).toString()
                    : DashboardUtils.SRING_ZERO));
        }

        return dashBoardMensalDTO;
    }
}
