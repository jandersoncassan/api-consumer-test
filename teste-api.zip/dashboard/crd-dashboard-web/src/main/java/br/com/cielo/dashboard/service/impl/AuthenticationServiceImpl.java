package br.com.cielo.dashboard.service.impl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import br.com.cielo.dashboard.dto.InfoUsuarioLdapDTO;
import br.com.cielo.dashboard.model.Usuario;
import br.com.cielo.dashboard.service.AuthenticationService;
import br.com.cielo.dashboard.service.LdapService;

/**
 * Classe de implementação do serviço do LDAP
 * @author @Cielo
 * @since 1.0.0
 */
@Service
public class AuthenticationServiceImpl implements AuthenticationService{

	private static final Logger LOG = LogManager.getLogger(AuthenticationServiceImpl.class);
	
	@Autowired
	private LdapService ldapService;
	
	@Override
	public InfoUsuarioLdapDTO autenticarAutorizar(Usuario usuario) {
		LOG.info("SERVICE IMPLEMENTACAO LDAP");
		try{			
			return(ldapService.autenticarUsuario(usuario));
		}catch(Exception ex){
			LOG.info("PROBLEMAS NA AUTENTICACAO");
			throw ex;
		}
	}

	@Override
	public UsernamePasswordAuthenticationToken createToken(Usuario usuario) {
		UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(
				usuario.getLogin(), 
				usuario.getSenha(),	
				usuario.getListaAuthorities());
		
		return token;
	}
	
}
