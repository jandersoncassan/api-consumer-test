package br.com.cielo.dashboard.service;

import br.com.cielo.credenciamento.dto.DominioRetornoInstalacaoDTO;

public interface IConsultarMotivoInstalacaoService {
    DominioRetornoInstalacaoDTO getDominioById(Integer id);
}
