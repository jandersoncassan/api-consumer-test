package br.com.cielo.dashboard.service.impl;

import static org.springframework.ldap.query.LdapQueryBuilder.query;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.AuthenticationException;
import org.springframework.ldap.OperationNotSupportedException;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.AbstractContextMapper;
import org.springframework.ldap.core.support.DefaultDirObjectFactory;
import org.springframework.ldap.core.support.LdapContextSource;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.stereotype.Service;

import br.com.cielo.dashboard.dto.InfoUsuarioLdapDTO;
import br.com.cielo.dashboard.model.Usuario;
import br.com.cielo.dashboard.service.LdapService;
import br.com.cielo.dashboard.utils.DashboardFile;

/**
 * Classe responsavel pela implementação do serviço de autenticação / autorização LDAP
 * @author @Cielo
 * @since 1.0.0
 */
@Service
public class LdapServiceImpl implements LdapService{

	private static final Logger LOG = LogManager.getLogger(LdapServiceImpl.class);
	
    private LdapTemplate ldapTemplate;
    
    private static final String LDAP_URL="ldap.context.url";
    private static final String LDAP_USER_DN="ldap.context.username";
    private static final String LDAP_PASSWORD="ldap.context.password";
    private static final String LDAP_BASE="ldap.context.base";
    private static final String LDAP_USER_GROUP="ldap.grupoUsuario";
    
    @Autowired
    private DashboardFile dashboardFile;
    
    /**
     * Configura o LDAP template
     */
    public void configLdapTemplate(){
    	LdapContextSource ldapContext = new LdapContextSource();
    	ldapContext.setUrl(getMessage(LDAP_URL));
    	ldapContext.setUserDn(getMessage(LDAP_USER_DN));
    	ldapContext.setPassword(getMessage(LDAP_PASSWORD));
    	ldapContext.setBase(getMessage(LDAP_BASE));
    	ldapContext.setDirObjectFactory(DefaultDirObjectFactory.class);
    	ldapContext.afterPropertiesSet();
    	
        ldapTemplate = new LdapTemplate(ldapContext);
    }
    
	@Override
	public InfoUsuarioLdapDTO autenticarUsuario(Usuario usuario) {
		LOG.info("INIT AUTENTICACAO / AUTORIZACAO ....");
		
		try{
			configLdapTemplate();
			
			List<InfoUsuarioLdapDTO> listInfoUsuario = this.ldapTemplate.search( query().where("cn").is(usuario.getLogin())
																			    , new MapeamentoUsuarioDTO());
			
			if(null == listInfoUsuario || listInfoUsuario.isEmpty()){
				 LOG.info("USUARIO INVALIDO ! ... ".concat(usuario.getLogin()));
				 throw new BadCredentialsException("Usuário inválido");
			}

			InfoUsuarioLdapDTO infoUsuario = autorizarUsuario(listInfoUsuario);
			autenticar(infoUsuario.getDn(), usuario.getSenha());
			
			LOG.info("AUTENTICACAO / AUTORIZACAO SUCESSO!");
			return infoUsuario;
			
		}catch(Exception ex){
			if(ex instanceof BadCredentialsException){
				throw ex;
			}
			LOG.error("PROBLEMAS NA COMUNICACAO COM LDAP ", ex);
			throw new AuthenticationServiceException("Problemas na comunicacao com LDAP.");
		}
	}
	
	
	/**
	 * Método responsavel por obter as informações e grupos do usuário
	 * @param listaInfoLdap
	 * @return
	 */
	private InfoUsuarioLdapDTO autorizarUsuario(List<InfoUsuarioLdapDTO> listaInfoLdap) {
		
		LOG.info("INIT VALIDAR GRUPO USUARIO E LOGIN HABILITADO ....");
		InfoUsuarioLdapDTO infoUsuario = obterInfoUsuarioLogin(listaInfoLdap);
		if(null == infoUsuario){
			throw new BadCredentialsException("Acesso negado");
		}
		return infoUsuario;
	}

	/**
	 * Obtém uma instância do DirContext autenticada usando o principal e as credenciais fornecidas.
	 * Normalmente para ser usado para fins de autenticação simples. 
	 * Tenha em atenção que este método nunca utilizará o agrupamento Java LDAP nativo, mesmo que esta instância esteja configurada para fazê-lo. 
	 * Isso é para forçar mudanças de senha no diretório de destino para entrar em vigor o mais rápido possível.
	 */
	private void autenticar(String principal, String credencial){        
		try {
			configLdapTemplate();
			
            ldapTemplate.getContextSource().getContext(principal, credencial);

		} catch (AuthenticationException ex) {
        	 LOG.info("SENHA INVALIDA !", ex);
        	 throw new BadCredentialsException("Senha inválida!");
        	 
        } catch (OperationNotSupportedException ex) {
        	LOG.info("USUARIO BLOQUEADO NO LDAP!", ex);
        	throw new BadCredentialsException("Acesso negado");
        }
     }
	
	/**
	 * Classe utilitária para mapeamento das informações do LDAP
	 * @author @Cielo
	 * @sice 1.0.0
	 */
	private static class MapeamentoUsuarioDTO extends AbstractContextMapper<InfoUsuarioLdapDTO> {
    	/**
    	 * Método responsavel pelo MAP das informações através do context
    	 */
        @Override
        public InfoUsuarioLdapDTO doMapFromContext(final DirContextOperations context) {
        	
          LOG.debug("Todos os atributos do usuário: "+context.getAttributes().toString());
          
            final InfoUsuarioLdapDTO usuario = new InfoUsuarioLdapDTO();
            usuario.setDn(context.getNameInNamespace());
            usuario.setLoginDisabled(context.getStringAttribute("loginDisabled"));
            usuario.setEmployeeStatus(context.getStringAttribute("employeeStatus"));
            usuario.setUserName(context.getStringAttribute("fullName"));
            usuario.setGrupos(context.getStringAttributes("groupMembership"));
            usuario.setDirXMLEntitlementRef(context.getStringAttributes("DirXML-EntitlementRef"));
            LOG.debug("usuario.getDirXMLEntitlementRef(): "+usuario.getDirXMLEntitlementRef());
            
            for (int i=0; i < usuario.getDirXMLEntitlementRef().length; i++) {
            	String role = usuario.getDirXMLEntitlementRef()[i];
            	
				if ((role != null) 
					&& (role.contains("#1#")) 
					&& (role.contains("CRD_"))  
					&& (role.contains("<param>"))
					&& (role.contains("</param>"))) {
					
					LOG.debug("role antes do substring: "+ role);
					//Parse da string para capturar o conteúdo entre o <param></param>
					role = role.substring( role.indexOf("<param>") + 7, role.indexOf("</param>")).trim();
					if (role.startsWith("CRD")) {
						LOG.debug("role depois do substring: "+ role);
						//Inclusão do prefixo "ROLE_" para que o spring-security entenda que trata-se de uma ROLE
						role = "ROLE_" + role;
						//Inclusão da role na lista de Authorities do usuário
						usuario.addRole(role);
					}
				}
			}
            
            return usuario;
        }
    }
    
	/**
	 * Método responsavel por verificar se o usuário pertence ao grupo e não está desabilitado
	 * @param result
	 * @return Boolean
	 */
	private InfoUsuarioLdapDTO obterInfoUsuarioLogin(List<InfoUsuarioLdapDTO> listaInfoLdap){
		for (InfoUsuarioLdapDTO infoUsuario : listaInfoLdap) {
			for(String grupo : infoUsuario.getGrupos()){
				if((null!=grupo && grupo.equals(getMessage(LDAP_USER_GROUP)))
						&& (infoUsuario.getEmployeeStatus().equals("Ativo"))){
					return infoUsuario;
				}
			}
		}
		return null;
	}
	
	/**
	 * Método responsavel por obter o valor da key de propriedade
	 * @param key
	 * @return String
	 */
	private String getMessage(String key){
		return (dashboardFile.getMessageExternal(key));
	}
}