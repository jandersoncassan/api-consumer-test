package br.com.cielo.dashboard.service;

import java.util.List;

import br.com.cielo.credenciamento.dto.MccDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccManutencaoRequestDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccDTO;


public interface IParametrizacaoMCCService {

    boolean verificarMccValido(Integer codigoMcc, String tipoPessoa, Integer codigoFerramenta);
    List<ParametrizacaoMccDTO> filtrarParametrizacao(List<Integer> codigosMcc, List<String> tiposPessoa, List<Integer> codigosFerramenta);
    void atualizarParametrizacao(ParametrizacaoMccManutencaoRequestDTO request);
    List<MccDTO> getListaDominiosMcc();
}
