/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

import br.com.cielo.credenciamento.dto.FerramentaDTO;

/**
 * @author persona
 *
 */
public interface IFerramentaService {
	
	/**
	 * 
	 * @param menor
	 * @param maior
	 * @return
	 */
	public List<FerramentaDTO> getFerramentasPorIntervaloDeCodigo(final int menor, final int maior);
}
