package br.com.cielo.dashboard.dto;


import java.util.ArrayList;
import java.util.List;
import br.com.cielo.dashboard.dto.ItemParametrizacaoMccDTO;

public class ParametrizacaoMccAuxiliarDTO {

	private List<ItemParametrizacaoMccDTO> listaItensParametrizacaoMcc;
	private List<String> itensMccsPJAtivosFerramenta;
	private List<String> itensMccsPFAtivosFerramenta;
	private List<String> itensMccsPJAtivosFerramentaOriginal;
	private List<String> itensMccsPFAtivosFerramentaOriginal;
	
	public List<ItemParametrizacaoMccDTO> getListaItensParametrizacaoMcc() {
		return listaItensParametrizacaoMcc;
	}
	public void setListaItensParametrizacaoMcc(List<ItemParametrizacaoMccDTO> listaItensParametrizacaoMcc) {
		this.listaItensParametrizacaoMcc = listaItensParametrizacaoMcc;
	}
	public List<String> getItensMccsPJAtivosFerramenta() {
		if (itensMccsPJAtivosFerramenta == null){
			itensMccsPJAtivosFerramenta = new ArrayList<String>();
		}		
		return itensMccsPJAtivosFerramenta;
	}
	public void setItensMccsPJAtivosFerramenta(List<String> itensMccsPJAtivosFerramenta) {
		this.itensMccsPJAtivosFerramenta = itensMccsPJAtivosFerramenta;
	}
	public List<String> getItensMccsPFAtivosFerramenta() {
		if (itensMccsPFAtivosFerramenta == null){
			itensMccsPFAtivosFerramenta = new ArrayList<String>();
		}				
		return itensMccsPFAtivosFerramenta;
	}
	public void setItensMccsPFAtivosFerramenta(List<String> itensMccsPFAtivosFerramenta) {
		this.itensMccsPFAtivosFerramenta = itensMccsPFAtivosFerramenta;
	}
	public List<String> getItensMccsPJAtivosFerramentaOriginal() {
		if (itensMccsPJAtivosFerramentaOriginal == null){
			itensMccsPJAtivosFerramentaOriginal = new ArrayList<String>();
		}
		return itensMccsPJAtivosFerramentaOriginal;
	}

	public void setItensMccsPJAtivosFerramentaOriginal(List<String> itensMccsPJAtivosFerramentaOriginal) {
		this.itensMccsPJAtivosFerramentaOriginal = itensMccsPJAtivosFerramentaOriginal;
	}

	public List<String> getItensMccsPFAtivosFerramentaOriginal() {
		if (itensMccsPFAtivosFerramentaOriginal == null){
			itensMccsPFAtivosFerramentaOriginal = new ArrayList<String>();
		}						
		return itensMccsPFAtivosFerramentaOriginal;
	}

	public void setItensMccsPFAtivosFerramentaOriginal(List<String> itensMccsPFAtivosFerramentaOriginal) {
		this.itensMccsPFAtivosFerramentaOriginal = itensMccsPFAtivosFerramentaOriginal;
	}

	
}
