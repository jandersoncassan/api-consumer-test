package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.ParametrizacaoBoasVindasDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoBoasVindasManutencaoRequestDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoRestricaoBoasVindasDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoRestricaoBoasVindasManutencaoRequestDTO;
import br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoBoasVindasServiceRemote;
import br.com.cielo.dashboard.service.IParametrizacaoBoasVindasService;

@Service
public class ParametrizacaoBoasVindasServiceImpl implements IParametrizacaoBoasVindasService {

	@Resource(mappedName="ParametrizacaoBoasVindasService#br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoBoasVindasServiceRemote")
	private ParametrizacaoBoasVindasServiceRemote parametrizacaoBoasVindasService;
	
	@Override
	public List<ParametrizacaoBoasVindasDTO> obterParametrizacoesVigentes() {
		// 
		return parametrizacaoBoasVindasService.obterParametrizacoesVigentes();
	}

	@Override
	public void atualizarParametrizacoes(ParametrizacaoBoasVindasManutencaoRequestDTO parametrizacoes) {

		parametrizacaoBoasVindasService.atualizarParametrizacoes(parametrizacoes);
		
	}

	@Override
	public List<ParametrizacaoRestricaoBoasVindasDTO> obterRestricoesVigentes(List<String> codigosBanco,
			List<Integer> codigosMcc, List<Integer> codigosSolucaoCaptura) {
		return parametrizacaoBoasVindasService.obterRestricoesVigentes(codigosBanco, codigosMcc, codigosSolucaoCaptura);
		
	}

	@Override
	public void atualizarRestricoes(ParametrizacaoRestricaoBoasVindasManutencaoRequestDTO restricoes) {
		
		parametrizacaoBoasVindasService.atualizarRestricoes(restricoes);
		
	}

}
