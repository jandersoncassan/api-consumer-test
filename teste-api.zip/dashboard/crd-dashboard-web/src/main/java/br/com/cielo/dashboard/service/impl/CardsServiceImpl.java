/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.CardsServiceRemote;
import br.com.cielo.dashboard.service.ICardsService;

/**
 * @author dcarneiro
 *
 */
@Service
public class CardsServiceImpl implements ICardsService {

	@Resource(mappedName = "CardsService#br.com.cielo.credenciamento.service.dashboard.CardsServiceRemote")
	private CardsServiceRemote cardsServiceRemote;

	@Override
	public List<Object> getCardsPrincipal(final String dataParaPesquisa) {
		return cardsServiceRemote.getCardsPrincipal(dataParaPesquisa);
	}
}
