package br.com.cielo.dashboard.dto;

import java.util.List;

import br.com.cielo.credenciamento.dto.ParametrizacaoSolucaoCapturaPermitidaDTO;

public class SolucaoCapturaAuxiliar {

	private List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaTratada;
	private List<String> convencional;
	private List<String> controle;
	private List<String> aluguelZero;
	private List<String> mei;
	private List<String> pf;
	private List<String> pj;
	private List<String> entregaMaquina;
	/**
	 * @return the listaTratada
	 */
	public List<ParametrizacaoSolucaoCapturaPermitidaDTO> getListaTratada() {
		return listaTratada;
	}
	/**
	 * @param listaTratada the listaTratada to set
	 */
	public void setListaTratada(List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaTratada) {
		this.listaTratada = listaTratada;
	}
	/**
	 * @return the convencional
	 */
	public List<String> getConvencional() {
		return convencional;
	}
	/**
	 * @param convencional the convencional to set
	 */
	public void setConvencional(List<String> convencional) {
		this.convencional = convencional;
	}
	/**
	 * @return the controle
	 */
	public List<String> getControle() {
		return controle;
	}
	/**
	 * @param controle the controle to set
	 */
	public void setControle(List<String> controle) {
		this.controle = controle;
	}
	/**
	 * @return the aluguelZero
	 */
	public List<String> getAluguelZero() {
		return aluguelZero;
	}
	/**
	 * @param aluguelZero the aluguelZero to set
	 */
	public void setAluguelZero(List<String> aluguelZero) {
		this.aluguelZero = aluguelZero;
	}
	/**
	 * @return the mei
	 */
	public List<String> getMei() {
		return mei;
	}
	/**
	 * @param mei the mei to set
	 */
	public void setMei(List<String> mei) {
		this.mei = mei;
	}
	/**
	 * @return the pf
	 */
	public List<String> getPf() {
		return pf;
	}
	/**
	 * @param pf the pf to set
	 */
	public void setPf(List<String> pf) {
		this.pf = pf;
	}
	/**
	 * @return the pj
	 */
	public List<String> getPj() {
		return pj;
	}
	/**
	 * @param pj the pj to set
	 */
	public void setPj(List<String> pj) {
		this.pj = pj;
	}
	/**
	 * @return the entregaMaquina
	 */
	public List<String> getEntregaMaquina() {
		return entregaMaquina;
	}
	/**
	 * @param entregaMaquina the entregaMaquina to set
	 */
	public void setEntregaMaquina(List<String> entregaMaquina) {
		this.entregaMaquina = entregaMaquina;
	}
	
	

}
