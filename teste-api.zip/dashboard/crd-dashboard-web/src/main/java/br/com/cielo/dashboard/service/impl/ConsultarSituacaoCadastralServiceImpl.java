package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.SituacaoCadastralDTO;
import br.com.cielo.credenciamento.service.dashboard.ConsultarSituacaoCadastralServiceRemote;
import br.com.cielo.dashboard.service.IConsultarSituacaoCadastralService;

@Service
public class ConsultarSituacaoCadastralServiceImpl implements IConsultarSituacaoCadastralService  {

	@Resource(mappedName="ConsultarSituacaoCadastralService#br.com.cielo.credenciamento.service.dashboard.ConsultarSituacaoCadastralServiceRemote")
	private ConsultarSituacaoCadastralServiceRemote consultarSituacaoCadastralService;
	
	
	@Override
	public List<SituacaoCadastralDTO> listarSituacaoCadastral() {
		return consultarSituacaoCadastralService.listarSituacaoCadastral();
	}

}
