package br.com.cielo.dashboard.service;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import br.com.cielo.dashboard.dto.InfoUsuarioLdapDTO;
import br.com.cielo.dashboard.model.Usuario;

/**
 * Interface responsavel pelas regras de autenticação / autorização LDAP
 * @author @Cielo
 * @since 1.0.0
 */
public interface AuthenticationService {

	/**
	 * Método responsavel pela autenticação do usuário
	 * @param usuario
	 * @return UsernamePasswordAuthenticationToken
	 */
	InfoUsuarioLdapDTO autenticarAutorizar(Usuario usuario);
	
	/**
	 * Método responsavel por criar o token de autenticação
	 * @param infoUsuario
	 */
	UsernamePasswordAuthenticationToken createToken(Usuario usuario);
	
}
