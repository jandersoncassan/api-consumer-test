package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.TipoPlanoCieloDTO;
import br.com.cielo.credenciamento.service.dashboard.TipoPlanoCieloServiceRemote;
import br.com.cielo.dashboard.service.ITipoPlanoCieloService;

@Service
public class TipoPlanoCieloServiceImpl implements ITipoPlanoCieloService {

	@Resource(mappedName="TipoPlanoCieloService#br.com.cielo.credenciamento.service.dashboard.TipoPlanoCieloServiceRemote")
	private TipoPlanoCieloServiceRemote tipoPlanoCieloServiceRemote;

	@Override
	public List<TipoPlanoCieloDTO> getTiposPlanoCielo() {

		return tipoPlanoCieloServiceRemote.getTiposPlanoCielo();
		
	}

}
