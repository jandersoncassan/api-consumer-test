/**
 * 
 */
package br.com.cielo.dashboard.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.credenciamento.enums.ProdutosEnum;
import br.com.cielo.credenciamento.enums.ServicoEnum;
import br.com.cielo.credenciamento.enums.SolucaoCapturaEnum;
import br.com.cielo.dashboard.dto.ConsultarDetalhePropostaDTO;
import br.com.cielo.dashboard.dto.ProdutosDTO;
import br.com.cielo.dashboard.dto.ServicosDTO;
import br.com.cielo.dashboard.model.Critica;
import br.com.cielo.dashboard.model.Endereco;
import br.com.cielo.dashboard.model.Etapa;
import br.com.cielo.dashboard.model.Proprietarios;
import br.com.cielo.dashboard.model.SolicitacaoSolucaoCaptura;
import br.com.cielo.dashboard.model.SolucaoCaptura;
import br.com.cielo.dashboard.model.Status;
import br.com.cielo.dashboard.model.Telefone;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IConsultarCriticasService;
import br.com.cielo.dashboard.service.IConsultarDetalhePropostaService;
import br.com.cielo.dashboard.service.IConsultarEnderecoService;
import br.com.cielo.dashboard.service.IConsultarEtapasService;
import br.com.cielo.dashboard.service.IConsultarMotivoInstalacaoService;
import br.com.cielo.dashboard.service.IConsultarProdutosService;
import br.com.cielo.dashboard.service.IConsultarProprietariosService;
import br.com.cielo.dashboard.service.IConsultarServicosService;
import br.com.cielo.dashboard.service.IConsultarSolicitacaoSolucaoCapturaService;
import br.com.cielo.dashboard.service.IConsultarSolucaoCapturaService;
import br.com.cielo.dashboard.service.IConsultarTelefoneService;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author Cielo S/A
 *
 */
@Controller
@Scope(value=WebApplicationContext.SCOPE_REQUEST)
public class ConsultarDetalhePropostaController {

	private static final Logger LOG = LogManager.getLogger(ConsultarDetalhePropostaController.class);
 
	@Autowired
	private IConsultarDetalhePropostaService consultarDetalhePropostaService;
	@Autowired
	private IConsultarProdutosService consultarProdutoService;
	@Autowired
	private IConsultarServicosService consultarServicosService;
	@Autowired
	private IConsultarEtapasService etapaService;
	@Autowired
	private IConsultarSolucaoCapturaService consultarSolucaoCapturaService;
	@Autowired
	private IConsultarSolicitacaoSolucaoCapturaService consultarSolicitacaoSolucaoCapturaService;
	@Autowired
	private IConsultarEnderecoService consultarEnderecoService;
	@Autowired
	private IConsultarTelefoneService consultarTelefoneService;
	@Autowired
	private IConsultarProprietariosService consultarProprietariosService;
	@Autowired
	private IConsultarCriticasService criticaService;
    @Autowired
    private IConsultarMotivoInstalacaoService motivoInstalacaoService;

	@RequestMapping("/initDetalheProposta")
	@Secured(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA)
	public String initDetalheProposta(HttpSession session, Model model,
			@ModelAttribute("consultar_detalhe_proposta") ConsultarDetalhePropostaDTO consultar) throws ParseException {
		if (DashboardUtils.isNotNullOrEmpty(session.getAttribute("numeroProposta"))) {
			LOG.info("INICIANDO O DETALHE DA PROPOSTA");

			Long prop = (Long) session.getAttribute("numeroProposta");
			consultar = getConsultarDetalheProposta(prop, session);

			model.addAttribute("consultar_detalhe_proposta", consultar);
			model.addAttribute("listProdutos", getListarProdutos(prop));
			model.addAttribute("listServicos", getListarServicos(prop));
			model.addAttribute("listEtapas", getListarEtapas(prop));
			
			model.addAttribute("listSolucaoCaptura", getListaSolucaoCaptura(prop));
			model.addAttribute("listSolicitacaoSolucaoCaptura", getListaSolicitacaoSolucaoCaptura(prop));
			model.addAttribute("listEndereco", getListaEndereco(prop));
			model.addAttribute("listTelefone", getListaTelefone(prop));
			model.addAttribute("listProprietarios", getListarProprietarios(prop));
			model.addAttribute("listCriticas", getListarCriticasByProposta(prop, session));
		}
		return NavigationDashBoard.CONSULTAR_DETALHE_PROPOSTA;
	}

	/**
	 * 
	 * @param numeroProposta
	 * @return
	 * @throws ParseException
	 */
	private ConsultarDetalhePropostaDTO getConsultarDetalheProposta(Long numeroProposta, HttpSession session)
			throws ParseException {
		LOG.info("CHAMANDO SERVICE PARA CONSULTAR DOS DETALHES DA PROPOSTA");
		return montarDto(consultarDetalhePropostaService.getDetalheProposta((Long) numeroProposta),
				(Long) numeroProposta, session);
	}

	/**
	 * 
	 * @param retornoConsulta
	 * @return
	 * @throws ParseException
	 */
	@SuppressWarnings("unchecked")
	private ConsultarDetalhePropostaDTO montarDto(Object[] retornoConsulta, Long proposta, HttpSession session)
			throws ParseException {

		ConsultarDetalhePropostaDTO dto = new ConsultarDetalhePropostaDTO();

		
		List<Status> listStatus = (List<Status>) session.getAttribute("listaStatus");

		dto.setProposta(proposta);

		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[3])) {
			dto.setDataAlteracaoRegistro(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta[3])));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[4])) {
			dto.setCodigoEtapa(Integer.parseInt(String.valueOf(retornoConsulta[4])));
			dto.setEtapa(getDescricaoEtapa(Integer.parseInt(String.valueOf(retornoConsulta[4])),session));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[5])) {
			dto.setNumeroEstabelecimentoComercial(Long.parseLong(String.valueOf(retornoConsulta[5])));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[6])) {
			dto.setRazaoSocial(String.valueOf(retornoConsulta[6]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[7])) {
			dto.setNomeFantasia(String.valueOf(retornoConsulta[7]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[8])) {
			dto.setInscricaoEstadual(Long.parseLong(String.valueOf(retornoConsulta[8])));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[9])) {
			dto.setMcc(String.valueOf(retornoConsulta[9]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[10])) {
			dto.setMccValidado(String.valueOf(retornoConsulta[10]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[11])) {
			dto.setNomeContato(String.valueOf(retornoConsulta[11]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[12])) {
			dto.setEmail(String.valueOf(retornoConsulta[12]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[13])) {
			dto.setIndicadorOfertaMei(String.valueOf(retornoConsulta[13]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[14])) {
			dto.setNomePlaqueta(String.valueOf(retornoConsulta[14]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[15])) {
			dto.setAfiliador(String.valueOf(retornoConsulta[15]));
		}

		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[16])) {
			dto.setSituacaoProposta(String.valueOf(retornoConsulta[16]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[17])) {
			dto.setDataAberturaProposta(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta[17])));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[18])) {
			for (Status st : listStatus) {
				if (st.getCodigo().equals(Integer.parseInt(String.valueOf(retornoConsulta[18])))) {
					dto.setSituacaoEtapa(st.getDescricao());
					break;
				}
			}
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[19])) {
			dto.setBanco(String.valueOf(retornoConsulta[19]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[20])) {
			dto.setFerramenta(String.valueOf(retornoConsulta[20]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[21])) {
			dto.setTipoPessoa(String.valueOf(retornoConsulta[21]));
			if (String.valueOf(retornoConsulta[21]).equalsIgnoreCase(DashboardUtils.FISICA)) {
				dto.setCpfCnpj(DashboardUtils.formatCpf(Integer.parseInt(String.valueOf(retornoConsulta[22])),
						Integer.parseInt(String.valueOf(retornoConsulta[23]))));
			} else {
				dto.setCpfCnpj(DashboardUtils.formatCnpj(Integer.parseInt(String.valueOf(retornoConsulta[24])),
						Integer.parseInt(String.valueOf(retornoConsulta[25])),
						Integer.parseInt(String.valueOf(retornoConsulta[26]))));
			}
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[27])) {
			dto.setPrioridadeAtendimento(Integer.parseInt(String.valueOf(retornoConsulta[27])));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[28])) {
			dto.setCategoria(String.valueOf(retornoConsulta[28]));
		}
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[29])) {
			dto.setAtivado(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta[29])));
		}
		//OFERTAS
		dto.setIndOfertaAssociada(DashboardUtils.isNotNullOrEmpty(retornoConsulta[30]) ? String.valueOf(retornoConsulta[30]) : DashboardUtils.EMPTY);	
		dto.setIndAceiteOferta(DashboardUtils.isNotNullOrEmpty(retornoConsulta[31]) ? String.valueOf(retornoConsulta[31]) : DashboardUtils.EMPTY);
		dto.setNivelOferta(DashboardUtils.isNotNullOrEmpty(retornoConsulta[32]) ? String.valueOf(retornoConsulta[32]) : DashboardUtils.EMPTY);
		dto.setCodigoOferta(DashboardUtils.isNotNullOrEmpty(retornoConsulta[33]) ? String.valueOf(retornoConsulta[33]) : DashboardUtils.EMPTY);
		if (DashboardUtils.isNotNullOrEmpty(retornoConsulta[34])) {
			dto.setBancoDescricao(String.valueOf(retornoConsulta[34]));
		}
		
		LOG.info("FINALIZACAO DA DTO DE CONSULTAR PROPOSTA DETALHE");
		return dto;
	}
	

	@SuppressWarnings("unchecked")
	private String getDescricaoEtapa(Integer etapa, HttpSession session) {
		List<Etapa> listEtapa = (List<Etapa>) session.getAttribute("listaEtapa");
		for (Etapa et : listEtapa) {
			if (et.getCodigo().equals(etapa)) {
				return et.getDescricao();
			}
		}
		return DashboardUtils.EMPTY;
	}

	/**
	 * 
	 * @param consultar
	 * @param session
	 * @param model
	 * @return
	 */
	private List<ProdutosDTO> getListarProdutos(Long proposta) {
		LOG.info("POPULANDO LISTA DE PRODUTOS");
		List<Object[]> retorno = consultarProdutoService.getListarProdutos(proposta);
		List<ProdutosDTO> listProduto = new ArrayList<ProdutosDTO>();

		for (int i = 0; i < retorno.size(); i++) {
			ProdutosDTO dto = new ProdutosDTO();
			dto.setCodigo(Integer.parseInt(String.valueOf(retorno.get(i)[0])));
			for (ProdutosEnum e : ProdutosEnum.values()) {
				if (e.getCodigo().equals(dto.getCodigo())) {
					dto.setDescricao(e.getDescricao());
					break;
				}
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[1])) {
				dto.setQuantidadeParcelas(String.valueOf(retorno.get(i)[1]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[2])) {
				dto.setQuantidadeDiasLiquidacao(String.valueOf(retorno.get(i)[2]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[3])) {
				dto.setIndicadorHabilitacao(String.valueOf(retorno.get(i)[3]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[4])) {
				dto.setCodigoErro(String.valueOf(retorno.get(i)[4]));
			}
			listProduto.add(dto);
		}
		LOG.info("FINALIZANDO LISTA DE PRODUTOS");
		return listProduto;
	}

	/**
	 * @param consultar
	 * @param session
	 * @param model
	 * @return
	 */
	private List<ServicosDTO> getListarServicos(Long proposta) {
		LOG.info("POPULANDO LISTA DE SERVICOS");
		List<Object[]> retorno = consultarServicosService.getListarServicos(proposta);
		List<ServicosDTO> listServicos = new ArrayList<ServicosDTO>();
		for (int i = 0; i < retorno.size(); i++) {
			ServicosDTO dto = new ServicosDTO();
			dto.setCodigo(Integer.parseInt(String.valueOf(retorno.get(i)[0])));
			for (ServicoEnum s : ServicoEnum.values()) {
				if (s.getCodigo().equals(dto.getCodigo())) {
					dto.setDescricao(s.getDescricao());
					break;
				}
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[1])) {
				dto.setIndicadorhabilitacao(String.valueOf(retorno.get(i)[1]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[2])) {
				dto.setErroServico(String.valueOf(retorno.get(i)[2]));
			}
			listServicos.add(dto);
		}
		LOG.info("FINALIZANDO LISTA DE SERVICOS");
		return listServicos;
	}

	/**
	 * @param consultar
	 * @param session
	 * @param model
	 * @return
	 * @throws ParseException
	 */
	private List<Etapa> getListarEtapas(Long proposta) throws ParseException {
		LOG.info("POPULANDO LISTA DE ETAPAS");
		List<Object[]> retorno = etapaService.getListarEtapaByProposta(proposta);
		List<Etapa> listServicos = new ArrayList<Etapa>();
		for (int i = 0; i < retorno.size(); i++) {
			Etapa et = new Etapa();
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[0])) {
				et.setDescricao(String.valueOf(retorno.get(i)[0]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[1])) {
				et.setStatusEtapa(String.valueOf(retorno.get(i)[1]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[2])) {
				et.setDataAberturaEtapa(DashboardUtils.convertStringToDate(String.valueOf(retorno.get(i)[2])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retorno.get(i)[3])) {
				et.setDataEncerramentoEtapa(DashboardUtils.convertStringToDate(String.valueOf(retorno.get(i)[3])));
			}
			listServicos.add(et);
		}
		LOG.info("FINALIZANDO LISTA DE ETAPAS");
		return listServicos;
	}

	/**
	 * Método: Obtem os telefones relacionados a proposta
	 * 
	 * @param proposta
	 * @param session
	 * @return
	 */
	private List<Telefone> getListaTelefone(Long proposta) {
		LOG.info("POPULANDO LISTA DE TELEFONE");
		List<Telefone> listTelefone = new ArrayList<Telefone>();
		List<Object[]> retornoConsulta = consultarTelefoneService.getListarTelefoneByProposta(proposta);
		for (int i = 0; i < retornoConsulta.size(); i++) {
			Telefone t = new Telefone();
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[0])) {
				t.setTipoTelefone(String.valueOf(retornoConsulta.get(i)[0]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[1])) {
				t.setDdd(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[1])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[2])) {
				t.setTelefone(DashboardUtils.formatTelefone(String.valueOf(retornoConsulta.get(i)[2])));
			}
			listTelefone.add(t);
		}
		LOG.info("FINALIZANDO LISTA DE TELEFONE");
		return listTelefone;
	}

	/**
	 * Método: Obtem Lista de enderecos relacionados a proposta
	 * 
	 * @param proposta
	 * @return
	 */
	private List<Endereco> getListaEndereco(Long proposta) {
		LOG.info("POPULANDO LISTA DE ENDERECOS");
		List<Endereco> listEndereco = new ArrayList<Endereco>();
		List<Object[]> retornoConsulta = consultarEnderecoService.getListarEnderecoByProposta(proposta);
		for (int i = 0; i < retornoConsulta.size(); i++) {
			Endereco end = new Endereco();
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[0])) {
				end.setTipoEndereco(String.valueOf(retornoConsulta.get(i)[0]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[1])) {
				end.setLogradouro(String.valueOf(retornoConsulta.get(i)[1]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[2])) {
				end.setComplementoLogradouro(String.valueOf(retornoConsulta.get(i)[2]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[3])) {
				end.setCidade(String.valueOf(retornoConsulta.get(i)[3]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[4])) {
				end.setEstado(String.valueOf(retornoConsulta.get(i)[4]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[5])) {
				end.setCep(DashboardUtils.formatCep(String.valueOf(retornoConsulta.get(i)[5])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[6])&& 
						!retornoConsulta.get(i)[6].equals(DashboardUtils.NULL)) {
				end.setNumeroLogradouro(String.valueOf(retornoConsulta.get(i)[6]));
			}
			
			listEndereco.add(end);
		}
		LOG.info("FINALIZANDO LISTA DE ENDERECOS");
		return listEndereco;
	}
	/**
	 * Método: Obtem lista de Proprietarios relacionados a proposta
	 * @param proposta
	 * @return
	 * @throws ParseException
	 */
	private List<Proprietarios> getListarProprietarios(Long proposta) throws ParseException {
		LOG.info("POPULANDO LISTA DE PROPRIETARIOS");
		List<Proprietarios> listProprietarios = new ArrayList<Proprietarios>();
		List<Object[]> retornoConsulta = consultarProprietariosService.getListarProprietariosByProposta(proposta);
		for (int i = 0; i < retornoConsulta.size(); i++) {
			Proprietarios prop = new Proprietarios();
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[0])) {
				prop.setNomeProprietario(String.valueOf(retornoConsulta.get(i)[0]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[1])) {
				prop.setCpf(DashboardUtils.formatCpf(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[1])),
						Integer.parseInt(String.valueOf(retornoConsulta.get(i)[2]))));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[3])) {
				prop.setDataNascimento(DashboardUtils.convertDateToString(String.valueOf(retornoConsulta.get(i)[3])));
			}
			listProprietarios.add(prop);
		}
		LOG.info("FINALIZANDO LISTA DE PROPRIETARIOS");
		return listProprietarios;
	}
	/**
	 * Método: Obtem solução de captura relacionada a proposta
	 * @param proposta
	 * @return
	 * @throws ParseException
	 */
	private List<SolucaoCaptura> getListaSolucaoCaptura(Long proposta) throws ParseException{
		LOG.info("POPULANDO LISTA DE SOLUCAO DE CAPTURA");
		List<SolucaoCaptura> listSolucaoCaptura = new ArrayList<SolucaoCaptura>();
		List<Object[]> retornoConsulta = consultarSolucaoCapturaService.getListarSolucaoCapturaByProposta(proposta);
		for (int i = 0; i < retornoConsulta.size(); i++) {
			SolucaoCaptura solucao = new SolucaoCaptura();
			
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[0])) {
				solucao.setChamadoInstalacao(String.valueOf(retornoConsulta.get(i)[0]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[1])) {
				solucao.setNumeroLogico(String.valueOf(retornoConsulta.get(i)[1]));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[2])) {
				solucao.setTipoTerminal(SolucaoCapturaEnum.getSolucaoCapturaEnum(
								Integer.parseInt(String.valueOf(retornoConsulta.get(i)[2]))).getDescricaoParaCliente());
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[3])) {
				solucao.setDataPrevistaInstalacao(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta.get(i)[3])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[4])) {
				solucao.setDataInstalacaoEquipamento(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta.get(i)[4])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[5])) {
				solucao.setDataCancelamentoInstalacao(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta.get(i)[5])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[6])) {
			    String codigo = String.valueOf(retornoConsulta.get(i)[6]);
                solucao.setCodigoMotivoCancelamento(codigo);
                String descricao = "MOTIVO SEM DESCRIÇÃO";
                try {
                    descricao = this.motivoInstalacaoService
                            .getDominioById(Integer.valueOf(codigo)).getDescricao();
                    solucao.setCodigoMotivoCancelamento(codigo + " - " + descricao);
                    solucao.setDescricaoMotivoCancelamento(descricao);
                } catch (Throwable t) {
                    LOG.error("Erro ao popular motivo instalação", t);
                }
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[7])) {
				solucao.setDataAtivacao(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta.get(i)[7])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[8])) {
				solucao.setDataDesbloqueio(DashboardUtils.convertStringToDate(String.valueOf(retornoConsulta.get(i)[8])));
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[9])) {
				solucao.setCodigoAcesso(String.valueOf(retornoConsulta.get(i)[9]));
			}

			listSolucaoCaptura.add(solucao);	
		}
		LOG.info("FINALIZANDO LISTA DE SOLUCAO DE CAPTURA");
		return listSolucaoCaptura;
	}
	/**
	 * Método: Obtem solução de captura relacionada a proposta
	 * @param proposta
	 * @return
	 * @throws ParseException
	 */
	private List<SolicitacaoSolucaoCaptura> getListaSolicitacaoSolucaoCaptura(Long proposta) throws ParseException{
		LOG.info("POPULANDO LISTA DE SOLICITACAO SOLUCAO DE CAPTURA");
		List<SolicitacaoSolucaoCaptura> listSolicitacaoSolucaoCaptura = new ArrayList<SolicitacaoSolucaoCaptura>();
		List<Object[]> retornoConsulta = consultarSolicitacaoSolucaoCapturaService.getListarSolicitacaoSolucaoCapturaByProposta(proposta);
		for (int i = 0; i < retornoConsulta.size(); i++) {
			SolicitacaoSolucaoCaptura solucao = new SolicitacaoSolucaoCaptura();
			
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[0])) {
				String solucaoCaptura = String.valueOf(retornoConsulta.get(i)[0]);
				solucao.setDescricao(solucaoCaptura.equals("0")?"INVÁLIDA": SolucaoCapturaEnum.getSolucaoCapturaEnum(
						Integer.parseInt(String.valueOf(retornoConsulta.get(i)[0]))).getDescricaoParaCliente());
			}
			if (DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[1])) {
				solucao.setQuantidade(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[1])));
			}
			listSolicitacaoSolucaoCaptura.add(solucao);	
		}
		LOG.info("FINALIZANDO LISTA DE SOLUCAO DE CAPTURA");
		return listSolicitacaoSolucaoCaptura;
	}
	/**
	 * 
	 * @param proposta
	 * @return
	 */
	private List<Critica> getListarCriticasByProposta(final Long proposta, HttpSession session){
		LOG.info("POPULANDO LISTA DE CRITICAS");
		List<Critica> listCriticas = new ArrayList<Critica>();
		List<Object[]> retornoConsulta = criticaService.getListaCriticasByProposta(proposta);
		for (int i = 0; i < retornoConsulta.size(); i++) {
			Critica critica = new Critica();
			if(DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[0])){
				critica.setEtapa(getDescricaoEtapa(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[0])),session));
			}
			if(DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[1])){
				critica.setCodigo(Integer.parseInt(String.valueOf(retornoConsulta.get(i)[1])));
			}
			if(DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[2])){
				critica.setDescricao(String.valueOf(retornoConsulta.get(i)[2]));
			}
			if(DashboardUtils.isNotNullOrEmpty(retornoConsulta.get(i)[3])){
				critica.setIndicador(String.valueOf(
						retornoConsulta.get(i)[3]).equalsIgnoreCase(DashboardUtils.S)?DashboardUtils.SIM:DashboardUtils.NAO);
			}
			listCriticas.add(critica);
		}
		LOG.info("FINALIZANDO LISTA DE CRITICAS");
		return listCriticas;
		
	}
}
