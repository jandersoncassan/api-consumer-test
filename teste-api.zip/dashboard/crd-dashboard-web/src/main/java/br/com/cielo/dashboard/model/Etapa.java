/**
 * 
 */
package br.com.cielo.dashboard.model;

/**
 * @author dcarneiro
 *
 */
public class Etapa {

	private Integer codigo;
	private String descricao;
	private String statusEtapa;
	private String dataAberturaEtapa;
	private String dataEncerramentoEtapa;
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the statusEtapa
	 */
	public String getStatusEtapa() {
		return statusEtapa;
	}
	/**
	 * @param statusEtapa the statusEtapa to set
	 */
	public void setStatusEtapa(String statusEtapa) {
		this.statusEtapa = statusEtapa;
	}
	/**
	 * @return the dataAberturaEtapa
	 */
	public String getDataAberturaEtapa() {
		return dataAberturaEtapa;
	}
	/**
	 * @param dataAberturaEtapa the dataAberturaEtapa to set
	 */
	public void setDataAberturaEtapa(String dataAberturaEtapa) {
		this.dataAberturaEtapa = dataAberturaEtapa;
	}
	/**
	 * @return the dataEncerramentoEtapa
	 */
	public String getDataEncerramentoEtapa() {
		return dataEncerramentoEtapa;
	}
	/**
	 * @param dataEncerramentoEtapa the dataEncerramentoEtapa to set
	 */
	public void setDataEncerramentoEtapa(String dataEncerramentoEtapa) {
		this.dataEncerramentoEtapa = dataEncerramentoEtapa;
	}
	
	
}
