/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarSolicitacaoSolucaoCapturaServiceRemote;
import br.com.cielo.dashboard.service.IConsultarSolicitacaoSolucaoCapturaService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarSolicitacaoSolucaoCapturaServiceImpl implements IConsultarSolicitacaoSolucaoCapturaService{
	
	@Resource(mappedName ="ConsultarSolicitacaoSolucaoCapturaService#br.com.cielo.credenciamento.service.dashboard.ConsultarSolicitacaoSolucaoCapturaServiceRemote")
	private ConsultarSolicitacaoSolucaoCapturaServiceRemote consultarSolicitacaoSolucaoCapturaServiceRemote;
	/**
	 * @param proposta
	 * @return
	 */
	public List<Object[]> getListarSolicitacaoSolucaoCapturaByProposta(Long proposta) {
		return consultarSolicitacaoSolucaoCapturaServiceRemote.getSolicitacaoSolucaoCaptura(proposta);
	}
}
