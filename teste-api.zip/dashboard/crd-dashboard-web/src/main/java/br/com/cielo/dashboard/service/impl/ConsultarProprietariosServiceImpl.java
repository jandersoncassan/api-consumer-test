/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarProprietariosServiceRemote;
import br.com.cielo.dashboard.service.IConsultarProprietariosService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarProprietariosServiceImpl implements IConsultarProprietariosService {

	@Resource(mappedName ="ConsultarProprietariosService#br.com.cielo.credenciamento.service.dashboard.ConsultarProprietariosServiceRemote")
	private ConsultarProprietariosServiceRemote consultarProprietariosServiceRemote;
	/**
	 * @param proposta
	 * @return
	 */
	public List<Object[]> getListarProprietariosByProposta(Long proposta) {
		return consultarProprietariosServiceRemote.getListaProprietariosByProposta(proposta);
	}
}
