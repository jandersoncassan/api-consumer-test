package br.com.cielo.dashboard.validator;

import java.util.List;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import br.com.cielo.dashboard.dto.ItemGradeValidacaoDomicilioBancarioDTO;
import br.com.cielo.dashboard.dto.ValidacaoDomicilioBancarioAuxiliarDTO;
import br.com.cielo.dashboard.utils.DashboardUtils;

@Component("validacaoDomicilioBancarioValidator")
public class ValidacaoDomicilioBancarioValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return ValidacaoDomicilioBancarioAuxiliarDTO.class.equals(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		ValidacaoDomicilioBancarioAuxiliarDTO formObject = (ValidacaoDomicilioBancarioAuxiliarDTO) target;

		List<ItemGradeValidacaoDomicilioBancarioDTO> itens = formObject.getListaValidacaoDomicilioBancario();

		if (formObject.getParametrizacoesAtivas() != null) {
			for (int i = 0; i < itens.size(); i++) {
				if (formObject.getParametrizacoesAtivas().contains(itens.get(i).getIdValidacaoDomicilioBancario())) {
					if (!DashboardUtils.isNotNullOrEmpty(itens.get(i).getCodigoSituacaoCadastral())) {
						errors.rejectValue("listaValidacaoDomicilioBancario[" + i + "].codigoSituacaoCadastral",
								"situacao.cadastral.nao.informada.validacao.bancaria", new Object[] { itens.get(i).getIdValidacaoDomicilioBancario() },
								"Selecione uma situação cadastral para o item " + itens.get(i).getDescricaoFerramenta() + " - " + itens.get(i).getDescricaoSolucaoCaptura());
					}
				}
			}
		}
		
	}

}
