/**
 * 
 */
package br.com.cielo.dashboard.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import br.com.cielo.credenciamento.enums.FerramentaEnum;
import br.com.cielo.credenciamento.enums.SituacaoEtapaEnum;
import br.com.cielo.credenciamento.enums.SolucaoCapturaEnum;
import br.com.cielo.credenciamento.enums.TipoContaEnum;
import br.com.cielo.credenciamento.enums.TipoPacoteEcommerceEnum;
import br.com.cielo.dashboard.utils.DashboardFile;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author dcarneiro
 *
 */
public class Proposta implements Serializable {

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;

	private String etapa;
	private Integer codigoEtapa;
	private String dataInclusaoRegistro;
	private Date dataInclusaoRegistroDate;
	private Integer ferramenta;
	private String banco;
	private String bancoDescricao;
	private Integer solucaoCaptura;
	private Integer situacaoEtapa;
	private Long proposta;
	private String campoCpfCnpj;
	private Long estabelecimentoComercial;
	private Long codigoAfiliacao;
	private String motivoCancelamento;
	private String descricaoMotivoCancelamento;
	private Integer codigoCritica;
	private String razaoSocial;
	private String nomeFantasia;
	private String mccAcatado;
	private String situacaoProposta;
	private String etapaConcatenadas;
	private String criticasConcatenadasComRessalvas;
	private String criticasConcatenadasSemRessalvas;
	private String tipoConta;
	private String codigoTipoPacoteComercioEletronico;
	private String descricaoTipoPlanoCielo;
	private BigDecimal valorFatMedioMensal;
    private Integer quantidadeDiasLiquidacao;
    private String indicadorPropostaAgro;
    private String codigoAgencia;
    private String indicadorClienteMultivan;
    private String dataCadastroEc;
    private String dataAtivacaoEc;
    /*ATRIBUTOS OFERTAS*/
    private String indOfertaAssociada;
    private String indAceiteOferta;
    private String nivelOferta;
    private String codigoOferta;
    private String codigoOfertaCombo;
    private String loginUsuarioOperador;
    /*ATRIBUTOS RL05 SPRINT02 SMART*/
    private Long numEcCadeiaForcada;
    private Long numEcEspelho;
    private String indEspelhamentoTaxa;
    private String nomeExecutivo;
    private String perfilSmart;
    private String indEntregaMaquina;
    
	/**
	 * @return the dataInclusaoRegistro
	 */
	public String getDataInclusaoRegistro() {
		return dataInclusaoRegistro;
	}

	/**
	 * @param dataInclusaoRegistro
	 *            the dataInclusaoRegistro to set
	 */
	public void setDataInclusaoRegistro(String dataInclusaoRegistro) {
		this.dataInclusaoRegistro = dataInclusaoRegistro;
	}

	/**
	 * @return the ferramenta
	 */
	public Integer getFerramenta() {
		return ferramenta;
	}

	/**
	 * @param ferramenta
	 *            the ferramenta to set
	 */
	public void setFerramenta(Integer ferramenta) {
		this.ferramenta = ferramenta;
	}

	/**
	 * @return the banco
	 */
	public String getBanco() {
		return banco;
	}

	/**
	 * @param banco
	 *            the banco to set
	 */
	public void setBanco(String banco) {
		this.banco = banco;
	}

	/**
	 * @return the solucaoCaptura
	 */
	public Integer getSolucaoCaptura() {
		return solucaoCaptura;
	}

	/**
	 * @param solucaoCaptura
	 *            the solucaoCaptura to set
	 */
	public void setSolucaoCaptura(Integer solucaoCaptura) {
		this.solucaoCaptura = solucaoCaptura;
	}

	/**
	 * @return the situacaoEtapa
	 */
	public Integer getSituacaoEtapa() {
		return situacaoEtapa;
	}

	/**
	 * @param situacaoEtapa
	 *            the situacaoEtapa to set
	 */
	public void setSituacaoEtapa(Integer situacaoEtapa) {
		this.situacaoEtapa = situacaoEtapa;
	}

	/**
	 * @return the proposta
	 */
	public Long getProposta() {
		return proposta;
	}

	/**
	 * @param proposta
	 *            the proposta to set
	 */
	public void setProposta(Long proposta) {
		this.proposta = proposta;
	}

	/**
	 * @return the estabelecimentoComercial
	 */
	public Long getEstabelecimentoComercial() {
		return estabelecimentoComercial;
	}

	/**
	 * @param estabelecimentoComercial
	 *            the estabelecimentoComercial to set
	 */
	public void setEstabelecimentoComercial(Long estabelecimentoComercial) {
		this.estabelecimentoComercial = estabelecimentoComercial;
	}

	/**
	 * @return the codigoAfiliacao
	 */
	public Long getCodigoAfiliacao() {
		return codigoAfiliacao;
	}

	/**
	 * @param codigoAfiliacao
	 *            the codigoAfiliacao to set
	 */
	public void setCodigoAfiliacao(Long codigoAfiliacao) {
		this.codigoAfiliacao = codigoAfiliacao;
	}

	/**
	 * @return the motivoCancelamento
	 */
	public String getMotivoCancelamento() {
		return motivoCancelamento;
	}
	
	/**
	 * @param motivoCancelamento
	 *            the motivoCancelamento to set
	 */
	public void setMotivoCancelamento(String motivoCancelamento) {
		this.motivoCancelamento = motivoCancelamento;
	}

	/**
	 * @return the campoCpfCnpj
	 */
	public String getCampoCpfCnpj() {
		return campoCpfCnpj;
	}

	/**
	 * @param campoCpfCnpj
	 *            the campoCpfCnpj to set
	 */
	public void setCampoCpfCnpj(String campoCpfCnpj) {
		this.campoCpfCnpj = campoCpfCnpj;
	}

	/**
	 * @return the codigoCritica
	 */
	public Integer getCodigoCritica() {
		return codigoCritica;
	}

	/**
	 * @param codigoCritica
	 *            the codigoCritica to set
	 */
	public void setCodigoCritica(Integer codigoCritica) {
		this.codigoCritica = codigoCritica;
	}
	/**
	 * @return the etapa
	 */
	public String getEtapa() {
		return etapa;
	}

	/**
	 * @param etapa the etapa to set
	 */
	public void setEtapa(String etapa) {
		this.etapa = etapa;
	}
	/**
	 * 
	 * @return
	 */	
	public String getBancoDescricao() {
		return bancoDescricao;
	}
	
	/**
	 * @param bancoDescricao the bancoDescricao to set
	 */
	public void setBancoDescricao(String bancoDescricao) {
		this.bancoDescricao = bancoDescricao;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getFerramentaDescricao() {
		for (FerramentaEnum ferramentaEnum : FerramentaEnum.values()) {
			if (ferramentaEnum.getCodigo().equals(this.getFerramenta())) {
				return ferramentaEnum.getDescricao();
			}
		}
		return DashboardUtils.EMPTY;
	}
	/**
	 * 
	 * @return
	 */
	public String getStatusDescricao() {
		for (SituacaoEtapaEnum statusEnum : SituacaoEtapaEnum.values()) {
			if (statusEnum.getCodigo().equals(this.getSituacaoEtapa())) {
				return statusEnum.getDescricao();
			}
		}
		return DashboardUtils.EMPTY;
	}
	/**
	 * 
	 * @return
	 */
	public String getSolucaoCapturaDescricao() {
		for (SolucaoCapturaEnum solucaoCapturaEnum : SolucaoCapturaEnum.values()) {
			if (solucaoCapturaEnum.getCodigo().equals(this.getSolucaoCaptura())) {
				return solucaoCapturaEnum.getDescricaoParaCliente();
			}
		}
		return DashboardUtils.EMPTY;
	}

	/**
	 * @return the razaoSocial
	 */
	public String getRazaoSocial() {
		return razaoSocial;
	}

	/**
	 * @param razaoSocial the razaoSocial to set
	 */
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	/**
	 * @return the nomeFantasia
	 */
	public String getNomeFantasia() {
		return nomeFantasia;
	}

	/**
	 * @param nomeFantasia the nomeFantasia to set
	 */
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	/**
	 * @return the etapaConcatenadas
	 */
	public String getEtapaConcatenadas() {
		return etapaConcatenadas;
	}

	/**
	 * @param etapaConcatenadas the etapaConcatenadas to set
	 */
	public void setEtapaConcatenadas(String etapaConcatenadas) {
		this.etapaConcatenadas = etapaConcatenadas;
	}

	/**
	 * @return the codigoEtapa
	 */
	public Integer getCodigoEtapa() {
		return codigoEtapa;
	}

	/**
	 * @param codigoEtapa the codigoEtapa to set
	 */
	public void setCodigoEtapa(Integer codigoEtapa) {
		this.codigoEtapa = codigoEtapa;
	}

	/**
	 * @return the mccAcatado
	 */
	public String getMccAcatado() {
		return mccAcatado;
	}

	/**
	 * @param mccAcatado the mccAcatado to set
	 */
	public void setMccAcatado(String mccAcatado) {
		this.mccAcatado = mccAcatado;
	}

	/**
	 * @return the situacaoProposta
	 */
	public String getSituacaoProposta() {
		return situacaoProposta;
	}

	/**
	 * @param situacaoProposta the situacaoProposta to set
	 */
	public void setSituacaoProposta(String situacaoProposta) {
		this.situacaoProposta = situacaoProposta;
	}
	/**
	 * @return the mccValidado
	 */
	public String getMccValidado() {
		String descricaoMccValidado = DashboardFile.getInstance().getMessageInternal("mcc."+mccAcatado);
		return DashboardUtils.isNotNullOrEmpty(descricaoMccValidado)?mccAcatado + " - " + descricaoMccValidado:mccAcatado;
	}

	/**
	 * @return the criticasConcatenadasComRessalvas
	 */
	public String getCriticasConcatenadasComRessalvas() {
		return criticasConcatenadasComRessalvas;
	}

	/**
	 * @param criticasConcatenadasComRessalvas the criticasConcatenadasComRessalvas to set
	 */
	public void setCriticasConcatenadasComRessalvas(String criticasConcatenadasComRessalvas) {
		this.criticasConcatenadasComRessalvas = criticasConcatenadasComRessalvas;
	}

	/**
	 * @return the criticasConcatenadasSemRessalvas
	 */
	public String getCriticasConcatenadasSemRessalvas() {
		return criticasConcatenadasSemRessalvas;
	}

	/**
	 * @param criticasConcatenadasSemRessalvas the criticasConcatenadasSemRessalvas to set
	 */
	public void setCriticasConcatenadasSemRessalvas(String criticasConcatenadasSemRessalvas) {
		this.criticasConcatenadasSemRessalvas = criticasConcatenadasSemRessalvas;
	}

	public String getTipoConta() {
		return tipoConta;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getTipoContaDescricao() {
		for (TipoContaEnum tipoContaEnum : TipoContaEnum.values()) {
			if (tipoContaEnum.getCodigo().equals(this.getTipoConta())) {
				return tipoContaEnum.getDescricaoParaCliente();
			}
		}
		return DashboardUtils.EMPTY;
	}

	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	public String getCodigoTipoPacoteComercioEletronico() {
		return codigoTipoPacoteComercioEletronico;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getTipoPacoteComercioEletronicoDescricao() {
		for (TipoPacoteEcommerceEnum tipoPacoteEcommerceEnum : TipoPacoteEcommerceEnum.values()) {
			if (tipoPacoteEcommerceEnum.getCodigo().equals(this.getCodigoTipoPacoteComercioEletronico())) {
				return tipoPacoteEcommerceEnum.getDescricaoParaCliente();
			}
		}
		return DashboardUtils.EMPTY;
	}

	public void setCodigoTipoPacoteComercioEletronico(String codigoTipoPacoteComercioEletronico) {
		this.codigoTipoPacoteComercioEletronico = codigoTipoPacoteComercioEletronico;
	}

	public String getDescricaoTipoPlanoCielo() {
		return descricaoTipoPlanoCielo;
	}

	public void setDescricaoTipoPlanoCielo(String descricaoTipoPlanoCielo) {
		this.descricaoTipoPlanoCielo = descricaoTipoPlanoCielo;
	}

	public BigDecimal getValorFatMedioMensal() {
		return valorFatMedioMensal;
	}

	public void setValorFatMedioMensal(BigDecimal valorFatMedioMensal) {
		this.valorFatMedioMensal = valorFatMedioMensal;
	}

	public Integer getQuantidadeDiasLiquidacao() {
		return quantidadeDiasLiquidacao;
	}

	public void setQuantidadeDiasLiquidacao(Integer quantidadeDiasLiquidacao) {
		this.quantidadeDiasLiquidacao = quantidadeDiasLiquidacao;
	}

	public String getIndicadorPropostaAgro() {
		return indicadorPropostaAgro;
	}

	public void setIndicadorPropostaAgro(String indicadorPropostaAgro) {
		this.indicadorPropostaAgro = indicadorPropostaAgro;
	}

	public String getCodigoAgencia() {
		return codigoAgencia;
	}

	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	public String getIndicadorClienteMultivan() {
		return indicadorClienteMultivan;
	}

	public void setIndicadorClienteMultivan(String indicadorClienteMultivan) {
		this.indicadorClienteMultivan = indicadorClienteMultivan;
	}

	public String getDescricaoMotivoCancelamento() {
		return descricaoMotivoCancelamento;
	}
	
	public void setDescricaoMotivoCancelamento(String descricaoMotivoCancelamento) {
		this.descricaoMotivoCancelamento = descricaoMotivoCancelamento;
	}

	public String getDataCadastroEc() {
		return dataCadastroEc;
	}

	public void setDataCadastroEc(String dataCadastroEc) {
		this.dataCadastroEc = dataCadastroEc;
	}

	public Date getDataInclusaoRegistroDate() {
		return dataInclusaoRegistroDate;
	}

	public void setDataInclusaoRegistroDate(Date dataInclusaoRegistroDate) {
		this.dataInclusaoRegistroDate = dataInclusaoRegistroDate;
	}

	/**
	 * @return the indOfertaAssociada
	 */
	public String getIndOfertaAssociada() {
		return indOfertaAssociada;
	}

	/**
	 * @param indOfertaAssociada the indOfertaAssociada to set
	 */
	public void setIndOfertaAssociada(String indOfertaAssociada) {
		this.indOfertaAssociada = indOfertaAssociada;
	}

	/**
	 * @return the indAceiteOferta
	 */
	public String getIndAceiteOferta() {
		return indAceiteOferta;
	}

	/**
	 * @param indAceiteOferta the indAceiteOferta to set
	 */
	public void setIndAceiteOferta(String indAceiteOferta) {
		this.indAceiteOferta = indAceiteOferta;
	}

	/**
	 * @return the nivelOferta
	 */
	public String getNivelOferta() {
		return nivelOferta;
	}

	/**
	 * @param nivelOferta the nivelOferta to set
	 */
	public void setNivelOferta(String nivelOferta) {
		this.nivelOferta = nivelOferta;
	}

	/**
	 * @return the codigoOferta
	 */
	public String getCodigoOferta() {
		return codigoOferta;
	}

	/**
	 * @param codigoOferta the codigoOferta to set
	 */
	public void setCodigoOferta(String codigoOferta) {
		this.codigoOferta = codigoOferta;
	}

	public String getLoginUsuarioOperador() {
		return loginUsuarioOperador;
	}

	public void setLoginUsuarioOperador(String loginUsuarioOperador) {
		this.loginUsuarioOperador = loginUsuarioOperador;
	}

	/**
	 * @return the codigoOfertaCombo
	 */
	public String getCodigoOfertaCombo() {
		return codigoOfertaCombo;
	}

	/**
	 * @param codigoOfertaCombo the codigoOfertaCombo to set
	 */
	public void setCodigoOfertaCombo(String codigoOfertaCombo) {
		this.codigoOfertaCombo = codigoOfertaCombo;
	}

	public String getDataAtivacaoEc() {
		return dataAtivacaoEc;
	}

	public void setDataAtivacaoEc(String dataAtivacaoEc) {
		this.dataAtivacaoEc = dataAtivacaoEc;
	}

	/**
	 * @return the numEcCadeiaForcada
	 */
	public Long getNumEcCadeiaForcada() {
		return numEcCadeiaForcada;
	}

	/**
	 * @param numEcCadeiaForcada the numEcCadeiaForcada to set
	 */
	public void setNumEcCadeiaForcada(Long numEcCadeiaForcada) {
		this.numEcCadeiaForcada = numEcCadeiaForcada;
	}

	/**
	 * @return the numEcEspelho
	 */
	public Long getNumEcEspelho() {
		return numEcEspelho;
	}

	/**
	 * @param numEcEspelho the numEcEspelho to set
	 */
	public void setNumEcEspelho(Long numEcEspelho) {
		this.numEcEspelho = numEcEspelho;
	}

	/**
	 * @return the indEspelhamentoTaxa
	 */
	public String getIndEspelhamentoTaxa() {
		return indEspelhamentoTaxa;
	}

	/**
	 * @param indEspelhamentoTaxa the indEspelhamentoTaxa to set
	 */
	public void setIndEspelhamentoTaxa(String indEspelhamentoTaxa) {
		this.indEspelhamentoTaxa = indEspelhamentoTaxa;
	}

	/**
	 * @return the nomeExecutivo
	 */
	public String getNomeExecutivo() {
		return nomeExecutivo;
	}

	/**
	 * @param nomeExecutivo the nomeExecutivo to set
	 */
	public void setNomeExecutivo(String nomeExecutivo) {
		this.nomeExecutivo = nomeExecutivo;
	}

	/**
	 * @return the perfilSmart
	 */
	public String getPerfilSmart() {
		return perfilSmart;
	}

	/**
	 * @param perfilSmart the perfilSmart to set
	 */
	public void setPerfilSmart(String perfilSmart) {
		this.perfilSmart = perfilSmart;
	}

	/**
	 * @return the indEntregaMaquina
	 */
	public String getIndEntregaMaquina() {
		return indEntregaMaquina;
	}

	/**
	 * @param indEntregaMaquina the indEntregaMaquina to set
	 */
	public void setIndEntregaMaquina(String indEntregaMaquina) {
		this.indEntregaMaquina = indEntregaMaquina;
	}
	
	
}
