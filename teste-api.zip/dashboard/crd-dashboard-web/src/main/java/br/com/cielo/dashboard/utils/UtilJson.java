package br.com.cielo.dashboard.utils;

import java.io.IOException;

import org.codehaus.jackson.map.ObjectMapper;

public class UtilJson {	
    
    public static String writeAsString(Object o) throws IOException {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(o);
    }
}
