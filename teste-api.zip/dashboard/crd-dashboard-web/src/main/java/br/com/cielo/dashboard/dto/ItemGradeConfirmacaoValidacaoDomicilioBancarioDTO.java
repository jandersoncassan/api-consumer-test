package br.com.cielo.dashboard.dto;

import java.io.Serializable;

public class ItemGradeConfirmacaoValidacaoDomicilioBancarioDTO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String tipoManutencao;
	private String descricaoFerramenta;
	private String descricaoSolucaoCaptura;
	
	public String getTipoManutencao() {
		return tipoManutencao;
	}
	public void setTipoManutencao(String tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}
	public String getDescricaoFerramenta() {
		return descricaoFerramenta;
	}
	public void setDescricaoFerramenta(String descricaoFerramenta) {
		this.descricaoFerramenta = descricaoFerramenta;
	}
	public String getDescricaoSolucaoCaptura() {
		return descricaoSolucaoCaptura;
	}
	public void setDescricaoSolucaoCaptura(String descricaoSolucaoCaptura) {
		this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
	}

	
}
