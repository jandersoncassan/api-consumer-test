/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarBancosServiceRemote;
import br.com.cielo.dashboard.service.IConsultarBancosService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarBancosServiceImpl implements IConsultarBancosService{

	@Resource(mappedName="ConsultarBancosService#br.com.cielo.credenciamento.service.dashboard.ConsultarBancosServiceRemote")
	private ConsultarBancosServiceRemote consultarBancoServiceRemote;
	
	/**
	 * Método: Obter Lista dos bancos parametrizados
	 * @return
	 */
	public List<Object[]> getListarBancosDomiciliosParametrizados() {
		return consultarBancoServiceRemote.getListarBancosDomiciliosParametrizados();
	}

}
