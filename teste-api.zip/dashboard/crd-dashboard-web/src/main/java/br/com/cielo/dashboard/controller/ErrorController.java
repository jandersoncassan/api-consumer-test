package br.com.cielo.dashboard.controller;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.cielo.dashboard.navigation.NavigationDashBoard;

@Controller
public class ErrorController {
	
	private static final Logger LOG = LogManager.getLogger(ErrorController.class);
	
	@RequestMapping("/securityAccessDenied")
	public String securityAccessDenied(HttpSession session){
		
		LOG.debug("Acesso negado para o usuario: " + session.getAttribute("username"));
		
		return NavigationDashBoard.PAGE_ACCESS_DENIED;
	}
}
