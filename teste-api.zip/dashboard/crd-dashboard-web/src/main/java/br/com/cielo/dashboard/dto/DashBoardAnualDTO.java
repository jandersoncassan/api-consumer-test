/**
 * 
 */
package br.com.cielo.dashboard.dto;

import java.util.List;

import br.com.cielo.dashboard.model.Ferramenta;

/**
 * @author dcarneiro
 *
 */
public class DashBoardAnualDTO {
	
	private String dataReferenciaPesquisa;
	private List<Integer> ferramentaPesquisa;
	private List<Ferramenta> listaFerramentas;
	private List<String> listaAnos;
	
	/**
	 * @return the dataReferenciaPesquisa
	 */
	public String getDataReferenciaPesquisa() {
		return dataReferenciaPesquisa;
	}
	/**
	 * @param dataReferenciaPesquisa the dataReferenciaPesquisa to set
	 */
	public void setDataReferenciaPesquisa(String dataReferenciaPesquisa) {
		this.dataReferenciaPesquisa = dataReferenciaPesquisa;
	}
	public List<String> getListaAnos() {
		return listaAnos;
	}
	public void setListaAnos(List<String> listaAnos) {
		this.listaAnos = listaAnos;
	}
	public List<Ferramenta> getListaFerramentas() {
		return listaFerramentas;
	}
	public void setListaFerramentas(List<Ferramenta> listaFerramentas) {
		this.listaFerramentas = listaFerramentas;
	}
	public List<Integer> getFerramentaPesquisa() {
		return ferramentaPesquisa;
	}
	public void setFerramentaPesquisa(List<Integer> ferramentaPesquisa) {
		this.ferramentaPesquisa = ferramentaPesquisa;
	}
	
}
