package br.com.cielo.dashboard.service;

import java.util.List;
import java.util.Optional;

import br.com.cielo.credenciamento.dto.ParametrizacaoSolucaoCapturaPermitidaDTO;

public interface IParametrizacaoSolucoesCapturaPermitidasService {

	/**
	 * Método Método responsavel por obter a lista de soluções parametrizadas
	 * @param codigosFerramenta
	 * @param codigosSolucaoCaptura
	 * @param tipoStatus
	 * @return
	 */
	List<ParametrizacaoSolucaoCapturaPermitidaDTO> obterListaSolucoesCaptura(
			final Optional<List<Integer>> codigosSolucaoCaptura, final Optional<List<Integer>> codigosFerramenta);

	/**
	 * Método responsavel por efetivar as manutenções nas parametrizações
	 * @param obterListaSolucoesCaptura
	 * @param codigoUsuario
	 */
	void efetivarAlteracaoParametrizaocao(final List<ParametrizacaoSolucaoCapturaPermitidaDTO> obterListaSolucoesCaptura, final String codigoUsuario);

}
