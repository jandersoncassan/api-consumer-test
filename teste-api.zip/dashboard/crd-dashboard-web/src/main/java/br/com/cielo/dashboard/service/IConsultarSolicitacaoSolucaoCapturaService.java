/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarSolicitacaoSolucaoCapturaService {
	/**
	 * Método: Obtem lista de solucao de captura relacionadas a proposta
	 * @param proposta
	 * @return
	 */
	List<Object[]> getListarSolicitacaoSolucaoCapturaByProposta(final Long proposta);
}
