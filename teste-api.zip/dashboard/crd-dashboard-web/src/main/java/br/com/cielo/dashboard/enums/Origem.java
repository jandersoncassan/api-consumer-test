package br.com.cielo.dashboard.enums;

/**
 * Enum responsavel pela classificação das origens que utilizam a aplicação crd-web 'Central'
 * @author @Cielo
 * @since Release 05 - Feiras
 * @version 1.0.0
 */
public enum Origem {

	CENTRAL(4), SMART(7), FEIRAS(8);
	
	private Integer codigo;
	
	private Origem(Integer codigo){
		this.codigo = codigo;
	}
	
	public Integer getCodigo(){
		return codigo;
	}
}
