/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.FerramentaDTO;
import br.com.cielo.credenciamento.service.dashboard.FerramentaServiceRemote;
import br.com.cielo.dashboard.service.IFerramentaService;

/**
 * @author persona
 *
 */
@Service
public class FerramentaServiceImpl implements IFerramentaService{

	@Resource(mappedName="FerramentaService#br.com.cielo.credenciamento.service.dashboard.FerramentaServiceRemote")
	private FerramentaServiceRemote ferramentaServiceRemote;
	
	@Override
	public List<FerramentaDTO> getFerramentasPorIntervaloDeCodigo(int menor, int maior) {
		return ferramentaServiceRemote.getFerramentasPorIntervaloDeCodigo(menor, maior);
	}

}
