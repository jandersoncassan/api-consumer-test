package br.com.cielo.dashboard.dto;

import java.util.ArrayList;
import java.util.List;

public class ItensGridSolucaoCaptura {
	
	List<String> convencional = new ArrayList<>();
	List<String> controle = new ArrayList<>();
	List<String> mei = new ArrayList<>();
	List<String> pf = new ArrayList<>();
	List<String> pj = new ArrayList<>();
	List<String> entregaMaquina = new ArrayList<>();
	
	/**
	 * @return the convencional
	 */
	public List<String> getConvencional() {
		return convencional;
	}
	/**
	 * @param convencional the convencional to set
	 */
	public void setConvencional(List<String> convencional) {
		this.convencional = convencional;
	}
	/**
	 * @return the controle
	 */
	public List<String> getControle() {
		return controle;
	}
	/**
	 * @param controle the controle to set
	 */
	public void setControle(List<String> controle) {
		this.controle = controle;
	}
	/**
	 * @return the mei
	 */
	public List<String> getMei() {
		return mei;
	}
	/**
	 * @param mei the mei to set
	 */
	public void setMei(List<String> mei) {
		this.mei = mei;
	}
	/**
	 * @return the pf
	 */
	public List<String> getPf() {
		return pf;
	}
	/**
	 * @param pf the pf to set
	 */
	public void setPf(List<String> pf) {
		this.pf = pf;
	}
	/**
	 * @return the pj
	 */
	public List<String> getPj() {
		return pj;
	}
	/**
	 * @param pj the pj to set
	 */
	public void setPj(List<String> pj) {
		this.pj = pj;
	}
	/**
	 * @return the entregaMaquina
	 */
	public List<String> getEntregaMaquina() {
		return entregaMaquina;
	}
	/**
	 * @param entregaMaquina the entregaMaquina to set
	 */
	public void setEntregaMaquina(List<String> entregaMaquina) {
		this.entregaMaquina = entregaMaquina;
	}

	
	
	
/*	List<ItemGridSolucaoCaptura> planoConvencional;
	List<ItemGridSolucaoCaptura> planoControle;
	List<ItemGridSolucaoCaptura> indicadorMei;
	List<ItemGridSolucaoCaptura> tipoPessoaFisica;
	List<ItemGridSolucaoCaptura> tipoPessoaJuridica;
	List<ItemGridSolucaoCaptura> entregaMaquina;
	*//**
	 * @return the planoConvencional
	 *//*
	public List<ItemGridSolucaoCaptura> getPlanoConvencional() {
		return planoConvencional;
	}
	*//**
	 * @param planoConvencional the planoConvencional to set
	 *//*
	public void setPlanoConvencional(List<ItemGridSolucaoCaptura> planoConvencional) {
		this.planoConvencional = planoConvencional;
	}
	*//**
	 * @return the planoControle
	 *//*
	public List<ItemGridSolucaoCaptura> getPlanoControle() {
		return planoControle;
	}
	*//**
	 * @param planoControle the planoControle to set
	 *//*
	public void setPlanoControle(List<ItemGridSolucaoCaptura> planoControle) {
		this.planoControle = planoControle;
	}
	*//**
	 * @return the indicadorMei
	 *//*
	public List<ItemGridSolucaoCaptura> getIndicadorMei() {
		return indicadorMei;
	}
	*//**
	 * @param indicadorMei the indicadorMei to set
	 *//*
	public void setIndicadorMei(List<ItemGridSolucaoCaptura> indicadorMei) {
		this.indicadorMei = indicadorMei;
	}
	*//**
	 * @return the tipoPessoaFisica
	 *//*
	public List<ItemGridSolucaoCaptura> getTipoPessoaFisica() {
		return tipoPessoaFisica;
	}
	*//**
	 * @param tipoPessoaFisica the tipoPessoaFisica to set
	 *//*
	public void setTipoPessoaFisica(List<ItemGridSolucaoCaptura> tipoPessoaFisica) {
		this.tipoPessoaFisica = tipoPessoaFisica;
	}
	*//**
	 * @return the tipoPessoaJuridica
	 *//*
	public List<ItemGridSolucaoCaptura> getTipoPessoaJuridica() {
		return tipoPessoaJuridica;
	}
	*//**
	 * @param tipoPessoaJuridica the tipoPessoaJuridica to set
	 *//*
	public void setTipoPessoaJuridica(List<ItemGridSolucaoCaptura> tipoPessoaJuridica) {
		this.tipoPessoaJuridica = tipoPessoaJuridica;
	}
	*//**
	 * @return the entregaMaquina
	 *//*
	public List<ItemGridSolucaoCaptura> getEntregaMaquina() {
		return entregaMaquina;
	}
	*//**
	 * @param entregaMaquina the entregaMaquina to set
	 *//*
	public void setEntregaMaquina(List<ItemGridSolucaoCaptura> entregaMaquina) {
		this.entregaMaquina = entregaMaquina;
	}
*/	

}
