/**
 * 
 */
package br.com.cielo.dashboard.model;

import java.io.Serializable;

/**
 * @author dcarneiro
 *
 */
public class TotalizadorRemessasPrincipal implements Serializable{

	private static final long serialVersionUID = 1L;
	
	private Integer totalRegistros;
	private Integer totalRegistrosProcessados;
	private Integer totalRegistrosRejeitados;
	/**
	 * @return the totalRegistros
	 */
	public Integer getTotalRegistros() {
		return totalRegistros;
	}
	/**
	 * @param totalRegistros the totalRegistros to set
	 */
	public void setTotalRegistros(Integer totalRegistros) {
		this.totalRegistros = totalRegistros;
	}
	/**
	 * @return the totalRegistrosProcessados
	 */
	public Integer getTotalRegistrosProcessados() {
		return totalRegistrosProcessados;
	}
	/**
	 * @param totalRegistrosProcessados the totalRegistrosProcessados to set
	 */
	public void setTotalRegistrosProcessados(Integer totalRegistrosProcessados) {
		this.totalRegistrosProcessados = totalRegistrosProcessados;
	}
	/**
	 * @return the totalRegistrosRejeitados
	 */
	public Integer getTotalRegistrosRejeitados() {
		return totalRegistrosRejeitados;
	}
	/**
	 * @param totalRegistrosRejeitados the totalRegistrosRejeitados to set
	 */
	public void setTotalRegistrosRejeitados(Integer totalRegistrosRejeitados) {
		this.totalRegistrosRejeitados = totalRegistrosRejeitados;
	}
	
	
	
}
