/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarStatusService {
	/**
	 * Método: Obtem os status de acordo com a etapa selecionada
	 * @param codigoEtapa
	 * @return
	 */
	List<Object>getListaStatus();
}
