/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface ICardsService {
	 /**
     * M�todo respons�vel por retornar as informa��es dos Cards
     * Quantidade de proposta no m�s corrente
     * Quantidade de instala��es no m�s corrente
     * Quantidade de ativa��es no m�s corrente
     * @return
     */
	List<Object> getCardsPrincipal(final String dataParaPesquisa);
}
