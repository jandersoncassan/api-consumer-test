/**
 * 
 */
package br.com.cielo.dashboard.controller;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.dashboard.dto.ConsultarRemessasDTO;
import br.com.cielo.dashboard.model.Bancos;
import br.com.cielo.dashboard.model.RemessasProcessadas;
import br.com.cielo.dashboard.model.TotalizadorRemessasPrincipal;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IConsultarBancosService;
import br.com.cielo.dashboard.service.IConsultarRemessasProcessadasService;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author Cielo S/A
 *
 */
@Controller
@Scope(value=WebApplicationContext.SCOPE_REQUEST)
public class ConsultarRemessasController {

	private static final Logger LOG = LogManager.getLogger(ConsultarRemessasController.class);

	@Autowired
	private IConsultarRemessasProcessadasService consultarRemessasProcessadasService;
	
	@Autowired
	private IConsultarBancosService consultarBancosService;

	private Integer totalRegistros;
	private Integer totalRejeitados;
	private Integer totalProcessados;

	
	@RequestMapping("/initRemessas")
	@Secured(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA)
	public String init(HttpSession session, Model model) {
		ConsultarRemessasDTO consultar = new ConsultarRemessasDTO();
		DashboardUtils.removerAllAtributosSession(session);
		getConsultarBancos(model, session);
		model.addAttribute("consulta_remessas",consultar);
		LOG.info("INICIANDO A CONSULTA DE REMESSAS");
		return NavigationDashBoard.CONSULTAR_REMESSA;
	}

	@RequestMapping("/consultarListaRemessas")
	@Secured(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA)
	public String consultar(
			@ModelAttribute("consulta_remessas") @Valid ConsultarRemessasDTO rejeitados,
			BindingResult bindingResult, HttpSession session, Model model) throws ParseException {

		this.inicializacao();
		LOG.info("INICIANDO CONSULTAR REMESSAS");
		session.removeAttribute("lista_consulta_remessa");
		model.addAttribute("listaBancos", session.getAttribute("listaBancos"));
		List<RemessasProcessadas> list = getConsultarRemessasCrd(rejeitados);
		model.addAttribute("list", list);
		/*Atributo de sessao para toggle*/
		session.setAttribute("lista_consulta_remessa", list);
		model.addAttribute("totalizador",
				totalizador(this.getTotalRejeitados(), this.getTotalProcessados(), this.getTotalRegistros()));
		return NavigationDashBoard.CONSULTAR_REMESSA;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/exportRelatorio")
	@Secured(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR)
	public void exportRelatorio(@ModelAttribute("consulta_remessas") @Valid ConsultarRemessasDTO rejeitados,
			BindingResult bindingResult, HttpSession session, Model model, HttpServletResponse response) throws Exception {
		
		XSSFWorkbook wb = new XSSFWorkbook();
		String[] hearders = new String[] { "BANCO", "REMESSA", "DATA MOVIMENTO", "DATA ALTERAÇÃO", "STATUS DA REMESSA",
				"TOTAL DE REGISTROS", "TOTAL DE PROCESSADOS", "TOTAL DE REJEITADOS" };
		try {
			List<RemessasProcessadas> object = (List<RemessasProcessadas>) session
					.getAttribute("lista_consulta_remessa");
			XSSFSheet sheet = wb.createSheet();
			XSSFRow row = sheet.createRow(0);
			/* create style */
			XSSFCellStyle style = wb.createCellStyle();
			XSSFFont font = wb.createFont();
			font.setBold(Boolean.TRUE);
			font.setFontHeightInPoints((short) 12);
			style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setFont(font);
			for (int i = 0; i < hearders.length; i++) {
				XSSFCell cell = row.createCell(i);
				cell.setCellValue(hearders[i]);
				cell.setCellStyle(style);
				sheet.setColumnWidth(i, i==0 ||i==1?2500:6000);
			}
			
			/*
			 * Formato de data
			 */
			XSSFCellStyle cellStyleData1 = wb.createCellStyle();
			XSSFCellStyle cellStyleData2 = wb.createCellStyle();
			XSSFCreationHelper createHelper = wb.getCreationHelper();
			cellStyleData1.setDataFormat(createHelper.createDataFormat().getFormat("dd/MM/yyyy"));
			cellStyleData2.setDataFormat(createHelper.createDataFormat().getFormat("dd/MM/yyyy hh:mm"));
			
			for (int i = 0; i < object.size(); i++) {
				XSSFRow rowConteudo = sheet.createRow(i + 1);
				rowConteudo.createCell((int) 0).setCellValue(object.get(i).getBancoOrigemDescricao());
				
				rowConteudo.createCell((int) 1).setCellValue(object.get(i).getNumeroRemessa());
				
				XSSFCell cellDataMovimento = rowConteudo.createCell((int) 2);
				cellDataMovimento.setCellValue(object.get(i).getDataMovimento());
				cellDataMovimento.setCellStyle(cellStyleData1);
				
				XSSFCell cellDataAlteracao = rowConteudo.createCell((int) 3);
				cellDataAlteracao.setCellValue(object.get(i).getDataAlteracao());
				cellDataAlteracao.setCellStyle(cellStyleData2);
				
				rowConteudo.createCell((int) 4).setCellValue(object.get(i).getStatusRemessa());
				
				rowConteudo.createCell((int) 5).setCellValue(object.get(i).getTotalRegistros());
				
				rowConteudo.createCell((int) 6).setCellValue(object.get(i).getTotalRegistrosProcessados());
				
				rowConteudo.createCell((int) 7).setCellValue(object.get(i).getTotalRegistrosRejeitados());
			}
			// write it as an excel attachment
			DashboardUtils.contentTypeForBrowser(response, wb, "RELATORIO_REMESSAS");
		} catch (Exception e) {
			LOG.error("ERRO AO GERAR RELATORIO DE REMESSAS");
			throw e;
		}
	}

	/**
	 * 
	 * @param model
	 * @param session
	 */
	private void getConsultarBancos(Model model, HttpSession session) {
		List<Object[]> retorno = consultarBancosService.getListarBancosDomiciliosParametrizados();
		List<Bancos> listaBancos = new ArrayList<Bancos>();
		for (int i = 0; i < retorno.size(); i++) {
			Object[] obj = (Object[]) retorno.get(i);
			Bancos et = new Bancos();
			et.setCodigoBanco(Integer.parseInt(String.valueOf(obj[0])));
			et.setDescricaoBanco(String.valueOf(obj[1]));
			listaBancos.add(et);
		}
		session.setAttribute("listaBancos", listaBancos);
		model.addAttribute("listaBancos", listaBancos);
	}
	/**
	 * 
	 * @param rejeitados
	 * @return
	 * @throws ParseException
	 */
	public List<RemessasProcessadas> getConsultarRemessasCrd(ConsultarRemessasDTO rejeitados)
			throws ParseException {
		List<RemessasProcessadas> listRemessas = new ArrayList<RemessasProcessadas>();
		LOG.info("REALIZANDO CONSULTAS DAS REMESSAS");
		

		String dataInicio = DashboardUtils.isNotNullOrEmpty(
				rejeitados.getPeriodoInicial())?rejeitados.getPeriodoInicial().split("to")[0]:
				DashboardUtils.EMPTY;
		
		String dataFim = DashboardUtils.isNotNullOrEmpty(
				rejeitados.getPeriodoInicial())?rejeitados.getPeriodoInicial().split("to")[1]:
				DashboardUtils.EMPTY;
		
		List<Object> retorno = consultarRemessasProcessadasService.getConsultarRemessasProcessadas(
				rejeitados.getBancos().getCodigoBanco(), rejeitados.getCodigoStatus(), 
				dataInicio, dataFim);

		for (Object object : retorno) {
			Object[] obj = (Object[]) object;
			RemessasProcessadas remessas = new RemessasProcessadas();
			remessas.setBancoOrigem(String.valueOf(obj[0]));
			remessas.setBancoOrigemDescricao(String.valueOf(obj[8]));
			remessas.setNumeroRemessa(Integer.parseInt(String.valueOf(obj[2])));				
			if(DashboardUtils.isNotNullOrEmpty(obj[1])){
				Date dataMovimentoDate = (Date) obj[1];
				remessas.setDataMovimentoDate(dataMovimentoDate);
				remessas.setDataMovimento(DashboardUtils.convertDateToString(String.valueOf(obj[1])));				
			}
			remessas.setTotalRegistros(Integer.parseInt(String.valueOf(obj[3])));
			remessas.setTotalRegistrosProcessados(Integer.parseInt(String.valueOf(obj[4])));
			remessas.setTotalRegistrosRejeitados(Integer.parseInt(String.valueOf(obj[5])));
			remessas.setStatusRemessa(String.valueOf(obj[6]));
			if(DashboardUtils.isNotNullOrEmpty(obj[7])){
				Date dataDataAlteracaoDate = (Date) obj[7];
				remessas.setDataAlteracaoDate(dataDataAlteracaoDate);
				remessas.setDataAlteracao(DashboardUtils.convertStringToDate(String.valueOf(obj[7])));				
			}
			listRemessas.add(remessas);
			totalRegistros += Integer.parseInt(String.valueOf(obj[3]));
			totalProcessados += Integer.parseInt(String.valueOf(obj[4]));
			totalRejeitados += Integer.parseInt(String.valueOf(obj[5]));
		}
		return listRemessas;
	}
	/**
	 * 
	 * @param totalRejeitados
	 * @param totalProcessados
	 * @param totalRegistros
	 * @return
	 */
	public TotalizadorRemessasPrincipal totalizador(Integer totalRejeitados, Integer totalProcessados,
			Integer totalRegistros) {
		TotalizadorRemessasPrincipal totalizados = new TotalizadorRemessasPrincipal();
		totalizados.setTotalRegistros(totalRegistros);
		totalizados.setTotalRegistrosProcessados(totalProcessados);
		totalizados.setTotalRegistrosRejeitados(totalRejeitados);
		return totalizados;
	}
	/**
	 * Init
	 */
	private void inicializacao() {
		this.setTotalRegistros(0);
		this.setTotalRejeitados(0);
		this.setTotalProcessados(0);
	}

	/**
	 * @return the totalRegistros
	 */
	public Integer getTotalRegistros() {
		return totalRegistros;
	}

	/**
	 * @param totalRegistros
	 *            the totalRegistros to set
	 */
	public void setTotalRegistros(Integer totalRegistros) {
		this.totalRegistros = totalRegistros;
	}

	/**
	 * @return the totalRejeitados
	 */
	public Integer getTotalRejeitados() {
		return totalRejeitados;
	}

	/**
	 * @param totalRejeitados
	 *            the totalRejeitados to set
	 */
	public void setTotalRejeitados(Integer totalRejeitados) {
		this.totalRejeitados = totalRejeitados;
	}

	/**
	 * @return the totalProcessados
	 */
	public Integer getTotalProcessados() {
		return totalProcessados;
	}

	/**
	 * @param totalProcessados
	 *            the totalProcessados to set
	 */
	public void setTotalProcessados(Integer totalProcessados) {
		this.totalProcessados = totalProcessados;
	}

}
