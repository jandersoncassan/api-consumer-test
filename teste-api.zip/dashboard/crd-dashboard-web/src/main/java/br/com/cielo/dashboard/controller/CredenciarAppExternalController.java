package br.com.cielo.dashboard.controller;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.cielo.dashboard.enums.Origem;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;

@Controller
public class CredenciarAppExternalController {

	private static final Logger LOG = LogManager.getLogger(CredenciarAppExternalController.class);

	@RequestMapping("/credenciarCentral")
	@Secured(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL)
	public String getPageCentral(HttpSession session){
		LOG.info("INIT PAGE CENTRAL");
		popularOrigem(session, Origem.CENTRAL.getCodigo());
		return getPageCredenciamento();
	}
	
	@RequestMapping("/credenciarFeiras")
	@Secured(SecurityRole.ROLE_CRD_CREDENCIAMENTO_FEIRA)
	public String getPageFeiras(HttpSession session){
		LOG.info("INIT PAGE FEIRAS");
		popularOrigem(session, Origem.FEIRAS.getCodigo());
		return getPageCredenciamento();
	}

	@RequestMapping("/credenciarSmart")
	@Secured(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART)
	public String getPageSmart(HttpSession session, Authentication auth){
		LOG.info("INIT PAGE SMART");
		session.setAttribute("perfilSmart", getDominioPerfilSmart(auth));
		popularOrigem(session, Origem.SMART.getCodigo());
		return getPageCredenciamento();
	}

	@RequestMapping("/credenciarSimulador")
	@Secured(SecurityRole.ROLE_CRD_SIMULADOR)
	public String getPageSimulador(){
		LOG.info("INIT PAGE SIMULADOR");
		return NavigationDashBoard.PAGE_FRAME_SIMULADOR;
	}

	/**
	 * Método responsavel por popular a origem da chamada APP Central
	 * @param session
	 * @param codigo
	 */
	private void popularOrigem(HttpSession session, Integer origem) {
		session.setAttribute("origem", origem);		
	}
	
	/**
	 * Método responsavel por obter o perfil do usuário smart
	 * @param authentication
	 * @return
	 */
	private Integer getDominioPerfilSmart(Authentication authentication){
		return SecurityRole.getDominioPerfilUsuarioSmart(authentication);
	}
	
	/**
	 * Método responsavel por retornar a página de credenciamento
	 * @return
	 */
	private String getPageCredenciamento(){
		return NavigationDashBoard.PAGE_FRAME_CENTRAL;
	}
	
}
