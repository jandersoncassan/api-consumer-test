/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarPropostaServiceRemote;
import br.com.cielo.dashboard.service.IConsultarPropostaService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarPropostaServiceImpl implements IConsultarPropostaService {

	@Resource(mappedName = "ConsultarPropostaService#br.com.cielo.credenciamento.service.dashboard.ConsultarPropostaServiceRemote")
	private ConsultarPropostaServiceRemote consultarPropostaServiceRemote;

	@Override
	public Object[] getProposta(Long proposta, Long estabelecimentoComercial, Integer codigoAfiliador, Integer[] etapa,
			Integer[] status, String periodoInicial, String periodoFinal, Boolean isSmart, Optional<Integer> codPerfilSmart) {

		return consultarPropostaServiceRemote.getProposta(proposta, estabelecimentoComercial, codigoAfiliador, etapa,
				status, periodoInicial, periodoFinal, isSmart, codPerfilSmart);
	}

	@Override
	public List<Object[]> getPropostaAllFilter(Integer[] ferramenta, Integer[] bancos, Integer[] solucaoCapturas,Integer codigoAfiliador, 
			String motivoCancelamento, String criticaEtapa, Integer[] etapas,Integer[] statusEtapas, String periodoInicial, 
			String periodoFinal, final Integer[] situacaoProposta,final String cpfCnpj, final String codigoOferta, Boolean isSmart, 
			Optional<Integer> codPerfilSmart, final Optional<String> indEntregaMaquina) {

		return consultarPropostaServiceRemote.getPropostaAllFilter(ferramenta, bancos, solucaoCapturas, codigoAfiliador,
				motivoCancelamento, criticaEtapa, etapas, statusEtapas, periodoInicial, periodoFinal, situacaoProposta,
				cpfCnpj, codigoOferta, isSmart, codPerfilSmart, indEntregaMaquina);
	}
	

}

