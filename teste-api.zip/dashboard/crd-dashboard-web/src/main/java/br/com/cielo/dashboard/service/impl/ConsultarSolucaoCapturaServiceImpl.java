/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarSolucaoCapturaServiceRemote;
import br.com.cielo.dashboard.service.IConsultarSolucaoCapturaService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarSolucaoCapturaServiceImpl implements IConsultarSolucaoCapturaService{
	
	@Resource(mappedName ="ConsultarSolucaoCapturaService#br.com.cielo.credenciamento.service.dashboard.ConsultarSolucaoCapturaServiceRemote")
	private ConsultarSolucaoCapturaServiceRemote consultarSolucaoCapturaServiceRemote;
	/**
	 * @param proposta
	 * @return
	 */
	public List<Object[]> getListarSolucaoCapturaByProposta(Long proposta) {
		return consultarSolucaoCapturaServiceRemote.getListaSolucaoCapturaByProposta(proposta);
	}

}
