package br.com.cielo.dashboard.model;

/**
 * Classe responsavel por representar as informações de descontos na oferta
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 *
 */
public class DescontosOfertas {

	private String tipo;
	private String valorOriginal;
	private String valorComDesconto;
	private String valorDesconto;
	private String percentualDesconto;
	/**
	 * @return the tipo
	 */
	public String getTipo() {
		return tipo;
	}
	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	/**
	 * @return the valorOriginal
	 */
	public String getValorOriginal() {
		return valorOriginal;
	}
	/**
	 * @param valorOriginal the valorOriginal to set
	 */
	public void setValorOriginal(String valorOriginal) {
		this.valorOriginal = valorOriginal;
	}
	/**
	 * @return the valorComDesconto
	 */
	public String getValorComDesconto() {
		return valorComDesconto;
	}
	/**
	 * @param valorComDesconto the valorComDesconto to set
	 */
	public void setValorComDesconto(String valorComDesconto) {
		this.valorComDesconto = valorComDesconto;
	}
	/**
	 * @return the valorDesconto
	 */
	public String getValorDesconto() {
		return valorDesconto;
	}
	/**
	 * @param valorDesconto the valorDesconto to set
	 */
	public void setValorDesconto(String valorDesconto) {
		this.valorDesconto = valorDesconto;
	}
	/**
	 * @return the percentualDesconto
	 */
	public String getPercentualDesconto() {
		return percentualDesconto;
	}
	/**
	 * @param percentualDesconto the percentualDesconto to set
	 */
	public void setPercentualDesconto(String percentualDesconto) {
		this.percentualDesconto = percentualDesconto;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "DescontosOfertas [tipo=" + tipo + ", valorOriginal=" + valorOriginal + ", valorComDesconto="
				+ valorComDesconto + ", valorDesconto=" + valorDesconto + ", percentualDesconto=" + percentualDesconto
				+ "]";
	}
	
	
	
	
}
