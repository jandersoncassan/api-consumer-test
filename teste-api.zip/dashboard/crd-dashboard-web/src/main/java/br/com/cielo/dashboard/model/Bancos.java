/**
 * 
 */
package br.com.cielo.dashboard.model;

import java.io.Serializable;

/**
 * @author dcarneiro
 *
 */
public class Bancos implements Serializable {

	private static final long serialVersionUID = 1L;
	//@NotNull(message="{campo.banco}")
	private Integer codigoBanco;
	private String descricaoBanco;
	private Integer quantidade;

	/**
	 * @return the codigoBanco
	 */
	public Integer getCodigoBanco() {
		return codigoBanco;
	}
	/**
	 * @param codigoBanco the codigoBanco to set
	 */
	public void setCodigoBanco(Integer codigoBanco) {
		this.codigoBanco = codigoBanco;
	}
	/**
	 * @return the descricaoBanco
	 */
	public String getDescricaoBanco() {
		return descricaoBanco;
	}
	/**
	 * @param descricaoBanco the descricaoBanco to set
	 */
	public void setDescricaoBanco(String descricaoBanco) {
		this.descricaoBanco = descricaoBanco;
	}
	/**
	 * @return the quantidade
	 */
	public Integer getQuantidade() {
		return quantidade;
	}
	/**
	 * @param quantidade the quantidade to set
	 */
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}

	
}
