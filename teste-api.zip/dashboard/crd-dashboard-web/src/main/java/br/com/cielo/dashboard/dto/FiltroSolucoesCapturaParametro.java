package br.com.cielo.dashboard.dto;

import java.util.List;

/**
 * Classe DTO representado o filtro de pesquisa da tela de parametrização solução de captura
 * @author @Cielo SA
 * @since Release 05 - Sprint 02
 * @version 1.0.0
 */
public class FiltroSolucoesCapturaParametro {
	
	private List<Integer> codigosSolucaoCaptura;
	private List<Integer> codigosFerramenta;
	private Integer tipoStatus;
	
	/**
	 * @return the codigosSolucaoCaptura
	 */
	public List<Integer> getCodigosSolucaoCaptura() {
		return codigosSolucaoCaptura;
	}
	/**
	 * @param codigosSolucaoCaptura the codigosSolucaoCaptura to set
	 */
	public void setCodigosSolucaoCaptura(List<Integer> codigosSolucaoCaptura) {
		this.codigosSolucaoCaptura = codigosSolucaoCaptura;
	}
	/**
	 * @return the codigosFerramenta
	 */
	public List<Integer> getCodigosFerramenta() {
		return codigosFerramenta;
	}
	/**
	 * @param codigosFerramenta the codigosFerramenta to set
	 */
	public void setCodigosFerramenta(List<Integer> codigosFerramenta) {
		this.codigosFerramenta = codigosFerramenta;
	}
	/**
	 * @return the tipoStatus
	 */
	public Integer getTipoStatus() {
		return tipoStatus;
	}
	/**
	 * @param tipoStatus the tipoStatus to set
	 */
	public void setTipoStatus(Integer tipoStatus) {
		this.tipoStatus = tipoStatus;
	}
	
	
	
}
