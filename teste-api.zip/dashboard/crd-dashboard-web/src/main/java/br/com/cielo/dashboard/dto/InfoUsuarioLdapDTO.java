package br.com.cielo.dashboard.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class InfoUsuarioLdapDTO implements Serializable{

    private static final long serialVersionUID = 1L;
    private String dn;
    private String loginDisabled;
    private String employeeStatus;
    private String[] grupos;
    private String userName;
    private String senhaBasica;
    private String lockedByIntruder;
    private String login;
    private String[] dirXMLEntitlementRef;
    private List<String> listaRoles = new ArrayList<String>();
    
	/**
	 * @return the dn
	 */
	public String getDn() {
		return dn;
	}

	/**
	 * @param dn the dn to set
	 */
	public void setDn(String dn) {
		this.dn = dn;
	}

	/**
	 * @return the loginDisabled
	 */
	public String getLoginDisabled() {
		return loginDisabled;
	}

	/**
	 * @param loginDisabled the loginDisabled to set
	 */
	public void setLoginDisabled(String loginDisabled) {
		this.loginDisabled = loginDisabled;
	}

	/**
	 * @return the employeeStatus
	 */
	public String getEmployeeStatus() {
		return employeeStatus;
	}

	/**
	 * @param employeeStatus the employeeStatus to set
	 */
	public void setEmployeeStatus(String employeeStatus) {
		this.employeeStatus = employeeStatus;
	}

	/**
	 * @return the grupos
	 */
	public String[] getGrupos() {
		return grupos;
	}

	/**
	 * @param grupos the grupos to set
	 */
	public void setGrupos(String[] grupos) {
		this.grupos = grupos;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the senhaBasica
	 */
	public String getSenhaBasica() {
		return senhaBasica;
	}

	/**
	 * @param senhaBasica the senhaBasica to set
	 */
	public void setSenhaBasica(String senhaBasica) {
		this.senhaBasica = senhaBasica;
	}

	/**
	 * @return the lockedByIntruder
	 */
	public String getLockedByIntruder() {
		return lockedByIntruder;
	}

	/**
	 * @param lockedByIntruder the lockedByIntruder to set
	 */
	public void setLockedByIntruder(String lockedByIntruder) {
		this.lockedByIntruder = lockedByIntruder;
	}

	/**
	 * @return the login
	 */
	public String getLogin() {
		return login;
	}

	/**
	 * @param login the login to set
	 */
	public void setLogin(String login) {
		this.login = login;
	}

	public String[] getDirXMLEntitlementRef() {
		return dirXMLEntitlementRef;
	}

	public void setDirXMLEntitlementRef(String[] dirXMLEntitlementRef) {
		this.dirXMLEntitlementRef = dirXMLEntitlementRef;
	}

	public List<String> getListaRoles() {
		return listaRoles;
	}

	public void setListaRoles(List<String> listaRoles) {
		this.listaRoles = listaRoles;
	}
	
	public void addRole(String role) {
		this.listaRoles.add(role);
	}
	
	public boolean removeRole(String role) {
		return this.listaRoles.remove(role);
	}
	
	public boolean findRole(String role) {
		return this.listaRoles.contains(role);
	}
	
}
