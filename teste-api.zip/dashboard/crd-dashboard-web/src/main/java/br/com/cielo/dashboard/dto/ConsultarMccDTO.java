package br.com.cielo.dashboard.dto;

import java.util.ArrayList;
import java.util.List;

import br.com.cielo.dashboard.model.Ferramenta;

public class ConsultarMccDTO {
	
	private List<Integer> codigosMcc;
	private List<Integer> codigosFerramenta;
	private List<String> codigosTipoPessoa;
	private Integer filtroAtivo;
	
	public ConsultarMccDTO() {
		this.codigosMcc = new ArrayList<Integer>();
		this.codigosFerramenta = new ArrayList<Integer>();
		this.codigosTipoPessoa = new ArrayList<String>();
		this.codigosTipoPessoa.add("J");
		this.codigosTipoPessoa.add("F");
	}
	
	
	public List<Integer> getCodigosFerramenta(){
		return this.codigosFerramenta;
	}
	
	public void setCodigosFerramenta(List<Integer> value){
		this.codigosFerramenta = value;
	}

	public List<Integer> getCodigosMcc() {
		return codigosMcc;
	}

	public void setCodigosMcc(List<Integer> codigosMcc) {
		this.codigosMcc = codigosMcc;
	}

	public List<String> getCodigosTipoPessoa() {
		return codigosTipoPessoa;
	}

	public void setCodigosTipoPessoa(List<String> codigosTipoPessoa) {
		this.codigosTipoPessoa = codigosTipoPessoa;
	}


	public Integer getFiltroAtivo() {
		return filtroAtivo;
	}


	public void setFiltroAtivo(Integer filtroAtivo) {
		this.filtroAtivo = filtroAtivo;
	}
		
}
