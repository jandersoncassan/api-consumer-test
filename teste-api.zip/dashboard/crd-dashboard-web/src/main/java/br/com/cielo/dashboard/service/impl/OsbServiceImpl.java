package br.com.cielo.dashboard.service.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType;
import br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType;
import br.com.cielo.dashboard.model.ConsultaOfertas;
import br.com.cielo.dashboard.service.IOsbService;
import br.com.cielo.dashboard.utils.DashboardFile;
import br.com.cielo.dashboard.utils.DashboardUtils;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertasRequestType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertasResponseType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertas_PortType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertas_Service;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertas_ServiceLocator;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOferta;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaRequestType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaResponseType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaSOAPQSService;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaSOAPQSServiceLocator;

/**
 * Classe responsavel pela implementação dos serviços SOAP OSB
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 */
@Service
public class OsbServiceImpl implements IOsbService {

	private static final Logger LOG = LogManager.getLogger(OsbServiceImpl.class);

	public CieloSoapHeaderType getHeader() {
		UsuarioType userWS = new UsuarioType();
		userWS.setId(getMessage(DashboardUtils.USER));
		userWS.setSenha(getMessage(DashboardUtils.PASSWORD));
		CieloSoapHeaderType header = new CieloSoapHeaderType();
		header.setUsuario(userWS);
		return header;
	}

	/**
	 * Consulta ofertas cadastradas no Interact
	 */
	@Override
	public ConsultarOfertaResponseType consultarOfertasInteract(ConsultaOfertas infoOfertas) throws MalformedURLException, ServiceException, RemoteException {
		
		LOG.info("INICIO CHAMADA SERVICO CONSULTA OFERTAS INTERACT");
		ConsultarOfertaSOAPQSService ws = new ConsultarOfertaSOAPQSServiceLocator();

		ConsultarOfertaRequestType request = new ConsultarOfertaRequestType();

		request.setCpfCnpj(Long.valueOf(infoOfertas.getCpfCnpj()));
		request.setCodigoNivel(infoOfertas.getCodigoNivel());
		request.setQtdOfertas(infoOfertas.getQtdadeOfertas());
		request.setCodigoSessao("LT02");

		DashboardUtils.deflate("CONSULTAR OFERTAS INTERACT REQUEST", request);
		ConsultarOferta service = ws.getConsultarOfertaSOAPQSPort(new URL(getMessage(DashboardUtils.ENDPOINT_CONSULTAR_OFERTAS_INTERACT)));

		ConsultarOfertaResponseType response = service.consultarOferta(getHeader(), request);
		DashboardUtils.deflate("CONSULTAR OFERTAS INTERACT RESPONSE", response);

		return response;
	}

	/**
	 * Consulta lista d eofertas cadastradas (dominios)
	 */
	@Override
	public ConsultarListaOfertasResponseType consultarListaOfertas() throws MalformedURLException, ServiceException, RemoteException {
		ConsultarListaOfertas_Service ws = new ConsultarListaOfertas_ServiceLocator();
		ConsultarListaOfertasRequestType request = new ConsultarListaOfertasRequestType();
		
		ConsultarListaOfertas_PortType service = ws.getConsultarListaOfertasSOAP(new URL(getMessage(DashboardUtils.ENDPOINT_CONSULTAR_LISTA_OFERTAS)));
	
		ConsultarListaOfertasResponseType response = service.consultarListaOfertas(getHeader(), request);
		DashboardUtils.deflate("CONSULTAR LISTA DE OFERTAS RESPONSE", response);
		
		return response;
	}

	/**
	 * Método responsavel por obter as informações no arquivo de propriedades
	 * 
	 * @param key
	 * @return
	 */
	private String getMessage(String key) {
		return DashboardFile.getInstance().getMessageExternal(key);
	}


}
