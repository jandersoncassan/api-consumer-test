package br.com.cielo.dashboard.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.ParametrizacaoSolucaoCapturaPermitidaDTO;
import br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoSolucaoCapturaServiceRemote;
import br.com.cielo.dashboard.service.IParametrizacaoSolucoesCapturaPermitidasService;

@Service
public class ParametrizacaoSolucaoCapturaPermitidaService implements IParametrizacaoSolucoesCapturaPermitidasService {
	
	private static final Integer INCLUSAO = 1;
	private static final Integer EXCLUSAO = 2;

	@Resource(mappedName = "ParametrizacaoSolucaoCapturaService#br.com.cielo.credenciamento.service.parametrizacao.ParametrizacaoSolucaoCapturaServiceRemote")
	private ParametrizacaoSolucaoCapturaServiceRemote solucaoCapturaServiceRemote;

	@Override
	public List<ParametrizacaoSolucaoCapturaPermitidaDTO> obterListaSolucoesCaptura(Optional<List<Integer>> codigosSolucaoCaptura, Optional<List<Integer>> codigosFerramenta) {

		return solucaoCapturaServiceRemote.getListaSolucoesCaptura(codigosSolucaoCaptura, codigosFerramenta);
	}

	@Override
	public void efetivarAlteracaoParametrizaocao(
			List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaSolucaoCaptura, String codigoUsuario) {
		//TRATAMOS A LISTA PARA REMOVER OS REGISTRO QUE POSSUAM A MESMA CHAVE COM ACAO DE INCLUSÃO E ALTERACAO
		removerAcaoDuplicada(listaSolucaoCaptura);
		solucaoCapturaServiceRemote.atualizarParametrizacoes(listaSolucaoCaptura, codigoUsuario);
	}

	/**
	 * Caso possua a mesma solução com a acao de incluir e excluir removemos a exclusao e deixamos só a inclusao
	 * Isso acontece pois na tela precisamos mostrar qual registros está sendo alterado (excluido) e como esse registro irá ficar na base (incluido)
	 * 
	 * @param solucao
	 * @return
	 */
	private void removerAcaoDuplicada(List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaSolucaoCaptura) {
		List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaExclusao = new ArrayList<>();
		List<ParametrizacaoSolucaoCapturaPermitidaDTO> registrosExclusao = listaSolucaoCaptura.stream().filter(solucao -> solucao.getTipoAcao().equals(EXCLUSAO)).collect(Collectors.toList());
		listaSolucaoCaptura.forEach(solucao -> tratarRegistrosDuplicados(solucao, registrosExclusao, listaExclusao));
		listaSolucaoCaptura.removeAll(listaExclusao);
	}

	/**
	 * Método responsavel por verificar se o registro que possui status de exclusao tambem possui um registro com inclusao
	 * @param solucao
	 * @param registrosExclusao
	 * @param listaExclusao
	 */
	private void tratarRegistrosDuplicados(ParametrizacaoSolucaoCapturaPermitidaDTO solucao, List<ParametrizacaoSolucaoCapturaPermitidaDTO> registrosExclusao, List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaExclusao) {
		for (ParametrizacaoSolucaoCapturaPermitidaDTO registroExclusao : registrosExclusao) {
			Integer ferramenta = registroExclusao.getCodigoFerramenta();
			Integer solucaoCaptura = registroExclusao.getCodigoSolucaoCaptura();			
			if(solucao.getCodigoFerramenta().equals(ferramenta) && solucao.getCodigoSolucaoCaptura().equals(solucaoCaptura) && solucao.getTipoAcao().equals(INCLUSAO)) {
				listaExclusao.add(registroExclusao);
			}
		}		
	}

}
