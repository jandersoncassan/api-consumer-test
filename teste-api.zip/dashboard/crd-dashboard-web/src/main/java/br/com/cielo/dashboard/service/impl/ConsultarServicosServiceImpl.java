/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarServicoServiceRemote;
import br.com.cielo.dashboard.service.IConsultarServicosService;

/**
 * @author dcarneiro
 *
 */
@Service 
public class ConsultarServicosServiceImpl implements IConsultarServicosService {

	@Resource(mappedName = "ConsultarServicoService#br.com.cielo.credenciamento.service.dashboard.ConsultarServicoServiceRemote")
	private ConsultarServicoServiceRemote consultarServicosRemote;
	
	/**
	 * Método: Obtem Lista de Servicos CRD
	 */
	public List<Object[]> getListarServicos(Long proposta) {
		return consultarServicosRemote.getListaServicos(proposta);
	}

}
