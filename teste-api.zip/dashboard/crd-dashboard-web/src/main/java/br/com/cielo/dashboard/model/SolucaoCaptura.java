/**
 * 
 */
package br.com.cielo.dashboard.model;

/**
 * @author dcarneiro
 *
 */
public class SolucaoCaptura {

	private Integer codigo;
	private String descricao;
	
	private String numeroLogico;
	private String chamadoInstalacao;
	private String tipoTerminal;
	private String dataPrevistaInstalacao;
	private String dataInstalacaoEquipamento;
	private String dataCancelamentoInstalacao;
	private String codigoMotivoCancelamento;
    private String descricaoMotivoCancelamento;	
	private String dataAtivacao;
	private String dataDesbloqueio;
	private String codigoAcesso;
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the numeroLogico
	 */
	public String getNumeroLogico() {
		return numeroLogico;
	}
	/**
	 * @param numeroLogico the numeroLogico to set
	 */
	public void setNumeroLogico(String numeroLogico) {
		this.numeroLogico = numeroLogico;
	}
	/**
	 * @return the chamadoInstalacao
	 */
	public String getChamadoInstalacao() {
		return chamadoInstalacao;
	}
	/**
	 * @param chamadoInstalacao the chamadoInstalacao to set
	 */
	public void setChamadoInstalacao(String chamadoInstalacao) {
		this.chamadoInstalacao = chamadoInstalacao;
	}
	/**
	 * @return the tipoTerminal
	 */
	public String getTipoTerminal() {
		return tipoTerminal;
	}
	/**
	 * @param tipoTerminal the tipoTerminal to set
	 */
	public void setTipoTerminal(String tipoTerminal) {
		this.tipoTerminal = tipoTerminal;
	}
	/**
	 * @return the dataPrevistaInstalacao
	 */
	public String getDataPrevistaInstalacao() {
		return dataPrevistaInstalacao;
	}
	/**
	 * @param dataPrevistaInstalacao the dataPrevistaInstalacao to set
	 */
	public void setDataPrevistaInstalacao(String dataPrevistaInstalacao) {
		this.dataPrevistaInstalacao = dataPrevistaInstalacao;
	}
	/**
	 * @return the dataInstalacaoEquipamento
	 */
	public String getDataInstalacaoEquipamento() {
		return dataInstalacaoEquipamento;
	}
	/**
	 * @param dataInstalacaoEquipamento the dataInstalacaoEquipamento to set
	 */
	public void setDataInstalacaoEquipamento(String dataInstalacaoEquipamento) {
		this.dataInstalacaoEquipamento = dataInstalacaoEquipamento;
	}
	/**
	 * @return the dataCancelamentoInstalacao
	 */
	public String getDataCancelamentoInstalacao() {
		return dataCancelamentoInstalacao;
	}
	/**
	 * @param dataCancelamentoInstalacao the dataCancelamentoInstalacao to set
	 */
	public void setDataCancelamentoInstalacao(String dataCancelamentoInstalacao) {
		this.dataCancelamentoInstalacao = dataCancelamentoInstalacao;
	}
	/**
	 * @return the codigoMotivoCancelamento
	 */
	public String getCodigoMotivoCancelamento() {
		return codigoMotivoCancelamento;
	}
	/**
	 * @param codigoMotivoCancelamento the codigoMotivoCancelamento to set
	 */
	public void setCodigoMotivoCancelamento(String codigoMotivoCancelamento) {
		this.codigoMotivoCancelamento = codigoMotivoCancelamento;
	}
	/**
	 * @return the dataAtivacao
	 */
	public String getDataAtivacao() {
		return dataAtivacao;
	}
	/**
	 * @param dataAtivacao the dataAtivacao to set
	 */
	public void setDataAtivacao(String dataAtivacao) {
		this.dataAtivacao = dataAtivacao;
	}
	/**
	 * @return the dataDesbloqueio
	 */
	public String getDataDesbloqueio() {
		return dataDesbloqueio;
	}
	/**
	 * @param dataDesbloqueio the dataDesbloqueio to set
	 */
	public void setDataDesbloqueio(String dataDesbloqueio) {
		this.dataDesbloqueio = dataDesbloqueio;
	}
    public String getDescricaoMotivoCancelamento() {
        return descricaoMotivoCancelamento;
    }
    public void setDescricaoMotivoCancelamento(String descricaoMotivoCancelamento) {
        this.descricaoMotivoCancelamento = descricaoMotivoCancelamento;
    }
	/**
	 * @return the codigoAcesso
	 */
	public String getCodigoAcesso() {
		return codigoAcesso;
	}
	/**
	 * @param codigoAcesso the codigoAcesso to set
	 */
	public void setCodigoAcesso(String codigoAcesso) {
		this.codigoAcesso = codigoAcesso;
	}
    
    
}
