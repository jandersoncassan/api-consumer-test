/**
 * 
 */
package br.com.cielo.dashboard.model;

/**
 * @author dcarneiro
 *
 */
public class RejeitadosBancoBatch {
	
	private Integer Banco;
	private Integer codigoErroAgencia;
	private Integer codigoErroBancoPropCreden;
	private Integer codigoErroBancoVisaVale;
	private Integer codigoErroComplementoMcc;
	private Integer codigoErroMcc;
	private Integer codigoErroTipoTerminal;
	private Integer codigoErroCentroCompra;
	private Integer codigoErroDataNascPrimProp;
	private Integer codigoErroDataNascSegProp;
	private Integer codigoErroDataNascTerProp;
	private Integer codigoErroIndAfiliacaoComercioEletronico;
	private Integer codigoErroIndDuplicidadeCadastro;
	private Integer codigoErroIndFlexCar;
	private Integer codigoErroIndMei;
	private Integer codigoErroIndOperadorSaude;
	private Integer codigoErroIndTarifaFacil;
	private Integer codigoErroIndMobile;
	private Integer codigoErroNumeroAgenciaVisaVale;
	private Integer codigoErroCepEndComercial;
	private Integer codigoErroCepEndCorrespondencia;
	private Integer codigoErroNumeroContaCorrente;
	private Integer codigoErroNumeroContaCorrenteVisaVale;
	private Integer codigoErroCPfCnpj;
	private Integer codigoErroCpfPrimProprietario;
	private Integer codigoErroCpfSegProprietario;
	private Integer codigoErroCpfTerProprietario;
	private Integer codigoErroDddMobile;
	private Integer codigoErroDddTelefoneFax;
	private Integer codigoErroInscricaoEstadual;
	private Integer codigoErroNumeroTelFax;
	private Integer codigoErroNumeroTelMovel;
	private Integer codigoErroRazaoSocial;
	private Integer codigoErroNomeCidadeEndEstabelec;
	private Integer codigoErroNomeCidadeEndCorrespondencia;
	private Integer codigoErroNomeComplementoPriProprietario;
	private Integer codigoErroNomeComplementoSegProprietario;
	private Integer codigoErroNomeComplementoTerProprietario;
	private Integer codigoErroNomeFantasia;
	private Integer codigoErroNomeLogradouroEndEstabelecimento;
	private Integer codigoErroNomeLograroudoEndCorrespondencia;
	private Integer codigoErroNomePessoaContato;
	private Integer codigoErroNomePlaqueta;
	private Integer codigoErroTaxaPercentualFlexCar;
	private Integer codigoErrotaxaPercentualTrocoFacil;
	private Integer codigoErroQuantPrazoPagamentoFlexCar;
	private Integer codigoErroQuantPrazopagamentoTrocoFacil;
	private Integer codigoErroSiglaEstadoEndComercial;
	private Integer codigoErroSiglaEstadoEndCorrespondencia;
	private Integer codigoErroTipoPessoa;
	
	
	/**/
	private Integer codigoAllErros;
	private String descricaoAllErros;
	
	/**
	 * @return the banco
	 */
	public Integer getBanco() {
		return Banco;
	}
	/**
	 * @param banco the banco to set
	 */
	public void setBanco(Integer banco) {
		Banco = banco;
	}
	/**
	 * @return the codigoErroAgencia
	 */
	public Integer getCodigoErroAgencia() {
		return codigoErroAgencia;
	}
	/**
	 * @param codigoErroAgencia the codigoErroAgencia to set
	 */
	public void setCodigoErroAgencia(Integer codigoErroAgencia) {
		this.codigoErroAgencia = codigoErroAgencia;
	}
	/**
	 * @return the codigoErroBancoPropCreden
	 */
	public Integer getCodigoErroBancoPropCreden() {
		return codigoErroBancoPropCreden;
	}
	/**
	 * @param codigoErroBancoPropCreden the codigoErroBancoPropCreden to set
	 */
	public void setCodigoErroBancoPropCreden(Integer codigoErroBancoPropCreden) {
		this.codigoErroBancoPropCreden = codigoErroBancoPropCreden;
	}
	/**
	 * @return the codigoErroComplementoMcc
	 */
	public Integer getCodigoErroComplementoMcc() {
		return codigoErroComplementoMcc;
	}
	/**
	 * @param codigoErroComplementoMcc the codigoErroComplementoMcc to set
	 */
	public void setCodigoErroComplementoMcc(Integer codigoErroComplementoMcc) {
		this.codigoErroComplementoMcc = codigoErroComplementoMcc;
	}
	/**
	 * @return the codigoErroMcc
	 */
	public Integer getCodigoErroMcc() {
		return codigoErroMcc;
	}
	/**
	 * @param codigoErroMcc the codigoErroMcc to set
	 */
	public void setCodigoErroMcc(Integer codigoErroMcc) {
		this.codigoErroMcc = codigoErroMcc;
	}
	/**
	 * @return the codigoErroTipoTerminal
	 */
	public Integer getCodigoErroTipoTerminal() {
		return codigoErroTipoTerminal;
	}
	/**
	 * @param codigoErroTipoTerminal the codigoErroTipoTerminal to set
	 */
	public void setCodigoErroTipoTerminal(Integer codigoErroTipoTerminal) {
		this.codigoErroTipoTerminal = codigoErroTipoTerminal;
	}
	/**
	 * @return the codigoErroCentroCompra
	 */
	public Integer getCodigoErroCentroCompra() {
		return codigoErroCentroCompra;
	}
	/**
	 * @param codigoErroCentroCompra the codigoErroCentroCompra to set
	 */
	public void setCodigoErroCentroCompra(Integer codigoErroCentroCompra) {
		this.codigoErroCentroCompra = codigoErroCentroCompra;
	}
	/**
	 * @return the codigoErroDataNascPrimProp
	 */
	public Integer getCodigoErroDataNascPrimProp() {
		return codigoErroDataNascPrimProp;
	}
	/**
	 * @param codigoErroDataNascPrimProp the codigoErroDataNascPrimProp to set
	 */
	public void setCodigoErroDataNascPrimProp(Integer codigoErroDataNascPrimProp) {
		this.codigoErroDataNascPrimProp = codigoErroDataNascPrimProp;
	}
	/**
	 * @return the codigoErroDataNascSegProp
	 */
	public Integer getCodigoErroDataNascSegProp() {
		return codigoErroDataNascSegProp;
	}
	/**
	 * @param codigoErroDataNascSegProp the codigoErroDataNascSegProp to set
	 */
	public void setCodigoErroDataNascSegProp(Integer codigoErroDataNascSegProp) {
		this.codigoErroDataNascSegProp = codigoErroDataNascSegProp;
	}
	/**
	 * @return the codigoErroDataNascTerProp
	 */
	public Integer getCodigoErroDataNascTerProp() {
		return codigoErroDataNascTerProp;
	}
	/**
	 * @param codigoErroDataNascTerProp the codigoErroDataNascTerProp to set
	 */
	public void setCodigoErroDataNascTerProp(Integer codigoErroDataNascTerProp) {
		this.codigoErroDataNascTerProp = codigoErroDataNascTerProp;
	}
	/**
	 * @return the codigoErroIndAfiliacaoComercioEletronico
	 */
	public Integer getCodigoErroIndAfiliacaoComercioEletronico() {
		return codigoErroIndAfiliacaoComercioEletronico;
	}
	/**
	 * @param codigoErroIndAfiliacaoComercioEletronico the codigoErroIndAfiliacaoComercioEletronico to set
	 */
	public void setCodigoErroIndAfiliacaoComercioEletronico(Integer codigoErroIndAfiliacaoComercioEletronico) {
		this.codigoErroIndAfiliacaoComercioEletronico = codigoErroIndAfiliacaoComercioEletronico;
	}
	/**
	 * @return the codigoErroIndDuplicidadeCadastro
	 */
	public Integer getCodigoErroIndDuplicidadeCadastro() {
		return codigoErroIndDuplicidadeCadastro;
	}
	/**
	 * @param codigoErroIndDuplicidadeCadastro the codigoErroIndDuplicidadeCadastro to set
	 */
	public void setCodigoErroIndDuplicidadeCadastro(Integer codigoErroIndDuplicidadeCadastro) {
		this.codigoErroIndDuplicidadeCadastro = codigoErroIndDuplicidadeCadastro;
	}
	/**
	 * @return the codigoErroIndFlexCar
	 */
	public Integer getCodigoErroIndFlexCar() {
		return codigoErroIndFlexCar;
	}
	/**
	 * @param codigoErroIndFlexCar the codigoErroIndFlexCar to set
	 */
	public void setCodigoErroIndFlexCar(Integer codigoErroIndFlexCar) {
		this.codigoErroIndFlexCar = codigoErroIndFlexCar;
	}
	/**
	 * @return the codigoErroIndMei
	 */
	public Integer getCodigoErroIndMei() {
		return codigoErroIndMei;
	}
	/**
	 * @param codigoErroIndMei the codigoErroIndMei to set
	 */
	public void setCodigoErroIndMei(Integer codigoErroIndMei) {
		this.codigoErroIndMei = codigoErroIndMei;
	}
	/**
	 * @return the codigoErroIndOperadorSaude
	 */
	public Integer getCodigoErroIndOperadorSaude() {
		return codigoErroIndOperadorSaude;
	}
	/**
	 * @param codigoErroIndOperadorSaude the codigoErroIndOperadorSaude to set
	 */
	public void setCodigoErroIndOperadorSaude(Integer codigoErroIndOperadorSaude) {
		this.codigoErroIndOperadorSaude = codigoErroIndOperadorSaude;
	}
	/**
	 * @return the codigoErroIndTarifaFacil
	 */
	public Integer getCodigoErroIndTarifaFacil() {
		return codigoErroIndTarifaFacil;
	}
	/**
	 * @param codigoErroIndTarifaFacil the codigoErroIndTarifaFacil to set
	 */
	public void setCodigoErroIndTarifaFacil(Integer codigoErroIndTarifaFacil) {
		this.codigoErroIndTarifaFacil = codigoErroIndTarifaFacil;
	}
	/**
	 * @return the codigoErroIndMobile
	 */
	public Integer getCodigoErroIndMobile() {
		return codigoErroIndMobile;
	}
	/**
	 * @param codigoErroIndMobile the codigoErroIndMobile to set
	 */
	public void setCodigoErroIndMobile(Integer codigoErroIndMobile) {
		this.codigoErroIndMobile = codigoErroIndMobile;
	}
	/**
	 * @return the codigoErroNumeroAgenciaVisaVale
	 */
	public Integer getCodigoErroNumeroAgenciaVisaVale() {
		return codigoErroNumeroAgenciaVisaVale;
	}
	/**
	 * @param codigoErroNumeroAgenciaVisaVale the codigoErroNumeroAgenciaVisaVale to set
	 */
	public void setCodigoErroNumeroAgenciaVisaVale(Integer codigoErroNumeroAgenciaVisaVale) {
		this.codigoErroNumeroAgenciaVisaVale = codigoErroNumeroAgenciaVisaVale;
	}
	/**
	 * @return the codigoErroCepEndComercial
	 */
	public Integer getCodigoErroCepEndComercial() {
		return codigoErroCepEndComercial;
	}
	/**
	 * @param codigoErroCepEndComercial the codigoErroCepEndComercial to set
	 */
	public void setCodigoErroCepEndComercial(Integer codigoErroCepEndComercial) {
		this.codigoErroCepEndComercial = codigoErroCepEndComercial;
	}
	/**
	 * @return the codigoErroCepEndCorrespondencia
	 */
	public Integer getCodigoErroCepEndCorrespondencia() {
		return codigoErroCepEndCorrespondencia;
	}
	/**
	 * @param codigoErroCepEndCorrespondencia the codigoErroCepEndCorrespondencia to set
	 */
	public void setCodigoErroCepEndCorrespondencia(Integer codigoErroCepEndCorrespondencia) {
		this.codigoErroCepEndCorrespondencia = codigoErroCepEndCorrespondencia;
	}
	/**
	 * @return the codigoErroNumeroContaCorrente
	 */
	public Integer getCodigoErroNumeroContaCorrente() {
		return codigoErroNumeroContaCorrente;
	}
	/**
	 * @param codigoErroNumeroContaCorrente the codigoErroNumeroContaCorrente to set
	 */
	public void setCodigoErroNumeroContaCorrente(Integer codigoErroNumeroContaCorrente) {
		this.codigoErroNumeroContaCorrente = codigoErroNumeroContaCorrente;
	}
	/**
	 * @return the codigoErroNumeroContaCorrenteVisaVale
	 */
	public Integer getCodigoErroNumeroContaCorrenteVisaVale() {
		return codigoErroNumeroContaCorrenteVisaVale;
	}
	/**
	 * @param codigoErroNumeroContaCorrenteVisaVale the codigoErroNumeroContaCorrenteVisaVale to set
	 */
	public void setCodigoErroNumeroContaCorrenteVisaVale(Integer codigoErroNumeroContaCorrenteVisaVale) {
		this.codigoErroNumeroContaCorrenteVisaVale = codigoErroNumeroContaCorrenteVisaVale;
	}
	/**
	 * @return the codigoErroCPfCnpj
	 */
	public Integer getCodigoErroCPfCnpj() {
		return codigoErroCPfCnpj;
	}
	/**
	 * @param codigoErroCPfCnpj the codigoErroCPfCnpj to set
	 */
	public void setCodigoErroCPfCnpj(Integer codigoErroCPfCnpj) {
		this.codigoErroCPfCnpj = codigoErroCPfCnpj;
	}
	/**
	 * @return the codigoErroCpfPrimProprietario
	 */
	public Integer getCodigoErroCpfPrimProprietario() {
		return codigoErroCpfPrimProprietario;
	}
	/**
	 * @param codigoErroCpfPrimProprietario the codigoErroCpfPrimProprietario to set
	 */
	public void setCodigoErroCpfPrimProprietario(Integer codigoErroCpfPrimProprietario) {
		this.codigoErroCpfPrimProprietario = codigoErroCpfPrimProprietario;
	}
	/**
	 * @return the codigoErroCpfSegProprietario
	 */
	public Integer getCodigoErroCpfSegProprietario() {
		return codigoErroCpfSegProprietario;
	}
	/**
	 * @param codigoErroCpfSegProprietario the codigoErroCpfSegProprietario to set
	 */
	public void setCodigoErroCpfSegProprietario(Integer codigoErroCpfSegProprietario) {
		this.codigoErroCpfSegProprietario = codigoErroCpfSegProprietario;
	}
	/**
	 * @return the codigoErroCpfTerProprietario
	 */
	public Integer getCodigoErroCpfTerProprietario() {
		return codigoErroCpfTerProprietario;
	}
	/**
	 * @param codigoErroCpfTerProprietario the codigoErroCpfTerProprietario to set
	 */
	public void setCodigoErroCpfTerProprietario(Integer codigoErroCpfTerProprietario) {
		this.codigoErroCpfTerProprietario = codigoErroCpfTerProprietario;
	}
	/**
	 * @return the codigoErroDddMobile
	 */
	public Integer getCodigoErroDddMobile() {
		return codigoErroDddMobile;
	}
	/**
	 * @param codigoErroDddMobile the codigoErroDddMobile to set
	 */
	public void setCodigoErroDddMobile(Integer codigoErroDddMobile) {
		this.codigoErroDddMobile = codigoErroDddMobile;
	}
	/**
	 * @return the codigoErroDddTelefoneFax
	 */
	public Integer getCodigoErroDddTelefoneFax() {
		return codigoErroDddTelefoneFax;
	}
	/**
	 * @param codigoErroDddTelefoneFax the codigoErroDddTelefoneFax to set
	 */
	public void setCodigoErroDddTelefoneFax(Integer codigoErroDddTelefoneFax) {
		this.codigoErroDddTelefoneFax = codigoErroDddTelefoneFax;
	}
	/**
	 * @return the codigoErroInscricaoEstadual
	 */
	public Integer getCodigoErroInscricaoEstadual() {
		return codigoErroInscricaoEstadual;
	}
	/**
	 * @param codigoErroInscricaoEstadual the codigoErroInscricaoEstadual to set
	 */
	public void setCodigoErroInscricaoEstadual(Integer codigoErroInscricaoEstadual) {
		this.codigoErroInscricaoEstadual = codigoErroInscricaoEstadual;
	}
	/**
	 * @return the codigoErroNumeroTelFax
	 */
	public Integer getCodigoErroNumeroTelFax() {
		return codigoErroNumeroTelFax;
	}
	/**
	 * @param codigoErroNumeroTelFax the codigoErroNumeroTelFax to set
	 */
	public void setCodigoErroNumeroTelFax(Integer codigoErroNumeroTelFax) {
		this.codigoErroNumeroTelFax = codigoErroNumeroTelFax;
	}
	/**
	 * @return the codigoErroNumeroTelMovel
	 */
	public Integer getCodigoErroNumeroTelMovel() {
		return codigoErroNumeroTelMovel;
	}
	/**
	 * @param codigoErroNumeroTelMovel the codigoErroNumeroTelMovel to set
	 */
	public void setCodigoErroNumeroTelMovel(Integer codigoErroNumeroTelMovel) {
		this.codigoErroNumeroTelMovel = codigoErroNumeroTelMovel;
	}
	/**
	 * @return the codigoErroRazaoSocial
	 */
	public Integer getCodigoErroRazaoSocial() {
		return codigoErroRazaoSocial;
	}
	/**
	 * @param codigoErroRazaoSocial the codigoErroRazaoSocial to set
	 */
	public void setCodigoErroRazaoSocial(Integer codigoErroRazaoSocial) {
		this.codigoErroRazaoSocial = codigoErroRazaoSocial;
	}
	/**
	 * @return the codigoErroNomeCidadeEndEstabelec
	 */
	public Integer getCodigoErroNomeCidadeEndEstabelec() {
		return codigoErroNomeCidadeEndEstabelec;
	}
	/**
	 * @param codigoErroNomeCidadeEndEstabelec the codigoErroNomeCidadeEndEstabelec to set
	 */
	public void setCodigoErroNomeCidadeEndEstabelec(Integer codigoErroNomeCidadeEndEstabelec) {
		this.codigoErroNomeCidadeEndEstabelec = codigoErroNomeCidadeEndEstabelec;
	}
	/**
	 * @return the codigoErroNomeCidadeEndCorrespondencia
	 */
	public Integer getCodigoErroNomeCidadeEndCorrespondencia() {
		return codigoErroNomeCidadeEndCorrespondencia;
	}
	/**
	 * @param codigoErroNomeCidadeEndCorrespondencia the codigoErroNomeCidadeEndCorrespondencia to set
	 */
	public void setCodigoErroNomeCidadeEndCorrespondencia(Integer codigoErroNomeCidadeEndCorrespondencia) {
		this.codigoErroNomeCidadeEndCorrespondencia = codigoErroNomeCidadeEndCorrespondencia;
	}
	/**
	 * @return the codigoErroNomeComplementoPriProprietario
	 */
	public Integer getCodigoErroNomeComplementoPriProprietario() {
		return codigoErroNomeComplementoPriProprietario;
	}
	/**
	 * @param codigoErroNomeComplementoPriProprietario the codigoErroNomeComplementoPriProprietario to set
	 */
	public void setCodigoErroNomeComplementoPriProprietario(Integer codigoErroNomeComplementoPriProprietario) {
		this.codigoErroNomeComplementoPriProprietario = codigoErroNomeComplementoPriProprietario;
	}
	/**
	 * @return the codigoErroNomeComplementoSegProprietario
	 */
	public Integer getCodigoErroNomeComplementoSegProprietario() {
		return codigoErroNomeComplementoSegProprietario;
	}
	/**
	 * @param codigoErroNomeComplementoSegProprietario the codigoErroNomeComplementoSegProprietario to set
	 */
	public void setCodigoErroNomeComplementoSegProprietario(Integer codigoErroNomeComplementoSegProprietario) {
		this.codigoErroNomeComplementoSegProprietario = codigoErroNomeComplementoSegProprietario;
	}
	/**
	 * @return the codigoErroNomeComplementoTerProprietario
	 */
	public Integer getCodigoErroNomeComplementoTerProprietario() {
		return codigoErroNomeComplementoTerProprietario;
	}
	/**
	 * @param codigoErroNomeComplementoTerProprietario the codigoErroNomeComplementoTerProprietario to set
	 */
	public void setCodigoErroNomeComplementoTerProprietario(Integer codigoErroNomeComplementoTerProprietario) {
		this.codigoErroNomeComplementoTerProprietario = codigoErroNomeComplementoTerProprietario;
	}
	/**
	 * @return the codigoErroNomeFantasia
	 */
	public Integer getCodigoErroNomeFantasia() {
		return codigoErroNomeFantasia;
	}
	/**
	 * @param codigoErroNomeFantasia the codigoErroNomeFantasia to set
	 */
	public void setCodigoErroNomeFantasia(Integer codigoErroNomeFantasia) {
		this.codigoErroNomeFantasia = codigoErroNomeFantasia;
	}
	/**
	 * @return the codigoErroNomeLogradouroEndEstabelecimento
	 */
	public Integer getCodigoErroNomeLogradouroEndEstabelecimento() {
		return codigoErroNomeLogradouroEndEstabelecimento;
	}
	/**
	 * @param codigoErroNomeLogradouroEndEstabelecimento the codigoErroNomeLogradouroEndEstabelecimento to set
	 */
	public void setCodigoErroNomeLogradouroEndEstabelecimento(Integer codigoErroNomeLogradouroEndEstabelecimento) {
		this.codigoErroNomeLogradouroEndEstabelecimento = codigoErroNomeLogradouroEndEstabelecimento;
	}
	/**
	 * @return the codigoErroNomeLograroudoEndCorrespondencia
	 */
	public Integer getCodigoErroNomeLograroudoEndCorrespondencia() {
		return codigoErroNomeLograroudoEndCorrespondencia;
	}
	/**
	 * @param codigoErroNomeLograroudoEndCorrespondencia the codigoErroNomeLograroudoEndCorrespondencia to set
	 */
	public void setCodigoErroNomeLograroudoEndCorrespondencia(Integer codigoErroNomeLograroudoEndCorrespondencia) {
		this.codigoErroNomeLograroudoEndCorrespondencia = codigoErroNomeLograroudoEndCorrespondencia;
	}
	/**
	 * @return the codigoErroNomePessoaContato
	 */
	public Integer getCodigoErroNomePessoaContato() {
		return codigoErroNomePessoaContato;
	}
	/**
	 * @param codigoErroNomePessoaContato the codigoErroNomePessoaContato to set
	 */
	public void setCodigoErroNomePessoaContato(Integer codigoErroNomePessoaContato) {
		this.codigoErroNomePessoaContato = codigoErroNomePessoaContato;
	}
	/**
	 * @return the codigoErroNomePlaqueta
	 */
	public Integer getCodigoErroNomePlaqueta() {
		return codigoErroNomePlaqueta;
	}
	/**
	 * @param codigoErroNomePlaqueta the codigoErroNomePlaqueta to set
	 */
	public void setCodigoErroNomePlaqueta(Integer codigoErroNomePlaqueta) {
		this.codigoErroNomePlaqueta = codigoErroNomePlaqueta;
	}
	/**
	 * @return the codigoErroTaxaPercentualFlexCar
	 */
	public Integer getCodigoErroTaxaPercentualFlexCar() {
		return codigoErroTaxaPercentualFlexCar;
	}
	/**
	 * @param codigoErroTaxaPercentualFlexCar the codigoErroTaxaPercentualFlexCar to set
	 */
	public void setCodigoErroTaxaPercentualFlexCar(Integer codigoErroTaxaPercentualFlexCar) {
		this.codigoErroTaxaPercentualFlexCar = codigoErroTaxaPercentualFlexCar;
	}
	/**
	 * @return the codigoErrotaxaPercentualTrocoFacil
	 */
	public Integer getCodigoErrotaxaPercentualTrocoFacil() {
		return codigoErrotaxaPercentualTrocoFacil;
	}
	/**
	 * @param codigoErrotaxaPercentualTrocoFacil the codigoErrotaxaPercentualTrocoFacil to set
	 */
	public void setCodigoErrotaxaPercentualTrocoFacil(Integer codigoErrotaxaPercentualTrocoFacil) {
		this.codigoErrotaxaPercentualTrocoFacil = codigoErrotaxaPercentualTrocoFacil;
	}
	/**
	 * @return the codigoErroQuantPrazoPagamentoFlexCar
	 */
	public Integer getCodigoErroQuantPrazoPagamentoFlexCar() {
		return codigoErroQuantPrazoPagamentoFlexCar;
	}
	/**
	 * @param codigoErroQuantPrazoPagamentoFlexCar the codigoErroQuantPrazoPagamentoFlexCar to set
	 */
	public void setCodigoErroQuantPrazoPagamentoFlexCar(Integer codigoErroQuantPrazoPagamentoFlexCar) {
		this.codigoErroQuantPrazoPagamentoFlexCar = codigoErroQuantPrazoPagamentoFlexCar;
	}
	/**
	 * @return the codigoErroQuantPrazopagamentoTrocoFacil
	 */
	public Integer getCodigoErroQuantPrazopagamentoTrocoFacil() {
		return codigoErroQuantPrazopagamentoTrocoFacil;
	}
	/**
	 * @param codigoErroQuantPrazopagamentoTrocoFacil the codigoErroQuantPrazopagamentoTrocoFacil to set
	 */
	public void setCodigoErroQuantPrazopagamentoTrocoFacil(Integer codigoErroQuantPrazopagamentoTrocoFacil) {
		this.codigoErroQuantPrazopagamentoTrocoFacil = codigoErroQuantPrazopagamentoTrocoFacil;
	}
	/**
	 * @return the codigoErroSiglaEstadoEndComercial
	 */
	public Integer getCodigoErroSiglaEstadoEndComercial() {
		return codigoErroSiglaEstadoEndComercial;
	}
	/**
	 * @param codigoErroSiglaEstadoEndComercial the codigoErroSiglaEstadoEndComercial to set
	 */
	public void setCodigoErroSiglaEstadoEndComercial(Integer codigoErroSiglaEstadoEndComercial) {
		this.codigoErroSiglaEstadoEndComercial = codigoErroSiglaEstadoEndComercial;
	}
	/**
	 * @return the codigoErroSiglaEstadoEndCorrespondencia
	 */
	public Integer getCodigoErroSiglaEstadoEndCorrespondencia() {
		return codigoErroSiglaEstadoEndCorrespondencia;
	}
	/**
	 * @param codigoErroSiglaEstadoEndCorrespondencia the codigoErroSiglaEstadoEndCorrespondencia to set
	 */
	public void setCodigoErroSiglaEstadoEndCorrespondencia(Integer codigoErroSiglaEstadoEndCorrespondencia) {
		this.codigoErroSiglaEstadoEndCorrespondencia = codigoErroSiglaEstadoEndCorrespondencia;
	}
	/**
	 * @return the codigoErroTipoPessoa
	 */
	public Integer getCodigoErroTipoPessoa() {
		return codigoErroTipoPessoa;
	}
	/**
	 * @param codigoErroTipoPessoa the codigoErroTipoPessoa to set
	 */
	public void setCodigoErroTipoPessoa(Integer codigoErroTipoPessoa) {
		this.codigoErroTipoPessoa = codigoErroTipoPessoa;
	}
	/**
	 * @return the codigoErroBancoVisaVale
	 */
	public Integer getCodigoErroBancoVisaVale() {
		return codigoErroBancoVisaVale;
	}
	/**
	 * @param codigoErroBancoVisaVale the codigoErroBancoVisaVale to set
	 */
	public void setCodigoErroBancoVisaVale(Integer codigoErroBancoVisaVale) {
		this.codigoErroBancoVisaVale = codigoErroBancoVisaVale;
	}
	/**
	 * @return the codigoAllErros
	 */
	public Integer getCodigoAllErros() {
		return codigoAllErros;
	}
	/**
	 * @param codigoAllErros the codigoAllErros to set
	 */
	public void setCodigoAllErros(Integer codigoAllErros) {
		this.codigoAllErros = codigoAllErros;
	}
	/**
	 * @return the descricaoAllErros
	 */
	public String getDescricaoAllErros() {
		return descricaoAllErros;
	}
	/**
	 * @param descricaoAllErros the descricaoAllErros to set
	 */
	public void setDescricaoAllErros(String descricaoAllErros) {
		this.descricaoAllErros = descricaoAllErros;
	}

	
	
}
