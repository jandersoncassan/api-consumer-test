package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.credenciamento.dto.ParametrizacaoBoasVindasDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoBoasVindasManutencaoDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoBoasVindasManutencaoRequestDTO;
import br.com.cielo.credenciamento.dto.SituacaoCadastralDTO;
import br.com.cielo.dashboard.dto.ItemGradeConfirmacaoBoasVindasDTO;
import br.com.cielo.dashboard.dto.ItemGradeParametrizacaoBoasVindasDTO;
import br.com.cielo.dashboard.dto.ParametrizacaoBoasVindasAuxiliarDTO;
import br.com.cielo.dashboard.model.Bancos;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IConsultarBancosService;
import br.com.cielo.dashboard.service.IConsultarSituacaoCadastralService;
import br.com.cielo.dashboard.service.IParametrizacaoBoasVindasService;
import br.com.cielo.dashboard.utils.DashboardUtils;
import br.com.cielo.dashboard.validator.BoasVindasValidator;

@Controller
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class ParametrizacaoBoasVindasController {

	@Autowired
	private IConsultarBancosService consultarBancosService;

	@Autowired
	private IConsultarSituacaoCadastralService consultarSituacaoCadastralService;

	@Autowired
	private IParametrizacaoBoasVindasService parametrizacaoBoasVindasService;
	
	@Autowired
	private BoasVindasValidator validator;

	@RequestMapping("/initParametrizacaoBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String initParametrizacaoBoasVindas(Model model, HttpSession session, Authentication authentication)
			throws IOException {

		carregarServicos(model, session, authentication);

		montarGradeParametrizacao(model, session, authentication);

		return NavigationDashBoard.PARAMETRIZACAO_BOAS_VINDAS;

	}

	private void montarGradeParametrizacao(Model model, HttpSession session, Authentication authentication) {

		ParametrizacaoBoasVindasAuxiliarDTO parametrizacoesBVAux = new ParametrizacaoBoasVindasAuxiliarDTO();
		
		List<Bancos> listaBancos = (List<Bancos>) session.getAttribute("listaBancos");
		
		if (listaBancos == null) {
			listaBancos = listarBancos(authentication);
			session.setAttribute("listaBancos", listaBancos);
			model.addAttribute("listaBancos", listaBancos);
		}

		List<ParametrizacaoBoasVindasDTO> parametrizacoesExistentes = parametrizacaoBoasVindasService.obterParametrizacoesVigentes();

		Map<String, ParametrizacaoBoasVindasDTO> mapParametrosExistentes = parametrizacoesExistentes.stream()
				.collect(Collectors.toMap(ParametrizacaoBoasVindasDTO:: getCodBanco, x -> x));
		
		List<ItemGradeParametrizacaoBoasVindasDTO> itensGrade = new ArrayList<ItemGradeParametrizacaoBoasVindasDTO>();
		List<String> itensAtivos = new ArrayList<String>(); 
		
		for (Bancos banco : listaBancos) {

			ItemGradeParametrizacaoBoasVindasDTO item = new ItemGradeParametrizacaoBoasVindasDTO();
			item.setCodBanco(banco.getCodigoBanco().toString());
			item.setNomeBanco(banco.getDescricaoBanco());

			if (mapParametrosExistentes.containsKey(item.getCodBanco())) {

				item.setIndicadorBoasVindas(true);
				item.setCodSituacaoCadastral(mapParametrosExistentes.get(item.getCodBanco()).getCodSituacaoCadastral());
				itensAtivos.add(item.getCodBanco());
			}
		
			itensGrade.add(item);
			
		}

		parametrizacoesBVAux.setParametrizacoesBoasVindas(itensGrade);
		
		parametrizacoesBVAux.setItensAtivos(itensAtivos);
		
		model.addAttribute("parametrizacoesbvaux", parametrizacoesBVAux);
		session.setAttribute("parametrizacoesbvaux", parametrizacoesBVAux);
		
	}

	private void carregarServicos(Model model, HttpSession session, Authentication authentication) {
		
		carregarSituacaoCadastral(model, session);

	}

	private List<Bancos> listarBancos(Authentication authentication) {

		List<Object[]> retorno = consultarBancosService.getListarBancosDomiciliosParametrizados();

		List<Bancos> listaBancos = retorno.stream().map(i -> converterRetornoConsultarBancos(i))
				.collect(Collectors.toList());

		return listaBancos;
	}

	private void carregarSituacaoCadastral(Model model, HttpSession session) {

		List<SituacaoCadastralDTO> retorno = (List<SituacaoCadastralDTO>) session.getAttribute("listaSituacaoCadastral");
		
		if (retorno == null) {
			retorno = consultarSituacaoCadastralService.listarSituacaoCadastral().stream()
					.filter(x -> situacaoCadastralValidaBoasVindas(x.getCodigo()))
					.collect(Collectors.toList());
			session.setAttribute("listaSituacaoCadastral", retorno);
		}
		
		model.addAttribute("listaSituacaoCadastral", retorno);
		
	}
	
	private Boolean situacaoCadastralValidaBoasVindas(String codSituacaoCadastral) {
		
		if ((codSituacaoCadastral.equals("O")) ||
			(codSituacaoCadastral.equals("C")) || 
			(codSituacaoCadastral.equals("P"))) {
			return true;
		}
		else {
			return false;
		}
	}

	private Bancos converterRetornoConsultarBancos(Object[] valores) {

		Bancos item = new Bancos();
		item.setCodigoBanco(Integer.parseInt(String.valueOf(valores[0])));
		item.setDescricaoBanco(String.valueOf(valores[1]));
		return item;
	}
	
	@RequestMapping("/identificarAtualizacoesBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR)
	public String identificarAtualizacoesBoasVindas(@ModelAttribute("parametrizacoesbvaux") @Valid ParametrizacaoBoasVindasAuxiliarDTO parametrizacaoBoasVindas,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication) throws ParseException {
		
		validator.validate(parametrizacaoBoasVindas, bindingResult);
		
		if (!bindingResult.hasErrors()){
			
			List<ParametrizacaoBoasVindasManutencaoDTO> listManutencoes = identificarAtualizacoes(parametrizacaoBoasVindas, session, model);
			
			List<Bancos> listaBancos = (List<Bancos>) session.getAttribute("listaBancos");
			Map<Integer, String> mapBancos = listaBancos.stream()
					.collect(Collectors.toMap(Bancos::getCodigoBanco, Bancos::getDescricaoBanco));
			
			List<ItemGradeConfirmacaoBoasVindasDTO> listConfirmacao = listManutencoes.stream()
					.map(item -> toItemConfirmacaoDTO(item, mapBancos))
					.collect(Collectors.toList());
			
			model.addAttribute("listConfirmacao", listConfirmacao);
			session.setAttribute("listManutencoes", listManutencoes);
			
		}
		else
		{
			List<FieldError> erros = bindingResult.getFieldErrors();
			model.addAttribute("erros", erros);
		}		
		
		model.addAttribute("parametrizacoesbvaux", parametrizacaoBoasVindas);
		
		return NavigationDashBoard.PARAMETRIZACAO_BOAS_VINDAS;
		
	}
	
	private ItemGradeConfirmacaoBoasVindasDTO toItemConfirmacaoDTO(ParametrizacaoBoasVindasManutencaoDTO item, Map<Integer, String> mapBancos) {
		
		ItemGradeConfirmacaoBoasVindasDTO retorno = new ItemGradeConfirmacaoBoasVindasDTO();
		retorno.setCodigoBanco(item.getCodBanco());
		retorno.setDescricaoBanco(mapBancos.get(item.getCodBanco()));

		if (item.isAtivo() && item.isAlterado()) {
			retorno.setTipoManutencao("Alteração");
		}
		if (item.isAtivo() && !item.isAlterado()) {
			retorno.setTipoManutencao("Incluído");
		}
		if (!item.isAtivo()) {
			retorno.setTipoManutencao("Excluído");
		}
		
		return retorno;
		
	}
	
	private List<ParametrizacaoBoasVindasManutencaoDTO> identificarAtualizacoes(ParametrizacaoBoasVindasAuxiliarDTO parametrizacaoBoasVindas,
			HttpSession session, Model model) {
		
		ParametrizacaoBoasVindasAuxiliarDTO parametrizacaoOriginal = (ParametrizacaoBoasVindasAuxiliarDTO) session.getAttribute("parametrizacoesbvaux");  
		
		Map<String, ItemGradeParametrizacaoBoasVindasDTO> hashParametrizacaoOriginal = parametrizacaoOriginal.getParametrizacoesBoasVindas()
				.stream().collect(Collectors.toMap(ItemGradeParametrizacaoBoasVindasDTO::getCodBanco, value -> value));
		
		List<String> itensIncluir = new ArrayList<String>();
		List<String> itensExcluir = new ArrayList<String>();
		List<String> itensValidarAlteracao = new ArrayList<String>();
		
		if (parametrizacaoBoasVindas.getItensAtivos() == null) {
			parametrizacaoBoasVindas.setItensAtivos(new ArrayList<String>());
		}

		if (parametrizacaoOriginal.getItensAtivos() == null) {
			parametrizacaoOriginal.setItensAtivos(new ArrayList<String>());
		}
		
		itensIncluir.addAll(parametrizacaoBoasVindas.getItensAtivos().stream()
				.filter(x -> !parametrizacaoOriginal.getItensAtivos().contains(x))
				.collect(Collectors.toList()));
		
		itensExcluir.addAll(parametrizacaoOriginal.getItensAtivos().stream()
				.filter(x -> !parametrizacaoBoasVindas.getItensAtivos().contains(x))
				.collect(Collectors.toList()));
		
		itensValidarAlteracao.addAll(parametrizacaoOriginal.getItensAtivos().stream()
				.filter(x -> parametrizacaoBoasVindas.getItensAtivos().contains(x))
				.collect(Collectors.toList()));
		
		List<ParametrizacaoBoasVindasManutencaoDTO> listaManutencoes = new ArrayList<ParametrizacaoBoasVindasManutencaoDTO>();
		
		listaManutencoes.addAll(parametrizacaoBoasVindas.getParametrizacoesBoasVindas().stream()
				.filter(x -> itensIncluir.contains(x.getCodBanco()))
				.map(x -> this.converterGradeToManutencaoDTO(x, true, false))
				.collect(Collectors.toList()));
					
		listaManutencoes.addAll(parametrizacaoBoasVindas.getParametrizacoesBoasVindas().stream()
				.filter(x -> itensExcluir.contains(x.getCodBanco()))
				.map(x -> this.converterGradeToManutencaoDTO(x, false, false))
				.collect(Collectors.toList()));
		
		listaManutencoes.addAll(parametrizacaoBoasVindas.getParametrizacoesBoasVindas().stream()
				.filter(x -> itensValidarAlteracao.contains(x.getCodBanco()))
				.filter(x -> !x.getCodSituacaoCadastral().equals(hashParametrizacaoOriginal.get(x.getCodBanco()).getCodSituacaoCadastral()))
				.map(x -> this.converterGradeToManutencaoDTO(x, true, true))
				.collect(Collectors.toList()));
		
		return listaManutencoes;		
		
	}
			
	@RequestMapping("/atualizarBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR)
	public String atualizar(@ModelAttribute("parametrizacoesbvaux") @Valid ParametrizacaoBoasVindasAuxiliarDTO parametrizacaoBoasVindas,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication) throws ParseException {
		
		List<ParametrizacaoBoasVindasManutencaoDTO> listManutencoes = (List<ParametrizacaoBoasVindasManutencaoDTO>) session.getAttribute("listManutencoes");

		aplicarAtualizacoes(listManutencoes, session, model);
		
		montarGradeParametrizacao(model, session, authentication);
		
		model.addAttribute("success", "Atualização realizada com sucesso!");
		
		return NavigationDashBoard.PARAMETRIZACAO_BOAS_VINDAS;
		
	}
	
	private void aplicarAtualizacoes(List<ParametrizacaoBoasVindasManutencaoDTO> listaManutencoes, HttpSession session, Model model) {
		
		ParametrizacaoBoasVindasManutencaoRequestDTO request = new ParametrizacaoBoasVindasManutencaoRequestDTO();
		request.setManutencoesBoasVindas(listaManutencoes);
		request.setUsuario((String) session.getAttribute("username"));
		
		parametrizacaoBoasVindasService.atualizarParametrizacoes(request);
		
	}
	
	private ParametrizacaoBoasVindasManutencaoDTO converterGradeToManutencaoDTO(ItemGradeParametrizacaoBoasVindasDTO item, boolean ativo, boolean alterado) {
		
		ParametrizacaoBoasVindasManutencaoDTO retorno = new ParametrizacaoBoasVindasManutencaoDTO();
		
		retorno.setCodBanco(Integer.parseInt(item.getCodBanco()));
		retorno.setCodSituacaoCadastral(item.getCodSituacaoCadastral());
		retorno.setAtivo(ativo);
		retorno.setAlterado(alterado);
		
		return retorno;
		
	}
	
	@RequestMapping("/exportParametrizacaoBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_EXPORTAR)
	public void exportParametrizacaoBoasVindas(@ModelAttribute("parametrizacoesbvaux") @Valid ParametrizacaoBoasVindasAuxiliarDTO parametrizacaoBoasVindas,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication, 
			HttpServletResponse response) throws IOException {

		XSSFWorkbook wb = new XSSFWorkbook();
		String[] hearders = new String[] {"BANCO"
										, "IND. BOAS VINDAS"
										, "SITUAÇÃO CADASTRAL"
										};
		try {
			
			List<SituacaoCadastralDTO> listaSituacaoCadastral = (List<SituacaoCadastralDTO>) session.getAttribute("listaSituacaoCadastral");
			
			Map<String, String> mapSituacaoCadastral = listaSituacaoCadastral.stream()
					.collect(Collectors.toMap(SituacaoCadastralDTO::getCodigo, x -> x.getDescricao()));
			
			ParametrizacaoBoasVindasAuxiliarDTO parametrizacaoAuxiliarDTO = (ParametrizacaoBoasVindasAuxiliarDTO) session.getAttribute("parametrizacoesbvaux");

			List<ItemGradeParametrizacaoBoasVindasDTO> listaItens = parametrizacaoAuxiliarDTO.getParametrizacoesBoasVindas();
			
			XSSFSheet sheet = wb.createSheet();
			XSSFRow row = sheet.createRow(0);

			/* create style */
			XSSFCellStyle style = wb.createCellStyle();
			XSSFFont font = wb.createFont();
			font.setBold(Boolean.TRUE);
			font.setFontHeightInPoints((short) 12);
			style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setFont(font);
			
			for (int i = 0; i < hearders.length; i++) {
				XSSFCell cell = row.createCell(i);
				cell.setCellValue(hearders[i]);
				cell.setCellStyle(style);
				sheet.setColumnWidth(i, i == 0 || i == 1 ? 2500 : 6000);
			}
			


			if (!listaItens.isEmpty()) {
				for (int i = 0; i < listaItens.size(); i++) {
					
					XSSFRow rowConteudo = sheet.createRow(i + 1);
					
					rowConteudo.createCell((int) 0).setCellValue(listaItens.get(i).getNomeBanco());
					if (parametrizacaoAuxiliarDTO.getItensAtivos().contains(listaItens.get(i).getCodBanco())){
						rowConteudo.createCell((int) 1).setCellValue("ATIVO");
						rowConteudo.createCell((int) 2).setCellValue(mapSituacaoCadastral.get(listaItens.get(i).getCodSituacaoCadastral()));
					}
					else{
						rowConteudo.createCell((int) 1).setCellValue("INATIVO");
					}

				}
			}
			DashboardUtils.contentTypeForBrowser(response, wb, "RELATORIO_PARAMETRIZACAO_BOAS_VINDAS");
			
			
			
		} catch (Exception e) {
			throw e;
		}
	}
}
