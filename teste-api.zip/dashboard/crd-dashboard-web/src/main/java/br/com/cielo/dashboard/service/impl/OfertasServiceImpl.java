package br.com.cielo.dashboard.service.impl;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.rpc.ServiceException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.dashboard.model.ConsultaOfertas;
import br.com.cielo.dashboard.model.DescontosOfertas;
import br.com.cielo.dashboard.model.Oferta;
import br.com.cielo.dashboard.model.OfertasInteract;
import br.com.cielo.dashboard.service.IOfertasService;
import br.com.cielo.dashboard.service.IOsbService;
import br.com.cielo.dashboard.utils.DashboardUtils;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertasResponseType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaResponseType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.OfertaType;

/**
 * Classe responsavel por implementar os serviços de consulta de ofertas
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 *
 */
@Service
public class OfertasServiceImpl implements IOfertasService {

	private static final Logger LOG = LogManager.getLogger(OfertasServiceImpl.class);

	@Autowired
	private IOsbService osbService;

	@Override
	public Optional<List<Oferta>> consultarOfertas(ConsultaOfertas infoOfertas) {
		LOG.info("CONSULTANDO AS OFERTAS CADASTRADAS NO INTERACT {}", infoOfertas);
		try {

			ConsultarOfertaResponseType response = osbService.consultarOfertasInteract(infoOfertas);
			return popularInfoOfertas(Optional.ofNullable(response.getOfertas()));

		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO OBTER AS OFERTAS DE CREDENCIAMENTO CADASTRADAS {}", ex);
			throw new RuntimeException("OCORREU UM ERRO AO OBTER AS OFERTAS DE CREDENCIAMENTO CADASTRADAS");
		}
	}

	/**
	 * Método responsavel por popular as informações da lista de ofertas
	 * 
	 * @param optional
	 * @return
	 */
	private Optional<List<Oferta>> popularInfoOfertas(Optional<OfertaType[]> optional) {
		if (optional.isPresent()) {
			List<Oferta> listaOfertas = Arrays.asList(optional.get()).stream().map(o -> popularOferta(o))
					.collect(Collectors.toList());
			return Optional.of(listaOfertas);
		}
		return Optional.empty();
	}

	/**
	 * Método responsavel por popular as informações de ofertas
	 * 
	 * @param ofertaType
	 * @return
	 */
	private Oferta popularOferta(OfertaType ofertaType) {
		Oferta oferta = new Oferta();
		oferta.setCodigo(ofertaType.getCodigo());
		oferta.setNome(ofertaType.getNome());
		oferta.setDescricao(ofertaType.getDescricao());
		oferta.setCategoria(ofertaType.getCategoria());

		Optional<DescontoType[]> descontosAvulso = Optional.ofNullable(ofertaType.getDescontosAvulso());
		Optional<DescontoType[]> comboDescontos = Optional.ofNullable(ofertaType.getComboDescontos());

		// LISTA COMBO DESCONTOS
		if (comboDescontos.isPresent()) {
			oferta.setComboDescontos(Arrays.asList(comboDescontos.get()).stream().map(d -> popularDesconto(d))
					.collect(Collectors.toList()));
		}
		// LISTA DE DESCONTOS AVULSO
		if (descontosAvulso.isPresent()) {
			oferta.setListaDescontos(Arrays.asList(descontosAvulso.get()).stream().map(d -> popularDesconto(d))
					.collect(Collectors.toList()));
		}

		return oferta;
	}

	/**
	 * Método responsavel por popular as informações de desconto das ofertas
	 * 
	 * @param descontoType
	 * @return
	 */
	private DescontosOfertas popularDesconto(DescontoType descontoType) {
		DescontosOfertas desconto = new DescontosOfertas();
		desconto.setTipo(descontoType.getTipoDesconto());
		desconto.setValorOriginal(popularValor(descontoType.getValorOriginal()));
		desconto.setValorComDesconto(popularValor(descontoType.getValorComDesconto()));
		desconto.setValorDesconto(popularValor(descontoType.getValorDesconto()));
		desconto.setPercentualDesconto(popularPercentual(descontoType.getPercentualDesconto()));

		return desconto;
	}

	/**
	 * Método responsavel por formatar as informações de valores
	 * 
	 * @param valor
	 * @return
	 */
	private String popularValor(BigDecimal valor) {
		if (null != valor) {
			return valor.toString();
		}
		return DashboardUtils.EMPTY;
	}

	/**
	 * Método responsavel por popular as informações de percentual
	 * 
	 * @param percentual
	 * @return
	 */
	private String popularPercentual(BigDecimal percentual) {
		if (null != percentual) {
			String percentualFormatado = percentual.toString().concat(" %");
			return percentualFormatado;
		}
		return DashboardUtils.EMPTY;
	}

	@Override
	public Optional<List<OfertasInteract>> consultarListaOfertas() {
		LOG.info("CONSULTANDO A LISTA DE OFERTAS ");
		try {
			ConsultarListaOfertasResponseType response = osbService.consultarListaOfertas();
			return popularInfoListaOfertas(Optional.ofNullable(response.getOfertas()));

		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.info("OCORREU UM ERRO NA CONSULTA DA LISTA DE OFERTAS {}", ex);
			throw new RuntimeException("OCORREU UM ERRO NA CONSULTA DA LISTA DE OFERTAS");
		}
	}

	/**
	 * Método responsavel por popular as informações de ofertas (itens lista combo)
	 * @param optional
	 * @return
	 */
	private Optional<List<OfertasInteract>> popularInfoListaOfertas(
			Optional<br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.OfertaType[]> optional) {
		if (optional.isPresent()) {

			List<OfertasInteract> listaItens = Arrays.asList(optional.get()).stream()
					.map(oferta -> popularItemOferta(oferta)).collect(Collectors.toList());
			return Optional.of(listaItens);
		}
		return Optional.empty();
	}

	/**
	 * Método responsavel por popular as informações do item da oferta 
	 * @param oferta
	 * @return
	 */
	private OfertasInteract popularItemOferta(
			br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.OfertaType oferta) {

		OfertasInteract item = new OfertasInteract();
		item.setCodigo(oferta.getCodigo());
		item.setDescricao(oferta.getNome());
		return item;
	}

}
