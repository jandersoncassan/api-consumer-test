package br.com.cielo.dashboard.dto;

public class ItemGradeConfirmacaoRestricaoBoasVindasDTO {
	private String descricaoBanco;
	private String descricaoMcc;
	private String descricaoSolucaoCaptura;
	private String tipoManutencao;
	public String getDescricaoBanco() {
		return descricaoBanco;
	}
	public void setDescricaoBanco(String descricaoBanco) {
		this.descricaoBanco = descricaoBanco;
	}
	public String getDescricaoMcc() {
		return descricaoMcc;
	}
	public void setDescricaoMcc(String descricaoMcc) {
		this.descricaoMcc = descricaoMcc;
	}
	public String getDescricaoSolucaoCaptura() {
		return descricaoSolucaoCaptura;
	}
	public void setDescricaoSolucaoCaptura(String descricaoSolucaoCaptura) {
		this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
	}
	public String getTipoManutencao() {
		return tipoManutencao;
	}
	public void setTipoManutencao(String tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}
	
}
