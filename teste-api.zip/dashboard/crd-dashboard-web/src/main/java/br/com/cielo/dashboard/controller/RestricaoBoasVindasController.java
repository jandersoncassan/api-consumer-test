package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.cielo.credenciamento.dto.MccDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoRestricaoBoasVindasDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoRestricaoBoasVindasManutencaoDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoRestricaoBoasVindasManutencaoRequestDTO;
import br.com.cielo.credenciamento.enums.SolucaoCapturaEnum;
import br.com.cielo.dashboard.dto.ItemGradeConfirmacaoRestricaoBoasVindasDTO;
import br.com.cielo.dashboard.dto.ItemGradeRestricaoBoasVindasDTO;
import br.com.cielo.dashboard.dto.ParametrizacaoRestricaoBoasVindasAuxiliarDTO;
import br.com.cielo.dashboard.dto.RestricaoBoasVindasFiltroDTO;
import br.com.cielo.dashboard.model.Bancos;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IConsultarBancosService;
import br.com.cielo.dashboard.service.IParametrizacaoBoasVindasService;
import br.com.cielo.dashboard.service.IParametrizacaoMCCService;
import br.com.cielo.dashboard.utils.DashboardUtils;

@Controller
public class RestricaoBoasVindasController  {
	
	@Autowired
	private IConsultarBancosService consultarBancosService;
	
	@Autowired
	private IParametrizacaoMCCService parametrizacaoMCCService;
	
	@Autowired
	private IParametrizacaoBoasVindasService parametrizacaoBoasVindasService;
	
	private void carregarServicos(HttpSession session, Model model, Authentication authentication){
		
		carregarDominioMCC(session, model);
		carregarBancosParametrizados(session, model);
				
	}
	
	private void carregarDominioMCC(HttpSession session, Model model){
		
		List<MccDTO> listaDominioMcc = parametrizacaoMCCService.getListaDominiosMcc();
		
		Map<Integer, String> mapMccsTemp = (Map<Integer, String>) listaDominioMcc.stream()
				.collect(Collectors.toMap(MccDTO::getIdMcc, b -> b.getDescricaoMcc()));

		Map<Integer, String> mapMccs = mapMccsTemp.entrySet().stream()
				.sorted((m1, m2) -> m1.getKey().compareTo(m2.getKey()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
						(x, y) -> x, LinkedHashMap::new));
		
		model.addAttribute("mapDominioMcc", mapMccs);
		session.setAttribute("mapDominioMcc", mapMccs);
		
	}
	
	private void carregarBancosParametrizados(HttpSession session, Model model) {

		List<Object[]> retorno = consultarBancosService.getListarBancosDomiciliosParametrizados();

		List<Bancos> listaBancos = retorno.stream().map(i -> converterRetornoConsultarBancos(i))
				.collect(Collectors.toList());
		
		List<String> parametrizacoesVigentes = parametrizacaoBoasVindasService.obterParametrizacoesVigentes().stream()
				.map(x->x.getCodBanco())
				.collect(Collectors.toList());
				
		Map<Integer, String> mapBancosAtivosBoasVindas = listaBancos.stream()
				.filter(x->parametrizacoesVigentes
				.contains(String.valueOf(x.getCodigoBanco())))
				.collect(Collectors.toMap(Bancos::getCodigoBanco, Bancos::getDescricaoBanco,
						(x, y) -> x, LinkedHashMap::new));
		
		model.addAttribute("mapBancosAtivosBoasVindas", mapBancosAtivosBoasVindas);
		session.setAttribute("mapBancosAtivosBoasVindas", mapBancosAtivosBoasVindas);	
	}
	
	private Bancos converterRetornoConsultarBancos(Object[] valores) {

		Bancos item = new Bancos();
		item.setCodigoBanco(Integer.parseInt(String.valueOf(valores[0])));
		item.setDescricaoBanco(String.valueOf(valores[1]));
		return item;
	}
	
	private void inicializarDTO(HttpSession session, Model model){
		
		RestricaoBoasVindasFiltroDTO filtroRestricaoBoasVindas = new RestricaoBoasVindasFiltroDTO();
		
		session.setAttribute("filtroRestricaoBoasVindasAux", filtroRestricaoBoasVindas);
		model.addAttribute("filtroRestricaoBoasVindasAux", filtroRestricaoBoasVindas);
		
		ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrizacaoRestricaoBoasVindasAux = new ParametrizacaoRestricaoBoasVindasAuxiliarDTO();
		
		session.setAttribute("parametrizacaoRestricaoBoasVindasAux", parametrizacaoRestricaoBoasVindasAux);
		model.addAttribute("parametrizacaoRestricaoBoasVindasAux", parametrizacaoRestricaoBoasVindasAux);
		
	}
	
	@RequestMapping("/initRestricaoBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String initRestricaoBoasVindas(HttpSession session, Model model, Authentication authentication){
		
		inicializarDTO(session, model);
		
		carregarServicos(session, model, authentication);
		
		return NavigationDashBoard.PARAMETRIZACAO_RESTRICAO_BOAS_VINDAS;
		
	}
	
	@RequestMapping("/consultarRestricaoBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String consultarRestricaoBoasBindas(@ModelAttribute("filtroRestricaoBoasVindasAux") @Valid RestricaoBoasVindasFiltroDTO filtroRestricaoBoasVindas,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication){

		montarGrade(filtroRestricaoBoasVindas ,session, model);
				
		return NavigationDashBoard.PARAMETRIZACAO_RESTRICAO_BOAS_VINDAS;
	}
	
	@SuppressWarnings("unchecked")
	private void montarGrade(RestricaoBoasVindasFiltroDTO filtroRestricaoBoasVindas, HttpSession session, Model model) {
		
		Map<Integer, String> mapBancosAtivosBoasVindas = (Map<Integer, String>) session.getAttribute("mapBancosAtivosBoasVindas");
		
		Map<Integer, String> mapDominioMcc = (Map<Integer, String>) session.getAttribute("mapDominioMcc");
    	Map<Integer, String> mapSolucoesCaptura = Arrays.asList(SolucaoCapturaEnum.values()).stream()
    			.collect(Collectors.toMap(SolucaoCapturaEnum::getCodigo , SolucaoCapturaEnum::getDescricaoParaCliente,
    			(id, descricao) -> id, HashMap::new));
		
		List<String> bancosPesquisa = filtroRestricaoBoasVindas.getCodigosBanco();
		List<Integer> mccsPesquisa = filtroRestricaoBoasVindas.getCodigosMcc();
		List<Integer> solucoesCapturaPesquisa = filtroRestricaoBoasVindas.getCodigosSolucaoCaptura();
		
		if (DashboardUtils.isListEmptyOrNull(bancosPesquisa)) {
			bancosPesquisa = mapBancosAtivosBoasVindas.keySet().stream().map(x -> String.valueOf(x)).collect(Collectors.toList());
		}
			
		if (DashboardUtils.isListEmptyOrNull(mccsPesquisa)) {
			mccsPesquisa = mapDominioMcc.keySet().stream().collect(Collectors.toList());
		}
			
		if (DashboardUtils.isListEmptyOrNull(solucoesCapturaPesquisa)) {

			solucoesCapturaPesquisa = mapSolucoesCaptura.keySet().stream().collect(Collectors.toList());
		}
		
		List<ParametrizacaoRestricaoBoasVindasDTO> restricoesVigentes = parametrizacaoBoasVindasService.obterRestricoesVigentes(
				filtroRestricaoBoasVindas.getCodigosBanco(), 
				filtroRestricaoBoasVindas.getCodigosMcc(), 
				filtroRestricaoBoasVindas.getCodigosSolucaoCaptura());

		List<String> restricoesAtivas = new ArrayList<String>(); 
		
		restricoesAtivas.addAll(restricoesVigentes.stream()
				.map(x -> x.getCodigoBanco() + "_" + x.getCodigoMcc() + "_" + x.getCodigoSolucaoCaptura())
				.collect(Collectors.toList()));		
		
		List<ItemGradeRestricaoBoasVindasDTO> itensGrade = new ArrayList<ItemGradeRestricaoBoasVindasDTO>();
		
		for(String codBanco : bancosPesquisa) {
			for (Integer codMcc : mccsPesquisa) {
				for (Integer codSolucao : solucoesCapturaPesquisa){
					
					ItemGradeRestricaoBoasVindasDTO itemGrade = new ItemGradeRestricaoBoasVindasDTO();
					
					itemGrade.setCodigoBanco(codBanco);
					itemGrade.setDescricaoBanco(mapBancosAtivosBoasVindas.get(Integer.parseInt(codBanco)));
					itemGrade.setCodigoMcc(codMcc);
					itemGrade.setDescricaoMcc(mapDominioMcc.get(codMcc));
					itemGrade.setCodigoSolucaoCaptura(codSolucao);
					itemGrade.setDescricaoSolucaoCaptura(mapSolucoesCaptura.get(codSolucao));
					
					if (filtroRestricaoBoasVindas.getFiltroAtivo() == 0){
						
						itensGrade.add(itemGrade);	
					}
					
					if ((filtroRestricaoBoasVindas.getFiltroAtivo() == 1) &&
						(restricoesAtivas.contains(itemGrade.getIdRestricaoBoasVindas()))) {
							
						itensGrade.add(itemGrade);
					}
					
					if ((filtroRestricaoBoasVindas.getFiltroAtivo() == 2) &&
							(!restricoesAtivas.contains(itemGrade.getIdRestricaoBoasVindas()))) {
								
							itensGrade.add(itemGrade);
						
					}
					
				}
			}
		}
		
		ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrizacaoRestricaoBoasVindasAux = new ParametrizacaoRestricaoBoasVindasAuxiliarDTO();
		
		parametrizacaoRestricaoBoasVindasAux.setChavesRestricoesBoasVindasAtivas(restricoesAtivas);
		parametrizacaoRestricaoBoasVindasAux.setRestricoesBoasVindas(itensGrade);
		
		session.setAttribute("parametrizacaoRestricaoBoasVindasAux", parametrizacaoRestricaoBoasVindasAux);
		session.setAttribute("parametrizacaoRestricaoBoasVindasAuxOrig", parametrizacaoRestricaoBoasVindasAux);
		session.setAttribute("filtroRestricaoBoasVindasAux", filtroRestricaoBoasVindas);
		model.addAttribute("filtroRestricaoBoasVindasAux", session.getAttribute("filtroRestricaoBoasVindasAux"));
		model.addAttribute("parametrizacaoRestricaoBoasVindasAux", parametrizacaoRestricaoBoasVindasAux);
		
	}
	
	@RequestMapping("/identificarAtualizacaoRestricaoBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR)
	public String identificarAtualizacaoRestricaoBoasVindas(@ModelAttribute("parametrizacaoRestricaoBoasVindasAux") @Valid ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrosRestricaoBoasVindas,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication) {
		
		Map<Integer, String> mapBancosAtivosBoasVindas = (Map<Integer, String>) session.getAttribute("mapBancosAtivosBoasVindas");
		
		Map<Integer, String> mapDominioMcc = (Map<Integer, String>) session.getAttribute("mapDominioMcc");
    	Map<Integer, String> mapSolucoesCaptura = Arrays.asList(SolucaoCapturaEnum.values()).stream()
    			.collect(Collectors.toMap(SolucaoCapturaEnum::getCodigo , SolucaoCapturaEnum::getDescricaoParaCliente,
    			(id, descricao) -> id, HashMap::new));
		
		List<ParametrizacaoRestricaoBoasVindasManutencaoDTO> listAtualizacoes = identificarAtualizacoes(parametrosRestricaoBoasVindas, session, model);

		List<ItemGradeConfirmacaoRestricaoBoasVindasDTO> listConfirmacao = listAtualizacoes.stream()
				.map(item -> toItemConfirmacaoDTO(item, mapBancosAtivosBoasVindas, mapDominioMcc, mapSolucoesCaptura))
				.collect(Collectors.toList());
		
		ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrizacoesAuxiliar = (ParametrizacaoRestricaoBoasVindasAuxiliarDTO) session.getAttribute("parametrizacaoRestricaoBoasVindasAux");
		
		parametrosRestricaoBoasVindas.setRestricoesBoasVindas(parametrizacoesAuxiliar.getRestricoesBoasVindas());

		session.setAttribute("listAtualizacoes", listAtualizacoes);
		model.addAttribute("listConfirmacao", listConfirmacao);
		model.addAttribute("filtroRestricaoBoasVindasAux", session.getAttribute("filtroRestricaoBoasVindasAux"));
		model.addAttribute("parametrizacaoRestricaoBoasVindasAux", parametrosRestricaoBoasVindas);
		
		return NavigationDashBoard.PARAMETRIZACAO_RESTRICAO_BOAS_VINDAS;
	}
	
	private ItemGradeConfirmacaoRestricaoBoasVindasDTO toItemConfirmacaoDTO(ParametrizacaoRestricaoBoasVindasManutencaoDTO item,
			Map<Integer, String> mapBancos, Map<Integer, String> mapDominioMcc, Map<Integer, String> mapSolucoesCaptura) {
		
		
		ItemGradeConfirmacaoRestricaoBoasVindasDTO retorno = new ItemGradeConfirmacaoRestricaoBoasVindasDTO();
		
		retorno.setDescricaoBanco(mapBancos.get(Integer.valueOf(item.getCodigoBanco())));
		retorno.setDescricaoMcc(mapDominioMcc.get(item.getCodigoMcc()));
		retorno.setDescricaoSolucaoCaptura(mapSolucoesCaptura.get(item.getCodigoSolucaoCaptura()));
		
		if (item.isAtivo()){
			retorno.setTipoManutencao("Inclusão");
		} else {
			retorno.setTipoManutencao("Exclusão");
		}
			
		return retorno;
		
	}
	
	
	private List<ParametrizacaoRestricaoBoasVindasManutencaoDTO> identificarAtualizacoes(ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrosRestricaoBoasVindas,
			HttpSession session, Model model) {

		ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrosRestricaoBoasVindasOrig = (ParametrizacaoRestricaoBoasVindasAuxiliarDTO) session.getAttribute("parametrizacaoRestricaoBoasVindasAuxOrig");
		
		List<ParametrizacaoRestricaoBoasVindasManutencaoDTO> listaManutencoes = new ArrayList<ParametrizacaoRestricaoBoasVindasManutencaoDTO>();

		List<String> chavesAtivasOrig = new ArrayList<String>();
		
		if (parametrosRestricaoBoasVindasOrig.getChavesRestricoesBoasVindasAtivas() != null){
			chavesAtivasOrig.addAll(parametrosRestricaoBoasVindasOrig.getChavesRestricoesBoasVindasAtivas());
		}
		
		List<String> chavesAtivas = new ArrayList<String>();
		if (parametrosRestricaoBoasVindas.getChavesRestricoesBoasVindasAtivas() != null) {
			chavesAtivas.addAll(parametrosRestricaoBoasVindas.getChavesRestricoesBoasVindasAtivas());
		}
		
		listaManutencoes.addAll(chavesAtivasOrig.stream()
				.filter(x -> !chavesAtivas.contains(x))
				.map(x -> convertToManutencaoDTO(x, false))
				.collect(Collectors.toList()));

		listaManutencoes.addAll(chavesAtivas.stream()
				.filter(x -> !chavesAtivasOrig.contains(x))
				.map(x -> convertToManutencaoDTO(x, true))
				.collect(Collectors.toList()));
		
		return listaManutencoes;
	}
	
	@RequestMapping("/atualizarRestricaoBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String atualizarRestricaoBoasVindas(@ModelAttribute("parametrizacaoRestricaoBoasVindasAux") @Valid ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrosRestricaoBoasVindas,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication){

		List<ParametrizacaoRestricaoBoasVindasManutencaoDTO> listAtualizacoes = (List<ParametrizacaoRestricaoBoasVindasManutencaoDTO>) session.getAttribute("listAtualizacoes");		
		
		ParametrizacaoRestricaoBoasVindasManutencaoRequestDTO request = new ParametrizacaoRestricaoBoasVindasManutencaoRequestDTO();
		
		request.setManutencoesRestricaoBoasVindas(listAtualizacoes);
		request.setUsuario((String) session.getAttribute("username"));
		
		try{
		
			parametrizacaoBoasVindasService.atualizarRestricoes(request);
			
		}		
		catch (Exception e) {
			model.addAttribute("error", "Erro durante a atualização: " + e.getMessage());
			return NavigationDashBoard.PARAMETRIZACAO_RESTRICAO_BOAS_VINDAS;
		}
				
				
		RestricaoBoasVindasFiltroDTO filtroRestricaoBoasVindas = (RestricaoBoasVindasFiltroDTO) session.getAttribute("filtroRestricaoBoasVindasAux");
		
		montarGrade(filtroRestricaoBoasVindas, session, model);
		
		model.addAttribute("success", "Atualização realizada com sucesso!");
		
		return NavigationDashBoard.PARAMETRIZACAO_RESTRICAO_BOAS_VINDAS;
	}
	
	
	private ParametrizacaoRestricaoBoasVindasManutencaoDTO convertToManutencaoDTO(String chaveRestricaoBoasVindas, boolean ativo){
		
		String[] valoresChave = chaveRestricaoBoasVindas.split("_");
		ParametrizacaoRestricaoBoasVindasManutencaoDTO dto = new ParametrizacaoRestricaoBoasVindasManutencaoDTO();
		dto.setCodigoBanco(valoresChave[0]);
		dto.setCodigoMcc(Integer.parseInt(valoresChave[1]));
		dto.setCodigoSolucaoCaptura(Integer.parseInt(valoresChave[2]));
		dto.setAtivo(ativo);
		return dto;
	}
	
	
	@RequestMapping("/exportRestricaoBoasVindas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_EXPORTAR)
	public String exportRestricaoBoasVindas(@ModelAttribute("filtroRestricaoBoasVindasAux") @Valid RestricaoBoasVindasFiltroDTO filtroRestricaoBoasVindas,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication, HttpServletResponse response) throws IOException{

		
		XSSFWorkbook wb = new XSSFWorkbook();
		String[] hearders = new String[] {"BANCO"
										, "CÓD. MCC"
										, "RAMO DE ATIVIDADE"
										, "SOLUÇÃO DE CAPTURA"
										, "SITUAÇÃO"
										};
		try {
			
			ParametrizacaoRestricaoBoasVindasAuxiliarDTO parametrosRestricaoBoasVindas = (ParametrizacaoRestricaoBoasVindasAuxiliarDTO) session.getAttribute("parametrizacaoRestricaoBoasVindasAux");

			

			List<ItemGradeRestricaoBoasVindasDTO> listaItens = parametrosRestricaoBoasVindas.getRestricoesBoasVindas();
			
			XSSFSheet sheet = wb.createSheet();
			XSSFRow row = sheet.createRow(0);

			/* create style */
			XSSFCellStyle style = wb.createCellStyle();
			XSSFFont font = wb.createFont();
			font.setBold(Boolean.TRUE);
			font.setFontHeightInPoints((short) 12);
			style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setFont(font);
			
			for (int i = 0; i < hearders.length; i++) {
				XSSFCell cell = row.createCell(i);
				cell.setCellValue(hearders[i]);
				cell.setCellStyle(style);
				sheet.setColumnWidth(i, i == 0 || i == 1 ? 2500 : 6000);
			}
			
			List<String> chavesAtivas = new ArrayList<String>();
			
			if (parametrosRestricaoBoasVindas.getChavesRestricoesBoasVindasAtivas() != null) {
				chavesAtivas.addAll(parametrosRestricaoBoasVindas.getChavesRestricoesBoasVindasAtivas());
			}
			
			if (!listaItens.isEmpty()) {
				for (int i = 0; i < listaItens.size(); i++) {
					
					XSSFRow rowConteudo = sheet.createRow(i + 1);
					
					rowConteudo.createCell((int) 0).setCellValue(listaItens.get(i).getDescricaoBanco());
					rowConteudo.createCell((int) 1).setCellValue(listaItens.get(i).getCodigoMcc()); 
					rowConteudo.createCell((int) 2).setCellValue(listaItens.get(i).getDescricaoMcc());
					rowConteudo.createCell((int) 3).setCellValue(listaItens.get(i).getDescricaoSolucaoCaptura());
					if (chavesAtivas.contains(listaItens.get(i).getIdRestricaoBoasVindas())) {
						rowConteudo.createCell((int) 4).setCellValue("RESTRITO");
					}
					else{
						rowConteudo.createCell((int) 4).setCellValue("PERMITIDO");
					}

				}
			}
			DashboardUtils.contentTypeForBrowser(response, wb, "RELATORIO_RESTRICAO_BOAS_VINDAS");
			
		} catch (Exception e) {
			throw e;
		}
		
		
		return NavigationDashBoard.PARAMETRIZACAO_RESTRICAO_BOAS_VINDAS;
	}
	
	
	
	
	
	

}
