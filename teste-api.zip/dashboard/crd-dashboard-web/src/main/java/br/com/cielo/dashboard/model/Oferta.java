package br.com.cielo.dashboard.model;

import java.util.List;

/**
 * Classe model responsavel por representar as informações da oferta
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 */
/**
 * @author janderson
 *
 */
public class Oferta {

	private String codigo;
	private String nome;
	private String descricao;
	private String categoria;	
	//DESCONTO AVULSOS
	private List<DescontosOfertas> listaDescontos;
	//COMBO DESCONTOS
	private List<DescontosOfertas> comboDescontos;
	
	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the categoria
	 */
	public String getCategoria() {
		return categoria;
	}
	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	/**
	 * @return the listaDescontos
	 */
	public List<DescontosOfertas> getListaDescontos() {
		return listaDescontos;
	}
	/**
	 * @param listaDescontos the listaDescontos to set
	 */
	public void setListaDescontos(List<DescontosOfertas> listaDescontos) {
		this.listaDescontos = listaDescontos;
	}
	/**
	 * @return the comboDescontos
	 */
	public List<DescontosOfertas> getComboDescontos() {
		return comboDescontos;
	}
	/**
	 * @param comboDescontos the comboDescontos to set
	 */
	public void setComboDescontos(List<DescontosOfertas> comboDescontos) {
		this.comboDescontos = comboDescontos;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Oferta [codigo=" + codigo + ", nome=" + nome + ", descricao=" + descricao + ", categoria=" + categoria
				+ ", listaDescontos=" + listaDescontos + ", comboDescontos=" + comboDescontos + "]";
	}
	
	
}
