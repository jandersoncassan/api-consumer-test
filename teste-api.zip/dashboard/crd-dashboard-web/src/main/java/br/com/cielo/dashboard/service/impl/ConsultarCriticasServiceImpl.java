/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarCriticasServiceRemote;
import br.com.cielo.dashboard.service.IConsultarCriticasService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarCriticasServiceImpl implements IConsultarCriticasService {

	@Resource(mappedName = "ConsultarCriticasService#br.com.cielo.credenciamento.service.dashboard.ConsultarCriticasServiceRemote")
	private ConsultarCriticasServiceRemote consultarCriticasServiceRemote;
	
	/**
	 * Método: Retornar as criticas relacionadas a proposta
	 * @param proposta
	 */
	public List<Object[]> getListaCriticasByProposta(Long proposta) {
		return consultarCriticasServiceRemote.getListaCriticasByProposta(proposta);
	}
	/**
	 * Método:Retorna todoas as criticas parametriza
	 * @return
	 */
	public List<Object> getListarCriticas() {
		return consultarCriticasServiceRemote.getListarCriticas();
	}
}
