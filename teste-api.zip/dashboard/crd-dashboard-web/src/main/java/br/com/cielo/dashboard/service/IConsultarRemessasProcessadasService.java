/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarRemessasProcessadasService {
	/**
	 * Método: Consultar Remessas
	 * @param codigoBanco
	 * @param periodoInicial
	 * @param periodoFinal
	 * @return
	 */
	List<Object> getConsultarRemessasProcessadas(final Integer codigoBanco, final Integer codigoStatus, final String periodoInicial, final String periodoFinal);
	/**
	 * Método: Consultar Remessas
	 * @param codigoBanco
	 * @param periodoInicial
	 * @param periodoFinal
	 * @return
	 */
	List<Object> getConsultarRejeitado(final Integer codigoBanco, final String periodoInicial, final String periodoFinal);
	
}
