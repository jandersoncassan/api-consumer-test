package br.com.cielo.dashboard.dto;

import java.io.Serializable;
import java.util.List;

public class RestricaoBoasVindasFiltroDTO implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> codigosBanco;
	private List<Integer> codigosMcc;
	private List<Integer> codigosSolucaoCaptura;
	private Integer filtroAtivo;
	
	public List<String> getCodigosBanco() {
		return codigosBanco;
	}
	public void setCodigosBanco(List<String> codigosBanco) {
		this.codigosBanco = codigosBanco;
	}
	public List<Integer> getCodigosMcc() {
		return codigosMcc;
	}
	public void setCodigosMcc(List<Integer> codigosMcc) {
		this.codigosMcc = codigosMcc;
	}
	public List<Integer> getCodigosSolucaoCaptura() {
		return codigosSolucaoCaptura;
	}
	public void setCodigosSolucaoCaptura(List<Integer> codigosSolucaoCaptura) {
		this.codigosSolucaoCaptura = codigosSolucaoCaptura;
	}
	public Integer getFiltroAtivo() {
		return filtroAtivo;
	}
	public void setFiltroAtivo(Integer filtroAtivo) {
		this.filtroAtivo = filtroAtivo;
	}
	
}
