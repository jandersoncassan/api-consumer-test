package br.com.cielo.dashboard.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;


/**
 * Classe Singleton responsavel pelo load dos arquivos de proprieadades
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 2.0.0
 */
@Component
@EnableScheduling
public class DashboardFile {
	
	private static final Logger LOG = LogManager.getLogger(DashboardFile.class);

	private static final String TIME_ZONE = "America/Sao_Paulo";
	
	private static final String ARQUIVO = "/application.properties";

	private Properties external;

	private Properties internal;
	
	private static DashboardFile instance;
	
	private DashboardFile() {
		// CARREGAMOS O ARQUIVO PROPERTIES
		try {
			init();
		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO CRIAR A INSTACIA DO SINGLETON");
			throw new RuntimeException("OCORREU UM ERRO AO CRIAR A INSTACIA DO SINGLETON", ex);
		}
	}
	
	@Scheduled(cron = "0 40 * * * *", zone = TIME_ZONE)
	private void init() throws IOException {
		LOG.info("CARREGAR ARQUIVO PROPRIEDADE - CRD-WEB  []", ARQUIVO);
		internal = new Properties();
		internal.load(getClass().getResourceAsStream(ARQUIVO));
		carregarProperties();
	}

	/**
	 * Método responsavel por carregar o arquivo de configurações no diretório do CRD
	 * @throws IOException 
	 * @throws FileNotFoundException 
	 */
	private void carregarProperties() throws FileNotFoundException, IOException {
		Path arquivo = Paths.get(String.format("%s%s%s", internal.getProperty("path").trim(), File.separator, internal.get("arquivo")));
		external = new Properties();
		LOG.info("CARREGANDO ARQUIVO ... []", arquivo.toFile());
		external.load(new FileInputStream(arquivo.toFile()));
	}
	
	/**
	 * Recupera a instância de Simulador File
	 * 
	 * @return
	 */
	public static DashboardFile getInstance() {
		if (null == instance) {
			instance = new DashboardFile();
		}
		return instance;
	}
	/**
	 * Método responsavel por obter as propriedades do arquivo interno
	 * 
	 * @param key
	 * @return String
	 */
	public String getMessageInternal(String key) {
//		LOG.debug("getMessageInternal="+internal.getProperty(key));
		return (internal.getProperty(key));
	}
	/**
	 * Método responsavel por obter as propriedades do arquivo externo
	 * 
	 * @param key
	 * @return String
	 */
	public String getMessageExternal(String key) {
//		LOG.debug("getMessageExternal="+external.getProperty(key));
		return (external.getProperty(key));
	}
}
