/**
 * 
 */
package br.com.cielo.dashboard.service;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarDetalhePropostaService {
	/**
	 * Método: Obter Detalhe da proposta
	 * @param numeroProposta
	 * @return
	 */
	public Object[] getDetalheProposta(final Long numeroProposta);
}
