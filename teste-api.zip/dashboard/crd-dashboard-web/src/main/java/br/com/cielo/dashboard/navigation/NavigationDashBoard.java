/**
 * 
 */
package br.com.cielo.dashboard.navigation;

/**
 * @author dcarneiro
 *
 */
public class NavigationDashBoard {

	/*INICIAL*/
	public static final String LOGIN = "login/login";
	public static final String HOME = "home";
	
	/*QUADRO RESUMO*/
	public static final String DASHBOARD_MENSAL = "dashboard/dashboard_mensal";
	public static final String DASHBOARD_ANUAL = "dashboard/dashboard_anual";
	public static final String DASHBOARD_ETAPAS = "dashboard/dashboard_etapas";
    public static final String DASHBOARD_TV = "dashboard/dashboard_tv";
	
	/*CONSULTAR REMESSAS*/
	public static final String CONSULTAR_REMESSA = "consultas/remessas";

	/*CONSULTA PROPOSTA*/
	public static final String CONSULTAR_PROPOSTA = "consultas/propostas"; 
	public static final String CONSULTAR_DETALHE_PROPOSTA = "consultas/detalhe_proposta";
	
	/* APLICACAO CREDENCIAMENTO EXTERNAS*/
	public static final String PAGE_FRAME_CENTRAL = "central/central";
	public static final String PAGE_FRAME_SIMULADOR = "simulador/simulador";
	
	/*OFERTAS*/
	public static final String CONSULTAR_OFERTAS = "ofertas/ofertas";
	
	/* PAGINA WELCOME */
	public static final String PAGE_WELCOME = "welcome/welcome";
	
	/* ACESSO NÃO PERMITIDO - NAO POSSUI PRIVILEGIOS*/
	public static final String PAGE_ACCESS_DENIED = "access_error/access_denied";
	

	/*CADASTRO PARAMETRIZACAO MCC */
	public static final String CADASTRO_MCC = "parametros/mcc";
	
	/*CADASTRO PARAMETRIZACAO RESTRICAO SOLUCAO CAPTURA*/
	public static final String PARAMETRIZACAO_SOLUCOES_CAPTURA_PERMITIDAS = "parametros/solucoes_captura_permitidas";
	
	/*CADASTRO PARAMETRIZACAO BOAS VINDAS */
	public static final String PARAMETRIZACAO_BOAS_VINDAS = "parametros/boas_vindas";
	
	/*CADASTRO PARAMETRIZACAO RESTRICAAO BOAS VINDAS */
	public static final String PARAMETRIZACAO_RESTRICAO_BOAS_VINDAS = "parametros/restricao_boas_vindas";

	/*CADASTRO PARAMETRIZACAO VALIDACAO DOMICILIO BANCARIO */
	public static final String PARAMETRIZACAO_VALIDACAO_DOMICILIO_BANCARIO = "parametros/validacao_domicilio_bancario";

}
