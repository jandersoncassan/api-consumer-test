package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.credenciamento.dto.FerramentaDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoDomicilioBancarioDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoDomicilioBancarioManutencaoDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoDomicilioBancarioManutencaoRequestDTO;
import br.com.cielo.credenciamento.dto.SituacaoCadastralDTO;
import br.com.cielo.credenciamento.enums.SolucaoCapturaEnum;
import br.com.cielo.dashboard.dto.ItemGradeConfirmacaoValidacaoDomicilioBancarioDTO;
import br.com.cielo.dashboard.dto.ItemGradeValidacaoDomicilioBancarioDTO;
import br.com.cielo.dashboard.dto.ValidacaoDomicilioBancarioAuxiliarDTO;
import br.com.cielo.dashboard.dto.ValidacaoDomicilioBancarioFiltroDTO;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IConsultarSituacaoCadastralService;
import br.com.cielo.dashboard.service.IFerramentaService;
import br.com.cielo.dashboard.service.IParametrizacaoDomicilioBancarioService;
import br.com.cielo.dashboard.utils.DashboardUtils;
import br.com.cielo.dashboard.validator.ValidacaoDomicilioBancarioValidator;

@Controller
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class ValidacaoDomicilioBancarioController {

	private static final String DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO = "filtroValidacaoDomicilioBancario";
	private static final String DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO = "validacaoDomicilioBancario";
	private static final String DTO_LISTA_MANUTENCOES_VALIDACAO_DOMICILIO_BANCARIO = "manutencoesValidacaoDomicilioBancario";
	private static final String DTO_LISTA_CONFIRMACAO_VALIDACAO_DOMICILIO_BANCARIO = "listaConfirmacaoValidacaoDomicilioBancario";

	private static final String MAP_FERRAMENTAS = "mapFerramentas";
	private static final String MAP_SOLUCAO_CAPTURA = "mapSolucaoCaptura";
	private static final String MAP_PARAMETRIZACOES_ORIGINAIS = "mapParametrizacaoOriginal";

	private static final String LIST_SITUACAO_CADASTRAL = "listaSituacaoCadastral";

	@Autowired
	private IFerramentaService ferramentaService;

	@Autowired
	private IConsultarSituacaoCadastralService consultarSituacaoCadastralService;

	@Autowired
	private IParametrizacaoDomicilioBancarioService parametrizacaoDomicilioBancarioService;
	
	@Autowired
	private ValidacaoDomicilioBancarioValidator validator;

	@RequestMapping("/initValidacaoDomicilioBancario")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String initValidacaoDomicilioBancario(Model model, HttpSession session, Authentication authentication)
			throws IOException {

		inicilizarDTO(model, session);

		carregarServicos(model, session);

		return NavigationDashBoard.PARAMETRIZACAO_VALIDACAO_DOMICILIO_BANCARIO;
		
	}

	private void inicilizarDTO(Model model, HttpSession session) {

		ValidacaoDomicilioBancarioFiltroDTO filtro = new ValidacaoDomicilioBancarioFiltroDTO();

		model.addAttribute(this.DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO, filtro);
		session.setAttribute(this.DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO, filtro);

		ValidacaoDomicilioBancarioAuxiliarDTO parametrizacoes = new ValidacaoDomicilioBancarioAuxiliarDTO();

		model.addAttribute(this.DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO, parametrizacoes);
		session.setAttribute(this.DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO, parametrizacoes);

	}

	private void carregarServicos(Model model, HttpSession session) {

		carregarFerramentas(model, session);
		carregarSolucaoCaptura(model, session);
		carregarSituacaoCadastral(model, session);
	}

	private void carregarFerramentas(Model model, HttpSession session) {

		List<FerramentaDTO> listaFerramentasDTO = ferramentaService.getFerramentasPorIntervaloDeCodigo(2, 89);

		Map<Integer, String> mapFerramentas = listaFerramentasDTO.stream().collect(Collectors.toMap(
				FerramentaDTO::getCodigo, FerramentaDTO::getDescricao, (oldValue, newValue) -> oldValue, HashMap::new));

		session.setAttribute(this.MAP_FERRAMENTAS, mapFerramentas);
		model.addAttribute(this.MAP_FERRAMENTAS, mapFerramentas);
	}

	private void carregarSolucaoCaptura(Model model, HttpSession session) {

		Map<Integer, String> mapSolucoesCaptura = Arrays.asList(SolucaoCapturaEnum.values()).stream()
				.collect(Collectors.toMap(SolucaoCapturaEnum::getCodigo, SolucaoCapturaEnum::getDescricaoParaCliente,
						(id, descricao) -> id, HashMap::new));

		session.setAttribute(this.MAP_SOLUCAO_CAPTURA, mapSolucoesCaptura);
		model.addAttribute(this.MAP_SOLUCAO_CAPTURA, mapSolucoesCaptura);
	}

	private void carregarSituacaoCadastral(Model model, HttpSession session) {

		List<SituacaoCadastralDTO> retorno = (List<SituacaoCadastralDTO>) session
				.getAttribute(this.LIST_SITUACAO_CADASTRAL);

		if (retorno == null) {
			retorno = consultarSituacaoCadastralService.listarSituacaoCadastral().stream()
					.filter(item -> this.situacaoCadastralValidaDomicilioBancario(item.getCodigo()))
					.collect(Collectors.toList());
			session.setAttribute(this.LIST_SITUACAO_CADASTRAL, retorno);
		}

		model.addAttribute(this.LIST_SITUACAO_CADASTRAL, retorno);

	}
	
	private Boolean situacaoCadastralValidaDomicilioBancario(String codSituacaoCadastral) {
		
		if ((codSituacaoCadastral.equals("O")) ||
			(codSituacaoCadastral.equals("C")) || 
			(codSituacaoCadastral.equals("P"))) {
			return true;
		}
		else {
			return false;
		}
	}

	@RequestMapping("/consultarValidacaoDomicilioBancario")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String consultarValidacaoDomicilioBancario(
			@ModelAttribute("filtroValidacaoDomicilioBancario") @Valid ValidacaoDomicilioBancarioFiltroDTO filtro,
			BindingResult bindingResult, Model model, HttpSession session, Authentication authentication) {

		session.removeAttribute(this.DTO_LISTA_MANUTENCOES_VALIDACAO_DOMICILIO_BANCARIO);
		
		montarGrade(filtro, model, session);

		return NavigationDashBoard.PARAMETRIZACAO_VALIDACAO_DOMICILIO_BANCARIO;
	}

	private void montarGrade(ValidacaoDomicilioBancarioFiltroDTO filtro, Model model, HttpSession session) {

		Map<Integer, String> mapFerramentas = (Map<Integer, String>) session.getAttribute(this.MAP_FERRAMENTAS);
		Map<Integer, String> mapSolucao = (Map<Integer, String>) session.getAttribute(this.MAP_SOLUCAO_CAPTURA);

		List<Integer> filtroFerramentas = new ArrayList<Integer>();
		List<Integer> filtroSolucao = new ArrayList<Integer>();

		if (DashboardUtils.isListEmptyOrNull(filtro.getCodigosFerramenta())) {
			filtroFerramentas.addAll(mapFerramentas.keySet());
		} else {
			filtroFerramentas.addAll(filtro.getCodigosFerramenta());
		}

		if (DashboardUtils.isListEmptyOrNull(filtro.getCodigosSolucaoCaptura())) {
			filtroSolucao.addAll(mapSolucao.keySet());
		} else {
			filtroSolucao.addAll(filtro.getCodigosSolucaoCaptura());
		}

		List<ParametrizacaoDomicilioBancarioDTO> parametrizacoesExistentes = parametrizacaoDomicilioBancarioService
				.consultar(filtro.getCodigosFerramenta(), filtro.getCodigosSolucaoCaptura());

		Map<String, ParametrizacaoDomicilioBancarioDTO> mapParametrizacoes = parametrizacoesExistentes.stream()
				.collect(Collectors.toMap(
						item -> gerarChaveParametrizacao(item.getCodFerramenta(), item.getCodSolucaoCaptura()),
						item -> item));

		List<ItemGradeValidacaoDomicilioBancarioDTO> itensGrade = new ArrayList<ItemGradeValidacaoDomicilioBancarioDTO>();

		for (Integer codFerramenta : filtroFerramentas) {
			for (Integer codSolucao : filtroSolucao) {
				ItemGradeValidacaoDomicilioBancarioDTO item = new ItemGradeValidacaoDomicilioBancarioDTO();
				item.setCodigoFerramenta(codFerramenta);
				item.setDescricaoFerramenta(mapFerramentas.get(codFerramenta));
				item.setCodigoSolucaoCaptura(codSolucao);
				item.setDescricaoSolucaoCaptura(mapSolucao.get(codSolucao));

				if (mapParametrizacoes.containsKey(item.getIdValidacaoDomicilioBancario())) {
					item.setCodigoSituacaoCadastral(
							mapParametrizacoes.get(item.getIdValidacaoDomicilioBancario()).getCodSituacaoCadastral());
				}
				
				if (filtro.getFiltroAtivo() == 0) {
					itensGrade.add(item);
				}
				
				if ((filtro.getFiltroAtivo() == 1) &&
					(mapParametrizacoes.containsKey(item.getIdValidacaoDomicilioBancario()))) {
					itensGrade.add(item);
				}

				if ((filtro.getFiltroAtivo() == 2) &&
					(!mapParametrizacoes.containsKey(item.getIdValidacaoDomicilioBancario()))) {
					itensGrade.add(item);
				}
				
			}
		}

		ValidacaoDomicilioBancarioAuxiliarDTO paramAuxiliar = new ValidacaoDomicilioBancarioAuxiliarDTO();
		paramAuxiliar.setListaValidacaoDomicilioBancario(itensGrade);

		paramAuxiliar.setParametrizacoesAtivas(parametrizacoesExistentes.stream()
				.map(x -> gerarChaveParametrizacao(x.getCodFerramenta(), x.getCodSolucaoCaptura()))
				.collect(Collectors.toList()));

		paramAuxiliar.setValidacaoDomicilioAtivos(parametrizacoesExistentes.stream().filter(x -> x.isValidarDomicilio())
				.map(x -> gerarChaveParametrizacao(x.getCodFerramenta(), x.getCodSolucaoCaptura()))
				.collect(Collectors.toList()));

		paramAuxiliar.setValidacaoParalelaTedAtivos(
				parametrizacoesExistentes.stream().filter(x -> x.isValidacaoParalelaTED())
						.map(x -> gerarChaveParametrizacao(x.getCodFerramenta(), x.getCodSolucaoCaptura()))
						.collect(Collectors.toList()));

		session.setAttribute(this.MAP_PARAMETRIZACOES_ORIGINAIS, mapParametrizacoes);
		session.setAttribute(this.DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO, filtro);
		session.setAttribute(this.DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO, paramAuxiliar);

		model.addAttribute(this.DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO, filtro);
		model.addAttribute(this.DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO, paramAuxiliar);
	}

	private String gerarChaveParametrizacao(Integer codigoFerramenta, Integer codigoSolucaoCaptura) {
		return String.valueOf(codigoFerramenta) + '_' + String.valueOf(codigoSolucaoCaptura);
	}
	
	@RequestMapping("/identificarAtualizacoesDomicilioBancario")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR)
	public String identificarAtualizacoesDomicilioBancario(@ModelAttribute("validacaoDomicilioBancario") @Valid ValidacaoDomicilioBancarioAuxiliarDTO parametrizacoes,
	BindingResult bindingResult, Model model, HttpSession session, Authentication authentication) {
	
		validator.validate(parametrizacoes, bindingResult);
		
		if (!bindingResult.hasErrors()){
		
			List<ParametrizacaoDomicilioBancarioManutencaoDTO> listaManutencoes = identificarAtualizacoes(parametrizacoes, model, session);
			List<ItemGradeConfirmacaoValidacaoDomicilioBancarioDTO> listaGradeConf = listaManutencoes.stream()
					.map(x -> this.toItemConfirmacaoDTO(x, session))
					.collect(Collectors.toList());

			model.addAttribute(this.DTO_LISTA_CONFIRMACAO_VALIDACAO_DOMICILIO_BANCARIO, listaGradeConf);
			session.setAttribute(this.DTO_LISTA_MANUTENCOES_VALIDACAO_DOMICILIO_BANCARIO, listaManutencoes);
			
		}
		else
		{
			List<FieldError> erros = bindingResult.getFieldErrors();
			model.addAttribute("erros", erros);
			
		}
		
		model.addAttribute(this.DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO, session.getAttribute(this.DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO));
		model.addAttribute(this.DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO, parametrizacoes);
		
		return NavigationDashBoard.PARAMETRIZACAO_VALIDACAO_DOMICILIO_BANCARIO;
	}
	
	
	@RequestMapping("/atualizarValidacaoDomicilioBancario")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR)
	public String atualizarValidacaoDomicilioBancario(
			@ModelAttribute("validacaoDomicilioBancario") @Valid ValidacaoDomicilioBancarioAuxiliarDTO parametrizacoes,
			BindingResult bindingResult, Model model, HttpSession session, Authentication authentication) {

			List<ParametrizacaoDomicilioBancarioManutencaoDTO> listaManutencoes = (List<ParametrizacaoDomicilioBancarioManutencaoDTO>) session.getAttribute(this.DTO_LISTA_MANUTENCOES_VALIDACAO_DOMICILIO_BANCARIO);
		
			aplicarAlteracoes(listaManutencoes, session);

			model.addAttribute("success", "Atualização realizada com sucesso!");

			ValidacaoDomicilioBancarioFiltroDTO filtro = (ValidacaoDomicilioBancarioFiltroDTO) session
				.getAttribute(this.DTO_FILTRO_VALIDACAO_DOMICILIO_BANCARIO);
			
			session.removeAttribute(this.DTO_LISTA_MANUTENCOES_VALIDACAO_DOMICILIO_BANCARIO);
			
			montarGrade(filtro, model, session);

		return NavigationDashBoard.PARAMETRIZACAO_VALIDACAO_DOMICILIO_BANCARIO;
	}
	
	private List<ParametrizacaoDomicilioBancarioManutencaoDTO> identificarAtualizacoes(ValidacaoDomicilioBancarioAuxiliarDTO parametrizacoes, Model model,
			HttpSession session) {
		
		ValidacaoDomicilioBancarioAuxiliarDTO paramOriginal = (ValidacaoDomicilioBancarioAuxiliarDTO) session
				.getAttribute(this.DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO);
		Map<String, ParametrizacaoDomicilioBancarioDTO> mapParametrizacaoOrig = (Map<String, ParametrizacaoDomicilioBancarioDTO>) session
				.getAttribute(this.MAP_PARAMETRIZACOES_ORIGINAIS);

		List<String> itensAtivosOrig = new ArrayList<String>();

		itensAtivosOrig.addAll(paramOriginal.getParametrizacoesAtivas());

		List<String> itensAtivos = new ArrayList<String>();

		itensAtivos.addAll(parametrizacoes.getParametrizacoesAtivas());

		List<String> itensIncluidos = new ArrayList<String>();
		List<String> itensExcluidos = new ArrayList<String>();
		List<String> itensAlterados = new ArrayList<String>();

		itensIncluidos
				.addAll(itensAtivos.stream().filter(x -> !itensAtivosOrig.contains(x)).collect(Collectors.toList()));

		itensExcluidos
				.addAll(itensAtivosOrig.stream().filter(x -> !itensAtivos.contains(x)).collect(Collectors.toList()));

		Map<String, ItemGradeValidacaoDomicilioBancarioDTO> mapItensGrade = parametrizacoes
				.getListaValidacaoDomicilioBancario().stream().collect(Collectors
						.toMap(ItemGradeValidacaoDomicilioBancarioDTO::getIdValidacaoDomicilioBancario, x -> x));

		itensAlterados.addAll(itensAtivos.stream().filter(x -> itensAtivosOrig.contains(x))
				.filter(x -> ((!mapItensGrade.get(x).getCodigoSituacaoCadastral()
						.equals(mapParametrizacaoOrig.get(x).getCodSituacaoCadastral())
						|| ((parametrizacoes.getValidacaoDomicilioAtivos().contains(x)
								&& !mapParametrizacaoOrig.get(x).isValidarDomicilio())
								|| (!parametrizacoes.getValidacaoDomicilioAtivos().contains(x)
										&& mapParametrizacaoOrig.get(x).isValidarDomicilio()))
						|| ((parametrizacoes.getValidacaoParalelaTedAtivos().contains(x)
								&& !mapParametrizacaoOrig.get(x).isValidacaoParalelaTED())
								|| (!parametrizacoes
										.getValidacaoParalelaTedAtivos().contains(x)
										&& mapParametrizacaoOrig.get(x)
												.isValidacaoParalelaTED())))))
				.collect(Collectors.toList()));

		List<ParametrizacaoDomicilioBancarioManutencaoDTO> listManutencoes = new ArrayList<ParametrizacaoDomicilioBancarioManutencaoDTO>();

		listManutencoes.addAll(parametrizacoes.getListaValidacaoDomicilioBancario().stream()
				.filter(item -> itensIncluidos.contains(item.getIdValidacaoDomicilioBancario()))
				.map(item -> toManutencaoDTO(item, parametrizacoes, false, true)).collect(Collectors.toList()));

		listManutencoes.addAll(parametrizacoes.getListaValidacaoDomicilioBancario().stream()
				.filter(item -> itensExcluidos.contains(item.getIdValidacaoDomicilioBancario()))
				.map(item -> toManutencaoDTO(item, parametrizacoes, false, false)).collect(Collectors.toList()));

		listManutencoes.addAll(parametrizacoes.getListaValidacaoDomicilioBancario().stream()
				.filter(item -> itensAlterados.contains(item.getIdValidacaoDomicilioBancario()))
				.map(item -> toManutencaoDTO(item, parametrizacoes, true, true)).collect(Collectors.toList()));
		
		return listManutencoes;
		
	}

	private void aplicarAlteracoes(List<ParametrizacaoDomicilioBancarioManutencaoDTO> listaManutencoes,
			HttpSession session) {

		ParametrizacaoDomicilioBancarioManutencaoRequestDTO request = new ParametrizacaoDomicilioBancarioManutencaoRequestDTO();
		request.setParametrizacoes(listaManutencoes);
		request.setCodUsuario((String) session.getAttribute("username"));

		parametrizacaoDomicilioBancarioService.atualizar(request);

	}
	
	private ItemGradeConfirmacaoValidacaoDomicilioBancarioDTO toItemConfirmacaoDTO(ParametrizacaoDomicilioBancarioManutencaoDTO item, HttpSession session){
		
		Map<Integer, String> mapFerramentas = (Map<Integer, String>) session.getAttribute(this.MAP_FERRAMENTAS);
		Map<Integer, String> mapSolucao = (Map<Integer, String>) session.getAttribute(this.MAP_SOLUCAO_CAPTURA);
		
		ItemGradeConfirmacaoValidacaoDomicilioBancarioDTO dto = new ItemGradeConfirmacaoValidacaoDomicilioBancarioDTO();
		dto.setDescricaoFerramenta(mapFerramentas.get(item.getParametrizacao().getCodFerramenta()));
		dto.setDescricaoSolucaoCaptura(mapSolucao.get(item.getParametrizacao().getCodSolucaoCaptura()));
		
		if (item.isAtivo() && item.isAlterado()){
			dto.setTipoManutencao("Alteração");
		}
		if (item.isAtivo() && !item.isAlterado()){
			dto.setTipoManutencao("Incluído");
		}
		if (!item.isAtivo()){
			dto.setTipoManutencao("Excluído");
		}
		
		return dto;
	}

	private ParametrizacaoDomicilioBancarioManutencaoDTO toManutencaoDTO(
			ItemGradeValidacaoDomicilioBancarioDTO itemGrade, ValidacaoDomicilioBancarioAuxiliarDTO parametrizacoes,
			boolean alterado, boolean ativo) {

		ParametrizacaoDomicilioBancarioManutencaoDTO itemManut = new ParametrizacaoDomicilioBancarioManutencaoDTO();
		ParametrizacaoDomicilioBancarioDTO itemManutDados = new ParametrizacaoDomicilioBancarioDTO();

		itemManutDados.setCodFerramenta(itemGrade.getCodigoFerramenta());
		itemManutDados.setCodSolucaoCaptura(itemGrade.getCodigoSolucaoCaptura());
		itemManutDados.setCodSituacaoCadastral(itemGrade.getCodigoSituacaoCadastral());
		itemManutDados.setValidarDomicilio(
				parametrizacoes.getValidacaoDomicilioAtivos().contains(itemGrade.getIdValidacaoDomicilioBancario()));
		itemManutDados.setValidacaoParalelaTED(
				parametrizacoes.getValidacaoParalelaTedAtivos().contains(itemGrade.getIdValidacaoDomicilioBancario()));

		itemManut.setParametrizacao(itemManutDados);
		itemManut.setAlterado(alterado);
		itemManut.setAtivo(ativo);

		return itemManut;

	}

	@RequestMapping("/exportValidacaoDomicilioBancario")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String exportValidacaoDomicilioBancario(
			@ModelAttribute("filtroValidacaoDomicilioBancario") @Valid ValidacaoDomicilioBancarioFiltroDTO filtro,
			BindingResult bindingResult, Model model, HttpSession session, Authentication authentication,
			HttpServletResponse response) throws Exception {

		XSSFWorkbook wb = new XSSFWorkbook();
		String[] hearders = new String[] { "FERRAMENTA", "SOLUÇÃO CAPTURA", "VALIDAR DOMICILIO", "VALICAÇÃO PARALELA",
				"SITUAÇÃO CADASTRAL" };
		try {

			ValidacaoDomicilioBancarioAuxiliarDTO parametrizacoes = (ValidacaoDomicilioBancarioAuxiliarDTO) session
					.getAttribute(this.DTO_LISTA_VALIDACAO_DOMICILIO_BANCARIO);

			List<SituacaoCadastralDTO> listSituacaoCadastral = (List<SituacaoCadastralDTO>) session
					.getAttribute(this.LIST_SITUACAO_CADASTRAL);

			Map<String, String> mapSituacaoCadastral = listSituacaoCadastral.stream()
					.collect(Collectors.toMap(SituacaoCadastralDTO::getCodigo, SituacaoCadastralDTO::getDescricao));

			XSSFSheet sheet = wb.createSheet();
			XSSFRow row = sheet.createRow(0);

			/* create style */
			XSSFCellStyle style = wb.createCellStyle();
			XSSFFont font = wb.createFont();
			font.setBold(Boolean.TRUE);
			font.setFontHeightInPoints((short) 12);
			style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setFont(font);

			for (int i = 0; i < hearders.length; i++) {
				XSSFCell cell = row.createCell(i);
				cell.setCellValue(hearders[i]);
				cell.setCellStyle(style);
				sheet.setColumnWidth(i, i == 0 || i == 1 ? 2500 : 6000);
			}
			
			int numeroLinhaExport = 0;

			if (!parametrizacoes.getListaValidacaoDomicilioBancario().isEmpty()) {
				
				for (int i = 0; i < parametrizacoes.getListaValidacaoDomicilioBancario().size(); i++) {

					if (parametrizacoes.getParametrizacoesAtivas().contains(parametrizacoes
							.getListaValidacaoDomicilioBancario().get(i).getIdValidacaoDomicilioBancario())) {

						numeroLinhaExport++;
						XSSFRow rowConteudo = sheet.createRow(numeroLinhaExport);

						rowConteudo.createCell((int) 0).setCellValue(
								parametrizacoes.getListaValidacaoDomicilioBancario().get(i).getDescricaoFerramenta());
						rowConteudo.createCell((int) 1).setCellValue(parametrizacoes
								.getListaValidacaoDomicilioBancario().get(i).getDescricaoSolucaoCaptura());

						if (parametrizacoes.getValidacaoDomicilioAtivos().contains(parametrizacoes
								.getListaValidacaoDomicilioBancario().get(i).getIdValidacaoDomicilioBancario())) {
							rowConteudo.createCell((int) 2).setCellValue("ATIVO");
							rowConteudo.createCell((int) 4).setCellValue(mapSituacaoCadastral.get(parametrizacoes
									.getListaValidacaoDomicilioBancario().get(i).getCodigoSituacaoCadastral()));
						} else {
							rowConteudo.createCell((int) 2).setCellValue("INATIVO");
						}

						if (parametrizacoes.getValidacaoParalelaTedAtivos().contains(parametrizacoes
								.getListaValidacaoDomicilioBancario().get(i).getIdValidacaoDomicilioBancario())) {
							rowConteudo.createCell((int) 3).setCellValue("ATIVO");
						} else {
							rowConteudo.createCell((int) 3).setCellValue("INATIVO");
						}
					}
				}
			}
			DashboardUtils.contentTypeForBrowser(response, wb, "RELATORIO_VALIDACAO_DOMICILIO_BANCARIO");
		} catch (Exception e) {
			throw e;
		}
		return NavigationDashBoard.PARAMETRIZACAO_VALIDACAO_DOMICILIO_BANCARIO;
	}

}
