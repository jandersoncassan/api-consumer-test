package br.com.cielo.dashboard.service;

import java.util.List;

import br.com.cielo.credenciamento.dto.ParametrizacaoDomicilioBancarioDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoDomicilioBancarioManutencaoRequestDTO;

public interface IParametrizacaoDomicilioBancarioService {
	
	List<ParametrizacaoDomicilioBancarioDTO> consultar(List<Integer> codigosFerramenta, List<Integer> codigosSolucaoCaptura);
	void atualizar(ParametrizacaoDomicilioBancarioManutencaoRequestDTO manutencoes);

}
