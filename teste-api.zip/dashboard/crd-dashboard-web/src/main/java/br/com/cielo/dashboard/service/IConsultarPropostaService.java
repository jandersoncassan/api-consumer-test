/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;
import java.util.Optional;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarPropostaService {
	/**
	 * Método: Get Proposta cliente R1
	 * 
	 * @param proposta
	 * @param estabelecimentoComercial
	 * @param cpfCnpj
	 * @param codigoAfiliador
	 * @param etapa
	 * @param status
	 * @param periodoInicial
	 * @param periodoFinal
	 * @return
	 */
	Object[] getProposta(final Long proposta, final Long estabelecimentoComercial, final Integer codigoAfiliador,
			final Integer[] etapa, final Integer[] status, final String periodoInicial, final String periodoFinal,
			final Boolean isSmart, final Optional<Integer> codPerfilSmart);

	/**
	 * 
	 * @param ferramenta
	 * @param bancos
	 * @param solucaoCapturas
	 * @param codigoAfiliador
	 * @param motivoCancelamento
	 * @param criticaEtapa
	 * @param etapas
	 * @param statusEtapas
	 * @param periodoInicial
	 * @param periodoFinal
	 * @return
	 */
	List<Object[]> getPropostaAllFilter(final Integer[] ferramenta, final Integer[] bancos,
			final Integer[] solucaoCapturas, final Integer codigoAfiliador, final String motivoCancelamento,
			final String criticaEtapa, final Integer[] etapas, final Integer[] statusEtapas,
			final String periodoInicial, final String periodoFinal, final Integer[] situacaoProposta,
			final String cpfCnpj, final String codigoOferta, final Boolean isSmart,
			final Optional<Integer> codPerfilSmart, final Optional<String> indEntregaMaquina);

}
