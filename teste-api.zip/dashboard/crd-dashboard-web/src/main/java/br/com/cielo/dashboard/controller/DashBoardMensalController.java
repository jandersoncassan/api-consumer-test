/**
 * 
 */
package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.cielo.dashboard.dto.DashBoardMensalDTO;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.ICardsService;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author dcarneiro
 *
 */
@Controller
public class DashBoardMensalController {

	private static final Logger LOG = LogManager.getLogger(DashBoardMensalController.class);
	
	@Autowired
	private ICardsService cardsService; 

	@RequestMapping(value="/initDashBoardMensal") 
	@Secured(SecurityRole.ROLE_CRD_DASHBOARD_VER)
	public String initDashBoardMensal(Model model, Authentication authentication) throws IOException {
		LOG.info("INIT PAGE DASHBOARD_MENSAL");
		String dataReferenciaPesquisa = new SimpleDateFormat(DashboardUtils.PATTERN_MM_YYYY).format(new Date());
		DashBoardMensalDTO dashboardMensalDTO = new DashBoardMensalDTO();
		dashboardMensalDTO.setDataReferenciaPesquisa(dataReferenciaPesquisa); 
		dashboardMensalDTO.setListaMeses(DashboardUtils.calcularMesAnoParaPesquisaDashboard());
		// OBTER CARDS
		dashboardMensalDTO = obterCards(dashboardMensalDTO);
		model.addAttribute("dashboardMensalDTO",dashboardMensalDTO);
		return NavigationDashBoard.DASHBOARD_MENSAL;
	}

	/**
	 * 
	 * @param dataReferenciaPesquisa
	 * @param model
	 * @param session
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/realizarPesquisaDashPorMesReferencia/{dataPesquisa}")
	@Secured(SecurityRole.ROLE_CRD_DASHBOARD_VER)
	public String realizarPesquisaDashPorMesReferencia(@PathVariable("dataPesquisa") String dataReferenciaPesquisa, Model model, HttpSession session) throws Throwable {
		LOG.info("LOAD DASH POR DATA REFERENCIA .. {}", dataReferenciaPesquisa);
		/*OBTEM INFORMAÇÕES DO CARD PRINCIPAL*/
		DashBoardMensalDTO dashboardMensalDTO = new DashBoardMensalDTO();
		dashboardMensalDTO.setDataReferenciaPesquisa(tratarDataPesquisa(dataReferenciaPesquisa));
		dashboardMensalDTO.setListaMeses(DashboardUtils.calcularMesAnoParaPesquisaDashboard());
		// OBTER CARDS
		dashboardMensalDTO = obterCards(dashboardMensalDTO);
		model.addAttribute("dashboardMensalDTO",dashboardMensalDTO);
		return NavigationDashBoard.DASHBOARD_MENSAL;
	}
	
	public DashBoardMensalDTO obterCards (DashBoardMensalDTO dashBoardMensalDTO) {
		List<Object> retorno = cardsService.getCardsPrincipal(dashBoardMensalDTO.getDataReferenciaPesquisa());
		if (DashboardUtils.isNotNullOrEmpty(retorno)) {
			dashBoardMensalDTO.setCredenciamento(DashboardUtils.formatNumber(
					DashboardUtils.isNotNullOrEmpty(retorno.get(0)) ? retorno.get(0).toString() : DashboardUtils.SRING_ZERO));
			dashBoardMensalDTO.setInstalacao(DashboardUtils.formatNumber(
					DashboardUtils.isNotNullOrEmpty(retorno.get(0)) ? retorno.get(1).toString() : DashboardUtils.SRING_ZERO));
			dashBoardMensalDTO.setAtivacao(DashboardUtils.formatNumber(
					DashboardUtils.isNotNullOrEmpty(retorno.get(0)) ? retorno.get(2).toString() : DashboardUtils.SRING_ZERO));
		}
		
		return dashBoardMensalDTO;
	}

	/**
	 * Método responsavel por formatar a data no padrão de pesquisa mm/yyyy
	 * 
	 * @param dataPesquisa
	 * @return
	 */
	private String tratarDataPesquisa(String dataPesquisa) {
		dataPesquisa = dataPesquisa.substring(0,2).concat("/").concat(dataPesquisa.substring(2));
		return dataPesquisa;
	}
}
