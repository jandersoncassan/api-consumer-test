package br.com.cielo.dashboard.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.credenciamento.dto.ParametrizacaoSolucaoCapturaPermitidaDTO;
import br.com.cielo.credenciamento.enums.FerramentaEnum;
import br.com.cielo.credenciamento.enums.SolucaoCapturaEnum;
import br.com.cielo.dashboard.dto.FiltroSolucoesCapturaParametro;
import br.com.cielo.dashboard.dto.SolucaoCapturaAuxiliar;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IParametrizacaoSolucoesCapturaPermitidasService;
import br.com.cielo.dashboard.utils.DashboardUtils;

@Controller
@Scope(value = WebApplicationContext.SCOPE_REQUEST)
public class SolucoesCapturaPermitidasController {

	private static final Logger LOG = LoggerFactory.getLogger(SolucoesCapturaPermitidasController.class);

	@Autowired
	private IParametrizacaoSolucoesCapturaPermitidasService solucaoCapturaService;

	private static final Integer ADICIONADO = 1;
	private static final Integer EXCLUIDO = 2;

	@RequestMapping("/initSolucoesCapturaPermitidas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String initSolucoesCapturaPermitidas(Model model, HttpSession session) {
		cleanOjectSession(session);
		model.addAttribute("filtroSolucaoCaptura", new FiltroSolucoesCapturaParametro());
		return NavigationDashBoard.PARAMETRIZACAO_SOLUCOES_CAPTURA_PERMITIDAS;
	}

	@RequestMapping("/consultarSolucoesCapturaPermitidas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String consultarSolucoesCapturaPermitidas(Model model, HttpSession session, @ModelAttribute("filtroSolucaoCaptura") FiltroSolucoesCapturaParametro filtro) {
		LOG.info("OBTENDO A LISTA DE SOLUCOES DE CAPTURA PARAMETRIZADAS ..");
		try {
			List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaSolucoes = obterListaSolucaoCaptura(filtro);
			consistirRegistrosLista(listaSolucoes, model, filtro, session);

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A LISTA DE SOLUCOES DE CAPTURA PARAMETRIZADAS .. {}", ex);
			model.addAttribute("error", "OCORREU UM ERRO NA CONSULTA DA LISTA DE SOLUÇÕES DE CAPTURA !");
		}
		return NavigationDashBoard.PARAMETRIZACAO_SOLUCOES_CAPTURA_PERMITIDAS;
	}


	@RequestMapping("/obterListaRegistrosAlterados")
	public String efetivarManutencaoSolucao(
			@ModelAttribute("listaSolucoesCapturaPermitidas") SolucaoCapturaAuxiliar listaSolucoes, @ModelAttribute("filtroSolucaoCaptura") FiltroSolucoesCapturaParametro filtro, Model model,
			HttpSession session) {
		LOG.info("OBTENDO A LISTA DE PARAMETRIZACOES QUE FORAM ALTERADAS ..");
		try {
			tratarAlteracaoParametros(listaSolucoes, session, model);
			// GUARDAMOS NA SESSÃO PARA CONSEGUIR CONSISTIR AS MUDANCAS DE PARAMETROS
			SolucaoCapturaAuxiliar listaSolucoesOriginal = (SolucaoCapturaAuxiliar) session.getAttribute("listaTratadaOriginal");
			model.addAttribute("listaSolucoesCapturaPermitidas", listaSolucoesOriginal);
			model.addAttribute("filtroSolucaoCaptura", session.getAttribute("filtroSolucaoCaptura"));
			model.addAttribute("isShowModal", "show");

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A LISTA DE PARAMETRIZAÇÕES ALTERADAS .. {}", ex);
			model.addAttribute("error", "OCORREU UM ERRO AO TRATAR A LISTA DE PARAMETRIZAÇÕES ALTERADAS !");
		}
		return NavigationDashBoard.PARAMETRIZACAO_SOLUCOES_CAPTURA_PERMITIDAS;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping("/efetivarManutencaoSolucao")
	public String efetivarManutencaoSolucao(Model model, HttpSession session) {
		LOG.info("EFETUANDO A MANUTENÇÃO DA LISTA DE PARAMETROS ALTERADOS ..");
		try {
			List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaRegistrosAlterados = (List<ParametrizacaoSolucaoCapturaPermitidaDTO>) session.getAttribute("registrosAlterados");
			String codigoUsuario = (String) session.getAttribute("username");			
			solucaoCapturaService.efetivarAlteracaoParametrizaocao(listaRegistrosAlterados, codigoUsuario);
			// CONSULTAMOS A LISTA NOVAMENTE
			FiltroSolucoesCapturaParametro filtro = (FiltroSolucoesCapturaParametro)session.getAttribute("filtroSolucaoCaptura");
			List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaSolucoes = obterListaSolucaoCaptura(filtro);
			consistirRegistrosLista(listaSolucoes, model, filtro, session);
			//SUCESSO 
			model.addAttribute("filtroSolucaoCaptura", filtro);
			model.addAttribute("success", "ATUALIZAÇÃO REALIZADA COM SUCESSO !");
			
		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO REALIZAR A MANUTENÇÃO NA LISTA DE SOLUCOES DE CAPTURA PARAMETRIZADAS .. {}",ex);
			model.addAttribute("error", "OCORREU UM ERRO AO ATUALIZAR OS PARAMETROS !");
		}
		return NavigationDashBoard.PARAMETRIZACAO_SOLUCOES_CAPTURA_PERMITIDAS;
	}

	
	/**
	 * Método responsavel por obter a lista de solucao de captura na base de dados
	 * @param filtro
	 * @return
	 */
	private List<ParametrizacaoSolucaoCapturaPermitidaDTO> obterListaSolucaoCaptura(FiltroSolucoesCapturaParametro filtro) {
		return solucaoCapturaService.obterListaSolucoesCaptura(
				Optional.ofNullable(filtro.getCodigosSolucaoCaptura()), Optional.ofNullable(filtro.getCodigosFerramenta()));
	}

	
	/**
	 * Meotodo responsavel por verificar se houver mudanças nos parametros
	 * 
	 * @param listaSolucoes
	 */
	private void tratarAlteracaoParametros(SolucaoCapturaAuxiliar listaSolucoesTela, HttpSession session, Model model) {
		session.removeAttribute("registrosAlterados");
		// LISTA ORIGINAL NA SESSAO
		SolucaoCapturaAuxiliar listaSolucoesOriginal = (SolucaoCapturaAuxiliar) session.getAttribute("listaTratadaOriginal");
		// TRATAMENTO SOLUCOES REMOVIDAS
		List<String> solucoesRemovidas = tratarSolucoesRemovidas(listaSolucoesOriginal, listaSolucoesTela);
		// TRATAMENTO SOLUCOES ADICIONADAS
		Map<String, String> solucoesAdicionadas = tratarSolucoesAdicionadas(listaSolucoesOriginal, listaSolucoesTela);
		// POPULA A LISTA DE REGISTROS ALTERADOS
		List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaRegistrosAlterados = popularListaParametrosAlterados(
				listaSolucoesOriginal, listaSolucoesTela, solucoesRemovidas, solucoesAdicionadas);
		model.addAttribute("listaRegistrosAlterados", listaRegistrosAlterados);
		// GUARDAMOS NA SESSÃO PARA CONSEGUIR CONSISTIR AS MUDANCAS DE PARAMETROS NA BASE DE DADOS
		
		session.setAttribute("registrosAlterados", listaRegistrosAlterados);
	}

	/**
	 * Método responsavel por tratar a lista de registros alterados
	 * 
	 * @param listaRegistrosAlterados
	 */
	private void tratarListaRegistrosAlterados(List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaRegistrosAlterados) {
		List<String> chaveAux = new ArrayList<>();
		List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaAuxExcluidos = new ArrayList<>();
		for (ParametrizacaoSolucaoCapturaPermitidaDTO registro : listaRegistrosAlterados) {
			String chave = registro.getCodigoFerramenta().toString()
					.concat(registro.getCodigoSolucaoCaptura().toString()).concat(registro.getTipoAcao().toString());
			if (chaveAux.contains(chave) || isParamExcluido(registro)) {
				listaAuxExcluidos.add(registro);// DUPLICADO || TUDO FLAG N
			} else {
				chaveAux.add(chave);
			}
		}
		listaRegistrosAlterados.removeAll(listaAuxExcluidos);
	}

	/**
	 * Método responsavel por verificar se o parametro foi excluido, todas as flags
	 * ficaram como 'N'
	 * 
	 * @param registro
	 * @return
	 */
	private boolean isParamExcluido(ParametrizacaoSolucaoCapturaPermitidaDTO registro) {
		return registro.getIndicadorPlanoConvencional().equals("N") && registro.getIndicadorPlanoControle().equals("N") 
				&& registro.getIndicadorPlanoAluguelZero().equals("N") && registro.getIndicadorOfertaMEI().equals("N") && registro.getIndicadorPf().equals("N")
				&& registro.getIndicadorPj().equals("N") && registro.getIndicadorEntregaMaquina().equals("N");
	}

	private List<ParametrizacaoSolucaoCapturaPermitidaDTO> onlyRemovidos(List<String> solucoesRemovidas) {
		return solucoesRemovidas.stream().map(solucaoRemovida -> popularInfoSolucao(solucaoRemovida, EXCLUIDO))
				.collect(Collectors.toList());
	}

	/**
	 * Método responsavel por consolidar a lista de registros alterados
	 * 
	 * @param solucoesRemovidas
	 * @param solucoesAdicionadas
	 * @return
	 */
	private List<ParametrizacaoSolucaoCapturaPermitidaDTO> popularListaParametrosAlterados(	SolucaoCapturaAuxiliar listaSolucoesOriginal, SolucaoCapturaAuxiliar listaSolucoesTela,
			List<String> solucoesRemovidas, Map<String, String> solucoesAdicionadas) {
		List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaRegistrosAlterados = new ArrayList<>();
		listaRegistrosAlterados.addAll(solucoesRemovidas.stream().map(solucaoRemovida -> tratarSolucaoRemovida(solucaoRemovida, listaSolucoesTela)).collect(Collectors.toList()));
		listaRegistrosAlterados.addAll(solucoesAdicionadas.entrySet().stream().map(k -> tratarSolucaoAdicionada(k.getKey(), k.getValue(), listaSolucoesOriginal)).collect(Collectors.toList()));
		listaRegistrosAlterados.addAll(onlyRemovidos(solucoesRemovidas));
		tratarListaRegistrosAlterados(listaRegistrosAlterados);
		return listaRegistrosAlterados;
	}

	/**
	 * Método responsavel por popular as informações de soluções removidas
	 * @param solucaoRemovida
	 * @param listaSolucoesTela
	 * @return
	 */
	private ParametrizacaoSolucaoCapturaPermitidaDTO tratarSolucaoRemovida(String solucaoRemovida, SolucaoCapturaAuxiliar listaSolucoesTela) {

		String[] indicadores = ObterIndicadoresTratados(solucaoRemovida, listaSolucoesTela);		
		String idSolucaoAdiconada = obterIdSolucaoTratada(indicadores);
		return popularInfoSolucao(idSolucaoAdiconada, ADICIONADO);
	}

	/**
	 * Consistencias para montar o id da solucao adicionadas
	 * 
	 * @param solucaoAdicionada
	 * @param index
	 * @param listaSolucoesOriginal
	 * @return
	 */
	private ParametrizacaoSolucaoCapturaPermitidaDTO tratarSolucaoAdicionada(String solucaoAdicionada, String index, SolucaoCapturaAuxiliar listaSolucoesOriginal) {

		String[] indicadores = ObterIndicadoresTratados(solucaoAdicionada, listaSolucoesOriginal);		
		if (index.length() > 1) {
			String[] indexs = index.split("\\|");
			for (int i = 0; i < indexs.length; i++) {
				indicadores[Integer.valueOf(indexs[i])] = "S";
			}
		} else {
			indicadores[Integer.valueOf(index)] = "S";
		}
		String idSolucaoAdiconada = obterIdSolucaoTratada(indicadores);
		return popularInfoSolucao(idSolucaoAdiconada, ADICIONADO);
	}

	/**
	 * Método responsavel por obter as informações de solucoes removidas / adicionadas
	 * @param solucao
	 * @param listaSolucao
	 * @return
	 */
	private String[] ObterIndicadoresTratados(String solucao, SolucaoCapturaAuxiliar listaSolucao) {
		
		String[] indicadores = new String[9];
		
		indicadores[0] = parseValue(solucao, 0);
		indicadores[1] = parseValue(solucao, 1);
		indicadores[2] = obterValorIndicador(listaSolucao.getConvencional(), solucao);
		indicadores[3] = obterValorIndicador(listaSolucao.getControle(), solucao);
		indicadores[4] = obterValorIndicador(listaSolucao.getAluguelZero(), solucao);
		indicadores[5] = obterValorIndicador(listaSolucao.getMei(), solucao);
		indicadores[6] = obterValorIndicador(listaSolucao.getPf(), solucao);
		indicadores[7] = obterValorIndicador(listaSolucao.getPj(), solucao);
		indicadores[8] = obterValorIndicador(listaSolucao.getEntregaMaquina(), solucao);

		return indicadores;
	}
	
	/**
	 * Método responsavel por obter o id da solucao removida / adicionada
	 * @param indicadores
	 * @return
	 */
	private String obterIdSolucaoTratada(String[] indicadores) {
		return montarId(indicadores[0], indicadores[1], indicadores[2], indicadores[3], indicadores[4], indicadores[5], indicadores[6], indicadores[7], indicadores[8]);
	}
	
	/**
	 * Método responsavel por gerar o Id das solucoes adicionadas
	 * 
	 * @param ferramenta
	 * @param solucao
	 * @param flagConvencional
	 * @param flagControle
	 * @param flagMei
	 * @param flagPf
	 * @param flagPj
	 * @param flagEntregaMaquina
	 * @return
	 */
	private String montarId(String ferramenta, String solucao, String flagConvencional, String flagControle, String flagAluguelZero,
			String flagMei, String flagPf, String flagPj, String flagEntregaMaquina) {
		return ferramenta.concat("|").concat(solucao).concat("|").concat(flagConvencional).concat("|")
				.concat(flagControle).concat("|").concat(flagAluguelZero).concat("|").concat(flagMei).concat("|").concat(flagPf).concat("|").concat(flagPj)
				.concat("|").concat(flagEntregaMaquina);
	}

	/**
	 * Método responsavel por obter o valor da flag
	 * 
	 * @param convencional
	 * @param solucaoAdicionada
	 * @return
	 */
	private String obterValorIndicador(List<String> listaIndicadoresOriginal, String solucaoAdicionada) {
		Optional<List<String>> listaIndicadores = Optional.ofNullable(listaIndicadoresOriginal);
		if (listaIndicadores.isPresent() && !listaIndicadores.get().isEmpty()) {
			return listaIndicadores.get().contains(solucaoAdicionada) ? "S" : "N";
		}
		return "N";
	}

	/**
	 * Método responsavel por obter o valor do indicador atraves do parse do id
	 * 
	 * @param id
	 * @param posicao
	 * @return
	 */
	private String parseValue(String id, Integer posicao) {
		return id.split("\\|")[posicao];
	}

	/**
	 * Método responsavel por tratar os itens adicionados
	 * 
	 * @param listaSolucoesOriginal
	 * @param listaSolucoesTela
	 * @return
	 */
	private Map<String, String> tratarSolucoesAdicionadas(SolucaoCapturaAuxiliar listaSolucoesOriginal,
			SolucaoCapturaAuxiliar listaSolucoesTela) {

		Map<String, String> solucoesAdiconadas = new HashMap<>();
		// TRATAMOS AS SOLUCOES QUE FORAM EXCLUIDAS
		if (Optional.ofNullable(listaSolucoesTela.getConvencional()).isPresent()) {// CONVENCIONAL
			listaSolucoesTela.getConvencional().forEach(solucao -> tratarSolucoesAdicionadas(solucao, "2",
					listaSolucoesOriginal.getConvencional(), solucoesAdiconadas));
		}
		if (Optional.ofNullable(listaSolucoesTela.getControle()).isPresent()) {// CONTROLE
			listaSolucoesTela.getControle().forEach(solucao -> tratarSolucoesAdicionadas(solucao, "3",
					listaSolucoesOriginal.getControle(), solucoesAdiconadas));
		}
		if (Optional.ofNullable(listaSolucoesTela.getAluguelZero()).isPresent()) {// ALUGUEL ZERO
			listaSolucoesTela.getAluguelZero().forEach(solucao -> tratarSolucoesAdicionadas(solucao, "4",
					listaSolucoesOriginal.getAluguelZero(), solucoesAdiconadas));
		}
		if (Optional.ofNullable(listaSolucoesTela.getMei()).isPresent()) {// MEI
			listaSolucoesTela.getMei().forEach(solucao -> tratarSolucoesAdicionadas(solucao, "5",
					listaSolucoesOriginal.getMei(), solucoesAdiconadas));
		}
		if (Optional.ofNullable(listaSolucoesTela.getPf()).isPresent()) {// PF
			listaSolucoesTela.getPf().forEach(solucao -> tratarSolucoesAdicionadas(solucao, "6",
					listaSolucoesOriginal.getPf(), solucoesAdiconadas));
		}
		if (Optional.ofNullable(listaSolucoesTela.getPj()).isPresent()) {// PJ
			listaSolucoesTela.getPj().forEach(solucao -> tratarSolucoesAdicionadas(solucao, "7",
					listaSolucoesOriginal.getPj(), solucoesAdiconadas));
		}
		if (Optional.ofNullable(listaSolucoesTela.getEntregaMaquina()).isPresent()) {// ENTREGA MAQUINA
			listaSolucoesTela.getEntregaMaquina().forEach(solucao -> tratarSolucoesAdicionadas(solucao, "8",
					listaSolucoesOriginal.getEntregaMaquina(), solucoesAdiconadas));
		}
		return solucoesAdiconadas;

	}

	/**
	 * Método responsavel por popular os itens removidos
	 * 
	 * @param listaSolucoesOriginal
	 * @param listaSolucoesTela
	 * @return
	 */
	private List<String> tratarSolucoesRemovidas(SolucaoCapturaAuxiliar listaSolucoesOriginal,
			SolucaoCapturaAuxiliar listaSolucoesTela) {
		List<String> solucoesRemovidas = new ArrayList<>();
		// TRATAMOS AS SOLUCOES QUE FORAM EXCLUIDAS
		if (Optional.ofNullable(listaSolucoesOriginal.getConvencional()).isPresent()) {// CONVENCIONAL
			listaSolucoesOriginal.getConvencional().forEach(solucao -> tratarSolucoesRemovidas(solucao,
					listaSolucoesTela.getConvencional(), solucoesRemovidas));
		}
		if (Optional.ofNullable(listaSolucoesOriginal.getControle()).isPresent()) {// CONTROLE
			listaSolucoesOriginal.getControle().forEach(
					solucao -> tratarSolucoesRemovidas(solucao, listaSolucoesTela.getControle(), solucoesRemovidas));
		}
		if (Optional.ofNullable(listaSolucoesOriginal.getAluguelZero()).isPresent()) {// ALUGUEL ZERO
			listaSolucoesOriginal.getAluguelZero().forEach(
					solucao -> tratarSolucoesRemovidas(solucao, listaSolucoesTela.getAluguelZero(), solucoesRemovidas));
		}
		if (Optional.ofNullable(listaSolucoesOriginal.getMei()).isPresent()) {// MEI
			listaSolucoesOriginal.getMei().forEach(
					solucao -> tratarSolucoesRemovidas(solucao, listaSolucoesTela.getMei(), solucoesRemovidas));
		}
		if (Optional.ofNullable(listaSolucoesOriginal.getPf()).isPresent()) {// PF
			listaSolucoesOriginal.getPf()
					.forEach(solucao -> tratarSolucoesRemovidas(solucao, listaSolucoesTela.getPf(), solucoesRemovidas));
		}
		if (Optional.ofNullable(listaSolucoesOriginal.getPj()).isPresent()) {// PJ
			listaSolucoesOriginal.getPj()
					.forEach(solucao -> tratarSolucoesRemovidas(solucao, listaSolucoesTela.getPj(), solucoesRemovidas));
		}
		if (Optional.ofNullable(listaSolucoesOriginal.getEntregaMaquina()).isPresent()) {// ENTREGA DE MAQUINAS
			listaSolucoesOriginal.getEntregaMaquina().forEach(solucao -> tratarSolucoesRemovidas(solucao,
					listaSolucoesTela.getEntregaMaquina(), solucoesRemovidas));
		}
		return solucoesRemovidas.stream().distinct().collect(Collectors.toList());
	}

	/**
	 * Método responsavel por verificar as csolucoes que foram removidas
	 * 
	 * @param solucao
	 * @param listaSolucoesTela
	 * @param solucoesRemovidas
	 */
	private void tratarSolucoesAdicionadas(String solucao, String index, List<String> listaSolucoesOriginal, Map<String, String> solucoesAdiconadas) {
		if (Optional.ofNullable(listaSolucoesOriginal).isPresent()) {
			if (!listaSolucoesOriginal.contains(solucao))
				if (solucoesAdiconadas.containsKey(solucao)) {
					String indexExistente = solucoesAdiconadas.get(solucao);
					String indexTratado = indexExistente.concat("|").concat(index);
					solucoesAdiconadas.remove(solucao);
					solucoesAdiconadas.put(solucao, indexTratado);
				} else {
					solucoesAdiconadas.put(solucao, index);
				}
		}
	}

	/**
	 * Método responsavel por verificar as csolucoes que foram removidas
	 * 
	 * @param solucao
	 * @param listaSolucoesTela
	 * @param solucoesRemovidas
	 */
	private void tratarSolucoesRemovidas(String solucao, List<String> listaSolucoesTela, List<String> solucoesRemovidas) {
		if (Optional.ofNullable(listaSolucoesTela).isPresent()) {
			if (!listaSolucoesTela.contains(solucao))
				solucoesRemovidas.add(solucao);
		} else {
			solucoesRemovidas.add(solucao);
		}
	}

	/**
	 * Método responsavel por popular as informações da solucao de captura
	 * 
	 * @param solucao
	 * @return
	 */
	private ParametrizacaoSolucaoCapturaPermitidaDTO popularInfoSolucao(String solucao, Integer tipoAcao) {

		String[] idRegistro = solucao.split("\\|");
		ParametrizacaoSolucaoCapturaPermitidaDTO solucaoCaptura = new ParametrizacaoSolucaoCapturaPermitidaDTO();
		solucaoCaptura.setCodigoFerramenta(Integer.valueOf(idRegistro[0]));
		solucaoCaptura.setDescricaoFerramenta(FerramentaEnum.getFerramentaEnum(Integer.valueOf(idRegistro[0])).getDescricao().toUpperCase());
		solucaoCaptura.setCodigoSolucaoCaptura(Integer.valueOf(idRegistro[1]));
		solucaoCaptura.setDescricaoSolucaoCaptura(SolucaoCapturaEnum.getSolucaoCapturaEnum(Integer.valueOf(idRegistro[1])).getDescricaoParaCliente().toUpperCase());
		solucaoCaptura.setIndicadorPlanoConvencional(idRegistro[2]);
		solucaoCaptura.setIndicadorPlanoControle(idRegistro[3]);
		solucaoCaptura.setIndicadorPlanoAluguelZero(idRegistro[4]);
		solucaoCaptura.setIndicadorOfertaMEI(idRegistro[5]);
		solucaoCaptura.setIndicadorPf(idRegistro[6]);
		solucaoCaptura.setIndicadorPj(idRegistro[7]);
		solucaoCaptura.setIndicadorEntregaMaquina(idRegistro[8]);
		solucaoCaptura.setTipoAcao(tipoAcao);
		return solucaoCaptura;
	}

	/**
	 * Método responsavel por consistir os registro da lista de soluções de captura
	 * 
	 * @param listaSolucoes
	 * @param model
	 * @param session
	 * @param ferramentas
	 * @param status
	 */
	private void consistirRegistrosLista(List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaSolucoes, Model model,
			FiltroSolucoesCapturaParametro filtro, HttpSession session) {
		// TRATAMENTO PARA OS DADOS DA LISTA DE SOLUÇÕES
		List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaTratada = tratarListaSolucoes(listaSolucoes, filtro.getCodigosSolucaoCaptura(), filtro.getCodigosFerramenta());
		listaTratada.sort(Comparator.comparing(ParametrizacaoSolucaoCapturaPermitidaDTO::getDescricaoFerramenta));
		// ItensGridSolucaoCaptura flagsSolucao = new ItensGridSolucaoCaptura();
		SolucaoCapturaAuxiliar solucoesCaptura = new SolucaoCapturaAuxiliar();
		List<String> convencional = new ArrayList<>();
		List<String> controle = new ArrayList<>();
		List<String> aluguelZero = new ArrayList<>();
		List<String> mei = new ArrayList<>();
		List<String> pf = new ArrayList<>();
		List<String> pj = new ArrayList<>();
		List<String> entregaMaquina = new ArrayList<>();

		for (ParametrizacaoSolucaoCapturaPermitidaDTO solucao : listaTratada) {
			if (solucao.getIndicadorPlanoConvencional().equals("S")) {
				convencional.add(solucao.getId());
			}
			if (solucao.getIndicadorPlanoControle().equals("S")) {
				controle.add(solucao.getId());
			}
			if (solucao.getIndicadorPlanoAluguelZero().equals("S")) {
				aluguelZero.add(solucao.getId());
			}
			if (solucao.getIndicadorOfertaMEI().equals("S")) {
				mei.add(solucao.getId());
			}
			if (solucao.getIndicadorPf().equals("S")) {
				pf.add(solucao.getId());
			}
			if (solucao.getIndicadorPj().equals("S")) {
				pj.add(solucao.getId());
			}
			if (solucao.getIndicadorEntregaMaquina().equals("S")) {
				entregaMaquina.add(solucao.getId());
			}
		}
		solucoesCaptura.setConvencional(convencional);
		solucoesCaptura.setControle(controle);
		solucoesCaptura.setAluguelZero(aluguelZero);
		solucoesCaptura.setMei(mei);
		solucoesCaptura.setPf(pf);
		solucoesCaptura.setPj(pj);
		solucoesCaptura.setEntregaMaquina(entregaMaquina);
		solucoesCaptura.setListaTratada(listaTratada);

		model.addAttribute("listaSolucoesCapturaPermitidas", solucoesCaptura);
		session.setAttribute("filtroSolucaoCaptura", filtro);
		// GUARDAMOS NA SESSÃO PARA CONSEGUIR CONSISTIR AS MUDANCAS DE PARAMETROS
		session.setAttribute("listaTratadaOriginal", solucoesCaptura);
	}

	/**
	 * Método responsavel por popular as soluções inativas para a ferramenta
	 * 
	 * @param listaSolucoesAtivas
	 * @param ferramentas
	 */
	private List<ParametrizacaoSolucaoCapturaPermitidaDTO> tratarListaSolucoes(
			List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaSolucoesAtivas, List<Integer> solucoes,
			List<Integer> listaFerramentas) {
		if (null == listaFerramentas) {
			listaFerramentas = getListaFerramenta();
		}
		if (!Optional.ofNullable(solucoes).isPresent()) {// SOMENTE SE NÃO SELECIONOU SOLUÇÃO DE CAPTURA
			List<SolucaoCapturaEnum> listaSolucoes = Arrays.asList(SolucaoCapturaEnum.values());
			// LISTA AUXILIAR TRATAMENTO SOLUÇÕES INATIVAS
			Map<Integer, Integer> listaAuxiliar = new HashMap<>();
			for (Integer ferramenta : listaFerramentas) {
				for (SolucaoCapturaEnum solucaoCapturaEnum : listaSolucoes) {
					int count = 0;
					for (ParametrizacaoSolucaoCapturaPermitidaDTO solucao : listaSolucoesAtivas) {
						if (solucao.getCodigoFerramenta().equals(ferramenta)) {
							if (solucaoCapturaEnum.getCodigo().equals(solucao.getCodigoSolucaoCaptura())) {
								count++;
							}
						}
					}
					// CASO PARA ESSA FERRAMENTA A SOLUCAO NÃO ESTEJA ATIVA
					if (count == 0)
						listaAuxiliar.put(solucaoCapturaEnum.getCodigo(), ferramenta);
				}
			}
			// TRATAMENTO LISTA INATIVA
			if (!listaAuxiliar.isEmpty()) {
				List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaInativa = listaAuxiliar.entrySet().stream()
						.map(key -> popularSolucaoInativa(key.getKey(), key.getValue())).collect(Collectors.toList());
				listaSolucoesAtivas.addAll(listaInativa);
				return listaSolucoesAtivas;
			}
		}
		// SOMENTE AS SOLUCOES ATIVAS
		return listaSolucoesAtivas;
	}

	/**
	 * Método responsavel por popular as solucoes inativas
	 * 
	 * @param solucao
	 * @param ferramenta
	 * @return
	 */
	private ParametrizacaoSolucaoCapturaPermitidaDTO popularSolucaoInativa(Integer codSolucao, Integer ferramenta) {
		ParametrizacaoSolucaoCapturaPermitidaDTO solucaoInativa = new ParametrizacaoSolucaoCapturaPermitidaDTO();
		solucaoInativa.setCodigoFerramenta(ferramenta);
		solucaoInativa.setDescricaoFerramenta(FerramentaEnum.getFerramentaEnum(ferramenta).getDescricao().toUpperCase());
		solucaoInativa.setCodigoSolucaoCaptura(codSolucao);
		solucaoInativa.setDescricaoSolucaoCaptura(SolucaoCapturaEnum.getSolucaoCapturaEnum(codSolucao).getDescricaoParaCliente().toUpperCase());
		solucaoInativa.setIndicadorEntregaMaquina("N");
		solucaoInativa.setIndicadorPf("N");
		solucaoInativa.setIndicadorPj("N");
		solucaoInativa.setIndicadorOfertaMEI("N");
		solucaoInativa.setIndicadorPlanoConvencional("N");
		solucaoInativa.setIndicadorPlanoControle("N");
		solucaoInativa.setIndicadorPlanoAluguelZero("N");
		return solucaoInativa;
	}

	/**
	 * Ferramentas disponiveis para consulta
	 * 
	 * @return
	 */
	private List<Integer> getListaFerramenta() {
		return Arrays.asList(new Integer[] { 2, 3, 4, 5, 6, 7, 8 });
	}

	@RequestMapping("/exportSolucoesCapturaPermitidas")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_EXPORTAR)
	public void exportSolucoesCapturaPermitidas(HttpSession session, HttpServletResponse response) throws Exception {

		XSSFWorkbook wb = new XSSFWorkbook();
		String[] hearders = new String[] { "Ferramenta", "Solução Captura", "Plano Convencional", "Controle", "Cielo Livre",
				"MEI", "Pessoa Física", "Pessoa Jurídica", "Entrega de Máquina", "Situação" };
		try {
			SolucaoCapturaAuxiliar solucoesCaptura = (SolucaoCapturaAuxiliar) session.getAttribute("listaTratadaOriginal");
			List<ParametrizacaoSolucaoCapturaPermitidaDTO> listaSolucoes = solucoesCaptura.getListaTratada();

			XSSFSheet sheet = wb.createSheet();
			XSSFRow row = sheet.createRow(0);

			XSSFCellStyle style = wb.createCellStyle();
			XSSFFont font = wb.createFont();
			font.setBold(Boolean.TRUE);
			font.setFontHeightInPoints((short) 12);
			style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setFont(font);
			style.setAlignment(HorizontalAlignment.CENTER);

			for (int i = 0; i < hearders.length; i++) {
				XSSFCell cell = row.createCell(i);
				cell.setCellValue(hearders[i]);
				cell.setCellStyle(style);
				sheet.setColumnWidth(i, 6000);
			}
			
			for (int i = 0; i < listaSolucoes.size(); i++) {
				//POPULAMOS SOMENTE AS SOLUCOES ATIVAS
					XSSFRow rowConteudo = sheet.createRow(i + 1);					
					rowConteudo.createCell((int) 0).setCellValue(listaSolucoes.get(i).getDescricaoFerramenta());
					rowConteudo.createCell((int) 1).setCellValue(listaSolucoes.get(i).getDescricaoSolucaoCaptura());
					rowConteudo.createCell((int) 2).setCellValue(getDescricaoIndicador(listaSolucoes.get(i).getIndicadorPlanoConvencional()));
					rowConteudo.createCell((int) 3).setCellValue(getDescricaoIndicador(listaSolucoes.get(i).getIndicadorPlanoControle()));
					rowConteudo.createCell((int) 4).setCellValue(getDescricaoIndicador(listaSolucoes.get(i).getIndicadorPlanoAluguelZero()));
					rowConteudo.createCell((int) 5).setCellValue(getDescricaoIndicador(listaSolucoes.get(i).getIndicadorOfertaMEI()));
					rowConteudo.createCell((int) 6).setCellValue(getDescricaoIndicador(listaSolucoes.get(i).getIndicadorPj()));
					rowConteudo.createCell((int) 7).setCellValue(getDescricaoIndicador(listaSolucoes.get(i).getIndicadorPf()));
					rowConteudo.createCell((int) 8).setCellValue(getDescricaoIndicador(listaSolucoes.get(i).getIndicadorEntregaMaquina()));
					rowConteudo.createCell((int) 9).setCellValue(listaSolucoes.get(i).isAtivo() ? "ATIVO" : "INATIVO");
			}
			//GERAMOS O RELATORIO/
			DashboardUtils.contentTypeForBrowser(response, wb, "RELATORIO_SOLUCOES_CAPTURA_PERMITIDAS");
			
		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO GERAR O RELATORIO DE SOLUCOES DE CAPTURA - EXPORT {}", ex);
		}

	}
	
	private String getDescricaoIndicador(String indicador) {
		return indicador.equals("S")? "Sim" : "Não";
	}

	/**
	 * Método responsavel por remover os objetos da sessao
	 * @param session
	 */
	private void cleanOjectSession(HttpSession session){
		session.removeAttribute("registrosAlterados");
		session.removeAttribute("filtroSolucaoCaptura");
		session.removeAttribute("listaTratadaOriginal");
		session.removeAttribute("filtroSolucaoCaptura");
	}

}
