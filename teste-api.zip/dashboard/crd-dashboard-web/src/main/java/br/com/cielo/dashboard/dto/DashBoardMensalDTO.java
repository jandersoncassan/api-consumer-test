/**
 * 
 */
package br.com.cielo.dashboard.dto;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public class DashBoardMensalDTO {
	
	private String credenciamento;
	private String ativacao;
	private String instalacao;
	private String dataReferenciaPesquisa;
	private List<String> listaMeses;
	
	/**
	 * @return the credenciamento
	 */
	public String getCredenciamento() {
		return credenciamento;
	}
	/**
	 * @param credenciamento the credenciamento to set
	 */
	public void setCredenciamento(String credenciamento) {
		this.credenciamento = credenciamento;
	}
	/**
	 * @return the ativacao
	 */
	public String getAtivacao() {
		return ativacao;
	}
	/**
	 * @param ativacao the ativacao to set
	 */
	public void setAtivacao(String ativacao) {
		this.ativacao = ativacao;
	}
	/**
	 * @return the instalacao
	 */
	public String getInstalacao() {
		return instalacao;
	}
	/**
	 * @param instalacao the instalacao to set
	 */
	public void setInstalacao(String instalacao) {
		this.instalacao = instalacao;
	}
	/**
	 * @return the dataReferenciaPesquisa
	 */
	public String getDataReferenciaPesquisa() {
		return dataReferenciaPesquisa;
	}
	/**
	 * @param dataReferenciaPesquisa the dataReferenciaPesquisa to set
	 */
	public void setDataReferenciaPesquisa(String dataReferenciaPesquisa) {
		this.dataReferenciaPesquisa = dataReferenciaPesquisa;
	}
	public List<String> getListaMeses() {
		return listaMeses;
	}
	public void setListaMeses(List<String> listaMeses) {
		this.listaMeses = listaMeses;
	}

}
