/**
 * 
 */
package br.com.cielo.dashboard.model;

/**
 * @author dcarneiro
 *
 */
public class ChartsEtapa {

	private String  data;
	private Integer quantidade;

	/**
	 * @return the quantidade
	 */
	public Integer getQuantidade() {
		return quantidade;
	}
	/**
	 * @param quantidade the quantidade to set
	 */
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
}
