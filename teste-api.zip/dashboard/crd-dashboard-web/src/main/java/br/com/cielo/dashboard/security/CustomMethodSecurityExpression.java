package br.com.cielo.dashboard.security;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import br.com.cielo.dashboard.dto.ConsultarPropostaDTO;

@Component("customMethodSecurityExpression")
public class CustomMethodSecurityExpression {
	
	private static final Logger LOG = LogManager.getLogger(CustomMethodSecurityExpression.class);
	
	public boolean hasAnyRoleBanco() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		List<String> authorities = SecurityRole.getRoles(auth);
		
		for (String authority : authorities) {
			if (authority.startsWith("ROLE_CRD_BANCO")) {
				LOG.debug("hasAnyRoleBanco true");
				return true;
			}
		}
		
		LOG.debug("hasAnyRoleBanco false");
		return false;
	}

	public boolean hasAnyRoleFerramenta() {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		List<String> authorities = SecurityRole.getRoles(auth);
		
		for (String authority : authorities) {
			if (authority.startsWith("ROLE_CRD_FERRAMENTA")) {
				LOG.debug("hasAnyRoleFerramenta true");
				return true;
			}
		}
		
		LOG.debug("hasAnyRoleFerramenta false");
		return false;
	}
	
	public boolean consultaPropostaPermitida(ConsultarPropostaDTO consultar) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		List<Integer> listaCodigoBancosPermitidos  = SecurityRole.converteListaRolesBancoParaListaCodigoBanco(authentication);
		List<Integer> listaCodigoFerramentasPermitidas = SecurityRole.converteListaRolesFerramentaParaListaCodigoFerramenta(authentication);
		boolean bancosConsultadosSaoPermitidos = true;
		boolean ferramentasConsultadasSaoPermitidas = true;
		
		if (!listaCodigoBancosPermitidos.contains(0)) {
			for (Integer codigoBancoConsultado : consultar.getCodigoBanco()) {
				if (!listaCodigoBancosPermitidos.contains(codigoBancoConsultado)) {
					bancosConsultadosSaoPermitidos = false;
				}
			}
		}
		
		if (!listaCodigoFerramentasPermitidas.contains(0)) {
			for (Integer codigoFerramentaConsultada : consultar.getCodigoFerramenta()) {
				if (!listaCodigoFerramentasPermitidas.contains(codigoFerramentaConsultada)) {
					ferramentasConsultadasSaoPermitidas = false;
				}
			}
		}
		
		LOG.debug(" bancosConsultadosSaoPermitidos=" + bancosConsultadosSaoPermitidos 
				+ " ferramentasConsultadasSaoPermitidas=" + ferramentasConsultadasSaoPermitidas);
		return bancosConsultadosSaoPermitidos && ferramentasConsultadasSaoPermitidas;
	}
	
}
