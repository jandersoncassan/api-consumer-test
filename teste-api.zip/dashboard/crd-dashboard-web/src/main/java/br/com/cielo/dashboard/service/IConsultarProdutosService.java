/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarProdutosService {
	/**
	 * 
	 * @param proposta
	 * @return
	 */
	List<Object[]> getListarProdutos(final Long proposta);
	
}
