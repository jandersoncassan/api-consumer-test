/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarProdutosServiceRemote;
import br.com.cielo.dashboard.service.IConsultarProdutosService;

/**
 * @author dcarneiro
 *
 */
@Service 
public class ConsultarProdutosServiceImpl implements IConsultarProdutosService {

	@Resource(mappedName = "ConsultarProdutosService#br.com.cielo.credenciamento.service.dashboard.ConsultarProdutosServiceRemote")
	private ConsultarProdutosServiceRemote consultarProdutoRemote;
	
	/**
	 * Método: Obtem Lista de Produtos CRD
	 */
	public List<Object[]> getListarProdutos(Long proposta) {
		return consultarProdutoRemote.getConsultarProdutos(proposta);
	}


}
