/**
 * 
 */
package br.com.cielo.dashboard.dto;

import java.io.Serializable;

import br.com.cielo.dashboard.model.Bancos;

/**
 * @author dcarneiro
 *
 */
public class ConsultarRemessasDTO  implements Serializable{

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;
	//@Valid
	private Bancos bancos;
	//@NotEmpty(message="{campo.perido.inicial}")
	private String periodoInicial;
	//@NotEmpty(message="{campo.perido.final}")
	private String periodoFinal;
	private Integer codigoStatus;
	/**
	 * @return the bancos
	 */
	public Bancos getBancos() {
		return bancos;
	}
	/**
	 * @param bancos the bancos to set
	 */
	public void setBancos(Bancos bancos) {
		this.bancos = bancos;
	}
	/**
	 * @return the periodoInicial
	 */
	public String getPeriodoInicial() {
		return periodoInicial;
	}
	/**
	 * @param periodoInicial the periodoInicial to set
	 */
	public void setPeriodoInicial(String periodoInicial) {
		this.periodoInicial = periodoInicial;
	}
	/**
	 * @return the periodoFinal
	 */
	public String getPeriodoFinal() {
		return periodoFinal;
	}
	/**
	 * @param periodoFinal the periodoFinal to set
	 */
	public void setPeriodoFinal(String periodoFinal) {
		this.periodoFinal = periodoFinal;
	}
	/**
	 * @return the codigoStatus
	 */
	public Integer getCodigoStatus() {
		return codigoStatus;
	}
	/**
	 * @param codigoStatus the codigoStatus to set
	 */
	public void setCodigoStatus(Integer codigoStatus) {
		this.codigoStatus = codigoStatus;
	}
}
