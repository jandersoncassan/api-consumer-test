package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarEtapaServiceRemote;
import br.com.cielo.dashboard.service.IConsultarEtapasService;

/**
 * 
 * @author dcarneiro
 *
 */
@Service
public class ConsultarEtapaServiceImpl implements IConsultarEtapasService{

	private static final Logger LOG = LogManager.getLogger(ConsultarEtapaServiceImpl.class);
	
	@Resource(mappedName = "ConsultarEtapaService#br.com.cielo.credenciamento.service.dashboard.ConsultarEtapaServiceRemote")
	private ConsultarEtapaServiceRemote consultarEtapaServiceRemote;
	
	@Override
	public List<Object> getListaEtapas() {
		LOG.info("REALIZANDO CONSULTA DAS ETAPAS DO CREDENCIAMENTO");
		return consultarEtapaServiceRemote.getListaEtapa();
	}
	/**
	 * @param proposta
	 * @return
	 */
	public List<Object[]> getListarEtapaByProposta(Long proposta) {
		return consultarEtapaServiceRemote.getListarEtapaByProposta(proposta);
	}
}
