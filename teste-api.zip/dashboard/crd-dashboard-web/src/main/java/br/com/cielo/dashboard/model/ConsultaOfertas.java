package br.com.cielo.dashboard.model;

import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * Classe model para tratamento de consulta de ofertas
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 *
 */
public class ConsultaOfertas {

	@NotEmpty(message="{campo.ofertas.cpfcnpj}")
	private String cpfCnpj;	
	
	@NotEmpty(message="{campo.ofertas.codigo.nivel}")
	private String codigoNivel;	
	
	@NotNull(message="{campo.ofertas.qtdade}")
	private Integer qtdadeOfertas;

	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}

	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	/**
	 * @return the codigoNivel
	 */
	public String getCodigoNivel() {
		return codigoNivel;
	}

	/**
	 * @param codigoNivel the codigoNivel to set
	 */
	public void setCodigoNivel(String codigoNivel) {
		this.codigoNivel = codigoNivel;
	}

	/**
	 * @return the qtdadeOfertas
	 */
	public Integer getQtdadeOfertas() {
		return qtdadeOfertas;
	}

	/**
	 * @param qtdadeOfertas the qtdadeOfertas to set
	 */
	public void setQtdadeOfertas(Integer qtdadeOfertas) {
		this.qtdadeOfertas = qtdadeOfertas;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ConsultaOfertas [cpfCnpj=" + cpfCnpj + ", codigoNivel=" + codigoNivel + ", qtdadeOfertas="
				+ qtdadeOfertas + "]";
	}
	
	
}
