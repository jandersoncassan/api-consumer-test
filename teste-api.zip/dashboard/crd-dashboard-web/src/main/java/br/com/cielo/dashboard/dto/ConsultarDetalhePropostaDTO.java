/**
 * 
 */
package br.com.cielo.dashboard.dto;

import java.io.Serializable;

import br.com.cielo.dashboard.utils.DashboardFile;
import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author dcarneiro
 *
 */
/**
 * @author dcarneiro
 *
 */
public class ConsultarDetalhePropostaDTO implements Serializable{

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;
	
	/*DADOS DA PROPOSTA*/
	private Long proposta;
	private Long numeroEstabelecimentoComercial;
	private String razaoSocial;
	private String nomeFantasia;
	private Long inscricaoEstadual;
	private String mcc;
	private String mccValidado;
	private String nomeContato;
	private String email;
	private String indicadorOfertaMei;
	private String nomePlaqueta;
	private String afiliador;
	private String etapa;
	private Integer codigoEtapa;
	private String situacaoEtapa;
	private String situacaoProposta;
	private String dataAberturaProposta;
	private String dataAlteracaoRegistro;
	private String banco;
	private String bancoDescricao;
	private String tipoPessoa;
	private String cpfCnpj;
	private String ferramenta;	
	private String categoria;
	private Integer prioridadeAtendimento;
	private String ativado;	
    /*ATRIBUTOS OFERTAS*/
    private String indOfertaAssociada;
    private String indAceiteOferta;
    private String nivelOferta;
    private String codigoOferta;

	/**
	 * @return the proposta
	 */
	public Long getProposta() {
		return proposta;
	}
	/**
	 * @param proposta the proposta to set
	 */
	public void setProposta(Long proposta) {
		this.proposta = proposta;
	}
	/**
	 * @return the numeroEstabelecimentoComercial
	 */
	public Long getNumeroEstabelecimentoComercial() {
		return numeroEstabelecimentoComercial;
	}
	/**
	 * @param numeroEstabelecimentoComercial the numeroEstabelecimentoComercial to set
	 */
	public void setNumeroEstabelecimentoComercial(Long numeroEstabelecimentoComercial) {
		this.numeroEstabelecimentoComercial = numeroEstabelecimentoComercial;
	}
	/**
	 * @return the etapa
	 */
	public String getEtapa() {
		return etapa;
	}
	/**
	 * @param etapa the etapa to set
	 */
	public void setEtapa(String etapa) {
		this.etapa = etapa;
	}
	/**
	 * @return the situacaoProposta
	 */
	public String getSituacaoProposta() {
		return situacaoProposta;
	}
	/**
	 * @param situacaoProposta the situacaoProposta to set
	 */
	public void setSituacaoProposta(String situacaoProposta) {
		this.situacaoProposta = situacaoProposta;
	}
	/**
	 * @return the dataAberturaProposta
	 */
	public String getDataAberturaProposta() {
		return dataAberturaProposta;
	}
	/**
	 * @param dataAberturaProposta the dataAberturaProposta to set
	 */
	public void setDataAberturaProposta(String dataAberturaProposta) {
		this.dataAberturaProposta = dataAberturaProposta;
	}
	/**
	 * @return the dataAlteracaoRegistro
	 */
	public String getDataAlteracaoRegistro() {
		return dataAlteracaoRegistro;
	}
	/**
	 * @param dataAlteracaoRegistro the dataAlteracaoRegistro to set
	 */
	public void setDataAlteracaoRegistro(String dataAlteracaoRegistro) {
		this.dataAlteracaoRegistro = dataAlteracaoRegistro;
	}
	/**
	 * @return the banco
	 */
	public String getBanco() {
		return  banco;
	}
	/**
	 * @param banco the banco to set
	 */
	public void setBanco(String banco) {
		this.banco = banco;
	}
	/**
	 * @return the tipoPessoa
	 */
	public String getTipoPessoa() {
		return tipoPessoa;
	}
	/**
	 * @param tipoPessoa the tipoPessoa to set
	 */
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}
	
	/**
	 * @return the ferramenta
	 */
	public String getFerramenta() {
		return DashboardUtils.descricaFerramenta(ferramenta);
	}
	/**
	 * @param ferramenta the ferramenta to set
	 */
	public void setFerramenta(String ferramenta) {
		this.ferramenta = ferramenta;
	}
	/**
	 * @return the categoria
	 */
	public String getCategoria() {
		return categoria;
	}
	/**
	 * @param categoria the categoria to set
	 */
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	/**
	 * @return the prioridadeAtendimento
	 */
	public Integer getPrioridadeAtendimento() {
		return prioridadeAtendimento;
	}
	/**
	 * @param prioridadeAtendimento the prioridadeAtendimento to set
	 */
	public void setPrioridadeAtendimento(Integer prioridadeAtendimento) {
		this.prioridadeAtendimento = prioridadeAtendimento;
	}
	/**
	 * @return the situacaoEtapa
	 */
	public String getSituacaoEtapa() {
		return situacaoEtapa;
	}
	/**
	 * @param situacaoEtapa the situacaoEtapa to set
	 */
	public void setSituacaoEtapa(String situacaoEtapa) {
		this.situacaoEtapa = situacaoEtapa;
	}
	
	/**
	 * 
	 * @return
	 */
	public String getTipoPessoaDescricao(){
		return DashboardUtils.isNotNullOrEmpty(tipoPessoa)&&tipoPessoa.equals("F")?"FÍSICA":"JURÍDICA";
	}
	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}
	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	/**
	 * @return the razaoSocial
	 */
	public String getRazaoSocial() {
		return razaoSocial;
	}
	/**
	 * @param razaoSocial the razaoSocial to set
	 */
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	/**
	 * @return the nomeFantasia
	 */
	public String getNomeFantasia() {
		return nomeFantasia;
	}
	/**
	 * @param nomeFantasia the nomeFantasia to set
	 */
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}
	/**
	 * @return the inscricaoEstadual
	 */
	public Long getInscricaoEstadual() {
		return inscricaoEstadual;
	}
	/**
	 * @param inscricaoEstadual the inscricaoEstadual to set
	 */
	public void setInscricaoEstadual(Long inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}
	/**
	 * @return the mcc
	 */
	public String getMcc() {
		String descricaoMcc = DashboardFile.getInstance().getMessageInternal("mcc."+mcc);
		return DashboardUtils.isNotNullOrEmpty(descricaoMcc)?mcc + " - " + descricaoMcc:mcc;
	}
	/**
	 * @param mcc the mcc to set
	 */
	public void setMcc(String mcc) {
		this.mcc = mcc;
	}
	/**
	 * @return the mccValidado
	 */
	public String getMccValidado() {
		String descricaoMccValidado = DashboardFile.getInstance().getMessageInternal("mcc."+mccValidado);
		return DashboardUtils.isNotNullOrEmpty(descricaoMccValidado)?mccValidado + " - " + descricaoMccValidado:mccValidado;
	}
	/**
	 * @param mccValidado the mccValidado to set
	 */
	public void setMccValidado(String mccValidado) {
		this.mccValidado = mccValidado;
	}
	/**
	 * @return the nomeContato
	 */
	public String getNomeContato() {
		return nomeContato;
	}
	/**
	 * @param nomeContato the nomeContato to set
	 */
	public void setNomeContato(String nomeContato) {
		this.nomeContato = nomeContato;
	}
	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}
	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}
	/**
	 * @return the indicadorOfertaMei
	 */
	public String getIndicadorOfertaMei() {
		return DashboardUtils.isNotNullOrEmpty(indicadorOfertaMei)&& indicadorOfertaMei.equals("S")?"SIM":"NÃO";
	}
	/**
	 * @param indicadorOfertaMei the indicadorOfertaMei to set
	 */
	public void setIndicadorOfertaMei(String indicadorOfertaMei) {
		this.indicadorOfertaMei = indicadorOfertaMei;
	}
	/**
	 * @return the nomePlaqueta
	 */
	public String getNomePlaqueta() {
		return nomePlaqueta;
	}
	/**
	 * @param nomePlaqueta the nomePlaqueta to set
	 */
	public void setNomePlaqueta(String nomePlaqueta) {
		this.nomePlaqueta = nomePlaqueta;
	}
	/**
	 * @return the afiliador
	 */
	public String getAfiliador() {
		return afiliador;
	}
	/**
	 * @param afiliador the afiliador to set
	 */
	public void setAfiliador(String afiliador) {
		this.afiliador = afiliador;
	}
	/**
	 * @return the ativado
	 */
	public String getAtivado() {
		return ativado;
	}
	/**
	 * @param ativado the ativado to set
	 */
	public void setAtivado(String ativado) {
		this.ativado = ativado;
	}
	/**
	 * @return the codigoEtapa
	 */
	public Integer getCodigoEtapa() {
		return codigoEtapa;
	}
	/**
	 * @param codigoEtapa the codigoEtapa to set
	 */
	public void setCodigoEtapa(Integer codigoEtapa) {
		this.codigoEtapa = codigoEtapa;
	}
	/**
	 * @return the indOfertaAssociada
	 */
	public String getIndOfertaAssociada() {
		return indOfertaAssociada;
	}
	/**
	 * @param indOfertaAssociada the indOfertaAssociada to set
	 */
	public void setIndOfertaAssociada(String indOfertaAssociada) {
		this.indOfertaAssociada = indOfertaAssociada;
	}
	/**
	 * @return the indAceiteOferta
	 */
	public String getIndAceiteOferta() {
		return indAceiteOferta;
	}
	/**
	 * @param indAceiteOferta the indAceiteOferta to set
	 */
	public void setIndAceiteOferta(String indAceiteOferta) {
		this.indAceiteOferta = indAceiteOferta;
	}
	/**
	 * @return the nivelOferta
	 */
	public String getNivelOferta() {
		return nivelOferta;
	}
	/**
	 * @param nivelOferta the nivelOferta to set
	 */
	public void setNivelOferta(String nivelOferta) {
		this.nivelOferta = nivelOferta;
	}
	/**
	 * @return the codigoOferta
	 */
	public String getCodigoOferta() {
		return codigoOferta;
	}
	/**
	 * @param codigoOferta the codigoOferta to set
	 */
	public void setCodigoOferta(String codigoOferta) {
		this.codigoOferta = codigoOferta;
	}
	public String getBancoDescricao() {
		return bancoDescricao;
	}
	public void setBancoDescricao(String bancoDescricao) {
		this.bancoDescricao = bancoDescricao;
	}
	
}
