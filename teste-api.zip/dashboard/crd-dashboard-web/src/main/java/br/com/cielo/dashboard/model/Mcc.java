package br.com.cielo.dashboard.model;

import java.io.Serializable;

public class Mcc implements Serializable{
	
	private Ferramenta ferramenta;
	private String tipoPessoa;
	private Integer codigoMcc;
	private Usuario usuarioInclusao;
	private String dataInclusao;
	
	public Ferramenta getFerramenta(){
		return this.ferramenta;
	}
	
	public void setFerramenta(Ferramenta value){
		this.ferramenta = value;
	}
	
	public String getTipoPessoa(){
		return this.tipoPessoa;
	}
	
	public void setTipoPessoa(String value){
		this.tipoPessoa = value;
	}
	
	public Integer getCodigoMcc(){
		return this.codigoMcc;
	}
	
	public void setCodigoMcc(Integer value){
		this.codigoMcc = value;
	}
	
	public Usuario getUsuarioInclusao(){
		return this.usuarioInclusao;
	}
	
	public void setUsuarioInclusao(Usuario value){
		this.usuarioInclusao = value;
	}
	
	public String getDataInclusao(){
		return this.dataInclusao;
	}
	
	public void setDataInclusao(String value){
		this.dataInclusao = value;
	}	
	
}