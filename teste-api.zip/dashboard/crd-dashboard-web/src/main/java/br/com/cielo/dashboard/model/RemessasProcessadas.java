/**
 * 
 */
package br.com.cielo.dashboard.model;

import java.io.Serializable;
import java.util.Date;

import br.com.cielo.dashboard.utils.DashboardUtils;

/**
 * @author dcarneiro
 *
 */
public class RemessasProcessadas implements Serializable {
	
	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;
	private Integer numeroRemessa;
	private String  statusRemessa;
	private String  bancoOrigem;
	private String  bancoOrigemDescricao;
	private Date  dataMovimentoDate;
	private String  dataMovimento;
	private Integer totalRegistros;
	private Integer totalRegistrosProcessados;
	private Integer totalRegistrosRejeitados;
	private Date dataAlteracaoDate;
	private String dataAlteracao;
	/**
	 * @return the numeroRemessa
	 */
	public Integer getNumeroRemessa() {
		return numeroRemessa;
	}
	/**
	 * @param numeroRemessa the numeroRemessa to set
	 */
	public void setNumeroRemessa(Integer numeroRemessa) {
		this.numeroRemessa = numeroRemessa;
	}
	/**
	 * @return the bancoOrigem
	 */
	public String getBancoOrigem() {
		return bancoOrigem;
	}
	/**
	 * @param bancoOrigem the bancoOrigem to set
	 */
	public void setBancoOrigem(String bancoOrigem) {
		this.bancoOrigem = bancoOrigem;
	}
	/**
	 * @return the dataMovimento
	 */
	public String getDataMovimento() {
		return dataMovimento;
	}
	/**
	 * @param dataMovimento the dataMovimento to set
	 */
	public void setDataMovimento(String dataMovimento) {
		this.dataMovimento = dataMovimento;
	}
	/**
	 * @return the totalRegistros
	 */
	public Integer getTotalRegistros() {
		return totalRegistros;
	}
	/**
	 * @param totalRegistros the totalRegistros to set
	 */
	public void setTotalRegistros(Integer totalRegistros) {
		this.totalRegistros = totalRegistros;
	}
	/**
	 * @return the totalRegistrosProcessados
	 */
	public Integer getTotalRegistrosProcessados() {
		return totalRegistrosProcessados;
	}
	/**
	 * @param totalRegistrosProcessados the totalRegistrosProcessados to set
	 */
	public void setTotalRegistrosProcessados(Integer totalRegistrosProcessados) {
		this.totalRegistrosProcessados = totalRegistrosProcessados;
	}
	/**
	 * @return the totalRegistrosRejeitados
	 */
	public Integer getTotalRegistrosRejeitados() {
		return totalRegistrosRejeitados;
	}
	/**
	 * @param totalRegistrosRejeitados the totalRegistrosRejeitados to set
	 */
	public void setTotalRegistrosRejeitados(Integer totalRegistrosRejeitados) {
		this.totalRegistrosRejeitados = totalRegistrosRejeitados;
	}
	/**
	 * @return the statusRemessa
	 */
	public String getStatusRemessa() {
		if(statusRemessa.equalsIgnoreCase(DashboardUtils.N) && 
				(totalRegistros > (this.totalRegistrosProcessados + totalRegistrosRejeitados))){
			return DashboardUtils.EM_PROCESSAMENTO;
		}else if(statusRemessa.equalsIgnoreCase(DashboardUtils.N) && 
				(totalRegistros == (this.totalRegistrosProcessados + totalRegistrosRejeitados))){
			return DashboardUtils.PROCESSADO;
		}else{
			return DashboardUtils.ENVIADO;
		}
	}
	/**
	 * @param statusRemessa the statusRemessa to set
	 */
	public void setStatusRemessa(String statusRemessa) {
		this.statusRemessa = statusRemessa;
	}
	/**
	 * @return the dataAlteracao
	 */
	public String getDataAlteracao() {
		return dataAlteracao;
	}
	/**
	 * @param dataAlteracao the dataAlteracao to set
	 */
	public void setDataAlteracao(String dataAlteracao) {
		this.dataAlteracao = dataAlteracao;
	}
	public Date getDataMovimentoDate() {
		return dataMovimentoDate;
	}
	public void setDataMovimentoDate(Date dataMovimentoDate) {
		this.dataMovimentoDate = dataMovimentoDate;
	}
	public Date getDataAlteracaoDate() {
		return dataAlteracaoDate;
	}
	public void setDataAlteracaoDate(Date dataAlteracaoDate) {
		this.dataAlteracaoDate = dataAlteracaoDate;
	}
	public String getBancoOrigemDescricao() {
		return bancoOrigemDescricao;
	}
	public void setBancoOrigemDescricao(String bancoOrigemDescricao) {
		this.bancoOrigemDescricao = bancoOrigemDescricao;
	}
	
	
}
