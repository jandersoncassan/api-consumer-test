package br.com.cielo.dashboard.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import br.com.cielo.dashboard.model.ConsultaOfertas;
import br.com.cielo.dashboard.model.Oferta;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.service.IOfertasService;

@Controller
public class ConsultarOfertasController {

	private static final Logger LOG = LogManager.getLogger(ConsultarOfertasController.class);

	@Autowired
	private IOfertasService ofertasService;
	
	@RequestMapping("/initPageOfertas")
	private String getPageOfertas(Model model){
		model.addAttribute("ofertas", new ConsultaOfertas());
		return NavigationDashBoard.CONSULTAR_OFERTAS;
	}
	
	@RequestMapping("/consultarOfertas")
	private String consultarOfertas(@ModelAttribute("ofertas") @Valid ConsultaOfertas ofertas, BindingResult bindingResult, Model model) {
		LOG.info("INIT PAGE CONSULTAR OFERTAS INTERACT");		
		if(bindingResult.hasErrors()){
			return NavigationDashBoard.CONSULTAR_OFERTAS;
		}		
		try{
			Optional<List<Oferta>> listaOfertas = ofertasService.consultarOfertas(ofertas);
			if(listaOfertas.isPresent()){
				model.addAttribute("listaOfertas", listaOfertas.get());			
			}else{
				model.addAttribute("notFound", "notFound");	
			}
		}catch(Exception ex){
			model.addAttribute("error", "error");
		}
		
		return NavigationDashBoard.CONSULTAR_OFERTAS;
	}

}
