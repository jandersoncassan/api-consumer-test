/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarCriticasService {
	/**
	 * Método: Obtem criticas relacionadas a proposta
	 * @param proposta
	 * @return
	 */
	List<Object[]> getListaCriticasByProposta(final Long proposta);
	/**
	 * Método: Listar todos as criticas parametrizadas
	 * @return
	 */
	List<Object> getListarCriticas();
}
