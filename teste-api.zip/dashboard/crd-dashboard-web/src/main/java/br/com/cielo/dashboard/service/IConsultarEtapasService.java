/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarEtapasService {
	/**
	 * Método: Obtem lista de etapas
	 * @return
	 */
	List<Object> getListaEtapas();
	/**
	 * Método: Consultar etapa da proposta
	 * @param proposta
	 * @return
	 */
	List<Object[]> getListarEtapaByProposta(final Long proposta);	

}
