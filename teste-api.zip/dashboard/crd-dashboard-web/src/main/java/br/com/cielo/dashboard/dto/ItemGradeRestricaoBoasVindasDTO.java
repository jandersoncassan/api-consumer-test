package br.com.cielo.dashboard.dto;

import java.io.Serializable;

public class ItemGradeRestricaoBoasVindasDTO implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String codigoBanco;
	private String descricaoBanco;
	private Integer codigoMcc;
	private String descricaoMcc;
	private Integer codigoSolucaoCaptura;
	private String descricaoSolucaoCaptura;
	private String idRestricaoBoasVindas;
	public String getCodigoBanco() {
		return codigoBanco;
	}
	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
		atualizarId();
	}
	public String getDescricaoBanco() {
		return descricaoBanco;
	}
	public void setDescricaoBanco(String descricaoBanco) {
		this.descricaoBanco = descricaoBanco;
		
	}
	public Integer getCodigoMcc() {
		return codigoMcc;
	}
	public void setCodigoMcc(Integer codigoMcc) {
		this.codigoMcc = codigoMcc;
		atualizarId();
	}
	public String getDescricaoMcc() {
		return descricaoMcc;
	}
	public void setDescricaoMcc(String descricaoMcc) {
		this.descricaoMcc = descricaoMcc;
	}
	public Integer getCodigoSolucaoCaptura() {
		return codigoSolucaoCaptura;
	}
	public void setCodigoSolucaoCaptura(Integer codigoSolucaoCaptura) {
		this.codigoSolucaoCaptura = codigoSolucaoCaptura;
		atualizarId();
	}
	public String getDescricaoSolucaoCaptura() {
		return descricaoSolucaoCaptura;
	}
	public void setDescricaoSolucaoCaptura(String descricaoSolucaoCaptura) {
		this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
	}
	public String getIdRestricaoBoasVindas() {
		return idRestricaoBoasVindas;
	}
	
	private void atualizarId(){
		
		this.idRestricaoBoasVindas = codigoBanco + '_' 
				+ String.valueOf(this.codigoMcc) + '_'
				+ String.valueOf(this.codigoSolucaoCaptura);
	}

	
}
