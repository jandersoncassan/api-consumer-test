/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarTelefoneServiceRemote;
import br.com.cielo.dashboard.service.IConsultarTelefoneService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarTelefoneServiceImpl implements IConsultarTelefoneService {
	
	@Resource(mappedName ="ConsultarTelefoneService#br.com.cielo.credenciamento.service.dashboard.ConsultarTelefoneServiceRemote")
	private ConsultarTelefoneServiceRemote consultarTelefoneServiceRemote;
	/**
	 * @param proposta
	 * @return
	 */
	public List<Object[]> getListarTelefoneByProposta(Long proposta) {
		return consultarTelefoneServiceRemote.getListaTelefoneByProposta(proposta);
	}

}
