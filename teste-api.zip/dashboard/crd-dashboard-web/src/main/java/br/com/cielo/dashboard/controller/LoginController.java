package br.com.cielo.dashboard.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.dashboard.dto.InfoUsuarioLdapDTO;
import br.com.cielo.dashboard.model.Usuario;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.CustomMethodSecurityExpression;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.AuthenticationService;
import br.com.cielo.dashboard.utils.DashboardFile;

@Controller
@Scope(value=WebApplicationContext.SCOPE_REQUEST)
public class LoginController {

	private static final Logger LOG = LogManager.getLogger(LoginController.class);
	
	@Autowired
	private AuthenticationService authenticationService;
	
	@Autowired
	private CustomMethodSecurityExpression customMethodSecurityExpression;
	
	@RequestMapping({ "/", "/welcome"}) 
	public String pageHome(Model model) {
		model.addAttribute("usuario", new Usuario());
		LOG.debug("Redirecionando para a página de login");
		return NavigationDashBoard.LOGIN;
	}
	
	@RequestMapping(value = "/processLogin", method = RequestMethod.POST)
	private String validarLogin(@ModelAttribute("usuario") @Valid Usuario usuario, BindingResult bindingResult, Model model, HttpSession session) {
		if (bindingResult.hasErrors()) {
			return NavigationDashBoard.LOGIN;
		}		
		
		if(isBypassUserAdmin(usuario)){
			bypassUserAdmin(session, usuario);
			return tratarPageLogin(usuario);
		}
		
		if(!validarUserLdap(usuario, model, session)){
			return NavigationDashBoard.LOGIN;
		}
		
		return tratarPageLogin(usuario);		
	}
	
	@RequestMapping({ "/initWelcome"}) 
	public String pageHome() {		
		return NavigationDashBoard.PAGE_WELCOME;
	}

	/**
	 * Método responsavel pela autenticação do Usuario no LDAP
	 * @param usuario
	 * @return Boolean
	 */ 
	private Boolean validarUserLdap(Usuario usuario, Model model, HttpSession session){		
		LOG.info("AUTENTICACAO / AUTORIZACAO LDAP | USUARIO (".concat(usuario.getLogin().concat(")")));
		try{
			InfoUsuarioLdapDTO infoUsuario = authenticationService.autenticarAutorizar(usuario);
			
			usuario.setNome(infoUsuario.getUserName());
			usuario.setListaRoles(infoUsuario.getListaRoles());
			
			LOG.info("ROLES do usuário " + usuario.getLogin() + ": " + usuario.getListaRoles());
			
			SecurityContextHolder.getContext().setAuthentication(authenticationService.createToken(usuario));
			
			validarRolesUsuario(session, usuario.getLogin(), usuario.getListaRoles());
			
			popularUsuarioLogado(session, usuario.getLogin(), usuario.getListaRoles(), usuario.getNome());
			
			return Boolean.TRUE;

		} catch(Exception ex) {
			model.addAttribute("error", ex.getMessage());
			return Boolean.FALSE;
		}
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	private String validarLogin(Model model,  HttpServletRequest request) throws ServletException {
		request.getSession().invalidate();
		request.logout();
		return pageHome(model);
	}

	/**
	 * Método responsavel por popular o nome do usuário logado na aplicação
	 * @param model
	 * @param usuarioLogado
	 */
	private void popularUsuarioLogado(HttpSession session, String usuarioLogado, List<String> userRoles, String nome){
		session.setAttribute("username", usuarioLogado.toUpperCase());
		session.setAttribute("userRoles", userRoles);
		session.setAttribute("nome", nome);
	}
	
	/**
	 * Faz uma rápida validação para verificar se o usuário possui as roles corretas 
	 * @param session
	 * @param usuarioLogado
	 * @param userRoles
	 */
	private void validarRolesUsuario(HttpSession session, String usuarioLogado, List<String> userRoles){
		
		List<String> mensagensRolesInvalidas = new ArrayList<String>();
		
		if ( (userRoles == null) || (userRoles.isEmpty()) ) {
			mensagensRolesInvalidas.add("Usuário não possui permissões.");
		} else {
			
			if (userRoles.contains(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA)) {
				if (!customMethodSecurityExpression.hasAnyRoleBanco()) {
					mensagensRolesInvalidas.add("Usuário não possui permissão de bancos.");
				}
				
				if (!customMethodSecurityExpression.hasAnyRoleFerramenta()) {
					mensagensRolesInvalidas.add("Usuário não possui permissão de ferramentas.");
				}
			}
			
		}
		
		session.setAttribute("mensagensRolesInvalidas", mensagensRolesInvalidas);
		
	}
	
	/**
	 * 
	 * @param usuario
	 * @return Boolean
	 */
	private Boolean isBypassUserAdmin(Usuario usuario){
		
		String adminUserEnable = isAdminUserEnable();
		
		LOG.info("Admin user enabled: " + adminUserEnable);
		
		return  usuario.getLogin().toUpperCase().equals("ADMIN")
				&& adminUserEnable != null 
				&& adminUserEnable.equals("true");
	}
	
	/**
	 * 
	 * @return String
	 */
	private void bypassUserAdmin(HttpSession session, Usuario usuario){
		LOG.info("AUTENTICACAO / AUTORIZACAO BYPASS | USUARIO ADMIN ");
		usuario.setNome("Admin");
		/*
		 * APENAS PARA TESTE
		 */
		switch(usuario.getSenha()) {
			case "1": //sem nada
				break;
			case "2": // só lista
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				break;
			case "3": // só exportar
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				break;
			case "4": //sem remessa
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				break;
			case "5": // sem proposta
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				break;
			case "6": //sem dash
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				break;
			case "7": //CENTRAL
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
				break;
			case "8": //OFERTAS
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				break;
			case "10": 
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_BANCO_001);
				usuario.addRole(SecurityRole.ROLE_CRD_BANCO_104);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_BANCO);
				break;
			case "11":
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_BANCO_104);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_BANCO);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_SITE);
				break;
			case "12":
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_BANCO);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_SITE);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_TODAS);
				break;
			case "13":
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_BANCO);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_SITE);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_TODAS);
				break;
			case "14":
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
				break;
            case "15":
                usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_TV);
                break;                
            case "16": //FEIRAS		
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_FEIRA);
				break;
            case "17": //SMART DDN	
 				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART);
 				usuario.addRole(SecurityRole.ROLE_CRD_TIPO_USUARIO_DDN);
 				break;
            case "18": //SMART ISO
  				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART);
  				usuario.addRole(SecurityRole.ROLE_CRD_TIPO_USUARIO_ISO);
  				break;
            case "19": //SMART COMERCIAL
  				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART);
  				usuario.addRole(SecurityRole.ROLE_CRD_TIPO_USUARIO_COMERCIAL);
  				break;
            case "20": // CRD Smart Usuário DDN Master
            	usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
                usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
                usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_SMART);
                usuario.addRole(SecurityRole.ROLE_CRD_TIPO_USUARIO_DDN);
                break;
            case "21": // CRD Smart Usuário DDN
            	usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
                usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
                usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_SMART);
                usuario.addRole(SecurityRole.ROLE_CRD_TIPO_USUARIO_DDN);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_USUARIO_UNICO);
                break;
            case "22": // CRD Smart Usuário Comercial
            	usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
                usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
                usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_SMART);
                usuario.addRole(SecurityRole.ROLE_CRD_TIPO_USUARIO_COMERCIAL);
                break;
            case "23": // CRD Central Usuário Master
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
                usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
                usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
                usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
                usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_CENTRAL);
                break;
            default:
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_PROPOSTA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_REMESSA_LISTA);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_VER);
				usuario.addRole(SecurityRole.ROLE_CRD_SIMULADOR);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_CENTRAL);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_FEIRA);
				usuario.addRole(SecurityRole.ROLE_CRD_CREDENCIAMENTO_SMART);
				usuario.addRole(SecurityRole.ROLE_CRD_CONSULTA_OFERTAS);
				usuario.addRole(SecurityRole.ROLE_CRD_DASHBOARD_TV);
				usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
				usuario.addRole(SecurityRole.ROLE_CRD_FERRAMENTA_TODAS);
				usuario.addRole(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR);
				usuario.addRole(SecurityRole.ROLE_CRD_PARAMETRIZACAO_EXPORTAR);
				usuario.addRole(SecurityRole.ROLE_CRD_BANCO_TODOS);
				break;
		}
			
		SecurityContextHolder.getContext().setAuthentication(authenticationService.createToken(usuario));
		
		validarRolesUsuario(session, usuario.getLogin(), usuario.getListaRoles());
		
		popularUsuarioLogado(session, usuario.getLogin(), usuario.getListaRoles(), usuario.getNome());
		
	} 

	/**
	 * Metodo auxiliar para tratamento de 'mock' bypass na autenticação 
	 * @return
	 */
	private String isAdminUserEnable(){
		return DashboardFile.getInstance().getMessageExternal("admin.user.enabled");
	}
	
	/**
	 * Tratamento para carregar a pagina home
	 * 
	 * @param usuario
	 * @return
	 */
	private String tratarPageLogin(Usuario usuario){
		
		if (usuario.getListaAuthorities().isEmpty()) {
			return NavigationDashBoard.PAGE_ACCESS_DENIED;
		} 
		return NavigationDashBoard.HOME;
	}
}
