/**
 * 
 */
package br.com.cielo.dashboard.model;

import java.io.Serializable;

/**
 * @author dcarneiro
 *
 */
public class Proprietarios implements Serializable{

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;

	private String nomeProprietario;
	private String cpf;
	private String dataNascimento;
	/**
	 * @return the nomeProprietario
	 */
	public String getNomeProprietario() {
		return nomeProprietario;
	}
	/**
	 * @param nomeProprietario the nomeProprietario to set
	 */
	public void setNomeProprietario(String nomeProprietario) {
		this.nomeProprietario = nomeProprietario;
	}
	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}
	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	/**
	 * @return the dataNascimento
	 */
	public String getDataNascimento() {
		return dataNascimento;
	}
	/**
	 * @param dataNascimento the dataNascimento to set
	 */
	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
}
