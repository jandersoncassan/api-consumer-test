package br.com.cielo.dashboard.dto;

import java.io.Serializable;
import java.util.List;

public class ValidacaoDomicilioBancarioFiltroDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<Integer> codigosFerramenta;
	List<Integer> codigosSolucaoCaptura;
	private Integer filtroAtivo;
	
	public List<Integer> getCodigosFerramenta() {
		return codigosFerramenta;
	}
	public void setCodigosFerramenta(List<Integer> codigosFerramenta) {
		this.codigosFerramenta = codigosFerramenta;
	}
	public List<Integer> getCodigosSolucaoCaptura() {
		return codigosSolucaoCaptura;
	}
	public void setCodigosSolucaoCaptura(List<Integer> codigosSolucaoCaptura) {
		this.codigosSolucaoCaptura = codigosSolucaoCaptura;
	}
	public Integer getFiltroAtivo(){
		return filtroAtivo;
	}
	public void setFiltroAtivo(Integer filtroAtivo){
		this.filtroAtivo = filtroAtivo;
	}
	
	
}
