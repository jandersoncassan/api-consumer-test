package br.com.cielo.dashboard.dto;

public class ItemGradeConfirmacaoMccDTO {
	
	private String descricaoFerramenta;
	private String descricaoMcc;
	private String tipoPessoa;
	private String tipoManutencao;
	
	public String getDescricaoFerramenta() {
		return descricaoFerramenta;
	}
	public void setDescricaoFerramenta(String descricaoFerramenta) {
		this.descricaoFerramenta = descricaoFerramenta;
	}
	public String getDescricaoMcc() {
		return descricaoMcc;
	}
	public void setDescricaoMcc(String descricaoMcc) {
		this.descricaoMcc = descricaoMcc;
	}
	public String getTipoPessoa(){
		return tipoPessoa;
	}
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}
	public String getTipoManutencao() {
		return tipoManutencao;
	}
	public void setTipoManutencao(String tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}
}
