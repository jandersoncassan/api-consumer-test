/**
*
**/
package br.com.cielo.dashboard.controller;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.context.WebApplicationContext;

import br.com.cielo.credenciamento.dto.FerramentaDTO;
import br.com.cielo.credenciamento.dto.MccDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccIdDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccManutencaoDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoMccManutencaoRequestDTO;
import br.com.cielo.dashboard.dto.ConsultarMccDTO;
import br.com.cielo.dashboard.dto.ItemGradeConfirmacaoMccDTO;
import br.com.cielo.dashboard.dto.ItemParametrizacaoMccDTO;
import br.com.cielo.dashboard.dto.ParametrizacaoMccAuxiliarDTO;
import br.com.cielo.dashboard.navigation.NavigationDashBoard;
import br.com.cielo.dashboard.security.SecurityRole;
import br.com.cielo.dashboard.service.IFerramentaService;
import br.com.cielo.dashboard.service.IParametrizacaoMCCService;
import br.com.cielo.dashboard.utils.DashboardUtils;


@Controller
@Scope(value=WebApplicationContext.SCOPE_REQUEST)
public class MccController {
	
	@Autowired
	private IParametrizacaoMCCService parametrizacaoMCCService;
	
	@Autowired
	private IFerramentaService ferramentaService;
	
	@RequestMapping("/initMcc")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String initMcc(Model model, HttpSession session, Authentication authentication) throws IOException {
		
		ConsultarMccDTO consultarMccDto = initialize();
		model.addAttribute("consultar_mcc", consultarMccDto);
		carregarServicos(session, model, authentication);
		
		ParametrizacaoMccAuxiliarDTO parametrizacaoMcc = new ParametrizacaoMccAuxiliarDTO();
		model.addAttribute("parametrizacaoMcc", parametrizacaoMcc);
		session.setAttribute("parametrizacaoMcc", parametrizacaoMcc);
		
		return NavigationDashBoard.CADASTRO_MCC;
	}
	
	@RequestMapping("/consultarMcc")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_CONSULTAR)
	public String consultar(@ModelAttribute("consultar_mcc") @Valid ConsultarMccDTO consultar,
			BindingResult bindingResult, HttpSession session, Model model) throws ParseException {

		model = carregarAtributosSession(session, model);

		model.addAttribute("parametrizacaoMcc", gerarListaParametrizacaoMcc(consultar, session, model));
		
		return NavigationDashBoard.CADASTRO_MCC;
	}
	
	@RequestMapping("/identificarAtualizacoesMcc")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR)
	public String identificarAtualizacoes(@ModelAttribute("parametrizacaoMcc") @Valid ParametrizacaoMccAuxiliarDTO parametrizacaoMcc,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication) throws ParseException {
		
		List<ParametrizacaoMccManutencaoDTO> listAtualizacoes = identificarAtualizacoes(parametrizacaoMcc, session, model);
		
		Map<Integer, String> mapMcc = (Map<Integer, String>) session.getAttribute("mapDominioMcc");
		Map<Integer, String> mapFerramentas = (Map<Integer, String>) session.getAttribute("mapFerramentas");
		
		List<ItemGradeConfirmacaoMccDTO> listConfirmacao = listAtualizacoes.stream()
				.map(item -> toItemConfirmacaoDTO(item, mapMcc, mapFerramentas))
				.collect(Collectors.toList());

		model.addAttribute("listConfirmacao", listConfirmacao);
		
		session.setAttribute("listAtualizacoes", listAtualizacoes);
		
		ParametrizacaoMccAuxiliarDTO parametrizacaoOriginal = (ParametrizacaoMccAuxiliarDTO) session.getAttribute("parametrizacaoMcc");
		
		parametrizacaoMcc.setListaItensParametrizacaoMcc(parametrizacaoOriginal.getListaItensParametrizacaoMcc());
		
		model.addAttribute("consultar_mcc", session.getAttribute("consultar_mcc"));
		model.addAttribute("parametrizacaoMcc", parametrizacaoMcc);
		model.addAttribute("listAtualizacoes", listAtualizacoes);
		
		return NavigationDashBoard.CADASTRO_MCC;
	}
	
	private ItemGradeConfirmacaoMccDTO toItemConfirmacaoDTO(ParametrizacaoMccManutencaoDTO item, Map<Integer, String> mapDominioMcc,
			Map<Integer, String> mapFerramentas) {
		
		ItemGradeConfirmacaoMccDTO retorno = new ItemGradeConfirmacaoMccDTO();
		retorno.setDescricaoFerramenta(mapFerramentas.get(item.getId().getCodigoFerramenta()));
		retorno.setDescricaoMcc(mapDominioMcc.get(item.getId().getCodigoMcc()));
		retorno.setTipoPessoa(item.getId().getTipoPessoa());
		if (item.isAtivo()){
			retorno.setTipoManutencao("Inclusão");
		}
		else
		{
			retorno.setTipoManutencao("Exclusão");
		}
		return retorno;
	}
	
	@RequestMapping("/atualizarMcc")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_ATUALIZAR)
	public String atualizar(@ModelAttribute("parametrizacaoMcc") @Valid ParametrizacaoMccAuxiliarDTO parametrizacaoMcc2,
			BindingResult bindingResult, HttpSession session, Model model, Authentication authentication) throws ParseException {
		
		try 
		{
			
			List<ParametrizacaoMccManutencaoDTO> listaAtualizacoes = (List<ParametrizacaoMccManutencaoDTO>) session.getAttribute("listAtualizacoes");
		
			aplicarAlteracoes(listaAtualizacoes, session, model, authentication);
			
			model = carregarAtributosSession(session, model);
			
			model.addAttribute("parametrizacaoMcc", gerarListaParametrizacaoMcc((ConsultarMccDTO) session.getAttribute("consultar_mcc"), session, model));
			
		}
		catch (Exception e) {
				model.addAttribute("error", "Erro durante a atualização: " + e.getMessage());
				return NavigationDashBoard.CADASTRO_MCC;
		}
		
		model.addAttribute("success", "Atualização realizada com sucesso!");
		return NavigationDashBoard.CADASTRO_MCC;
		
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping("/exportParametrizacaoMcc")
	@Secured(SecurityRole.ROLE_CRD_PARAMETRIZACAO_EXPORTAR)
	public void exportParametrizacaoMcc(@ModelAttribute("parametrizacaoMcc") @Valid ConsultarMccDTO consultar,
			BindingResult bindingResult, HttpSession session, Model model, HttpServletResponse response)
			throws Exception {
		
		
		XSSFWorkbook wb = new XSSFWorkbook();
		String[] hearders = new String[] {"FERRAMENTA"
										, "CÓD. MCC"
										, "RAMO DE ATIVIDADE"
										, "ATIVO PESSOA JURÍDICA"
										, "ATIVO PESSOA FÍSICA"
										};
		try {
			ParametrizacaoMccAuxiliarDTO parametrizacaoMccAuxiliarDTO = (ParametrizacaoMccAuxiliarDTO) session.getAttribute("parametrizacaoMcc");

			List<ItemParametrizacaoMccDTO> listaItensMcc = parametrizacaoMccAuxiliarDTO.getListaItensParametrizacaoMcc();
			
			XSSFSheet sheet = wb.createSheet();
			XSSFRow row = sheet.createRow(0);

			/* create style */
			XSSFCellStyle style = wb.createCellStyle();
			XSSFFont font = wb.createFont();
			font.setBold(Boolean.TRUE);
			font.setFontHeightInPoints((short) 12);
			style.setFillForegroundColor(IndexedColors.AQUA.getIndex());
			style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			style.setFont(font);
			
			for (int i = 0; i < hearders.length; i++) {
				XSSFCell cell = row.createCell(i);
				cell.setCellValue(hearders[i]);
				cell.setCellStyle(style);
				sheet.setColumnWidth(i, i == 0 || i == 1 ? 2500 : 6000);
			}
			


			if (!listaItensMcc.isEmpty()) {
				for (int i = 0; i < listaItensMcc.size(); i++) {
					
					XSSFRow rowConteudo = sheet.createRow(i + 1);
					
					rowConteudo.createCell((int) 0).setCellValue(listaItensMcc.get(i).getDescricaoFerramenta());
					rowConteudo.createCell((int) 1).setCellValue(listaItensMcc.get(i).getIdMcc()); 
					rowConteudo.createCell((int) 2).setCellValue(listaItensMcc.get(i).getDescricaoMcc());
					if (parametrizacaoMccAuxiliarDTO.getItensMccsPJAtivosFerramenta().contains(listaItensMcc.get(i).getIdItemParametrizacaoMccPJ())) {
						rowConteudo.createCell((int) 3).setCellValue("ATIVO");
					}
					else{
						rowConteudo.createCell((int) 3).setCellValue("INATIVO");
					}
					
					
					if (parametrizacaoMccAuxiliarDTO.getItensMccsPFAtivosFerramenta().contains(listaItensMcc.get(i).getIdItemParametrizacaoMccPF())) {
						rowConteudo.createCell((int) 4).setCellValue("ATIVO");
					}
					else{
						rowConteudo.createCell((int) 4).setCellValue("INATIVO");
					}

				}
			}
			DashboardUtils.contentTypeForBrowser(response, wb, "RELATORIO_PARAM_MCC");
		} catch (Exception e) {
			throw e;
		}
		
	}
	
	private List<ParametrizacaoMccManutencaoDTO> identificarAtualizacoes(ParametrizacaoMccAuxiliarDTO parametrizacaoMcc, HttpSession session, Model model){
		
		ParametrizacaoMccAuxiliarDTO parametrizacaoOriginal = (ParametrizacaoMccAuxiliarDTO) session.getAttribute("parametrizacaoMcc");
		
		List<String> excluirItens = new ArrayList<String>();
		List<String> incluirItens = new ArrayList<String>();
		
		excluirItens.addAll(parametrizacaoOriginal.getItensMccsPFAtivosFerramentaOriginal().stream()
				.filter(p -> !parametrizacaoMcc.getItensMccsPFAtivosFerramenta().contains(p))
				.collect(Collectors.toList()));
		excluirItens.addAll(parametrizacaoOriginal.getItensMccsPJAtivosFerramentaOriginal().stream()
				.filter(p -> !parametrizacaoMcc.getItensMccsPJAtivosFerramenta().contains(p))
				.collect(Collectors.toList()));

		incluirItens.addAll(parametrizacaoMcc.getItensMccsPFAtivosFerramenta().stream()
				.filter(p -> !parametrizacaoOriginal.getItensMccsPFAtivosFerramentaOriginal().contains(p))
				.collect(Collectors.toList()));
		incluirItens.addAll(parametrizacaoMcc.getItensMccsPJAtivosFerramenta().stream()
				.filter(p -> !parametrizacaoOriginal.getItensMccsPJAtivosFerramentaOriginal().contains(p))
				.collect(Collectors.toList()));

		List<ParametrizacaoMccManutencaoDTO> listaParametrizacaoManutencaoDTO = new ArrayList<ParametrizacaoMccManutencaoDTO>();
		
		for(String chaveObj: excluirItens){
			listaParametrizacaoManutencaoDTO.add(convertChaveItemListaToParametrizacaoMccManutencao(chaveObj, false));
		}
		for(String chaveObj: incluirItens){
			listaParametrizacaoManutencaoDTO.add(convertChaveItemListaToParametrizacaoMccManutencao(chaveObj, true));
		}
		
		return listaParametrizacaoManutencaoDTO;
		
	}
	
	
	private void aplicarAlteracoes(List<ParametrizacaoMccManutencaoDTO> listaParametrizacaoManutencaoDTO, HttpSession session, Model model,
			Authentication authentication) {
		
		ParametrizacaoMccManutencaoRequestDTO parametrizacaoMccManutencaoRequestDTO = new ParametrizacaoMccManutencaoRequestDTO();
		parametrizacaoMccManutencaoRequestDTO.setListaManutencoes(listaParametrizacaoManutencaoDTO);
		parametrizacaoMccManutencaoRequestDTO.setCodigoUsuario((String) session.getAttribute("username"));
		
		parametrizacaoMCCService.atualizarParametrizacao(parametrizacaoMccManutencaoRequestDTO);
		
	}
	
	private ParametrizacaoMccManutencaoDTO convertChaveItemListaToParametrizacaoMccManutencao(String chaveItem, boolean ativo){
		
		String[] chave = chaveItem.split("_");
		
		ParametrizacaoMccIdDTO chaveObj = new ParametrizacaoMccIdDTO(); 
		chaveObj.setTipoPessoa(chave[0]);
		chaveObj.setCodigoFerramenta(Integer.parseInt(chave[1]));
		chaveObj.setCodigoMcc(Integer.parseInt(chave[2]));
		ParametrizacaoMccManutencaoDTO item = new ParametrizacaoMccManutencaoDTO();
		item.setId(chaveObj);
		item.setAtivo(ativo);
		
		return item;
	}
	
	private void carregarServicos(HttpSession session, Model model, Authentication authentication){
		
		carregarDominioMCC(session, model);
		carregarFerramentas(model, session);
				
	}
	
	private void carregarDominioMCC(HttpSession session, Model model){
		
		List<MccDTO> listaDominioMcc = parametrizacaoMCCService.getListaDominiosMcc();
		
		Map<Integer, String> mapMccsTemp = (Map<Integer, String>) listaDominioMcc.stream()
				.collect(Collectors.toMap(MccDTO::getIdMcc, b -> b.getDescricaoMcc()));

		Map<Integer, String> mapMccs = mapMccsTemp.entrySet().stream()
				.sorted((m1, m2) -> m1.getKey().compareTo(m2.getKey()))
				.collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
						(oldValue, newValue) -> oldValue, LinkedHashMap::new));
		
		model.addAttribute("mapDominioMcc", mapMccs);
		session.setAttribute("mapDominioMcc", mapMccs);
		
	}
	
	private Model carregarAtributosSession(HttpSession session, Model model) {

		model.addAttribute("listaFerramentas", session.getAttribute("listaFerramentas"));
		
		if (DashboardUtils.isNotNullOrEmpty(session.getAttribute("parametrizacaoMcc"))) {
			model.addAttribute("parametrizacaoMcc", session.getAttribute("parametrizacaoMcc"));
		}
		if (!DashboardUtils.isNotNullOrEmpty(session.getAttribute("consultar_mcc"))) {
			ConsultarMccDTO consultarMccDto = initialize();
			session.setAttribute("consultar_mcc", consultarMccDto);
		}

		model.addAttribute("consultar_mcc", session.getAttribute("consultar_mcc"));
		
		return model;
	}
	
	
	/**
	 * Método:Initialize
	 * 
	 * @return
	 */
	public ConsultarMccDTO initialize() {
		ConsultarMccDTO consultarMccDto = new ConsultarMccDTO();
		return consultarMccDto;
	}
	

	@SuppressWarnings("unchecked")
	private ParametrizacaoMccAuxiliarDTO gerarListaParametrizacaoMcc(ConsultarMccDTO consultar, HttpSession session, Model model) {
			
		List<ParametrizacaoMccDTO> retornoConsulta;
		
		retornoConsulta = parametrizacaoMCCService.filtrarParametrizacao(consultar.getCodigosMcc(), 
				consultar.getCodigosTipoPessoa(), consultar.getCodigosFerramenta());
		
		if (retornoConsulta == null){
			retornoConsulta = new ArrayList<ParametrizacaoMccDTO>();
		}
		
		retornoConsulta.sort((mcc1, mcc2) -> {
			if (mcc1.getId().getCodigoMcc().compareTo(mcc2.getId().getCodigoMcc()) != 0) {
				return mcc1.getId().getCodigoMcc().compareTo(mcc2.getId().getCodigoMcc());
			}
			if (mcc1.getId().getCodigoFerramenta().compareTo(mcc2.getId().getCodigoFerramenta()) != 0) {
				return mcc1.getId().getCodigoFerramenta().compareTo(mcc2.getId().getCodigoFerramenta());
			}
			if (mcc1.getId().getTipoPessoa().equals("F")) {
				return -1;
			}
			else {
				return 1;
			}
		});
		
		Map<Integer, String> mapMcc = (Map<Integer, String>) session.getAttribute("mapDominioMcc");
		Map<Integer, String> mapFerramentas = (Map<Integer, String>) session.getAttribute("mapFerramentas");
		
		List<Integer> filtroMcc = new ArrayList<Integer>();
		
		if ((consultar.getCodigosMcc() == null) ||
				(consultar.getCodigosMcc().size() == 0))
		{
			filtroMcc = new ArrayList<Integer>(mapMcc.keySet());
		}
		else
		{
			filtroMcc = consultar.getCodigosMcc();
		}
		
		List<Integer> filtroFerramentas = new ArrayList<Integer>();
		
		if (consultar.getCodigosFerramenta() != null) {
			if (consultar.getCodigosFerramenta().size() > 0)
			{
				filtroFerramentas.addAll(consultar.getCodigosFerramenta());
			}
			else
			{
				filtroFerramentas.addAll(mapFerramentas.keySet().stream()
						.collect(Collectors.toList()));
				
			}
		}
		else {
			filtroFerramentas.addAll(mapFerramentas.keySet().stream()
					.collect(Collectors.toList()));
		}
		
		List<String> mccsAtivosPF = new ArrayList<String>();
		List<String> mccsAtivosPJ = new ArrayList<String>();
		
		mccsAtivosPF = retornoConsulta.stream().filter(item -> (item.getId().getTipoPessoa().equals("F")))
				.map(x -> x.getId().obterChave()).collect(Collectors.toList());
		
		mccsAtivosPJ = retornoConsulta.stream().filter(item -> (item.getId().getTipoPessoa().equals("J")))
				.map(x -> x.getId().obterChave()).collect(Collectors.toList());
		
		List<ItemParametrizacaoMccDTO> listaItens = new ArrayList<ItemParametrizacaoMccDTO>();
		
		for(Integer idMcc : filtroMcc){
			for(Integer idFerramenta : filtroFerramentas) {
				 
				ItemParametrizacaoMccDTO item = new ItemParametrizacaoMccDTO();
				item.setIdMcc(idMcc);
				item.setDescricaoMcc(mapMcc.get(idMcc));
				item.setIdFerramenta(idFerramenta);
				item.setDescricaoFerramenta(mapFerramentas.get(idFerramenta));
				
				if (consultar.getFiltroAtivo() == 0) {
					listaItens.add(item);
				}

				if ((consultar.getFiltroAtivo() == 1) &&
					(mccsAtivosPF.contains(item.getIdItemParametrizacaoMccPF()) ||
				 	 mccsAtivosPJ.contains(item.getIdItemParametrizacaoMccPJ()))){
						
					listaItens.add(item);
				}
				
				if ((consultar.getFiltroAtivo() == 2) &&
						(!mccsAtivosPF.contains(item.getIdItemParametrizacaoMccPF()) &&
					  	 !mccsAtivosPJ.contains(item.getIdItemParametrizacaoMccPJ()))){
						
					listaItens.add(item);
				}
				
			}
		}
		
		ParametrizacaoMccAuxiliarDTO parametrizacaoBase = new ParametrizacaoMccAuxiliarDTO();
		
		parametrizacaoBase.setListaItensParametrizacaoMcc(listaItens);
		
		parametrizacaoBase.setItensMccsPFAtivosFerramenta(mccsAtivosPF);
		parametrizacaoBase.setItensMccsPFAtivosFerramentaOriginal(mccsAtivosPF);

		parametrizacaoBase.setItensMccsPJAtivosFerramenta(mccsAtivosPJ);
		parametrizacaoBase.setItensMccsPJAtivosFerramentaOriginal(mccsAtivosPJ);

		
		/* REMOVENDO ATRIBUTOS DA SESSÃO */
		DashboardUtils.removerAtributoToSession(session, "parametrizacaoMcc");
		
		session.setAttribute("consultar_mcc", consultar);
		model.addAttribute("consultar_mcc", consultar);
		
		session.setAttribute("parametrizacaoMcc", parametrizacaoBase);
		model.addAttribute("parametrizacaoMcc", parametrizacaoBase);
		
		return parametrizacaoBase;
	}
	
	/**
	 * Carrega ferramentas a serem exibidas no filtro de selação de ferramentas
	 * 
	 * @param model
	 * @param session
	 */
    private void carregarFerramentas(Model model, HttpSession session) {
    	
		List<FerramentaDTO> listaFerramentasDTO = ferramentaService.getFerramentasPorIntervaloDeCodigo(2, 89);
		
		Map<Integer, String> mapFerramentas = listaFerramentasDTO.stream()
				.collect(Collectors.toMap(FerramentaDTO::getCodigo, FerramentaDTO::getDescricao,
						(oldValue, newValue) -> oldValue, HashMap::new));
				
		session.setAttribute("mapFerramentas", mapFerramentas);
		model.addAttribute("mapFerramentas", mapFerramentas);
	}
	
}