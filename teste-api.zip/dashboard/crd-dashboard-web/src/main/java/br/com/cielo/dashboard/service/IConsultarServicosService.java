/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarServicosService {
	/**
	 * 
	 * @param proposta
	 * @return
	 */
	List<Object[]> getListarServicos(final Long proposta);
	
}
