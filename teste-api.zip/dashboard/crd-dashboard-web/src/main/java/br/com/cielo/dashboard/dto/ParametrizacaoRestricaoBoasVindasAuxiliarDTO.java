package br.com.cielo.dashboard.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ParametrizacaoRestricaoBoasVindasAuxiliarDTO implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<String> chavesRestricoesBoasVindasAtivas;
	private List<ItemGradeRestricaoBoasVindasDTO> restricoesBoasVindas;

	public List<String> getChavesRestricoesBoasVindasAtivas() {
		return chavesRestricoesBoasVindasAtivas;
	}

	public void setChavesRestricoesBoasVindasAtivas(List<String> restricoesBoasVindas) {
		this.chavesRestricoesBoasVindasAtivas = restricoesBoasVindas;
	}

	public List<ItemGradeRestricaoBoasVindasDTO> getRestricoesBoasVindas() {
		return restricoesBoasVindas;
	}

	public void setRestricoesBoasVindas(List<ItemGradeRestricaoBoasVindasDTO> restricoesBoasVindas) {
		this.restricoesBoasVindas = restricoesBoasVindas;
	}
}
