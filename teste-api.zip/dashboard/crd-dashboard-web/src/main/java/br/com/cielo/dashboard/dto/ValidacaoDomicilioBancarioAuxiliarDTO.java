package br.com.cielo.dashboard.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.com.cielo.dashboard.utils.DashboardUtils;

public class ValidacaoDomicilioBancarioAuxiliarDTO implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<ItemGradeValidacaoDomicilioBancarioDTO> listaValidacaoDomicilioBancario;
	List<String> validacaoDomicilioAtivos;
	List<String> validacaoParalelaTedAtivos;
	List<String> parametrizacoesAtivas;
	
	public List<String> getParametrizacoesAtivas() {
		return parametrizacoesAtivas;
	}
	public void setParametrizacoesAtivas(List<String> parametrizacoesAtivas) {
		this.parametrizacoesAtivas = parametrizacoesAtivas;
	}
	public List<ItemGradeValidacaoDomicilioBancarioDTO> getListaValidacaoDomicilioBancario() {
		return listaValidacaoDomicilioBancario;
	}
	public void setListaValidacaoDomicilioBancario(
			List<ItemGradeValidacaoDomicilioBancarioDTO> listaValidacaoDomicilioBancario) {
		this.listaValidacaoDomicilioBancario = listaValidacaoDomicilioBancario;
	}
	public List<String> getValidacaoDomicilioAtivos() {
		if (DashboardUtils.isListEmptyOrNull(this.validacaoDomicilioAtivos)) {
			return new ArrayList<String>(); 
		}
		return validacaoDomicilioAtivos;
	}
	public void setValidacaoDomicilioAtivos(List<String> validacaoDomicilioAtivos) {
		this.validacaoDomicilioAtivos = validacaoDomicilioAtivos;
	}
	public List<String> getValidacaoParalelaTedAtivos() {
		if (DashboardUtils.isListEmptyOrNull(this.validacaoParalelaTedAtivos)) {
			return new ArrayList<String>(); 
		}
		return validacaoParalelaTedAtivos;
	}
	public void setValidacaoParalelaTedAtivos(List<String> validacaoParalelaTedAtivos) {
		this.validacaoParalelaTedAtivos = validacaoParalelaTedAtivos;
	}
	
	

}
