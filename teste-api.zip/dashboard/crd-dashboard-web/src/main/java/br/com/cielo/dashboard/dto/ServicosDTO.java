/**
 * 
 */
package br.com.cielo.dashboard.dto;

import java.io.Serializable;

/**
 * @author dcarneiro
 *
 */
public class ServicosDTO implements Serializable{

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;

	private Integer codigo;
	private String descricao;
	private String indicadorhabilitacao;
	private String erroServico;
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the indicadorhabilitacao
	 */
	public String getIndicadorhabilitacao() {
		return indicadorhabilitacao;
	}
	/**
	 * @param indicadorhabilitacao the indicadorhabilitacao to set
	 */
	public void setIndicadorhabilitacao(String indicadorhabilitacao) {
		this.indicadorhabilitacao = indicadorhabilitacao;
	}
	/**
	 * @return the erroServico
	 */
	public String getErroServico() {
		return erroServico;
	}
	/**
	 * @param erroServico the erroServico to set
	 */
	public void setErroServico(String erroServico) {
		this.erroServico = erroServico;
	}
	
}
