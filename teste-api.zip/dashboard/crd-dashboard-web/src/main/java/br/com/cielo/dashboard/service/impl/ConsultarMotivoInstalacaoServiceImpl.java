/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.dto.DominioRetornoInstalacaoDTO;
import br.com.cielo.credenciamento.service.integracao.gtec.ConsultaDominioRetornoInstalacaoServiceRemote;
import br.com.cielo.dashboard.service.IConsultarMotivoInstalacaoService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarMotivoInstalacaoServiceImpl implements IConsultarMotivoInstalacaoService {
	
	@Resource(mappedName ="ConsultaDominioRetornoInstalacaoService#br.com.cielo.credenciamento.service.integracao.gtec.ConsultaDominioRetornoInstalacaoServiceRemote")
	private ConsultaDominioRetornoInstalacaoServiceRemote dominioService;

    @Override
    public DominioRetornoInstalacaoDTO getDominioById(Integer id) {
        return this.dominioService.obterDominioRetornoInstalacaoById(id);
    }
}
