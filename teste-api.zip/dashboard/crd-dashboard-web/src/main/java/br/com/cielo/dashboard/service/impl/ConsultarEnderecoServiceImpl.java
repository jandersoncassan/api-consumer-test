/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarEnderecoServiceRemote;
import br.com.cielo.dashboard.service.IConsultarEnderecoService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarEnderecoServiceImpl implements IConsultarEnderecoService {

	@Resource(mappedName ="ConsultarEnderecoService#br.com.cielo.credenciamento.service.dashboard.ConsultarEnderecoServiceRemote")
	private ConsultarEnderecoServiceRemote consultarEnderecoServiceRemote;

	/**
	 * @param proposta
	 * @return
	 */
	public List<Object[]> getListarEnderecoByProposta(Long proposta) {
		return consultarEnderecoServiceRemote.getConsultarEndereco(proposta);
	}

}
