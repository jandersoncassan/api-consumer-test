package br.com.cielo.dashboard.validator;

import java.util.List;
import java.util.stream.Collectors;

import javax.jms.Session;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import br.com.cielo.dashboard.dto.ItemGradeParametrizacaoBoasVindasDTO;
import br.com.cielo.dashboard.dto.ParametrizacaoBoasVindasAuxiliarDTO;
import br.com.cielo.dashboard.utils.DashboardUtils;

@Component("boasVindasValidator")
public class BoasVindasValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return ParametrizacaoBoasVindasAuxiliarDTO.class.equals(clazz);

	}

	@Override
	public void validate(Object target, Errors errors) {

		ParametrizacaoBoasVindasAuxiliarDTO formObject = (ParametrizacaoBoasVindasAuxiliarDTO) target;

		List<ItemGradeParametrizacaoBoasVindasDTO> itens = formObject.getParametrizacoesBoasVindas();

		if (formObject.getItensAtivos() != null) {
			for (int i = 0; i < itens.size(); i++) {
				if (formObject.getItensAtivos().contains(itens.get(i).getCodBanco())) {
					if (!DashboardUtils.isNotNullOrEmpty(itens.get(i).getCodSituacaoCadastral())) {
						errors.rejectValue("parametrizacoesBoasVindas[" + i + "].codSituacaoCadastral",
								"situacao.cadastral.nao.informada", new Object[] { itens.get(i).getNomeBanco() },
								"Selecione uma situação cadastral para o banco " + itens.get(i).getNomeBanco());
					}
				}
			}
		}
	}

}
