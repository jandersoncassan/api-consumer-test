/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarBancosService {
	/**
	 * Método: Obter lista bancos parametrizados
	 * @return
	 */
	List<Object[]> getListarBancosDomiciliosParametrizados();

}
