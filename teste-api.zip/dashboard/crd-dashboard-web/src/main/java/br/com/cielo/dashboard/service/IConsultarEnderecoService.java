/**
 * 
 */
package br.com.cielo.dashboard.service;

import java.util.List;

/**
 * @author dcarneiro
 *
 */
public interface IConsultarEnderecoService {
	/**
	 * Método: Obtem enderecos relacionados a proposta
	 * @param proposta
	 * @return
	 */
	List<Object[]> getListarEnderecoByProposta(final Long proposta);
}
