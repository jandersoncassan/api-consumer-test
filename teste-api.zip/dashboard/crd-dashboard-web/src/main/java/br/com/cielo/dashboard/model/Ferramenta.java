/**
 * 
 */
package br.com.cielo.dashboard.model;

/**
 * @author dcarneiro
 *
 */
public class Ferramenta {

	private Integer codigo;
	private String descricao;
	private Integer ferramenta;
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the ferramenta
	 */
	public Integer getFerramenta() {
		return ferramenta;
	}
	/**
	 * @param ferramenta the ferramenta to set
	 */
	public void setFerramenta(Integer ferramenta) {
		this.ferramenta = ferramenta;
	}
	
}
