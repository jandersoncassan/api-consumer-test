package br.com.cielo.dashboard.service;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import br.com.cielo.dashboard.model.ConsultaOfertas;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertasResponseType;
import br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaResponseType;

/**
 * Inteerface responsavel pela implementação dos serviços SOAP
 * 
 * @author @Cielo SA
 * @since Release 04 - Sprint 02
 * @version 1.0.0
 */
public interface IOsbService {

	/**
	 * Método responsavel por consultar as ofertas cadastradas no interact
	 *
	 * @param cpfCnpj
	 * @param codigoNivel
	 * @param qtdadeOfertas
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws RemoteException
	 */
	ConsultarOfertaResponseType consultarOfertasInteract(ConsultaOfertas infoOfertas)
			throws MalformedURLException, ServiceException, RemoteException;

	/**
	 * Método responsavel por consultas a lista de ofertas (dominios)
	 * cadastradas no Interact
	 * 
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws RemoteException
	 */
	ConsultarListaOfertasResponseType consultarListaOfertas()
			throws MalformedURLException, ServiceException, RemoteException;
}
