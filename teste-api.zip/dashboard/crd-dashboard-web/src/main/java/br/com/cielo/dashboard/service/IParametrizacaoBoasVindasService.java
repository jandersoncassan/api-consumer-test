package br.com.cielo.dashboard.service;

import java.util.List;

import br.com.cielo.credenciamento.dto.ParametrizacaoBoasVindasDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoBoasVindasManutencaoRequestDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoRestricaoBoasVindasDTO;
import br.com.cielo.credenciamento.dto.ParametrizacaoRestricaoBoasVindasManutencaoRequestDTO;

public interface IParametrizacaoBoasVindasService {
	List<ParametrizacaoBoasVindasDTO> obterParametrizacoesVigentes();
	void atualizarParametrizacoes(ParametrizacaoBoasVindasManutencaoRequestDTO parametrizacoes);
	
	List<ParametrizacaoRestricaoBoasVindasDTO> obterRestricoesVigentes(List<String> codigosBanco, List<Integer> codigosMcc, List<Integer> codigosSolucaoCaptura);
	void atualizarRestricoes(ParametrizacaoRestricaoBoasVindasManutencaoRequestDTO restricoes);
}
