package br.com.cielo.dashboard.service;

import java.util.List;

import org.springframework.stereotype.Component;

/**
 * 
 * @author dcarneiro
 *
 */
@Component
public interface IConsultarRejeitadosService {
	/**
	 * Método: Realiza consulta das propostas rejeitados atraves do bancos batch
	 * 
	 * @param codigoBanco
	 * @param periodoInicial
	 * @param periodoFinal
	 * @param isSomenteRejeitado
	 * @return List<Object>
	 */
	List<Object> getConsultaRejeitados(Integer codigoBanco, String periodoInicial, String periodoFinal,
			String isSomenteRejeitado);
}
