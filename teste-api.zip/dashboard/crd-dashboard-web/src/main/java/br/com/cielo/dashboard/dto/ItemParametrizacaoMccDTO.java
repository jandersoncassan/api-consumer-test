package br.com.cielo.dashboard.dto;

public class ItemParametrizacaoMccDTO {
	
	private Integer idMcc = 0;
	private String descricaoMcc;
	private Integer idFerramenta = 0;
	private String descricaoFerramenta;
	private String idItemParametrizacaoMccPJ;
	private String idItemParametrizacaoMccPF;
	
	public String getDescricaoMcc() {
		return descricaoMcc;
	}
	public void setDescricaoMcc(String descricaoMcc) {
		this.descricaoMcc = descricaoMcc;
	}
	public Integer getIdFerramenta() {
		return idFerramenta;
	}
	public void setIdFerramenta(Integer idFerramenta) {
		this.idFerramenta = idFerramenta;
		atualizarIdItemParametrizacaoMcc();
	}
	public String getDescricaoFerramenta() {
		return descricaoFerramenta;
	}
	public void setDescricaoFerramenta(String descricaoFerramenta) {
		this.descricaoFerramenta = descricaoFerramenta;
	}
	public Integer getIdMcc() {
		return idMcc;
	}
	public void setIdMcc(Integer idMcc) {
		this.idMcc = idMcc;
		atualizarIdItemParametrizacaoMcc();
	}
	
	public String getIdItemParametrizacaoMccPJ(){
		return idItemParametrizacaoMccPJ;
	}
		
	public String getIdItemParametrizacaoMccPF(){
		return idItemParametrizacaoMccPF;
	}

	private void atualizarIdItemParametrizacaoMcc(){
		this.idItemParametrizacaoMccPF = "F_" + idFerramenta.toString() + "_" + idMcc.toString();  
		this.idItemParametrizacaoMccPJ = "J_" + idFerramenta.toString() + "_" + idMcc.toString();
	}

}
