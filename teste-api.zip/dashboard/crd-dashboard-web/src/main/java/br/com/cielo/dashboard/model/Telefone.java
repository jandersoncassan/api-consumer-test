/**
 * 
 */
package br.com.cielo.dashboard.model;

import java.io.Serializable;

/**
 * @author dcarneiro
 *
 */
public class Telefone implements Serializable{

	/**
	 * Serial ID
	 */
	private static final long serialVersionUID = 1L;

	private Integer ddd;
	private String tipoTelefone;
	private String Telefone;
	/**
	 * @return the ddd
	 */
	public Integer getDdd() {
		return ddd;
	}
	/**
	 * @param ddd the ddd to set
	 */
	public void setDdd(Integer ddd) {
		this.ddd = ddd;
	}
	/**
	 * @return the telefone
	 */
	public String getTelefone() {
		return Telefone;
	}
	/**
	 * @param telefone the telefone to set
	 */
	public void setTelefone(String telefone) {
		Telefone = telefone;
	}
	/**
	 * @return the tipoTelefone
	 */
	public String getTipoTelefone() {
		return tipoTelefone;
	}
	/**
	 * @param tipoTelefone the tipoTelefone to set
	 */
	public void setTipoTelefone(String tipoTelefone) {
		this.tipoTelefone = tipoTelefone;
	}
}
