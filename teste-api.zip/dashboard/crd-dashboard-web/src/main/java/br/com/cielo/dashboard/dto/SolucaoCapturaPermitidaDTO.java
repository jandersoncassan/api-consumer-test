package br.com.cielo.dashboard.dto;

public class SolucaoCapturaPermitidaDTO {
	
	private Integer codigoFerramenta = 0;
	private String descricaoFerramenta;
	private Integer codigoSolucaoCaptura = 0;
	private String descricaoSolucaoCaptura;
	private Integer codigoTipoPlano = 0;
	private String descricaoTipoPlano;
	private String idSolucaoCapturaPermitidaPJ;
	private String idSolucaoCapturaPermitidaPF;
	private String idSolucaoCapturaPermitidaPJMEI;
	
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
		this.atualizarIdsRestricaoSolucaoCaptura();
	}
	public String getDescricaoFerramenta() {
		return descricaoFerramenta;
	}
	public void setDescricaoFerramenta(String descricaoFerramenta) {
		this.descricaoFerramenta = descricaoFerramenta;
	}
	public Integer getCodigoSolucaoCaptura() {
		return codigoSolucaoCaptura;
	}
	public void setCodigoSolucaoCaptura(Integer codigoSolucaoCaptura) {
		this.codigoSolucaoCaptura = codigoSolucaoCaptura;
		this.atualizarIdsRestricaoSolucaoCaptura();
	}
	public String getDescricaoSolucaoCaptura() {
		return descricaoSolucaoCaptura;
	}
	public void setDescricaoSolucaoCaptura(String descricaoSolucaoCaptura) {
		this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
	}
	public Integer getCodigoTipoPlano() {
		return codigoTipoPlano;
	}
	public void setCodigoTipoPlano(Integer codigoTipoPlano) {
		this.codigoTipoPlano = codigoTipoPlano;
		this.atualizarIdsRestricaoSolucaoCaptura();
	}
	public String getDescricaoTipoPlano() {
		return descricaoTipoPlano;
	}
	public void setDescricaoTipoPlano(String descricaoTipoPlano) {
		this.descricaoTipoPlano = descricaoTipoPlano;
	}
	public String getIdSolucaoCapturaPermitidaPJ() {
		return idSolucaoCapturaPermitidaPJ;
	}
	public String getIdSolucaoCapturaPermitidaPF() {
		return idSolucaoCapturaPermitidaPF;
	}
	
	public String getIdSolucaoCapturaPermitidaPJMEI() {
		return idSolucaoCapturaPermitidaPJMEI;
	}
	
	private void atualizarIdsRestricaoSolucaoCaptura(){
		
		this.idSolucaoCapturaPermitidaPJ = this.codigoFerramenta + "_" + 
											this.codigoSolucaoCaptura + "_" +
											this.codigoTipoPlano + "_N_J";

		this.idSolucaoCapturaPermitidaPF = this.codigoFerramenta + "_" + 
				this.codigoSolucaoCaptura + "_" +
				this.codigoTipoPlano + "_N_F";
		
		this.idSolucaoCapturaPermitidaPJMEI =  this.codigoFerramenta + "_" + 
				this.codigoSolucaoCaptura + "_" +
				this.codigoTipoPlano + "_S_J";

	}

}
