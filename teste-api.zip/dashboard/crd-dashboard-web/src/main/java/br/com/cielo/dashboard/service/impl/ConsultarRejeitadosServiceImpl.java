/**
 * 
 */
package br.com.cielo.dashboard.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import br.com.cielo.credenciamento.service.dashboard.ConsultarRejeitadosServiceRemote;
import br.com.cielo.dashboard.service.IConsultarRejeitadosService;

/**
 * @author dcarneiro
 *
 */
@Service
public class ConsultarRejeitadosServiceImpl implements IConsultarRejeitadosService {
	
	private static final Logger LOG = LogManager.getLogger(ConsultarRejeitadosServiceImpl.class);
	
	@Resource(mappedName="ConsultarRejeitadosService#br.com.cielo.credenciamento.service.dashboard.ConsultarRejeitadosServiceRemote")
	private ConsultarRejeitadosServiceRemote consultarRejeitadoServiceRemote;

	/**
	 * Método: realiza consulta das propostas rejeitadas
	 * @param codigoBanco
	 * @param periodoInicial
	 * @param periodoFinal
	 * @param isSomenteRejeitado
	 * @return Object
	 */
	public List<Object> getConsultaRejeitados(Integer codigoBanco, String periodoInicial, String periodoFinal,
			String isSomenteRejeitado) {
		LOG.info("SOLICITANDO CONSULTA DOS CLINTES REJEITADOS");
		return consultarRejeitadoServiceRemote.getConsultaRejeitados(codigoBanco, periodoInicial, periodoFinal,
				isSomenteRejeitado);		
	}
}
