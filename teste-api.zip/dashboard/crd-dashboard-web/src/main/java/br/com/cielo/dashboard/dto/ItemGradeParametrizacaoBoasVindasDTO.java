package br.com.cielo.dashboard.dto;

import java.io.Serializable;

public class ItemGradeParametrizacaoBoasVindasDTO implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String codBanco;
	private String nomeBanco;
	private boolean indicadorBoasVindas;
	private String codSituacaoCadastral;
	
	public String getCodBanco() {
		return codBanco;
	}
	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}
	public String getNomeBanco() {
		return nomeBanco;
	}
	public void setNomeBanco(String nomeBanco) {
		this.nomeBanco = nomeBanco;
	}
	public boolean isIndicadorBoasVindas() {
		return indicadorBoasVindas;
	}
	public void setIndicadorBoasVindas(boolean indicadorBoasVindas) {
		this.indicadorBoasVindas = indicadorBoasVindas;
	}
	public String getCodSituacaoCadastral() {
		return codSituacaoCadastral;
	}
	public void setCodSituacaoCadastral(String codSituacaoCadastral) {
		this.codSituacaoCadastral = codSituacaoCadastral;
	}
	
	
}
