package br.com.cielo.dashboard.dto;

import java.io.Serializable;

public class ItemGradeConfirmacaoBoasVindasDTO implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int codigoBanco;
	private String descricaoBanco;
	private String tipoManutencao;
	public int getCodigoBanco() {
		return codigoBanco;
	}
	public void setCodigoBanco(int codigoBanco) {
		this.codigoBanco = codigoBanco;
	}
	public String getDescricaoBanco() {
		return descricaoBanco;
	}
	public void setDescricaoBanco(String descricaoBanco) {
		this.descricaoBanco = descricaoBanco;
	}
	public String getTipoManutencao() {
		return tipoManutencao;
	}
	public void setTipoManutencao(String tipoManutencao) {
		this.tipoManutencao = tipoManutencao;
	}
}
