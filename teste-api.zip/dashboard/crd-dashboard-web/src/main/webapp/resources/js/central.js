$(function() {
	
	loaderShow();
	$('#info').hide();
	
	//TOKEN APP CRM
	getTokenAppCrm = function(){
		return "WXKYRCRMTOKEN1A2B3W!UTHA";
	}
	//TRATAMENTO PARA FERRAMENTAS SMART
	isSmart = function(codFerramenta){
		return (codFerramenta == 7? true: false);
	}
	//MONTA A QUERY PARAM PARA EXECUTAR A CHAMADA
	getQueryParam = function(){
		var $username = $('#username').text();		
		var $codigoFerramenta = $('#origem').text();
		var $queryParam = 'usuario='+$username+'&token='+getTokenAppCrm()+'&codigoFerramenta='+$codigoFerramenta;
		
		if(isSmart($codigoFerramenta)){
			var $perfilSmart = $('#perfilSmart').text();
			$queryParam = $queryParam+'&perfilSmart='+$perfilSmart;
		}		
		return $queryParam;
	}
	//CARREGA A APLICACAO CREDENCIAMENTO
	loadAppCentral = function(){
		var protocol = window.location.protocol;
		var hostname= window.location.hostname;
		var port = window.location.port;
		var context="crd-crm";			
		var url = protocol+'//'+hostname+(port ? ':'+'9050' :'')+'/'+context+'/?'+getQueryParam();
		$('#app-central').attr('src',url);
		loaderHide();
	}
	loadAppCentral();	
	//NOVO CLIENTE
	$("#novoCliente").click(function(){	
		loadAppCentral();
	})
	//TRATAMENTO DE EVENTOS
	window.addEventListener("message", receiveMessage, false);
    function receiveMessage(event){
    	window.scroll(0, 0);         
    }
 

})
