$(function() {

	loadCheckBox = function(element){
		$(element).bootstrapToggle({
			 on: 'Sim',
		     off: 'Não'
		}); 
	}

	//TABELA DATATABLE
	loadTable = function(element){
		$(element).DataTable(
						{
							aaSorting : [],// desabilita a ordenação default do primeiro campo da tabela. 
							bProcessing : true,
							retrieve: true,
							pagingType : "full_numbers",
							language : {
								processing : "Processando...",
								search : "Pesquisar:",
								lengthMenu : "Mostrar _MENU_ registros por p&aacute;gina",
								info : "Mostrar de _START_ at&eacute; _END_ de _TOTAL_ registros",
								infoEmpty : "Mostrando 0 at&eacute; 0 de 0 registros",
								infoFiltered : "(Filtrar de _MAX_ total registros)",
								infoPostFix : "",
								loadingRecords : "Carregando...",
								zeroRecords : "Nenhum registro encontrado para o filtro informado!",
								emptyTable : "Nenhum registro encontrado!",
								paginate : {
									first : "Primeiro&nbsp ",
									previous : "Anterior&nbsp  ",
									next : " &nbsp Pr&oacute;ximo &nbsp ",
									last : "&nbsp&Uacute;ltimo"
								},
								aria : {
									sortAscending : ": Ordenar colunas de forma ascendente",
									sortDescending : ": Ordenar colunas de forma descendente"
								},
								stateSave: true
							}
						});
	}

	//	// Apply the date range picker with custom settings to the button
	loadDatePicker = function(element){
		$(element).daterangepicker(
				{
					format : 'DD/MM/YYYY',
					//	    startDate: moment().subtract(15, 'days'),
					//	    endDate: moment(),
					dateLimit : {
						days : 15
					},
					linkedCalendars : false,
					autoUpdateInput : true,
					showCustomRangeLabel : false,
					changeMonth : true,
					changeYear : true,
					yearRange : '-100:+1',
					maxDate : '12/31/2099',
					//  timePicker: false,
					//  timePickerIncrement: 1,
					//timePicker12Hour: true,
					opens : 'left',
					drops : 'down',
					buttonClasses : [ 'btn', 'btn-sm' ],
					applyClass : 'btn-primary',
					cancelClass : 'btn-default',
					separator : ' to ',
					locale : {
						applyLabel : 'Selecionar',
						cancelLabel : 'Cancelar',
						fromLabel : 'From',
						toLabel : '&nbspTo&nbsp',
						customRangeLabel : 'Custom',
						daysOfWeek : [ 'Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex',
								'S&aacute;b' ],
						monthNames : [ "Janeiro", "Fevereiro", "Mar&ccedil;o",
								"Abril", "Maio", "Junho", "Julho", "Agosto",
								"Setembro", "Outubro", "Novembro", "Dezembro" ],
						firstDay : 1
					}
	
				});
	}

	//##UTILS
	// SOMENTE NUMEROS
	onlyNumber = function(e){		
		if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			return false;
		}
	};

	// TRATAR CARACTERES ESPECIAIS
	$(".ascii").on("change paste keyup onkeypress", function(event) {
		var value = foldToASCII(event.target.value).toUpperCase();
		value = value.replace(/[^0-9A-Za-z ]/g, '')
		event.target.value = value;
	});

	$("#dashboard_menu").click(function() {
		$("#dashboard_submenu").toggle("slow");
	});
	
	$("#consultas_menu").click(function() {
		$("#consultas_submenu").toggle("slow");
	});

	loaderShow = function() {
		$(".loader").show();
	}

	loaderHide = function() {
		$(".loader").hide();
	}
	
	showPageTop = function(){
		window.scroll(0, 0);   
		loaderHide();
	}

	//OBTEM O HOST
	hostContext = function() {
		var protocol = window.location.protocol;
		var host = window.location.host;
		return protocol + '//' + host + '/' + 'crd-web';
	}
	
	//CONTROLE SESSAO EXPIRADA
	sessionControl = function(statusCodeHttp){
		if(statusCodeHttp == 403)
			window.location.href = hostContext()+'/securityAccessDenied';
	}

	$("#parametros_menu").click(function() {
		$("#parametros_submenu").toggle("slow");
	});

	//OBTEM A PAGINA HTML DA APLICAÇÃO
	getPage = function(requestMapping) {
		$.get({
			url : hostContext() + '/' + requestMapping,
			dataType : "html",
			success : function(data) {
				$("#conteudo").html(data);
				showPageTop();				
			},
			error : function(xhr, status) {
				sessionControl(xhr.status);
				showPageTop();
			}
		});
	}

	//OBTEM A PAGINA HTML DA APLICAÇÃO
	postPage = function(requestMapping, dataForm) {
		$.post({
			url : hostContext() + '/' + requestMapping,
			dataType : "html",
			data : dataForm,	 
			success : function(data) {
				$("#conteudo").html(data);
				showPageTop();
			},
			error : function(xhr, status) {
				sessionControl(xhr.status);
				showPageTop();
			}
		});
	}

	//LOAD PAGE
	getPage('initWelcome');
	
	callServiceGet = function(uri, e){
		loaderShow();
		e.preventDefault();
		getPage(uri);
	}

	//HOME
	$("#home").click(function(e) {
		callServiceGet('initWelcome', e);
	});
	
	//QUADRO RESUMO - VISAO MENSAL
	$("#dashboard_page_mensal").click(function(e) {
		callServiceGet('initDashBoardMensal', e);
	});
	
	//QUADRO RESUMO - VISAO ANUAL
	$("#dashboard_page_anual").click(function(e) {
		callServiceGet('initDashBoardAnual', e);
	});
	
	//QUADRO RESUMO - VISAO ETAPASA
	$("#dashboard_page_etapas").click(function(e) {
		callServiceGet('initDashBoardEtapas', e);
	});

	// # CONSULTAS PROPOSTAS
	$("#page_propostas").click(function(e) {
		callServiceGet('initProposta', e);
	});

	//REMESSAS
	$("#page_remessas").click(function(e) {
		callServiceGet('initRemessas', e);
	});

	//ACESSO VIA MENU LATERAL APP CENTRAL
	$("#credenciar_central").click(function(e) {
		callServiceGet('credenciarCentral', e);
	})

	//ACESSO VIA MENU LATERAL APP FEIRAS
	$("#credenciar_feiras").click(function(e) {
		callServiceGet('credenciarFeiras', e);
	})

	//ACESSO VIA MENU LATERAL APP SMART
	$("#credenciar_smart").click(function(e) {
		callServiceGet('credenciarSmart', e);
	})

	//ACESSO VIA MENU LATERAL
	$("#simulador").click(function(e) {
		callServiceGet('credenciarSimulador', e);
	})

		//ACESSO VIA MENU LATERAL
	$("#ofertas").click(function(e) {
		callServiceGet('initPageOfertas', e);
	})	

	$("#dashboard_tv").click(function(e) {
		callServiceGet('initDashBoardTv', e);
	})
	
	$("#page_parametromcc").click(function(e){
		callServiceGet('initMcc', e);
	});
	
	$("#page_restricaosolucaocaptura").click(function(e){
		callServiceGet('initSolucoesCapturaPermitidas', e);
	});
	
	$("#page_parametroboasvindas").click(function(e){
		callServiceGet('initParametrizacaoBoasVindas', e);
	});
	
	$("#page_restricaoboasvindas").click(function(e){
		callServiceGet('initRestricaoBoasVindas', e);
	});
	
	$("#page_validacaodomiciliobancario").click(function(e){
		callServiceGet('initValidacaoDomicilioBancario', e);
	});	

	loaderHide();
	
})