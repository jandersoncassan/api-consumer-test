function maximizarTv() {
	$("#col_conteudo").hide();
	$("#col_menu").hide();
	$(".page-header").hide();
	$("#tv-conteudo-maximizado").append($("#ferramentaBancosSucesso"));
	$("#tv-conteudo-maximizado").append($("#ferramentaBancosRejeitados"));
	$("#tv-conteudo-maximizado").append($("#tempoAtivacaoD7_D60"));
	$("#ferramentaBancosSucesso").addClass("maximizado");
	$("#ferramentaBancosRejeitados").addClass("maximizado");
	$("#tempoAtivacaoD7_D60").addClass("maximizado");
	$("#tv-botao-minimizar").show();
	$("#tv-conteudo-maximizado").show();
	$('body').css('zoom','125%');
	refreshSizeConteudo();
}

function minimizarTv() {
	$("#tv-botao-minimizar").hide();
	$("#tv-conteudo-maximizado").hide();
	$("#tv-conteudo-sucesso").append($("#ferramentaBancosSucesso"));
	$("#tv-conteudo-rejeitados").append($("#ferramentaBancosRejeitados"));
	$("#tv-conteudo-ativacao").append($("#tempoAtivacaoD7_D60"));
	$("#ferramentaBancosSucesso").removeClass("maximizado");
	$("#ferramentaBancosRejeitados").removeClass("maximizado");
	$("#tempoAtivacaoD7_D60").removeClass("maximizado");
	$(".page-header").show();
	$("#col_menu").show();
	$("#col_conteudo").show();
	$('body').css('zoom','100%');
	refreshSizeConteudo();
}

function refreshSizeConteudo(){	
	if(!($("#tempoAtivacaoD7_D60").highcharts() === undefined)){
		$("#tempoAtivacaoD7_D60").highcharts().setSize($("#tempoAtivacaoD7_D60").width());
		$("#tempoAtivacaoD7_D60").highcharts().redraw();
	}
	
	if(!($("#ferramentaBancosRejeitados").highcharts() === undefined)){
		$("#ferramentaBancosRejeitados").highcharts().setSize($("#ferramentaBancosRejeitados").width());
		$("#ferramentaBancosRejeitados").highcharts().redraw();
	}

	if(!($("#ferramentaBancosSucesso").highcharts() === undefined)){
		$("#ferramentaBancosSucesso").highcharts().setSize($("#ferramentaBancosSucesso").width());
		$("#ferramentaBancosSucesso").highcharts().redraw();
	}
}

function reloadTv() {
	// Recarregar se o conteúdo da TV estiver maximizado
	if($("#tv-conteudo-maximizado:visible").length > 0) {

		if(!($("#ferramentaBancosSucesso").highcharts() === undefined)){
			//$("#ferramentaBancosSucesso").highcharts().destroy();
			processarFerramentaBancosSucesso();
		}

		if(!($("#ferramentaBancosRejeitados").highcharts() === undefined)){
			//$("#ferramentaBancosRejeitados").highcharts().destroy();
			processarFerramentaBancosReject();
		}

		if(!($("#tempoAtivacaoD7_D60").highcharts() === undefined)){
			//$("#tempoAtivacaoD7_D60").highcharts().destroy();
			processarAtivacaoD7_D60();
		}
	}
}

$(function() {
	if($("#tv-conteudo-maximizado").length == 0) {
		$("body").append($("<div id='tv-conteudo-maximizado' style='display:none'></div>"));	
		setInterval(reloadTv, 600000);
	}

	if($("#tv-botao-minimizar").length == 0) {
		$("body").append($("<div id='tv-botao-minimizar' style='display:none'><a href='javascript:;'><span class='glyphicon glyphicon-resize-small' style='font-size: 30px'></span></a></div>"));
		$("#tv-botao-maximizar a").click(function(){maximizarTv();});

	}

	$("#tv-botao-minimizar a").click(function(){minimizarTv();});
	minimizarTv();	
	$(window).resize(function(){refreshSizeConteudo()});
	
});