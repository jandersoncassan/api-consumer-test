$(function() {

	loaderShow();
	//TOKEN SIMULADOR
	getTokenSimulador = function(){
		return "XYabZSIMULADORWcdKHCRD";
	}
	
	loadAppSimulador = function(){
		var protocol = window.location.protocol;
		var host= window.location.host;
		var context="crd-simulador";			
		var url = protocol+'//'+host+'/'+context+'/'+getTokenSimulador();
		$('#app-simulador').attr('src',url);
		loaderHide();
	}
	loadAppSimulador();


});