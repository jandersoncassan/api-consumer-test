$(function() {
	
	$('.selectpicker').selectpicker('refresh');
	
	$('#cpfCnpj').keypress(function(e){		
		return onlyNumber(e);
	})
	
	$("#ofertasSubmit").click(function(e){
		loaderShow();
		e.preventDefault();		
		var $dataForm = $("form[name=formOfertas]").serialize();		
		postPage('consultarOfertas', $dataForm);
	})

})
