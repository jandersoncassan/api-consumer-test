$(function(){

	$(".toggle").each(function(){
		$(this).addClass("glyphicon glyphicon-plus");
	})
	
	$("a").click(function(){
		var name = $(this).attr('id');
		trocarToggleImagem("#"+name+"PlusMinus");
	});
	
	trocarToggleImagem = function(id){
		var plus = "glyphicon glyphicon-plus";
		var minus = "glyphicon glyphicon-minus";
		var campoPlusMinusEc = id;

		if($(campoPlusMinusEc).hasClass(plus)){
			$(campoPlusMinusEc).removeClass(plus);
			$(campoPlusMinusEc).addClass(minus);
		}else{
			$(campoPlusMinusEc).removeClass(minus);
			$(campoPlusMinusEc).addClass(plus);
		}
	}
	
	$("#propostaHistoryBack").click(function(e){
		loaderShow();
		e.preventDefault();		
		getPage('historyBackProposta');
	});

});
