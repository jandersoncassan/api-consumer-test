$(function() {

	$('.selectpicker').selectpicker('refresh');
	loadTable("table");

	var collapse = $("#collapseSpan").val();
	isLoadForm = function() {
		var coll = collapse;
		if (coll == "") {
			$("#collapseOne").addClass("collapse in");
			$("#toggleRestricaoBoasVindas").removeClass("glyphicon glyphicon-plus");
			$("#toggleRestricaoBoasVindas").addClass("glyphicon glyphicon-minus");
		} else {
			$("#collapseOne").addClass("panel-collapse collapse");
			$("#toggleRestricaoBoasVindas").removeClass("glyphicon glyphicon-minus");
			$("#toggleRestricaoBoasVindas").addClass("glyphicon glyphicon-plus");
		}
	}

	/* chamando function */
	isLoadForm();

	$("#restricaoBoasVindas").click(function() {
		var plus = "glyphicon glyphicon-plus";
		var minus = "glyphicon glyphicon-minus";
		var campo = "#toggleRestricaoBoasVindas";
		if ($(campo).hasClass(plus)) {
			$(campo).removeClass(plus);
			$(campo).addClass(minus);
		} else {
			$(campo).removeClass(minus);
			$(campo).addClass(plus);
		}
	});

	$(".parent").each(function(index) {
		var group = $(this).data("group");
		var parent = $(this);

		parent.change(function() { // "select all" change
			$(group).prop('checked', parent.prop("checked"));
		});
		$(group).change(function() {
			parent.prop('checked', false);
			if ($(group + ':checked').length == $(group).length) {
				parent.prop('checked', true);
			}
		});
	});

	$("#bto_pesq_restricao_boas_vindas").click(function(e) {
		loaderShow();
		e.preventDefault();
		var $dataForm = $("form[name=formFiltroRestricaoBoasVindas]").serialize();
		postPage('consultarRestricaoBoasVindas', $dataForm);
	});
	
	$("#atualizar").click(function(e) {
		loaderShow();
		e.preventDefault();
		var table = $('#table_restricao_boas_vindas').DataTable();
		var $dataForm = table.$('input,select,textarea').serialize();
		postPage('identificarAtualizacaoRestricaoBoasVindas', $dataForm);
	});	

	$("#modalConfirm").click(function(e) {
		loaderShow();
		e.preventDefault();
		var table = $('#table_restricao_boas_vindas').DataTable();
		var $dataForm = table.$('input,select,textarea').serialize();
		postPage('atualizarRestricaoBoasVindas', $dataForm);
		$('body').removeClass('modal-open');
		$('.modal-backdrop').remove();		
	});

	$('#confirm').on('hidden.bs.modal', function () {
		$('body').removeClass('modal-open');
		$('.modal-content').remove();
		$('.modal-backdrop').remove();		
	});

});