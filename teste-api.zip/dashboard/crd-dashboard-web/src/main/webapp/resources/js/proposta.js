$(function(){
	
	$('.selectpicker').selectpicker('refresh');
	loadTable("table");
	loadDatePicker(".datePicker");
	
	var collapse = $("#collapseSpan").val();
	isLoadForm = function(){
		var coll = collapse;
		if(coll==""){
			$("#collapseOne").addClass("collapse in");
			$("#toggleProposta").removeClass("glyphicon glyphicon-plus");
			$("#toggleProposta").addClass("glyphicon glyphicon-minus");
		}else{
			$("#collapseOne").addClass("panel-collapse collapse");
			$("#toggleProposta").removeClass("glyphicon glyphicon-minus");
			$("#toggleProposta").addClass("glyphicon glyphicon-plus");
		}
	}
	
	/*chamando function*/   
	isLoadForm();
	 
	$("#proposta").click(function(){
		var plus = "glyphicon glyphicon-plus";
		var minus = "glyphicon glyphicon-minus";
		var campo = "#toggleProposta";
		if($(campo).hasClass(plus)){
			$(campo).removeClass(plus);
			$(campo).addClass(minus);
		}else{
			$(campo).removeClass(minus);
			$(campo).addClass(plus);
		}
	});

	
	$(".cpf").keydown(function(){
	    var tamanho = $(".cpf").val().length;
	    if(tamanho < 14){
	    	 $('.cpf').mask('000.000.000-00', {reverse: true});
	    } else {
	    	 $('.cpf').mask('00.000.000/0000-00', {reverse: true});
	    }                   
	});
	
	$("#bto_pesq_proposta").click(function(e){
		loaderShow();
		e.preventDefault();		
		var $dataForm = $("form[name=formProposta]").serialize();		
		postPage('consultarListaProposta', $dataForm);
	})
	
		
	$(document).on('click', '.detalheProposta', function(e){
		loaderShow();
		e.preventDefault();		
		var numeroProposta = $(this).text();		
		getPage('redirecionarConsultaDetalheProposta/'+numeroProposta);
	});


}); 