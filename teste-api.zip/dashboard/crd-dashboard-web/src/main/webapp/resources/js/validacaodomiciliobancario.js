$(function() {

	$('.selectpicker').selectpicker('refresh');
	loadTable("table");

	var collapse = $("#collapseSpan").val();
	isLoadForm = function() {
		var coll = collapse;
		if (coll == "") {
			$("#collapseOne").addClass("collapse in");
			$("#toggleValidacaoDomicilioBancario").removeClass("glyphicon glyphicon-plus");
			$("#toggleValidacaoDomicilioBancario").addClass("glyphicon glyphicon-minus");
		} else {
			$("#collapseOne").addClass("panel-collapse collapse");
			$("#toggleValidacaoDomicilioBancario").removeClass("glyphicon glyphicon-minus");
			$("#toggleValidacaoDomicilioBancario").addClass("glyphicon glyphicon-plus");
		}
	}

	/* chamando function */
	isLoadForm();

	$("#cadastroValidacaoDomicilioBancario").click(function() {
		var plus = "glyphicon glyphicon-plus";
		var minus = "glyphicon glyphicon-minus";
		var campo = "#toggleValidacaoDomicilioBancario";
		if ($(campo).hasClass(plus)) {
			$(campo).removeClass(plus);
			$(campo).addClass(minus);
		} else {
			$(campo).removeClass(minus);
			$(campo).addClass(plus);
		}
	});

	$(".parent").each(function(index) {
		var group = $(this).data("group");
		var parent = $(this);

		parent.change(function() { // "select all" change
			$(group + ':enabled').prop('checked', parent.prop("checked"));
		});
		$(group).change(function() {
			parent.prop('checked', false);
			if ($(group + ':checked').length == $(group).length) {
				parent.prop('checked', true);
			}
		});
	});
	
	$("#bto_pesq_valid_domic_banc").click(function(e) {
		loaderShow();
		e.preventDefault();
		var $dataForm = $("form[name=formFiltroValidacaoDomiciliBancario]").serialize();
		postPage('consultarValidacaoDomicilioBancario', $dataForm);
	});

	
	$("#atualizar").click(function(e) {
		loaderShow();
		e.preventDefault();
		var table = $('#table_validacaoDomicilioBancario').DataTable();
		var $dataForm = table.$('input,select,textarea').serialize();
		postPage('identificarAtualizacoesDomicilioBancario', $dataForm);
		
	});
	
	$("#modalCancel").click(function(e) {
		$('body').removeClass('modal-open');
		$('.modal-backdrop').remove();		
	});
	
	$("#modalConfirm").click(function(e) {
		loaderShow();
		e.preventDefault();
		var table = $('#table_validacaoDomicilioBancario').DataTable();
		var $dataForm = table.$('input,select,textarea').serialize();
		postPage('atualizarValidacaoDomicilioBancario', $dataForm);
		$('body').removeClass('modal-open');
		$('.modal-backdrop').remove();		
	});
	

});

$.extend( $.fn.dataTable.defaults, {
	"columnDefs": [{
		"targets": 'no-sort',
		"orderable": false,
	}]
} );


$(function() {

	associarHabilitarControles = function(){
		$('.indicador').each(function(index) {
			
			var parent = $(this);
			var group = $('#table_validacaoDomicilioBancario span[data-id-item=' + parent.data('id-group') + ']');
		
			parent.change(function() {
					
					var isEnabled = parent.prop('checked');
					
					if (isEnabled) {
						$(group).find('button').removeClass('disabled');
						$(group).find('select').removeAttr('disabled');
						$('#table_validacaoDomicilioBancario input[data-id-item=' + parent.data('id-group') + ']').removeAttr('disabled');
					}
					else {
						$(group).find('button').addClass('disabled');
						$(group).find('select').attr('disabled', true);
						$('#table_validacaoDomicilioBancario input[data-id-item=' + parent.data('id-group') + ']').attr('disabled', true);
					}
			});
		});	}
	
	$('#table_validacaoDomicilioBancario').DataTable()
	.on('draw', function(){
		associarHabilitarControles();
	});
	
	$(document).ready(function(){
		
		associarHabilitarControles();
	});
});
