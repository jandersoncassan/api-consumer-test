$(function() {
	
	var highchartsOptions = Highcharts.setOptions({
	      lang: {
	            loading: 'Aguarde...',
	            months: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
	            weekdays: ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'],
	            shortMonths: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
	            exportButtonTitle: "Exportar",
	            printChart: "Imprimir",
	            rangeSelectorFrom: "De",
	            rangeSelectorTo: "Até",
	            rangeSelectorZoom: "Período",
	            downloadPNG: 'Download no formato PNG',
	            downloadJPEG: 'Download no formato JPEG',
	            downloadPDF: 'Download no formato PDF',
	            downloadSVG: 'Download no formato SVG',
	            noData: 'Não há dados a serem exibidos',
	            contextButtonTitle: 'Opções de exportação e impressão',
	            viewData: 'Visualizar dados em tabela',
	            decimalPoint: ','
	            }
	      }
	  );
	
	$("#dataReferenciaPesquisa").selectpicker('refresh');
	$("#ferramentaPesquisa").selectpicker('refresh');
	
    //PESQUISA MENSAL
	$('#bto_pesq_dash_mensal').click(function (e){	  
	    loaderShow();
	    e.preventDefault();
	    
	    $(".panel").css({ opacity: 0.4 });	    
	    var $dataPesquisa = $('#dataReferenciaPesquisa').val().replace('/','');
		getPage('realizarPesquisaDashPorMesReferencia/'+$dataPesquisa);
	});
	
	 //PESQUISA ANUAL
	$('#bto_pesq_dash_anual').click(function (e){	  
	    loaderShow();
	    e.preventDefault();
	    
	    $(".panel").css({ opacity: 0.4 });	    
	    var $dataPesquisa = $('#dataReferenciaPesquisa').val();
	    var $ferramentaPesquisa = $("#ferramentaPesquisa").val() == null ? [] : $("#ferramentaPesquisa").val();
	    
		getPage('realizarPesquisaDashPorAnoReferencia/'+$dataPesquisa+'?ferramentaPesquisa='+$ferramentaPesquisa);
	});
	
	//PESQUISA MÊS ETAPAS
	$('#bto_pesq_dash_etapas').click(function (e){	  
	    loaderShow();
	    e.preventDefault();
	    
	    $(".panel").css({ opacity: 0.4 });	    
	    var $dataPesquisa = $('#dataReferenciaPesquisa').val().replace('/','');
	    var $ferramentaPesquisa = $("#ferramentaPesquisa").val() == null ? [] : $("#ferramentaPesquisa").val();
	    
		getPage('realizarPesquisaDashPorEtapas/'+$dataPesquisa+'?ferramentaPesquisa='+$ferramentaPesquisa);
	});

	setTimeout(function(){
		$('.highcharts-credits').hide();
	 },5000);
});