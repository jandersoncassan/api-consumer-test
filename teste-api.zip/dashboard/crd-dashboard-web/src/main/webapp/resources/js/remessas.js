$(function(){
	
	$('.selectpicker').selectpicker('refresh');
	
	var collapse = $("#collapseSpan").val();
	
	loadTable("table");
	loadDatePicker(".datePicker");

	
	isLoadForm = function(){
		var coll = collapse;
		if(coll==""){
			$("#collapseOne").addClass("collapse in");
			$("#toggleRemessa").removeClass("glyphicon glyphicon-plus");
			$("#toggleRemessa").addClass("glyphicon glyphicon-minus");
		}else{
			$("#collapseOne").addClass("panel-collapse collapse");
			$("#toggleRemessa").removeClass("glyphicon glyphicon-minus");
			$("#toggleRemessa").addClass("glyphicon glyphicon-plus");
		}
	}

	/*chamando function*/
	isLoadForm();
	
	$("#remessa").click(function(){
		var plus = "glyphicon glyphicon-plus";
		var minus = "glyphicon glyphicon-minus";
		var campo = "#toggleRemessa";
		if($(campo).hasClass(plus)){
			$(campo).removeClass(plus);
			$(campo).addClass(minus);
		}else{
			$(campo).removeClass(minus);
			$(campo).addClass(plus);
		}
	});

	$("#bto_pesq_remessas").click(function(e){
		loaderShow();
		e.preventDefault();		
		var $dataForm = $("form[name=formRemessas]").serialize();		
		postPage('consultarListaRemessas', $dataForm);
	})

});