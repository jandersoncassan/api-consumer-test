$(function() {

	 loadCheckBox('.filterCheckbox');	 
	
	 var $isShowModal = $('#showModal').text();
	 if($isShowModal)
		 $('#btoModal').click();
	 
	$('.selectpicker').selectpicker('refresh');
	loadTable("table");

	var collapse = $("#collapseSpan").val();
	isLoadForm = function() {
		var coll = collapse;
		if (coll == undefined || coll == "" ) {
			$("#collapseOne").addClass("collapse in");
			$("#toggleSolucoesCapturaPermitidas").removeClass("glyphicon glyphicon-plus");
			$("#toggleSolucoesCapturaPermitidas").addClass("glyphicon glyphicon-minus");
		} else {
			$("#collapseOne").addClass("panel-collapse collapse");
			$("#toggleSolucoesCapturaPermitidas").removeClass("glyphicon glyphicon-minus");
			$("#toggleSolucoesCapturaPermitidas").addClass("glyphicon glyphicon-plus");
		}
	}
	/* chamando function */
	isLoadForm();

	$("#cadastroSolucoesCapturaPermitidas").click(function() {
		var plus = "glyphicon glyphicon-plus";
		var minus = "glyphicon glyphicon-minus";
		var campo = "#toggleSolucoesCapturaPermitidas";
		if ($(campo).hasClass(plus)) {
			$(campo).removeClass(plus);
			$(campo).addClass(minus);
		} else {
			$(campo).removeClass(minus);
			$(campo).addClass(plus);
		}
	});

	$(".parent").each(function(index) {
		var group = $(this).data("group");
		var parent = $(this);

		parent.change(function() { // "select all" change
			$(group).prop('checked', parent.prop("checked"));
		});
		$(group).change(function() {
			parent.prop('checked', false);
			if ($(group + ':checked').length == $(group).length) {
				parent.prop('checked', true);
			}
		});
	});
	
	$("#btoPesquisarSolucaoCaptura").click(function(e) {
		loaderShow();
		e.preventDefault();
		var $dataForm = $("form[name=formFiltroSolucaoCaptura]").serialize();
		postPage('consultarSolucoesCapturaPermitidas', $dataForm);
	});
	
	$("#atualizar").click(function(e) {
		loaderShow();
		e.preventDefault();
		var table = $('#tableSolucoesCaptura').DataTable();
		var $dataForm = table.$('input,select,textarea').serialize();
		postPage('obterListaRegistrosAlterados', $dataForm);
	});	
	
	$("#modalConfirm").click(function(e) {
		loaderShow();
		e.preventDefault();
		getPage('efetivarManutencaoSolucao');
	});

});