$(function() {
	
	$('[data-toggle=popover]').popover({
		
	   content: $('#divUserRoles').html(),
	   html: true

	});
	
})


