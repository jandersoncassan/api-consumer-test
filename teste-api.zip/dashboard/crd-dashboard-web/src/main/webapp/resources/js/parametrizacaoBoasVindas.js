$(function() {

	$('.selectpicker').selectpicker('refresh');
	loadTable("table");

});

$(function() {

	associarHabilitarControles = function() {
		$('.indicador').each(
				function(index) {

					var parent = $(this);
					var group = $('#table_boas_vindas span[data-id-banco='
							+ parent.data('group') + ']');

					parent.change(function() {
						if (parent.is(":checked")) {
							$(group).find('button').removeClass('disabled');
							$(group).find('select').attr('disabled', false);
						} else {
							$(group).find('button').addClass('disabled');
							$(group).find('select').attr('disabled', true);
						}
					});
				});
	}

	$('#table_boas_vindas').DataTable().on('draw', function() {
		associarHabilitarControles();
	});

	associarHabilitarControles();

});

$("#atualizar").click(function(e) {
	loaderShow();
	e.preventDefault();
	var table = $('#table_boas_vindas').DataTable();
	var $dataForm = table.$('input,select,textarea').serialize();
	postPage('identificarAtualizacoesBoasVindas', $dataForm);

});

$("#modalConfirm").click(function(e) {
	loaderShow();
	e.preventDefault();
	var table = $('#table_boas_vindas').DataTable();
	var $dataForm = table.$('input,select,textarea').serialize();
	postPage('atualizarBoasVindas', $dataForm);
	$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();
});

$("#modalCancel").click(function(e) {
	$('body').removeClass('modal-open');
	$('.modal-content').remove();
	$('.modal-backdrop').remove();		
});


