$(function() {

	$('.selectpicker').selectpicker('refresh');
	loadTable("table");

	var collapse = $("#collapseSpan").val();
	isLoadForm = function() {
		var coll = collapse;
		if (coll == "") {
			$("#collapseOne").addClass("collapse in");
			$("#toggleCadastroMcc").removeClass("glyphicon glyphicon-plus");
			$("#toggleCadastroMcc").addClass("glyphicon glyphicon-minus");
		} else {
			$("#collapseOne").addClass("panel-collapse collapse");
			$("#toggleCadastroMcc").removeClass("glyphicon glyphicon-minus");
			$("#toggleCadastroMcc").addClass("glyphicon glyphicon-plus");
		}
	}

	/* chamando function */
	isLoadForm();

	$("#cadastroMcc").click(function() {
		var plus = "glyphicon glyphicon-plus";
		var minus = "glyphicon glyphicon-minus";
		var campo = "#toggleCadastroMcc";
		if ($(campo).hasClass(plus)) {
			$(campo).removeClass(plus);
			$(campo).addClass(minus);
		} else {
			$(campo).removeClass(minus);
			$(campo).addClass(plus);
		}
	});

	$(".parent").each(function(index) {
		var group = $(this).data("group");
		var parent = $(this);

		parent.change(function() { // "select all" change
			$(group).prop('checked', parent.prop("checked"));
		});
		$(group).change(function() {
			parent.prop('checked', false);
			if ($(group + ':checked').length == $(group).length) {
				parent.prop('checked', true);
			}
		});
	});


	var tableWrapper = $("#table_mcc_wrapper").val();

	removeSort = function() {
		var tbl = tableWrapper;
		if (tbl != "") {
			$("#checkAllPJ").removeClass("sorting");
			$("#checkAllPF").removeClass("sorting");
		}
	}

	removeSort();

});

$("#bto_pesq_param_mcc").click(function(e) {
	loaderShow();
	e.preventDefault();
	var $dataForm = $("form[name=formFiltroMcc]").serialize();
	postPage('consultarMcc', $dataForm);
});

$("#atualizar").click(function(e) {
	loaderShow();
	e.preventDefault();
	var table = $('#table_mcc').DataTable();
	var $dataForm = table.$('input,select,textarea').serialize();
	postPage('identificarAtualizacoesMcc', $dataForm);
});	

$("#modalConfirm").click(function(e) {
	loaderShow();
	e.preventDefault();
	var table = $('#table_mcc').DataTable();
	var $dataForm = table.$('input,select,textarea').serialize();
	postPage('atualizarMcc', $dataForm);
	$('body').removeClass('modal-open');
	$('.modal-backdrop').remove();		
});

$('#confirm').on('hidden.bs.modal', function () {
	$('body').removeClass('modal-open');
	$('.modal-content').remove();
	$('.modal-backdrop').remove();		
});
