package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas;

public class ConsultarListaOfertasProxy implements br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertas_PortType {
  private String _endpoint = null;
  private br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertas_PortType consultarListaOfertas_PortType = null;
  
  public ConsultarListaOfertasProxy() {
    _initConsultarListaOfertasProxy();
  }
  
  public ConsultarListaOfertasProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarListaOfertasProxy();
  }
  
  private void _initConsultarListaOfertasProxy() {
    try {
      consultarListaOfertas_PortType = (new br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertas_ServiceLocator()).getConsultarListaOfertasSOAP();
      if (consultarListaOfertas_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarListaOfertas_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarListaOfertas_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarListaOfertas_PortType != null)
      ((javax.xml.rpc.Stub)consultarListaOfertas_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertas_PortType getConsultarListaOfertas_PortType() {
    if (consultarListaOfertas_PortType == null)
      _initConsultarListaOfertasProxy();
    return consultarListaOfertas_PortType;
  }
  
  public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertasResponseType consultarListaOfertas(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.ConsultarListaOfertasRequestType parameters) throws java.rmi.RemoteException{
    if (consultarListaOfertas_PortType == null)
      _initConsultarListaOfertasProxy();
    return consultarListaOfertas_PortType.consultarListaOfertas(header, parameters);
  }
  
  
}