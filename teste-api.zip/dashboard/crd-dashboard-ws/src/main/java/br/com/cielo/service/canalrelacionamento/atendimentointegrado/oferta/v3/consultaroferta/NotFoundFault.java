/**
 * NotFoundFault.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta;

public class NotFoundFault  implements java.io.Serializable {
    private java.lang.String codigoSessao;

    private java.lang.String codigoStatus;

    private br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.FaultDetail detalhe;

    public NotFoundFault() {
    }

    public NotFoundFault(
           java.lang.String codigoSessao,
           java.lang.String codigoStatus,
           br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.FaultDetail detalhe) {
           this.codigoSessao = codigoSessao;
           this.codigoStatus = codigoStatus;
           this.detalhe = detalhe;
    }


    /**
     * Gets the codigoSessao value for this NotFoundFault.
     * 
     * @return codigoSessao
     */
    public java.lang.String getCodigoSessao() {
        return codigoSessao;
    }


    /**
     * Sets the codigoSessao value for this NotFoundFault.
     * 
     * @param codigoSessao
     */
    public void setCodigoSessao(java.lang.String codigoSessao) {
        this.codigoSessao = codigoSessao;
    }


    /**
     * Gets the codigoStatus value for this NotFoundFault.
     * 
     * @return codigoStatus
     */
    public java.lang.String getCodigoStatus() {
        return codigoStatus;
    }


    /**
     * Sets the codigoStatus value for this NotFoundFault.
     * 
     * @param codigoStatus
     */
    public void setCodigoStatus(java.lang.String codigoStatus) {
        this.codigoStatus = codigoStatus;
    }


    /**
     * Gets the detalhe value for this NotFoundFault.
     * 
     * @return detalhe
     */
    public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.FaultDetail getDetalhe() {
        return detalhe;
    }


    /**
     * Sets the detalhe value for this NotFoundFault.
     * 
     * @param detalhe
     */
    public void setDetalhe(br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.FaultDetail detalhe) {
        this.detalhe = detalhe;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NotFoundFault)) return false;
        NotFoundFault other = (NotFoundFault) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoSessao==null && other.getCodigoSessao()==null) || 
             (this.codigoSessao!=null &&
              this.codigoSessao.equals(other.getCodigoSessao()))) &&
            ((this.codigoStatus==null && other.getCodigoStatus()==null) || 
             (this.codigoStatus!=null &&
              this.codigoStatus.equals(other.getCodigoStatus()))) &&
            ((this.detalhe==null && other.getDetalhe()==null) || 
             (this.detalhe!=null &&
              this.detalhe.equals(other.getDetalhe())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoSessao() != null) {
            _hashCode += getCodigoSessao().hashCode();
        }
        if (getCodigoStatus() != null) {
            _hashCode += getCodigoStatus().hashCode();
        }
        if (getDetalhe() != null) {
            _hashCode += getDetalhe().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NotFoundFault.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "NotFoundFault"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSessao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoSessao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detalhe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "detalhe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "FaultDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
