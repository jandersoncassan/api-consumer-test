/**
 * ConsultarListaOfertasResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas;

public class ConsultarListaOfertasResponseType  implements java.io.Serializable {
    private br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.OfertaType[] ofertas;

    public ConsultarListaOfertasResponseType() {
    }

    public ConsultarListaOfertasResponseType(
           br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.OfertaType[] ofertas) {
           this.ofertas = ofertas;
    }


    /**
     * Gets the ofertas value for this ConsultarListaOfertasResponseType.
     * 
     * @return ofertas
     */
    public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.OfertaType[] getOfertas() {
        return ofertas;
    }


    /**
     * Sets the ofertas value for this ConsultarListaOfertasResponseType.
     * 
     * @param ofertas
     */
    public void setOfertas(br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultarlistaofertas.OfertaType[] ofertas) {
        this.ofertas = ofertas;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarListaOfertasResponseType)) return false;
        ConsultarListaOfertasResponseType other = (ConsultarListaOfertasResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ofertas==null && other.getOfertas()==null) || 
             (this.ofertas!=null &&
              java.util.Arrays.equals(this.ofertas, other.getOfertas())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getOfertas() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOfertas());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOfertas(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarListaOfertasResponseType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultarlistaofertas", "ConsultarListaOfertasResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ofertas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultarlistaofertas", "ofertas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultarlistaofertas", "OfertaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultarlistaofertas", "ofertas"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
