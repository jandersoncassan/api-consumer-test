package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta;

public class ConsultarOfertaProxy implements br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOferta {
  private String _endpoint = null;
  private br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOferta consultarOferta = null;
  
  public ConsultarOfertaProxy() {
    _initConsultarOfertaProxy();
  }
  
  public ConsultarOfertaProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarOfertaProxy();
  }
  
  private void _initConsultarOfertaProxy() {
    try {
      consultarOferta = (new br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaSOAPQSServiceLocator()).getConsultarOfertaSOAPQSPort();
      if (consultarOferta != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarOferta)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarOferta)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarOferta != null)
      ((javax.xml.rpc.Stub)consultarOferta)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOferta getConsultarOferta() {
    if (consultarOferta == null)
      _initConsultarOfertaProxy();
    return consultarOferta;
  }
  
  public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaResponseType consultarOferta(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaRequestType parameters) throws java.rmi.RemoteException{
    if (consultarOferta == null)
      _initConsultarOfertaProxy();
    return consultarOferta.consultarOferta(header, parameters);
  }
  
  
}