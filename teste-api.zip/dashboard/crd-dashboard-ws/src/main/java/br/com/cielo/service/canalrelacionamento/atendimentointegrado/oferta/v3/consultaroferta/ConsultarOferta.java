/**
 * ConsultarOferta.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta;

public interface ConsultarOferta extends java.rmi.Remote {
    public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaResponseType consultarOferta(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.ConsultarOfertaRequestType parameters) throws java.rmi.RemoteException;
}
