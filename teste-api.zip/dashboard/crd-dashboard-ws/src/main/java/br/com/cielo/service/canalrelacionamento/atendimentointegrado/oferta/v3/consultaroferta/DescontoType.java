/**
 * DescontoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta;

public class DescontoType  implements java.io.Serializable {
    /* Colecao de descontos valor
     * 						ALUGUEL,
     * 						TAXA
     * 						MDR,
     * 						ARV,
     * 						POSTECIPADO */
    private java.lang.String tipoDesconto;

    private java.math.BigDecimal valorOriginal;

    private java.math.BigDecimal valorComDesconto;

    private java.math.BigDecimal valorDesconto;

    private java.math.BigDecimal percentualDesconto;

    private java.math.BigDecimal quantidadeMeses;

    private java.math.BigDecimal valorMetaFaturamento;

    public DescontoType() {
    }

    public DescontoType(
           java.lang.String tipoDesconto,
           java.math.BigDecimal valorOriginal,
           java.math.BigDecimal valorComDesconto,
           java.math.BigDecimal valorDesconto,
           java.math.BigDecimal percentualDesconto,
           java.math.BigDecimal quantidadeMeses,
           java.math.BigDecimal valorMetaFaturamento) {
           this.tipoDesconto = tipoDesconto;
           this.valorOriginal = valorOriginal;
           this.valorComDesconto = valorComDesconto;
           this.valorDesconto = valorDesconto;
           this.percentualDesconto = percentualDesconto;
           this.quantidadeMeses = quantidadeMeses;
           this.valorMetaFaturamento = valorMetaFaturamento;
    }


    /**
     * Gets the tipoDesconto value for this DescontoType.
     * 
     * @return tipoDesconto   * Colecao de descontos valor
     * 						ALUGUEL,
     * 						TAXA
     * 						MDR,
     * 						ARV,
     * 						POSTECIPADO
     */
    public java.lang.String getTipoDesconto() {
        return tipoDesconto;
    }


    /**
     * Sets the tipoDesconto value for this DescontoType.
     * 
     * @param tipoDesconto   * Colecao de descontos valor
     * 						ALUGUEL,
     * 						TAXA
     * 						MDR,
     * 						ARV,
     * 						POSTECIPADO
     */
    public void setTipoDesconto(java.lang.String tipoDesconto) {
        this.tipoDesconto = tipoDesconto;
    }


    /**
     * Gets the valorOriginal value for this DescontoType.
     * 
     * @return valorOriginal
     */
    public java.math.BigDecimal getValorOriginal() {
        return valorOriginal;
    }


    /**
     * Sets the valorOriginal value for this DescontoType.
     * 
     * @param valorOriginal
     */
    public void setValorOriginal(java.math.BigDecimal valorOriginal) {
        this.valorOriginal = valorOriginal;
    }


    /**
     * Gets the valorComDesconto value for this DescontoType.
     * 
     * @return valorComDesconto
     */
    public java.math.BigDecimal getValorComDesconto() {
        return valorComDesconto;
    }


    /**
     * Sets the valorComDesconto value for this DescontoType.
     * 
     * @param valorComDesconto
     */
    public void setValorComDesconto(java.math.BigDecimal valorComDesconto) {
        this.valorComDesconto = valorComDesconto;
    }


    /**
     * Gets the valorDesconto value for this DescontoType.
     * 
     * @return valorDesconto
     */
    public java.math.BigDecimal getValorDesconto() {
        return valorDesconto;
    }


    /**
     * Sets the valorDesconto value for this DescontoType.
     * 
     * @param valorDesconto
     */
    public void setValorDesconto(java.math.BigDecimal valorDesconto) {
        this.valorDesconto = valorDesconto;
    }


    /**
     * Gets the percentualDesconto value for this DescontoType.
     * 
     * @return percentualDesconto
     */
    public java.math.BigDecimal getPercentualDesconto() {
        return percentualDesconto;
    }


    /**
     * Sets the percentualDesconto value for this DescontoType.
     * 
     * @param percentualDesconto
     */
    public void setPercentualDesconto(java.math.BigDecimal percentualDesconto) {
        this.percentualDesconto = percentualDesconto;
    }


    /**
     * Gets the quantidadeMeses value for this DescontoType.
     * 
     * @return quantidadeMeses
     */
    public java.math.BigDecimal getQuantidadeMeses() {
        return quantidadeMeses;
    }


    /**
     * Sets the quantidadeMeses value for this DescontoType.
     * 
     * @param quantidadeMeses
     */
    public void setQuantidadeMeses(java.math.BigDecimal quantidadeMeses) {
        this.quantidadeMeses = quantidadeMeses;
    }


    /**
     * Gets the valorMetaFaturamento value for this DescontoType.
     * 
     * @return valorMetaFaturamento
     */
    public java.math.BigDecimal getValorMetaFaturamento() {
        return valorMetaFaturamento;
    }


    /**
     * Sets the valorMetaFaturamento value for this DescontoType.
     * 
     * @param valorMetaFaturamento
     */
    public void setValorMetaFaturamento(java.math.BigDecimal valorMetaFaturamento) {
        this.valorMetaFaturamento = valorMetaFaturamento;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DescontoType)) return false;
        DescontoType other = (DescontoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.tipoDesconto==null && other.getTipoDesconto()==null) || 
             (this.tipoDesconto!=null &&
              this.tipoDesconto.equals(other.getTipoDesconto()))) &&
            ((this.valorOriginal==null && other.getValorOriginal()==null) || 
             (this.valorOriginal!=null &&
              this.valorOriginal.equals(other.getValorOriginal()))) &&
            ((this.valorComDesconto==null && other.getValorComDesconto()==null) || 
             (this.valorComDesconto!=null &&
              this.valorComDesconto.equals(other.getValorComDesconto()))) &&
            ((this.valorDesconto==null && other.getValorDesconto()==null) || 
             (this.valorDesconto!=null &&
              this.valorDesconto.equals(other.getValorDesconto()))) &&
            ((this.percentualDesconto==null && other.getPercentualDesconto()==null) || 
             (this.percentualDesconto!=null &&
              this.percentualDesconto.equals(other.getPercentualDesconto()))) &&
            ((this.quantidadeMeses==null && other.getQuantidadeMeses()==null) || 
             (this.quantidadeMeses!=null &&
              this.quantidadeMeses.equals(other.getQuantidadeMeses()))) &&
            ((this.valorMetaFaturamento==null && other.getValorMetaFaturamento()==null) || 
             (this.valorMetaFaturamento!=null &&
              this.valorMetaFaturamento.equals(other.getValorMetaFaturamento())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTipoDesconto() != null) {
            _hashCode += getTipoDesconto().hashCode();
        }
        if (getValorOriginal() != null) {
            _hashCode += getValorOriginal().hashCode();
        }
        if (getValorComDesconto() != null) {
            _hashCode += getValorComDesconto().hashCode();
        }
        if (getValorDesconto() != null) {
            _hashCode += getValorDesconto().hashCode();
        }
        if (getPercentualDesconto() != null) {
            _hashCode += getPercentualDesconto().hashCode();
        }
        if (getQuantidadeMeses() != null) {
            _hashCode += getQuantidadeMeses().hashCode();
        }
        if (getValorMetaFaturamento() != null) {
            _hashCode += getValorMetaFaturamento().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DescontoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "DescontoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoDesconto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "tipoDesconto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorOriginal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "valorOriginal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorComDesconto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "valorComDesconto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorDesconto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "valorDesconto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualDesconto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "percentualDesconto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeMeses");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "quantidadeMeses"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorMetaFaturamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "valorMetaFaturamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
