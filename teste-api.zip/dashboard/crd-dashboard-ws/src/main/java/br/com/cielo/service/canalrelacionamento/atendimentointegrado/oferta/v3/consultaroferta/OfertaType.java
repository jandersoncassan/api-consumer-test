/**
 * OfertaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta;

public class OfertaType  implements java.io.Serializable {
    private java.lang.String codigo;

    private java.lang.String nome;

    private java.lang.String descricao;

    private java.lang.String categoria;

    private java.lang.String termoEligibilidade;

    private java.lang.Integer prioridade;

    private java.lang.String codigoNivel;

    private java.lang.String codigoSessao;

    private java.lang.String codigoRastreio;

    private br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] comboDescontos;

    private br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] descontosAvulso;

    public OfertaType() {
    }

    public OfertaType(
           java.lang.String codigo,
           java.lang.String nome,
           java.lang.String descricao,
           java.lang.String categoria,
           java.lang.String termoEligibilidade,
           java.lang.Integer prioridade,
           java.lang.String codigoNivel,
           java.lang.String codigoSessao,
           java.lang.String codigoRastreio,
           br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] comboDescontos,
           br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] descontosAvulso) {
           this.codigo = codigo;
           this.nome = nome;
           this.descricao = descricao;
           this.categoria = categoria;
           this.termoEligibilidade = termoEligibilidade;
           this.prioridade = prioridade;
           this.codigoNivel = codigoNivel;
           this.codigoSessao = codigoSessao;
           this.codigoRastreio = codigoRastreio;
           this.comboDescontos = comboDescontos;
           this.descontosAvulso = descontosAvulso;
    }


    /**
     * Gets the codigo value for this OfertaType.
     * 
     * @return codigo
     */
    public java.lang.String getCodigo() {
        return codigo;
    }


    /**
     * Sets the codigo value for this OfertaType.
     * 
     * @param codigo
     */
    public void setCodigo(java.lang.String codigo) {
        this.codigo = codigo;
    }


    /**
     * Gets the nome value for this OfertaType.
     * 
     * @return nome
     */
    public java.lang.String getNome() {
        return nome;
    }


    /**
     * Sets the nome value for this OfertaType.
     * 
     * @param nome
     */
    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }


    /**
     * Gets the descricao value for this OfertaType.
     * 
     * @return descricao
     */
    public java.lang.String getDescricao() {
        return descricao;
    }


    /**
     * Sets the descricao value for this OfertaType.
     * 
     * @param descricao
     */
    public void setDescricao(java.lang.String descricao) {
        this.descricao = descricao;
    }


    /**
     * Gets the categoria value for this OfertaType.
     * 
     * @return categoria
     */
    public java.lang.String getCategoria() {
        return categoria;
    }


    /**
     * Sets the categoria value for this OfertaType.
     * 
     * @param categoria
     */
    public void setCategoria(java.lang.String categoria) {
        this.categoria = categoria;
    }


    /**
     * Gets the termoEligibilidade value for this OfertaType.
     * 
     * @return termoEligibilidade
     */
    public java.lang.String getTermoEligibilidade() {
        return termoEligibilidade;
    }


    /**
     * Sets the termoEligibilidade value for this OfertaType.
     * 
     * @param termoEligibilidade
     */
    public void setTermoEligibilidade(java.lang.String termoEligibilidade) {
        this.termoEligibilidade = termoEligibilidade;
    }


    /**
     * Gets the prioridade value for this OfertaType.
     * 
     * @return prioridade
     */
    public java.lang.Integer getPrioridade() {
        return prioridade;
    }


    /**
     * Sets the prioridade value for this OfertaType.
     * 
     * @param prioridade
     */
    public void setPrioridade(java.lang.Integer prioridade) {
        this.prioridade = prioridade;
    }


    /**
     * Gets the codigoNivel value for this OfertaType.
     * 
     * @return codigoNivel
     */
    public java.lang.String getCodigoNivel() {
        return codigoNivel;
    }


    /**
     * Sets the codigoNivel value for this OfertaType.
     * 
     * @param codigoNivel
     */
    public void setCodigoNivel(java.lang.String codigoNivel) {
        this.codigoNivel = codigoNivel;
    }


    /**
     * Gets the codigoSessao value for this OfertaType.
     * 
     * @return codigoSessao
     */
    public java.lang.String getCodigoSessao() {
        return codigoSessao;
    }


    /**
     * Sets the codigoSessao value for this OfertaType.
     * 
     * @param codigoSessao
     */
    public void setCodigoSessao(java.lang.String codigoSessao) {
        this.codigoSessao = codigoSessao;
    }


    /**
     * Gets the codigoRastreio value for this OfertaType.
     * 
     * @return codigoRastreio
     */
    public java.lang.String getCodigoRastreio() {
        return codigoRastreio;
    }


    /**
     * Sets the codigoRastreio value for this OfertaType.
     * 
     * @param codigoRastreio
     */
    public void setCodigoRastreio(java.lang.String codigoRastreio) {
        this.codigoRastreio = codigoRastreio;
    }


    /**
     * Gets the comboDescontos value for this OfertaType.
     * 
     * @return comboDescontos
     */
    public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] getComboDescontos() {
        return comboDescontos;
    }


    /**
     * Sets the comboDescontos value for this OfertaType.
     * 
     * @param comboDescontos
     */
    public void setComboDescontos(br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] comboDescontos) {
        this.comboDescontos = comboDescontos;
    }


    /**
     * Gets the descontosAvulso value for this OfertaType.
     * 
     * @return descontosAvulso
     */
    public br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] getDescontosAvulso() {
        return descontosAvulso;
    }


    /**
     * Sets the descontosAvulso value for this OfertaType.
     * 
     * @param descontosAvulso
     */
    public void setDescontosAvulso(br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta.DescontoType[] descontosAvulso) {
        this.descontosAvulso = descontosAvulso;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OfertaType)) return false;
        OfertaType other = (OfertaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigo==null && other.getCodigo()==null) || 
             (this.codigo!=null &&
              this.codigo.equals(other.getCodigo()))) &&
            ((this.nome==null && other.getNome()==null) || 
             (this.nome!=null &&
              this.nome.equals(other.getNome()))) &&
            ((this.descricao==null && other.getDescricao()==null) || 
             (this.descricao!=null &&
              this.descricao.equals(other.getDescricao()))) &&
            ((this.categoria==null && other.getCategoria()==null) || 
             (this.categoria!=null &&
              this.categoria.equals(other.getCategoria()))) &&
            ((this.termoEligibilidade==null && other.getTermoEligibilidade()==null) || 
             (this.termoEligibilidade!=null &&
              this.termoEligibilidade.equals(other.getTermoEligibilidade()))) &&
            ((this.prioridade==null && other.getPrioridade()==null) || 
             (this.prioridade!=null &&
              this.prioridade.equals(other.getPrioridade()))) &&
            ((this.codigoNivel==null && other.getCodigoNivel()==null) || 
             (this.codigoNivel!=null &&
              this.codigoNivel.equals(other.getCodigoNivel()))) &&
            ((this.codigoSessao==null && other.getCodigoSessao()==null) || 
             (this.codigoSessao!=null &&
              this.codigoSessao.equals(other.getCodigoSessao()))) &&
            ((this.codigoRastreio==null && other.getCodigoRastreio()==null) || 
             (this.codigoRastreio!=null &&
              this.codigoRastreio.equals(other.getCodigoRastreio()))) &&
            ((this.comboDescontos==null && other.getComboDescontos()==null) || 
             (this.comboDescontos!=null &&
              java.util.Arrays.equals(this.comboDescontos, other.getComboDescontos()))) &&
            ((this.descontosAvulso==null && other.getDescontosAvulso()==null) || 
             (this.descontosAvulso!=null &&
              java.util.Arrays.equals(this.descontosAvulso, other.getDescontosAvulso())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigo() != null) {
            _hashCode += getCodigo().hashCode();
        }
        if (getNome() != null) {
            _hashCode += getNome().hashCode();
        }
        if (getDescricao() != null) {
            _hashCode += getDescricao().hashCode();
        }
        if (getCategoria() != null) {
            _hashCode += getCategoria().hashCode();
        }
        if (getTermoEligibilidade() != null) {
            _hashCode += getTermoEligibilidade().hashCode();
        }
        if (getPrioridade() != null) {
            _hashCode += getPrioridade().hashCode();
        }
        if (getCodigoNivel() != null) {
            _hashCode += getCodigoNivel().hashCode();
        }
        if (getCodigoSessao() != null) {
            _hashCode += getCodigoSessao().hashCode();
        }
        if (getCodigoRastreio() != null) {
            _hashCode += getCodigoRastreio().hashCode();
        }
        if (getComboDescontos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getComboDescontos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getComboDescontos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDescontosAvulso() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDescontosAvulso());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDescontosAvulso(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OfertaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "OfertaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "nome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "descricao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("categoria");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "categoria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("termoEligibilidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "termoEligibilidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prioridade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "prioridade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoNivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoNivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSessao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoSessao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRastreio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoRastreio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("comboDescontos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "comboDescontos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "DescontoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "descontos"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descontosAvulso");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "descontosAvulso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "DescontoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "descontos"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
