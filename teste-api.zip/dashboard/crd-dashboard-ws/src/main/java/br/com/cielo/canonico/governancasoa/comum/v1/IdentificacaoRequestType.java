/**
 * IdentificacaoRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.governancasoa.comum.v1;


/**
 * Estes atributos sao utilizados no header cielo para identificar
 * a origem da requisicao
 *     		ao servico.
 */
public class IdentificacaoRequestType  implements java.io.Serializable {
    private java.lang.String nomeSistema;

    private java.lang.String nomeTipoChamada;

    public IdentificacaoRequestType() {
    }

    public IdentificacaoRequestType(
           java.lang.String nomeSistema,
           java.lang.String nomeTipoChamada) {
           this.nomeSistema = nomeSistema;
           this.nomeTipoChamada = nomeTipoChamada;
    }


    /**
     * Gets the nomeSistema value for this IdentificacaoRequestType.
     * 
     * @return nomeSistema
     */
    public java.lang.String getNomeSistema() {
        return nomeSistema;
    }


    /**
     * Sets the nomeSistema value for this IdentificacaoRequestType.
     * 
     * @param nomeSistema
     */
    public void setNomeSistema(java.lang.String nomeSistema) {
        this.nomeSistema = nomeSistema;
    }


    /**
     * Gets the nomeTipoChamada value for this IdentificacaoRequestType.
     * 
     * @return nomeTipoChamada
     */
    public java.lang.String getNomeTipoChamada() {
        return nomeTipoChamada;
    }


    /**
     * Sets the nomeTipoChamada value for this IdentificacaoRequestType.
     * 
     * @param nomeTipoChamada
     */
    public void setNomeTipoChamada(java.lang.String nomeTipoChamada) {
        this.nomeTipoChamada = nomeTipoChamada;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IdentificacaoRequestType)) return false;
        IdentificacaoRequestType other = (IdentificacaoRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nomeSistema==null && other.getNomeSistema()==null) || 
             (this.nomeSistema!=null &&
              this.nomeSistema.equals(other.getNomeSistema()))) &&
            ((this.nomeTipoChamada==null && other.getNomeTipoChamada()==null) || 
             (this.nomeTipoChamada!=null &&
              this.nomeTipoChamada.equals(other.getNomeTipoChamada())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNomeSistema() != null) {
            _hashCode += getNomeSistema().hashCode();
        }
        if (getNomeTipoChamada() != null) {
            _hashCode += getNomeTipoChamada().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IdentificacaoRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "IdentificacaoRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeSistema");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomeSistema"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoChamada");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomeTipoChamada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
