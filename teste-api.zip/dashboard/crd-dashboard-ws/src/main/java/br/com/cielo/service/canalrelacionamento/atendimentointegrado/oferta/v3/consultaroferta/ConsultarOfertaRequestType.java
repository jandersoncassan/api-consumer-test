/**
 * ConsultarOfertaRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.canalrelacionamento.atendimentointegrado.oferta.v3.consultaroferta;

public class ConsultarOfertaRequestType  implements java.io.Serializable {
    private java.lang.Long cpfCnpj;

    private java.lang.Boolean indicadorConsultaEspecifica;

    private java.math.BigDecimal codigoAfiliacao;

    private java.lang.Integer quantidadeEquipamentos;

    /* plano cielo (convencional e cielo controle) */
    private java.lang.String tipoPlano;

    /* plano cielo de aluguel (mais, plus) */
    private java.lang.String tipoPlanoAluguel;

    /* CEP (5 primeiros digitos) */
    private java.lang.Integer cep;

    private java.lang.String cidade;

    private java.lang.String estado;

    private java.lang.Integer codigoBanco;

    private java.lang.Integer codigoSolucaoCaptura;

    private java.math.BigDecimal faturamentoMedio;

    private java.lang.Integer ramoAtividade;

    private java.lang.String tipoPessoa;

    private java.lang.Boolean indicarMultivan;

    private java.lang.String cupomDesconto;

    private java.lang.String remarketing;

    private java.lang.String codigoNivel;

    private java.lang.Integer qtdOfertas;

    private java.lang.String codigoSessao;

    public ConsultarOfertaRequestType() {
    }

    public ConsultarOfertaRequestType(
           java.lang.Long cpfCnpj,
           java.lang.Boolean indicadorConsultaEspecifica,
           java.math.BigDecimal codigoAfiliacao,
           java.lang.Integer quantidadeEquipamentos,
           java.lang.String tipoPlano,
           java.lang.String tipoPlanoAluguel,
           java.lang.Integer cep,
           java.lang.String cidade,
           java.lang.String estado,
           java.lang.Integer codigoBanco,
           java.lang.Integer codigoSolucaoCaptura,
           java.math.BigDecimal faturamentoMedio,
           java.lang.Integer ramoAtividade,
           java.lang.String tipoPessoa,
           java.lang.Boolean indicarMultivan,
           java.lang.String cupomDesconto,
           java.lang.String remarketing,
           java.lang.String codigoNivel,
           java.lang.Integer qtdOfertas,
           java.lang.String codigoSessao) {
           this.cpfCnpj = cpfCnpj;
           this.indicadorConsultaEspecifica = indicadorConsultaEspecifica;
           this.codigoAfiliacao = codigoAfiliacao;
           this.quantidadeEquipamentos = quantidadeEquipamentos;
           this.tipoPlano = tipoPlano;
           this.tipoPlanoAluguel = tipoPlanoAluguel;
           this.cep = cep;
           this.cidade = cidade;
           this.estado = estado;
           this.codigoBanco = codigoBanco;
           this.codigoSolucaoCaptura = codigoSolucaoCaptura;
           this.faturamentoMedio = faturamentoMedio;
           this.ramoAtividade = ramoAtividade;
           this.tipoPessoa = tipoPessoa;
           this.indicarMultivan = indicarMultivan;
           this.cupomDesconto = cupomDesconto;
           this.remarketing = remarketing;
           this.codigoNivel = codigoNivel;
           this.qtdOfertas = qtdOfertas;
           this.codigoSessao = codigoSessao;
    }


    /**
     * Gets the cpfCnpj value for this ConsultarOfertaRequestType.
     * 
     * @return cpfCnpj
     */
    public java.lang.Long getCpfCnpj() {
        return cpfCnpj;
    }


    /**
     * Sets the cpfCnpj value for this ConsultarOfertaRequestType.
     * 
     * @param cpfCnpj
     */
    public void setCpfCnpj(java.lang.Long cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }


    /**
     * Gets the indicadorConsultaEspecifica value for this ConsultarOfertaRequestType.
     * 
     * @return indicadorConsultaEspecifica
     */
    public java.lang.Boolean getIndicadorConsultaEspecifica() {
        return indicadorConsultaEspecifica;
    }


    /**
     * Sets the indicadorConsultaEspecifica value for this ConsultarOfertaRequestType.
     * 
     * @param indicadorConsultaEspecifica
     */
    public void setIndicadorConsultaEspecifica(java.lang.Boolean indicadorConsultaEspecifica) {
        this.indicadorConsultaEspecifica = indicadorConsultaEspecifica;
    }


    /**
     * Gets the codigoAfiliacao value for this ConsultarOfertaRequestType.
     * 
     * @return codigoAfiliacao
     */
    public java.math.BigDecimal getCodigoAfiliacao() {
        return codigoAfiliacao;
    }


    /**
     * Sets the codigoAfiliacao value for this ConsultarOfertaRequestType.
     * 
     * @param codigoAfiliacao
     */
    public void setCodigoAfiliacao(java.math.BigDecimal codigoAfiliacao) {
        this.codigoAfiliacao = codigoAfiliacao;
    }


    /**
     * Gets the quantidadeEquipamentos value for this ConsultarOfertaRequestType.
     * 
     * @return quantidadeEquipamentos
     */
    public java.lang.Integer getQuantidadeEquipamentos() {
        return quantidadeEquipamentos;
    }


    /**
     * Sets the quantidadeEquipamentos value for this ConsultarOfertaRequestType.
     * 
     * @param quantidadeEquipamentos
     */
    public void setQuantidadeEquipamentos(java.lang.Integer quantidadeEquipamentos) {
        this.quantidadeEquipamentos = quantidadeEquipamentos;
    }


    /**
     * Gets the tipoPlano value for this ConsultarOfertaRequestType.
     * 
     * @return tipoPlano   * plano cielo (convencional e cielo controle)
     */
    public java.lang.String getTipoPlano() {
        return tipoPlano;
    }


    /**
     * Sets the tipoPlano value for this ConsultarOfertaRequestType.
     * 
     * @param tipoPlano   * plano cielo (convencional e cielo controle)
     */
    public void setTipoPlano(java.lang.String tipoPlano) {
        this.tipoPlano = tipoPlano;
    }


    /**
     * Gets the tipoPlanoAluguel value for this ConsultarOfertaRequestType.
     * 
     * @return tipoPlanoAluguel   * plano cielo de aluguel (mais, plus)
     */
    public java.lang.String getTipoPlanoAluguel() {
        return tipoPlanoAluguel;
    }


    /**
     * Sets the tipoPlanoAluguel value for this ConsultarOfertaRequestType.
     * 
     * @param tipoPlanoAluguel   * plano cielo de aluguel (mais, plus)
     */
    public void setTipoPlanoAluguel(java.lang.String tipoPlanoAluguel) {
        this.tipoPlanoAluguel = tipoPlanoAluguel;
    }


    /**
     * Gets the cep value for this ConsultarOfertaRequestType.
     * 
     * @return cep   * CEP (5 primeiros digitos)
     */
    public java.lang.Integer getCep() {
        return cep;
    }


    /**
     * Sets the cep value for this ConsultarOfertaRequestType.
     * 
     * @param cep   * CEP (5 primeiros digitos)
     */
    public void setCep(java.lang.Integer cep) {
        this.cep = cep;
    }


    /**
     * Gets the cidade value for this ConsultarOfertaRequestType.
     * 
     * @return cidade
     */
    public java.lang.String getCidade() {
        return cidade;
    }


    /**
     * Sets the cidade value for this ConsultarOfertaRequestType.
     * 
     * @param cidade
     */
    public void setCidade(java.lang.String cidade) {
        this.cidade = cidade;
    }


    /**
     * Gets the estado value for this ConsultarOfertaRequestType.
     * 
     * @return estado
     */
    public java.lang.String getEstado() {
        return estado;
    }


    /**
     * Sets the estado value for this ConsultarOfertaRequestType.
     * 
     * @param estado
     */
    public void setEstado(java.lang.String estado) {
        this.estado = estado;
    }


    /**
     * Gets the codigoBanco value for this ConsultarOfertaRequestType.
     * 
     * @return codigoBanco
     */
    public java.lang.Integer getCodigoBanco() {
        return codigoBanco;
    }


    /**
     * Sets the codigoBanco value for this ConsultarOfertaRequestType.
     * 
     * @param codigoBanco
     */
    public void setCodigoBanco(java.lang.Integer codigoBanco) {
        this.codigoBanco = codigoBanco;
    }


    /**
     * Gets the codigoSolucaoCaptura value for this ConsultarOfertaRequestType.
     * 
     * @return codigoSolucaoCaptura
     */
    public java.lang.Integer getCodigoSolucaoCaptura() {
        return codigoSolucaoCaptura;
    }


    /**
     * Sets the codigoSolucaoCaptura value for this ConsultarOfertaRequestType.
     * 
     * @param codigoSolucaoCaptura
     */
    public void setCodigoSolucaoCaptura(java.lang.Integer codigoSolucaoCaptura) {
        this.codigoSolucaoCaptura = codigoSolucaoCaptura;
    }


    /**
     * Gets the faturamentoMedio value for this ConsultarOfertaRequestType.
     * 
     * @return faturamentoMedio
     */
    public java.math.BigDecimal getFaturamentoMedio() {
        return faturamentoMedio;
    }


    /**
     * Sets the faturamentoMedio value for this ConsultarOfertaRequestType.
     * 
     * @param faturamentoMedio
     */
    public void setFaturamentoMedio(java.math.BigDecimal faturamentoMedio) {
        this.faturamentoMedio = faturamentoMedio;
    }


    /**
     * Gets the ramoAtividade value for this ConsultarOfertaRequestType.
     * 
     * @return ramoAtividade
     */
    public java.lang.Integer getRamoAtividade() {
        return ramoAtividade;
    }


    /**
     * Sets the ramoAtividade value for this ConsultarOfertaRequestType.
     * 
     * @param ramoAtividade
     */
    public void setRamoAtividade(java.lang.Integer ramoAtividade) {
        this.ramoAtividade = ramoAtividade;
    }


    /**
     * Gets the tipoPessoa value for this ConsultarOfertaRequestType.
     * 
     * @return tipoPessoa
     */
    public java.lang.String getTipoPessoa() {
        return tipoPessoa;
    }


    /**
     * Sets the tipoPessoa value for this ConsultarOfertaRequestType.
     * 
     * @param tipoPessoa
     */
    public void setTipoPessoa(java.lang.String tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }


    /**
     * Gets the indicarMultivan value for this ConsultarOfertaRequestType.
     * 
     * @return indicarMultivan
     */
    public java.lang.Boolean getIndicarMultivan() {
        return indicarMultivan;
    }


    /**
     * Sets the indicarMultivan value for this ConsultarOfertaRequestType.
     * 
     * @param indicarMultivan
     */
    public void setIndicarMultivan(java.lang.Boolean indicarMultivan) {
        this.indicarMultivan = indicarMultivan;
    }


    /**
     * Gets the cupomDesconto value for this ConsultarOfertaRequestType.
     * 
     * @return cupomDesconto
     */
    public java.lang.String getCupomDesconto() {
        return cupomDesconto;
    }


    /**
     * Sets the cupomDesconto value for this ConsultarOfertaRequestType.
     * 
     * @param cupomDesconto
     */
    public void setCupomDesconto(java.lang.String cupomDesconto) {
        this.cupomDesconto = cupomDesconto;
    }


    /**
     * Gets the remarketing value for this ConsultarOfertaRequestType.
     * 
     * @return remarketing
     */
    public java.lang.String getRemarketing() {
        return remarketing;
    }


    /**
     * Sets the remarketing value for this ConsultarOfertaRequestType.
     * 
     * @param remarketing
     */
    public void setRemarketing(java.lang.String remarketing) {
        this.remarketing = remarketing;
    }


    /**
     * Gets the codigoNivel value for this ConsultarOfertaRequestType.
     * 
     * @return codigoNivel
     */
    public java.lang.String getCodigoNivel() {
        return codigoNivel;
    }


    /**
     * Sets the codigoNivel value for this ConsultarOfertaRequestType.
     * 
     * @param codigoNivel
     */
    public void setCodigoNivel(java.lang.String codigoNivel) {
        this.codigoNivel = codigoNivel;
    }


    /**
     * Gets the qtdOfertas value for this ConsultarOfertaRequestType.
     * 
     * @return qtdOfertas
     */
    public java.lang.Integer getQtdOfertas() {
        return qtdOfertas;
    }


    /**
     * Sets the qtdOfertas value for this ConsultarOfertaRequestType.
     * 
     * @param qtdOfertas
     */
    public void setQtdOfertas(java.lang.Integer qtdOfertas) {
        this.qtdOfertas = qtdOfertas;
    }


    /**
     * Gets the codigoSessao value for this ConsultarOfertaRequestType.
     * 
     * @return codigoSessao
     */
    public java.lang.String getCodigoSessao() {
        return codigoSessao;
    }


    /**
     * Sets the codigoSessao value for this ConsultarOfertaRequestType.
     * 
     * @param codigoSessao
     */
    public void setCodigoSessao(java.lang.String codigoSessao) {
        this.codigoSessao = codigoSessao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarOfertaRequestType)) return false;
        ConsultarOfertaRequestType other = (ConsultarOfertaRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cpfCnpj==null && other.getCpfCnpj()==null) || 
             (this.cpfCnpj!=null &&
              this.cpfCnpj.equals(other.getCpfCnpj()))) &&
            ((this.indicadorConsultaEspecifica==null && other.getIndicadorConsultaEspecifica()==null) || 
             (this.indicadorConsultaEspecifica!=null &&
              this.indicadorConsultaEspecifica.equals(other.getIndicadorConsultaEspecifica()))) &&
            ((this.codigoAfiliacao==null && other.getCodigoAfiliacao()==null) || 
             (this.codigoAfiliacao!=null &&
              this.codigoAfiliacao.equals(other.getCodigoAfiliacao()))) &&
            ((this.quantidadeEquipamentos==null && other.getQuantidadeEquipamentos()==null) || 
             (this.quantidadeEquipamentos!=null &&
              this.quantidadeEquipamentos.equals(other.getQuantidadeEquipamentos()))) &&
            ((this.tipoPlano==null && other.getTipoPlano()==null) || 
             (this.tipoPlano!=null &&
              this.tipoPlano.equals(other.getTipoPlano()))) &&
            ((this.tipoPlanoAluguel==null && other.getTipoPlanoAluguel()==null) || 
             (this.tipoPlanoAluguel!=null &&
              this.tipoPlanoAluguel.equals(other.getTipoPlanoAluguel()))) &&
            ((this.cep==null && other.getCep()==null) || 
             (this.cep!=null &&
              this.cep.equals(other.getCep()))) &&
            ((this.cidade==null && other.getCidade()==null) || 
             (this.cidade!=null &&
              this.cidade.equals(other.getCidade()))) &&
            ((this.estado==null && other.getEstado()==null) || 
             (this.estado!=null &&
              this.estado.equals(other.getEstado()))) &&
            ((this.codigoBanco==null && other.getCodigoBanco()==null) || 
             (this.codigoBanco!=null &&
              this.codigoBanco.equals(other.getCodigoBanco()))) &&
            ((this.codigoSolucaoCaptura==null && other.getCodigoSolucaoCaptura()==null) || 
             (this.codigoSolucaoCaptura!=null &&
              this.codigoSolucaoCaptura.equals(other.getCodigoSolucaoCaptura()))) &&
            ((this.faturamentoMedio==null && other.getFaturamentoMedio()==null) || 
             (this.faturamentoMedio!=null &&
              this.faturamentoMedio.equals(other.getFaturamentoMedio()))) &&
            ((this.ramoAtividade==null && other.getRamoAtividade()==null) || 
             (this.ramoAtividade!=null &&
              this.ramoAtividade.equals(other.getRamoAtividade()))) &&
            ((this.tipoPessoa==null && other.getTipoPessoa()==null) || 
             (this.tipoPessoa!=null &&
              this.tipoPessoa.equals(other.getTipoPessoa()))) &&
            ((this.indicarMultivan==null && other.getIndicarMultivan()==null) || 
             (this.indicarMultivan!=null &&
              this.indicarMultivan.equals(other.getIndicarMultivan()))) &&
            ((this.cupomDesconto==null && other.getCupomDesconto()==null) || 
             (this.cupomDesconto!=null &&
              this.cupomDesconto.equals(other.getCupomDesconto()))) &&
            ((this.remarketing==null && other.getRemarketing()==null) || 
             (this.remarketing!=null &&
              this.remarketing.equals(other.getRemarketing()))) &&
            ((this.codigoNivel==null && other.getCodigoNivel()==null) || 
             (this.codigoNivel!=null &&
              this.codigoNivel.equals(other.getCodigoNivel()))) &&
            ((this.qtdOfertas==null && other.getQtdOfertas()==null) || 
             (this.qtdOfertas!=null &&
              this.qtdOfertas.equals(other.getQtdOfertas()))) &&
            ((this.codigoSessao==null && other.getCodigoSessao()==null) || 
             (this.codigoSessao!=null &&
              this.codigoSessao.equals(other.getCodigoSessao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCpfCnpj() != null) {
            _hashCode += getCpfCnpj().hashCode();
        }
        if (getIndicadorConsultaEspecifica() != null) {
            _hashCode += getIndicadorConsultaEspecifica().hashCode();
        }
        if (getCodigoAfiliacao() != null) {
            _hashCode += getCodigoAfiliacao().hashCode();
        }
        if (getQuantidadeEquipamentos() != null) {
            _hashCode += getQuantidadeEquipamentos().hashCode();
        }
        if (getTipoPlano() != null) {
            _hashCode += getTipoPlano().hashCode();
        }
        if (getTipoPlanoAluguel() != null) {
            _hashCode += getTipoPlanoAluguel().hashCode();
        }
        if (getCep() != null) {
            _hashCode += getCep().hashCode();
        }
        if (getCidade() != null) {
            _hashCode += getCidade().hashCode();
        }
        if (getEstado() != null) {
            _hashCode += getEstado().hashCode();
        }
        if (getCodigoBanco() != null) {
            _hashCode += getCodigoBanco().hashCode();
        }
        if (getCodigoSolucaoCaptura() != null) {
            _hashCode += getCodigoSolucaoCaptura().hashCode();
        }
        if (getFaturamentoMedio() != null) {
            _hashCode += getFaturamentoMedio().hashCode();
        }
        if (getRamoAtividade() != null) {
            _hashCode += getRamoAtividade().hashCode();
        }
        if (getTipoPessoa() != null) {
            _hashCode += getTipoPessoa().hashCode();
        }
        if (getIndicarMultivan() != null) {
            _hashCode += getIndicarMultivan().hashCode();
        }
        if (getCupomDesconto() != null) {
            _hashCode += getCupomDesconto().hashCode();
        }
        if (getRemarketing() != null) {
            _hashCode += getRemarketing().hashCode();
        }
        if (getCodigoNivel() != null) {
            _hashCode += getCodigoNivel().hashCode();
        }
        if (getQtdOfertas() != null) {
            _hashCode += getQtdOfertas().hashCode();
        }
        if (getCodigoSessao() != null) {
            _hashCode += getCodigoSessao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarOfertaRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "ConsultarOfertaRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpfCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "cpfCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorConsultaEspecifica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "indicadorConsultaEspecifica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoAfiliacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoAfiliacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeEquipamentos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "quantidadeEquipamentos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoPlano");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "tipoPlano"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoPlanoAluguel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "tipoPlanoAluguel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cep");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "cep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "cidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "estado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("faturamentoMedio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "faturamentoMedio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ramoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "ramoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "tipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicarMultivan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "indicarMultivan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cupomDesconto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "cupomDesconto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("remarketing");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "remarketing"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoNivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoNivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("qtdOfertas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "qtdOfertas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSessao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/canalrelacionamento/atendimentointegrado/oferta/v3/consultaroferta", "codigoSessao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
