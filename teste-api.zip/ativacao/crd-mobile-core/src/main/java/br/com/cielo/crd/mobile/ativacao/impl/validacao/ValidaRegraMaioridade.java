package br.com.cielo.crd.mobile.ativacao.impl.validacao;

import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.ValidacaoService;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.common.DadosProprietarioType;
import br.com.cielo.crd.mobile.qualifier.ValidacaoMobile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

@ValidacaoMobile(etapa=ValidacaoEnum.VALIDAR_MAIORIDADE)
public class ValidaRegraMaioridade extends ValidacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(ValidaRegraMaioridade.class);

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosValidacao) {
		LOG.debug("INIT VALIDACAO MAIORIDADE");
		AtivacaoMobile retorno =  new AtivacaoMobile();
		popularInfoValidacao(retorno, ValidacaoEnum.VALIDAR_MAIORIDADE);
		//INIT Verificar Existência Domicilio Bancario
		init(dadosValidacao, retorno);
		return retorno;
	}

	/**
	 * Método responsavel pela validação da maioridade do cliente
	 * @param dadosValidacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosValidacao, AtivacaoMobile retorno) {
		retorno.setIsEtapaValida(Boolean.TRUE);
		int qtdadeProprietarios =  dadosValidacao.getListaProprietarios().size();
		int qtdadePropMenores = 0;
		Iterator<DadosProprietarioType> prop = dadosValidacao.getListaProprietarios().iterator();
		while(prop.hasNext()){
			DadosProprietarioType proprietario = prop.next();
			Date dataNascimento = proprietario.getDataNascimento();
			Boolean isMaior = isMaiorIdade(dataNascimento);
			if(!isMaior){
				qtdadePropMenores ++;
				prop.remove();
			}
		}		
		if(qtdadeProprietarios == qtdadePropMenores){
			popularRetorno(retorno, "PROPRIETARIO MENOR DE 18 ANOS"); 
		}
	}	
	
	 /**
     * Método responsavel por verificar se o proprietário é maior de idade
     * @param dataNascimento
     * @return Boolean
     */
    private Boolean isMaiorIdade(final Date dataNascimento){
        Calendar calDataNasc = Calendar.getInstance();
        calDataNasc.setTime(dataNascimento);
        Calendar calAtualMenosDezoito = Calendar.getInstance();
        calAtualMenosDezoito.add(Calendar.YEAR, CrdMobileUtils.MENOS_DEZOITO);
        return calAtualMenosDezoito.after(calDataNasc);
   }
	
	/**
	 * Método responsavel por popular a mensagem de tratamento Cpf/Cnpj
	 * @param mensagem
	 * @return AtivacaoMobile
	 */
	private AtivacaoMobile popularRetorno(AtivacaoMobile retorno, String mensagem){
		retorno.setIsEtapaValida(Boolean.FALSE);
		retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
		retorno.setMensagem(mensagem);
		return retorno;
	}

}
