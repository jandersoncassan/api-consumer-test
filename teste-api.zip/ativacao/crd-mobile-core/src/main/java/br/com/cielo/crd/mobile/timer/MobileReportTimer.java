package br.com.cielo.crd.mobile.timer;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.service.MobileReportService;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

@Singleton
public class MobileReportTimer {

    private static final Logger LOG = LoggerFactory.getLogger(MobileReportTimer.class);

    @Inject
    private MobileReportService mobileReportService;

    private final String NAME_CLUSTER = "weblogic.Name";

    private final String CLUSTER_NO1 = "credServer1";

    private static int count = CrdMobileUtils.NUM_ZERO;

    private static String data = CrdMobileUtils.getDataAtual();

    /**
     * SCHEDULER RESPONSAVEL POR ENVIAR O EMAIL COM O RELATORIO DE PROCESSAMENTO DE ATIVACAO MOBILE
     */
   @Schedule(hour = "12", minute = "00", info = "Scheduler Envio de Email Processamento Ativação Mobile", persistent = false)
    public void execute() {

        LOG.debug("INIT : ENVIO DE EMAIL PROCESSAMENTO ATIVACAO MOBILE");
        try {
            String nameServer = System.getProperty(NAME_CLUSTER);
            LOG.debug("NOME SERVIDOR : " + nameServer + " DATA : " + data + " COUNT : " + count);
            if (nameServer.equals(CLUSTER_NO1)) {
                tratarParamEnvioEmail();
                if (count == CrdMobileUtils.NUM_ZERO) {
                    mobileReportService.gerarReportMobile();
                    count++;
                }
            }
        } catch (Exception ex) {
            LOG.debug(String.format("%s",
                "ERROR : OCORREU UMA EXCEÇÃO AO ENVIAR EMAIL PROCESSAMENTO ATIVACAO MOBILE : [{}]", ex.getMessage()));
        }
    }

    /**
     * Método responsavel pela consistência de envio de email
     */
    private void tratarParamEnvioEmail() {

        String data_atual = CrdMobileUtils.getDataAtual();
        LOG.debug("DATA_CONTROLE : " + data + " DATA_ATUAL : " + data_atual + " DATAS_EQUAL : "
            + !data.equals(data_atual) + " COUNT : " + count);
        if (!data.equals(data_atual) && count != 0) {
            data = data_atual;
            count = 0;
        }
    }

}
