package br.com.cielo.crd.mobile.ativacao.impl.ativar;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoRequest;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoResponse;

@AtivarMobile(etapa=AtivacaoEnum.GERAR_NUMERO_LOGICO)
public class GeracaoNumeroLogico extends AtivacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(GeracaoNumeroLogico.class);
	
	@Inject
	private ServicosOsb service;

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		LOG.debug("INIT GERAR NUMERO LOGICO");
		popularInfoValidacao(retorno, AtivacaoEnum.GERAR_NUMERO_LOGICO);
		init(dadosAtivacao, retorno);
		return retorno;
	}

	/**
	 * Método init da execução de inclusão de clientes em redes
	 * @param dadosAtivacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		IncluirNumeroLogicoRequest request = popularRequest(dadosAtivacao, retorno);
		gerarNumeroLogico(request, retorno);
	}

	/**
	 * Método responsavel pela habilitação de produtos
	 * @param request
	 * @param retorno
	 */
	private void gerarNumeroLogico(IncluirNumeroLogicoRequest request, AtivacaoMobile retorno) {
		try {
			CrdMobileUtils.deflate("GERACAO NUMERO LOGICO", request);
			IncluirNumeroLogicoResponse retornoService = service.gerarNumeroLogico(request);
			persistirInfoRetorno(retornoService, retorno);			
		} catch (Exception e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}		
	}

	/**
	 * Método responsavel pela persistencia das informações de retorno do serviço de redes
	 * @param service
	 * @param retorno
	 */
	private void persistirInfoRetorno(IncluirNumeroLogicoResponse service, AtivacaoMobile retorno){
		retorno.setNumeroLogico(Integer.valueOf(service.getNumeroLogico().toString()));
		retorno.setDigNumLogico(service.getDigitoNumeroLogico());
		retorno.setIsEtapaValida(Boolean.TRUE);		
	}
	
	/**
	 * Método responsavel por popular a request
	 * @param dadosAtivacao
	 * @return HabilitarListaProdutoRequest
	 */
	private IncluirNumeroLogicoRequest popularRequest(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		IncluirNumeroLogicoRequest request = new IncluirNumeroLogicoRequest();
		request.setSistemaOrigem(CrdMobileUtils.CRD);
		request.setCodigoCliente(retorno.getNumeroEC());
		request.setGrupoSolucaoCaptura(CrdMobileUtils.GRUPO_SOLUCAO_CAPTURA);
		request.setTipoTerminal(CrdMobileUtils.TIPO_TERMINAL);
		return request;
	}
}
