package br.com.cielo.crd.mobile.qualifier;

import static java.lang.annotation.ElementType.*;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.inject.Qualifier;

import br.com.cielo.crd.mobile.enums.EtapasAtivacaoMobileEnum;

@Target({TYPE, FIELD, METHOD, PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Qualifier
public @interface EtapaMobile {
	EtapasAtivacaoMobileEnum etapa();
}
