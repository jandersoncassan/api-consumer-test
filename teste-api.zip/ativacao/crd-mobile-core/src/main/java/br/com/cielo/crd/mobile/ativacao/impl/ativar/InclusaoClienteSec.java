package br.com.cielo.crd.mobile.ativacao.impl.ativar;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.common.DomicilioBancarioType;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileFile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.BancoType;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.Cliente;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosProprietarioType;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoType;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoTypeCodigoTipoEndereco;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorMicroEmpreendedorIndividual;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorPersistencia;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneType;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneTypeCodigoTipoTelefone;

@AtivarMobile(etapa=AtivacaoEnum.INCLUIR_EC_SEC)
public class InclusaoClienteSec extends AtivacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(InclusaoClienteSec.class);
	
	private static final String MCC_PJ_FIXO = "08999";
	
	private static final String TP3 = "TP3";
	
	private final String KEY_LISTA_MCCS = "lista.mccs";
	
	@Inject
	private CrdMobileFile loadFile;

	@Inject
	private ServicosOsb service;

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		LOG.debug("INIT INCLUSAO CLIENTE SEC");
		retorno =  new AtivacaoMobile();
		popularInfoValidacao(retorno, AtivacaoEnum.INCLUIR_EC_SEC);
		init(dadosAtivacao, retorno);
		return retorno;
	}

	/**
	 * Método responsavel pela inclusão do cliente no SEC
	 * @param dadosAtivacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		if(validarMccAtivacao(dadosAtivacao, retorno)){
			if(validarTipoTelefone(retorno, dadosAtivacao.getTelefonesEstabelecimento())){
				IncluirRequest request = popularRequest(dadosAtivacao);
				incluirCliente(request, retorno);
			}
		}
	}
	
	/**
	 * Método responsavel por verificar se o telefone celular foi informado
	 * @param retorno 
	 * @param telefonesEstabelecimento
	 * @return boolean
	 */
	private boolean validarTipoTelefone(AtivacaoMobile retorno, List<br.com.cielo.crd.mobile.model.common.TelefoneType> telefonesEstabelecimento) {		
		Boolean isTelefoneValido = Boolean.FALSE;
		for(br.com.cielo.crd.mobile.model.common.TelefoneType telfone : telefonesEstabelecimento){
			if(telfone.getCodigoTipoTelefone().equals(CrdMobileUtils.NUM_TRES)){
				isTelefoneValido = Boolean.TRUE;
				break;
			}
		}
		if(!isTelefoneValido){			
			retorno.setIsEtapaValida(Boolean.FALSE);
			retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
			retorno.setMensagem("TELEFONE CELULAR OBRIGATORIO");
			return Boolean.FALSE;
		}
		return  isTelefoneValido;
	}

	
	/**
	 * Método responsavel pela validação do MCC
	 * @param dadosAtivacao
	 * @param retorno
	 * @return boolean
	 */
	private Boolean validarMccAtivacao(AtivacaoMobileRequest dadosAtivacao,  AtivacaoMobile retorno) {

		if(dadosAtivacao.getTipoPessoa().equals("F")){
			if(!isMccValidoPF(dadosAtivacao.getEstabelecimentoComercial().getCodigoRamoAtividade())){
				retorno.setIsEtapaValida(Boolean.FALSE);
				retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
				retorno.setMensagem("CODIGO MCC INVALIDO");
				return Boolean.FALSE;
			}
		}	
		return Boolean.TRUE;
	}

	/**
	 * Método responsavel pela chamada de inclusão do EC no SEC
	 * @param request
	 */
	private void incluirCliente(IncluirRequest request, AtivacaoMobile retorno) {		
		try {
			CrdMobileUtils.deflate("CADASTRAR EC SEC", request);
			IncluirResponse cliente = service.incluirClienteSec(request);
			consistirInfoCliente(cliente, retorno);
		} catch (Exception e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}
	}
	
	/**
	 * Método responsavel pelo tratamento das informações retornadas do SEC
	 * @param cliente
	 * @param retorno
	 */
	private void consistirInfoCliente(IncluirResponse cliente, AtivacaoMobile retorno) {
		retorno.setIsEtapaValida(Boolean.TRUE);		
		retorno.setNumeroECTemp(cliente.getCodigoCliente());
		retorno.setCorrelationId(cliente.getCorrelationId());
	}

	/**
	 * Método responsavel por popular as informações de Request na Inclusão do Cliente no SEC
	 * @param dadosAtivacao
	 */
	private IncluirRequest popularRequest(AtivacaoMobileRequest dadosAtivacao){
		IncluirRequest request = new IncluirRequest();
		//INFORMACOES DO CLIENTE
		request.setCliente(popularCliente(dadosAtivacao));
		IncluirRequestIndicadorMicroEmpreendedorIndividual mei = IncluirRequestIndicadorMicroEmpreendedorIndividual.
				fromString(dadosAtivacao.getEstabelecimentoComercial().getIndicadorMei()); 
		request.setIndicadorMicroEmpreendedorIndividual(mei);
		//TRATAMENTO SITE "FIXO"
		request.setCodigoBancoCredenciamento(CrdMobileUtils.CODIGO_BANCO_CREDENCIAMENTO);
		request.setCodigoRamoAtividade(dadosAtivacao.getTipoPessoa().equals(CrdMobileUtils.JURIDICA)? MCC_PJ_FIXO: 
									   dadosAtivacao.getEstabelecimentoComercial().getCodigoRamoAtividade().toString());
		request.setNomePessoaContato(tratarPessoaContato(dadosAtivacao.getEstabelecimentoComercial().getNomePessoaContato()));
		String nomePlaqueta = dadosAtivacao.getEstabelecimentoComercial().getNomePlaqueta().toUpperCase();
		request.setNomePlaqueta(nomePlaqueta.length()>22?nomePlaqueta.substring(0,22):nomePlaqueta);
		//INFORMACOES DE ENDERECO
		request.setDadosEnderecoCliente(popularEnderecos(dadosAtivacao.getEnderecoEstabelecimento()));
		//INFORMACOES DE TELEFONE
		request.setDadosTelefoneCliente(popularTelefones(dadosAtivacao.getTelefonesEstabelecimento()));
		//INFORMACOES DE PROPRIETARIOS
		request.setDadosProprietariosCliente(popularProprietarios(dadosAtivacao.getListaProprietarios()));
		//INFORMACOES DE DOMICILIO BANCARIO
		request.setDadosBancariosCliente(popularDadosBancarios(dadosAtivacao.getDomicilioBancario()));
		//INFORMACOES UTILS SEC, CASO O CODIGO SEJA MAIOR QUE 07, PERSISTIMOS APENAS 07 ** SERÁ CORRIGIDO NA RELEASE 01
		request.setRegionalAfiliadora(tratarCodigoAfiliador(dadosAtivacao.getCodigoAfiliador()));
		//request.setRegionalAfiliadora(BigInteger.ZERO);
		//NESSE MOMENTO AINDA NÃO PERSISITIMOS AS INFORMAÇÕES DO EC
		request.setIndicadorPersistencia(IncluirRequestIndicadorPersistencia.N);
		return request;		
	}
	
	/**
	 * Método responsavel por popular as informações do cliente
	 * @param dadosAtivacao
	 * @return Cliente
	 */
	private Cliente popularCliente(AtivacaoMobileRequest dadosAtivacao){
		Cliente cliente = new Cliente();
		String nomeRazaoSocial = dadosAtivacao.getEstabelecimentoComercial().getNomeRazaoSocial().toUpperCase();
		cliente.setNomeRazaoSocial(nomeRazaoSocial.length() > 32 ? nomeRazaoSocial.substring(0, 32):nomeRazaoSocial);
		String nomeFantasia = dadosAtivacao.getEstabelecimentoComercial().getNomeFantasia().toUpperCase();
		cliente.setNomeFantasia(nomeFantasia.length() > 32 ? nomeFantasia.substring(0, 32):nomeFantasia);
		if(dadosAtivacao.getTipoPessoa().equals(CrdMobileUtils.FISICA)){
			cliente.setNumeroCpf(dadosAtivacao.getNumeroCpfCnpj());
			cliente.setNumeroInscricaoEstadual(CrdMobileUtils.NUM_ZERO_STRING);

		}else{		
			cliente.setNumeroCnpj(dadosAtivacao.getNumeroCpfCnpj());
			cliente.setNumeroInscricaoEstadual(dadosAtivacao.getEstabelecimentoComercial().getNumeroInscricaoEstadual().toString());
		}
		return cliente;
	}

	/**
	 * Método responsavel por popular a lista de endereços
	 * @param enderecoEstabelecimento
	 * @return EnderecoType[]
	 */
	private EnderecoType[] popularEnderecos(List<br.com.cielo.crd.mobile.model.common.EnderecoType> enderecoEstabelecimento) {
		List<EnderecoType> enderecos = new ArrayList<>();
		for(br.com.cielo.crd.mobile.model.common.EnderecoType endereco : enderecoEstabelecimento){
			enderecos.add(popularEnderecoType(endereco));
		}
		EnderecoType[] enderecosArray = new EnderecoType[enderecos.size()];
		return enderecos.toArray(enderecosArray);
	}

	/**
	 * Método responsavel por popular as informações de endereço
	 * @param enderecoAtivacao
	 * @return EnderecoType
	 */
    private EnderecoType popularEnderecoType(br.com.cielo.crd.mobile.model.common.EnderecoType enderecoAtivacao) {

        EnderecoType endereco = new EnderecoType();
        endereco.setCodigoTipoEndereco(EnderecoTypeCodigoTipoEndereco
            .fromString(enderecoAtivacao.getCodigoTipoEndereco().toString()));
        
        String logradouro = enderecoAtivacao.getLogradouro().toUpperCase();
        String logradouroCompleto = logradouro.concat(CrdMobileUtils.SEPARADOR_VIRGULA_ESPACO).concat(enderecoAtivacao.getNumeroLogradouro());
        int tamLogradCompleto = logradouroCompleto.length();     
        if(tamLogradCompleto > 32){
        	int truncar = tamLogradCompleto - 32;
        	logradouro = logradouro.substring(0, logradouro.length()-truncar);
        	logradouroCompleto = logradouro.concat(CrdMobileUtils.SEPARADOR_VIRGULA_ESPACO).concat(enderecoAtivacao.getNumeroLogradouro());
        }               
        endereco.setNomeLogradouro(logradouroCompleto); 
        String nomeCidade = enderecoAtivacao.getCidade().toUpperCase();
        endereco.setNomeCidade(nomeCidade.length() > 30?nomeCidade.substring(0,30):nomeCidade);
        endereco.setSiglaEstado(enderecoAtivacao.getSiglaEstado().toUpperCase());
        endereco.setNumeroCEP(enderecoAtivacao.getNumeroCep().toString());
        String complemento = enderecoAtivacao.getComplemento().toUpperCase();
        endereco.setDescricaoComplementoEndereco(complemento.length() > 32 ? complemento.substring(0,32): complemento);
        return endereco;
    }

    /**
     * Método responsavel por popular a lista de telefones
     * @param telefonesEstabelecimento
     * @return TelefoneType[]
     */
	private TelefoneType[] popularTelefones(List<br.com.cielo.crd.mobile.model.common.TelefoneType> telefonesEstabelecimento) {
		List<TelefoneType> telefones = new ArrayList<>();
		Boolean existeTelComercial = isTelComExistente(telefonesEstabelecimento);
		for(br.com.cielo.crd.mobile.model.common.TelefoneType telefone : telefonesEstabelecimento){		
			if(telefone.getCodigoTipoTelefone().equals(CrdMobileUtils.NUM_TRES)){
				telefone.setCodigoTipoTelefone(CrdMobileUtils.NUM_DOIS);
				if(!existeTelComercial){
					telefones.add(popularTelefoneType(createTelefoneComercial(telefone.getNumeroDdd(), telefone.getNumeroTelefone())));
				}
			}
			telefones.add(popularTelefoneType(telefone));
		}
		TelefoneType[] telefonesArray = new TelefoneType[telefones.size()];
		return telefones.toArray(telefonesArray);
	}

	/**
	 * Método responasavel
	 * @param telefonesEstabelecimento
	 * @return
	 */
	private Boolean isTelComExistente(List<br.com.cielo.crd.mobile.model.common.TelefoneType> telefonesEstabelecimento){
		Boolean existeComercial = Boolean.FALSE;
		for(br.com.cielo.crd.mobile.model.common.TelefoneType telfone : telefonesEstabelecimento){
			if(telfone.getCodigoTipoTelefone().equals(CrdMobileUtils.NUM_DOIS)){
				telfone.setCodigoTipoTelefone(CrdMobileUtils.NUM_CINCO);
				existeComercial = Boolean.TRUE;				
			}
			
		}
		return existeComercial;
	}
	
	/**
	 * Caso não exista telefone comercial precisamos criar
	 * @param ddd
	 * @param numTelefone
	 * @return br.com.cielo.crd.mobile.model.common.TelefoneType
	 */
	private br.com.cielo.crd.mobile.model.common.TelefoneType createTelefoneComercial(Integer ddd, String numTelefone){
		br.com.cielo.crd.mobile.model.common.TelefoneType comercial = new br.com.cielo.crd.mobile.model.common.TelefoneType();
		comercial.setCodigoTipoTelefone(CrdMobileUtils.NUM_CINCO);
		comercial.setNumeroDdd(ddd);
		comercial.setNumeroTelefone(numTelefone);
		return comercial;
	}
	
	
	/**
	 * Método responsavel por popular as informações de telefone
	 * @param telefone
	 * @return TelefoneType
	 */
	private TelefoneType popularTelefoneType(br.com.cielo.crd.mobile.model.common.TelefoneType telefone) {
		TelefoneType tel = new TelefoneType();
		tel.setCodigoTipoTelefone(TelefoneTypeCodigoTipoTelefone.fromString(telefone.getCodigoTipoTelefone().toString()));
		tel.setNumeroDDD(telefone.getNumeroDdd().toString());
		tel.setNumeroTelefone(telefone.getNumeroTelefone().toString());
		return tel;
	}

	/**
	 * Método responsavel por popular as informações do proprietarios
	 * @param listaProprietarios
	 * @return DadosProprietarioType[]
	 */
	private DadosProprietarioType[] popularProprietarios(List<br.com.cielo.crd.mobile.model.common.DadosProprietarioType> listaProprietarios) {
		List<DadosProprietarioType> proprietarios = new ArrayList<>();
		for(br.com.cielo.crd.mobile.model.common.DadosProprietarioType proprietario : listaProprietarios){
			proprietarios.add(popularProprietarioType(proprietario));
		}
		DadosProprietarioType[] proprietariosArray = new DadosProprietarioType[proprietarios.size()];
		return proprietarios.toArray(proprietariosArray);
	}

	/**
	 * Método responsavel por popular as informações do proprietário
	 * @param proprietario
	 * @return DadosProprietarioType
	 */
	private DadosProprietarioType popularProprietarioType(br.com.cielo.crd.mobile.model.common.DadosProprietarioType proprietario) {
		DadosProprietarioType prop = new DadosProprietarioType();
		prop.setDataNascimento(proprietario.getDataNascimento());
		String nomeProprietario = proprietario.getNome().toUpperCase();
		prop.setNome(nomeProprietario.length() > 32 ? nomeProprietario.substring(0,32):nomeProprietario);
		prop.setNumeroCpf(proprietario.getNumeroCpf());
		return prop;
	}

	/**
	 * Método responsavel por popular as informações de domicilio bancário
	 * @param domicilioBancario
	 * @return BancoType
	 */
	private BancoType popularDadosBancarios(DomicilioBancarioType domicilioBancario) {
		BancoType bancoType = new BancoType();
		bancoType.setCodigoBanco(domicilioBancario.getCodigoBanco());
		bancoType.setNumeroAgencia(domicilioBancario.getNumeroAgencia());
		bancoType.setNumeroConta(domicilioBancario.getNumeroConta());
		bancoType.setTipoConta(domicilioBancario.getTipoConta());
		return bancoType;
	}
	
	/**
	 * Método responsavel por validar se o MCC para ativação é valido
	 * @param codMcc
	 * @return Boolean
	 * @FIXME MCCS FIXOS ALINHADO COM A AREA DE NEGOICO
	 */
	private Boolean isMccValidoPF(Integer codMcc){
		Integer [] listaMccValido = carregarListaMcc();
		boolean isMaccValido = false;
		for(int i=0; i< listaMccValido.length; i++){
			if(listaMccValido[i].equals(codMcc)){
				isMaccValido = true;
				break;
			}
		}
		return isMaccValido;
	}
	
	/**
	 * Método responsavel por carregar a lista de MCCs
	 * @return Integer[]
	 */
	private Integer[] carregarListaMcc(){
		String mccs = loadFile.getMessage(KEY_LISTA_MCCS);		
		String [] lista = mccs.split(CrdMobileUtils.SEPARADOR_VIRGULA);
		Integer[] listaMccs = new Integer[lista.length];
		for(int i=0;i<lista.length;i++){
			listaMccs[i] = Integer.valueOf(lista[i]);
		}
		return listaMccs;
	}

	/**
	 * Método responsavel por tratar o campo pessoa contato precisa ter no máximo 32 caracteres e possuir a informação de TP3
	 * @param pessoaContato
	 * @return String
	 */
	private String tratarPessoaContato(String pessoaContato){
		String contatoTratado = pessoaContato.length() > 29 ? pessoaContato.substring(0, 29): pessoaContato;
		return contatoTratado.toUpperCase().concat(TP3);
	}
	
	/**
	 * Método responsavel por tratar a informação de código afiliador, devido a uma restrição do book, precisa possuir no máximo 07 caracteres
	 * @param codigoAfiliador
	 * @return String
	 */
	private BigInteger tratarCodigoAfiliador(Integer codigoAfiliador){	
		String codigo = codigoAfiliador.toString();
		codigo =  (codigo.length() > 7 ? codigo.substring(0,7): codigo);	
		return BigInteger.valueOf(Long.valueOf(codigo));
	}

	/*  ##  MCC - DESCRICAO	 
			0742	Veterinário
			4121	Taxi / Limousines
			5691	Roupas Masculinas e Femininas
			5697	Alfaiates / Costureiras (os)
			5963	Vendas a Domicílio
			5977	Cosméticos
			6211	Corretor de Seguros
			7211	Babá
			7230	Salão de Beleza / Barbearia
			7277	Advogados
			7298	Clínicas de Beleza - SPA
			8011	Médicos / Clínicas
			8021	Dentistas / Ortodontistas - Clínicas
			8299	Serviços  Educacionais - Não Classificados
			8911	Arquitetura e Engenharia
			8999	Profissionais Não Relacionados
			8999	Profissionais Não Relacionados
  */
}
	