package br.com.cielo.crd.mobile.ativacao.impl.ativar;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.ativacao.ValidacaoService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.qualifier.ValidacaoMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileFile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequest;
import br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequestIndicadorPersistencia;
import br.com.cielo.service.cadastro.servico.servico.v1.ServicoType;

@AtivarMobile(etapa=AtivacaoEnum.HABILITAR_SERVICOS)
public class HabilitacaoServicos extends AtivacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(HabilitacaoServicos.class);
	
	private final String KEY_LISTA_SERVICOS = "lista.servicos";
	
	@Inject
	private ServicosOsb service;

	@Inject
	private CrdMobileFile loadFile;
	
	@Inject @ValidacaoMobile(etapa=ValidacaoEnum.VERIFICAR_EXISTENCIA_CLIENTE)
	private ValidacaoService verificarExistenciaCliente;


	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		LOG.debug("INIT HABILITAR SERVICOS SEC");
		popularInfoValidacao(retorno, AtivacaoEnum.HABILITAR_SERVICOS);
		init(dadosAtivacao, retorno);
		return retorno;
	}

	/**
	 * Método init para Habilitação de serviços no SEC
	 * 
	 * @param dadosAtivacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		HabilitarListaServicoRequest request = popularRequest(dadosAtivacao, retorno);
		
		try{
			//SERVIÇO DE HABILITAÇÃO DE SERVIÇOS NO SEC
			habilitarServicos(request, retorno);
			
		}catch(Exception ex){	
			
			tratarFault(ex, retorno);
			retorno.setIsEtapaValida(Boolean.FALSE);				
			//HOUVE EXCEÇÃO POR TIMEOUT NA HABILITAÇÃO DE SERVICO
			if(isTimeoutException(retorno.getMensagem())){	
				
				try {
					Thread.sleep(2000);
					//VERIFICAMOS SE O CLIENTE FOI CADASTRADO 
					AtivacaoMobile clienteExiste = verificarExistenciaCliente.validar(dadosAtivacao);	
					
					if(!clienteExiste.getIsEtapaValida()){
						String mensagem = clienteExiste.getMensagem();
						//SE O CLIENTE JA EXISTE, SIGNIFICA QUE RECEBEMOS TIMEOUT MAS O SEC PROSSEGUIU COM O CADASTRO, ASSIM PROSSEGUIMOS O FLUXO PARA INCLUSÃO EM REDES
						if(null != mensagem && mensagem.equals("CLIENTE EXISTENTE NO SEC"))
							retorno.setIsEtapaValida(Boolean.TRUE);
					}
				} catch (InterruptedException e) {
					LOG.error("ERRO NA CONSULTA DE CLIENTE, QDO TIMEOUT NA HABILITACAO DE SERVICOS {}", e);
				}
			}
		}
	}

	/**
	 * Método responsavel pela habilitação de produtos
	 * @param request
	 * @param retorno
	 * @throws ServiceException 
	 * @throws RemoteException 
	 * @throws MalformedURLException 
	 * @throws Fault 
	 */
	private void habilitarServicos(HabilitarListaServicoRequest request, AtivacaoMobile retorno) 
				throws Fault, MalformedURLException, RemoteException, ServiceException {
		
		CrdMobileUtils.deflate("HABILITAR SERVICOS SEC", request);
		service.habilitarServicos(request);
		persistirInfoRetorno(retorno);	
	}

	/**
	 * Método responsavel por verificar se houve exceção por time out no SEC
	 * 
	 * @param mensagem
	 * @return
	 */
	private boolean isTimeoutException(String mensagem) {
		return (mensagem.contains("Read timed out"));
	}
	

	private void persistirInfoRetorno(AtivacaoMobile retorno) {
		retorno.setIsEtapaValida(Boolean.TRUE);	
		retorno.setNumeroEC(retorno.getNumeroECTemp());
	}

	/**
	 * Método responsavel por popular a request
	 * @param dadosAtivacao
	 * @return HabilitarListaProdutoRequest
	 */
	private HabilitarListaServicoRequest popularRequest(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		HabilitarListaServicoRequest request = new HabilitarListaServicoRequest();
		request.setCodigoCliente(retorno.getNumeroECTemp());
		request.setCorrelationId(retorno.getCorrelationId());
		//NESSE MOMENTO PERSISITIMOS AS INFORMAÇÕES DO EC
		request.setIndicadorPersistencia(HabilitarListaServicoRequestIndicadorPersistencia.S);
		request.setDadosServicoClienteHabilitacao(popularServicos());
		return request;
	}

	/**
	 * Método responsavel por popular a lista de serviços
	 * @return ServicoType[]
	 */
	private ServicoType[] popularServicos() {
		List<ServicoType> servicos = new ArrayList<>();	
		List<String> listaServicos = popularListServicos();	
		for(String serv : listaServicos){
			ServicoType servico = new ServicoType();
			servico.setCodigoServico(BigInteger.valueOf(Long.valueOf(serv)));
			servicos.add(servico);
		}
		ServicoType[] servicoArray = new ServicoType[servicos.size()];
		return servicos.toArray(servicoArray);
	}

	/**
	 * Método responsavel por devolver a lista de serviços
	 * @return List<String> lista de servicos
	 * FIXME ALINHADO COM A ARAEA DE NEGOCIO QUE PASSARIAMOS FIXO
	 */
	private List<String> popularListServicos(){	
		List<String> listaServicos = new ArrayList<>();		
		String servicos = loadFile.getMessage(KEY_LISTA_SERVICOS);		
		String [] lista = servicos.split(CrdMobileUtils.SEPARADOR_VIRGULA);
		for(int i=0;i<lista.length;i++){
			listaServicos.add(lista[i]);
		}
		return listaServicos;
	}
	

}
