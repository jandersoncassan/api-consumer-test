package br.com.cielo.crd.mobile.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.ejb.Singleton;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Classe responsavel ´por fazer o carregamento do arquivo de propriedades da ativação mobile
 * 
 * @author @Cielo
 */
@Singleton
public class CrdMobileFile {

    private static final Logger LOG = LoggerFactory.getLogger(CrdMobileFile.class);

    private static final String ARQUIVO = "message.properties";

    private Properties properties;

    private Properties config;

    @PostConstruct
    public void init() {

        LOG.debug("CARREGAR ARQUIVO PROPRIEDADE - ATIVACAO MOBILE []", ARQUIVO);
        config = new Properties();
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(ARQUIVO);

        try {
            this.config.load(inputStream);
        } catch (IOException e) {
            LOG.debug("ERRO : Carregar arquivo properties [][]", ARQUIVO, e);
        }
        // CARREGAMOS O ARQUIVO DE PROPRIEDADES DA ATIVACAO MOBILE
        carregarProperties();
    }

    /**
     * Método responsavel por carregar o arquivo de configurações no diretório do CRD
     */
    private void carregarProperties() {

        Path arquivo = Paths
            .get(String.format("%s%s%s", config.getProperty("path"), File.separator, config.get("arquivo")));
        properties = new Properties();
        try {
            properties.load(new FileInputStream(arquivo.toFile()));
        } catch (IOException e) {
            LOG.debug("ERRO : Carregar arquivo properties [][]", arquivo.toFile(), e);
        }
    }

    /**
     * Método responsavel por obter as propriedades do arquivo
     * 
     * @param key
     * @return String
     */
    public String getMessage(String key) {

        return (properties.getProperty(key));
    }

}
