package br.com.cielo.crd.mobile.model;

import br.com.cielo.crd.mobile.enums.EtapasAtivacaoMobileEnum;

/**
 * Classe responsavel por retorno o status da execução da consistencia nas fases de ativaçao mobile
 * @author @Cielo
 */
public class AtivacaoMobile {

	private String origem;
	
	private EtapasAtivacaoMobileEnum etapaAtivacao;
	
	private String servico;
	
	private Boolean isEtapaValida;

	private Long numeroEC;
	
	private Integer numeroLogico;
	
	private Integer digNumLogico;
	
	private String codigoMensagem;
	
	private String mensagem;
	
	private String tipoCritica;
	
	private boolean isAvisoGtec;

	//TRATAMENTO PARA INCLUSÃO DO EC, SOMENTE É PERSISTIDO APÓS HAB DE PROD E SERVIÇOS
	//APÓS ISSO O EC É PERSISTIDO
	private Long numeroECTemp;
	private String correlationId;
	/**
	 * @return the etapaAtivacao
	 */
	public EtapasAtivacaoMobileEnum getEtapaAtivacao() {
		return etapaAtivacao;
	}

	/**
	 * @param etapaAtivacao the etapaAtivacao to set
	 */
	public void setEtapaAtivacao(EtapasAtivacaoMobileEnum etapaAtivacao) {
		this.etapaAtivacao = etapaAtivacao;
	}

	/**
	 * @return the isEtapaValida
	 */
	public Boolean getIsEtapaValida() {
		return isEtapaValida;
	}

	/**
	 * @param isEtapaValida the isEtapaValida to set
	 */
	public void setIsEtapaValida(Boolean isEtapaValida) {
		this.isEtapaValida = isEtapaValida;
	}

	/**
	 * @return the mensagem
	 */
	public String getMensagem() {
		return mensagem;
	}

	/**
	 * @param mensagem the mensagem to set
	 */
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	/**
	 * @return the origem
	 */
	public String getOrigem() {
		return origem;
	}

	/**
	 * @param origem the origem to set
	 */
	public void setOrigem(String origem) {
		this.origem = origem;
	}

	/**
	 * @return the servico
	 */
	public String getServico() {
		return servico;
	}

	/**
	 * @param servico the servico to set
	 */
	public void setServico(String servico) {
		this.servico = servico;
	}

	/**
	 * @return the numeroEC
	 */
	public Long getNumeroEC() {
		return numeroEC;
	}

	/**
	 * @param numeroEC the numeroEC to set
	 */
	public void setNumeroEC(Long numeroEC) {
		this.numeroEC = numeroEC;
	}

	/**
	 * @return the numeroLogico
	 */
	public Integer getNumeroLogico() {
		return numeroLogico;
	}

	/**
	 * @param numeroLogico the numeroLogico to set
	 */
	public void setNumeroLogico(Integer numeroLogico) {
		this.numeroLogico = numeroLogico;
	}

	
	/**
	 * @return the digNumLogico
	 */
	public Integer getDigNumLogico() {
		return digNumLogico;
	}

	/**
	 * @param digNumLogico the digNumLogico to set
	 */
	public void setDigNumLogico(Integer digNumLogico) {
		this.digNumLogico = digNumLogico;
	}

	/**
	 * @return the tipoCritica
	 */
	public String getTipoCritica() {
		return tipoCritica;
	}

	/**
	 * @param tipoCritica the tipoCritica to set
	 */
	public void setTipoCritica(String tipoCritica) {
		this.tipoCritica = tipoCritica;
	}

	/**
	 * @return the isAvisoGtec
	 */
	public Boolean getIsAvisoGtec() {
		return isAvisoGtec;
	}

	/**
	 * @param isAvisoGtec the isAvisoGtec to set
	 */
	public void setIsAvisoGtec(Boolean isAvisoGtec) {
		this.isAvisoGtec = isAvisoGtec;
	}

	/**
	 * @return the codigoMensagem
	 */
	public String getCodigoMensagem() {
		return codigoMensagem;
	}

	/**
	 * @param codigoMensagem the codigoMensagem to set
	 */
	public void setCodigoMensagem(String codigoMensagem) {
		this.codigoMensagem = codigoMensagem;
	}

	/**
	 * @return the numeroECTemp
	 */
	public Long getNumeroECTemp() {
		return numeroECTemp;
	}

	/**
	 * @param numeroECTemp the numeroECTemp to set
	 */
	public void setNumeroECTemp(Long numeroECTemp) {
		this.numeroECTemp = numeroECTemp;
	}

	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * @param correlationId the correlationId to set
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
	
	
	
}
