package br.com.cielo.crd.mobile.service.impl;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.nio.file.DirectoryStream;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.zip.GZIPInputStream;

import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.enums.StatusAtivacaoEnum;
import br.com.cielo.crd.mobile.model.MobileReport;
import br.com.cielo.crd.mobile.service.MobileReportService;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileFile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

public class MobileReportServiceImpl implements MobileReportService {

    private static final Logger logger = LoggerFactory.getLogger(MobileReportServiceImpl.class);

    private static final String LOG_HOME = "/CRD/log/ativacao";
    
    private static final String LOG_HOME_BKP = "/CRD/log/ativacao/BKP/";
    
    private static final String LOG_NAME = "^(ativacao-mobile_)+(.)*(.gz)$";

    private static final String CAMINHO_ARQUIVO = LOG_HOME + "/ativacao-mobile-consolidado.log";

    private static final String EMAIL_CRD = "email.crd";

    private static final String KEY_LISTA_EMAIL_CONSOLIDADO = "lista.email.consolidado";
    
    private static final String KEY_LISTA_EMAIL_PARCIAL = "lista.email.parcial";

    private static final String KEY_LISTA_EMAIL_INSUCESSO = "lista.email.insucesso";

    @Inject
    private ServicosOsb service;

    @Inject
    private CrdMobileFile loadFile;

    @Override
    public void gerarReportMobile() {
        try {
            consolidarLogs();
            popularRelatorio();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    /**
     * Consolida os logs dos nos do WebLogic num unico arquivo de log.
     */
    private void consolidarLogs() {
        try {
            Path arquivo = preparaArquivoConsolidado();
            List<String> nomeArquivos = listaArquivosLog(LOG_HOME);
            for (String nome : nomeArquivos) {
                gravaArquivoConsolidado(arquivo, nome);
            }
            //APOS GERAR O CONSOLIDADO PRECISAMOS MOVER OS ARQUIVOS PARA A PASTA BKP
        	 moverFilesBKP(nomeArquivos);
        } catch (Exception e) {
            logger.debug("ERRO CONSOLIDADNDO ARQUIVOS DE LOG", e);
        }
    }

    /**
     * Grava (append) no arquivo consolidado.
     * 
     * @param arquivo
     *            arquivo consolidado
     * @param origem
     *            arquivo a ser lido
     * 
     * @throws IOException
     *             no caso de erro
     */
    private void gravaArquivoConsolidado(final Path arquivo, final String origem) throws IOException {

        BufferedWriter writer = null;
        BufferedReader reader = null;

        try {
            writer = Files.newBufferedWriter(arquivo, StandardCharsets.UTF_8, StandardOpenOption.APPEND);
            reader = getBufferedReader(origem);

            String linha;
            while ((linha = reader.readLine()) != null) {
                writer.write(linha);
                writer.newLine();
            }
            
        } finally {
            try {
                if (writer != null)
                    writer.close();
            } catch (IOException e) {
            }
            try {
                if (reader != null)
                    reader.close();
            } catch (IOException e) {
            	System.err.println(e);
            }
            
        }
    }

    /**
     * Método responsavel por mover os arquivos para a pasta BKP
     * @param caminhoFile
     */
    private void moverFilesBKP( List<String> nomeArquivos){
    	try {
    		/*APOS CONSOLIDADO MOVEMOS PARA A PASTA BKP*/
    		if(!nomeArquivos.isEmpty()){
	    		for (String caminhoFile : nomeArquivos) {
	    			String nomeFile = caminhoFile.substring(CrdMobileUtils.NUM_DEZOITO);
	    			Path fileOrigem = FileSystems.getDefault().getPath(caminhoFile);
	    			Path fileDestino = FileSystems.getDefault().getPath(LOG_HOME_BKP.concat(nomeFile));
	    			Files.move(fileOrigem, fileDestino, StandardCopyOption.REPLACE_EXISTING);
				}
    		}
		} catch (IOException ex) {
			System.err.println("OCORREU UM ERRO AO MOVER O ARQUIVO PARA O BKP : "+ ex);
		}    	
    }
    
    /**
     * Método responsavel pelo tratamentos dos arquivos de log
     * @param origem
     * @return BufferedReader
     * @throws IOException
     */
    private BufferedReader getBufferedReader(String origem) throws IOException{
    	//if(origem.matches(LOG_NAME_END)){        	
		FileInputStream  file = new FileInputStream (origem);
    	GZIPInputStream gzis = new GZIPInputStream(file);
    	InputStreamReader inputReader = new InputStreamReader(gzis);
    	return(new BufferedReader(inputReader));
       // } TRAMANETO ARQUIVO <> .GZ
       //return Files.newBufferedReader(Paths.get(origem), StandardCharsets.UTF_8);
    }
    
    /**
     * Prepara arquivo consolidado; cria se nao existir e esvazia-o caso ja exista.
     * 
     * @return arquivo consolidado vazio pronto para ser gravado
     * 
     * @throws IOException
     *             no caso de erro
     */
    private Path preparaArquivoConsolidado() throws IOException {

        Path arquivo = Paths.get(CAMINHO_ARQUIVO);

        Files.deleteIfExists(arquivo);
        arquivo = Files.createFile(arquivo);

        return arquivo;
    }

    /**
     * Lista arquivos de log a serem consolidados.
     * 
     * @param caminho
     *            local onde estao os arquivos de log
     * 
     * @return lista de nome de arquivos
     * 
     * @throws IOException
     *             no caso de erro
     */
    public List<String> listaArquivosLog(final String caminho) throws IOException {

        final List<String> nomes = new ArrayList<>();
        DirectoryStream<Path> directoryStream = Files.newDirectoryStream(Paths.get(caminho));
        
        for (Path path : directoryStream) {
            String nome = path.getFileName().toString();
            if (nome.matches(LOG_NAME)) {
                nomes.add(path.toString()); // Grava caminho completo do arquivo
            }
        }
        directoryStream.close();
        return nomes;
    }

    /**
     * Método responsavel por obter as informações para popular o relatório
     */
    private void popularRelatorio() {

        List<MobileReport> listaInformacoes = obterInformacoes();
        Integer completo = CrdMobileUtils.NUM_ZERO;
        Integer parcial = CrdMobileUtils.NUM_ZERO;
        Integer rejeitado = CrdMobileUtils.NUM_ZERO;
        for (MobileReport report : listaInformacoes) {
            if (report.getStatus().equals("S")) {
                completo++;
            } else if (report.getStatus().equals("P")) {
                parcial++;
            } else {
                rejeitado++;
            }
        }
        // EMAIL CONSOLIDADO
        String emailConsolidado = montarHtmlConsolidado(listaInformacoes, completo, parcial, rejeitado);
        enviarEmail(getEmailContatos(KEY_LISTA_EMAIL_CONSOLIDADO), emailConsolidado, CrdMobileUtils.TITULO_CONSOLIDADO.concat(" - ").concat(CrdMobileUtils.getDataDiaAnterior()));
        // EMAIL PARCIAL
        String emailParcial = montarHtmlParcial(listaInformacoes, parcial);
        enviarEmail(getEmailContatos(KEY_LISTA_EMAIL_PARCIAL), emailParcial, CrdMobileUtils.TITULO_PARCIAL.concat(" - ").concat(CrdMobileUtils.getDataDiaAnterior()));
        // EMAIL INSUCESSO
        String emailInsucesso = montarHtmlInsucesso(listaInformacoes, rejeitado);
        enviarEmail(getEmailContatos(KEY_LISTA_EMAIL_INSUCESSO), emailInsucesso, CrdMobileUtils.TITULO_INSUCESSO.concat(" - ").concat(CrdMobileUtils.getDataDiaAnterior()));
    }

    /**
     * Método responsavel pelo envio de email
     * 
     * @param emailCrd
     * @param emailContatos
     * @param conteudoEmail
     */
    private void enviarEmail(String[] emailContatos, String conteudoEmail, String titulo) {

        String emailCrd = getEmailCrd(EMAIL_CRD);
        try {
            service.enviarEmail(emailCrd, emailContatos, conteudoEmail, titulo);
        } catch (RemoteException | MalformedURLException | ServiceException e) {
            logger.debug("ERRO AO ENVIAR EMAIL PROCESSAMENTO ATIVACAO MOBILE");
        }
    }

    /**
     * Método responsavel por obter as informações para popular o relatório de processamento
     * 
     * @return List<MobileReport>
     */
    private List<MobileReport> obterInformacoes() {

        List<MobileReport> listaReport = new ArrayList<>();
        List<String> listaMensagem = lerArquivo();
        for (String mensagem : listaMensagem) {
            String[] msg = mensagem.split("\\|");
            String hora = msg[0].split(" ")[1];
            if(isMonitoracao(mensagem))
            	continue;
            listaReport.add(tratarMensagem(msg[1], hora));
        }
        return listaReport;
    }
    
    /**
     * Método responsavel por verificar se o registro foi gerado pela monitoração da API
     * @param mensagem
     * @return boolean
     */
    private boolean isMonitoracao(String mensagem){
    	return mensagem.split(";")[1].split(":")[1].equals("99");
    }

     /**
     * Método responsavel por carregar as informações do arquivo de log
     * 
     * @return
     */
    private List<String> lerArquivo() {

        List<String> informacoes = new ArrayList<>();
        try {
            Scanner in = new Scanner(new FileReader(CAMINHO_ARQUIVO));
            while (in.hasNextLine()) {
                String line = in.nextLine();
                informacoes.add(line);
            }
            in.close();
        } catch (Exception e) {
            System.err.println("OCORREU UM ERRO NA LEITURA DO ARQUIVO DE LOG : []"+ CAMINHO_ARQUIVO + e);
        }
        return informacoes;
    }

    /**
     * Método responsavel por formatar a mensagem
     * 
     * @param mensagem
     * @param hora
     * @return MobileReport
     */
    private MobileReport tratarMensagem(String mensagem, String hora) {

        MobileReport report = new MobileReport();
        String[] info = mensagem.split(";");
        int qtd = info.length;

        try {
        	report.setStatus(info[0].split(":")[1]);
            report.setFerramenta(info[1].split(":")[1]);
            report.setCpfCnpj(info[2].split(":")[1]);
            report.setData(info[3].split(":")[1]);
            report.setHora(hora);
            report.setEtapa(info[4].split(":")[1]);
            report.setNumeroEc(info[5].split(":")[1]);
            report.setNumeroLogico(info[6].split(":")[1]);
            report.setNotificacaoGtec(info[7].split(":")[1]);
            report.setCritica(info[8].split(":")[1]);
            report.setProblema(info[9].split(":")[1]);
            // report.setDddTelefone(info[9].split(":")[1]);
            report.setDddTelefone(info[qtd - 3].split(":")[1]);
            // report.setHoraInicial(info[10].split("-")[1]);
            report.setHoraInicial(info[qtd - 2].split("-")[1]);
            // report.setHoraFinal(info[11].split("-")[1]);
            report.setHoraFinal(info[qtd - 1].split("-")[1]);
        } catch (Exception e) {
        	 System.err.println("OCORREU UM ERRO AO EFETUAR O MATCH DAS INFORMACOES DO LOG" + e);
        }

        return report;
    }

    /**
     * Método responsavel por obter o email do CRD "DE"
     * 
     * @param keyMessage
     * @return String
     */
    private String getEmailCrd(String keyMessage) {

        return loadFile.getMessage(keyMessage);
    }

    /**
     * Método responsavel por obter a lista de emails para contato "PARA"
     * 
     * @param keyMessage
     * @return String[]
     */
    private String[] getEmailContatos(String keyMessage) {

        return (loadFile.getMessage(keyMessage).split(CrdMobileUtils.SEPARADOR_VIRGULA));
    }

    /**
     * Método responsavel por montar o conteúdo do email
     * 
     * @param listaInformacoes
     * @return String
     */
    private String montarHtmlConsolidado(List<MobileReport> listaInformacoes, Integer totalCompleto,
        Integer totalParcial, Integer totalRejeitado) {

        Integer totalGeral = getTotal(totalCompleto, totalParcial, totalRejeitado);
        StringBuilder builderHtml = new StringBuilder();
        htmlHead(builderHtml);
        if (!listaInformacoes.isEmpty()) {
            builderHtml.append("<div style='padding-left:50'>");
            builderHtml.append(
                "<div><b>"+CrdMobileUtils.TOTAL+": <u style='background-color:yellow'> " + totalGeral + "</u></b></div>");
            builderHtml.append("</div>");
            htmlTabelaResumo(builderHtml, totalCompleto, totalParcial, totalRejeitado);
            if(totalCompleto > CrdMobileUtils.NUM_ZERO){
            	builderHtml.append("<div><b>"+CrdMobileUtils.TOTAL+" (Completos) : <u style='background-color:yellow'> " + totalCompleto
            			+ "</u></b></div>");
            	htmlListaCorpoSucesso(builderHtml, listaInformacoes);
            }else{
            	htmlSemProcessMobile(builderHtml, CrdMobileUtils.SEM_PROCESSAMENTO_MOBILE_SUCESSO);
            }            
         } else {
            htmlSemProcessamento(builderHtml);
        }
        htmlFinal(builderHtml);
        return builderHtml.toString();
    }

    /**
     * Método responsavel por montar o conteúdo do email
     * 
     * @param listaInformacoes
     * @return String
     */
    private String montarHtmlParcial(List<MobileReport> listaInformacoes, Integer totalParcial) {

        StringBuilder builderHtml = new StringBuilder();
        htmlHead(builderHtml);
        if (!listaInformacoes.isEmpty()) {
            builderHtml.append("<div style='padding-left:50'>");
            builderHtml.append("<div><b>"+CrdMobileUtils.TOTAL+"(Parcial) : <u style='background-color:yellow'> " + totalParcial
                + "</u></b></div>");
            builderHtml.append("</div>");
            if (totalParcial > CrdMobileUtils.NUM_ZERO) {
            	 htmlListaCorpo(builderHtml, listaInformacoes, StatusAtivacaoEnum.PARCIAL);
            } else {
                htmlSemProcessMobile(builderHtml, CrdMobileUtils.SEM_PROCESSAMENTO_MOBILE_PARCIAL);
            }
        } else {
            htmlSemProcessamento(builderHtml);
        }
        htmlFinal(builderHtml);
        return builderHtml.toString();
    }

    /**
     * Método responsavel por montar o conteúdo do email
     * 
     * @param listaInformacoes
     * @return String
     */
    private String montarHtmlInsucesso(List<MobileReport> listaInformacoes, Integer totalInsucesso) {

        StringBuilder builderHtml = new StringBuilder();
        htmlHead(builderHtml);
        if (!listaInformacoes.isEmpty()) {
            builderHtml.append("<div style='padding-left:50'>");
            builderHtml.append("<div><b>"+CrdMobileUtils.TOTAL+" (Rejeitados) : <u style='background-color:yellow'> " + totalInsucesso
                + "</u></b></div>");
            builderHtml.append("</div>");
            if (totalInsucesso > CrdMobileUtils.NUM_ZERO) {
            	htmlListaCorpo(builderHtml, listaInformacoes, StatusAtivacaoEnum.INSUCESSO);
            } else {
                htmlSemProcessMobile(builderHtml, CrdMobileUtils.SEM_PROCESSAMENTO_MOBILE_INSUCESSO);
            }
        } else {
            htmlSemProcessamento(builderHtml);
        }
        htmlFinal(builderHtml);
        return builderHtml.toString();
    }

    /**
     * Método responsavel por montar o HEAD do relatório
     * 
     * @param builderHtml
     */
    private void htmlHead(StringBuilder builderHtml) {

        builderHtml.append("<html>");
        builderHtml.append("<body>");
        builderHtml.append(
            "<center><label><h1><b>CRD- Credenciamento</b></h1></label>	<label><h3>Ativação Mobile<h3></label></center>");
        builderHtml.append("<div style='padding-left:50'>");
        builderHtml.append(
            "<p><b>"+CrdMobileUtils.DATA+"<font style='background-color:yellow'>" + CrdMobileUtils.getDataDiaAnterior() + "</font></b></p>");
        builderHtml.append("</div>");
    }

    /**
     * Método responsavel por montar a tabela resumo do consolidado
     * 
     * @param builderHtml
     * @param totalCompleto
     * @param totalParcial
     * @param totalRejeitado
     */
    private void htmlTabelaResumo(StringBuilder builderHtml, Integer totalCompleto, Integer totalParcial,
        Integer totalRejeitado) {

        builderHtml.append("<div style='padding-top:15'>");
        builderHtml.append("<table border='1'>");
        builderHtml.append("<thead>");
        builderHtml.append("<tr style='background-color:LightSkyBlue' align='center'>");
        builderHtml.append("<td style='width:150'><b>Status</b></td>");
        builderHtml.append("<td style='width:90'><b>Quantidade</b></td>");
        builderHtml.append("</tr>");
        builderHtml.append("</thead>");
        builderHtml.append("<tbody>");
        builderHtml.append("<tr>");
        builderHtml.append("<td style='background-color:Azure'><b>Completo</b></td>");
        builderHtml.append("<td align='center'>" + totalCompleto + "</td>");
        builderHtml.append("</tr>");
        builderHtml.append("<tr>");
        builderHtml.append("<td style='background-color:Azure'><b>Parcial</b></td>");
        builderHtml.append("<td align='center'>" + totalParcial + "</td>");
        builderHtml.append("</tr>");
        builderHtml.append("<tr>");
        builderHtml.append("<td style='background-color:Azure'><b>Rejeitado</b></td>");
        builderHtml.append("<td align='center'>" + totalRejeitado + "</td>");
        builderHtml.append("</tr>");
        builderHtml.append("</tbody>");
        builderHtml.append("</table>");
        builderHtml.append("</div>");
    }

    /**
     * 
     * @param builderHtml
     * @param listaInformacoes
     */
    private void htmlListaCorpo(StringBuilder builderHtml, List<MobileReport> listaInformacoes, StatusAtivacaoEnum status) {

        builderHtml.append("<div style='padding-top:100; padding-left:50'>");
        builderHtml.append("<table border='1'>");
        builderHtml.append("<thead>");
        builderHtml.append("<tr style='background-color:LightSkyBlue' align='center'>");
	        builderHtml.append("<td style='width:80;font-bold'><b>Ferramenta</b></td>");
	        builderHtml.append("<td style='width:130'><b>CPF/CNPJ</b></td>");
	        builderHtml.append("<td style='width:130'><b>Hora Movimento</b></td>");
	        builderHtml.append("<td style='width:200'><b>Etapa Proposta</b></td>");
	        builderHtml.append("<td style='width:90'><b>Número EC</b></td>");
	        builderHtml.append("<td style='width:120'><b>Número Lógico</b></td>");
	        builderHtml.append("<td style='width:150'><b>GTEC Notificado?</b></td>");
	        builderHtml.append("<td style='width:280'><b>Problema</b></td>");
	        builderHtml.append("<td style='width:280'><b>Critica</b></td>");
	    builderHtml.append("</tr>");
        builderHtml.append("</thead>");
        builderHtml.append("<tbody>");
        for (MobileReport informacao : listaInformacoes) {
            if (informacao.getStatus().equals(Character.toString(status.getFlag()))) {
                builderHtml.append("<tr align='center'>");
                builderHtml.append("<td>" + informacao.getFerramenta() + "</td>");
                builderHtml.append("<td>" + CrdMobileUtils.formatarCpfCnpj(informacao.getCpfCnpj()) + "</td>");
                builderHtml.append("<td>" + informacao.getHora() + "</td>");
                builderHtml.append("<td>" + informacao.getEtapa() + "</td>");
                builderHtml.append("<td>" + tratarNull(informacao.getNumeroEc()) + "</td>");
                builderHtml.append("<td>" + tratarNull(informacao.getNumeroLogico()) + "</td>");
                builderHtml.append("<td>" + informacao.getNotificacaoGtec() + "</td>");
                builderHtml.append("<td>" + tratarNull(informacao.getProblema()) + "</td>");
                builderHtml.append("<td>" + tratarNull(informacao.getCritica()) + "</td>");
                builderHtml.append("</tr>");
            }
        }
        builderHtml.append("</tbody>");
        builderHtml.append("</table>");
        builderHtml.append("</div>");
    }

    /**
     * Caso haja rejeições (parcial ou insucesso) montamos a grid com os problemas
     */
    private void htmlListaCorpoSucesso(StringBuilder builderHtml, List<MobileReport> listaInformacoes) {

        builderHtml.append("<div style='padding-top:15; padding-left:50'>");
        builderHtml.append("<table border='1'>");
        builderHtml.append("<thead>");
        builderHtml.append("<tr style='background-color:LightSkyBlue' align='center'>");
	        builderHtml.append("<td style='width:100;font-bold'><b>Ferramenta</b></td>");
	        builderHtml.append("<td style='width:110'><b>CPF/CNPJ</b></td>");
	        builderHtml.append("<td style='width:90'><b>Número EC</b></td>");
	        builderHtml.append("<td style='width:120'><b>Número Lógico</b></td>");
	        builderHtml.append("<td style='width:110'><b>Telefone</b></td>");
	        builderHtml.append("<td style='width:110'><b>Hora Inicial</b></td>");
	        builderHtml.append("<td style='width:110'><b>Hora Final</b></td>");
        builderHtml.append("</tr>");
        builderHtml.append("</thead>");
        builderHtml.append("<tbody>");
        for (MobileReport informacao : listaInformacoes) {
            if (informacao.getStatus().equals(Character.toString(StatusAtivacaoEnum.SUCESSO.getFlag()))) {
                builderHtml.append("<tr align='center'>");
                builderHtml.append("<td>" + informacao.getFerramenta() + "</td>");
                builderHtml.append("<td>" + CrdMobileUtils.formatarCpfCnpj(informacao.getCpfCnpj()) + "</td>");
                builderHtml.append("<td>" + tratarNull(informacao.getNumeroEc()) + "</td>");
                builderHtml.append("<td>" + tratarNull(informacao.getNumeroLogico()) + "</td>");
                builderHtml.append("<td>" + informacao.getDddTelefone() + "</td>");
                builderHtml.append("<td>" + informacao.getHoraInicial() + "</td>");
                builderHtml.append("<td>" + informacao.getHoraFinal() + "</td>");
                builderHtml.append("</tr>");
            }
        }
        builderHtml.append("</tbody>");
        builderHtml.append("</table>");
        builderHtml.append("</div>");
    }

    /**
     * Efetua a finalização do html
     */
    private void htmlSemProcessamento(StringBuilder builderHtml) {

        builderHtml.append("<div style='padding-top:30; padding-left:50'>");
        builderHtml.append("<table>");
        builderHtml.append("<tr><td style='background-color:Azure'>");
        builderHtml.append("<label><b>"+CrdMobileUtils.SEM_PROCESSAMENTO_MOBILE+"</b></label>");
        builderHtml.append("</td></tr>");
        builderHtml.append("</table>");
        builderHtml.append("<div>");
    }

    /**
     * Efetua a finalização do html
     */
    private void htmlSemProcessMobile(StringBuilder builderHtml, String mensagem) {

        builderHtml.append("<div style='padding-top:30; padding-left:50'>");
        builderHtml.append("<table>");
        builderHtml.append("<tr><td style='background-color:Azure'>");
        builderHtml.append("<label><b>"+mensagem+"</b></label>");
        builderHtml.append("</td></tr>");
        builderHtml.append("</table>");
        builderHtml.append("<div>");
    }

    /**
     * Efetua a finalização do html
     */
    private void htmlFinal(StringBuilder builderHtml) {

        builderHtml.append(
            "<p style='padding-top:30'><strong>Note:</strong> <font size='2' style='font-style:italic'>"+CrdMobileUtils.MOBILE_FOOTER+"</font></p>");
        builderHtml.append("</body>");
        builderHtml.append("</html>");
    }

    /**
     * Método responsavel por calcular o total de processamento
     * 
     * @param totalCompleto
     * @param totalParcial
     * @param totalRejeitado
     * @return Integer
     */
    private Integer getTotal(Integer totalCompleto, Integer totalParcial, Integer totalRejeitado) {

        return totalCompleto + totalParcial + totalRejeitado;
    }

    /**
     * Tratamento para não exibir campo null
     * 
     * @param campo
     * @return
     */
    private String tratarNull(String campo) {

        return ("null".equals(campo) ? "-" : campo.length() > 60 ? campo.substring(0, 55).concat(" ....") : campo);
    }
    
}
