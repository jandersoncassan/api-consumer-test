package br.com.cielo.crd.mobile.model.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * Informações do Estabelecimento Comercial ativação mobile
 * @author @Cielo SA
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class EstabelecimentoComercialType implements Serializable{

	private static final long serialVersionUID = 1L;

	@XmlElement(required = true)
    private Integer codigoRamoAtividade;
	
	@XmlElement(required = true)
    private String indicadorMei;

	@XmlElement(required = true)
    private String nomeRazaoSocial;
    
	@XmlElement(required = true)
    private Long numeroInscricaoEstadual;
    
	@XmlElement(required = true)
    private String nomeFantasia;

	@XmlElement(required = true)
    private String nomePlaqueta;

	@XmlElement(required = true)
    private String nomePessoaContato;

	/**
	 * @return the codigoRamoAtividade
	 */
	public Integer getCodigoRamoAtividade() {
		return codigoRamoAtividade;
	}

	/**
	 * @param codigoRamoAtividade the codigoRamoAtividade to set
	 */
	public void setCodigoRamoAtividade(Integer codigoRamoAtividade) {
		this.codigoRamoAtividade = codigoRamoAtividade;
	}

	/**
	 * @return the indicadorMei
	 */
	public String getIndicadorMei() {
		return indicadorMei;
	}

	/**
	 * @param indicadorMei the indicadorMei to set
	 */
	public void setIndicadorMei(String indicadorMei) {
		this.indicadorMei = indicadorMei;
	}

	/**
	 * @return the nomeRazaoSocial
	 */
	public String getNomeRazaoSocial() {
		return nomeRazaoSocial;
	}

	/**
	 * @param nomeRazaoSocial the nomeRazaoSocial to set
	 */
	public void setNomeRazaoSocial(String nomeRazaoSocial) {
		this.nomeRazaoSocial = nomeRazaoSocial;
	}

	/**
	 * @return the numeroInscricaoEstadual
	 */
	public Long getNumeroInscricaoEstadual() {
		return numeroInscricaoEstadual;
	}

	/**
	 * @param numeroInscricaoEstadual the numeroInscricaoEstadual to set
	 */
	public void setNumeroInscricaoEstadual(Long numeroInscricaoEstadual) {
		this.numeroInscricaoEstadual = numeroInscricaoEstadual;
	}

	/**
	 * @return the nomeFantasia
	 */
	public String getNomeFantasia() {
		return nomeFantasia;
	}

	/**
	 * @param nomeFantasia the nomeFantasia to set
	 */
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	/**
	 * @return the nomePlaqueta
	 */
	public String getNomePlaqueta() {
		return nomePlaqueta;
	}

	/**
	 * @param nomePlaqueta the nomePlaqueta to set
	 */
	public void setNomePlaqueta(String nomePlaqueta) {
		this.nomePlaqueta = nomePlaqueta;
	}

	/**
	 * @return the nomePessoaContato
	 */
	public String getNomePessoaContato() {
		return nomePessoaContato;
	}

	/**
	 * @param nomePessoaContato the nomePessoaContato to set
	 */
	public void setNomePessoaContato(String nomePessoaContato) {
		this.nomePessoaContato = nomePessoaContato;
	}

    
   

}
