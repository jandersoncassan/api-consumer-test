package br.com.cielo.crd.mobile.service.osb;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaResponse;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse;
import br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequest;
import br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoResponse;
import br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequest;
import br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoResponse;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteRequest;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteResponse;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoRequest;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoResponse;
import br.com.cielo.service.corporativo.email.v3.EnviarEmailResponseType;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoRequest;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoResponse;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCRequestType;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCResponseType;

/**
 * Interface para implementação dos serviços expostos no OSB ativação mobile
 * @author @Cielo
 *
 */
public interface ServicosOsb{

	/**
	 * Método responsavel por verificar a existência do cliente no SEC
	 * @param cpfCnpj
	 * @return Boolean
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	Boolean verificarExistenciaCliente(final String cpfCnpj)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel por verificar a existência do domicilio bancário
	 * @param cdBanco
	 * @param cdAgencia
	 * @param cdConta
	 * @return Boolean
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	Boolean verificarExistenciaDomBancario(final BigInteger cdBanco, final BigInteger cdAgencia, final String cdConta, final String tipoConta)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel por validar o domicilio bancário
	 * @param cdBanco
	 * @param nuAgencia
	 * @param nuConta
	 * @return ValidarDigitoAgenciaContaResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
    ValidarDigitoAgenciaContaResponse validarDomicilioBancario(final String cdBanco,
            final BigInteger nuAgencia, final String nuConta, final String tipoConta) throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel pela inclusão do cliente no SEC
	 * @param request
	 * @return IncluirResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	IncluirResponse incluirClienteSec(IncluirRequest request)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel pela habilitação de produtos no SEC
	 * @param request
	 * @return HabilitarListaProdutoResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	HabilitarListaProdutoResponse habilitarProdutos(HabilitarListaProdutoRequest request)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel pela habilitação de serviços no SEC
	 * @param request
	 * @return HabilitarListaServicoResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	HabilitarListaServicoResponse habilitarServicos(HabilitarListaServicoRequest request)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel pela inclusão do cliente em Redes
	 * @param request
	 * @return IncluirClienteResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	IncluirClienteResponse incluirClienteRedes(IncluirClienteRequest request)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel pela geração do numerico lógico
	 * @param request
	 * @return IncluirNumeroLogicoResponse
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	IncluirNumeroLogicoResponse gerarNumeroLogico(IncluirNumeroLogicoRequest request)
			throws RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel pela notificação do numero lógico ao GTEC
	 * @param request
	 * @return NotificarNumeroLogicoGTeCResponseType
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	NotificarNumeroLogicoGTeCResponseType notificarNumeroLogico(NotificarNumeroLogicoGTeCRequestType request)
			throws Fault, RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel pela notificação do evento SEC
	 * @param NotificarInstalacaoMobileRequest
	 * @return NotificarInstalacaoMobileResponse
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	NotificarInstalacaoEquipamentoResponse notificaAberturaEventoMobile(NotificarInstalacaoEquipamentoRequest request)
			throws Fault, RemoteException, MalformedURLException, ServiceException;
	/**
	 * Método responsavel pelo envio de email, processamento ativação mobile
	 * @param emailDe
	 * @param listaEmailPara
	 * @param mensagem
	 * @param assunto
	 * @return EnviarEmailResponseType
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	EnviarEmailResponseType enviarEmail(String emailDe, String[] listaEmailPara, String mensagem, String assunto)
			throws RemoteException, MalformedURLException, ServiceException;
}
