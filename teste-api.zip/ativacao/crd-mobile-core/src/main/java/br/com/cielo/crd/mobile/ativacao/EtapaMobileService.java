package br.com.cielo.crd.mobile.ativacao;

import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;

/**
 * Interface responsavel pelas consistencias de validação na ativação mobile
 * @author @Cielo
 */
public interface EtapaMobileService {

	/**
	 * Método responsavel pela validacao na ativação mobile
	 * @param dadosValidacao
	 * @return AtivacaoMobile
	 */
	AtivacaoMobile validar(AtivacaoMobileRequest dadosRequest);
}
