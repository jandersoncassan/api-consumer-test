/**
 * 
 */
package br.com.cielo.crd.mobile.enums;

/**
 * Enum responsavel por validar o tipo de exceção que ocorreu no processamento da ativação mobile
 * @author @Cielo
 */
public enum TipoCritica {

	CRITICA_NEGOCIO("CRITICA DE NEGOCIO"), 
	ERRO_SISTEMICO("ERRO SISTEMICO");
	
	private String critica;
	
	private TipoCritica(String critica){
		this.critica = critica;
	}
	
	public String getDescricao(){
		return critica;
	}
}
