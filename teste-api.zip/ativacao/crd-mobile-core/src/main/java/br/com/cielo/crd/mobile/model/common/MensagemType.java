package br.com.cielo.crd.mobile.model.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 * Classe que devolve o erro que ocorreu no momento da ativação mobile
 * @author @Cielo
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class MensagemType implements Serializable{
	
	private static final long serialVersionUID = 1L;

	private String sistemaOrigem;
	
	private String servico;
	
	private String tipoCritica;

	private String codigo;

	private String mensagem;
	

	/**
	 * @return the sistemaOrigem
	 */
	public String getSistemaOrigem() {
		return sistemaOrigem;
	}

	/**
	 * @param sistemaOrigem the sistemaOrigem to set
	 */
	public void setSistemaOrigem(String sistemaOrigem) {
		this.sistemaOrigem = sistemaOrigem;
	}

	/**
	 * @return the mensagem
	 */
	public String getMensagem() {
		return mensagem;
	}

	/**
	 * @param mensagem the mensagem to set
	 */
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}

	/**
	 * @return the servico
	 */
	public String getServico() {
		return servico;
	}

	/**
	 * @param servico the servico to set
	 */
	public void setServico(String servico) {
		this.servico = servico;
	}

	/**
	 * @return the tipoCritica
	 */
	public String getTipoCritica() {
		return tipoCritica;
	}

	/**
	 * @param tipoCritica the tipoCritica to set
	 */
	public void setTipoCritica(String tipoCritica) {
		this.tipoCritica = tipoCritica;
	}

	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	
	
}
