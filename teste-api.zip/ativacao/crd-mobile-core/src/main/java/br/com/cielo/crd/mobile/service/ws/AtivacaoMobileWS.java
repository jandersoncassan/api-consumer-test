package br.com.cielo.crd.mobile.service.ws;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.soap.SOAPException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.impl.validacao.VerificaExistenciaDomicilioBancario;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.AtivacaoMobileResponse;
import br.com.cielo.crd.mobile.service.AtivacaoMobileService;
import br.com.cielo.crd.mobile.util.CrdMobileFile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

/**
 * Serviço responsavel pela ativação do Mobile via CRD
 * 
 * @author @Cielo
 *
 */
@WebService(targetNamespace = "http://credenciamento.cielo.com.br/operacao/comercial/ativar_mobile/v1", serviceName = "AtivacaoMobileService", portName = "AtivacaoMobile")
@Stateless
public class AtivacaoMobileWS {

	private static final Logger LOG = LoggerFactory.getLogger(VerificaExistenciaDomicilioBancario.class);

	@Inject
	private CrdMobileFile loadFile;

	@Inject
	private AtivacaoMobileService ativacaoMobileService;

	@WebMethod(operationName = "ativarMobile", action = "ativarMobile")
	@WebResult(name = "retornoAtivacaoMobile")
	public AtivacaoMobileResponse ativarMobile(
			@WebParam(name = "dadosAtivacao") final AtivacaoMobileRequest dadosAtivacao) throws SOAPException {
		LOG.debug("WS ATIVACAO MOBILE");
		if (isLoggerRequest()) {
			CrdMobileUtils.deflate("INIT ENTRADA", dadosAtivacao);
		}
		
		return ativar(dadosAtivacao);
	}

	/**
	 * Método responsavel pelo inicio da ativação mobile
	 * 
	 * @param dadosAtivacao
	 * @return AtivacaoMobileResponse
	 * @throws SOAPException
	 */
	private AtivacaoMobileResponse ativar(AtivacaoMobileRequest dadosAtivacao) throws SOAPException {
		return ativacaoMobileService.initAtivarMobile(dadosAtivacao);
	}

	/**
	 * Método responsavel por verificar se deve ou não ser logada a requisição de entrada
	 */
	private boolean isLoggerRequest() {
		String flag = loadFile.getMessage(CrdMobileUtils.KEY_LOGGER);
		if (flag.equals(CrdMobileUtils.FLAG_S)) {
			return true;
		}
		return false;
	}

}
