package br.com.cielo.crd.mobile.ativacao.impl.ativar;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoRequest;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoResponse;

@AtivarMobile(etapa=AtivacaoEnum.NOTIFICAR_ABERTURA_EVENTO_MOBILE_SEC)
public class NotificarAberturaEventoMobileSec extends AtivacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(NotificarAberturaEventoMobileSec.class);
	
	@Inject
	private ServicosOsb service;

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		LOG.debug("INIT NOTIFICAR ABERTURA EVENTO MOBILE SEC");
		popularInfoValidacao(retorno, AtivacaoEnum.NOTIFICAR_ABERTURA_EVENTO_MOBILE_SEC);
		init(dadosAtivacao, retorno);
		return retorno;
	}

	/**
	 * Método init da execução da abertura do evento mobile no sec
	 * @param dadosAtivacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		NotificarInstalacaoEquipamentoRequest request = popularRequest(dadosAtivacao, retorno);
		notificarAberturaEventoMobileSec(request, retorno);
	}

	/**
	 * Método responsavel pela notificação da abertura do evento mobile no sec
	 * @param request
	 * @param retorno
	 */
	private void notificarAberturaEventoMobileSec(NotificarInstalacaoEquipamentoRequest request, AtivacaoMobile retorno) {
		try {
			CrdMobileUtils.deflate("NOTIFICACAO ABERTURA EVENTO MOBILE SEC", request);
			NotificarInstalacaoEquipamentoResponse resp = service.notificaAberturaEventoMobile(request);
			LOG.debug("NUMERO EVENTO GERADO NO SEC --- > " + resp.getNumeroRegistroEvento());
		} catch (Exception e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}		
	}

	/**
	 * Método responsavel por popular a request
	 * @param dadosAtivacao
	 * @return NotificarInstalacaoMobileRequest
	 */
	private NotificarInstalacaoEquipamentoRequest popularRequest(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		
		NotificarInstalacaoEquipamentoRequest request = new NotificarInstalacaoEquipamentoRequest();
		request.setCanalSolicitante(CrdMobileUtils.CREDENCIAMENTO);
		request.setCodigoCliente(retorno.getNumeroEC());
		request.setDescricaoSolucaoCaptura(CrdMobileUtils.DESCRICAO_SOLUCAO_CAPTURA);
		request.setNumeroLogico(String.valueOf(retorno.getNumeroLogico()));
		return request;
	}
}
