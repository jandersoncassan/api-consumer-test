package br.com.cielo.crd.mobile.model.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * Model dados do endereço do estabelecimento comercial na ativação mobile
 * @author @Cielo SA
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class EnderecoType implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(required = true)
    private Integer codigoTipoEndereco; //2-COMERCIAL <> 3-CORRESPONDECIA
    
    @XmlElement(required = true)
    private String logradouro;
    
    @XmlElement(required = true)
    private String complemento;
    
    @XmlElement(required = true)
    private String numeroLogradouro;
    
    @XmlElement(required = true)
    private String cidade;
    
    @XmlElement(required = true)
    private String siglaEstado;
    
    @XmlElement(required = true)
    private String numeroCep;

    public Integer getCodigoTipoEndereco() {
        return codigoTipoEndereco;
    }

    public void setCodigoTipoEndereco(final Integer codigoTipoEndereco) {
        this.codigoTipoEndereco = codigoTipoEndereco;
    }

    public String getLogradouro() {
        return logradouro;
    }

    public void setLogradouro(final String logradouro) {
        this.logradouro = logradouro;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(final String complemento) {
        this.complemento = complemento;
    }

    public String getNumeroLogradouro() {
        return numeroLogradouro;
    }

    public void setNumeroLogradouro(final String numeroLogradouro) {
        this.numeroLogradouro = numeroLogradouro;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(final String cidade) {
        this.cidade = cidade;
    }

    public String getSiglaEstado() {
        return siglaEstado;
    }

    public void setSiglaEstado(final String siglaEstado) {
        this.siglaEstado = siglaEstado;
    }

    public String getNumeroCep() {
        return numeroCep;
    }

    public void setNumeroCep(final String numeroCep) {
        this.numeroCep = numeroCep;
    }
    

}
