package br.com.cielo.crd.mobile.service;

import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.AtivacaoMobileResponse;

/**
 * Interface responsavel por iniciar as consistencias para ativacao mobile
 * @author @Cielo
 */
public interface AtivacaoMobileService {
	
	/**
	 * Método responsavel por iniciar as consistencias para ativação mobile
	 * @param ativacaoRequest
	 * @return AtivacaoMobileResponse
	 */
	AtivacaoMobileResponse initAtivarMobile(AtivacaoMobileRequest ativacaoRequest);
}
