package br.com.cielo.crd.mobile.service;

public interface MobileReportService {

	/**
	 * Método responsavel por gerar o ralatório de processamento de ativação mobile
	 */
	void gerarReportMobile();
}
