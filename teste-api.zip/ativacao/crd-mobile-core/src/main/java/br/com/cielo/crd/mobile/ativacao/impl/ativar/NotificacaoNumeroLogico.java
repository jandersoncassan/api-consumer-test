package br.com.cielo.crd.mobile.ativacao.impl.ativar;

import java.math.BigInteger;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.common.TelefoneType;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCRequestType;

@AtivarMobile(etapa=AtivacaoEnum.NOTIFICAR_GTEC_NUM_LOGICO)
public class NotificacaoNumeroLogico extends AtivacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(NotificacaoNumeroLogico.class);
	
	@Inject
	private ServicosOsb service;

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		LOG.debug("INIT NOTIFICAR NUMERO LOGICO");
		popularInfoValidacao(retorno, AtivacaoEnum.NOTIFICAR_GTEC_NUM_LOGICO);
		init(dadosAtivacao, retorno);
		return retorno;
	}

	/**
	 * Método init da execução de inclusão de clientes em redes
	 * @param dadosAtivacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		NotificarNumeroLogicoGTeCRequestType request = popularRequest(dadosAtivacao, retorno);
		notificarNumeroLogico(request, retorno);
	}

	/**
	 * Método responsavel pela habilitação de produtos
	 * @param request
	 * @param retorno
	 */
	private void notificarNumeroLogico(NotificarNumeroLogicoGTeCRequestType request, AtivacaoMobile retorno) {
		try {
			CrdMobileUtils.deflate("NOTIFICACAO NUMERO LOGICO", request);
			service.notificarNumeroLogico(request);
			tratarRetornoServico(retorno);		
		} catch (Exception e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}		
	}

	/**
	 * Método responsavel pelo tratamento do retorno do serviço
	 */
	private void tratarRetornoServico(AtivacaoMobile retorno){
		retorno.setIsEtapaValida(Boolean.TRUE);		
		retorno.setIsAvisoGtec(Boolean.TRUE);
	}
	
	/**
	 * Método responsavel por popular a request
	 * @param dadosAtivacao
	 * @return HabilitarListaProdutoRequest
	 */
	private NotificarNumeroLogicoGTeCRequestType popularRequest(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		NotificarNumeroLogicoGTeCRequestType request = new NotificarNumeroLogicoGTeCRequestType();
		request.setNumeroLogico(retorno.getNumeroLogico().toString());
		request.setNumeroLoja(String.valueOf(CrdMobileUtils.NUM_UM));
		request.setNumeroEstabelecimento(retorno.getNumeroEC().toString());
		request.setCodigoModeloSolucaoMobile(CrdMobileUtils.TIPO_TERMINAL);
		br.com.cielo.service.operacao.logistica.equipamento.v4.TelefoneType telefone= new br.com.cielo.service.operacao.logistica.equipamento.v4.TelefoneType();
		for(TelefoneType tel : dadosAtivacao.getTelefonesEstabelecimento()){			
			if(tel.getCodigoTipoTelefone().equals(CrdMobileUtils.NUM_DOIS)){
				telefone.setNumeroDDD(new BigInteger(tel.getNumeroDdd().toString()));
				telefone.setNumeroTelefone(new BigInteger(tel.getNumeroTelefone().toString()));
				request.setTelefone(telefone);
				break;
			}
		}
		request.setIndicadorLeitorCodigoBarras(Boolean.FALSE);
		request.setCodigoModeloSolucaoDefinido(CrdMobileUtils.COD_MODELO_SOL_DEFINIDO);
		return request;
	}
}
