package br.com.cielo.crd.mobile.ativacao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.ativacao.EtapaMobileService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.enums.EtapasAtivacaoMobileEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.qualifier.EtapaMobile;

/**
 * Classe responsavel pela implementação das validações da ativação mobile
 * @author @Cielo
 */
@EtapaMobile(etapa=EtapasAtivacaoMobileEnum.ATIVACAO)
public class EtapaAtivacaoServiceImpl implements EtapaMobileService{

	private static final Logger LOG = LoggerFactory.getLogger(EtapaAtivacaoServiceImpl.class);
	
	private List<AtivacaoService> listaEtapasAtivacao;

	@Inject @AtivarMobile(etapa=AtivacaoEnum.INCLUIR_EC_SEC)
	private AtivacaoService incluirClienteSec;

	@Inject @AtivarMobile(etapa=AtivacaoEnum.HABILITAR_PRODUTOS)
	private AtivacaoService habilitarProdutos;

	@Inject @AtivarMobile(etapa=AtivacaoEnum.HABILITAR_SERVICOS)
	private AtivacaoService habilitarServicos;
	
	@Inject @AtivarMobile(etapa=AtivacaoEnum.INCLUIR_EC_REDES)
	private AtivacaoService incluirClienteRedes;

	@Inject @AtivarMobile(etapa=AtivacaoEnum.GERAR_NUMERO_LOGICO)
	private AtivacaoService obterNumeroLogico;

	@Inject @AtivarMobile(etapa=AtivacaoEnum.NOTIFICAR_GTEC_NUM_LOGICO)
	private AtivacaoService notificarNumLogicoGtec;
	
	@Inject @AtivarMobile(etapa=AtivacaoEnum.NOTIFICAR_ABERTURA_EVENTO_MOBILE_SEC)
	private AtivacaoService notificarAberturaEventoMobileSec;
	
	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao) {
		LOG.debug("ETAPA ATIVACAO MOBILE ");
		AtivacaoMobile retorno = null;
	   	for(AtivacaoService etapa : listaEtapasAtivacao){
    		retorno = etapa.validar(dadosAtivacao, retorno);
    		if(!retorno.getIsEtapaValida()){
    			break;
    		}
   	  }
	   	return retorno;
	}

	/**
	 * Método responsavel por popular as implementações das etapas de ativacao mobile
	 */
 	@PostConstruct
 	private void addEtapaValidacao(){
 		if(null == listaEtapasAtivacao){
 			listaEtapasAtivacao = new ArrayList<AtivacaoService>();
 		}
 		listaEtapasAtivacao.addAll(Arrays.asList(incluirClienteSec, habilitarProdutos, habilitarServicos, incluirClienteRedes, 
 												 obterNumeroLogico, notificarNumLogicoGtec, notificarAberturaEventoMobileSec));

 	}

}
