package br.com.cielo.crd.mobile.ativacao.impl.ativar;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileFile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequest;
import br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequestIndicadorPersistencia;
import br.com.cielo.service.cadastro.produto.produto.v3.ProdutoType;

@AtivarMobile(etapa=AtivacaoEnum.HABILITAR_PRODUTOS)
public class HabilitacaoProdutos extends AtivacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(HabilitacaoProdutos.class);
	
	private final String KEY_LISTA_PRODUTOS = "lista.produtos";
	
	@Inject
	private ServicosOsb service;

	@Inject
	private CrdMobileFile loadFile;

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		LOG.debug("INIT HABILITAR PRODUTOS SEC");
		popularInfoValidacao(retorno, AtivacaoEnum.HABILITAR_PRODUTOS);
		init(dadosAtivacao, retorno);
		return retorno;
	}

	/**
	 * Método init da execução de inclusão de clientes em redes
	 * @param dadosAtivacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		HabilitarListaProdutoRequest request = popularRequest(dadosAtivacao, retorno);
		habilitarProdutos(request, retorno);
	}

	/**
	 * Método responsavel pela habilitação de produtos
	 * @param request
	 * @param retorno
	 */
	private void habilitarProdutos(HabilitarListaProdutoRequest request, AtivacaoMobile retorno) {
		try {
			CrdMobileUtils.deflate("HABILITAR PRODUTOS SEC", request);
			service.habilitarProdutos(request);
			retorno.setIsEtapaValida(Boolean.TRUE);					
		} catch (Exception e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}		
	}

	/**
	 * Método responsavel por popular a request
	 * @param dadosAtivacao
	 * @return HabilitarListaProdutoRequest
	 */
	private HabilitarListaProdutoRequest popularRequest(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		HabilitarListaProdutoRequest request = new HabilitarListaProdutoRequest();
		request.setCodigoCliente(retorno.getNumeroECTemp());
		request.setCorrelationId(retorno.getCorrelationId());
		//NESSE MOMENTO AINDA NÃO PERSISITIMOS AS INFORMAÇÕES DO EC
		request.setIndicadorPersistencia(HabilitarListaProdutoRequestIndicadorPersistencia.N);
		request.setDadosProdutosClienteHabilitacao(popularProdutos());
		return request;
	}

	/**
	 * Métododo responsavel por popular a lista de produtos para habilitar no SEC
	 * @return ProdutoType[]
	 */
	private ProdutoType[] popularProdutos() {		
		List<ProdutoType> produtos = new ArrayList<>();		
		List<String[]> listaProdutos = popularListProdutos();		
		for(String [] produto : listaProdutos){
			ProdutoType prod = new ProdutoType();
			prod.setCodigoProduto(BigInteger.valueOf(Long.valueOf(produto[0])));
			prod.setPercentualTaxa(BigDecimal.valueOf(Double.valueOf(produto[1])));
			prod.setQuantidadeDiasPrazo(BigInteger.valueOf(Long.valueOf(produto[2])));
			produtos.add(prod);
		}			
		ProdutoType[] produtoArray = new ProdutoType[produtos.size()] ;
		return produtos.toArray(produtoArray);
	}
		
	/**
	 * Método responsavel por devolver a lista de produtos
	 * @return Map
	 * FIXME ALINHADO COM A ARAEA DE NEGOCIO QUE AS TAXAS E PRAZOS SERÃO FIXAS
	 */
	private List<String[]> popularListProdutos(){
		List<String[]> listaProdutos = new ArrayList<>();
		String produtos = loadFile.getMessage(KEY_LISTA_PRODUTOS);		
		String [] listaProdTxPrz = produtos.split(CrdMobileUtils.SEPARADOR_VIRGULA);
		for(int i=0;i<listaProdTxPrz.length;i++){
			String[] prodTxPrz = listaProdTxPrz[i].split(CrdMobileUtils.SEPARADOR_PONTO_VIRGULA);
			listaProdutos.add(new String[]{prodTxPrz[0],prodTxPrz[1],prodTxPrz[2]});
		}
		return listaProdutos;
	}
	
	

}
