package br.com.cielo.crd.mobile.service.osb.impl;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.rpc.ServiceException;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType;
import br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileFile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_PortType;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_Service;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_ServiceLocator;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaRequest;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaResponse;
import br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteService;
import br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteServiceLocator;
import br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteServicePortType;
import br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteRequest;
import br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteService;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteServiceLocator;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteServicePortType;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse;
import br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequest;
import br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoResponse;
import br.com.cielo.service.cadastro.produto.produto.v3.Produto_PortType;
import br.com.cielo.service.cadastro.produto.produto.v3.Produto_Service;
import br.com.cielo.service.cadastro.produto.produto.v3.Produto_ServiceLocator;
import br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequest;
import br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoResponse;
import br.com.cielo.service.cadastro.servico.servico.v1.Servico_PortType;
import br.com.cielo.service.cadastro.servico.servico.v1.Servico_Service;
import br.com.cielo.service.cadastro.servico.servico.v1.Servico_ServiceLocator;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteRequest;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteResponse;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteService;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteServiceLocator;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteServicePortType;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoRequest;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoResponse;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_PortType;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_Service;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_ServiceLocator;
import br.com.cielo.service.corporativo.email.v3.Email;
import br.com.cielo.service.corporativo.email.v3.EmailService;
import br.com.cielo.service.corporativo.email.v3.EmailServiceLocator;
import br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestType;
import br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeCharset;
import br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeConteudo;
import br.com.cielo.service.corporativo.email.v3.EnviarEmailResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancario;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancarioService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancarioServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioResponse;
import br.com.cielo.service.operacao.logistica.equipamento.v4.EquipamentoContract;
import br.com.cielo.service.operacao.logistica.equipamento.v4.EquipamentoContractLocator;
import br.com.cielo.service.operacao.logistica.equipamento.v4.EquipamentoContractPortType;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoRequest;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoResponse;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCRequestType;
import br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCResponseType;

/**
 * Classe de implementação dos serviços expostos no OSB para ativação mobile
 * @author @Cielo
 */
@Named
public class ServicosOsbImpl implements ServicosOsb{

	@Inject
	private CrdMobileFile crdMobileFile;

	/**
	 * Método responsavel por popular as informações de autenticação do servico SOAP exposto no OSB
	 * @return CieloSoapHeaderType
	 */
	private CieloSoapHeaderType buildHeader() {
        UsuarioType user = new UsuarioType();
        user.setId(crdMobileFile.getMessage(CrdMobileUtils.HEADER_USER));
        user.setSenha(crdMobileFile.getMessage(CrdMobileUtils.HEADER_PASS));

        CieloSoapHeaderType header = new CieloSoapHeaderType();
        header.setUsuario(user);
        return header;
    }

	/**
	 * Método responsavel pela validação de cliente já existente no SEC
	 * @return Boolean 
	 */
	@Override
	public Boolean verificarExistenciaCliente(String cpfCnpj)
	        throws MalformedURLException, ServiceException, Fault, RemoteException {

	        ClienteService ws = new ClienteServiceLocator();
	        VerificarExistenciaClienteRequest req = new VerificarExistenciaClienteRequest();
	        req.setNumeroCpfCnpj(cpfCnpj);

	        ClienteServicePortType service = ws.getClienteServiceSOAPPort(
	            new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_VERIFICAR_EXISTENCIA_CLIENTE)));

	        VerificarExistenciaClienteResponse response =  service.verificarExistenciaCliente(req, buildHeader());
	        return response.isIndicadorExistenciaCliente();
	    }
	
	/**
	 * Método responsavel por verificar a existência do domicilio bancario
	 * @param cdBanco
	 * @param cdAgencia
	 * @param cdConta
	 * @return Boolean
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	@Override
    public Boolean verificarExistenciaDomBancario(final BigInteger cdBanco,
            final BigInteger cdAgencia, final String cdConta, final String tipoConta) throws MalformedURLException, ServiceException, Fault, RemoteException {

		    Credenciamento_VerificarExistenciaDomicilioBancarioService ws = new Credenciamento_VerificarExistenciaDomicilioBancarioServiceLocator();
		    VerificarExistenciaDomicilioBancarioRequest req = new VerificarExistenciaDomicilioBancarioRequest();
            req.setCodigoBanco(cdBanco);
            req.setNumeroAgencia(cdAgencia);
            req.setNumeroConta(cdConta);
            req.setTipoConta(tipoConta);

            Credenciamento_VerificarExistenciaDomicilioBancario service = ws.getCredenciamento_VerificarExistenciaDomicilioBancarioServiceSoapPort(
                new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_VERIFICAR_EXISTENCIA_DOMICILIO)));

            VerificarExistenciaDomicilioBancarioResponse response = service.verificarExistenciaDomicilioBancario(req, buildHeader());
            return response.isIndicadorExisteDomicilioBancario();

        }

	/**
	 * Método responsavel por validar o domicilio bancário
	 * @param cdBanco
	 * @param nuAgencia
	 * @param nuConta
	 * @return 
	 * @return ValidarDigitoAgenciaContaResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	@Override
    public ValidarDigitoAgenciaContaResponse validarDomicilioBancario(final String cdBanco,
            final BigInteger nuAgencia, final String nuConta, final String tipoConta) throws MalformedURLException, ServiceException, Fault, RemoteException {

		    Banco_ValidarDigitoAgenciaContaService_Service ws = new Banco_ValidarDigitoAgenciaContaService_ServiceLocator();
            ValidarDigitoAgenciaContaRequest req = new ValidarDigitoAgenciaContaRequest();
            req.setCodigoBanco(BigInteger.valueOf(Long.valueOf(cdBanco)));
            req.setNumeroAgencia(nuAgencia);
            req.setNumeroConta(nuConta);
            req.setTipoConta(tipoConta);

            Banco_ValidarDigitoAgenciaContaService_PortType service = ws.getBancoSOAP(
            		new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_VALIDAR_DOMICILIO_BANCARIO)));
            return service.validarDigitoAgenciaConta(req, buildHeader());
        }

	/**
	 * Método responsavel pela inclusão de cliente no SEC
	 * @param request
	 * @return IncluirResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	@Override
	public IncluirResponse incluirClienteSec(IncluirRequest request) throws MalformedURLException, ServiceException, Fault, RemoteException{
		
		DadosClienteService ws = new DadosClienteServiceLocator();
		DadosClienteServicePortType service = ws.getDadosClienteServiceSOAPPort(
				new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_INCLUIR_CLIENTE_SEC)));		
		IncluirResponse response = service.incluir(request, buildHeader());
		return response;
	}
	
	/**
	 * Método responsvel pela habilitação de produtos no SEC
	 * @param request
	 * @return HabilitarListaProdutoResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	@Override
	public HabilitarListaProdutoResponse habilitarProdutos(HabilitarListaProdutoRequest request) 
			throws MalformedURLException, ServiceException, Fault, RemoteException{
		
		Produto_Service ws = new Produto_ServiceLocator();
		Produto_PortType service = ws.getProdutoSOAP(
				new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_HABILITAR_PRODUTOS)));
		return service.habilitarListaProduto(request, buildHeader());
	}
	
	/**
	 * Método responsavel por habilitar os serviços no SEC
	 * @param request
	 * @return HabilitarListaServicoResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	@Override
	public HabilitarListaServicoResponse habilitarServicos(HabilitarListaServicoRequest request) 
			throws MalformedURLException, ServiceException, Fault, RemoteException{
		
		Servico_Service ws = new Servico_ServiceLocator();
		Servico_PortType service = ws.getServicoSOAP(
				new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_HABILITAR_SERVICOS)));
		return service.habilitarListaServico(request, buildHeader());
	}
	
	/**
	 * Método responsavel pela inclusão de clientes em redes
	 * @param request
	 * @return IncluirClienteResponse
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	@Override
	public IncluirClienteResponse incluirClienteRedes(IncluirClienteRequest request) 
			throws MalformedURLException, ServiceException, Fault, RemoteException{
		
		IncluirClienteService ws = new IncluirClienteServiceLocator();
		IncluirClienteServicePortType service = ws.getIncluirClienteServiceSOAPPort(
				new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_INCLUIR_CLIENTE_REDES)));
		return service.incluirCliente(buildHeader(), request);
	}
	
	/**
	 * Método responsavel pela inclusão do numero lógico em Redes
	 * @param request
	 * @return IncluirNumeroLogicoResponse
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	@Override
	public IncluirNumeroLogicoResponse gerarNumeroLogico(IncluirNumeroLogicoRequest request) 
			throws RemoteException, MalformedURLException, ServiceException{
		
		IncluirNumeroLogico_Service ws = new IncluirNumeroLogico_ServiceLocator();
		IncluirNumeroLogico_PortType service = ws.getIncluirNumeroLogicoSOAP(
				new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_GERACAO_NUMERO_LOGICO)));
		return service.incluirNumeroLogico(buildHeader(), request);
	}
	
	/**
	 * Método responsavel por notificar o numero lógico para o GTEC
	 * @param request
	 * @return NotificarNumeroLogicoGTeCResponseType
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	@Override
	public NotificarNumeroLogicoGTeCResponseType notificarNumeroLogico(NotificarNumeroLogicoGTeCRequestType request) 
			throws Fault, RemoteException, MalformedURLException, ServiceException{
		
		EquipamentoContract ws = new EquipamentoContractLocator();
		EquipamentoContractPortType service = ws.getEquipamentoContractSOAPPort(
				new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_NOTIFICAR_NUMERO_LOGICO_E_NOTIFICACAO_SEC)));
		
		NotificarNumeroLogicoGTeCResponseType response = service.notificarNumeroLogicoGTeC(buildHeader(), request);
		return response;
	}
	
	/**
	 * Método responsavel pelo envio de email
	 * @param emailDe
	 * @param listaEmailPara
	 * @param mensagem
	 * @param assunto
	 * @return EnviarEmailResponseType
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	@Override
	public EnviarEmailResponseType enviarEmail(String emailDe, String[] listaEmailPara, String mensagem, String assunto) 
			throws RemoteException, MalformedURLException, ServiceException{
		
		EmailService ws = new EmailServiceLocator();
		EnviarEmailRequestType request = new EnviarEmailRequestType();
        request.setConteudo(EnviarEmailRequestTypeConteudo.HTML);
        request.setCharset(EnviarEmailRequestTypeCharset.value1);
        request.setDeEmail(emailDe);
        request.setPara(listaEmailPara);
        request.setAssunto(assunto);
        request.setMensagem(mensagem);
		Email service = ws.getEmailSoapPort(new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_ENVIAR_EMAIL)));
		return service.enviarEmail(request);
	}

	/**
	 * Método: Notificar abertura evento no SEC da instalação mobile
	 * @param NotificarInstalacaoMobileRequest
	 * @exception RemoteException|MalformedURLException|Fault
	 * @return {NotificarInstalacaoMobileResponse}
	 */
	public NotificarInstalacaoEquipamentoResponse notificaAberturaEventoMobile(
			NotificarInstalacaoEquipamentoRequest request) throws Fault,
			RemoteException, MalformedURLException, ServiceException {

		EquipamentoContract ws = new EquipamentoContractLocator();
		EquipamentoContractPortType service = ws.getEquipamentoContractSOAPPort(
				new URL(crdMobileFile.getMessage(CrdMobileUtils.ENDPOINT_NOTIFICAR_NUMERO_LOGICO_E_NOTIFICACAO_SEC)));

		NotificarInstalacaoEquipamentoResponse resp = service.notificarInstalacaoEquipamento(buildHeader(), request);

        return resp;
	}
}
