package br.com.cielo.crd.mobile.enums;

/**
 * Classe responsavel pelos status da ativação mobile
 * @author @Cielo
 */
public enum StatusAtivacaoEnum {

	SUCESSO(1,"Sucesso", 'S'),
	PARCIAL(2,"Parcial", 'P'),
	INSUCESSO(3,"Insucesso", 'I');
	
	private Integer codigo;
	
	private String descricao;
	
	private char flag;
	
	private StatusAtivacaoEnum(Integer codigo, String descricao, char flag){
		this.codigo = codigo;
		this.descricao = descricao;
		this.flag = flag;
	}

	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	
	/**
	 * @return the descricao
	 */
	public char getFlag() {
		return flag;
	}

}
