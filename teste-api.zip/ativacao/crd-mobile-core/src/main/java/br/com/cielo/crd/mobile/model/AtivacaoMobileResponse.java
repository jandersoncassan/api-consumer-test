package br.com.cielo.crd.mobile.model;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import br.com.cielo.crd.mobile.model.common.MensagemType;

/**
 * Representa a requisição do serviço de ativação mobile.
 * @author @Cielo SA
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AtivacaoMobileResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	
    private Integer codStatus;
    
    private String descStatus;
    
    private Long numeroEc;
    
    private Integer numeroLogico;
   
    private Integer digNumLogico;

    /**
     * Atributo lista de críticas da proposta
     */
    @XmlElement(name = "mensagem")
    private MensagemType mensagem;

	/**
	 * @return the codStatus
	 */
	public Integer getCodStatus() {
		return codStatus;
	}

	/**
	 * @param codStatus the codStatus to set
	 */
	public void setCodStatus(Integer codStatus) {
		this.codStatus = codStatus;
	}

	/**
	 * @return the descStatus
	 */
	public String getDescStatus() {
		return descStatus;
	}

	/**
	 * @param descStatus the descStatus to set
	 */
	public void setDescStatus(String descStatus) {
		this.descStatus = descStatus;
	}

	/**
	 * @return the numeroEc
	 */
	public Long getNumeroEc() {
		return numeroEc;
	}

	/**
	 * @param numeroEc the numeroEc to set
	 */
	public void setNumeroEc(Long numeroEc) {
		this.numeroEc = numeroEc;
	}

	/**
	 * @return the numeroLogico
	 */
	public Integer getNumeroLogico() {
		return numeroLogico;
	}

	/**
	 * @param numeroLogico the numeroLogico to set
	 */
	public void setNumeroLogico(Integer numeroLogico) {
		this.numeroLogico = numeroLogico;
	}

	/**
	 * @return the mensagem
	 */
	public MensagemType getMensagem() {
		return mensagem;
	}

	/**
	 * @param mensagem the mensagem to set
	 */
	public void setMensagem(MensagemType mensagem) {
		this.mensagem = mensagem;
	}

	/**
	 * @return the digNumLogico
	 */
	public Integer getDigNumLogico() {
		return digNumLogico;
	}

	/**
	 * @param digNumLogico the digNumLogico to set
	 */
	public void setDigNumLogico(Integer digNumLogico) {
		this.digNumLogico = digNumLogico;
	}
	
}
