package br.com.cielo.crd.mobile.enums;

/**
 * Enum para controle das fases de ativação mobile
 * @author @Cielo
 */
public enum EtapasAtivacaoMobileEnum {

	VALIDACAO, ATIVACAO;
}
