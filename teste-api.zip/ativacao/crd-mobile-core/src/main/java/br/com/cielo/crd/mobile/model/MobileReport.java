package br.com.cielo.crd.mobile.model;

public class MobileReport {

	private String status;
	private String ferramenta;
	private String cpfCnpj;
	private String data;
	private String hora;
	private String etapa;
	private String numeroEc;
	private String numeroLogico;
	private String notificacaoGtec;
	private String critica;
	private String problema;
	private String dddTelefone;
	private String horaInicial;
	private String horaFinal;
	
	
	/**
	 * @return the ferramenta
	 */
	public String getFerramenta() {
		ferramenta = ferramenta.equals("3")?"SITE":ferramenta.equals("4")?"SMART":"OUTROS";
		return ferramenta;
	}
	/**
	 * @param ferramenta the ferramenta to set
	 */
	public void setFerramenta(String ferramenta) {
		this.ferramenta = ferramenta;
	}
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}
	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	/**
	 * @return the data
	 */
	public String getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(String data) {
		this.data = data;
	}
	/**
	 * @return the etapa
	 */
	public String getEtapa() {
		return etapa;
	}
	/**
	 * @param etapa the etapa to set
	 */
	public void setEtapa(String etapa) {
		this.etapa = etapa;
	}
	/**
	 * @return the numeroEc
	 */
	public String getNumeroEc() {
		return numeroEc;
	}
	/**
	 * @param numeroEc the numeroEc to set
	 */
	public void setNumeroEc(String numeroEc) {
		this.numeroEc = numeroEc;
	}
	/**
	 * @return the numeroLogico
	 */
	public String getNumeroLogico() {
		return numeroLogico;
	}
	/**
	 * @param numeroLogico the numeroLogico to set
	 */
	public void setNumeroLogico(String numeroLogico) {
		this.numeroLogico = numeroLogico;
	}
	/**
	 * @return the notificacaoGtec
	 */
	public String getNotificacaoGtec() {
		return notificacaoGtec;
	}
	/**
	 * @param notificacaoGtec the notificacaoGtec to set
	 */
	public void setNotificacaoGtec(String notificacaoGtec) {
		this.notificacaoGtec = notificacaoGtec;
	}
	/**
	 * @return the critica
	 */
	public String getCritica() {
		return critica;
	}
	/**
	 * @param critica the critica to set
	 */
	public void setCritica(String critica) {
		this.critica = critica;
	}
	/**
	 * @return the problema
	 */
	public String getProblema() {
		return problema;
	}
	/**
	 * @param problema the problema to set
	 */
	public void setProblema(String problema) {
		this.problema = problema;
	}
	/**
	 * @return the hora
	 */
	public String getHora() {
		return hora;
	}
	/**
	 * @param hora the hora to set
	 */
	public void setHora(String hora) {
		this.hora = hora;
	}
	/**
	 * @return the dddTelefone
	 */
	public String getDddTelefone() {
		return dddTelefone;
	}
	/**
	 * @param dddTelefone the dddTelefone to set
	 */
	public void setDddTelefone(String dddTelefone) {
		this.dddTelefone = dddTelefone;
	}
	/**
	 * @return the horaInicial
	 */
	public String getHoraInicial() {
		return horaInicial;
	}
	/**
	 * @param horaInicial the horaInicial to set
	 */
	public void setHoraInicial(String horaInicial) {
		this.horaInicial = horaInicial;
	}
	/**
	 * @return the horaFinal
	 */
	public String getHoraFinal() {
		return horaFinal;
	}
	/**
	 * @param horaFinal the horaFinal to set
	 */
	public void setHoraFinal(String horaFinal) {
		this.horaFinal = horaFinal;
	}
	
	
}
