package br.com.cielo.crd.mobile.enums;

/**
 * Enum para controle das etapas de validação na ativação mobile
 * @author @Cielo
 */
public enum ValidacaoEnum {

	VALIDAR_CPF_CNPJ("CRD","VALIDAR CPF CNPJ"), 
	VALIDAR_MAIORIDADE("CRD","VALIDAR MAIORIDADE"), 
	VERIFICAR_EXISTENCIA_CLIENTE("SEC","VERIFICAR EXISTENCIA CLIENTE"), 
	VERIFICAR_EXISTENCIA_DOMICILIO_BANCARIO("SEC","VERIFICAR EXISTENCIA DOMICILIO BANCARIO"), 
	VALIDAR_DOMICILO_BANCARIO("SEC","VALIDAR DOMICILIO BANCARIO");
	
	private String origem;
	private String servico;
	
	private ValidacaoEnum(String origem, String servico){
		this.origem = origem;
		this.servico = servico;
	}

	/**
	 * @return the origem
	 */
	public String getOrigem() {
		return origem;
	}

	/**
	 * @return the servico
	 */
	public String getServico() {
		return servico;
	}
	
	
}
