package br.com.cielo.crd.mobile.model.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * Model solucao de captura para a ativação mobile
 * @author @Cielo SA
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class SolucaoCapturaType implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(required = true)
    private Integer codigoSolucaoCaptura;

    public Integer getCodigoSolucaoCaptura() {
        return codigoSolucaoCaptura;
    }

    public void setCodigoSolucaoCaptura(final Integer codigoSolucaoCaptura) {
        this.codigoSolucaoCaptura = codigoSolucaoCaptura;
    }

}
