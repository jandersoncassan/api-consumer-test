package br.com.cielo.crd.mobile.model;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

import br.com.cielo.crd.mobile.model.common.DadosProprietarioType;
import br.com.cielo.crd.mobile.model.common.DomicilioBancarioType;
import br.com.cielo.crd.mobile.model.common.EnderecoType;
import br.com.cielo.crd.mobile.model.common.EstabelecimentoComercialType;
import br.com.cielo.crd.mobile.model.common.SolucaoCapturaType;
import br.com.cielo.crd.mobile.model.common.TelefoneType;

/**
 * Representa a requisição do serviço de ativação mobile.
 * @author @Cielo SA
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class AtivacaoMobileRequest implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@XmlElement(required = true)
    private Integer codigoFerramenta;

	@XmlElement(required = true)
    private String numeroCpfCnpj;

	@XmlElement(required = true)
    private String tipoPessoa;    
	
	@XmlElement(required = true)
    private Integer codigoAfiliador;

    @XmlElement(name = "estabelecimentoComercial", required = true)
    private EstabelecimentoComercialType estabelecimentoComercial;
    
    @XmlElement(name = "domicilioBancario", required = true)
    private DomicilioBancarioType domicilioBancario;

    @XmlElement(name = "solucaoCaptura", required = true)
    private SolucaoCapturaType tiposSolucaoCaptura;

    @XmlElementWrapper(name = "enderecos", required = true)
    @XmlElement(name = "endereco", required = true)
    private List<EnderecoType> enderecoEstabelecimento;

    @XmlElementWrapper(name = "telefones", required = true)
    @XmlElement(name = "telefone", required = true)
    private List<TelefoneType> telefonesEstabelecimento;

    @XmlElementWrapper(name = "proprietarios", required = true)
    @XmlElement(name = "proprietario", required = true)
    private List<DadosProprietarioType> listaProprietarios;

	/**
	 * @return the codigoFerramenta
	 */
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}

	/**
	 * @param codigoFerramenta the codigoFerramenta to set
	 */
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
	}

	/**
	 * @return the numeroCpfCnpj
	 */
	public String getNumeroCpfCnpj() {
		return numeroCpfCnpj;
	}

	/**
	 * @param numeroCpfCnpj the numeroCpfCnpj to set
	 */
	public void setNumeroCpfCnpj(String numeroCpfCnpj) {
		this.numeroCpfCnpj = numeroCpfCnpj;
	}

	/**
	 * @return the tipoPessoa
	 */
	public String getTipoPessoa() {
		return tipoPessoa;
	}

	/**
	 * @param tipoPessoa the tipoPessoa to set
	 */
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	/**
	 * @return the estabelecimentoComercial
	 */
	public EstabelecimentoComercialType getEstabelecimentoComercial() {
		return estabelecimentoComercial;
	}

	/**
	 * @param estabelecimentoComercial the estabelecimentoComercial to set
	 */
	public void setEstabelecimentoComercial(EstabelecimentoComercialType estabelecimentoComercial) {
		this.estabelecimentoComercial = estabelecimentoComercial;
	}

	/**
	 * @return the domicilioBancario
	 */
	public DomicilioBancarioType getDomicilioBancario() {
		return domicilioBancario;
	}

	/**
	 * @param domicilioBancario the domicilioBancario to set
	 */
	public void setDomicilioBancario(DomicilioBancarioType domicilioBancario) {
		this.domicilioBancario = domicilioBancario;
	}

	/**
	 * @return the tiposSolucaoCaptura
	 */
	public SolucaoCapturaType getTiposSolucaoCaptura() {
		return tiposSolucaoCaptura;
	}

	/**
	 * @param tiposSolucaoCaptura the tiposSolucaoCaptura to set
	 */
	public void setTiposSolucaoCaptura(SolucaoCapturaType tiposSolucaoCaptura) {
		this.tiposSolucaoCaptura = tiposSolucaoCaptura;
	}

	/**
	 * @return the enderecoEstabelecimento
	 */
	public List<EnderecoType> getEnderecoEstabelecimento() {
		return enderecoEstabelecimento;
	}

	/**
	 * @param enderecoEstabelecimento the enderecoEstabelecimento to set
	 */
	public void setEnderecoEstabelecimento(List<EnderecoType> enderecoEstabelecimento) {
		this.enderecoEstabelecimento = enderecoEstabelecimento;
	}

	/**
	 * @return the telefonesEstabelecimento
	 */
	public List<TelefoneType> getTelefonesEstabelecimento() {
		return telefonesEstabelecimento;
	}

	/**
	 * @param telefonesEstabelecimento the telefonesEstabelecimento to set
	 */
	public void setTelefonesEstabelecimento(List<TelefoneType> telefonesEstabelecimento) {
		this.telefonesEstabelecimento = telefonesEstabelecimento;
	}

	/**
	 * @return the listaProprietarios
	 */
	public List<DadosProprietarioType> getListaProprietarios() {
		return listaProprietarios;
	}

	/**
	 * @param listaProprietarios the listaProprietarios to set
	 */
	public void setListaProprietarios(List<DadosProprietarioType> listaProprietarios) {
		this.listaProprietarios = listaProprietarios;
	}

	/**
	 * @return the codigoAfiliador
	 */
	public Integer getCodigoAfiliador() {
		return codigoAfiliador;
	}

	/**
	 * @param codigoAfiliador the codigoAfiliador to set
	 */
	public void setCodigoAfiliador(Integer codigoAfiliador) {
		this.codigoAfiliador = codigoAfiliador;
	}

}
