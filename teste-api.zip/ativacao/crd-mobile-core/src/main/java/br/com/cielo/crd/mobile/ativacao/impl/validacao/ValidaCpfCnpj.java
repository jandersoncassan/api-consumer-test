package br.com.cielo.crd.mobile.ativacao.impl.validacao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.ValidacaoService;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.ValidacaoMobile;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

@ValidacaoMobile(etapa=ValidacaoEnum.VALIDAR_CPF_CNPJ)
public class ValidaCpfCnpj extends ValidacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(ValidaCpfCnpj.class);

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosValidacao) {
		LOG.debug("INIT VALIDACAO CPF CNPJ");
		AtivacaoMobile retorno =  new AtivacaoMobile();
		popularInfoValidacao(retorno, ValidacaoEnum.VALIDAR_CPF_CNPJ);
		//INIT Verificar Existência Domicilio Bancario
		init(dadosValidacao, retorno);
		return retorno;
	}

	/**
	 * Método responsavel pela validação do CPF / CNPJ
	 * @param dadosValidacao
	 */
	private void init(AtivacaoMobileRequest dadosValidacao, AtivacaoMobile retorno) {
		if(dadosValidacao.getNumeroCpfCnpj().isEmpty())
			dadosValidacao.setNumeroCpfCnpj("0");
		validarCpfCnpj(dadosValidacao.getTipoPessoa(), dadosValidacao.getNumeroCpfCnpj(), retorno);
	}

	/**
 	 * Método responsavel pela validação do Cpf/Cnpj
 	 * @param tpPessoa
 	 * @param cpfCnpj
 	 * @return AtivacaoMobileResponse
 	 */
 	private void validarCpfCnpj(String tpPessoa, String cpfCnpj, AtivacaoMobile retorno){
 		retorno.setIsEtapaValida(Boolean.TRUE);
 		if(tpPessoa.equals("F")){
             validarCpf(cpfCnpj, retorno);
 		}else{
 			 validarCnpj(cpfCnpj, retorno);
 		}
 	}
 	
 	/**
 	 * Método responsavel pela validação do CPF
 	 * @param numCpf
 	 * @return AtivacaoMobileResponse
 	 */
 	private void validarCpf(String numCpf, AtivacaoMobile retorno){ 	
 		Boolean cpfLength = validarCpfCnpjLength("CPF",numCpf);
 		if(cpfLength){ 			
 			Boolean isCpfValido = CrdMobileUtils.verifSeqNumRepetidosCpf(numCpf);
 			if(!isCpfValido){
 				isCpfValido = CrdMobileUtils.validarCpf(numCpf);
 				if(!isCpfValido){
 					popularRetorno(retorno, "CPF INVALIDO");
 				}
 			}else{
 				popularRetorno(retorno, "CPF INVALIDO SEQUENCIA DE CARACTERES REPETIDAS");
 			}
 		}else{
 			popularRetorno(retorno, "CPF INVALIDO TAMANHO DIFERENTE DE 11 DIGITOS");
 		}
 	}
 	
 	
 	
 	/**
 	 * Método responsavel pela validação CNPJ
 	 * @param numCnpj
 	 * @return AtivacaoMobileResponse
 	 */
	private void validarCnpj(String numCnpj, AtivacaoMobile retorno){ 	
		Boolean cpfLength = validarCpfCnpjLength("CNPJ",numCnpj);
 		if(cpfLength){ 	
	 		Boolean isCnpjValido = CrdMobileUtils.verifSeqNumRepetidosCnpj(numCnpj);
	 		if(!isCnpjValido){
	 			isCnpjValido = CrdMobileUtils.validarCnpj(numCnpj);
	 			if(!isCnpjValido){
	 				popularRetorno(retorno, "CNPJ INVALIDO");
	 			}
	 		}else{
	 			popularRetorno(retorno, "CNPJ INVALIDO SEQUENCIA DE CARACTERES REPETIDAS"); 			
	 		}
 		}else{
 			popularRetorno(retorno, "CNPJ INVALIDO TAMANHO DIFERENTE DE 14 DIGITOS"); 			
 		}
 	}

	/**
	 * Método responsavel por verificar a quantidade de caracteres do cpfcnpj
	 * @param tipo
	 * @param numCpfCnpj
	 * @return Boolean
	 */
	private Boolean validarCpfCnpjLength(String tipo, String numCpfCnpj){
		if(tipo.equals("CPF")){
			return numCpfCnpj.length() == CrdMobileUtils.NUM_ONZE;
		}else{
			return numCpfCnpj.length() == CrdMobileUtils.NUM_QUATORZE;
		}
	}	
	
	/**
	 * Método responsavel por popular a mensagem de tratamento Cpf/Cnpj
	 * @param mensagem
	 * @return AtivacaoMobile
	 */
	private AtivacaoMobile popularRetorno(AtivacaoMobile retorno, String mensagem){
		retorno.setIsEtapaValida(Boolean.FALSE);
		retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
		retorno.setMensagem(mensagem);
		return retorno;
	}

}
