package br.com.cielo.crd.mobile.ativacao.impl.ativar;

import java.math.BigInteger;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.AtivacaoService;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.common.EnderecoType;
import br.com.cielo.crd.mobile.model.common.TelefoneType;
import br.com.cielo.crd.mobile.qualifier.AtivarMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteRequest;

@AtivarMobile(etapa=AtivacaoEnum.INCLUIR_EC_REDES)
public class InclusaoClienteRedes extends AtivacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(InclusaoClienteRedes.class);
	
	@Inject
	private ServicosOsb service;

	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		LOG.debug("INIT INCLUSAO CLIENTE REDES");
		popularInfoValidacao(retorno, AtivacaoEnum.INCLUIR_EC_REDES);
		init(dadosAtivacao, retorno);
		return retorno;
	}

	/**
	 * Método responsavel pela inclusão do cliente em Redes
	 * @param dadosAtivacao
	 * @param retorno
	 */
	private void init(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno) {
		IncluirClienteRequest request = popularRequest(dadosAtivacao, retorno);
		incluirCliente(request, retorno);
	}
	

	/**
	 * Método responsavel pela inclusão de cliente em Redes
	 * @param request
	 */
	private void incluirCliente(IncluirClienteRequest request, AtivacaoMobile retorno) {		
		try {
			 CrdMobileUtils.deflate("CADASTRAR EC REDES", request);
			 service.incluirClienteRedes(request);
			 retorno.setIsEtapaValida(Boolean.TRUE);		
		} catch (Exception e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}
	}
	
	/**
	 * Método responsavel por popular as informações de request
	 * @param dadosAtivacao
	 * @param retorno
	 * @return IncluirClienteRequest
	 */
	 private IncluirClienteRequest popularRequest(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno){
		IncluirClienteRequest request = new IncluirClienteRequest();
		//FERRAMENTA - CRD
		request.setFerramentaOrigemChamada(CrdMobileUtils.CRD);
		//PARAMETRO FIXO 0001 -- CONFORME INFORMAÇÕES DO SWENSON (REDES)
		request.setLojaEstabelecimentoComercial(new BigInteger(String.valueOf(CrdMobileUtils.NUM_UM)));
		request.setTipoTecnologia(CrdMobileUtils.MOBILE);
		request.setIndicadorCartaoPresente(Boolean.FALSE); //?
		request.setStatusEC(CrdMobileUtils.OPEN);
		request.setMotivoStatusEC(CrdMobileUtils.STRING_EMPTY);
		request.setIndicadorCartaoInternacional(Boolean.FALSE);
		request.setIndicadorVendaCartaoInternacional(Boolean.FALSE);
		//FLAG PARA HABILITAR VENDA DIGITADA EM REDES 'S'
		request.setIndicadorVendaDigitada(Boolean.TRUE);
		//PARAMETRO FIXO C -- CONFORME INFORMAÇÕES DO SWENSON (REDES)
		request.setIndicadorInformacoesCompletas(CrdMobileUtils.COMPLETA);
		//INFORMACOES DO CLIENTE
		request.setCodigoCliente(retorno.getNumeroEC());
		popularInformacoesCliente(request, dadosAtivacao);
		//INFORMACOES DE ENDERECO
		popularEndereco(request, dadosAtivacao.getEnderecoEstabelecimento());
		//INFORMACOES DE TELEFONE
		popularTelefone(request, dadosAtivacao.getTelefonesEstabelecimento());
		return request;
	}
	
	/**
	 * Método responsavel por popular as informações de endereço
	 * @param request
	 * @param enderecoEstabelecimento
	 */
	private void popularEndereco(IncluirClienteRequest request,	List<EnderecoType> enderecoEstabelecimento) {		
		 for (EnderecoType endereco : enderecoEstabelecimento) {
			 	//CODIGO ENDERECO == 2 - COMERCIAL
	            if (endereco.getCodigoTipoEndereco() == CrdMobileUtils.NUM_DOIS) {
	            	String logradouro = endereco.getLogradouro().toUpperCase().concat(CrdMobileUtils.SEPARADOR_VIRGULA_ESPACO).concat(endereco.getNumeroLogradouro());
	                logradouro = logradouro.length() > 40 ?logradouro.substring(0,40): logradouro;
	            	request.setLogradouro(logradouro);
	            	request.setCep(String.valueOf(endereco.getNumeroCep()));
	            	String cidade = endereco.getCidade().toUpperCase();
	            	request.setCidade(cidade.length()>40?cidade.substring(0, 40):cidade);
	            	request.setSiglaUF(endereco.getSiglaEstado().toUpperCase());
	            	//BAIRRO PASSAMOS O COMPLEMENTO
	            	String bairro = endereco.getComplemento().toUpperCase();
	            	request.setBairro(bairro.length()>20?bairro.substring(0, 20):bairro);
	            	break;
	            }
	       }
	}

	/**
	 * Método responsavel por popular as informações de telefone
	 * @param request
	 * @param telefonesEstabelecimento
	 */
	private void popularTelefone(IncluirClienteRequest request,	List<TelefoneType> telefonesEstabelecimento) {
		 for(TelefoneType telefone : telefonesEstabelecimento){
			 //CODIGO TELEFONE == 2 - COMERCIAL
			 if(telefone.getCodigoTipoTelefone() == CrdMobileUtils.NUM_DOIS){
				 request.setDddNumeroTelefone(new BigInteger(String.valueOf(telefone.getNumeroDdd())));
				 request.setNumeroTelefone(new BigInteger(String.valueOf(telefone.getNumeroTelefone())));
				 break;
			 }
		 }
	}

	/**
	 * Método responsavel por popular as informações do cliente
	 * @param dadosAtivacao
	 * @return Cliente
	 */
	private void popularInformacoesCliente(IncluirClienteRequest request, AtivacaoMobileRequest dadosAtivacao){
		String descCompletaEc = dadosAtivacao.getEstabelecimentoComercial().getNomeRazaoSocial().toUpperCase();
		request.setDescricaoCompletaEC(descCompletaEc.length()>40?descCompletaEc.substring(0,40):descCompletaEc);
		String nomePlaqueta = dadosAtivacao.getEstabelecimentoComercial().getNomePlaqueta().toUpperCase();
		request.setDescricaoResumidaEC(nomePlaqueta.length() > 10 ? nomePlaqueta.substring(0, 10) : nomePlaqueta);//LIMITE DE 10 CARACTERES EM REDES
		request.setTipoPessoa(dadosAtivacao.getTipoPessoa());
		request.setNumeroCPFCNPJ(BigInteger.valueOf(Long.valueOf(dadosAtivacao.getNumeroCpfCnpj())));
		if(dadosAtivacao.getTipoPessoa().equals(CrdMobileUtils.JURIDICA)){
			request.setCodigoRamoAtividade(new BigInteger(String.valueOf(8999)));			
		}else{
			request.setCodigoRamoAtividade(new BigInteger(String.valueOf(dadosAtivacao.getEstabelecimentoComercial().getCodigoRamoAtividade())));			
		}
	}
}	