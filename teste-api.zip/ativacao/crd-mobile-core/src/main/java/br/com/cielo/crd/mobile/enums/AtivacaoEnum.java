package br.com.cielo.crd.mobile.enums;

public enum AtivacaoEnum {

	INCLUIR_EC_SEC("SEC","INCLUIR EC SEC"), 
	HABILITAR_PRODUTOS("SEC","HABILITAR PRODUTOS"), 
	HABILITAR_SERVICOS("SEC","HABILITAR SERVICOS"),
	INCLUIR_EC_REDES("REDES","INCLUIR EC REDES"),
	GERAR_NUMERO_LOGICO("REDES","GERAR NUMERO LOGICO"),
	NOTIFICAR_GTEC_NUM_LOGICO("SEC","NOTIFICAR GTEC NUMERO LOGICO"),
	NOTIFICAR_ABERTURA_EVENTO_MOBILE_SEC("SEC","ABERTURA DE EVENTO MOBILE SEC");
	
	private String origem;
	private String servico;

	private AtivacaoEnum(String origem, String servico){
		this.origem = origem;
		this.servico = servico;
	}

	/**
	 * @return the origem
	 */
	public String getOrigem() {
		return origem;
	}

	/**
	 * @return the servico
	 */
	public String getServico() {
		return servico;
	}

}
