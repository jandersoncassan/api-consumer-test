package br.com.cielo.crd.mobile.ativacao.impl.validacao;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.ValidacaoService;
import br.com.cielo.crd.mobile.enums.MensagemDomicilioEnum;
import br.com.cielo.crd.mobile.enums.TipoContaEnum;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.common.DomicilioBancarioType;
import br.com.cielo.crd.mobile.qualifier.ValidacaoMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaResponse;

@ValidacaoMobile(etapa=ValidacaoEnum.VALIDAR_DOMICILO_BANCARIO)
public class ValidaDomicilioBancario extends ValidacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(ValidaDomicilioBancario.class);
	
	@Inject
	private ServicosOsb service;
	
	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosValidacao) {
		LOG.debug("INIT VALIDACAO DOMICILIO BANCARIO");
		AtivacaoMobile retorno =  new AtivacaoMobile();
		popularInfoValidacao(retorno, ValidacaoEnum.VALIDAR_DOMICILO_BANCARIO);
		//INIT Verificar Existência Domicilio Bancario
		init(dadosValidacao.getDomicilioBancario(), retorno);
		return retorno;
	}
	

	/**
	 * Método inicial para verificar se o cliente já existe no SEC
	 * @param dadosValidacao
	 * @return AtivacaoMobile
	 */ 
	private void init(DomicilioBancarioType dadosDomicilio, AtivacaoMobile retorno){		
		try {
			String codBanco = dadosDomicilio.getCodigoBanco();
			BigInteger codAgencia = BigInteger.valueOf(Long.valueOf(dadosDomicilio.getNumeroAgencia()));
			String numeroConta = dadosDomicilio.getNumeroConta(); 
			String tipoConta = dadosDomicilio.getTipoConta();

			ValidarDigitoAgenciaContaResponse response = service.validarDomicilioBancario(codBanco, codAgencia, numeroConta, tipoConta);
			consistirDomicilioBancario(response, retorno, dadosDomicilio.getTipoConta());
		} catch (MalformedURLException | RemoteException | ServiceException e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}
	}


	/**
	 * Método responsavel pelas consistencia da validação do servico de domicilio Bancario
	 * @param response
	 */
	private void consistirDomicilioBancario(ValidarDigitoAgenciaContaResponse response, AtivacaoMobile retorno, String tipoConta){
		if(response.isIndicadorDigitoValido()){
			retorno.setIsEtapaValida(Boolean.TRUE);
		}else{
			retorno.setIsEtapaValida(Boolean.FALSE);
			switch(response.getCodigoStatusProcessamento().intValue()){
			    case CrdMobileUtils.NUM_TREZE:
			    	retorno.setMensagem(MensagemDomicilioEnum.BANCO_NAO_ASSOCIADO.getDescricao());
			    	retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
			    	break;
			    case CrdMobileUtils.NUM_QUATORZE :
				    retorno.setMensagem(MensagemDomicilioEnum.BANCO_INVALIDO.getDescricao());
			    	retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
				    break;
			    case CrdMobileUtils.NUM_QUINZE :
				    retorno.setMensagem(MensagemDomicilioEnum.AGENCIA_INVALIDA.getDescricao());
			    	retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
				    break;
				case CrdMobileUtils.NUM_DEZESSEIS :
					if(tipoConta.equals(TipoContaEnum.CONTA_CORRENTE.getCodigo())){
					    retorno.setMensagem(MensagemDomicilioEnum.CONTA_INVALIDA.getDescricao());
				    	retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
			    	}else{
			    		//CASO TIPO DE CONTA SEJA POUPANCA, NÃO REJEITAMOS A PROPOSTA POR CONTA INVÁLIDA
			    		retorno.setIsEtapaValida(Boolean.TRUE);
			    	}
				    break;			
			}
		}
	}
	
}
