package br.com.cielo.crd.mobile.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.EtapaMobileService;
import br.com.cielo.crd.mobile.enums.EtapasAtivacaoMobileEnum;
import br.com.cielo.crd.mobile.enums.StatusAtivacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.AtivacaoMobileResponse;
import br.com.cielo.crd.mobile.model.common.MensagemType;
import br.com.cielo.crd.mobile.model.common.TelefoneType;
import br.com.cielo.crd.mobile.qualifier.EtapaMobile;
import br.com.cielo.crd.mobile.service.AtivacaoMobileService;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

public class AtivacaoMobileServiceImpl implements AtivacaoMobileService{

    private static final Logger LOG = LoggerFactory.getLogger(AtivacaoMobileServiceImpl.class);

	private List<EtapaMobileService> listaEtapasMobile;

	@Inject @EtapaMobile(etapa=EtapasAtivacaoMobileEnum.VALIDACAO)
	private EtapaMobileService validacaoMobile;

	@Inject @EtapaMobile(etapa=EtapasAtivacaoMobileEnum.ATIVACAO)
	private EtapaMobileService ativacaoMobile;

	/**
	 * Método responsavel por iniciar as consistencias para ativação mobile
	 * @param ativacaoRequest
	 * @return AtivacaoMobileResponse
	 */
	@Override
	public AtivacaoMobileResponse initAtivarMobile(AtivacaoMobileRequest ativacaoRequest) {	
		CrdMobileUtils.limparCaracterEspecial(ativacaoRequest);
		return validar(ativacaoRequest);
	}
	
	/**
	 * Método responsavel pelas chamdas validaçãoes na ativação mobile
	 * @param ativacaoRequest
	 * @return AtivacaoMobileResponse
	 */
    private AtivacaoMobileResponse validar(AtivacaoMobileRequest ativacaoRequest){
    	AtivacaoMobile retorno = null;
    	String horaInicial = CrdMobileUtils.getHoraAtual();
    	for(EtapaMobileService etapa : listaEtapasMobile){
    		retorno = etapa.validar(ativacaoRequest);
    		if(!retorno.getIsEtapaValida()){
    			break;
    		}
    	  }
    	String horaFinal = CrdMobileUtils.getHoraAtual();
    	return popularResponse(retorno, ativacaoRequest, horaInicial, horaFinal);
    }

    /**
     * Método responsavel por popular as informações de retorno da ativação mobile
     * @param retorno
     * @return AtivacaoMobileResponse
     */
    private AtivacaoMobileResponse popularResponse(AtivacaoMobile retorno, AtivacaoMobileRequest ativacao, String horaInicial, String horaFinal){
    	AtivacaoMobileResponse response = new AtivacaoMobileResponse();
    	Integer codFerramenta = ativacao.getCodigoFerramenta();
    	String numCpfCnpj = ativacao.getNumeroCpfCnpj();
    	if(!retorno.getIsEtapaValida()){
    		if(retorno.getEtapaAtivacao().equals(EtapasAtivacaoMobileEnum.VALIDACAO) ||
    				(retorno.getEtapaAtivacao().equals(EtapasAtivacaoMobileEnum.ATIVACAO) && null == retorno.getNumeroEC())){    			
    			 popularResponseInsucesso(response, retorno, codFerramenta, numCpfCnpj);    			
    		} else {    			
    			popularResponseParcial(response, retorno, codFerramenta, numCpfCnpj);
     		}
    	}else  	
    		popularResponseSucesso(response, retorno, codFerramenta, numCpfCnpj, getTelefoneCelular(ativacao.getTelefonesEstabelecimento()), horaInicial, horaFinal);
    	
    	return response;
    }
 
    /**
     * Caso ocorra insucesso na ativacao populamos as informações no response
     * @param retorno
     * @param codFerramenta 
     * @param horaFinal 
     * @param horaInicial 
     * @param telefone 
     * @return AtivacaoMobileResponse
     */
    private void popularResponseSucesso(AtivacaoMobileResponse response, AtivacaoMobile retorno, Integer codFerramenta, String cpfCnpj, String telefone, String horaInicial, String horaFinal){
    	popularStatusAtivacao(response, StatusAtivacaoEnum.SUCESSO);
    	response.setNumeroEc(retorno.getNumeroEC());
    	response.setNumeroLogico(retorno.getNumeroLogico());
    	response.setDigNumLogico(retorno.getDigNumLogico());
    	registrarLog(StatusAtivacaoEnum.SUCESSO.getFlag(), retorno, codFerramenta, cpfCnpj, telefone, horaInicial, horaFinal);
    }

    /**
     * Caso ocorra insucesso na ativacao populamos as informações no response
     * @param retorno
     * @param codFerramenta 
     * @return AtivacaoMobileResponse
     */
    private void popularResponseInsucesso(AtivacaoMobileResponse response, AtivacaoMobile retorno, Integer codFerramenta, String cpfCnpj){
    	popularStatusAtivacao(response, StatusAtivacaoEnum.INSUCESSO);
		response.setMensagem(popularErrorAtivacao(retorno));
		registrarLog(StatusAtivacaoEnum.INSUCESSO.getFlag(), retorno, codFerramenta, cpfCnpj,null, null,null);
    }
    
    /**
     * Caso ocorra insucesso na ativacao populamos as informações no response
     * @param retorno
     * @param codFerramenta 
     * @return AtivacaoMobileResponse
     */
    private void popularResponseParcial(AtivacaoMobileResponse response, AtivacaoMobile retorno, Integer codFerramenta, String cpfCnpj){
    	popularStatusAtivacao(response, StatusAtivacaoEnum.PARCIAL);
    	response.setNumeroEc(retorno.getNumeroEC());
		if(null != retorno.getNumeroLogico()){
			response.setNumeroLogico(retorno.getNumeroLogico());
			response.setDigNumLogico(response.getDigNumLogico());
		}    		
		response.setMensagem(popularErrorAtivacao(retorno));
		registrarLog(StatusAtivacaoEnum.PARCIAL.getFlag(), retorno, codFerramenta, cpfCnpj,null, null,null);
    }
    
    /**
     * Método esponsavel por popular as informações do status na ativação mobile
     * @param AtivacaoMobileResponse
     */
    private void popularStatusAtivacao(AtivacaoMobileResponse response, StatusAtivacaoEnum status){
		response.setCodStatus(status.getCodigo());
		response.setDescStatus(status.getDescricao());
   }
   
    /**
     * Método esponsavel por popular as informações de erro na ativação mobile
     * @param retorno
     * @return ErrorType
     */
    private MensagemType popularErrorAtivacao(AtivacaoMobile retorno){
    	MensagemType erro = new MensagemType();
		erro.setSistemaOrigem(retorno.getOrigem());
		erro.setServico(retorno.getServico());
		erro.setTipoCritica(retorno.getTipoCritica());
		erro.setCodigo(retorno.getCodigoMensagem());
		erro.setMensagem(retorno.getMensagem());
		return erro;
    }
    
	/**
	 * Método responsavel por popular as implementações das etapas de ativacao mobile
	 */
 	@PostConstruct
 	private void addEtapaValidacao(){
 		if(null == listaEtapasMobile){
 			listaEtapasMobile = new ArrayList<EtapaMobileService>();
 		}
 		listaEtapasMobile.addAll(Arrays.asList(validacaoMobile, ativacaoMobile));
 	}
 	
 	/**
 	 * Método responsavel por registrar os logs da execução de ativação mobile
 	 * @param codFerramenta 
 	 * @param horaFinal 
 	 * @param horaInicial 
 	 * @param telefone 
 	 */
 	private void registrarLog(char flagTipo, AtivacaoMobile retorno, Integer codFerramenta, String cpfCnpj, String telefone, String horaInicial, String horaFinal){
 		LOG.info("|STATUS:" + flagTipo +
 				 ";FERRAMENTA:"+codFerramenta+
 				 ";CPF/CNPJ:" + cpfCnpj+
 				 ";DATA:"+ CrdMobileUtils.getDataAtual()+ 
 				 ";ETAPA:" + retorno.getServico() +
 				 ";NUMERO EC:" + retorno.getNumeroEC()+
 				 ";NUMERO LOGICO:" + tratarInfoNumLogico(retorno.getNumeroLogico(), retorno.getDigNumLogico())+
 				 ";GTEC:" + tratarAvisoGtec(retorno.getIsAvisoGtec())+
 				 ";CRITICA:" + retorno.getTipoCritica()+
 				 ";PROBLEMA:" +tratarMensagemProblema(retorno.getMensagem())+
 		 		 ";DDD_FONE:" +telefone+
 		 		 ";H_INICIAL-" +horaInicial+
 		 		 ";H_FINAL-" +horaFinal);
 	}
 	
 	/**
 	 * Método responsavel pelo tratamento do numero lógico
 	 * @param numeroLogico
 	 * @param digNumeroLogico
 	 * @return String
 	 */
 	private String tratarInfoNumLogico(Integer numeroLogico, Integer digNumeroLogico){
 		if(null != numeroLogico && null != digNumeroLogico){
 			return numeroLogico.toString().concat("-").concat(digNumeroLogico.toString());
 		}else if(null != numeroLogico && null == digNumeroLogico){
 			return numeroLogico.toString();
 		}else{
 			return null;
 		} 		
 	}
 	
 	/**
 	 * Método responsavel por verificar se o GTEC foi notificado sobre o numero lógico
 	 * @param isAvisoGtec
 	 * @return String
 	 */
 	private String tratarAvisoGtec(Boolean isAvisoGtec){
 		return isAvisoGtec?"SIM": "NAO";
 	}
 	
 	/**
 	 * Obtem o telefone celular informado
 	 * @return
 	 */
 	private String getTelefoneCelular(List<TelefoneType> telefones){
 		String numTelefone = "N/A";
 		for(TelefoneType telefone : telefones){
 			if(telefone.getCodigoTipoTelefone().equals(CrdMobileUtils.NUM_DOIS)){
 				numTelefone = String.valueOf("(").concat(telefone.getNumeroDdd().toString()).concat(") ").concat(telefone.getNumeroTelefone());
 				break;
 			}
 		}
 		return numTelefone;
 	}
 	
 	private String tratarMensagemProblema(String msgProblema){
 		if(null != msgProblema && msgProblema.contains("java.net.SocketTimeoutException")){
 			return "PROBLEMAS NA COMUNICACAO COM O PROVEDOR (SocketTimeoutException)";
 		}
 		return msgProblema;
 	}
 }
