package br.com.cielo.crd.mobile.ativacao.impl.validacao;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.ValidacaoService;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.ValidacaoMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;

@ValidacaoMobile(etapa = ValidacaoEnum.VERIFICAR_EXISTENCIA_CLIENTE)
public class VerificaExistenciaCliente extends ValidacaoService {

    private static final Logger LOG = LoggerFactory.getLogger(VerificaExistenciaCliente.class);

    @Inject
    private ServicosOsb service;

    @Override
    public AtivacaoMobile validar(AtivacaoMobileRequest dadosValidacao) {

        LOG.debug("INIT VALIDACAO VERIFICAR EXISTENCIA CLIENTE");
        AtivacaoMobile retorno = new AtivacaoMobile();
        popularInfoValidacao(retorno, ValidacaoEnum.VERIFICAR_EXISTENCIA_CLIENTE);
        // INIT Verificar Existência Cliente
        init(dadosValidacao.getNumeroCpfCnpj(), retorno);
        return retorno;
    }

    /**
     * Método inicial para verificar se o cliente já existe no SEC
     * 
     * @param dadosValidacao
     * @return AtivacaoMobile
     */
    private void init(String cpfCnpj, AtivacaoMobile retorno) {

        try {
            Boolean isClienteExistente = service.verificarExistenciaCliente(cpfCnpj);
            tratarRetorno(isClienteExistente, retorno);
        } catch (MalformedURLException | RemoteException | ServiceException e) {
            retorno.setIsEtapaValida(Boolean.FALSE);
            tratarFault(e, retorno);
        }
    }

    /**
     * Método responsavel por verificar as consistnecia de retorno do SEC
     * 
     * @param isClienteExistente
     * @param retorno
     */
    private void tratarRetorno(Boolean isClienteExistente, AtivacaoMobile retorno) {

        if (isClienteExistente) {
            retorno.setIsEtapaValida(Boolean.FALSE);
            retorno.setMensagem("CLIENTE EXISTENTE NO SEC");
            retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
        } else {
            retorno.setIsEtapaValida(Boolean.TRUE);
        }
    }

}
