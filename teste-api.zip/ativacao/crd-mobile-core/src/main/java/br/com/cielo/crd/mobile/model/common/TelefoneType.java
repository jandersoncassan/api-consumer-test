package br.com.cielo.crd.mobile.model.common;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * Model telefones estabelecimento comercial ativação mobile
 * @author @Cielo SA
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class TelefoneType implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(required = true)
    private Integer codigoTipoTelefone;//2-COMERCIAL <> 3-CELULAR
    
    @XmlElement(required = true)
    private Integer numeroDdd;
    
    @XmlElement(required = true)
    private String numeroTelefone;

    /**
     * @return the codigoTipoTelefone
     */
    public Integer getCodigoTipoTelefone() {
        return codigoTipoTelefone;
    }

    /**
     * @param codigoTipoTelefone the codigoTipoTelefone to set
     */
    public void setCodigoTipoTelefone(final Integer codigoTipoTelefone) {
        this.codigoTipoTelefone = codigoTipoTelefone;
    }

    /**
     * @return the numeroDdd
     */
    public Integer getNumeroDdd() {
        return numeroDdd;
    }

    /**
     * @param numeroDdd the numeroDdd to set
     */
    public void setNumeroDdd(final Integer numeroDdd) {
        this.numeroDdd = numeroDdd;
    }

    /**
     * @return the numeroTelefone
     */
    public String getNumeroTelefone() {
        return numeroTelefone;
    }

    /**
     * @param numeroTelefone the numeroTelefone to set
     */
    public void setNumeroTelefone(final String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

}
