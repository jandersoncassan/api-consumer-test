package br.com.cielo.crd.mobile.model.common;

import java.io.Serializable;
import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * Model dados dos proprietários ativação mobile
 * @author @Cielo SA
 */
@XmlAccessorType(XmlAccessType.FIELD)
public class DadosProprietarioType implements Serializable {

    private static final long serialVersionUID = 1L;

    @XmlElement(required = true)
    private String nome;
    
    @XmlElement(required = true)
    private String numeroCpf;
    
    @XmlElement(required = true)
    private Date dataNascimento;

    public String getNome() {
        return nome;
    }

    public void setNome(final String nome) {
        this.nome = nome;
    }

    public String getNumeroCpf() {
        return numeroCpf;
    }

    public void setNumeroCpf(final String numeroCpf) {
        this.numeroCpf = numeroCpf;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(final Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
}
