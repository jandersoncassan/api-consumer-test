package br.com.cielo.crd.mobile.ativacao;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.crd.mobile.enums.EtapasAtivacaoMobileEnum;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

/**
 * Classe abstrata responsavel pelas consistencias de validação da ativação mobile
 * @author @Cielo
 */
public abstract class ValidacaoService {

	private static final String BEA = "BEA";
	
	/**
	 * Método responsavel por iniciar as consistencias de validação na ativação mobile
	 * @param dadosValidacao
	 * @return AtivacaoMobile
	 */
	public abstract AtivacaoMobile validar(AtivacaoMobileRequest dadosValidacao);
	
	/**
	 * Método responsavel por popular as informações do serviço de validação
	 * @param retorno
	 * @param validacao
	 */
	public void popularInfoValidacao(AtivacaoMobile retorno, ValidacaoEnum validacao){
		retorno.setEtapaAtivacao(EtapasAtivacaoMobileEnum.VALIDACAO);
		retorno.setOrigem(validacao.getOrigem());
		retorno.setServico(validacao.getServico());

	}
	
	/**
	 * Método responsavel pelo tratamento da fault
	 * @param e
	 * @param retorno
	 */
	public  void tratarFault(Exception exception, AtivacaoMobile retorno){
		if(exception instanceof Fault){
			Fault fault = (Fault) exception;
			if(fault.getCodigo().startsWith(BEA)){
				popularCritica(retorno, fault.getCodigo(), fault.getDescricao(), TipoCritica.ERRO_SISTEMICO);
			}else{
				if(Integer.valueOf(fault.getCodigo()) > CrdMobileUtils.NUM_NOVENTA_MIL){
					if(Integer.valueOf(fault.getCodigo()).equals(CrdMobileUtils.NUM_NOVENTA_MIL_QUATRO)){
						popularCritica(retorno, fault.getCodigo(), "SEC FECHADO PARA PROCESSAMENTO", TipoCritica.ERRO_SISTEMICO);
					}else{
						popularCritica(retorno, fault.getCodigo(), fault.getDescricao(), TipoCritica.ERRO_SISTEMICO);
					}			
				}else{
					popularCritica(retorno, fault.getCodigo(), fault.getFaultString(), TipoCritica.CRITICA_NEGOCIO);
				}
			}			
		}else {
			retorno.setTipoCritica(TipoCritica.ERRO_SISTEMICO.getDescricao());
			retorno.setCodigoMensagem("9999");
			retorno.setMensagem("EXCEPTION FAULT SERVER");
		}
	}

	/**
	 * Método responsavel por popular as criticas
	 * @param retorno
	 * @param codErro
	 * @param mensagem
	 * @param tipoCritica
	 */
	private void popularCritica( AtivacaoMobile retorno, String codErro, String mensagem, TipoCritica tipoCritica){
		retorno.setTipoCritica(tipoCritica.getDescricao());
		retorno.setCodigoMensagem(codErro);
		retorno.setMensagem(mensagem);
	}
}
