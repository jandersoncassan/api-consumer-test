package br.com.cielo.crd.mobile.util;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.cielo.crd.mobile.ativacao.impl.ativar.InclusaoClienteRedes;
import br.com.cielo.crd.mobile.model.common.EstabelecimentoComercialType;

/**
 * Classe utilitária da ativação mobile
 * 
 * @author @Cielo
 */
public class CrdMobileUtils {

    private static final Logger LOG = LoggerFactory.getLogger(InclusaoClienteRedes.class);

    private static final ObjectMapper objectMapper = new ObjectMapper();

    // INFORMAÇÕES HEADER SERVIÇOS SOAP
    public static final String HEADER_USER = "tns.osb.header.user";

    public static final String HEADER_PASS = "tns.osb.header.pass";

    // ENDPOINT VALIDACAO
    public static final String ENDPOINT_VERIFICAR_EXISTENCIA_CLIENTE = "endpoint.verificar.existencia.cliente";

    public static final String ENDPOINT_VERIFICAR_EXISTENCIA_DOMICILIO = "endpoint.verificar.existencia.domicilio";

    public static final String ENDPOINT_VALIDAR_DOMICILIO_BANCARIO = "endpoint.validar.domicilio.bancario";

    // ENDPOINT ATIVACAO
    public static final String ENDPOINT_INCLUIR_CLIENTE_SEC = "endpoint.incluir.cliente.sec";

    public static final String ENDPOINT_HABILITAR_PRODUTOS = "endpoint.habilitar.produtos";

    public static final String ENDPOINT_HABILITAR_SERVICOS = "endpoint.habilitar.servicos";

    public static final String ENDPOINT_INCLUIR_CLIENTE_REDES = "endpoint.incluir.cliente.redes";

    public static final String ENDPOINT_GERACAO_NUMERO_LOGICO = "endpoint.geracao.numero.logico";

    public static final String ENDPOINT_NOTIFICAR_NUMERO_LOGICO_E_NOTIFICACAO_SEC = "endpoint.notificar.numero.logico.e.notificacao.sec";

    // EMAIL
    public static final String ENDPOINT_ENVIAR_EMAIL = "endpoint.enviar.email";

    public static final String TNS = "http://credenciamento.cielo.com.br/operacao/comercial/ativar_mobile/v1";

    public static final String ATVMOB = "ATVMOB";

    public static final String GRUPO_SOLUCAO_CAPTURA = "MOB";

    public static final String TIPO_TERMINAL = "XC";

    public static final String COD_MODELO_SOL_DEFINIDO = "B";

    public static final String SEPARADOR_VIRGULA = ",";

    public static final String SEPARADOR_PONTO_VIRGULA = ";";

    public static final String SEPARADOR_VIRGULA_ESPACO = ", ";

    // TIPO DE PESSOA
    public static final String FISICA = "F";

    public static final String JURIDICA = "J";

    // # NUMEROS //
    public static final String NUM_ZERO_STRING = "0";

    public static final int NUM_ZERO = 0;

    public static final int NUM_UM = 1;

    public static final int NUM_DOIS = 2;

    public static final int NUM_TRES = 3;

    public static final int NUM_CINCO = 5;

    public static final int NUM_NOVE = 9;

    public static final int NUM_ONZE = 11;

    public static final int NUM_DOZE = 12;

    public static final int NUM_TREZE = 13;

    public static final int NUM_QUATORZE = 14;

    public static final int NUM_QUINZE = 15;

    public static final int NUM_DEZESSEIS = 16;

    public static final int NUM_DEZOITO = 18;
    
    public static final int MENOS_DEZOITO = -18;

    public static final int NUM_NOVENTA_MIL = 90000;

    // SEC FECHADO
    public static final int NUM_NOVENTA_MIL_QUATRO = 90004;

    private static final int[] PESO_CPF = { 11, 10, 9, 8, 7, 6, 5, 4, 3, 2 };

    private static final int[] PESO_CNPJ = { 6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2 };

    public static final String CRD = "#CRD";

    public static final String CREDENCIAMENTO = "CRD";

    public static final long CODIGO_BANCO_CREDENCIAMENTO = 9999;

    // INFORMAÇÕES INCLUSÃO DO CLIENTE EM REDES
    public static final String TRES_ZEROS_UM = "0001";

    public static final String MOBILE = "MOB";

    public static final String COMPLETA = "C";

    public static final String STRING_EMPTY = "";

    public static final String OPEN = "O";

    /* FLAG 'E' HORARIO COMERCIAL */
    public static final String DESCRICAO_SOLUCAO_CAPTURA = "MOBILE";

    /* CONTROLE DE LOG REQUISICAO ATIVACAO */
    public static final String FLAG_S = "S";

    public static final String KEY_LOGGER = "habilitar.log";

    /* MENSAGENS RELATORIO MOBILE */
    private static final String TITULO_RELATORIO = "[CRD] Report Processamento Ativação Mobile : ";
    public static final String TITULO_CONSOLIDADO = TITULO_RELATORIO.concat("CONSOLIDADO");
    public static final String TITULO_PARCIAL = TITULO_RELATORIO.concat("PARCIAL");
    public static final String TITULO_INSUCESSO = TITULO_RELATORIO.concat("INSUCESSO");
    
    public static final String TOTAL = "Total Credenciamentos ";
    public static final String DATA = "Data : ";
    
    private static final String SEM_PROCESSAMENTO_MOBILE_STATUS = "Não houve processamento de ativação mobile com status ";
    public static final String SEM_PROCESSAMENTO_MOBILE_SUCESSO = SEM_PROCESSAMENTO_MOBILE_STATUS.concat("SUCESSO");
    public static final String SEM_PROCESSAMENTO_MOBILE_PARCIAL = SEM_PROCESSAMENTO_MOBILE_STATUS.concat("PARCIAL");
    public static final String SEM_PROCESSAMENTO_MOBILE_INSUCESSO = SEM_PROCESSAMENTO_MOBILE_STATUS.concat("INSUCESSO");
    
    public static final String SEM_PROCESSAMENTO_MOBILE = "Não houve processamento de ativação mobile nesta data!";
    public static final String MOBILE_FOOTER = "Esse é um email automático, por favor não responda essa mensagem";
    
    /**
     * Método responsavel por devolver a data atual
     * 
     * @return String
     */
    public static String getDataAtual() {

        Calendar date = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");
        return (sdf.format(date.getTime()));
    }

    /**
     * Método responsavel por devolver a data atual
     * 
     * @return String
     */
    public static String getDataDiaAnterior() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -1); 
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy");        
        return (sdf.format(calendar.getTime()));
    }

    /**
     * Método responsavel por devolver a hora atual
     * 
     * @return String
     */
    public static String getHoraAtual() {

        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        Date hora = Calendar.getInstance().getTime(); // Ou qualquer outra forma que tem
        return (sdf.format(hora));
    }

    /**
     * Método responsavel por verificar possui sequencia de numeros repetidos
     * 
     * @param cpf
     * @return boolean
     */
    public static boolean verifSeqNumRepetidosCpf(String cpf) {

        if (cpf == null || cpf.matches("^(0{11}|1{11}|2{11}|3{11}|4{11}|5{11}|6{11}|7{11}|8{11}|9{11})$")) {
            return true;
        }
        return false;
    }

    /**
     * Método responsavel por verificar possui sequencia de numeros repetidos
     * 
     * @param cnpj
     * @return boolean
     */
    public static boolean verifSeqNumRepetidosCnpj(String cnpj) {

        if (cnpj == null || cnpj.matches("^(0{14}|1{14}|2{14}|3{14}|4{14}|5{14}|6{14}|7{14}|8{14}|9{14})$")) {
            return true;
        }
        return false;
    }

    /**
     * Método responsavel pela validação do CPF
     * 
     * @param numeroCpf
     * @return boolean
     */
    public static boolean validarCpf(String numeroCpf) {

        Integer digito1 = calcularDigito(numeroCpf.substring(NUM_ZERO, NUM_NOVE), PESO_CPF);
        Integer digito2 = calcularDigito(numeroCpf.substring(NUM_ZERO, NUM_NOVE) + digito1, PESO_CPF);
        return numeroCpf.equals(numeroCpf.substring(NUM_ZERO, NUM_NOVE) + digito1.toString() + digito2.toString());
    }

    /**
     * Método responsavel pela validação do cnpj
     * 
     * @param cnpj
     * @return boolean
     */
    public static boolean validarCnpj(final String cnpj) {

        Integer digito1 = calcularDigito(cnpj.substring(NUM_ZERO, NUM_DOZE), PESO_CNPJ);
        Integer digito2 = calcularDigito(cnpj.substring(NUM_ZERO, NUM_DOZE) + digito1, PESO_CNPJ);
        return cnpj.equals(cnpj.substring(NUM_ZERO, NUM_DOZE) + digito1.toString() + digito2.toString());
    }

    /**
     * Método responsavel por calcular o digito Cpf/Cnpj
     * 
     * @param cpfCnpj
     * @param peso
     * @return int
     */
    private static int calcularDigito(final String cpfCnpj, final int[] peso) {

        int soma = NUM_ZERO;
        for (int indice = cpfCnpj.length() - NUM_UM, digito; indice >= NUM_ZERO; indice--) {
            digito = Integer.parseInt(cpfCnpj.substring(indice, indice + NUM_UM));
            soma += digito * peso[peso.length - cpfCnpj.length() + indice];
        }
        soma = NUM_ONZE - soma % NUM_ONZE;
        return soma > NUM_NOVE ? NUM_ZERO : soma;
    }

    /**
     * Método responsavel por gerar o json
     * 
     * @param object
     * @return byte[]
     * @throws IllegalArgumentException
     */
    public static byte[] deflate(String operacao, Object object) throws IllegalArgumentException {

        byte[] bytes = null;
        try {
            String json = objectMapper.writeValueAsString(object);
            bytes = json.getBytes();
            printLog(operacao, new String(bytes));
        } catch (JsonProcessingException e) {
        }
        return bytes;
    }

    /**
     * Print das informações de log
     * 
     * @param operacao
     * @param mensagem
     */
    private static void printLog(String operacao, String mensagem) {

        LOG.debug("-=-=-=-=-=-=-=-=>".concat(operacao).concat(" PAYLOAD : {}"), mensagem);
    }

    /**
     * Aplicar mascara CPF / CNPJ
     * 
     * @param cpfCnpj
     * @return
     */
    public static String formatarCpfCnpj(String cpfCnpj) {

        if (cpfCnpj.length() == 11) {
            return cpfCnpj.replaceAll("(\\d{3})(\\d{3})(\\d{3})(\\d{2})", "$1.$2.$3-$4");
        }
        return cpfCnpj.replaceAll("(\\d{2})(\\d{3})(\\d{3})(\\d{4})(\\d{2})", "$1.$2.$3/$4-$5");
    }
    
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void limparCaracterEspecial(Object objrequest){
		Field[] fields = objrequest.getClass().getDeclaredFields();
		try{
			for (Field field : fields) {
				Type type = field.getGenericType();
				
				if(isAssignableFrom(field.getType())){	
					field.setAccessible(true);
					Object obj = field.get(objrequest);
					tratarField(obj);
					
				}else if(isParameterizedType(type)){
					 field.setAccessible(true);
					 List<Object> listObject = (java.util.List) field.get(objrequest);
				     for(Object obj : listObject){
				    	 tratarField(obj);
				     }
				}
			}
		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO AO TRATAR OS CARACTERES ESPECIAIS", ex);
		}
	}
	
	/**
	 * Tratar objeto Establecimento Comercial
	 * @param clazz
	 * @return
	 */
	private static boolean isAssignableFrom(Class<?> clazz){
		return (clazz.isAssignableFrom(EstabelecimentoComercialType.class));
	}
	
	/**
	 * Tratar objeto List
	 * @param type
	 * @return
	 */
	private static boolean isParameterizedType(Type type){
		return (type instanceof ParameterizedType);
	}
	
	/**
	 * Tratamento campo a campo
	 * @param obj
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private static void tratarField(Object obj) throws IllegalArgumentException, IllegalAccessException{
		Field[] typeFields = obj.getClass().getDeclaredFields();
		 for (Field typeField : typeFields) {	
			 if(typeField.getType().isAssignableFrom(String.class)){
				 typeField.setAccessible(true);
				 String info = (String) typeField.get(obj);							 
				 info = regexInfo(info);							 
				 typeField.set(obj, info);
			 }
		 }
	}
	/**
	 * Método responsavel por limpar os caracteres especiais
	 * @param info
	 * @return
	 */
	private static String regexInfo(String info){
		 return info.replaceAll("[ãâàáä]",	"a")
				 .replaceAll("[êèéë&]",	"e")
				 .replaceAll("[îìíï]",	"i")
				 .replaceAll("[õôòóö]",	"o")
				 .replaceAll("[ûúùü]",	"u")
				 .replaceAll("[ÃÂÀÁÄ]",	"A")
				 .replaceAll("[ÊÈÉË]",	"E")
				 .replaceAll("[ÎÌÍÏ]",	"I")
				 .replaceAll("[ÕÔÒÓÖ]",	"O")
				 .replaceAll("[ÛÙÚÜ]",	"U")
				 .replace('ç',	'c')
				 .replace('Ç',	'C')
				 .replace('ñ',	'n')
				 .replace('Ñ',	'N')
				 .replaceAll("[^a-zA-Z0-9_\\-&@ ]", "");
	}

}
