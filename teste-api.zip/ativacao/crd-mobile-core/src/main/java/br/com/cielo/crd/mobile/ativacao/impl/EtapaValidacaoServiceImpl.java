package br.com.cielo.crd.mobile.ativacao.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.EtapaMobileService;
import br.com.cielo.crd.mobile.ativacao.ValidacaoService;
import br.com.cielo.crd.mobile.enums.EtapasAtivacaoMobileEnum;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.qualifier.EtapaMobile;
import br.com.cielo.crd.mobile.qualifier.ValidacaoMobile;

/**
 * Classe responsavel pela implementação das validações da ativação mobile
 * @author @Cielo
 */
@EtapaMobile(etapa=EtapasAtivacaoMobileEnum.VALIDACAO)
public class EtapaValidacaoServiceImpl implements EtapaMobileService{

	private static final Logger LOG = LoggerFactory.getLogger(EtapaValidacaoServiceImpl.class);
	
	private List<ValidacaoService> listaEtapasValidacao;

	@Inject @ValidacaoMobile(etapa=ValidacaoEnum.VALIDAR_CPF_CNPJ)
	private ValidacaoService validarCpfCnpj;

	@Inject @ValidacaoMobile(etapa=ValidacaoEnum.VALIDAR_MAIORIDADE)
	private ValidacaoService validarMaioridade;

	@Inject @ValidacaoMobile(etapa=ValidacaoEnum.VERIFICAR_EXISTENCIA_CLIENTE)
	private ValidacaoService verificarExistenciaCliente;

	@Inject @ValidacaoMobile(etapa=ValidacaoEnum.VALIDAR_DOMICILO_BANCARIO)
	private ValidacaoService validarDomicilioBancario;

	@Inject @ValidacaoMobile(etapa=ValidacaoEnum.VERIFICAR_EXISTENCIA_DOMICILIO_BANCARIO)
	private ValidacaoService verificarExistenciaDomBancario;

	/**
	 * Método responsavel pelas consisteências na etapa de VALIDAÇÃO da ativação mobile
     * @param retorno
     * @return AtivacaoMobileResponse
	 */
	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosValidacao) {
		LOG.debug("ETAPA VALIDACAO ATIVACAO MOBILE ");
		AtivacaoMobile retorno = null;
	   	for(ValidacaoService etapa : listaEtapasValidacao){
    		retorno = etapa.validar(dadosValidacao);
    		if(!retorno.getIsEtapaValida()){
    			break;
    		}
    	  }
	   	return retorno;
	}

	/**
	 * Método responsavel por popular as implementações das etapas de ativacao mobile
	 */
 	@PostConstruct
 	private void addEtapaValidacao(){
 		if(null == listaEtapasValidacao){
 			listaEtapasValidacao = new ArrayList<ValidacaoService>();
 		}
 		listaEtapasValidacao.addAll(Arrays.asList(validarCpfCnpj, validarMaioridade, verificarExistenciaCliente, validarDomicilioBancario, verificarExistenciaDomBancario));
 	}

}
