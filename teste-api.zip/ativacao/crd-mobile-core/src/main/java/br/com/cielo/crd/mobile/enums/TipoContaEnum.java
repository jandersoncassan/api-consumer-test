package br.com.cielo.crd.mobile.enums;

/**
 * Classe ENUM para tratamento do tipo de conta
 * @author @Cielo
 * @since 1.0.0
 */
public enum TipoContaEnum {

	CONTA_CORRENTE("0"), CONTA_POUPANCA("2");
	
	private String codigo;
	
	private TipoContaEnum(String codigo){
		this.codigo = codigo;
	}

	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	
	
	
}
