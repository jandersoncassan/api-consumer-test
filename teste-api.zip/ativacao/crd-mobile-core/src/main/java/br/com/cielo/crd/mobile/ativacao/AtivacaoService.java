package br.com.cielo.crd.mobile.ativacao;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.crd.mobile.enums.AtivacaoEnum;
import br.com.cielo.crd.mobile.enums.EtapasAtivacaoMobileEnum;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.util.CrdMobileUtils;

/**
 * Classe abstrata responsavel pelas consistencias de validação da ativação mobile
 * @author @Cielo
 */
public abstract class AtivacaoService {

	private static final String BEA = "BEA";
	
	private static final String SEC = "SEC";

	/**
	 * Método responsavel por iniciar as consistencias de validação na ativação mobile
	 * @param dadosValidacao
	 * @return AtivacaoMobile
	 */
	public abstract AtivacaoMobile validar(AtivacaoMobileRequest dadosAtivacao, AtivacaoMobile retorno);

	/**
	 * Método responsavel por popular as informações do serviço de validação
	 * @param retorno
	 * @param validacao
	 */
	public void popularInfoValidacao(AtivacaoMobile retorno, AtivacaoEnum validacao){
		retorno.setEtapaAtivacao(EtapasAtivacaoMobileEnum.ATIVACAO);
		retorno.setOrigem(validacao.getOrigem());
		retorno.setServico(validacao.getServico());
	}
	
	/**
	 * Método responsavel pelo tratamento da fault
	 * @param e
	 * @param retorno
	 */
	public  void tratarFault(Exception exception, AtivacaoMobile retorno){
		if(exception instanceof Fault){
			Fault fault = (Fault)exception;
			if(fault.getCodigo().startsWith(BEA) || !retorno.getOrigem().equals(SEC)){
				retorno.setTipoCritica(TipoCritica.ERRO_SISTEMICO.getDescricao());
				popularInfoFault(fault, retorno);
				
			}else if(retorno.getOrigem().equals(SEC)){
				if(Integer.valueOf(((Fault)exception).getCodigo()) > CrdMobileUtils.NUM_NOVENTA_MIL){
					retorno.setTipoCritica(TipoCritica.ERRO_SISTEMICO.getDescricao());
					popularInfoFault(fault, retorno);
				}else{
					retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
					popularInfoFault(fault, retorno);
				}
			}	
		}else {
			retorno.setTipoCritica(TipoCritica.ERRO_SISTEMICO.getDescricao());
			retorno.setCodigoMensagem("9999");
			retorno.setMensagem("EXCEPTION FAULT SERVER");
		}
	}
	
	/**
	 * Método responsavel por popular as informações da Fault
	 * @param fault
	 * @param retorno
	 */
	private void popularInfoFault(Fault fault, AtivacaoMobile retorno){
		retorno.setCodigoMensagem(fault.getCodigo());
		retorno.setMensagem(fault.getDescricao());
	}

	
}
