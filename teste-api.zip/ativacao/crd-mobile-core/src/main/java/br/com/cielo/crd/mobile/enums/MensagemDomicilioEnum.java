package br.com.cielo.crd.mobile.enums;

public enum MensagemDomicilioEnum {

	BANCO_NAO_ASSOCIADO(1, "BANCO NAO ASSOCIADO"), 
	BANCO_INVALIDO(2, "BANCO INVALIDO"), 
	AGENCIA_INVALIDA(3, "AGENCIA INVALIDA"), 
	CONTA_INVALIDA(4, "CONTA INVALIDA");
	
	private Integer codigo;
	private String descricao;
	
	private MensagemDomicilioEnum(Integer codigo, String descricao){
		this.codigo = codigo;
		this.descricao = descricao;
	}

	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	
}
