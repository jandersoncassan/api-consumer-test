package br.com.cielo.crd.mobile.ativacao.impl.validacao;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.crd.mobile.ativacao.ValidacaoService;
import br.com.cielo.crd.mobile.enums.TipoCritica;
import br.com.cielo.crd.mobile.enums.ValidacaoEnum;
import br.com.cielo.crd.mobile.model.AtivacaoMobile;
import br.com.cielo.crd.mobile.model.AtivacaoMobileRequest;
import br.com.cielo.crd.mobile.model.common.DomicilioBancarioType;
import br.com.cielo.crd.mobile.qualifier.ValidacaoMobile;
import br.com.cielo.crd.mobile.service.osb.ServicosOsb;

@ValidacaoMobile(etapa=ValidacaoEnum.VERIFICAR_EXISTENCIA_DOMICILIO_BANCARIO)
public class VerificaExistenciaDomicilioBancario extends ValidacaoService{

	private static final Logger LOG = LoggerFactory.getLogger(VerificaExistenciaDomicilioBancario.class);
	
	@Inject
	private ServicosOsb service;
	
	@Override
	public AtivacaoMobile validar(AtivacaoMobileRequest dadosValidacao) {
		LOG.debug("INIT VALIDACAO VERIFICAR EXISTENCIA DOMICILIO");
		AtivacaoMobile retorno =  new AtivacaoMobile();
		popularInfoValidacao(retorno, ValidacaoEnum.VERIFICAR_EXISTENCIA_DOMICILIO_BANCARIO);
		//INIT Verificar Existência Domicilio Bancario
		init(dadosValidacao.getDomicilioBancario(), retorno);
		return retorno;
	}
	

	/**
	 * Método inicial para verificar se o cliente já existe no SEC
	 * @param dadosValidacao
	 * @return AtivacaoMobile
	 */ 
	private void init(DomicilioBancarioType dadosDomicilio, AtivacaoMobile retorno){		
		try {
			BigInteger codBanco = BigInteger.valueOf(Long.valueOf(dadosDomicilio.getCodigoBanco()));
			BigInteger codAgencia = BigInteger.valueOf(Long.valueOf(dadosDomicilio.getNumeroAgencia()));
			String numeroConta = dadosDomicilio.getNumeroConta(); 
			String tipoConta = dadosDomicilio.getTipoConta();
			
			Boolean isDomicilioExistente = service.verificarExistenciaDomBancario(codBanco, codAgencia, numeroConta, tipoConta);
			consistirExistenciaDomicilio(isDomicilioExistente, retorno);
		} catch (MalformedURLException | RemoteException | ServiceException e) {
			retorno.setIsEtapaValida(Boolean.FALSE);
			tratarFault(e, retorno);
		}
	}
	
	/**
	 * Método responsavel pelo tratamento do retorno do servico
	 * @param isDomicilioExistente
	 * @param retorno
	 */
	private void consistirExistenciaDomicilio(Boolean isDomicilioExistente, AtivacaoMobile retorno){
		if(isDomicilioExistente){
			retorno.setIsEtapaValida(Boolean.FALSE);
			retorno.setTipoCritica(TipoCritica.CRITICA_NEGOCIO.getDescricao());
			retorno.setMensagem("DOMICILIO BANCARIO JA EXISTE");
		}else{
			retorno.setIsEtapaValida(Boolean.TRUE);
		}
		
		
	}
	
}
