/**
 * Codigo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1;

public class Codigo implements java.io.Serializable {
    private java.lang.String _value_;
    private static java.util.HashMap _table_ = new java.util.HashMap();

    // Constructor
    protected Codigo(java.lang.String value) {
        _value_ = value;
        _table_.put(_value_,this);
    }

    public static final java.lang.String _AED = "AED";
    public static final java.lang.String _AFN = "AFN";
    public static final java.lang.String _ALL = "ALL";
    public static final java.lang.String _AMD = "AMD";
    public static final java.lang.String _ANG = "ANG";
    public static final java.lang.String _AOA = "AOA";
    public static final java.lang.String _ARS = "ARS";
    public static final java.lang.String _AUD = "AUD";
    public static final java.lang.String _AWG = "AWG";
    public static final java.lang.String _AZN = "AZN";
    public static final java.lang.String _BAM = "BAM";
    public static final java.lang.String _BBD = "BBD";
    public static final java.lang.String _BDT = "BDT";
    public static final java.lang.String _BGN = "BGN";
    public static final java.lang.String _BHD = "BHD";
    public static final java.lang.String _BIF = "BIF";
    public static final java.lang.String _BMD = "BMD";
    public static final java.lang.String _BND = "BND";
    public static final java.lang.String _BOB = "BOB";
    public static final java.lang.String _BRL = "BRL";
    public static final java.lang.String _BSD = "BSD";
    public static final java.lang.String _BTN = "BTN";
    public static final java.lang.String _BWP = "BWP";
    public static final java.lang.String _BYR = "BYR";
    public static final java.lang.String _BZD = "BZD";
    public static final java.lang.String _CAD = "CAD";
    public static final java.lang.String _CDF = "CDF";
    public static final java.lang.String _CHF = "CHF";
    public static final java.lang.String _CLF = "CLF";
    public static final java.lang.String _CLP = "CLP";
    public static final java.lang.String _CNH = "CNH";
    public static final java.lang.String _CNY = "CNY";
    public static final java.lang.String _COP = "COP";
    public static final java.lang.String _CRC = "CRC";
    public static final java.lang.String _CUP = "CUP";
    public static final java.lang.String _CVE = "CVE";
    public static final java.lang.String _CZK = "CZK";
    public static final java.lang.String _DJF = "DJF";
    public static final java.lang.String _DKK = "DKK";
    public static final java.lang.String _DOP = "DOP";
    public static final java.lang.String _DZD = "DZD";
    public static final java.lang.String _EGP = "EGP";
    public static final java.lang.String _ERN = "ERN";
    public static final java.lang.String _ETB = "ETB";
    public static final java.lang.String _EUR = "EUR";
    public static final java.lang.String _FJD = "FJD";
    public static final java.lang.String _FKP = "FKP";
    public static final java.lang.String _GBP = "GBP";
    public static final java.lang.String _GEL = "GEL";
    public static final java.lang.String _GHS = "GHS";
    public static final java.lang.String _GIP = "GIP";
    public static final java.lang.String _GMD = "GMD";
    public static final java.lang.String _GNF = "GNF";
    public static final java.lang.String _GTQ = "GTQ";
    public static final java.lang.String _GWP = "GWP";
    public static final java.lang.String _GYD = "GYD";
    public static final java.lang.String _HKD = "HKD";
    public static final java.lang.String _HNL = "HNL";
    public static final java.lang.String _HRK = "HRK";
    public static final java.lang.String _HTG = "HTG";
    public static final java.lang.String _HUF = "HUF";
    public static final java.lang.String _IDR = "IDR";
    public static final java.lang.String _ILS = "ILS";
    public static final java.lang.String _INR = "INR";
    public static final java.lang.String _IQD = "IQD";
    public static final java.lang.String _IRR = "IRR";
    public static final java.lang.String _ISK = "ISK";
    public static final java.lang.String _JMD = "JMD";
    public static final java.lang.String _JOD = "JOD";
    public static final java.lang.String _JPY = "JPY";
    public static final java.lang.String _KES = "KES";
    public static final java.lang.String _KGS = "KGS";
    public static final java.lang.String _KHR = "KHR";
    public static final java.lang.String _KMF = "KMF";
    public static final java.lang.String _KPW = "KPW";
    public static final java.lang.String _KRW = "KRW";
    public static final java.lang.String _KWD = "KWD";
    public static final java.lang.String _KYD = "KYD";
    public static final java.lang.String _KZT = "KZT";
    public static final java.lang.String _LAK = "LAK";
    public static final java.lang.String _LBP = "LBP";
    public static final java.lang.String _LKR = "LKR";
    public static final java.lang.String _LRD = "LRD";
    public static final java.lang.String _LSL = "LSL";
    public static final java.lang.String _LTL = "LTL";
    public static final java.lang.String _LVL = "LVL";
    public static final java.lang.String _LYD = "LYD";
    public static final java.lang.String _MAD = "MAD";
    public static final java.lang.String _MDL = "MDL";
    public static final java.lang.String _MGA = "MGA";
    public static final java.lang.String _MKD = "MKD";
    public static final java.lang.String _MMK = "MMK";
    public static final java.lang.String _MNT = "MNT";
    public static final java.lang.String _MOP = "MOP";
    public static final java.lang.String _MRO = "MRO";
    public static final java.lang.String _MUR = "MUR";
    public static final java.lang.String _MVR = "MVR";
    public static final java.lang.String _MWK = "MWK";
    public static final java.lang.String _MXN = "MXN";
    public static final java.lang.String _MYR = "MYR";
    public static final java.lang.String _MZN = "MZN";
    public static final java.lang.String _NAD = "NAD";
    public static final java.lang.String _NGN = "NGN";
    public static final java.lang.String _NIO = "NIO";
    public static final java.lang.String _NOK = "NOK";
    public static final java.lang.String _NPR = "NPR";
    public static final java.lang.String _NZD = "NZD";
    public static final java.lang.String _OMR = "OMR";
    public static final java.lang.String _PAB = "PAB";
    public static final java.lang.String _PEN = "PEN";
    public static final java.lang.String _PGK = "PGK";
    public static final java.lang.String _PHP = "PHP";
    public static final java.lang.String _PKR = "PKR";
    public static final java.lang.String _PLN = "PLN";
    public static final java.lang.String _PYG = "PYG";
    public static final java.lang.String _QAR = "QAR";
    public static final java.lang.String _RON = "RON";
    public static final java.lang.String _RSD = "RSD";
    public static final java.lang.String _RUB = "RUB";
    public static final java.lang.String _RWF = "RWF";
    public static final java.lang.String _SAR = "SAR";
    public static final java.lang.String _SBD = "SBD";
    public static final java.lang.String _SCR = "SCR";
    public static final java.lang.String _SDG = "SDG";
    public static final java.lang.String _SDR = "SDR";
    public static final java.lang.String _SEK = "SEK";
    public static final java.lang.String _SGD = "SGD";
    public static final java.lang.String _SHP = "SHP";
    public static final java.lang.String _SLL = "SLL";
    public static final java.lang.String _SOS = "SOS";
    public static final java.lang.String _SRD = "SRD";
    public static final java.lang.String _SSP = "SSP";
    public static final java.lang.String _STD = "STD";
    public static final java.lang.String _SVC = "SVC";
    public static final java.lang.String _SYP = "SYP";
    public static final java.lang.String _SZL = "SZL";
    public static final java.lang.String _THB = "THB";
    public static final java.lang.String _TJS = "TJS";
    public static final java.lang.String _TMT = "TMT";
    public static final java.lang.String _TND = "TND";
    public static final java.lang.String _TOP = "TOP";
    public static final java.lang.String _TRY = "TRY";
    public static final java.lang.String _TTD = "TTD";
    public static final java.lang.String _TWD = "TWD";
    public static final java.lang.String _TZS = "TZS";
    public static final java.lang.String _UAH = "UAH";
    public static final java.lang.String _UGX = "UGX";
    public static final java.lang.String _USD = "USD";
    public static final java.lang.String _UYU = "UYU";
    public static final java.lang.String _UZS = "UZS";
    public static final java.lang.String _VEF = "VEF";
    public static final java.lang.String _VND = "VND";
    public static final java.lang.String _VUV = "VUV";
    public static final java.lang.String _WST = "WST";
    public static final java.lang.String _XAF = "XAF";
    public static final java.lang.String _XAU = "XAU";
    public static final java.lang.String _XCD = "XCD";
    public static final java.lang.String _XEU = "XEU";
    public static final java.lang.String _XOF = "XOF";
    public static final java.lang.String _XPF = "XPF";
    public static final java.lang.String _YER = "YER";
    public static final java.lang.String _ZAR = "ZAR";
    public static final java.lang.String _ZMW = "ZMW";
    public static final java.lang.String _ZWL = "ZWL";
    public static final Codigo AED = new Codigo(_AED);
    public static final Codigo AFN = new Codigo(_AFN);
    public static final Codigo ALL = new Codigo(_ALL);
    public static final Codigo AMD = new Codigo(_AMD);
    public static final Codigo ANG = new Codigo(_ANG);
    public static final Codigo AOA = new Codigo(_AOA);
    public static final Codigo ARS = new Codigo(_ARS);
    public static final Codigo AUD = new Codigo(_AUD);
    public static final Codigo AWG = new Codigo(_AWG);
    public static final Codigo AZN = new Codigo(_AZN);
    public static final Codigo BAM = new Codigo(_BAM);
    public static final Codigo BBD = new Codigo(_BBD);
    public static final Codigo BDT = new Codigo(_BDT);
    public static final Codigo BGN = new Codigo(_BGN);
    public static final Codigo BHD = new Codigo(_BHD);
    public static final Codigo BIF = new Codigo(_BIF);
    public static final Codigo BMD = new Codigo(_BMD);
    public static final Codigo BND = new Codigo(_BND);
    public static final Codigo BOB = new Codigo(_BOB);
    public static final Codigo BRL = new Codigo(_BRL);
    public static final Codigo BSD = new Codigo(_BSD);
    public static final Codigo BTN = new Codigo(_BTN);
    public static final Codigo BWP = new Codigo(_BWP);
    public static final Codigo BYR = new Codigo(_BYR);
    public static final Codigo BZD = new Codigo(_BZD);
    public static final Codigo CAD = new Codigo(_CAD);
    public static final Codigo CDF = new Codigo(_CDF);
    public static final Codigo CHF = new Codigo(_CHF);
    public static final Codigo CLF = new Codigo(_CLF);
    public static final Codigo CLP = new Codigo(_CLP);
    public static final Codigo CNH = new Codigo(_CNH);
    public static final Codigo CNY = new Codigo(_CNY);
    public static final Codigo COP = new Codigo(_COP);
    public static final Codigo CRC = new Codigo(_CRC);
    public static final Codigo CUP = new Codigo(_CUP);
    public static final Codigo CVE = new Codigo(_CVE);
    public static final Codigo CZK = new Codigo(_CZK);
    public static final Codigo DJF = new Codigo(_DJF);
    public static final Codigo DKK = new Codigo(_DKK);
    public static final Codigo DOP = new Codigo(_DOP);
    public static final Codigo DZD = new Codigo(_DZD);
    public static final Codigo EGP = new Codigo(_EGP);
    public static final Codigo ERN = new Codigo(_ERN);
    public static final Codigo ETB = new Codigo(_ETB);
    public static final Codigo EUR = new Codigo(_EUR);
    public static final Codigo FJD = new Codigo(_FJD);
    public static final Codigo FKP = new Codigo(_FKP);
    public static final Codigo GBP = new Codigo(_GBP);
    public static final Codigo GEL = new Codigo(_GEL);
    public static final Codigo GHS = new Codigo(_GHS);
    public static final Codigo GIP = new Codigo(_GIP);
    public static final Codigo GMD = new Codigo(_GMD);
    public static final Codigo GNF = new Codigo(_GNF);
    public static final Codigo GTQ = new Codigo(_GTQ);
    public static final Codigo GWP = new Codigo(_GWP);
    public static final Codigo GYD = new Codigo(_GYD);
    public static final Codigo HKD = new Codigo(_HKD);
    public static final Codigo HNL = new Codigo(_HNL);
    public static final Codigo HRK = new Codigo(_HRK);
    public static final Codigo HTG = new Codigo(_HTG);
    public static final Codigo HUF = new Codigo(_HUF);
    public static final Codigo IDR = new Codigo(_IDR);
    public static final Codigo ILS = new Codigo(_ILS);
    public static final Codigo INR = new Codigo(_INR);
    public static final Codigo IQD = new Codigo(_IQD);
    public static final Codigo IRR = new Codigo(_IRR);
    public static final Codigo ISK = new Codigo(_ISK);
    public static final Codigo JMD = new Codigo(_JMD);
    public static final Codigo JOD = new Codigo(_JOD);
    public static final Codigo JPY = new Codigo(_JPY);
    public static final Codigo KES = new Codigo(_KES);
    public static final Codigo KGS = new Codigo(_KGS);
    public static final Codigo KHR = new Codigo(_KHR);
    public static final Codigo KMF = new Codigo(_KMF);
    public static final Codigo KPW = new Codigo(_KPW);
    public static final Codigo KRW = new Codigo(_KRW);
    public static final Codigo KWD = new Codigo(_KWD);
    public static final Codigo KYD = new Codigo(_KYD);
    public static final Codigo KZT = new Codigo(_KZT);
    public static final Codigo LAK = new Codigo(_LAK);
    public static final Codigo LBP = new Codigo(_LBP);
    public static final Codigo LKR = new Codigo(_LKR);
    public static final Codigo LRD = new Codigo(_LRD);
    public static final Codigo LSL = new Codigo(_LSL);
    public static final Codigo LTL = new Codigo(_LTL);
    public static final Codigo LVL = new Codigo(_LVL);
    public static final Codigo LYD = new Codigo(_LYD);
    public static final Codigo MAD = new Codigo(_MAD);
    public static final Codigo MDL = new Codigo(_MDL);
    public static final Codigo MGA = new Codigo(_MGA);
    public static final Codigo MKD = new Codigo(_MKD);
    public static final Codigo MMK = new Codigo(_MMK);
    public static final Codigo MNT = new Codigo(_MNT);
    public static final Codigo MOP = new Codigo(_MOP);
    public static final Codigo MRO = new Codigo(_MRO);
    public static final Codigo MUR = new Codigo(_MUR);
    public static final Codigo MVR = new Codigo(_MVR);
    public static final Codigo MWK = new Codigo(_MWK);
    public static final Codigo MXN = new Codigo(_MXN);
    public static final Codigo MYR = new Codigo(_MYR);
    public static final Codigo MZN = new Codigo(_MZN);
    public static final Codigo NAD = new Codigo(_NAD);
    public static final Codigo NGN = new Codigo(_NGN);
    public static final Codigo NIO = new Codigo(_NIO);
    public static final Codigo NOK = new Codigo(_NOK);
    public static final Codigo NPR = new Codigo(_NPR);
    public static final Codigo NZD = new Codigo(_NZD);
    public static final Codigo OMR = new Codigo(_OMR);
    public static final Codigo PAB = new Codigo(_PAB);
    public static final Codigo PEN = new Codigo(_PEN);
    public static final Codigo PGK = new Codigo(_PGK);
    public static final Codigo PHP = new Codigo(_PHP);
    public static final Codigo PKR = new Codigo(_PKR);
    public static final Codigo PLN = new Codigo(_PLN);
    public static final Codigo PYG = new Codigo(_PYG);
    public static final Codigo QAR = new Codigo(_QAR);
    public static final Codigo RON = new Codigo(_RON);
    public static final Codigo RSD = new Codigo(_RSD);
    public static final Codigo RUB = new Codigo(_RUB);
    public static final Codigo RWF = new Codigo(_RWF);
    public static final Codigo SAR = new Codigo(_SAR);
    public static final Codigo SBD = new Codigo(_SBD);
    public static final Codigo SCR = new Codigo(_SCR);
    public static final Codigo SDG = new Codigo(_SDG);
    public static final Codigo SDR = new Codigo(_SDR);
    public static final Codigo SEK = new Codigo(_SEK);
    public static final Codigo SGD = new Codigo(_SGD);
    public static final Codigo SHP = new Codigo(_SHP);
    public static final Codigo SLL = new Codigo(_SLL);
    public static final Codigo SOS = new Codigo(_SOS);
    public static final Codigo SRD = new Codigo(_SRD);
    public static final Codigo SSP = new Codigo(_SSP);
    public static final Codigo STD = new Codigo(_STD);
    public static final Codigo SVC = new Codigo(_SVC);
    public static final Codigo SYP = new Codigo(_SYP);
    public static final Codigo SZL = new Codigo(_SZL);
    public static final Codigo THB = new Codigo(_THB);
    public static final Codigo TJS = new Codigo(_TJS);
    public static final Codigo TMT = new Codigo(_TMT);
    public static final Codigo TND = new Codigo(_TND);
    public static final Codigo TOP = new Codigo(_TOP);
    public static final Codigo TRY = new Codigo(_TRY);
    public static final Codigo TTD = new Codigo(_TTD);
    public static final Codigo TWD = new Codigo(_TWD);
    public static final Codigo TZS = new Codigo(_TZS);
    public static final Codigo UAH = new Codigo(_UAH);
    public static final Codigo UGX = new Codigo(_UGX);
    public static final Codigo USD = new Codigo(_USD);
    public static final Codigo UYU = new Codigo(_UYU);
    public static final Codigo UZS = new Codigo(_UZS);
    public static final Codigo VEF = new Codigo(_VEF);
    public static final Codigo VND = new Codigo(_VND);
    public static final Codigo VUV = new Codigo(_VUV);
    public static final Codigo WST = new Codigo(_WST);
    public static final Codigo XAF = new Codigo(_XAF);
    public static final Codigo XAU = new Codigo(_XAU);
    public static final Codigo XCD = new Codigo(_XCD);
    public static final Codigo XEU = new Codigo(_XEU);
    public static final Codigo XOF = new Codigo(_XOF);
    public static final Codigo XPF = new Codigo(_XPF);
    public static final Codigo YER = new Codigo(_YER);
    public static final Codigo ZAR = new Codigo(_ZAR);
    public static final Codigo ZMW = new Codigo(_ZMW);
    public static final Codigo ZWL = new Codigo(_ZWL);
    public java.lang.String getValue() { return _value_;}
    public static Codigo fromValue(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        Codigo enumeration = (Codigo)
            _table_.get(value);
        if (enumeration==null) throw new java.lang.IllegalArgumentException();
        return enumeration;
    }
    public static Codigo fromString(java.lang.String value)
          throws java.lang.IllegalArgumentException {
        return fromValue(value);
    }
    public boolean equals(java.lang.Object obj) {return (obj == this);}
    public int hashCode() { return toString().hashCode();}
    public java.lang.String toString() { return _value_;}
    public java.lang.Object readResolve() throws java.io.ObjectStreamException { return fromValue(_value_);}
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumSerializer(
            _javaType, _xmlType);
    }
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new org.apache.axis.encoding.ser.EnumDeserializer(
            _javaType, _xmlType);
    }
    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Codigo.class);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Codigo"));
    }
    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

}
