/**
 * SolicitaAnaliseAlvaraRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class SolicitaAnaliseAlvaraRequest  implements java.io.Serializable {
    /* Numero Protocolo do CRM */
    private java.lang.String protocolo;

    /* Codigo adotado pela Cielo para identificar o Cliente */
    private java.lang.Long codigoCliente;

    /* Numero do telefone do contato do cliente com a Cielo */
    private java.lang.String numeroTelefoneContato;

    /* Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre as partes. */
    private java.lang.String nomeContato;

    /* Nome do endereco de email do contato do cliente com a Cielo */
    private java.lang.String nomeEmailContato;

    /* Status do Estabelecimento Comercial */
    private java.lang.String codigoSituacaoCliente;

    /* Nome do proprietario do estabelecimento comercial Cliente da
     * Cielo. */
    private java.lang.String nomeProprietario;

    public SolicitaAnaliseAlvaraRequest() {
    }

    public SolicitaAnaliseAlvaraRequest(
           java.lang.String protocolo,
           java.lang.Long codigoCliente,
           java.lang.String numeroTelefoneContato,
           java.lang.String nomeContato,
           java.lang.String nomeEmailContato,
           java.lang.String codigoSituacaoCliente,
           java.lang.String nomeProprietario) {
           this.protocolo = protocolo;
           this.codigoCliente = codigoCliente;
           this.numeroTelefoneContato = numeroTelefoneContato;
           this.nomeContato = nomeContato;
           this.nomeEmailContato = nomeEmailContato;
           this.codigoSituacaoCliente = codigoSituacaoCliente;
           this.nomeProprietario = nomeProprietario;
    }


    /**
     * Gets the protocolo value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @return protocolo   * Numero Protocolo do CRM
     */
    public java.lang.String getProtocolo() {
        return protocolo;
    }


    /**
     * Sets the protocolo value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @param protocolo   * Numero Protocolo do CRM
     */
    public void setProtocolo(java.lang.String protocolo) {
        this.protocolo = protocolo;
    }


    /**
     * Gets the codigoCliente value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the numeroTelefoneContato value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @return numeroTelefoneContato   * Numero do telefone do contato do cliente com a Cielo
     */
    public java.lang.String getNumeroTelefoneContato() {
        return numeroTelefoneContato;
    }


    /**
     * Sets the numeroTelefoneContato value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @param numeroTelefoneContato   * Numero do telefone do contato do cliente com a Cielo
     */
    public void setNumeroTelefoneContato(java.lang.String numeroTelefoneContato) {
        this.numeroTelefoneContato = numeroTelefoneContato;
    }


    /**
     * Gets the nomeContato value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @return nomeContato   * Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre as partes.
     */
    public java.lang.String getNomeContato() {
        return nomeContato;
    }


    /**
     * Sets the nomeContato value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @param nomeContato   * Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre as partes.
     */
    public void setNomeContato(java.lang.String nomeContato) {
        this.nomeContato = nomeContato;
    }


    /**
     * Gets the nomeEmailContato value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @return nomeEmailContato   * Nome do endereco de email do contato do cliente com a Cielo
     */
    public java.lang.String getNomeEmailContato() {
        return nomeEmailContato;
    }


    /**
     * Sets the nomeEmailContato value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @param nomeEmailContato   * Nome do endereco de email do contato do cliente com a Cielo
     */
    public void setNomeEmailContato(java.lang.String nomeEmailContato) {
        this.nomeEmailContato = nomeEmailContato;
    }


    /**
     * Gets the codigoSituacaoCliente value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @return codigoSituacaoCliente   * Status do Estabelecimento Comercial
     */
    public java.lang.String getCodigoSituacaoCliente() {
        return codigoSituacaoCliente;
    }


    /**
     * Sets the codigoSituacaoCliente value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @param codigoSituacaoCliente   * Status do Estabelecimento Comercial
     */
    public void setCodigoSituacaoCliente(java.lang.String codigoSituacaoCliente) {
        this.codigoSituacaoCliente = codigoSituacaoCliente;
    }


    /**
     * Gets the nomeProprietario value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @return nomeProprietario   * Nome do proprietario do estabelecimento comercial Cliente da
     * Cielo.
     */
    public java.lang.String getNomeProprietario() {
        return nomeProprietario;
    }


    /**
     * Sets the nomeProprietario value for this SolicitaAnaliseAlvaraRequest.
     * 
     * @param nomeProprietario   * Nome do proprietario do estabelecimento comercial Cliente da
     * Cielo.
     */
    public void setNomeProprietario(java.lang.String nomeProprietario) {
        this.nomeProprietario = nomeProprietario;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SolicitaAnaliseAlvaraRequest)) return false;
        SolicitaAnaliseAlvaraRequest other = (SolicitaAnaliseAlvaraRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.protocolo==null && other.getProtocolo()==null) || 
             (this.protocolo!=null &&
              this.protocolo.equals(other.getProtocolo()))) &&
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.numeroTelefoneContato==null && other.getNumeroTelefoneContato()==null) || 
             (this.numeroTelefoneContato!=null &&
              this.numeroTelefoneContato.equals(other.getNumeroTelefoneContato()))) &&
            ((this.nomeContato==null && other.getNomeContato()==null) || 
             (this.nomeContato!=null &&
              this.nomeContato.equals(other.getNomeContato()))) &&
            ((this.nomeEmailContato==null && other.getNomeEmailContato()==null) || 
             (this.nomeEmailContato!=null &&
              this.nomeEmailContato.equals(other.getNomeEmailContato()))) &&
            ((this.codigoSituacaoCliente==null && other.getCodigoSituacaoCliente()==null) || 
             (this.codigoSituacaoCliente!=null &&
              this.codigoSituacaoCliente.equals(other.getCodigoSituacaoCliente()))) &&
            ((this.nomeProprietario==null && other.getNomeProprietario()==null) || 
             (this.nomeProprietario!=null &&
              this.nomeProprietario.equals(other.getNomeProprietario())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProtocolo() != null) {
            _hashCode += getProtocolo().hashCode();
        }
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getNumeroTelefoneContato() != null) {
            _hashCode += getNumeroTelefoneContato().hashCode();
        }
        if (getNomeContato() != null) {
            _hashCode += getNomeContato().hashCode();
        }
        if (getNomeEmailContato() != null) {
            _hashCode += getNomeEmailContato().hashCode();
        }
        if (getCodigoSituacaoCliente() != null) {
            _hashCode += getCodigoSituacaoCliente().hashCode();
        }
        if (getNomeProprietario() != null) {
            _hashCode += getNomeProprietario().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SolicitaAnaliseAlvaraRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">solicitaAnaliseAlvaraRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protocolo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "protocolo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefoneContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroTelefoneContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "nomeContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEmailContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "nomeEmailContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSituacaoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoSituacaoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeProprietario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "nomeProprietario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
