/**
 * TarifaGrupoProdutoPrazoFlexivel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class TarifaGrupoProdutoPrazoFlexivel  implements java.io.Serializable {
    /* Quantidade de dias que o valor transacionado, relacionado a
     * qualquer produto pertencente ao grupo, será repassado ao cliente de
     * forma antecipada. */
    private java.math.BigInteger quantidadeDiasGrupoPrazoFlexivel;

    /* Valor da taxa correspondente a quantidade de dias (de 1 a 30)
     * de antecipação de repasse de pagamento ao cliente relacionado a qualquer
     * produto pertencente ao grupo. */
    private java.lang.Double percentualTaxaGrupoPrazoFlexivel;

    public TarifaGrupoProdutoPrazoFlexivel() {
    }

    public TarifaGrupoProdutoPrazoFlexivel(
           java.math.BigInteger quantidadeDiasGrupoPrazoFlexivel,
           java.lang.Double percentualTaxaGrupoPrazoFlexivel) {
           this.quantidadeDiasGrupoPrazoFlexivel = quantidadeDiasGrupoPrazoFlexivel;
           this.percentualTaxaGrupoPrazoFlexivel = percentualTaxaGrupoPrazoFlexivel;
    }


    /**
     * Gets the quantidadeDiasGrupoPrazoFlexivel value for this TarifaGrupoProdutoPrazoFlexivel.
     * 
     * @return quantidadeDiasGrupoPrazoFlexivel   * Quantidade de dias que o valor transacionado, relacionado a
     * qualquer produto pertencente ao grupo, será repassado ao cliente de
     * forma antecipada.
     */
    public java.math.BigInteger getQuantidadeDiasGrupoPrazoFlexivel() {
        return quantidadeDiasGrupoPrazoFlexivel;
    }


    /**
     * Sets the quantidadeDiasGrupoPrazoFlexivel value for this TarifaGrupoProdutoPrazoFlexivel.
     * 
     * @param quantidadeDiasGrupoPrazoFlexivel   * Quantidade de dias que o valor transacionado, relacionado a
     * qualquer produto pertencente ao grupo, será repassado ao cliente de
     * forma antecipada.
     */
    public void setQuantidadeDiasGrupoPrazoFlexivel(java.math.BigInteger quantidadeDiasGrupoPrazoFlexivel) {
        this.quantidadeDiasGrupoPrazoFlexivel = quantidadeDiasGrupoPrazoFlexivel;
    }


    /**
     * Gets the percentualTaxaGrupoPrazoFlexivel value for this TarifaGrupoProdutoPrazoFlexivel.
     * 
     * @return percentualTaxaGrupoPrazoFlexivel   * Valor da taxa correspondente a quantidade de dias (de 1 a 30)
     * de antecipação de repasse de pagamento ao cliente relacionado a qualquer
     * produto pertencente ao grupo.
     */
    public java.lang.Double getPercentualTaxaGrupoPrazoFlexivel() {
        return percentualTaxaGrupoPrazoFlexivel;
    }


    /**
     * Sets the percentualTaxaGrupoPrazoFlexivel value for this TarifaGrupoProdutoPrazoFlexivel.
     * 
     * @param percentualTaxaGrupoPrazoFlexivel   * Valor da taxa correspondente a quantidade de dias (de 1 a 30)
     * de antecipação de repasse de pagamento ao cliente relacionado a qualquer
     * produto pertencente ao grupo.
     */
    public void setPercentualTaxaGrupoPrazoFlexivel(java.lang.Double percentualTaxaGrupoPrazoFlexivel) {
        this.percentualTaxaGrupoPrazoFlexivel = percentualTaxaGrupoPrazoFlexivel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TarifaGrupoProdutoPrazoFlexivel)) return false;
        TarifaGrupoProdutoPrazoFlexivel other = (TarifaGrupoProdutoPrazoFlexivel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.quantidadeDiasGrupoPrazoFlexivel==null && other.getQuantidadeDiasGrupoPrazoFlexivel()==null) || 
             (this.quantidadeDiasGrupoPrazoFlexivel!=null &&
              this.quantidadeDiasGrupoPrazoFlexivel.equals(other.getQuantidadeDiasGrupoPrazoFlexivel()))) &&
            ((this.percentualTaxaGrupoPrazoFlexivel==null && other.getPercentualTaxaGrupoPrazoFlexivel()==null) || 
             (this.percentualTaxaGrupoPrazoFlexivel!=null &&
              this.percentualTaxaGrupoPrazoFlexivel.equals(other.getPercentualTaxaGrupoPrazoFlexivel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQuantidadeDiasGrupoPrazoFlexivel() != null) {
            _hashCode += getQuantidadeDiasGrupoPrazoFlexivel().hashCode();
        }
        if (getPercentualTaxaGrupoPrazoFlexivel() != null) {
            _hashCode += getPercentualTaxaGrupoPrazoFlexivel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TarifaGrupoProdutoPrazoFlexivel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifaGrupoProdutoPrazoFlexivel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeDiasGrupoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeDiasGrupoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaGrupoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxaGrupoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
