/**
 * FaixaTaxaSegmentado.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class FaixaTaxaSegmentado  implements java.io.Serializable {
    /* Valor da taxa correspondente a uma faixa de parcelas do produto
     * contratado pelo cliente ou ofertado para o cliente. */
    private java.lang.Double percentualTaxaFaixa;

    /* Numero inicial da parcela da faixa para a cobrança da taxa. */
    private java.math.BigInteger numeroInicialParcelaFaixa;

    /* Numero final da parcela da faixa para a cobrança da taxa. */
    private java.math.BigInteger numeroFinalParcelaFaixa;

    /* Codigo que identifica a faixa de taxa valida para um conjunto
     * de prestacoes de um produto parcelado a ser ofertado para o cliente. */
    private java.math.BigInteger codigoFaixa;

    /* Valor do descontocorrespondente a uma faixa de parcelas do
     * produto contratado pelo cliente ou ofertado para o cliente.
     * No documento funcional esta sendo solicitado este campo para que quando
     * for parcelado segmentado este campo deve ser somado com a taxa atual
     * das parcelas do cliente. */
    private java.lang.Double percentualDescontoSegmentado;

    /* Percentual da taxa padrão correspondente a uma faixa de parcelas
     * do produto. */
    private java.lang.Double percentualPadraoTaxaFaixa;

    public FaixaTaxaSegmentado() {
    }

    public FaixaTaxaSegmentado(
           java.lang.Double percentualTaxaFaixa,
           java.math.BigInteger numeroInicialParcelaFaixa,
           java.math.BigInteger numeroFinalParcelaFaixa,
           java.math.BigInteger codigoFaixa,
           java.lang.Double percentualDescontoSegmentado,
           java.lang.Double percentualPadraoTaxaFaixa) {
           this.percentualTaxaFaixa = percentualTaxaFaixa;
           this.numeroInicialParcelaFaixa = numeroInicialParcelaFaixa;
           this.numeroFinalParcelaFaixa = numeroFinalParcelaFaixa;
           this.codigoFaixa = codigoFaixa;
           this.percentualDescontoSegmentado = percentualDescontoSegmentado;
           this.percentualPadraoTaxaFaixa = percentualPadraoTaxaFaixa;
    }


    /**
     * Gets the percentualTaxaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @return percentualTaxaFaixa   * Valor da taxa correspondente a uma faixa de parcelas do produto
     * contratado pelo cliente ou ofertado para o cliente.
     */
    public java.lang.Double getPercentualTaxaFaixa() {
        return percentualTaxaFaixa;
    }


    /**
     * Sets the percentualTaxaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @param percentualTaxaFaixa   * Valor da taxa correspondente a uma faixa de parcelas do produto
     * contratado pelo cliente ou ofertado para o cliente.
     */
    public void setPercentualTaxaFaixa(java.lang.Double percentualTaxaFaixa) {
        this.percentualTaxaFaixa = percentualTaxaFaixa;
    }


    /**
     * Gets the numeroInicialParcelaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @return numeroInicialParcelaFaixa   * Numero inicial da parcela da faixa para a cobrança da taxa.
     */
    public java.math.BigInteger getNumeroInicialParcelaFaixa() {
        return numeroInicialParcelaFaixa;
    }


    /**
     * Sets the numeroInicialParcelaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @param numeroInicialParcelaFaixa   * Numero inicial da parcela da faixa para a cobrança da taxa.
     */
    public void setNumeroInicialParcelaFaixa(java.math.BigInteger numeroInicialParcelaFaixa) {
        this.numeroInicialParcelaFaixa = numeroInicialParcelaFaixa;
    }


    /**
     * Gets the numeroFinalParcelaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @return numeroFinalParcelaFaixa   * Numero final da parcela da faixa para a cobrança da taxa.
     */
    public java.math.BigInteger getNumeroFinalParcelaFaixa() {
        return numeroFinalParcelaFaixa;
    }


    /**
     * Sets the numeroFinalParcelaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @param numeroFinalParcelaFaixa   * Numero final da parcela da faixa para a cobrança da taxa.
     */
    public void setNumeroFinalParcelaFaixa(java.math.BigInteger numeroFinalParcelaFaixa) {
        this.numeroFinalParcelaFaixa = numeroFinalParcelaFaixa;
    }


    /**
     * Gets the codigoFaixa value for this FaixaTaxaSegmentado.
     * 
     * @return codigoFaixa   * Codigo que identifica a faixa de taxa valida para um conjunto
     * de prestacoes de um produto parcelado a ser ofertado para o cliente.
     */
    public java.math.BigInteger getCodigoFaixa() {
        return codigoFaixa;
    }


    /**
     * Sets the codigoFaixa value for this FaixaTaxaSegmentado.
     * 
     * @param codigoFaixa   * Codigo que identifica a faixa de taxa valida para um conjunto
     * de prestacoes de um produto parcelado a ser ofertado para o cliente.
     */
    public void setCodigoFaixa(java.math.BigInteger codigoFaixa) {
        this.codigoFaixa = codigoFaixa;
    }


    /**
     * Gets the percentualDescontoSegmentado value for this FaixaTaxaSegmentado.
     * 
     * @return percentualDescontoSegmentado   * Valor do descontocorrespondente a uma faixa de parcelas do
     * produto contratado pelo cliente ou ofertado para o cliente.
     * No documento funcional esta sendo solicitado este campo para que quando
     * for parcelado segmentado este campo deve ser somado com a taxa atual
     * das parcelas do cliente.
     */
    public java.lang.Double getPercentualDescontoSegmentado() {
        return percentualDescontoSegmentado;
    }


    /**
     * Sets the percentualDescontoSegmentado value for this FaixaTaxaSegmentado.
     * 
     * @param percentualDescontoSegmentado   * Valor do descontocorrespondente a uma faixa de parcelas do
     * produto contratado pelo cliente ou ofertado para o cliente.
     * No documento funcional esta sendo solicitado este campo para que quando
     * for parcelado segmentado este campo deve ser somado com a taxa atual
     * das parcelas do cliente.
     */
    public void setPercentualDescontoSegmentado(java.lang.Double percentualDescontoSegmentado) {
        this.percentualDescontoSegmentado = percentualDescontoSegmentado;
    }


    /**
     * Gets the percentualPadraoTaxaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @return percentualPadraoTaxaFaixa   * Percentual da taxa padrão correspondente a uma faixa de parcelas
     * do produto.
     */
    public java.lang.Double getPercentualPadraoTaxaFaixa() {
        return percentualPadraoTaxaFaixa;
    }


    /**
     * Sets the percentualPadraoTaxaFaixa value for this FaixaTaxaSegmentado.
     * 
     * @param percentualPadraoTaxaFaixa   * Percentual da taxa padrão correspondente a uma faixa de parcelas
     * do produto.
     */
    public void setPercentualPadraoTaxaFaixa(java.lang.Double percentualPadraoTaxaFaixa) {
        this.percentualPadraoTaxaFaixa = percentualPadraoTaxaFaixa;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof FaixaTaxaSegmentado)) return false;
        FaixaTaxaSegmentado other = (FaixaTaxaSegmentado) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.percentualTaxaFaixa==null && other.getPercentualTaxaFaixa()==null) || 
             (this.percentualTaxaFaixa!=null &&
              this.percentualTaxaFaixa.equals(other.getPercentualTaxaFaixa()))) &&
            ((this.numeroInicialParcelaFaixa==null && other.getNumeroInicialParcelaFaixa()==null) || 
             (this.numeroInicialParcelaFaixa!=null &&
              this.numeroInicialParcelaFaixa.equals(other.getNumeroInicialParcelaFaixa()))) &&
            ((this.numeroFinalParcelaFaixa==null && other.getNumeroFinalParcelaFaixa()==null) || 
             (this.numeroFinalParcelaFaixa!=null &&
              this.numeroFinalParcelaFaixa.equals(other.getNumeroFinalParcelaFaixa()))) &&
            ((this.codigoFaixa==null && other.getCodigoFaixa()==null) || 
             (this.codigoFaixa!=null &&
              this.codigoFaixa.equals(other.getCodigoFaixa()))) &&
            ((this.percentualDescontoSegmentado==null && other.getPercentualDescontoSegmentado()==null) || 
             (this.percentualDescontoSegmentado!=null &&
              this.percentualDescontoSegmentado.equals(other.getPercentualDescontoSegmentado()))) &&
            ((this.percentualPadraoTaxaFaixa==null && other.getPercentualPadraoTaxaFaixa()==null) || 
             (this.percentualPadraoTaxaFaixa!=null &&
              this.percentualPadraoTaxaFaixa.equals(other.getPercentualPadraoTaxaFaixa())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPercentualTaxaFaixa() != null) {
            _hashCode += getPercentualTaxaFaixa().hashCode();
        }
        if (getNumeroInicialParcelaFaixa() != null) {
            _hashCode += getNumeroInicialParcelaFaixa().hashCode();
        }
        if (getNumeroFinalParcelaFaixa() != null) {
            _hashCode += getNumeroFinalParcelaFaixa().hashCode();
        }
        if (getCodigoFaixa() != null) {
            _hashCode += getCodigoFaixa().hashCode();
        }
        if (getPercentualDescontoSegmentado() != null) {
            _hashCode += getPercentualDescontoSegmentado().hashCode();
        }
        if (getPercentualPadraoTaxaFaixa() != null) {
            _hashCode += getPercentualPadraoTaxaFaixa().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(FaixaTaxaSegmentado.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixaTaxaSegmentado"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaFaixa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxaFaixa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroInicialParcelaFaixa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroInicialParcelaFaixa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroFinalParcelaFaixa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroFinalParcelaFaixa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFaixa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoFaixa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualDescontoSegmentado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualDescontoSegmentado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualPadraoTaxaFaixa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualPadraoTaxaFaixa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
