/**
 * ConsultarOrdemProdutoResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarOrdemProdutoResponse  implements java.io.Serializable {
    private java.math.BigInteger codigo;

    private java.lang.String descricao;

    private java.lang.String bandeira;

    private java.lang.String apelido;

    private java.math.BigInteger ordem;

    public ConsultarOrdemProdutoResponse() {
    }

    public ConsultarOrdemProdutoResponse(
           java.math.BigInteger codigo,
           java.lang.String descricao,
           java.lang.String bandeira,
           java.lang.String apelido,
           java.math.BigInteger ordem) {
           this.codigo = codigo;
           this.descricao = descricao;
           this.bandeira = bandeira;
           this.apelido = apelido;
           this.ordem = ordem;
    }


    /**
     * Gets the codigo value for this ConsultarOrdemProdutoResponse.
     * 
     * @return codigo
     */
    public java.math.BigInteger getCodigo() {
        return codigo;
    }


    /**
     * Sets the codigo value for this ConsultarOrdemProdutoResponse.
     * 
     * @param codigo
     */
    public void setCodigo(java.math.BigInteger codigo) {
        this.codigo = codigo;
    }


    /**
     * Gets the descricao value for this ConsultarOrdemProdutoResponse.
     * 
     * @return descricao
     */
    public java.lang.String getDescricao() {
        return descricao;
    }


    /**
     * Sets the descricao value for this ConsultarOrdemProdutoResponse.
     * 
     * @param descricao
     */
    public void setDescricao(java.lang.String descricao) {
        this.descricao = descricao;
    }


    /**
     * Gets the bandeira value for this ConsultarOrdemProdutoResponse.
     * 
     * @return bandeira
     */
    public java.lang.String getBandeira() {
        return bandeira;
    }


    /**
     * Sets the bandeira value for this ConsultarOrdemProdutoResponse.
     * 
     * @param bandeira
     */
    public void setBandeira(java.lang.String bandeira) {
        this.bandeira = bandeira;
    }


    /**
     * Gets the apelido value for this ConsultarOrdemProdutoResponse.
     * 
     * @return apelido
     */
    public java.lang.String getApelido() {
        return apelido;
    }


    /**
     * Sets the apelido value for this ConsultarOrdemProdutoResponse.
     * 
     * @param apelido
     */
    public void setApelido(java.lang.String apelido) {
        this.apelido = apelido;
    }


    /**
     * Gets the ordem value for this ConsultarOrdemProdutoResponse.
     * 
     * @return ordem
     */
    public java.math.BigInteger getOrdem() {
        return ordem;
    }


    /**
     * Sets the ordem value for this ConsultarOrdemProdutoResponse.
     * 
     * @param ordem
     */
    public void setOrdem(java.math.BigInteger ordem) {
        this.ordem = ordem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarOrdemProdutoResponse)) return false;
        ConsultarOrdemProdutoResponse other = (ConsultarOrdemProdutoResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigo==null && other.getCodigo()==null) || 
             (this.codigo!=null &&
              this.codigo.equals(other.getCodigo()))) &&
            ((this.descricao==null && other.getDescricao()==null) || 
             (this.descricao!=null &&
              this.descricao.equals(other.getDescricao()))) &&
            ((this.bandeira==null && other.getBandeira()==null) || 
             (this.bandeira!=null &&
              this.bandeira.equals(other.getBandeira()))) &&
            ((this.apelido==null && other.getApelido()==null) || 
             (this.apelido!=null &&
              this.apelido.equals(other.getApelido()))) &&
            ((this.ordem==null && other.getOrdem()==null) || 
             (this.ordem!=null &&
              this.ordem.equals(other.getOrdem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigo() != null) {
            _hashCode += getCodigo().hashCode();
        }
        if (getDescricao() != null) {
            _hashCode += getDescricao().hashCode();
        }
        if (getBandeira() != null) {
            _hashCode += getBandeira().hashCode();
        }
        if (getApelido() != null) {
            _hashCode += getApelido().hashCode();
        }
        if (getOrdem() != null) {
            _hashCode += getOrdem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarOrdemProdutoResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarOrdemProdutoResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "bandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apelido");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "apelido"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ordem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ordem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
