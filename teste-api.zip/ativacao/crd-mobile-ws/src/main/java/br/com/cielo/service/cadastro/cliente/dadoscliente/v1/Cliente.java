/**
 * Cliente.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;


/**
 * Tipo complexo que representa os dados da pessoa juridica.
 */
public class Cliente  implements java.io.Serializable {
    private java.lang.String numeroCnpj;

    private java.lang.String numeroCpf;

    private java.lang.String nomeRazaoSocial;

    private java.lang.String numeroInscricaoEstadual;

    private java.lang.String nomeFantasia;

    public Cliente() {
    }

    public Cliente(
           java.lang.String numeroCnpj,
           java.lang.String numeroCpf,
           java.lang.String nomeRazaoSocial,
           java.lang.String numeroInscricaoEstadual,
           java.lang.String nomeFantasia) {
           this.numeroCnpj = numeroCnpj;
           this.numeroCpf = numeroCpf;
           this.nomeRazaoSocial = nomeRazaoSocial;
           this.numeroInscricaoEstadual = numeroInscricaoEstadual;
           this.nomeFantasia = nomeFantasia;
    }


    /**
     * Gets the numeroCnpj value for this Cliente.
     * 
     * @return numeroCnpj
     */
    public java.lang.String getNumeroCnpj() {
        return numeroCnpj;
    }


    /**
     * Sets the numeroCnpj value for this Cliente.
     * 
     * @param numeroCnpj
     */
    public void setNumeroCnpj(java.lang.String numeroCnpj) {
        this.numeroCnpj = numeroCnpj;
    }


    /**
     * Gets the numeroCpf value for this Cliente.
     * 
     * @return numeroCpf
     */
    public java.lang.String getNumeroCpf() {
        return numeroCpf;
    }


    /**
     * Sets the numeroCpf value for this Cliente.
     * 
     * @param numeroCpf
     */
    public void setNumeroCpf(java.lang.String numeroCpf) {
        this.numeroCpf = numeroCpf;
    }


    /**
     * Gets the nomeRazaoSocial value for this Cliente.
     * 
     * @return nomeRazaoSocial
     */
    public java.lang.String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }


    /**
     * Sets the nomeRazaoSocial value for this Cliente.
     * 
     * @param nomeRazaoSocial
     */
    public void setNomeRazaoSocial(java.lang.String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }


    /**
     * Gets the numeroInscricaoEstadual value for this Cliente.
     * 
     * @return numeroInscricaoEstadual
     */
    public java.lang.String getNumeroInscricaoEstadual() {
        return numeroInscricaoEstadual;
    }


    /**
     * Sets the numeroInscricaoEstadual value for this Cliente.
     * 
     * @param numeroInscricaoEstadual
     */
    public void setNumeroInscricaoEstadual(java.lang.String numeroInscricaoEstadual) {
        this.numeroInscricaoEstadual = numeroInscricaoEstadual;
    }


    /**
     * Gets the nomeFantasia value for this Cliente.
     * 
     * @return nomeFantasia
     */
    public java.lang.String getNomeFantasia() {
        return nomeFantasia;
    }


    /**
     * Sets the nomeFantasia value for this Cliente.
     * 
     * @param nomeFantasia
     */
    public void setNomeFantasia(java.lang.String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Cliente)) return false;
        Cliente other = (Cliente) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroCnpj==null && other.getNumeroCnpj()==null) || 
             (this.numeroCnpj!=null &&
              this.numeroCnpj.equals(other.getNumeroCnpj()))) &&
            ((this.numeroCpf==null && other.getNumeroCpf()==null) || 
             (this.numeroCpf!=null &&
              this.numeroCpf.equals(other.getNumeroCpf()))) &&
            ((this.nomeRazaoSocial==null && other.getNomeRazaoSocial()==null) || 
             (this.nomeRazaoSocial!=null &&
              this.nomeRazaoSocial.equals(other.getNomeRazaoSocial()))) &&
            ((this.numeroInscricaoEstadual==null && other.getNumeroInscricaoEstadual()==null) || 
             (this.numeroInscricaoEstadual!=null &&
              this.numeroInscricaoEstadual.equals(other.getNumeroInscricaoEstadual()))) &&
            ((this.nomeFantasia==null && other.getNomeFantasia()==null) || 
             (this.nomeFantasia!=null &&
              this.nomeFantasia.equals(other.getNomeFantasia())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroCnpj() != null) {
            _hashCode += getNumeroCnpj().hashCode();
        }
        if (getNumeroCpf() != null) {
            _hashCode += getNumeroCpf().hashCode();
        }
        if (getNomeRazaoSocial() != null) {
            _hashCode += getNomeRazaoSocial().hashCode();
        }
        if (getNumeroInscricaoEstadual() != null) {
            _hashCode += getNumeroInscricaoEstadual().hashCode();
        }
        if (getNomeFantasia() != null) {
            _hashCode += getNomeFantasia().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Cliente.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "Cliente"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "numeroCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCpf");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "numeroCpf"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeRazaoSocial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "nomeRazaoSocial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroInscricaoEstadual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "numeroInscricaoEstadual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFantasia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "nomeFantasia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
