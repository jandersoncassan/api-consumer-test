/**
 * ManterPrazoFlexivelRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ManterPrazoFlexivelRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o Cliente */
    private java.lang.Long codigoCliente;

    /* Indicador Operação: Indica se a operação é: I - Inclusão; A
     * - Alteração; E - Exclusão */
    private java.lang.String indicaOperacao;

    /* O código de grupo de prazos flexíveis representa o agrupamento
     * de produtos do prazo flexível. */
    private java.math.BigInteger codigoGrupoPrazoFlexivel;

    /* Quantidade de dias que o valor transacionado, relacionado a
     * qualquer produto pertencente ao grupo, será repassado ao cliente de
     * forma antecipada. */
    private java.math.BigInteger quantidadeDiasGrupoPrazoFlexivel;

    /* Valor da taxa correspondente a quantidade de dias (de 1 a 30)
     * de antecipação de repasse de pagamento ao cliente relacionado a qualquer
     * produto pertencente ao grupo. */
    private java.lang.Double percentualTaxaGrupoPrazoFlexivel;

    public ManterPrazoFlexivelRequest() {
    }

    public ManterPrazoFlexivelRequest(
           java.lang.Long codigoCliente,
           java.lang.String indicaOperacao,
           java.math.BigInteger codigoGrupoPrazoFlexivel,
           java.math.BigInteger quantidadeDiasGrupoPrazoFlexivel,
           java.lang.Double percentualTaxaGrupoPrazoFlexivel) {
           this.codigoCliente = codigoCliente;
           this.indicaOperacao = indicaOperacao;
           this.codigoGrupoPrazoFlexivel = codigoGrupoPrazoFlexivel;
           this.quantidadeDiasGrupoPrazoFlexivel = quantidadeDiasGrupoPrazoFlexivel;
           this.percentualTaxaGrupoPrazoFlexivel = percentualTaxaGrupoPrazoFlexivel;
    }


    /**
     * Gets the codigoCliente value for this ManterPrazoFlexivelRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this ManterPrazoFlexivelRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the indicaOperacao value for this ManterPrazoFlexivelRequest.
     * 
     * @return indicaOperacao   * Indicador Operação: Indica se a operação é: I - Inclusão; A
     * - Alteração; E - Exclusão
     */
    public java.lang.String getIndicaOperacao() {
        return indicaOperacao;
    }


    /**
     * Sets the indicaOperacao value for this ManterPrazoFlexivelRequest.
     * 
     * @param indicaOperacao   * Indicador Operação: Indica se a operação é: I - Inclusão; A
     * - Alteração; E - Exclusão
     */
    public void setIndicaOperacao(java.lang.String indicaOperacao) {
        this.indicaOperacao = indicaOperacao;
    }


    /**
     * Gets the codigoGrupoPrazoFlexivel value for this ManterPrazoFlexivelRequest.
     * 
     * @return codigoGrupoPrazoFlexivel   * O código de grupo de prazos flexíveis representa o agrupamento
     * de produtos do prazo flexível.
     */
    public java.math.BigInteger getCodigoGrupoPrazoFlexivel() {
        return codigoGrupoPrazoFlexivel;
    }


    /**
     * Sets the codigoGrupoPrazoFlexivel value for this ManterPrazoFlexivelRequest.
     * 
     * @param codigoGrupoPrazoFlexivel   * O código de grupo de prazos flexíveis representa o agrupamento
     * de produtos do prazo flexível.
     */
    public void setCodigoGrupoPrazoFlexivel(java.math.BigInteger codigoGrupoPrazoFlexivel) {
        this.codigoGrupoPrazoFlexivel = codigoGrupoPrazoFlexivel;
    }


    /**
     * Gets the quantidadeDiasGrupoPrazoFlexivel value for this ManterPrazoFlexivelRequest.
     * 
     * @return quantidadeDiasGrupoPrazoFlexivel   * Quantidade de dias que o valor transacionado, relacionado a
     * qualquer produto pertencente ao grupo, será repassado ao cliente de
     * forma antecipada.
     */
    public java.math.BigInteger getQuantidadeDiasGrupoPrazoFlexivel() {
        return quantidadeDiasGrupoPrazoFlexivel;
    }


    /**
     * Sets the quantidadeDiasGrupoPrazoFlexivel value for this ManterPrazoFlexivelRequest.
     * 
     * @param quantidadeDiasGrupoPrazoFlexivel   * Quantidade de dias que o valor transacionado, relacionado a
     * qualquer produto pertencente ao grupo, será repassado ao cliente de
     * forma antecipada.
     */
    public void setQuantidadeDiasGrupoPrazoFlexivel(java.math.BigInteger quantidadeDiasGrupoPrazoFlexivel) {
        this.quantidadeDiasGrupoPrazoFlexivel = quantidadeDiasGrupoPrazoFlexivel;
    }


    /**
     * Gets the percentualTaxaGrupoPrazoFlexivel value for this ManterPrazoFlexivelRequest.
     * 
     * @return percentualTaxaGrupoPrazoFlexivel   * Valor da taxa correspondente a quantidade de dias (de 1 a 30)
     * de antecipação de repasse de pagamento ao cliente relacionado a qualquer
     * produto pertencente ao grupo.
     */
    public java.lang.Double getPercentualTaxaGrupoPrazoFlexivel() {
        return percentualTaxaGrupoPrazoFlexivel;
    }


    /**
     * Sets the percentualTaxaGrupoPrazoFlexivel value for this ManterPrazoFlexivelRequest.
     * 
     * @param percentualTaxaGrupoPrazoFlexivel   * Valor da taxa correspondente a quantidade de dias (de 1 a 30)
     * de antecipação de repasse de pagamento ao cliente relacionado a qualquer
     * produto pertencente ao grupo.
     */
    public void setPercentualTaxaGrupoPrazoFlexivel(java.lang.Double percentualTaxaGrupoPrazoFlexivel) {
        this.percentualTaxaGrupoPrazoFlexivel = percentualTaxaGrupoPrazoFlexivel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ManterPrazoFlexivelRequest)) return false;
        ManterPrazoFlexivelRequest other = (ManterPrazoFlexivelRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.indicaOperacao==null && other.getIndicaOperacao()==null) || 
             (this.indicaOperacao!=null &&
              this.indicaOperacao.equals(other.getIndicaOperacao()))) &&
            ((this.codigoGrupoPrazoFlexivel==null && other.getCodigoGrupoPrazoFlexivel()==null) || 
             (this.codigoGrupoPrazoFlexivel!=null &&
              this.codigoGrupoPrazoFlexivel.equals(other.getCodigoGrupoPrazoFlexivel()))) &&
            ((this.quantidadeDiasGrupoPrazoFlexivel==null && other.getQuantidadeDiasGrupoPrazoFlexivel()==null) || 
             (this.quantidadeDiasGrupoPrazoFlexivel!=null &&
              this.quantidadeDiasGrupoPrazoFlexivel.equals(other.getQuantidadeDiasGrupoPrazoFlexivel()))) &&
            ((this.percentualTaxaGrupoPrazoFlexivel==null && other.getPercentualTaxaGrupoPrazoFlexivel()==null) || 
             (this.percentualTaxaGrupoPrazoFlexivel!=null &&
              this.percentualTaxaGrupoPrazoFlexivel.equals(other.getPercentualTaxaGrupoPrazoFlexivel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getIndicaOperacao() != null) {
            _hashCode += getIndicaOperacao().hashCode();
        }
        if (getCodigoGrupoPrazoFlexivel() != null) {
            _hashCode += getCodigoGrupoPrazoFlexivel().hashCode();
        }
        if (getQuantidadeDiasGrupoPrazoFlexivel() != null) {
            _hashCode += getQuantidadeDiasGrupoPrazoFlexivel().hashCode();
        }
        if (getPercentualTaxaGrupoPrazoFlexivel() != null) {
            _hashCode += getPercentualTaxaGrupoPrazoFlexivel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ManterPrazoFlexivelRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">manterPrazoFlexivelRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicaOperacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "IndicaOperacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoGrupoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoGrupoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeDiasGrupoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "quantidadeDiasGrupoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaGrupoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "percentualTaxaGrupoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
