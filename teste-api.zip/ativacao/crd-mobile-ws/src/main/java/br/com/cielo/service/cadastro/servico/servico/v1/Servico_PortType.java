/**
 * Servico_PortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.servico.servico.v1;

public interface Servico_PortType extends java.rmi.Remote {
    public br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoHabilitadoClienteResponse consultarServicoHabilitadoCliente(br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoHabilitadoClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
    public br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoElegivelClienteResponse consultarServicoElegivelCliente(br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoElegivelClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
    public br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoNaoElegivelClienteResponse consultarServicoNaoElegivelCliente(br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoNaoElegivelClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
    public br.com.cielo.service.cadastro.servico.servico.v1.HabilitarServicoResponse habilitarServico(br.com.cielo.service.cadastro.servico.servico.v1.HabilitarServicoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
    public br.com.cielo.service.cadastro.servico.servico.v1.DesabilitarServicoResponse desabilitarServico(br.com.cielo.service.cadastro.servico.servico.v1.DesabilitarServicoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
    public br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoResponse habilitarListaServico(br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
