/**
 * ProdutoAlterarPropostaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class ProdutoAlterarPropostaType  implements java.io.Serializable {
    private java.math.BigInteger codigoProduto;

    private java.math.BigDecimal percentualTaxaPadrao;

    private int quantideParcelaProduto;

    private boolean indicadorProdutoHabilitado;

    private int codigoErroHabilitacao;

    public ProdutoAlterarPropostaType() {
    }

    public ProdutoAlterarPropostaType(
           java.math.BigInteger codigoProduto,
           java.math.BigDecimal percentualTaxaPadrao,
           int quantideParcelaProduto,
           boolean indicadorProdutoHabilitado,
           int codigoErroHabilitacao) {
           this.codigoProduto = codigoProduto;
           this.percentualTaxaPadrao = percentualTaxaPadrao;
           this.quantideParcelaProduto = quantideParcelaProduto;
           this.indicadorProdutoHabilitado = indicadorProdutoHabilitado;
           this.codigoErroHabilitacao = codigoErroHabilitacao;
    }


    /**
     * Gets the codigoProduto value for this ProdutoAlterarPropostaType.
     * 
     * @return codigoProduto
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this ProdutoAlterarPropostaType.
     * 
     * @param codigoProduto
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the percentualTaxaPadrao value for this ProdutoAlterarPropostaType.
     * 
     * @return percentualTaxaPadrao
     */
    public java.math.BigDecimal getPercentualTaxaPadrao() {
        return percentualTaxaPadrao;
    }


    /**
     * Sets the percentualTaxaPadrao value for this ProdutoAlterarPropostaType.
     * 
     * @param percentualTaxaPadrao
     */
    public void setPercentualTaxaPadrao(java.math.BigDecimal percentualTaxaPadrao) {
        this.percentualTaxaPadrao = percentualTaxaPadrao;
    }


    /**
     * Gets the quantideParcelaProduto value for this ProdutoAlterarPropostaType.
     * 
     * @return quantideParcelaProduto
     */
    public int getQuantideParcelaProduto() {
        return quantideParcelaProduto;
    }


    /**
     * Sets the quantideParcelaProduto value for this ProdutoAlterarPropostaType.
     * 
     * @param quantideParcelaProduto
     */
    public void setQuantideParcelaProduto(int quantideParcelaProduto) {
        this.quantideParcelaProduto = quantideParcelaProduto;
    }


    /**
     * Gets the indicadorProdutoHabilitado value for this ProdutoAlterarPropostaType.
     * 
     * @return indicadorProdutoHabilitado
     */
    public boolean isIndicadorProdutoHabilitado() {
        return indicadorProdutoHabilitado;
    }


    /**
     * Sets the indicadorProdutoHabilitado value for this ProdutoAlterarPropostaType.
     * 
     * @param indicadorProdutoHabilitado
     */
    public void setIndicadorProdutoHabilitado(boolean indicadorProdutoHabilitado) {
        this.indicadorProdutoHabilitado = indicadorProdutoHabilitado;
    }


    /**
     * Gets the codigoErroHabilitacao value for this ProdutoAlterarPropostaType.
     * 
     * @return codigoErroHabilitacao
     */
    public int getCodigoErroHabilitacao() {
        return codigoErroHabilitacao;
    }


    /**
     * Sets the codigoErroHabilitacao value for this ProdutoAlterarPropostaType.
     * 
     * @param codigoErroHabilitacao
     */
    public void setCodigoErroHabilitacao(int codigoErroHabilitacao) {
        this.codigoErroHabilitacao = codigoErroHabilitacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProdutoAlterarPropostaType)) return false;
        ProdutoAlterarPropostaType other = (ProdutoAlterarPropostaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto()))) &&
            ((this.percentualTaxaPadrao==null && other.getPercentualTaxaPadrao()==null) || 
             (this.percentualTaxaPadrao!=null &&
              this.percentualTaxaPadrao.equals(other.getPercentualTaxaPadrao()))) &&
            this.quantideParcelaProduto == other.getQuantideParcelaProduto() &&
            this.indicadorProdutoHabilitado == other.isIndicadorProdutoHabilitado() &&
            this.codigoErroHabilitacao == other.getCodigoErroHabilitacao();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        if (getPercentualTaxaPadrao() != null) {
            _hashCode += getPercentualTaxaPadrao().hashCode();
        }
        _hashCode += getQuantideParcelaProduto();
        _hashCode += (isIndicadorProdutoHabilitado() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        _hashCode += getCodigoErroHabilitacao();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProdutoAlterarPropostaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "produtoAlterarPropostaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaPadrao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "percentualTaxaPadrao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantideParcelaProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "quantideParcelaProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorProdutoHabilitado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "indicadorProdutoHabilitado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoErroHabilitacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoErroHabilitacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
