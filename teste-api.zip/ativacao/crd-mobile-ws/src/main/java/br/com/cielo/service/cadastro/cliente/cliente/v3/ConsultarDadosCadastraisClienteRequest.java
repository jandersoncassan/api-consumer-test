/**
 * ConsultarDadosCadastraisClienteRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ConsultarDadosCadastraisClienteRequest  implements java.io.Serializable {
    private java.lang.String codigoCliente;

    private br.com.cielo.service.cadastro.cliente.cliente.v3.IdentificacaoClienteType identificacaoCliente;

    private java.lang.String tipoConsulta;

    public ConsultarDadosCadastraisClienteRequest() {
    }

    public ConsultarDadosCadastraisClienteRequest(
           java.lang.String codigoCliente,
           br.com.cielo.service.cadastro.cliente.cliente.v3.IdentificacaoClienteType identificacaoCliente,
           java.lang.String tipoConsulta) {
           this.codigoCliente = codigoCliente;
           this.identificacaoCliente = identificacaoCliente;
           this.tipoConsulta = tipoConsulta;
    }


    /**
     * Gets the codigoCliente value for this ConsultarDadosCadastraisClienteRequest.
     * 
     * @return codigoCliente
     */
    public java.lang.String getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this ConsultarDadosCadastraisClienteRequest.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(java.lang.String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the identificacaoCliente value for this ConsultarDadosCadastraisClienteRequest.
     * 
     * @return identificacaoCliente
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.IdentificacaoClienteType getIdentificacaoCliente() {
        return identificacaoCliente;
    }


    /**
     * Sets the identificacaoCliente value for this ConsultarDadosCadastraisClienteRequest.
     * 
     * @param identificacaoCliente
     */
    public void setIdentificacaoCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.IdentificacaoClienteType identificacaoCliente) {
        this.identificacaoCliente = identificacaoCliente;
    }


    /**
     * Gets the tipoConsulta value for this ConsultarDadosCadastraisClienteRequest.
     * 
     * @return tipoConsulta
     */
    public java.lang.String getTipoConsulta() {
        return tipoConsulta;
    }


    /**
     * Sets the tipoConsulta value for this ConsultarDadosCadastraisClienteRequest.
     * 
     * @param tipoConsulta
     */
    public void setTipoConsulta(java.lang.String tipoConsulta) {
        this.tipoConsulta = tipoConsulta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDadosCadastraisClienteRequest)) return false;
        ConsultarDadosCadastraisClienteRequest other = (ConsultarDadosCadastraisClienteRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.identificacaoCliente==null && other.getIdentificacaoCliente()==null) || 
             (this.identificacaoCliente!=null &&
              this.identificacaoCliente.equals(other.getIdentificacaoCliente()))) &&
            ((this.tipoConsulta==null && other.getTipoConsulta()==null) || 
             (this.tipoConsulta!=null &&
              this.tipoConsulta.equals(other.getTipoConsulta())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getIdentificacaoCliente() != null) {
            _hashCode += getIdentificacaoCliente().hashCode();
        }
        if (getTipoConsulta() != null) {
            _hashCode += getTipoConsulta().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDadosCadastraisClienteRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDadosCadastraisClienteRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identificacaoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "identificacaoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "IdentificacaoClienteType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoConsulta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "tipoConsulta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
