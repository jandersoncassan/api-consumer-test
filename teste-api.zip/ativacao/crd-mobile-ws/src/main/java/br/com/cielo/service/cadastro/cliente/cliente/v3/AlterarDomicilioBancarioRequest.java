/**
 * AlterarDomicilioBancarioRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class AlterarDomicilioBancarioRequest  implements java.io.Serializable {
    /* Numero Protocolo do CRM */
    private java.lang.String protocolo;

    /* Codigo adotado pela Cielo para identificar o Cliente */
    private java.lang.Long codigoCliente;

    /* Codigo da bandeira que estao travada neste domicilio bancario */
    private java.lang.String codigoBandeiraTrava;

    /* Código Banco Anterior - Numero que identifica o banco dentro
     * do sistema de compensacao nacional controlado pelo BACEN. */
    private java.math.BigInteger codigoBancoAnterior;

    /* Código Banco Novo - Numero que identifica o banco dentro do
     * sistema de compensacao nacional controlado pelo BACEN. */
    private java.math.BigInteger codigoBancoNovo;

    /* Numero Agencia Anterior - Codigo da agencia bancaria onde o
     * cliente possui uma conta-corrente, sendo esta, utilizada no relacionamento
     * com a Cielo. */
    private java.math.BigInteger numeroAgenciaAnterior;

    /* Numero Agencia Novo - Codigo da agencia bancaria onde o cliente
     * possui uma conta-corrente, sendo esta, utilizada no relacionamento
     * com a Cielo. */
    private java.math.BigInteger numeroAgenciaNovo;

    /* Numero Conta Corrente Anterior - Numero da conta-corrente que
     * o cliente possui e que e utilizada no relacionamento financeiro com
     * a Cielo. */
    private java.lang.String numeroContaCorrenteAnterior;

    /* Numero Conta Corrente Novo - Numero da conta-corrente que o
     * cliente possui e que e utilizada no relacionamento financeiro com
     * a Cielo. */
    private java.lang.String numeroContaCorrenteNovo;

    public AlterarDomicilioBancarioRequest() {
    }

    public AlterarDomicilioBancarioRequest(
           java.lang.String protocolo,
           java.lang.Long codigoCliente,
           java.lang.String codigoBandeiraTrava,
           java.math.BigInteger codigoBancoAnterior,
           java.math.BigInteger codigoBancoNovo,
           java.math.BigInteger numeroAgenciaAnterior,
           java.math.BigInteger numeroAgenciaNovo,
           java.lang.String numeroContaCorrenteAnterior,
           java.lang.String numeroContaCorrenteNovo) {
           this.protocolo = protocolo;
           this.codigoCliente = codigoCliente;
           this.codigoBandeiraTrava = codigoBandeiraTrava;
           this.codigoBancoAnterior = codigoBancoAnterior;
           this.codigoBancoNovo = codigoBancoNovo;
           this.numeroAgenciaAnterior = numeroAgenciaAnterior;
           this.numeroAgenciaNovo = numeroAgenciaNovo;
           this.numeroContaCorrenteAnterior = numeroContaCorrenteAnterior;
           this.numeroContaCorrenteNovo = numeroContaCorrenteNovo;
    }


    /**
     * Gets the protocolo value for this AlterarDomicilioBancarioRequest.
     * 
     * @return protocolo   * Numero Protocolo do CRM
     */
    public java.lang.String getProtocolo() {
        return protocolo;
    }


    /**
     * Sets the protocolo value for this AlterarDomicilioBancarioRequest.
     * 
     * @param protocolo   * Numero Protocolo do CRM
     */
    public void setProtocolo(java.lang.String protocolo) {
        this.protocolo = protocolo;
    }


    /**
     * Gets the codigoCliente value for this AlterarDomicilioBancarioRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this AlterarDomicilioBancarioRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the codigoBandeiraTrava value for this AlterarDomicilioBancarioRequest.
     * 
     * @return codigoBandeiraTrava   * Codigo da bandeira que estao travada neste domicilio bancario
     */
    public java.lang.String getCodigoBandeiraTrava() {
        return codigoBandeiraTrava;
    }


    /**
     * Sets the codigoBandeiraTrava value for this AlterarDomicilioBancarioRequest.
     * 
     * @param codigoBandeiraTrava   * Codigo da bandeira que estao travada neste domicilio bancario
     */
    public void setCodigoBandeiraTrava(java.lang.String codigoBandeiraTrava) {
        this.codigoBandeiraTrava = codigoBandeiraTrava;
    }


    /**
     * Gets the codigoBancoAnterior value for this AlterarDomicilioBancarioRequest.
     * 
     * @return codigoBancoAnterior   * Código Banco Anterior - Numero que identifica o banco dentro
     * do sistema de compensacao nacional controlado pelo BACEN.
     */
    public java.math.BigInteger getCodigoBancoAnterior() {
        return codigoBancoAnterior;
    }


    /**
     * Sets the codigoBancoAnterior value for this AlterarDomicilioBancarioRequest.
     * 
     * @param codigoBancoAnterior   * Código Banco Anterior - Numero que identifica o banco dentro
     * do sistema de compensacao nacional controlado pelo BACEN.
     */
    public void setCodigoBancoAnterior(java.math.BigInteger codigoBancoAnterior) {
        this.codigoBancoAnterior = codigoBancoAnterior;
    }


    /**
     * Gets the codigoBancoNovo value for this AlterarDomicilioBancarioRequest.
     * 
     * @return codigoBancoNovo   * Código Banco Novo - Numero que identifica o banco dentro do
     * sistema de compensacao nacional controlado pelo BACEN.
     */
    public java.math.BigInteger getCodigoBancoNovo() {
        return codigoBancoNovo;
    }


    /**
     * Sets the codigoBancoNovo value for this AlterarDomicilioBancarioRequest.
     * 
     * @param codigoBancoNovo   * Código Banco Novo - Numero que identifica o banco dentro do
     * sistema de compensacao nacional controlado pelo BACEN.
     */
    public void setCodigoBancoNovo(java.math.BigInteger codigoBancoNovo) {
        this.codigoBancoNovo = codigoBancoNovo;
    }


    /**
     * Gets the numeroAgenciaAnterior value for this AlterarDomicilioBancarioRequest.
     * 
     * @return numeroAgenciaAnterior   * Numero Agencia Anterior - Codigo da agencia bancaria onde o
     * cliente possui uma conta-corrente, sendo esta, utilizada no relacionamento
     * com a Cielo.
     */
    public java.math.BigInteger getNumeroAgenciaAnterior() {
        return numeroAgenciaAnterior;
    }


    /**
     * Sets the numeroAgenciaAnterior value for this AlterarDomicilioBancarioRequest.
     * 
     * @param numeroAgenciaAnterior   * Numero Agencia Anterior - Codigo da agencia bancaria onde o
     * cliente possui uma conta-corrente, sendo esta, utilizada no relacionamento
     * com a Cielo.
     */
    public void setNumeroAgenciaAnterior(java.math.BigInteger numeroAgenciaAnterior) {
        this.numeroAgenciaAnterior = numeroAgenciaAnterior;
    }


    /**
     * Gets the numeroAgenciaNovo value for this AlterarDomicilioBancarioRequest.
     * 
     * @return numeroAgenciaNovo   * Numero Agencia Novo - Codigo da agencia bancaria onde o cliente
     * possui uma conta-corrente, sendo esta, utilizada no relacionamento
     * com a Cielo.
     */
    public java.math.BigInteger getNumeroAgenciaNovo() {
        return numeroAgenciaNovo;
    }


    /**
     * Sets the numeroAgenciaNovo value for this AlterarDomicilioBancarioRequest.
     * 
     * @param numeroAgenciaNovo   * Numero Agencia Novo - Codigo da agencia bancaria onde o cliente
     * possui uma conta-corrente, sendo esta, utilizada no relacionamento
     * com a Cielo.
     */
    public void setNumeroAgenciaNovo(java.math.BigInteger numeroAgenciaNovo) {
        this.numeroAgenciaNovo = numeroAgenciaNovo;
    }


    /**
     * Gets the numeroContaCorrenteAnterior value for this AlterarDomicilioBancarioRequest.
     * 
     * @return numeroContaCorrenteAnterior   * Numero Conta Corrente Anterior - Numero da conta-corrente que
     * o cliente possui e que e utilizada no relacionamento financeiro com
     * a Cielo.
     */
    public java.lang.String getNumeroContaCorrenteAnterior() {
        return numeroContaCorrenteAnterior;
    }


    /**
     * Sets the numeroContaCorrenteAnterior value for this AlterarDomicilioBancarioRequest.
     * 
     * @param numeroContaCorrenteAnterior   * Numero Conta Corrente Anterior - Numero da conta-corrente que
     * o cliente possui e que e utilizada no relacionamento financeiro com
     * a Cielo.
     */
    public void setNumeroContaCorrenteAnterior(java.lang.String numeroContaCorrenteAnterior) {
        this.numeroContaCorrenteAnterior = numeroContaCorrenteAnterior;
    }


    /**
     * Gets the numeroContaCorrenteNovo value for this AlterarDomicilioBancarioRequest.
     * 
     * @return numeroContaCorrenteNovo   * Numero Conta Corrente Novo - Numero da conta-corrente que o
     * cliente possui e que e utilizada no relacionamento financeiro com
     * a Cielo.
     */
    public java.lang.String getNumeroContaCorrenteNovo() {
        return numeroContaCorrenteNovo;
    }


    /**
     * Sets the numeroContaCorrenteNovo value for this AlterarDomicilioBancarioRequest.
     * 
     * @param numeroContaCorrenteNovo   * Numero Conta Corrente Novo - Numero da conta-corrente que o
     * cliente possui e que e utilizada no relacionamento financeiro com
     * a Cielo.
     */
    public void setNumeroContaCorrenteNovo(java.lang.String numeroContaCorrenteNovo) {
        this.numeroContaCorrenteNovo = numeroContaCorrenteNovo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarDomicilioBancarioRequest)) return false;
        AlterarDomicilioBancarioRequest other = (AlterarDomicilioBancarioRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.protocolo==null && other.getProtocolo()==null) || 
             (this.protocolo!=null &&
              this.protocolo.equals(other.getProtocolo()))) &&
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.codigoBandeiraTrava==null && other.getCodigoBandeiraTrava()==null) || 
             (this.codigoBandeiraTrava!=null &&
              this.codigoBandeiraTrava.equals(other.getCodigoBandeiraTrava()))) &&
            ((this.codigoBancoAnterior==null && other.getCodigoBancoAnterior()==null) || 
             (this.codigoBancoAnterior!=null &&
              this.codigoBancoAnterior.equals(other.getCodigoBancoAnterior()))) &&
            ((this.codigoBancoNovo==null && other.getCodigoBancoNovo()==null) || 
             (this.codigoBancoNovo!=null &&
              this.codigoBancoNovo.equals(other.getCodigoBancoNovo()))) &&
            ((this.numeroAgenciaAnterior==null && other.getNumeroAgenciaAnterior()==null) || 
             (this.numeroAgenciaAnterior!=null &&
              this.numeroAgenciaAnterior.equals(other.getNumeroAgenciaAnterior()))) &&
            ((this.numeroAgenciaNovo==null && other.getNumeroAgenciaNovo()==null) || 
             (this.numeroAgenciaNovo!=null &&
              this.numeroAgenciaNovo.equals(other.getNumeroAgenciaNovo()))) &&
            ((this.numeroContaCorrenteAnterior==null && other.getNumeroContaCorrenteAnterior()==null) || 
             (this.numeroContaCorrenteAnterior!=null &&
              this.numeroContaCorrenteAnterior.equals(other.getNumeroContaCorrenteAnterior()))) &&
            ((this.numeroContaCorrenteNovo==null && other.getNumeroContaCorrenteNovo()==null) || 
             (this.numeroContaCorrenteNovo!=null &&
              this.numeroContaCorrenteNovo.equals(other.getNumeroContaCorrenteNovo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProtocolo() != null) {
            _hashCode += getProtocolo().hashCode();
        }
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getCodigoBandeiraTrava() != null) {
            _hashCode += getCodigoBandeiraTrava().hashCode();
        }
        if (getCodigoBancoAnterior() != null) {
            _hashCode += getCodigoBancoAnterior().hashCode();
        }
        if (getCodigoBancoNovo() != null) {
            _hashCode += getCodigoBancoNovo().hashCode();
        }
        if (getNumeroAgenciaAnterior() != null) {
            _hashCode += getNumeroAgenciaAnterior().hashCode();
        }
        if (getNumeroAgenciaNovo() != null) {
            _hashCode += getNumeroAgenciaNovo().hashCode();
        }
        if (getNumeroContaCorrenteAnterior() != null) {
            _hashCode += getNumeroContaCorrenteAnterior().hashCode();
        }
        if (getNumeroContaCorrenteNovo() != null) {
            _hashCode += getNumeroContaCorrenteNovo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarDomicilioBancarioRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDomicilioBancarioRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protocolo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "protocolo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBandeiraTrava");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoBandeiraTrava"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBancoAnterior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoBancoAnterior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBancoNovo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoBancoNovo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroAgenciaAnterior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroAgenciaAnterior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroAgenciaNovo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroAgenciaNovo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroContaCorrenteAnterior");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroContaCorrenteAnterior"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroContaCorrenteNovo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroContaCorrenteNovo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
