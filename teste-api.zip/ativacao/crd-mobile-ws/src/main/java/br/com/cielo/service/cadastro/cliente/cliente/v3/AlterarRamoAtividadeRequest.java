/**
 * AlterarRamoAtividadeRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class AlterarRamoAtividadeRequest  implements java.io.Serializable {
    /* Numero Protocolo do CRM */
    private java.lang.String protocolo;

    /* Codigo adotado pela Cielo para identificar o Cliente */
    private java.lang.Long codigoCliente;

    /* Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre
     * 							as partes. */
    private java.lang.String nomeContato;

    /* Codigo definido pelas bandeiras Visa e Mastercard para identificar
     * um ramo de atividade 
     * 							Tambem conhecido como MCC, ele e adotado pela Cielo e por todos
     * os adquirentes e emissores 
     * 							do mundo para classificar o ramo de negocio dos seus clientes. */
    private java.lang.String codigoRamoAtividade;

    public AlterarRamoAtividadeRequest() {
    }

    public AlterarRamoAtividadeRequest(
           java.lang.String protocolo,
           java.lang.Long codigoCliente,
           java.lang.String nomeContato,
           java.lang.String codigoRamoAtividade) {
           this.protocolo = protocolo;
           this.codigoCliente = codigoCliente;
           this.nomeContato = nomeContato;
           this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the protocolo value for this AlterarRamoAtividadeRequest.
     * 
     * @return protocolo   * Numero Protocolo do CRM
     */
    public java.lang.String getProtocolo() {
        return protocolo;
    }


    /**
     * Sets the protocolo value for this AlterarRamoAtividadeRequest.
     * 
     * @param protocolo   * Numero Protocolo do CRM
     */
    public void setProtocolo(java.lang.String protocolo) {
        this.protocolo = protocolo;
    }


    /**
     * Gets the codigoCliente value for this AlterarRamoAtividadeRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this AlterarRamoAtividadeRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the nomeContato value for this AlterarRamoAtividadeRequest.
     * 
     * @return nomeContato   * Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre
     * 							as partes.
     */
    public java.lang.String getNomeContato() {
        return nomeContato;
    }


    /**
     * Sets the nomeContato value for this AlterarRamoAtividadeRequest.
     * 
     * @param nomeContato   * Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre
     * 							as partes.
     */
    public void setNomeContato(java.lang.String nomeContato) {
        this.nomeContato = nomeContato;
    }


    /**
     * Gets the codigoRamoAtividade value for this AlterarRamoAtividadeRequest.
     * 
     * @return codigoRamoAtividade   * Codigo definido pelas bandeiras Visa e Mastercard para identificar
     * um ramo de atividade 
     * 							Tambem conhecido como MCC, ele e adotado pela Cielo e por todos
     * os adquirentes e emissores 
     * 							do mundo para classificar o ramo de negocio dos seus clientes.
     */
    public java.lang.String getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this AlterarRamoAtividadeRequest.
     * 
     * @param codigoRamoAtividade   * Codigo definido pelas bandeiras Visa e Mastercard para identificar
     * um ramo de atividade 
     * 							Tambem conhecido como MCC, ele e adotado pela Cielo e por todos
     * os adquirentes e emissores 
     * 							do mundo para classificar o ramo de negocio dos seus clientes.
     */
    public void setCodigoRamoAtividade(java.lang.String codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarRamoAtividadeRequest)) return false;
        AlterarRamoAtividadeRequest other = (AlterarRamoAtividadeRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.protocolo==null && other.getProtocolo()==null) || 
             (this.protocolo!=null &&
              this.protocolo.equals(other.getProtocolo()))) &&
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.nomeContato==null && other.getNomeContato()==null) || 
             (this.nomeContato!=null &&
              this.nomeContato.equals(other.getNomeContato()))) &&
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProtocolo() != null) {
            _hashCode += getProtocolo().hashCode();
        }
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getNomeContato() != null) {
            _hashCode += getNomeContato().hashCode();
        }
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarRamoAtividadeRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarRamoAtividadeRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protocolo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "protocolo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "nomeContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
