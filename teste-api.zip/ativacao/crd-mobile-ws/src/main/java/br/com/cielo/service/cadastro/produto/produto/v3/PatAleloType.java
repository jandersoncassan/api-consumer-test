/**
 * PatAleloType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class PatAleloType  extends br.com.cielo.canonico.cadastro.v1.PatAlelo  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo;

    public PatAleloType() {
    }

    public PatAleloType(
           java.lang.Long codigoCliente,
           java.math.BigInteger codigoProduto,
           java.util.Date dataAfiliacao,
           br.com.cielo.canonico.cadastro.v1.LojaFisica dadosLojaFisica,
           java.lang.String indicadorServicoDelivery,
           java.lang.String indicadorVendaInternet,
           java.lang.String indicadorApresentacaoCartao,
           br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo) {
        super(
            codigoCliente,
            codigoProduto,
            dataAfiliacao,
            dadosLojaFisica,
            indicadorServicoDelivery,
            indicadorVendaInternet,
            indicadorApresentacaoCartao);
        this.dadosPatAlelo = dadosPatAlelo;
    }


    /**
     * Gets the dadosPatAlelo value for this PatAleloType.
     * 
     * @return dadosPatAlelo
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType getDadosPatAlelo() {
        return dadosPatAlelo;
    }


    /**
     * Sets the dadosPatAlelo value for this PatAleloType.
     * 
     * @param dadosPatAlelo
     */
    public void setDadosPatAlelo(br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo) {
        this.dadosPatAlelo = dadosPatAlelo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PatAleloType)) return false;
        PatAleloType other = (PatAleloType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.dadosPatAlelo==null && other.getDadosPatAlelo()==null) || 
             (this.dadosPatAlelo!=null &&
              this.dadosPatAlelo.equals(other.getDadosPatAlelo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getDadosPatAlelo() != null) {
            _hashCode += getDadosPatAlelo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PatAleloType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "PatAleloType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosPatAlelo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosPatAlelo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloCommonType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
