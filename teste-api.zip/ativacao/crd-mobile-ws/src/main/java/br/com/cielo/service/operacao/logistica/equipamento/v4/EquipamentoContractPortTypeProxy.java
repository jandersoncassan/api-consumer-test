package br.com.cielo.service.operacao.logistica.equipamento.v4;

public class EquipamentoContractPortTypeProxy implements br.com.cielo.service.operacao.logistica.equipamento.v4.EquipamentoContractPortType {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.logistica.equipamento.v4.EquipamentoContractPortType equipamentoContractPortType = null;
  
  public EquipamentoContractPortTypeProxy() {
    _initEquipamentoContractPortTypeProxy();
  }
  
  public EquipamentoContractPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initEquipamentoContractPortTypeProxy();
  }
  
  private void _initEquipamentoContractPortTypeProxy() {
    try {
      equipamentoContractPortType = (new br.com.cielo.service.operacao.logistica.equipamento.v4.EquipamentoContractLocator()).getEquipamentoContractSOAPPort();
      if (equipamentoContractPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)equipamentoContractPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)equipamentoContractPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (equipamentoContractPortType != null)
      ((javax.xml.rpc.Stub)equipamentoContractPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.logistica.equipamento.v4.EquipamentoContractPortType getEquipamentoContractPortType() {
    if (equipamentoContractPortType == null)
      _initEquipamentoContractPortTypeProxy();
    return equipamentoContractPortType;
  }
  
  public br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoResponse notificarInstalacaoEquipamento(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (equipamentoContractPortType == null)
      _initEquipamentoContractPortTypeProxy();
    return equipamentoContractPortType.notificarInstalacaoEquipamento(header, parameters);
  }
  
  public br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCResponseType notificarNumeroLogicoGTeC(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCRequestType parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (equipamentoContractPortType == null)
      _initEquipamentoContractPortTypeProxy();
    return equipamentoContractPortType.notificarNumeroLogicoGTeC(header, parameters);
  }
  
  
}