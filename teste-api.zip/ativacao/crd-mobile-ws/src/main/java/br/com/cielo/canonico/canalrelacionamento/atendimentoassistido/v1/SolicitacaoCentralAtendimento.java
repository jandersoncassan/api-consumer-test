/**
 * SolicitacaoCentralAtendimento.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.canalrelacionamento.atendimentoassistido.v1;


/**
 * Solicitacoes dos clientes que foram realizadas atraves da central
 * de atendimento. Exemplos de tipo de solicitacoes: 
 * 1 - Alterar Produto
 * 2 - Habilitar Produto
 * 3 - Habilitar Servico
 * 4 - Abrir Solicitacao de Negociacao de Taxa
 * 5 - Habilitar Venda Digitada
 * 6 - Desabilitar Venda Digitada
 * Referencia: arquivo VSAM.CAPTACAV - sistema SEC.
 */
public class SolicitacaoCentralAtendimento  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o Cliente.
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC. */
    private java.lang.Long codigoCliente;

    /* Codigo que identifica unicamente uma solicitacao. 
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC. */
    private java.math.BigInteger codigoSolicitacao;

    /* Data prevista para a solicitacao ser concluida.
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC. */
    private java.util.Date dataPrevistaConclusaoSolicitacao;

    public SolicitacaoCentralAtendimento() {
    }

    public SolicitacaoCentralAtendimento(
           java.lang.Long codigoCliente,
           java.math.BigInteger codigoSolicitacao,
           java.util.Date dataPrevistaConclusaoSolicitacao) {
           this.codigoCliente = codigoCliente;
           this.codigoSolicitacao = codigoSolicitacao;
           this.dataPrevistaConclusaoSolicitacao = dataPrevistaConclusaoSolicitacao;
    }


    /**
     * Gets the codigoCliente value for this SolicitacaoCentralAtendimento.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente.
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC.
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this SolicitacaoCentralAtendimento.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente.
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC.
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the codigoSolicitacao value for this SolicitacaoCentralAtendimento.
     * 
     * @return codigoSolicitacao   * Codigo que identifica unicamente uma solicitacao. 
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC.
     */
    public java.math.BigInteger getCodigoSolicitacao() {
        return codigoSolicitacao;
    }


    /**
     * Sets the codigoSolicitacao value for this SolicitacaoCentralAtendimento.
     * 
     * @param codigoSolicitacao   * Codigo que identifica unicamente uma solicitacao. 
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC.
     */
    public void setCodigoSolicitacao(java.math.BigInteger codigoSolicitacao) {
        this.codigoSolicitacao = codigoSolicitacao;
    }


    /**
     * Gets the dataPrevistaConclusaoSolicitacao value for this SolicitacaoCentralAtendimento.
     * 
     * @return dataPrevistaConclusaoSolicitacao   * Data prevista para a solicitacao ser concluida.
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC.
     */
    public java.util.Date getDataPrevistaConclusaoSolicitacao() {
        return dataPrevistaConclusaoSolicitacao;
    }


    /**
     * Sets the dataPrevistaConclusaoSolicitacao value for this SolicitacaoCentralAtendimento.
     * 
     * @param dataPrevistaConclusaoSolicitacao   * Data prevista para a solicitacao ser concluida.
     * Referencia: arquivo VSAM.CAPTACAV - sistema SEC.
     */
    public void setDataPrevistaConclusaoSolicitacao(java.util.Date dataPrevistaConclusaoSolicitacao) {
        this.dataPrevistaConclusaoSolicitacao = dataPrevistaConclusaoSolicitacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SolicitacaoCentralAtendimento)) return false;
        SolicitacaoCentralAtendimento other = (SolicitacaoCentralAtendimento) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.codigoSolicitacao==null && other.getCodigoSolicitacao()==null) || 
             (this.codigoSolicitacao!=null &&
              this.codigoSolicitacao.equals(other.getCodigoSolicitacao()))) &&
            ((this.dataPrevistaConclusaoSolicitacao==null && other.getDataPrevistaConclusaoSolicitacao()==null) || 
             (this.dataPrevistaConclusaoSolicitacao!=null &&
              this.dataPrevistaConclusaoSolicitacao.equals(other.getDataPrevistaConclusaoSolicitacao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getCodigoSolicitacao() != null) {
            _hashCode += getCodigoSolicitacao().hashCode();
        }
        if (getDataPrevistaConclusaoSolicitacao() != null) {
            _hashCode += getDataPrevistaConclusaoSolicitacao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SolicitacaoCentralAtendimento.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/canalrelacionamento/atendimentoassistido/v1", "SolicitacaoCentralAtendimento"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/canalrelacionamento/atendimentoassistido/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSolicitacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/canalrelacionamento/atendimentoassistido/v1", "codigoSolicitacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataPrevistaConclusaoSolicitacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/canalrelacionamento/atendimentoassistido/v1", "dataPrevistaConclusaoSolicitacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
