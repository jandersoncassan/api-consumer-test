/**
 * DadosClienteServiceSOAPBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;

public class DadosClienteServiceSOAPBindingStub extends org.apache.axis.client.Stub implements br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteServicePortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[2];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("incluir");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "incluirRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">incluirRequest"), br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">incluirResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "incluirResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarDadosCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "consultarDadosClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "consultarDadosClienteRequestType"), br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteRequestType.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "consultarDadosClienteResponseType"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "consultarDadosClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[1] = oper;

    }

    public DadosClienteServiceSOAPBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public DadosClienteServiceSOAPBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public DadosClienteServiceSOAPBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Codigo");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Moeda");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Moeda.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Cliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Cliente.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Contato.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contatos");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Contato[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "contato");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DadosBancarios");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.DadosBancarios.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Endereco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Enderecos");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Endereco[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "enderecos");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixasTaxaSegmentado");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixaTaxaSegmentado");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosFaixaTaxaSegmentado");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixaTaxaSegmentado");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filiais");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Filial[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filial");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "filial");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filial");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Filial.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GrupoProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GruposProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GrupoProdutoPrazoFlexivel");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosGrupoProdutoPrazoFlexivel");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "NoHierarquiaCliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.NoHierarquiaCliente.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "NosHierarquiaCliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.NoHierarquiaCliente[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "NoHierarquiaCliente");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nohierarquiacliente");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Produto.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produtos");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Produto[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "produto");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Proprietario");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Proprietario.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Proprietarios");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Proprietarios.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacaoFuncionamentoCliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacoesFuncionamentoCliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacaoFuncionamentoCliente");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "situacaoFuncionamentoCliente");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Tarifa");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Tarifa.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifaGrupoProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifasGrupoProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifaGrupoProdutoPrazoFlexivel");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosTarifaGrupoProdutoPrazoFlexivel");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.Fault.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "FaultDetail");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.FaultDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Tipo");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.Tipo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "faultcode");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.Faultcode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "IdentificacaoRequestType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.IdentificacaoRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "UsuarioType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">>incluirRequest>indicadorMicroEmpreendedorIndividual");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorMicroEmpreendedorIndividual.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">>incluirRequest>indicadorPersistencia");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorPersistencia.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">EnderecoType>codigoTipoEndereco");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoTypeCodigoTipoEndereco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">incluirRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">incluirResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">TelefoneType>codigoTipoTelefone");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneTypeCodigoTipoTelefone.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">TipoPessoaType>codigoTipoPessoa");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TipoPessoaTypeCodigoTipoPessoa.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "BancoType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.BancoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "Cliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.Cliente.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "consultarDadosClienteRequestType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "consultarDadosClienteResponseType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "DadosProprietariosClienteType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosProprietarioType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "DadosProprietarioType");
            qName2 = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "dadosProprietario");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "DadosProprietarioType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosProprietarioType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecoCategoria");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoCategoria.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecosCategorias");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoCategoria[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecoCategoria");
            qName2 = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "enderecoCategoria");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecosType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecoType");
            qName2 = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "endereco");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecoType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "TelefonesType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "TelefoneType");
            qName2 = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "telefone");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "TelefoneType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "TipoPessoaType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TipoPessoaType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse incluir(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "incluir"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType consultarDadosCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteRequestType parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarDadosCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
