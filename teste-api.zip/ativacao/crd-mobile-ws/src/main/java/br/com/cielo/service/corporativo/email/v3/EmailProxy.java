package br.com.cielo.service.corporativo.email.v3;

public class EmailProxy implements br.com.cielo.service.corporativo.email.v3.Email {
  private String _endpoint = null;
  private br.com.cielo.service.corporativo.email.v3.Email email = null;
  
  public EmailProxy() {
    _initEmailProxy();
  }
  
  public EmailProxy(String endpoint) {
    _endpoint = endpoint;
    _initEmailProxy();
  }
  
  private void _initEmailProxy() {
    try {
      email = (new br.com.cielo.service.corporativo.email.v3.EmailServiceLocator()).getEmailSoapPort();
      if (email != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)email)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)email)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (email != null)
      ((javax.xml.rpc.Stub)email)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.corporativo.email.v3.Email getEmail() {
    if (email == null)
      _initEmailProxy();
    return email;
  }
  
  public br.com.cielo.service.corporativo.email.v3.EnviarEmailResponseType enviarEmail(br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestType parameters) throws java.rmi.RemoteException{
    if (email == null)
      _initEmailProxy();
    return email.enviarEmail(parameters);
  }
  
  
}