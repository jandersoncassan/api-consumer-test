package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ClienteServicePortTypeProxy implements br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteServicePortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteServicePortType clienteServicePortType = null;
  
  public ClienteServicePortTypeProxy() {
    _initClienteServicePortTypeProxy();
  }
  
  public ClienteServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initClienteServicePortTypeProxy();
  }
  
  private void _initClienteServicePortTypeProxy() {
    try {
      clienteServicePortType = (new br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteServiceLocator()).getClienteServiceSOAPPort();
      if (clienteServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)clienteServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)clienteServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (clienteServicePortType != null)
      ((javax.xml.rpc.Stub)clienteServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteServicePortType getClienteServicePortType() {
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType;
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse consultarDadosCadastraisCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarDadosCadastraisCliente(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse consultarFiliais(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarFiliais(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse consultarCadastroSite(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarCadastroSite(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse alterarTerceiroTelefoneCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.alterarTerceiroTelefoneCliente(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse checarPreAutorizacaoMCC(br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.checarPreAutorizacaoMCC(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse alterarStatusCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.alterarStatusCliente(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse alterarDadosCadastraisCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.alterarDadosCadastraisCliente(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse consultarDomicilioBancario(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarDomicilioBancario(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse consultarPriorizacaoCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarPriorizacaoCliente(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse consultarDomicilioBancarioTruncado(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarDomicilioBancarioTruncado(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse solicitaAnaliseAlvara(br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.solicitaAnaliseAlvara(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse manterPrazoFlexivel(br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.manterPrazoFlexivel(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse consultarPrazosTaxasPrazoFlexivel(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarPrazosTaxasPrazoFlexivel(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse alterarDomicilioBancario(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.alterarDomicilioBancario(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse alterarRamoAtividade(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.alterarRamoAtividade(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse alterarSMSCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.alterarSMSCliente(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse consultarECCompanhiaAerea(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.consultarECCompanhiaAerea(parameters);
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse verificarExistenciaCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (clienteServicePortType == null)
      _initClienteServicePortTypeProxy();
    return clienteServicePortType.verificarExistenciaCliente(parameters, header);
  }
  
  
}