/**
 * ConsultarDetalheProdutoNaoElegivelClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarDetalheProdutoNaoElegivelClienteResponse  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.produto.produto.v3.DadosProdutoType produto;

    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    public ConsultarDetalheProdutoNaoElegivelClienteResponse() {
    }

    public ConsultarDetalheProdutoNaoElegivelClienteResponse(
           br.com.cielo.service.cadastro.produto.produto.v3.DadosProdutoType produto,
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem) {
           this.produto = produto;
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the produto value for this ConsultarDetalheProdutoNaoElegivelClienteResponse.
     * 
     * @return produto
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosProdutoType getProduto() {
        return produto;
    }


    /**
     * Sets the produto value for this ConsultarDetalheProdutoNaoElegivelClienteResponse.
     * 
     * @param produto
     */
    public void setProduto(br.com.cielo.service.cadastro.produto.produto.v3.DadosProdutoType produto) {
        this.produto = produto;
    }


    /**
     * Gets the codigoRetorno value for this ConsultarDetalheProdutoNaoElegivelClienteResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this ConsultarDetalheProdutoNaoElegivelClienteResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this ConsultarDetalheProdutoNaoElegivelClienteResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this ConsultarDetalheProdutoNaoElegivelClienteResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDetalheProdutoNaoElegivelClienteResponse)) return false;
        ConsultarDetalheProdutoNaoElegivelClienteResponse other = (ConsultarDetalheProdutoNaoElegivelClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.produto==null && other.getProduto()==null) || 
             (this.produto!=null &&
              this.produto.equals(other.getProduto()))) &&
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProduto() != null) {
            _hashCode += getProduto().hashCode();
        }
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDetalheProdutoNaoElegivelClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarDetalheProdutoNaoElegivelClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosProdutoType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
