/**
 * PatAlelo.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class PatAlelo  implements java.io.Serializable {
    /* Codigo interno que identifica um cliente na Cielo. */
    private java.lang.Long codigoCliente;

    /* Codigo do produto da Alelo para o programa de alimentação do
     * trabalhador (VR e VA). */
    private java.math.BigInteger codigoProduto;

    /* Data em que o cliente foi afiliado para o produto Alelo do
     * programa de alimentação do trabalhador. */
    private java.util.Date dataAfiliacao;

    /* Dados sobre a característica física da loja do estabelecimento
     * comercial. */
    private br.com.cielo.canonico.cadastro.v1.LojaFisica dadosLojaFisica;

    /* Indica (S/N) se a loja física possui serviço de entrega em
     * domicílio para os clientes do estabelecimento comercial. */
    private java.lang.String indicadorServicoDelivery;

    /* Indica (S/N) se a loja física possui serviço de venda pela
     * internet para os clientes do estabelecimento comercial. */
    private java.lang.String indicadorVendaInternet;

    /* Indica (S/N) se o estabelecimento comercial aceita o cartão
     * presencialmente. */
    private java.lang.String indicadorApresentacaoCartao;

    public PatAlelo() {
    }

    public PatAlelo(
           java.lang.Long codigoCliente,
           java.math.BigInteger codigoProduto,
           java.util.Date dataAfiliacao,
           br.com.cielo.canonico.cadastro.v1.LojaFisica dadosLojaFisica,
           java.lang.String indicadorServicoDelivery,
           java.lang.String indicadorVendaInternet,
           java.lang.String indicadorApresentacaoCartao) {
           this.codigoCliente = codigoCliente;
           this.codigoProduto = codigoProduto;
           this.dataAfiliacao = dataAfiliacao;
           this.dadosLojaFisica = dadosLojaFisica;
           this.indicadorServicoDelivery = indicadorServicoDelivery;
           this.indicadorVendaInternet = indicadorVendaInternet;
           this.indicadorApresentacaoCartao = indicadorApresentacaoCartao;
    }


    /**
     * Gets the codigoCliente value for this PatAlelo.
     * 
     * @return codigoCliente   * Codigo interno que identifica um cliente na Cielo.
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this PatAlelo.
     * 
     * @param codigoCliente   * Codigo interno que identifica um cliente na Cielo.
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the codigoProduto value for this PatAlelo.
     * 
     * @return codigoProduto   * Codigo do produto da Alelo para o programa de alimentação do
     * trabalhador (VR e VA).
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this PatAlelo.
     * 
     * @param codigoProduto   * Codigo do produto da Alelo para o programa de alimentação do
     * trabalhador (VR e VA).
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the dataAfiliacao value for this PatAlelo.
     * 
     * @return dataAfiliacao   * Data em que o cliente foi afiliado para o produto Alelo do
     * programa de alimentação do trabalhador.
     */
    public java.util.Date getDataAfiliacao() {
        return dataAfiliacao;
    }


    /**
     * Sets the dataAfiliacao value for this PatAlelo.
     * 
     * @param dataAfiliacao   * Data em que o cliente foi afiliado para o produto Alelo do
     * programa de alimentação do trabalhador.
     */
    public void setDataAfiliacao(java.util.Date dataAfiliacao) {
        this.dataAfiliacao = dataAfiliacao;
    }


    /**
     * Gets the dadosLojaFisica value for this PatAlelo.
     * 
     * @return dadosLojaFisica   * Dados sobre a característica física da loja do estabelecimento
     * comercial.
     */
    public br.com.cielo.canonico.cadastro.v1.LojaFisica getDadosLojaFisica() {
        return dadosLojaFisica;
    }


    /**
     * Sets the dadosLojaFisica value for this PatAlelo.
     * 
     * @param dadosLojaFisica   * Dados sobre a característica física da loja do estabelecimento
     * comercial.
     */
    public void setDadosLojaFisica(br.com.cielo.canonico.cadastro.v1.LojaFisica dadosLojaFisica) {
        this.dadosLojaFisica = dadosLojaFisica;
    }


    /**
     * Gets the indicadorServicoDelivery value for this PatAlelo.
     * 
     * @return indicadorServicoDelivery   * Indica (S/N) se a loja física possui serviço de entrega em
     * domicílio para os clientes do estabelecimento comercial.
     */
    public java.lang.String getIndicadorServicoDelivery() {
        return indicadorServicoDelivery;
    }


    /**
     * Sets the indicadorServicoDelivery value for this PatAlelo.
     * 
     * @param indicadorServicoDelivery   * Indica (S/N) se a loja física possui serviço de entrega em
     * domicílio para os clientes do estabelecimento comercial.
     */
    public void setIndicadorServicoDelivery(java.lang.String indicadorServicoDelivery) {
        this.indicadorServicoDelivery = indicadorServicoDelivery;
    }


    /**
     * Gets the indicadorVendaInternet value for this PatAlelo.
     * 
     * @return indicadorVendaInternet   * Indica (S/N) se a loja física possui serviço de venda pela
     * internet para os clientes do estabelecimento comercial.
     */
    public java.lang.String getIndicadorVendaInternet() {
        return indicadorVendaInternet;
    }


    /**
     * Sets the indicadorVendaInternet value for this PatAlelo.
     * 
     * @param indicadorVendaInternet   * Indica (S/N) se a loja física possui serviço de venda pela
     * internet para os clientes do estabelecimento comercial.
     */
    public void setIndicadorVendaInternet(java.lang.String indicadorVendaInternet) {
        this.indicadorVendaInternet = indicadorVendaInternet;
    }


    /**
     * Gets the indicadorApresentacaoCartao value for this PatAlelo.
     * 
     * @return indicadorApresentacaoCartao   * Indica (S/N) se o estabelecimento comercial aceita o cartão
     * presencialmente.
     */
    public java.lang.String getIndicadorApresentacaoCartao() {
        return indicadorApresentacaoCartao;
    }


    /**
     * Sets the indicadorApresentacaoCartao value for this PatAlelo.
     * 
     * @param indicadorApresentacaoCartao   * Indica (S/N) se o estabelecimento comercial aceita o cartão
     * presencialmente.
     */
    public void setIndicadorApresentacaoCartao(java.lang.String indicadorApresentacaoCartao) {
        this.indicadorApresentacaoCartao = indicadorApresentacaoCartao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof PatAlelo)) return false;
        PatAlelo other = (PatAlelo) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto()))) &&
            ((this.dataAfiliacao==null && other.getDataAfiliacao()==null) || 
             (this.dataAfiliacao!=null &&
              this.dataAfiliacao.equals(other.getDataAfiliacao()))) &&
            ((this.dadosLojaFisica==null && other.getDadosLojaFisica()==null) || 
             (this.dadosLojaFisica!=null &&
              this.dadosLojaFisica.equals(other.getDadosLojaFisica()))) &&
            ((this.indicadorServicoDelivery==null && other.getIndicadorServicoDelivery()==null) || 
             (this.indicadorServicoDelivery!=null &&
              this.indicadorServicoDelivery.equals(other.getIndicadorServicoDelivery()))) &&
            ((this.indicadorVendaInternet==null && other.getIndicadorVendaInternet()==null) || 
             (this.indicadorVendaInternet!=null &&
              this.indicadorVendaInternet.equals(other.getIndicadorVendaInternet()))) &&
            ((this.indicadorApresentacaoCartao==null && other.getIndicadorApresentacaoCartao()==null) || 
             (this.indicadorApresentacaoCartao!=null &&
              this.indicadorApresentacaoCartao.equals(other.getIndicadorApresentacaoCartao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        if (getDataAfiliacao() != null) {
            _hashCode += getDataAfiliacao().hashCode();
        }
        if (getDadosLojaFisica() != null) {
            _hashCode += getDadosLojaFisica().hashCode();
        }
        if (getIndicadorServicoDelivery() != null) {
            _hashCode += getIndicadorServicoDelivery().hashCode();
        }
        if (getIndicadorVendaInternet() != null) {
            _hashCode += getIndicadorVendaInternet().hashCode();
        }
        if (getIndicadorApresentacaoCartao() != null) {
            _hashCode += getIndicadorApresentacaoCartao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(PatAlelo.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "PatAlelo"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataAfiliacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataAfiliacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosLojaFisica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosLojaFisica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "LojaFisica"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorServicoDelivery");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorServicoDelivery"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVendaInternet");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "IndicadorVendaInternet"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorApresentacaoCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorApresentacaoCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
