/**
 * ProdutoServicoClienteType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ProdutoServicoClienteType  implements java.io.Serializable {
    private java.math.BigInteger codigoProdutoMatriz;

    private java.math.BigInteger codigoProdutoSecundario;

    public ProdutoServicoClienteType() {
    }

    public ProdutoServicoClienteType(
           java.math.BigInteger codigoProdutoMatriz,
           java.math.BigInteger codigoProdutoSecundario) {
           this.codigoProdutoMatriz = codigoProdutoMatriz;
           this.codigoProdutoSecundario = codigoProdutoSecundario;
    }


    /**
     * Gets the codigoProdutoMatriz value for this ProdutoServicoClienteType.
     * 
     * @return codigoProdutoMatriz
     */
    public java.math.BigInteger getCodigoProdutoMatriz() {
        return codigoProdutoMatriz;
    }


    /**
     * Sets the codigoProdutoMatriz value for this ProdutoServicoClienteType.
     * 
     * @param codigoProdutoMatriz
     */
    public void setCodigoProdutoMatriz(java.math.BigInteger codigoProdutoMatriz) {
        this.codigoProdutoMatriz = codigoProdutoMatriz;
    }


    /**
     * Gets the codigoProdutoSecundario value for this ProdutoServicoClienteType.
     * 
     * @return codigoProdutoSecundario
     */
    public java.math.BigInteger getCodigoProdutoSecundario() {
        return codigoProdutoSecundario;
    }


    /**
     * Sets the codigoProdutoSecundario value for this ProdutoServicoClienteType.
     * 
     * @param codigoProdutoSecundario
     */
    public void setCodigoProdutoSecundario(java.math.BigInteger codigoProdutoSecundario) {
        this.codigoProdutoSecundario = codigoProdutoSecundario;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProdutoServicoClienteType)) return false;
        ProdutoServicoClienteType other = (ProdutoServicoClienteType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoProdutoMatriz==null && other.getCodigoProdutoMatriz()==null) || 
             (this.codigoProdutoMatriz!=null &&
              this.codigoProdutoMatriz.equals(other.getCodigoProdutoMatriz()))) &&
            ((this.codigoProdutoSecundario==null && other.getCodigoProdutoSecundario()==null) || 
             (this.codigoProdutoSecundario!=null &&
              this.codigoProdutoSecundario.equals(other.getCodigoProdutoSecundario())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoProdutoMatriz() != null) {
            _hashCode += getCodigoProdutoMatriz().hashCode();
        }
        if (getCodigoProdutoSecundario() != null) {
            _hashCode += getCodigoProdutoSecundario().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProdutoServicoClienteType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ProdutoServicoClienteType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProdutoMatriz");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoProdutoMatriz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProdutoSecundario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoProdutoSecundario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
