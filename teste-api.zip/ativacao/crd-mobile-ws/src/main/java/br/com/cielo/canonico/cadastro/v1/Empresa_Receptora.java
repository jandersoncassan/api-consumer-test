/**
 * Empresa_Receptora.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Cadastro de empresas adquirentes que podem capturar transações
 * que serão liquidadas pela Cielo. Estas empresas são chamdas pela área
 * de produtos da Cielo como Vans.
 */
public class Empresa_Receptora  implements java.io.Serializable {
    /* Nome da empresa adquirente terceira que está autorizada a transacionar
     * o produto Cielo. */
    private java.lang.String nomeEmpresaReceptora;

    public Empresa_Receptora() {
    }

    public Empresa_Receptora(
           java.lang.String nomeEmpresaReceptora) {
           this.nomeEmpresaReceptora = nomeEmpresaReceptora;
    }


    /**
     * Gets the nomeEmpresaReceptora value for this Empresa_Receptora.
     * 
     * @return nomeEmpresaReceptora   * Nome da empresa adquirente terceira que está autorizada a transacionar
     * o produto Cielo.
     */
    public java.lang.String getNomeEmpresaReceptora() {
        return nomeEmpresaReceptora;
    }


    /**
     * Sets the nomeEmpresaReceptora value for this Empresa_Receptora.
     * 
     * @param nomeEmpresaReceptora   * Nome da empresa adquirente terceira que está autorizada a transacionar
     * o produto Cielo.
     */
    public void setNomeEmpresaReceptora(java.lang.String nomeEmpresaReceptora) {
        this.nomeEmpresaReceptora = nomeEmpresaReceptora;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Empresa_Receptora)) return false;
        Empresa_Receptora other = (Empresa_Receptora) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nomeEmpresaReceptora==null && other.getNomeEmpresaReceptora()==null) || 
             (this.nomeEmpresaReceptora!=null &&
              this.nomeEmpresaReceptora.equals(other.getNomeEmpresaReceptora())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNomeEmpresaReceptora() != null) {
            _hashCode += getNomeEmpresaReceptora().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Empresa_Receptora.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Empresa_Receptora"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEmpresaReceptora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "NomeEmpresaReceptora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
