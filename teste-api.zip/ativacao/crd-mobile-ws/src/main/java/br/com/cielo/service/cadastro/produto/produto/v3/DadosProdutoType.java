/**
 * DadosProdutoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class DadosProdutoType  extends br.com.cielo.canonico.cadastro.v1.Produto  implements java.io.Serializable {
    /* Campo enviado pelo SEC para ordenar a apresentação
     * 								do produtos na tela do CRM com base no faturamento da Cielo. */
    private java.math.BigInteger ordemApresentacao;

    /* Grupo de produtos de prazo flexível. */
    private br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType grupoProdutoPrazoFlexivel;

    private java.lang.String tipoGrupoProduto;

    public DadosProdutoType() {
    }

    public DadosProdutoType(
           java.lang.String nomeProduto,
           br.com.cielo.canonico.cadastro.v1.DadosBancarios dadosBancarios,
           java.math.BigInteger codigoProduto,
           java.lang.String numeroProduto,
           java.math.BigDecimal percentualTaxa,
           java.math.BigInteger quantidadeDiasPrazo,
           java.lang.String descricaoProduto,
           br.com.cielo.canonico.cadastro.v1.Tarifa dadosTarifa,
           java.math.BigInteger codigoEmpresa,
           java.lang.String numeroEmpresa,
           java.math.BigInteger codigoBandeira,
           java.lang.String numeroBandeira,
           java.math.BigInteger codigoFormaPagamento,
           java.lang.Boolean indicadorSecuratizacao,
           java.lang.Boolean indicadorSecuratizacaoAntecipacao,
           java.lang.String codigoLiquidacao,
           java.lang.String nomeTipoCobranca,
           java.lang.String nomeSituacaoBandeira,
           java.lang.String nomeBandeira,
           java.lang.String nomeTipoLiquidacao,
           java.util.Date dataHabilitacaoProdutoCliente,
           java.math.BigDecimal percentualDesconto,
           java.lang.Boolean indicadorVendaDigitada,
           java.lang.Boolean indicadorVendaDigitadaHabilitada,
           java.math.BigInteger ordemApresentacao,
           br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType grupoProdutoPrazoFlexivel,
           java.lang.String tipoGrupoProduto) {
        super(
            nomeProduto,
            dadosBancarios,
            codigoProduto,
            numeroProduto,
            percentualTaxa,
            quantidadeDiasPrazo,
            descricaoProduto,
            dadosTarifa,
            codigoEmpresa,
            numeroEmpresa,
            codigoBandeira,
            numeroBandeira,
            codigoFormaPagamento,
            indicadorSecuratizacao,
            indicadorSecuratizacaoAntecipacao,
            codigoLiquidacao,
            nomeTipoCobranca,
            nomeSituacaoBandeira,
            nomeBandeira,
            nomeTipoLiquidacao,
            dataHabilitacaoProdutoCliente,
            percentualDesconto,
            indicadorVendaDigitada,
            indicadorVendaDigitadaHabilitada);
        this.ordemApresentacao = ordemApresentacao;
        this.grupoProdutoPrazoFlexivel = grupoProdutoPrazoFlexivel;
        this.tipoGrupoProduto = tipoGrupoProduto;
    }


    /**
     * Gets the ordemApresentacao value for this DadosProdutoType.
     * 
     * @return ordemApresentacao   * Campo enviado pelo SEC para ordenar a apresentação
     * 								do produtos na tela do CRM com base no faturamento da Cielo.
     */
    public java.math.BigInteger getOrdemApresentacao() {
        return ordemApresentacao;
    }


    /**
     * Sets the ordemApresentacao value for this DadosProdutoType.
     * 
     * @param ordemApresentacao   * Campo enviado pelo SEC para ordenar a apresentação
     * 								do produtos na tela do CRM com base no faturamento da Cielo.
     */
    public void setOrdemApresentacao(java.math.BigInteger ordemApresentacao) {
        this.ordemApresentacao = ordemApresentacao;
    }


    /**
     * Gets the grupoProdutoPrazoFlexivel value for this DadosProdutoType.
     * 
     * @return grupoProdutoPrazoFlexivel   * Grupo de produtos de prazo flexível.
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType getGrupoProdutoPrazoFlexivel() {
        return grupoProdutoPrazoFlexivel;
    }


    /**
     * Sets the grupoProdutoPrazoFlexivel value for this DadosProdutoType.
     * 
     * @param grupoProdutoPrazoFlexivel   * Grupo de produtos de prazo flexível.
     */
    public void setGrupoProdutoPrazoFlexivel(br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType grupoProdutoPrazoFlexivel) {
        this.grupoProdutoPrazoFlexivel = grupoProdutoPrazoFlexivel;
    }


    /**
     * Gets the tipoGrupoProduto value for this DadosProdutoType.
     * 
     * @return tipoGrupoProduto
     */
    public java.lang.String getTipoGrupoProduto() {
        return tipoGrupoProduto;
    }


    /**
     * Sets the tipoGrupoProduto value for this DadosProdutoType.
     * 
     * @param tipoGrupoProduto
     */
    public void setTipoGrupoProduto(java.lang.String tipoGrupoProduto) {
        this.tipoGrupoProduto = tipoGrupoProduto;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosProdutoType)) return false;
        DadosProdutoType other = (DadosProdutoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = super.equals(obj) && 
            ((this.ordemApresentacao==null && other.getOrdemApresentacao()==null) || 
             (this.ordemApresentacao!=null &&
              this.ordemApresentacao.equals(other.getOrdemApresentacao()))) &&
            ((this.grupoProdutoPrazoFlexivel==null && other.getGrupoProdutoPrazoFlexivel()==null) || 
             (this.grupoProdutoPrazoFlexivel!=null &&
              this.grupoProdutoPrazoFlexivel.equals(other.getGrupoProdutoPrazoFlexivel()))) &&
            ((this.tipoGrupoProduto==null && other.getTipoGrupoProduto()==null) || 
             (this.tipoGrupoProduto!=null &&
              this.tipoGrupoProduto.equals(other.getTipoGrupoProduto())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = super.hashCode();
        if (getOrdemApresentacao() != null) {
            _hashCode += getOrdemApresentacao().hashCode();
        }
        if (getGrupoProdutoPrazoFlexivel() != null) {
            _hashCode += getGrupoProdutoPrazoFlexivel().hashCode();
        }
        if (getTipoGrupoProduto() != null) {
            _hashCode += getTipoGrupoProduto().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosProdutoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosProdutoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ordemApresentacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ordemApresentacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grupoProdutoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "grupoProdutoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "GrupoProdutoPrazoFlexivelType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoGrupoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "tipoGrupoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
