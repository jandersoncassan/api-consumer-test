/**
 * GrupoProdutoPrazoFlexivel.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Representa o agrupamento de produtos do prazo flexível.
 */
public class GrupoProdutoPrazoFlexivel  implements java.io.Serializable {
    /* O código de grupo de prazos flexíveis representa o agrupamento
     * de produtos do prazo flexível. */
    private java.math.BigInteger codigoGrupoPrazoFlexivel;

    /* Descrição do grupo de prazos flexíveis, que representa o agrupamento
     * de produtos do prazo flexível. */
    private java.lang.String descricaoGrupoPrazoFelxivel;

    private br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel[] dadosTarifasGrupoProdutoPrazoFlexivel;

    /* Relação de produtos de prazo flexível relacionados ao grupo. */
    private br.com.cielo.canonico.cadastro.v1.Produto[] dadosProdutos;

    public GrupoProdutoPrazoFlexivel() {
    }

    public GrupoProdutoPrazoFlexivel(
           java.math.BigInteger codigoGrupoPrazoFlexivel,
           java.lang.String descricaoGrupoPrazoFelxivel,
           br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel[] dadosTarifasGrupoProdutoPrazoFlexivel,
           br.com.cielo.canonico.cadastro.v1.Produto[] dadosProdutos) {
           this.codigoGrupoPrazoFlexivel = codigoGrupoPrazoFlexivel;
           this.descricaoGrupoPrazoFelxivel = descricaoGrupoPrazoFelxivel;
           this.dadosTarifasGrupoProdutoPrazoFlexivel = dadosTarifasGrupoProdutoPrazoFlexivel;
           this.dadosProdutos = dadosProdutos;
    }


    /**
     * Gets the codigoGrupoPrazoFlexivel value for this GrupoProdutoPrazoFlexivel.
     * 
     * @return codigoGrupoPrazoFlexivel   * O código de grupo de prazos flexíveis representa o agrupamento
     * de produtos do prazo flexível.
     */
    public java.math.BigInteger getCodigoGrupoPrazoFlexivel() {
        return codigoGrupoPrazoFlexivel;
    }


    /**
     * Sets the codigoGrupoPrazoFlexivel value for this GrupoProdutoPrazoFlexivel.
     * 
     * @param codigoGrupoPrazoFlexivel   * O código de grupo de prazos flexíveis representa o agrupamento
     * de produtos do prazo flexível.
     */
    public void setCodigoGrupoPrazoFlexivel(java.math.BigInteger codigoGrupoPrazoFlexivel) {
        this.codigoGrupoPrazoFlexivel = codigoGrupoPrazoFlexivel;
    }


    /**
     * Gets the descricaoGrupoPrazoFelxivel value for this GrupoProdutoPrazoFlexivel.
     * 
     * @return descricaoGrupoPrazoFelxivel   * Descrição do grupo de prazos flexíveis, que representa o agrupamento
     * de produtos do prazo flexível.
     */
    public java.lang.String getDescricaoGrupoPrazoFelxivel() {
        return descricaoGrupoPrazoFelxivel;
    }


    /**
     * Sets the descricaoGrupoPrazoFelxivel value for this GrupoProdutoPrazoFlexivel.
     * 
     * @param descricaoGrupoPrazoFelxivel   * Descrição do grupo de prazos flexíveis, que representa o agrupamento
     * de produtos do prazo flexível.
     */
    public void setDescricaoGrupoPrazoFelxivel(java.lang.String descricaoGrupoPrazoFelxivel) {
        this.descricaoGrupoPrazoFelxivel = descricaoGrupoPrazoFelxivel;
    }


    /**
     * Gets the dadosTarifasGrupoProdutoPrazoFlexivel value for this GrupoProdutoPrazoFlexivel.
     * 
     * @return dadosTarifasGrupoProdutoPrazoFlexivel
     */
    public br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel[] getDadosTarifasGrupoProdutoPrazoFlexivel() {
        return dadosTarifasGrupoProdutoPrazoFlexivel;
    }


    /**
     * Sets the dadosTarifasGrupoProdutoPrazoFlexivel value for this GrupoProdutoPrazoFlexivel.
     * 
     * @param dadosTarifasGrupoProdutoPrazoFlexivel
     */
    public void setDadosTarifasGrupoProdutoPrazoFlexivel(br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel[] dadosTarifasGrupoProdutoPrazoFlexivel) {
        this.dadosTarifasGrupoProdutoPrazoFlexivel = dadosTarifasGrupoProdutoPrazoFlexivel;
    }


    /**
     * Gets the dadosProdutos value for this GrupoProdutoPrazoFlexivel.
     * 
     * @return dadosProdutos   * Relação de produtos de prazo flexível relacionados ao grupo.
     */
    public br.com.cielo.canonico.cadastro.v1.Produto[] getDadosProdutos() {
        return dadosProdutos;
    }


    /**
     * Sets the dadosProdutos value for this GrupoProdutoPrazoFlexivel.
     * 
     * @param dadosProdutos   * Relação de produtos de prazo flexível relacionados ao grupo.
     */
    public void setDadosProdutos(br.com.cielo.canonico.cadastro.v1.Produto[] dadosProdutos) {
        this.dadosProdutos = dadosProdutos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof GrupoProdutoPrazoFlexivel)) return false;
        GrupoProdutoPrazoFlexivel other = (GrupoProdutoPrazoFlexivel) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoGrupoPrazoFlexivel==null && other.getCodigoGrupoPrazoFlexivel()==null) || 
             (this.codigoGrupoPrazoFlexivel!=null &&
              this.codigoGrupoPrazoFlexivel.equals(other.getCodigoGrupoPrazoFlexivel()))) &&
            ((this.descricaoGrupoPrazoFelxivel==null && other.getDescricaoGrupoPrazoFelxivel()==null) || 
             (this.descricaoGrupoPrazoFelxivel!=null &&
              this.descricaoGrupoPrazoFelxivel.equals(other.getDescricaoGrupoPrazoFelxivel()))) &&
            ((this.dadosTarifasGrupoProdutoPrazoFlexivel==null && other.getDadosTarifasGrupoProdutoPrazoFlexivel()==null) || 
             (this.dadosTarifasGrupoProdutoPrazoFlexivel!=null &&
              java.util.Arrays.equals(this.dadosTarifasGrupoProdutoPrazoFlexivel, other.getDadosTarifasGrupoProdutoPrazoFlexivel()))) &&
            ((this.dadosProdutos==null && other.getDadosProdutos()==null) || 
             (this.dadosProdutos!=null &&
              java.util.Arrays.equals(this.dadosProdutos, other.getDadosProdutos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoGrupoPrazoFlexivel() != null) {
            _hashCode += getCodigoGrupoPrazoFlexivel().hashCode();
        }
        if (getDescricaoGrupoPrazoFelxivel() != null) {
            _hashCode += getDescricaoGrupoPrazoFelxivel().hashCode();
        }
        if (getDadosTarifasGrupoProdutoPrazoFlexivel() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosTarifasGrupoProdutoPrazoFlexivel());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosTarifasGrupoProdutoPrazoFlexivel(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDadosProdutos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosProdutos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosProdutos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(GrupoProdutoPrazoFlexivel.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GrupoProdutoPrazoFlexivel"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoGrupoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoGrupoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoGrupoPrazoFelxivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoGrupoPrazoFelxivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosTarifasGrupoProdutoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosTarifasGrupoProdutoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifaGrupoProdutoPrazoFlexivel"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosTarifaGrupoProdutoPrazoFlexivel"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosProdutos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosProdutos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "produto"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
