/**
 * Email.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.corporativo.email.v3;

public interface Email extends java.rmi.Remote {

    /**
     * Operacao responsavel por enviar email
     */
    public br.com.cielo.service.corporativo.email.v3.EnviarEmailResponseType enviarEmail(br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestType parameters) throws java.rmi.RemoteException;
}
