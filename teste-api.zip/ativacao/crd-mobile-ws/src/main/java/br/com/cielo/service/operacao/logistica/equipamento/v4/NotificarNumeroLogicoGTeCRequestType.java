/**
 * NotificarNumeroLogicoGTeCRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.logistica.equipamento.v4;

public class NotificarNumeroLogicoGTeCRequestType  implements java.io.Serializable {
    private java.lang.String numeroLogico;

    private java.lang.String numeroLoja;

    private java.lang.String numeroEstabelecimento;

    private java.lang.String codigoModeloSolucaoMobile;

    private java.lang.String descricaoMarcaMobile;

    private br.com.cielo.service.operacao.logistica.equipamento.v4.TelefoneType telefone;

    private java.lang.String numeroNACMobile;

    private java.lang.Boolean indicadorLeitorCodigoBarras;

    private java.lang.String codigoModeloSolucaoDefinido;

    public NotificarNumeroLogicoGTeCRequestType() {
    }

    public NotificarNumeroLogicoGTeCRequestType(
           java.lang.String numeroLogico,
           java.lang.String numeroLoja,
           java.lang.String numeroEstabelecimento,
           java.lang.String codigoModeloSolucaoMobile,
           java.lang.String descricaoMarcaMobile,
           br.com.cielo.service.operacao.logistica.equipamento.v4.TelefoneType telefone,
           java.lang.String numeroNACMobile,
           java.lang.Boolean indicadorLeitorCodigoBarras,
           java.lang.String codigoModeloSolucaoDefinido) {
           this.numeroLogico = numeroLogico;
           this.numeroLoja = numeroLoja;
           this.numeroEstabelecimento = numeroEstabelecimento;
           this.codigoModeloSolucaoMobile = codigoModeloSolucaoMobile;
           this.descricaoMarcaMobile = descricaoMarcaMobile;
           this.telefone = telefone;
           this.numeroNACMobile = numeroNACMobile;
           this.indicadorLeitorCodigoBarras = indicadorLeitorCodigoBarras;
           this.codigoModeloSolucaoDefinido = codigoModeloSolucaoDefinido;
    }


    /**
     * Gets the numeroLogico value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return numeroLogico
     */
    public java.lang.String getNumeroLogico() {
        return numeroLogico;
    }


    /**
     * Sets the numeroLogico value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param numeroLogico
     */
    public void setNumeroLogico(java.lang.String numeroLogico) {
        this.numeroLogico = numeroLogico;
    }


    /**
     * Gets the numeroLoja value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return numeroLoja
     */
    public java.lang.String getNumeroLoja() {
        return numeroLoja;
    }


    /**
     * Sets the numeroLoja value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param numeroLoja
     */
    public void setNumeroLoja(java.lang.String numeroLoja) {
        this.numeroLoja = numeroLoja;
    }


    /**
     * Gets the numeroEstabelecimento value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return numeroEstabelecimento
     */
    public java.lang.String getNumeroEstabelecimento() {
        return numeroEstabelecimento;
    }


    /**
     * Sets the numeroEstabelecimento value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param numeroEstabelecimento
     */
    public void setNumeroEstabelecimento(java.lang.String numeroEstabelecimento) {
        this.numeroEstabelecimento = numeroEstabelecimento;
    }


    /**
     * Gets the codigoModeloSolucaoMobile value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return codigoModeloSolucaoMobile
     */
    public java.lang.String getCodigoModeloSolucaoMobile() {
        return codigoModeloSolucaoMobile;
    }


    /**
     * Sets the codigoModeloSolucaoMobile value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param codigoModeloSolucaoMobile
     */
    public void setCodigoModeloSolucaoMobile(java.lang.String codigoModeloSolucaoMobile) {
        this.codigoModeloSolucaoMobile = codigoModeloSolucaoMobile;
    }


    /**
     * Gets the descricaoMarcaMobile value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return descricaoMarcaMobile
     */
    public java.lang.String getDescricaoMarcaMobile() {
        return descricaoMarcaMobile;
    }


    /**
     * Sets the descricaoMarcaMobile value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param descricaoMarcaMobile
     */
    public void setDescricaoMarcaMobile(java.lang.String descricaoMarcaMobile) {
        this.descricaoMarcaMobile = descricaoMarcaMobile;
    }


    /**
     * Gets the telefone value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return telefone
     */
    public br.com.cielo.service.operacao.logistica.equipamento.v4.TelefoneType getTelefone() {
        return telefone;
    }


    /**
     * Sets the telefone value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param telefone
     */
    public void setTelefone(br.com.cielo.service.operacao.logistica.equipamento.v4.TelefoneType telefone) {
        this.telefone = telefone;
    }


    /**
     * Gets the numeroNACMobile value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return numeroNACMobile
     */
    public java.lang.String getNumeroNACMobile() {
        return numeroNACMobile;
    }


    /**
     * Sets the numeroNACMobile value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param numeroNACMobile
     */
    public void setNumeroNACMobile(java.lang.String numeroNACMobile) {
        this.numeroNACMobile = numeroNACMobile;
    }


    /**
     * Gets the indicadorLeitorCodigoBarras value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return indicadorLeitorCodigoBarras
     */
    public java.lang.Boolean getIndicadorLeitorCodigoBarras() {
        return indicadorLeitorCodigoBarras;
    }


    /**
     * Sets the indicadorLeitorCodigoBarras value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param indicadorLeitorCodigoBarras
     */
    public void setIndicadorLeitorCodigoBarras(java.lang.Boolean indicadorLeitorCodigoBarras) {
        this.indicadorLeitorCodigoBarras = indicadorLeitorCodigoBarras;
    }


    /**
     * Gets the codigoModeloSolucaoDefinido value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @return codigoModeloSolucaoDefinido
     */
    public java.lang.String getCodigoModeloSolucaoDefinido() {
        return codigoModeloSolucaoDefinido;
    }


    /**
     * Sets the codigoModeloSolucaoDefinido value for this NotificarNumeroLogicoGTeCRequestType.
     * 
     * @param codigoModeloSolucaoDefinido
     */
    public void setCodigoModeloSolucaoDefinido(java.lang.String codigoModeloSolucaoDefinido) {
        this.codigoModeloSolucaoDefinido = codigoModeloSolucaoDefinido;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NotificarNumeroLogicoGTeCRequestType)) return false;
        NotificarNumeroLogicoGTeCRequestType other = (NotificarNumeroLogicoGTeCRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroLogico==null && other.getNumeroLogico()==null) || 
             (this.numeroLogico!=null &&
              this.numeroLogico.equals(other.getNumeroLogico()))) &&
            ((this.numeroLoja==null && other.getNumeroLoja()==null) || 
             (this.numeroLoja!=null &&
              this.numeroLoja.equals(other.getNumeroLoja()))) &&
            ((this.numeroEstabelecimento==null && other.getNumeroEstabelecimento()==null) || 
             (this.numeroEstabelecimento!=null &&
              this.numeroEstabelecimento.equals(other.getNumeroEstabelecimento()))) &&
            ((this.codigoModeloSolucaoMobile==null && other.getCodigoModeloSolucaoMobile()==null) || 
             (this.codigoModeloSolucaoMobile!=null &&
              this.codigoModeloSolucaoMobile.equals(other.getCodigoModeloSolucaoMobile()))) &&
            ((this.descricaoMarcaMobile==null && other.getDescricaoMarcaMobile()==null) || 
             (this.descricaoMarcaMobile!=null &&
              this.descricaoMarcaMobile.equals(other.getDescricaoMarcaMobile()))) &&
            ((this.telefone==null && other.getTelefone()==null) || 
             (this.telefone!=null &&
              this.telefone.equals(other.getTelefone()))) &&
            ((this.numeroNACMobile==null && other.getNumeroNACMobile()==null) || 
             (this.numeroNACMobile!=null &&
              this.numeroNACMobile.equals(other.getNumeroNACMobile()))) &&
            ((this.indicadorLeitorCodigoBarras==null && other.getIndicadorLeitorCodigoBarras()==null) || 
             (this.indicadorLeitorCodigoBarras!=null &&
              this.indicadorLeitorCodigoBarras.equals(other.getIndicadorLeitorCodigoBarras()))) &&
            ((this.codigoModeloSolucaoDefinido==null && other.getCodigoModeloSolucaoDefinido()==null) || 
             (this.codigoModeloSolucaoDefinido!=null &&
              this.codigoModeloSolucaoDefinido.equals(other.getCodigoModeloSolucaoDefinido())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroLogico() != null) {
            _hashCode += getNumeroLogico().hashCode();
        }
        if (getNumeroLoja() != null) {
            _hashCode += getNumeroLoja().hashCode();
        }
        if (getNumeroEstabelecimento() != null) {
            _hashCode += getNumeroEstabelecimento().hashCode();
        }
        if (getCodigoModeloSolucaoMobile() != null) {
            _hashCode += getCodigoModeloSolucaoMobile().hashCode();
        }
        if (getDescricaoMarcaMobile() != null) {
            _hashCode += getDescricaoMarcaMobile().hashCode();
        }
        if (getTelefone() != null) {
            _hashCode += getTelefone().hashCode();
        }
        if (getNumeroNACMobile() != null) {
            _hashCode += getNumeroNACMobile().hashCode();
        }
        if (getIndicadorLeitorCodigoBarras() != null) {
            _hashCode += getIndicadorLeitorCodigoBarras().hashCode();
        }
        if (getCodigoModeloSolucaoDefinido() != null) {
            _hashCode += getCodigoModeloSolucaoDefinido().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NotificarNumeroLogicoGTeCRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "notificarNumeroLogicoGTeCRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "numeroLogico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLoja");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "numeroLoja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "numeroEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoModeloSolucaoMobile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "codigoModeloSolucaoMobile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoMarcaMobile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "descricaoMarcaMobile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "telefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "TelefoneType"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroNACMobile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "numeroNACMobile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorLeitorCodigoBarras");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "indicadorLeitorCodigoBarras"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoModeloSolucaoDefinido");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "codigoModeloSolucaoDefinido"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
