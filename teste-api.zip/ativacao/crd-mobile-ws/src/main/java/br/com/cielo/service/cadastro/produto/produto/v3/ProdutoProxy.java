package br.com.cielo.service.cadastro.produto.produto.v3;

public class ProdutoProxy implements br.com.cielo.service.cadastro.produto.produto.v3.Produto_PortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.produto.produto.v3.Produto_PortType produto_PortType = null;
  
  public ProdutoProxy() {
    _initProdutoProxy();
  }
  
  public ProdutoProxy(String endpoint) {
    _endpoint = endpoint;
    _initProdutoProxy();
  }
  
  private void _initProdutoProxy() {
    try {
      produto_PortType = (new br.com.cielo.service.cadastro.produto.produto.v3.Produto_ServiceLocator()).getProdutoSOAP();
      if (produto_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)produto_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)produto_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (produto_PortType != null)
      ((javax.xml.rpc.Stub)produto_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.Produto_PortType getProduto_PortType() {
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType;
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosHabilitadoClienteResponse consultarProdutosHabilitadoCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosHabilitadoClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarProdutosHabilitadoCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoHabilitadoClienteResponse consultarDetalheProdutoHabilitadoCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoHabilitadoClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarDetalheProdutoHabilitadoCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosElegiveisClienteResponse consultarProdutosElegiveisCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosElegiveisClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarProdutosElegiveisCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoElegivelClienteResponse consultarDetalheProdutoElegivelCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoElegivelClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarDetalheProdutoElegivelCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosNaoElegiveisClienteResponse consultarProdutosNaoElegiveisCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosNaoElegiveisClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarProdutosNaoElegiveisCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoNaoElegivelClienteResponse consultarDetalheProdutoNaoElegivelCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoNaoElegivelClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarDetalheProdutoNaoElegivelCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoMultivanContratadoClienteResponse consultarDetalheProdutoMultivanContratadoCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarDetalheProdutoMultivanContratadoClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarDetalheProdutoMultivanContratadoCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.HabilitarProdutoResponse habilitarProduto(br.com.cielo.service.cadastro.produto.produto.v3.HabilitarProdutoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.habilitarProduto(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.DesabilitarProdutoResponse desabilitarProduto(br.com.cielo.service.cadastro.produto.produto.v3.DesabilitarProdutoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.desabilitarProduto(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.AlterarParcelaFaixaProdutoResponse alterarParcelaFaixaProduto(br.com.cielo.service.cadastro.produto.produto.v3.AlterarParcelaFaixaProdutoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.alterarParcelaFaixaProduto(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.HabilitarDesabilitarVendaDigitadaResponse habilitarDesabilitarVendaDigitada(br.com.cielo.service.cadastro.produto.produto.v3.HabilitarDesabilitarVendaDigitadaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.habilitarDesabilitarVendaDigitada(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ValidarPermissaoVendaDigitadaResponse validarPermissaoVendaDigitada(br.com.cielo.service.cadastro.produto.produto.v3.ValidarPermissaoVendaDigitadaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.validarPermissaoVendaDigitada(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosPrazoFlexivelResponse consultarProdutosPrazoFlexivel(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosPrazoFlexivelRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarProdutosPrazoFlexivel(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarInformacaoPatAleloResponse consultarInformacaoPatAlelo(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarInformacaoPatAleloRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarInformacaoPatAlelo(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosDesabilitadosResponse consultarProdutosDesabilitados(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosDesabilitadosRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarProdutosDesabilitados(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarOrdemProdutoResponse consultarOrdemProduto(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarOrdemProdutoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarOrdemProduto(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosServicosClienteResponse consultarProdutosServicosCliente(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarProdutosServicosClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarProdutosServicosCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoResponse habilitarListaProduto(br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.habilitarListaProduto(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarTaxaPrazoResponse consultarTaxaPrazo(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarTaxaPrazoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.consultarTaxaPrazo(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v3.NotificarProdutosNaoHabilitadosResponse notificarProdutosNaoHabilitados(br.com.cielo.service.cadastro.produto.produto.v3.NotificarProdutosNaoHabilitadosRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (produto_PortType == null)
      _initProdutoProxy();
    return produto_PortType.notificarProdutosNaoHabilitados(parameters, header);
  }
  
  
}