/**
 * SituacaoFuncionamentoCliente.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class SituacaoFuncionamentoCliente  implements java.io.Serializable {
    private java.lang.String codigoSituacaoCliente;

    private java.util.Date dataReabertura;

    private java.util.Date dataFechamento;

    private java.lang.String codigoMotivoFechamento;

    /* Descricao do motivo de fechamento */
    private java.lang.String nomeMotivoFechamento;

    public SituacaoFuncionamentoCliente() {
    }

    public SituacaoFuncionamentoCliente(
           java.lang.String codigoSituacaoCliente,
           java.util.Date dataReabertura,
           java.util.Date dataFechamento,
           java.lang.String codigoMotivoFechamento,
           java.lang.String nomeMotivoFechamento) {
           this.codigoSituacaoCliente = codigoSituacaoCliente;
           this.dataReabertura = dataReabertura;
           this.dataFechamento = dataFechamento;
           this.codigoMotivoFechamento = codigoMotivoFechamento;
           this.nomeMotivoFechamento = nomeMotivoFechamento;
    }


    /**
     * Gets the codigoSituacaoCliente value for this SituacaoFuncionamentoCliente.
     * 
     * @return codigoSituacaoCliente
     */
    public java.lang.String getCodigoSituacaoCliente() {
        return codigoSituacaoCliente;
    }


    /**
     * Sets the codigoSituacaoCliente value for this SituacaoFuncionamentoCliente.
     * 
     * @param codigoSituacaoCliente
     */
    public void setCodigoSituacaoCliente(java.lang.String codigoSituacaoCliente) {
        this.codigoSituacaoCliente = codigoSituacaoCliente;
    }


    /**
     * Gets the dataReabertura value for this SituacaoFuncionamentoCliente.
     * 
     * @return dataReabertura
     */
    public java.util.Date getDataReabertura() {
        return dataReabertura;
    }


    /**
     * Sets the dataReabertura value for this SituacaoFuncionamentoCliente.
     * 
     * @param dataReabertura
     */
    public void setDataReabertura(java.util.Date dataReabertura) {
        this.dataReabertura = dataReabertura;
    }


    /**
     * Gets the dataFechamento value for this SituacaoFuncionamentoCliente.
     * 
     * @return dataFechamento
     */
    public java.util.Date getDataFechamento() {
        return dataFechamento;
    }


    /**
     * Sets the dataFechamento value for this SituacaoFuncionamentoCliente.
     * 
     * @param dataFechamento
     */
    public void setDataFechamento(java.util.Date dataFechamento) {
        this.dataFechamento = dataFechamento;
    }


    /**
     * Gets the codigoMotivoFechamento value for this SituacaoFuncionamentoCliente.
     * 
     * @return codigoMotivoFechamento
     */
    public java.lang.String getCodigoMotivoFechamento() {
        return codigoMotivoFechamento;
    }


    /**
     * Sets the codigoMotivoFechamento value for this SituacaoFuncionamentoCliente.
     * 
     * @param codigoMotivoFechamento
     */
    public void setCodigoMotivoFechamento(java.lang.String codigoMotivoFechamento) {
        this.codigoMotivoFechamento = codigoMotivoFechamento;
    }


    /**
     * Gets the nomeMotivoFechamento value for this SituacaoFuncionamentoCliente.
     * 
     * @return nomeMotivoFechamento   * Descricao do motivo de fechamento
     */
    public java.lang.String getNomeMotivoFechamento() {
        return nomeMotivoFechamento;
    }


    /**
     * Sets the nomeMotivoFechamento value for this SituacaoFuncionamentoCliente.
     * 
     * @param nomeMotivoFechamento   * Descricao do motivo de fechamento
     */
    public void setNomeMotivoFechamento(java.lang.String nomeMotivoFechamento) {
        this.nomeMotivoFechamento = nomeMotivoFechamento;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SituacaoFuncionamentoCliente)) return false;
        SituacaoFuncionamentoCliente other = (SituacaoFuncionamentoCliente) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoSituacaoCliente==null && other.getCodigoSituacaoCliente()==null) || 
             (this.codigoSituacaoCliente!=null &&
              this.codigoSituacaoCliente.equals(other.getCodigoSituacaoCliente()))) &&
            ((this.dataReabertura==null && other.getDataReabertura()==null) || 
             (this.dataReabertura!=null &&
              this.dataReabertura.equals(other.getDataReabertura()))) &&
            ((this.dataFechamento==null && other.getDataFechamento()==null) || 
             (this.dataFechamento!=null &&
              this.dataFechamento.equals(other.getDataFechamento()))) &&
            ((this.codigoMotivoFechamento==null && other.getCodigoMotivoFechamento()==null) || 
             (this.codigoMotivoFechamento!=null &&
              this.codigoMotivoFechamento.equals(other.getCodigoMotivoFechamento()))) &&
            ((this.nomeMotivoFechamento==null && other.getNomeMotivoFechamento()==null) || 
             (this.nomeMotivoFechamento!=null &&
              this.nomeMotivoFechamento.equals(other.getNomeMotivoFechamento())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoSituacaoCliente() != null) {
            _hashCode += getCodigoSituacaoCliente().hashCode();
        }
        if (getDataReabertura() != null) {
            _hashCode += getDataReabertura().hashCode();
        }
        if (getDataFechamento() != null) {
            _hashCode += getDataFechamento().hashCode();
        }
        if (getCodigoMotivoFechamento() != null) {
            _hashCode += getCodigoMotivoFechamento().hashCode();
        }
        if (getNomeMotivoFechamento() != null) {
            _hashCode += getNomeMotivoFechamento().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SituacaoFuncionamentoCliente.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacaoFuncionamentoCliente"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSituacaoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoSituacaoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataReabertura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataReabertura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataFechamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataFechamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoMotivoFechamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoMotivoFechamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeMotivoFechamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeMotivoFechamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
