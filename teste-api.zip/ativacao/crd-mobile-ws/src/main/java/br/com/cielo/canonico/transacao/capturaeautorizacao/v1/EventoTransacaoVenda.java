/**
 * EventoTransacaoVenda.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.transacao.capturaeautorizacao.v1;


/**
 * Cada evento do ciclo de vida de uma transacao de venda desde a
 * sua autorizacao ate qualquer contestacao que ocorra apos sua liquidacao
 * (cancelamento de venda, chargeback, etc)
 */
public class EventoTransacaoVenda  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o seu cliente */
    private java.lang.Long codigoCliente;

    /* Numero unico atribuido a uma transacao de venda pelo sistema
     * STAR  no momento em que e processada a sua captura. Este numero nao
     * corresponde ao NSU e nem ao Reference Number. */
    private java.lang.String numeroReferenciaUnico;

    /* Data em que ocorreu algum evento relacionado a uma transacao
     * de venda. */
    private java.util.Date dataEvento;

    /* Nome do evento que pode ser:
     *                   - Autorizacao: Representa o momento em que a autorizacao
     * da transacao foi confirmada;
     *                   - Captura:Representa o momento que a captura da
     * transacao foi efetuada para inicio do processo de liquidacao financeira;
     * - Agendamento:Representa o momento em que o agendamento do pagamento
     * da transacao para o estabelecimento comercial foi efetuado. Para cada
     * evento de captura sera gerado um ou mais eventos de agendamento, de
     * acordo com o tipo de venda. Se tivermos uma venda credito a vista
     * ou debito, teremos apenas um agendamento. Se tivermos uma venda parcelado
     * loja, teremos tantos agendamentos quanto o numero de parcelas da venda.
     * Ou seja, se a venda parcelado loja tiver 5 parcelas, serao gerados
     * 5 eventos de agendamento, um para cada parcela.
     *                   - Pagamento: Representa o momento em que o pagamento
     * da transacao para o estabelecimento comercial foi efetuado na conta-corrente
     * dele.
     *                   Podem existir outros eventos que surgirao no nascimento
     * de outras transacoes financeiras decorrentes desta venda, como por
     * exemplo, o seu cancelamento, chargeback, etc. */
    private java.lang.String nomeEvento;

    /* Situacao do evento e o Indicador de estagio do evento
     *                   Se o evento for uma autorizacao de venda, a situacao
     * do evento sera a situacao da autorizacao (Aprovada; Negada; Desfeita)
     * Se o evento for a carga da transacao de venda na BaseII, a situacao
     * do evento sera a situacao apos o processamento desta carga (Capturada,
     * Rejeitada)
     *                   Se o evento for de um agendamento, a situacao do
     * evento sera (Agendada)
     *                   Se o evento for de pagamento, a situacao do evento
     * sera a situacao do pagamento (liquidado na data, pendente de pagamento
     * por erro no Domicilio, pendente por nao receber do banco a confirmacao
     * do pagamento realizado etc */
    private java.lang.String nomeSituacaoEvento;

    /* Nome do tipo de transacao realziada no evento
     *          Regra aplicada:
     *          1. Tipo de movimento + "Parcela" + (n/t), em que o tipo de
     * movimento sera venda, cancelamento ou reversao de cancelamento. "n"
     * e o numero da parcela e "t" o numero total de parcelas. Caso o tipo
     * de pagamento nao seja do tipo parcelado loja, a palavra "Parcela"
     * e o numero de parcelas (n/t) nao devera ser exibido. 
     *          2. Caso o cancelamento ou reversao de cancelamento nao esteja
     * associado a uma parcela, o tipo de transacao sera: Tipo de movimento
     * + ("Parcelas pagas" - se tipo de pagamento for parcelado loja ou "Venda
     * paga" - se tipo de pagamento for diferente de parcelado loja) */
    private java.lang.String nomeTipoTransacao;

    /* Indicador de envio para a Bandeira no processo de clearing.
     * 
     *          Sera exibido somente para o evento lancamento de agendamento. */
    private java.lang.String indicadorEnvioBandeira;

    /* Informacoes especificas do Tipo de transacao Cancelamento ou
     * Reversao de Cancelamento:
     *          detalha o motivo do status do cancelamento, normalmente o
     * motivo de rejeicao do cancelamento */
    private java.lang.String descricaoDetalheCancelamento;

    /* Numero que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN. */
    private java.lang.String codigoBanco;

    public EventoTransacaoVenda() {
    }

    public EventoTransacaoVenda(
           java.lang.Long codigoCliente,
           java.lang.String numeroReferenciaUnico,
           java.util.Date dataEvento,
           java.lang.String nomeEvento,
           java.lang.String nomeSituacaoEvento,
           java.lang.String nomeTipoTransacao,
           java.lang.String indicadorEnvioBandeira,
           java.lang.String descricaoDetalheCancelamento,
           java.lang.String codigoBanco) {
           this.codigoCliente = codigoCliente;
           this.numeroReferenciaUnico = numeroReferenciaUnico;
           this.dataEvento = dataEvento;
           this.nomeEvento = nomeEvento;
           this.nomeSituacaoEvento = nomeSituacaoEvento;
           this.nomeTipoTransacao = nomeTipoTransacao;
           this.indicadorEnvioBandeira = indicadorEnvioBandeira;
           this.descricaoDetalheCancelamento = descricaoDetalheCancelamento;
           this.codigoBanco = codigoBanco;
    }


    /**
     * Gets the codigoCliente value for this EventoTransacaoVenda.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o seu cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this EventoTransacaoVenda.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o seu cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the numeroReferenciaUnico value for this EventoTransacaoVenda.
     * 
     * @return numeroReferenciaUnico   * Numero unico atribuido a uma transacao de venda pelo sistema
     * STAR  no momento em que e processada a sua captura. Este numero nao
     * corresponde ao NSU e nem ao Reference Number.
     */
    public java.lang.String getNumeroReferenciaUnico() {
        return numeroReferenciaUnico;
    }


    /**
     * Sets the numeroReferenciaUnico value for this EventoTransacaoVenda.
     * 
     * @param numeroReferenciaUnico   * Numero unico atribuido a uma transacao de venda pelo sistema
     * STAR  no momento em que e processada a sua captura. Este numero nao
     * corresponde ao NSU e nem ao Reference Number.
     */
    public void setNumeroReferenciaUnico(java.lang.String numeroReferenciaUnico) {
        this.numeroReferenciaUnico = numeroReferenciaUnico;
    }


    /**
     * Gets the dataEvento value for this EventoTransacaoVenda.
     * 
     * @return dataEvento   * Data em que ocorreu algum evento relacionado a uma transacao
     * de venda.
     */
    public java.util.Date getDataEvento() {
        return dataEvento;
    }


    /**
     * Sets the dataEvento value for this EventoTransacaoVenda.
     * 
     * @param dataEvento   * Data em que ocorreu algum evento relacionado a uma transacao
     * de venda.
     */
    public void setDataEvento(java.util.Date dataEvento) {
        this.dataEvento = dataEvento;
    }


    /**
     * Gets the nomeEvento value for this EventoTransacaoVenda.
     * 
     * @return nomeEvento   * Nome do evento que pode ser:
     *                   - Autorizacao: Representa o momento em que a autorizacao
     * da transacao foi confirmada;
     *                   - Captura:Representa o momento que a captura da
     * transacao foi efetuada para inicio do processo de liquidacao financeira;
     * - Agendamento:Representa o momento em que o agendamento do pagamento
     * da transacao para o estabelecimento comercial foi efetuado. Para cada
     * evento de captura sera gerado um ou mais eventos de agendamento, de
     * acordo com o tipo de venda. Se tivermos uma venda credito a vista
     * ou debito, teremos apenas um agendamento. Se tivermos uma venda parcelado
     * loja, teremos tantos agendamentos quanto o numero de parcelas da venda.
     * Ou seja, se a venda parcelado loja tiver 5 parcelas, serao gerados
     * 5 eventos de agendamento, um para cada parcela.
     *                   - Pagamento: Representa o momento em que o pagamento
     * da transacao para o estabelecimento comercial foi efetuado na conta-corrente
     * dele.
     *                   Podem existir outros eventos que surgirao no nascimento
     * de outras transacoes financeiras decorrentes desta venda, como por
     * exemplo, o seu cancelamento, chargeback, etc.
     */
    public java.lang.String getNomeEvento() {
        return nomeEvento;
    }


    /**
     * Sets the nomeEvento value for this EventoTransacaoVenda.
     * 
     * @param nomeEvento   * Nome do evento que pode ser:
     *                   - Autorizacao: Representa o momento em que a autorizacao
     * da transacao foi confirmada;
     *                   - Captura:Representa o momento que a captura da
     * transacao foi efetuada para inicio do processo de liquidacao financeira;
     * - Agendamento:Representa o momento em que o agendamento do pagamento
     * da transacao para o estabelecimento comercial foi efetuado. Para cada
     * evento de captura sera gerado um ou mais eventos de agendamento, de
     * acordo com o tipo de venda. Se tivermos uma venda credito a vista
     * ou debito, teremos apenas um agendamento. Se tivermos uma venda parcelado
     * loja, teremos tantos agendamentos quanto o numero de parcelas da venda.
     * Ou seja, se a venda parcelado loja tiver 5 parcelas, serao gerados
     * 5 eventos de agendamento, um para cada parcela.
     *                   - Pagamento: Representa o momento em que o pagamento
     * da transacao para o estabelecimento comercial foi efetuado na conta-corrente
     * dele.
     *                   Podem existir outros eventos que surgirao no nascimento
     * de outras transacoes financeiras decorrentes desta venda, como por
     * exemplo, o seu cancelamento, chargeback, etc.
     */
    public void setNomeEvento(java.lang.String nomeEvento) {
        this.nomeEvento = nomeEvento;
    }


    /**
     * Gets the nomeSituacaoEvento value for this EventoTransacaoVenda.
     * 
     * @return nomeSituacaoEvento   * Situacao do evento e o Indicador de estagio do evento
     *                   Se o evento for uma autorizacao de venda, a situacao
     * do evento sera a situacao da autorizacao (Aprovada; Negada; Desfeita)
     * Se o evento for a carga da transacao de venda na BaseII, a situacao
     * do evento sera a situacao apos o processamento desta carga (Capturada,
     * Rejeitada)
     *                   Se o evento for de um agendamento, a situacao do
     * evento sera (Agendada)
     *                   Se o evento for de pagamento, a situacao do evento
     * sera a situacao do pagamento (liquidado na data, pendente de pagamento
     * por erro no Domicilio, pendente por nao receber do banco a confirmacao
     * do pagamento realizado etc
     */
    public java.lang.String getNomeSituacaoEvento() {
        return nomeSituacaoEvento;
    }


    /**
     * Sets the nomeSituacaoEvento value for this EventoTransacaoVenda.
     * 
     * @param nomeSituacaoEvento   * Situacao do evento e o Indicador de estagio do evento
     *                   Se o evento for uma autorizacao de venda, a situacao
     * do evento sera a situacao da autorizacao (Aprovada; Negada; Desfeita)
     * Se o evento for a carga da transacao de venda na BaseII, a situacao
     * do evento sera a situacao apos o processamento desta carga (Capturada,
     * Rejeitada)
     *                   Se o evento for de um agendamento, a situacao do
     * evento sera (Agendada)
     *                   Se o evento for de pagamento, a situacao do evento
     * sera a situacao do pagamento (liquidado na data, pendente de pagamento
     * por erro no Domicilio, pendente por nao receber do banco a confirmacao
     * do pagamento realizado etc
     */
    public void setNomeSituacaoEvento(java.lang.String nomeSituacaoEvento) {
        this.nomeSituacaoEvento = nomeSituacaoEvento;
    }


    /**
     * Gets the nomeTipoTransacao value for this EventoTransacaoVenda.
     * 
     * @return nomeTipoTransacao   * Nome do tipo de transacao realziada no evento
     *          Regra aplicada:
     *          1. Tipo de movimento + "Parcela" + (n/t), em que o tipo de
     * movimento sera venda, cancelamento ou reversao de cancelamento. "n"
     * e o numero da parcela e "t" o numero total de parcelas. Caso o tipo
     * de pagamento nao seja do tipo parcelado loja, a palavra "Parcela"
     * e o numero de parcelas (n/t) nao devera ser exibido. 
     *          2. Caso o cancelamento ou reversao de cancelamento nao esteja
     * associado a uma parcela, o tipo de transacao sera: Tipo de movimento
     * + ("Parcelas pagas" - se tipo de pagamento for parcelado loja ou "Venda
     * paga" - se tipo de pagamento for diferente de parcelado loja)
     */
    public java.lang.String getNomeTipoTransacao() {
        return nomeTipoTransacao;
    }


    /**
     * Sets the nomeTipoTransacao value for this EventoTransacaoVenda.
     * 
     * @param nomeTipoTransacao   * Nome do tipo de transacao realziada no evento
     *          Regra aplicada:
     *          1. Tipo de movimento + "Parcela" + (n/t), em que o tipo de
     * movimento sera venda, cancelamento ou reversao de cancelamento. "n"
     * e o numero da parcela e "t" o numero total de parcelas. Caso o tipo
     * de pagamento nao seja do tipo parcelado loja, a palavra "Parcela"
     * e o numero de parcelas (n/t) nao devera ser exibido. 
     *          2. Caso o cancelamento ou reversao de cancelamento nao esteja
     * associado a uma parcela, o tipo de transacao sera: Tipo de movimento
     * + ("Parcelas pagas" - se tipo de pagamento for parcelado loja ou "Venda
     * paga" - se tipo de pagamento for diferente de parcelado loja)
     */
    public void setNomeTipoTransacao(java.lang.String nomeTipoTransacao) {
        this.nomeTipoTransacao = nomeTipoTransacao;
    }


    /**
     * Gets the indicadorEnvioBandeira value for this EventoTransacaoVenda.
     * 
     * @return indicadorEnvioBandeira   * Indicador de envio para a Bandeira no processo de clearing.
     * 
     *          Sera exibido somente para o evento lancamento de agendamento.
     */
    public java.lang.String getIndicadorEnvioBandeira() {
        return indicadorEnvioBandeira;
    }


    /**
     * Sets the indicadorEnvioBandeira value for this EventoTransacaoVenda.
     * 
     * @param indicadorEnvioBandeira   * Indicador de envio para a Bandeira no processo de clearing.
     * 
     *          Sera exibido somente para o evento lancamento de agendamento.
     */
    public void setIndicadorEnvioBandeira(java.lang.String indicadorEnvioBandeira) {
        this.indicadorEnvioBandeira = indicadorEnvioBandeira;
    }


    /**
     * Gets the descricaoDetalheCancelamento value for this EventoTransacaoVenda.
     * 
     * @return descricaoDetalheCancelamento   * Informacoes especificas do Tipo de transacao Cancelamento ou
     * Reversao de Cancelamento:
     *          detalha o motivo do status do cancelamento, normalmente o
     * motivo de rejeicao do cancelamento
     */
    public java.lang.String getDescricaoDetalheCancelamento() {
        return descricaoDetalheCancelamento;
    }


    /**
     * Sets the descricaoDetalheCancelamento value for this EventoTransacaoVenda.
     * 
     * @param descricaoDetalheCancelamento   * Informacoes especificas do Tipo de transacao Cancelamento ou
     * Reversao de Cancelamento:
     *          detalha o motivo do status do cancelamento, normalmente o
     * motivo de rejeicao do cancelamento
     */
    public void setDescricaoDetalheCancelamento(java.lang.String descricaoDetalheCancelamento) {
        this.descricaoDetalheCancelamento = descricaoDetalheCancelamento;
    }


    /**
     * Gets the codigoBanco value for this EventoTransacaoVenda.
     * 
     * @return codigoBanco   * Numero que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public java.lang.String getCodigoBanco() {
        return codigoBanco;
    }


    /**
     * Sets the codigoBanco value for this EventoTransacaoVenda.
     * 
     * @param codigoBanco   * Numero que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public void setCodigoBanco(java.lang.String codigoBanco) {
        this.codigoBanco = codigoBanco;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EventoTransacaoVenda)) return false;
        EventoTransacaoVenda other = (EventoTransacaoVenda) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.numeroReferenciaUnico==null && other.getNumeroReferenciaUnico()==null) || 
             (this.numeroReferenciaUnico!=null &&
              this.numeroReferenciaUnico.equals(other.getNumeroReferenciaUnico()))) &&
            ((this.dataEvento==null && other.getDataEvento()==null) || 
             (this.dataEvento!=null &&
              this.dataEvento.equals(other.getDataEvento()))) &&
            ((this.nomeEvento==null && other.getNomeEvento()==null) || 
             (this.nomeEvento!=null &&
              this.nomeEvento.equals(other.getNomeEvento()))) &&
            ((this.nomeSituacaoEvento==null && other.getNomeSituacaoEvento()==null) || 
             (this.nomeSituacaoEvento!=null &&
              this.nomeSituacaoEvento.equals(other.getNomeSituacaoEvento()))) &&
            ((this.nomeTipoTransacao==null && other.getNomeTipoTransacao()==null) || 
             (this.nomeTipoTransacao!=null &&
              this.nomeTipoTransacao.equals(other.getNomeTipoTransacao()))) &&
            ((this.indicadorEnvioBandeira==null && other.getIndicadorEnvioBandeira()==null) || 
             (this.indicadorEnvioBandeira!=null &&
              this.indicadorEnvioBandeira.equals(other.getIndicadorEnvioBandeira()))) &&
            ((this.descricaoDetalheCancelamento==null && other.getDescricaoDetalheCancelamento()==null) || 
             (this.descricaoDetalheCancelamento!=null &&
              this.descricaoDetalheCancelamento.equals(other.getDescricaoDetalheCancelamento()))) &&
            ((this.codigoBanco==null && other.getCodigoBanco()==null) || 
             (this.codigoBanco!=null &&
              this.codigoBanco.equals(other.getCodigoBanco())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getNumeroReferenciaUnico() != null) {
            _hashCode += getNumeroReferenciaUnico().hashCode();
        }
        if (getDataEvento() != null) {
            _hashCode += getDataEvento().hashCode();
        }
        if (getNomeEvento() != null) {
            _hashCode += getNomeEvento().hashCode();
        }
        if (getNomeSituacaoEvento() != null) {
            _hashCode += getNomeSituacaoEvento().hashCode();
        }
        if (getNomeTipoTransacao() != null) {
            _hashCode += getNomeTipoTransacao().hashCode();
        }
        if (getIndicadorEnvioBandeira() != null) {
            _hashCode += getIndicadorEnvioBandeira().hashCode();
        }
        if (getDescricaoDetalheCancelamento() != null) {
            _hashCode += getDescricaoDetalheCancelamento().hashCode();
        }
        if (getCodigoBanco() != null) {
            _hashCode += getCodigoBanco().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EventoTransacaoVenda.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "EventoTransacaoVenda"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroReferenciaUnico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroReferenciaUnico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataEvento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dataEvento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEvento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeEvento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeSituacaoEvento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeSituacaoEvento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeTipoTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorEnvioBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "indicadorEnvioBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoDetalheCancelamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoDetalheCancelamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
