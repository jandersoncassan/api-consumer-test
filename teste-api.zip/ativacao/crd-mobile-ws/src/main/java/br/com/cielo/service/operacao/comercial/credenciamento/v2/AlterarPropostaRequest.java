/**
 * AlterarPropostaRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class AlterarPropostaRequest  implements java.io.Serializable {
    private long numeroProposta;

    private java.lang.String numeroCpfCnpj;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCodigoTipoPessoa codigoTipoPessoa;

    private long codigoCliente;

    private java.lang.String nomeRazaoSocial;

    private boolean indicadorMicroEmpreendedorIndividual;

    private java.lang.Long numeroInscricaoEstadual;

    private java.lang.String nomeFantasia;

    private java.lang.String nomePLaqueta;

    private java.lang.String nomePessoaContato;

    private long codigoRamoAtividade;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.BancoType domicilioBancarioCliente;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCategoriaCredenciamento categoriaCredenciamento;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestPrioridadeProposta prioridadeProposta;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneType[] telefoneEstabelecimento;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoType[] enderecoEstabelecimento;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoAlterarPropostaType[] servicos;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaType[] solucaoCaptura;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoAlterarPropostaType[] produtos;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.DadosProprietarioType[] proprietarios;

    private int codigoSituacao;

    private int codigoEtapa;

    private int codigoSituacaoEtapa;

    public AlterarPropostaRequest() {
    }

    public AlterarPropostaRequest(
           long numeroProposta,
           java.lang.String numeroCpfCnpj,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCodigoTipoPessoa codigoTipoPessoa,
           long codigoCliente,
           java.lang.String nomeRazaoSocial,
           boolean indicadorMicroEmpreendedorIndividual,
           java.lang.Long numeroInscricaoEstadual,
           java.lang.String nomeFantasia,
           java.lang.String nomePLaqueta,
           java.lang.String nomePessoaContato,
           long codigoRamoAtividade,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.BancoType domicilioBancarioCliente,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCategoriaCredenciamento categoriaCredenciamento,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestPrioridadeProposta prioridadeProposta,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneType[] telefoneEstabelecimento,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoType[] enderecoEstabelecimento,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoAlterarPropostaType[] servicos,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaType[] solucaoCaptura,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoAlterarPropostaType[] produtos,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.DadosProprietarioType[] proprietarios,
           int codigoSituacao,
           int codigoEtapa,
           int codigoSituacaoEtapa) {
           this.numeroProposta = numeroProposta;
           this.numeroCpfCnpj = numeroCpfCnpj;
           this.codigoTipoPessoa = codigoTipoPessoa;
           this.codigoCliente = codigoCliente;
           this.nomeRazaoSocial = nomeRazaoSocial;
           this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
           this.numeroInscricaoEstadual = numeroInscricaoEstadual;
           this.nomeFantasia = nomeFantasia;
           this.nomePLaqueta = nomePLaqueta;
           this.nomePessoaContato = nomePessoaContato;
           this.codigoRamoAtividade = codigoRamoAtividade;
           this.domicilioBancarioCliente = domicilioBancarioCliente;
           this.categoriaCredenciamento = categoriaCredenciamento;
           this.prioridadeProposta = prioridadeProposta;
           this.telefoneEstabelecimento = telefoneEstabelecimento;
           this.enderecoEstabelecimento = enderecoEstabelecimento;
           this.servicos = servicos;
           this.solucaoCaptura = solucaoCaptura;
           this.produtos = produtos;
           this.proprietarios = proprietarios;
           this.codigoSituacao = codigoSituacao;
           this.codigoEtapa = codigoEtapa;
           this.codigoSituacaoEtapa = codigoSituacaoEtapa;
    }


    /**
     * Gets the numeroProposta value for this AlterarPropostaRequest.
     * 
     * @return numeroProposta
     */
    public long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this AlterarPropostaRequest.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the numeroCpfCnpj value for this AlterarPropostaRequest.
     * 
     * @return numeroCpfCnpj
     */
    public java.lang.String getNumeroCpfCnpj() {
        return numeroCpfCnpj;
    }


    /**
     * Sets the numeroCpfCnpj value for this AlterarPropostaRequest.
     * 
     * @param numeroCpfCnpj
     */
    public void setNumeroCpfCnpj(java.lang.String numeroCpfCnpj) {
        this.numeroCpfCnpj = numeroCpfCnpj;
    }


    /**
     * Gets the codigoTipoPessoa value for this AlterarPropostaRequest.
     * 
     * @return codigoTipoPessoa
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCodigoTipoPessoa getCodigoTipoPessoa() {
        return codigoTipoPessoa;
    }


    /**
     * Sets the codigoTipoPessoa value for this AlterarPropostaRequest.
     * 
     * @param codigoTipoPessoa
     */
    public void setCodigoTipoPessoa(br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCodigoTipoPessoa codigoTipoPessoa) {
        this.codigoTipoPessoa = codigoTipoPessoa;
    }


    /**
     * Gets the codigoCliente value for this AlterarPropostaRequest.
     * 
     * @return codigoCliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this AlterarPropostaRequest.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the nomeRazaoSocial value for this AlterarPropostaRequest.
     * 
     * @return nomeRazaoSocial
     */
    public java.lang.String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }


    /**
     * Sets the nomeRazaoSocial value for this AlterarPropostaRequest.
     * 
     * @param nomeRazaoSocial
     */
    public void setNomeRazaoSocial(java.lang.String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }


    /**
     * Gets the indicadorMicroEmpreendedorIndividual value for this AlterarPropostaRequest.
     * 
     * @return indicadorMicroEmpreendedorIndividual
     */
    public boolean isIndicadorMicroEmpreendedorIndividual() {
        return indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Sets the indicadorMicroEmpreendedorIndividual value for this AlterarPropostaRequest.
     * 
     * @param indicadorMicroEmpreendedorIndividual
     */
    public void setIndicadorMicroEmpreendedorIndividual(boolean indicadorMicroEmpreendedorIndividual) {
        this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Gets the numeroInscricaoEstadual value for this AlterarPropostaRequest.
     * 
     * @return numeroInscricaoEstadual
     */
    public java.lang.Long getNumeroInscricaoEstadual() {
        return numeroInscricaoEstadual;
    }


    /**
     * Sets the numeroInscricaoEstadual value for this AlterarPropostaRequest.
     * 
     * @param numeroInscricaoEstadual
     */
    public void setNumeroInscricaoEstadual(java.lang.Long numeroInscricaoEstadual) {
        this.numeroInscricaoEstadual = numeroInscricaoEstadual;
    }


    /**
     * Gets the nomeFantasia value for this AlterarPropostaRequest.
     * 
     * @return nomeFantasia
     */
    public java.lang.String getNomeFantasia() {
        return nomeFantasia;
    }


    /**
     * Sets the nomeFantasia value for this AlterarPropostaRequest.
     * 
     * @param nomeFantasia
     */
    public void setNomeFantasia(java.lang.String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }


    /**
     * Gets the nomePLaqueta value for this AlterarPropostaRequest.
     * 
     * @return nomePLaqueta
     */
    public java.lang.String getNomePLaqueta() {
        return nomePLaqueta;
    }


    /**
     * Sets the nomePLaqueta value for this AlterarPropostaRequest.
     * 
     * @param nomePLaqueta
     */
    public void setNomePLaqueta(java.lang.String nomePLaqueta) {
        this.nomePLaqueta = nomePLaqueta;
    }


    /**
     * Gets the nomePessoaContato value for this AlterarPropostaRequest.
     * 
     * @return nomePessoaContato
     */
    public java.lang.String getNomePessoaContato() {
        return nomePessoaContato;
    }


    /**
     * Sets the nomePessoaContato value for this AlterarPropostaRequest.
     * 
     * @param nomePessoaContato
     */
    public void setNomePessoaContato(java.lang.String nomePessoaContato) {
        this.nomePessoaContato = nomePessoaContato;
    }


    /**
     * Gets the codigoRamoAtividade value for this AlterarPropostaRequest.
     * 
     * @return codigoRamoAtividade
     */
    public long getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this AlterarPropostaRequest.
     * 
     * @param codigoRamoAtividade
     */
    public void setCodigoRamoAtividade(long codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the domicilioBancarioCliente value for this AlterarPropostaRequest.
     * 
     * @return domicilioBancarioCliente
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.BancoType getDomicilioBancarioCliente() {
        return domicilioBancarioCliente;
    }


    /**
     * Sets the domicilioBancarioCliente value for this AlterarPropostaRequest.
     * 
     * @param domicilioBancarioCliente
     */
    public void setDomicilioBancarioCliente(br.com.cielo.service.operacao.comercial.credenciamento.v2.BancoType domicilioBancarioCliente) {
        this.domicilioBancarioCliente = domicilioBancarioCliente;
    }


    /**
     * Gets the categoriaCredenciamento value for this AlterarPropostaRequest.
     * 
     * @return categoriaCredenciamento
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCategoriaCredenciamento getCategoriaCredenciamento() {
        return categoriaCredenciamento;
    }


    /**
     * Sets the categoriaCredenciamento value for this AlterarPropostaRequest.
     * 
     * @param categoriaCredenciamento
     */
    public void setCategoriaCredenciamento(br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCategoriaCredenciamento categoriaCredenciamento) {
        this.categoriaCredenciamento = categoriaCredenciamento;
    }


    /**
     * Gets the prioridadeProposta value for this AlterarPropostaRequest.
     * 
     * @return prioridadeProposta
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestPrioridadeProposta getPrioridadeProposta() {
        return prioridadeProposta;
    }


    /**
     * Sets the prioridadeProposta value for this AlterarPropostaRequest.
     * 
     * @param prioridadeProposta
     */
    public void setPrioridadeProposta(br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestPrioridadeProposta prioridadeProposta) {
        this.prioridadeProposta = prioridadeProposta;
    }


    /**
     * Gets the telefoneEstabelecimento value for this AlterarPropostaRequest.
     * 
     * @return telefoneEstabelecimento
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneType[] getTelefoneEstabelecimento() {
        return telefoneEstabelecimento;
    }


    /**
     * Sets the telefoneEstabelecimento value for this AlterarPropostaRequest.
     * 
     * @param telefoneEstabelecimento
     */
    public void setTelefoneEstabelecimento(br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneType[] telefoneEstabelecimento) {
        this.telefoneEstabelecimento = telefoneEstabelecimento;
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneType getTelefoneEstabelecimento(int i) {
        return this.telefoneEstabelecimento[i];
    }

    public void setTelefoneEstabelecimento(int i, br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneType _value) {
        this.telefoneEstabelecimento[i] = _value;
    }


    /**
     * Gets the enderecoEstabelecimento value for this AlterarPropostaRequest.
     * 
     * @return enderecoEstabelecimento
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoType[] getEnderecoEstabelecimento() {
        return enderecoEstabelecimento;
    }


    /**
     * Sets the enderecoEstabelecimento value for this AlterarPropostaRequest.
     * 
     * @param enderecoEstabelecimento
     */
    public void setEnderecoEstabelecimento(br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoType[] enderecoEstabelecimento) {
        this.enderecoEstabelecimento = enderecoEstabelecimento;
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoType getEnderecoEstabelecimento(int i) {
        return this.enderecoEstabelecimento[i];
    }

    public void setEnderecoEstabelecimento(int i, br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoType _value) {
        this.enderecoEstabelecimento[i] = _value;
    }


    /**
     * Gets the servicos value for this AlterarPropostaRequest.
     * 
     * @return servicos
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoAlterarPropostaType[] getServicos() {
        return servicos;
    }


    /**
     * Sets the servicos value for this AlterarPropostaRequest.
     * 
     * @param servicos
     */
    public void setServicos(br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoAlterarPropostaType[] servicos) {
        this.servicos = servicos;
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoAlterarPropostaType getServicos(int i) {
        return this.servicos[i];
    }

    public void setServicos(int i, br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoAlterarPropostaType _value) {
        this.servicos[i] = _value;
    }


    /**
     * Gets the solucaoCaptura value for this AlterarPropostaRequest.
     * 
     * @return solucaoCaptura
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaType[] getSolucaoCaptura() {
        return solucaoCaptura;
    }


    /**
     * Sets the solucaoCaptura value for this AlterarPropostaRequest.
     * 
     * @param solucaoCaptura
     */
    public void setSolucaoCaptura(br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaType[] solucaoCaptura) {
        this.solucaoCaptura = solucaoCaptura;
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaType getSolucaoCaptura(int i) {
        return this.solucaoCaptura[i];
    }

    public void setSolucaoCaptura(int i, br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaType _value) {
        this.solucaoCaptura[i] = _value;
    }


    /**
     * Gets the produtos value for this AlterarPropostaRequest.
     * 
     * @return produtos
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoAlterarPropostaType[] getProdutos() {
        return produtos;
    }


    /**
     * Sets the produtos value for this AlterarPropostaRequest.
     * 
     * @param produtos
     */
    public void setProdutos(br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoAlterarPropostaType[] produtos) {
        this.produtos = produtos;
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoAlterarPropostaType getProdutos(int i) {
        return this.produtos[i];
    }

    public void setProdutos(int i, br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoAlterarPropostaType _value) {
        this.produtos[i] = _value;
    }


    /**
     * Gets the proprietarios value for this AlterarPropostaRequest.
     * 
     * @return proprietarios
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.DadosProprietarioType[] getProprietarios() {
        return proprietarios;
    }


    /**
     * Sets the proprietarios value for this AlterarPropostaRequest.
     * 
     * @param proprietarios
     */
    public void setProprietarios(br.com.cielo.service.operacao.comercial.credenciamento.v2.DadosProprietarioType[] proprietarios) {
        this.proprietarios = proprietarios;
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.DadosProprietarioType getProprietarios(int i) {
        return this.proprietarios[i];
    }

    public void setProprietarios(int i, br.com.cielo.service.operacao.comercial.credenciamento.v2.DadosProprietarioType _value) {
        this.proprietarios[i] = _value;
    }


    /**
     * Gets the codigoSituacao value for this AlterarPropostaRequest.
     * 
     * @return codigoSituacao
     */
    public int getCodigoSituacao() {
        return codigoSituacao;
    }


    /**
     * Sets the codigoSituacao value for this AlterarPropostaRequest.
     * 
     * @param codigoSituacao
     */
    public void setCodigoSituacao(int codigoSituacao) {
        this.codigoSituacao = codigoSituacao;
    }


    /**
     * Gets the codigoEtapa value for this AlterarPropostaRequest.
     * 
     * @return codigoEtapa
     */
    public int getCodigoEtapa() {
        return codigoEtapa;
    }


    /**
     * Sets the codigoEtapa value for this AlterarPropostaRequest.
     * 
     * @param codigoEtapa
     */
    public void setCodigoEtapa(int codigoEtapa) {
        this.codigoEtapa = codigoEtapa;
    }


    /**
     * Gets the codigoSituacaoEtapa value for this AlterarPropostaRequest.
     * 
     * @return codigoSituacaoEtapa
     */
    public int getCodigoSituacaoEtapa() {
        return codigoSituacaoEtapa;
    }


    /**
     * Sets the codigoSituacaoEtapa value for this AlterarPropostaRequest.
     * 
     * @param codigoSituacaoEtapa
     */
    public void setCodigoSituacaoEtapa(int codigoSituacaoEtapa) {
        this.codigoSituacaoEtapa = codigoSituacaoEtapa;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarPropostaRequest)) return false;
        AlterarPropostaRequest other = (AlterarPropostaRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.numeroProposta == other.getNumeroProposta() &&
            ((this.numeroCpfCnpj==null && other.getNumeroCpfCnpj()==null) || 
             (this.numeroCpfCnpj!=null &&
              this.numeroCpfCnpj.equals(other.getNumeroCpfCnpj()))) &&
            ((this.codigoTipoPessoa==null && other.getCodigoTipoPessoa()==null) || 
             (this.codigoTipoPessoa!=null &&
              this.codigoTipoPessoa.equals(other.getCodigoTipoPessoa()))) &&
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.nomeRazaoSocial==null && other.getNomeRazaoSocial()==null) || 
             (this.nomeRazaoSocial!=null &&
              this.nomeRazaoSocial.equals(other.getNomeRazaoSocial()))) &&
            this.indicadorMicroEmpreendedorIndividual == other.isIndicadorMicroEmpreendedorIndividual() &&
            ((this.numeroInscricaoEstadual==null && other.getNumeroInscricaoEstadual()==null) || 
             (this.numeroInscricaoEstadual!=null &&
              this.numeroInscricaoEstadual.equals(other.getNumeroInscricaoEstadual()))) &&
            ((this.nomeFantasia==null && other.getNomeFantasia()==null) || 
             (this.nomeFantasia!=null &&
              this.nomeFantasia.equals(other.getNomeFantasia()))) &&
            ((this.nomePLaqueta==null && other.getNomePLaqueta()==null) || 
             (this.nomePLaqueta!=null &&
              this.nomePLaqueta.equals(other.getNomePLaqueta()))) &&
            ((this.nomePessoaContato==null && other.getNomePessoaContato()==null) || 
             (this.nomePessoaContato!=null &&
              this.nomePessoaContato.equals(other.getNomePessoaContato()))) &&
            this.codigoRamoAtividade == other.getCodigoRamoAtividade() &&
            ((this.domicilioBancarioCliente==null && other.getDomicilioBancarioCliente()==null) || 
             (this.domicilioBancarioCliente!=null &&
              this.domicilioBancarioCliente.equals(other.getDomicilioBancarioCliente()))) &&
            ((this.categoriaCredenciamento==null && other.getCategoriaCredenciamento()==null) || 
             (this.categoriaCredenciamento!=null &&
              this.categoriaCredenciamento.equals(other.getCategoriaCredenciamento()))) &&
            ((this.prioridadeProposta==null && other.getPrioridadeProposta()==null) || 
             (this.prioridadeProposta!=null &&
              this.prioridadeProposta.equals(other.getPrioridadeProposta()))) &&
            ((this.telefoneEstabelecimento==null && other.getTelefoneEstabelecimento()==null) || 
             (this.telefoneEstabelecimento!=null &&
              java.util.Arrays.equals(this.telefoneEstabelecimento, other.getTelefoneEstabelecimento()))) &&
            ((this.enderecoEstabelecimento==null && other.getEnderecoEstabelecimento()==null) || 
             (this.enderecoEstabelecimento!=null &&
              java.util.Arrays.equals(this.enderecoEstabelecimento, other.getEnderecoEstabelecimento()))) &&
            ((this.servicos==null && other.getServicos()==null) || 
             (this.servicos!=null &&
              java.util.Arrays.equals(this.servicos, other.getServicos()))) &&
            ((this.solucaoCaptura==null && other.getSolucaoCaptura()==null) || 
             (this.solucaoCaptura!=null &&
              java.util.Arrays.equals(this.solucaoCaptura, other.getSolucaoCaptura()))) &&
            ((this.produtos==null && other.getProdutos()==null) || 
             (this.produtos!=null &&
              java.util.Arrays.equals(this.produtos, other.getProdutos()))) &&
            ((this.proprietarios==null && other.getProprietarios()==null) || 
             (this.proprietarios!=null &&
              java.util.Arrays.equals(this.proprietarios, other.getProprietarios()))) &&
            this.codigoSituacao == other.getCodigoSituacao() &&
            this.codigoEtapa == other.getCodigoEtapa() &&
            this.codigoSituacaoEtapa == other.getCodigoSituacaoEtapa();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getNumeroProposta()).hashCode();
        if (getNumeroCpfCnpj() != null) {
            _hashCode += getNumeroCpfCnpj().hashCode();
        }
        if (getCodigoTipoPessoa() != null) {
            _hashCode += getCodigoTipoPessoa().hashCode();
        }
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getNomeRazaoSocial() != null) {
            _hashCode += getNomeRazaoSocial().hashCode();
        }
        _hashCode += (isIndicadorMicroEmpreendedorIndividual() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getNumeroInscricaoEstadual() != null) {
            _hashCode += getNumeroInscricaoEstadual().hashCode();
        }
        if (getNomeFantasia() != null) {
            _hashCode += getNomeFantasia().hashCode();
        }
        if (getNomePLaqueta() != null) {
            _hashCode += getNomePLaqueta().hashCode();
        }
        if (getNomePessoaContato() != null) {
            _hashCode += getNomePessoaContato().hashCode();
        }
        _hashCode += new Long(getCodigoRamoAtividade()).hashCode();
        if (getDomicilioBancarioCliente() != null) {
            _hashCode += getDomicilioBancarioCliente().hashCode();
        }
        if (getCategoriaCredenciamento() != null) {
            _hashCode += getCategoriaCredenciamento().hashCode();
        }
        if (getPrioridadeProposta() != null) {
            _hashCode += getPrioridadeProposta().hashCode();
        }
        if (getTelefoneEstabelecimento() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTelefoneEstabelecimento());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTelefoneEstabelecimento(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEnderecoEstabelecimento() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEnderecoEstabelecimento());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEnderecoEstabelecimento(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getServicos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getServicos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getServicos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getSolucaoCaptura() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSolucaoCaptura());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSolucaoCaptura(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProdutos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProdutos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProdutos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProprietarios() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProprietarios());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProprietarios(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        _hashCode += getCodigoSituacao();
        _hashCode += getCodigoEtapa();
        _hashCode += getCodigoSituacaoEtapa();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarPropostaRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">alterarPropostaRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCpfCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "numeroCpfCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoTipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>alterarPropostaRequest>codigoTipoPessoa"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeRazaoSocial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "nomeRazaoSocial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMicroEmpreendedorIndividual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "indicadorMicroEmpreendedorIndividual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroInscricaoEstadual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "numeroInscricaoEstadual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFantasia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "nomeFantasia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePLaqueta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "nomePLaqueta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePessoaContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "nomePessoaContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domicilioBancarioCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "domicilioBancarioCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "bancoType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("categoriaCredenciamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "categoriaCredenciamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>alterarPropostaRequest>categoriaCredenciamento"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prioridadeProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "prioridadeProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>alterarPropostaRequest>prioridadeProposta"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telefoneEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "telefoneEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "telefoneType"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enderecoEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "enderecoEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "enderecoType"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("servicos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "servicos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "servicoAlterarPropostaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "solucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "solucaoCapturaAlterarPropostaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produtos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "produtos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "produtoAlterarPropostaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("proprietarios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "proprietarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "dadosProprietarioType"));
        elemField.setNillable(false);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSituacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoSituacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoEtapa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoEtapa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSituacaoEtapa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoSituacaoEtapa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
