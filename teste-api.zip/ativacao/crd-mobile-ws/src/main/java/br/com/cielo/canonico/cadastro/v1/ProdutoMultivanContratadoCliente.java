/**
 * ProdutoMultivanContratadoCliente.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Produtos contratados pelo cliente que podem ser trasacionados por
 * outras vans.
 */
public class ProdutoMultivanContratadoCliente  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o Cliente */
    private java.lang.Long codigoCliente;

    /* Codigo do produto oferecido pela Cielo aos seus clientes */
    private java.math.BigInteger codigoProduto;

    /* Dados da empresa receptora. */
    private br.com.cielo.canonico.cadastro.v1.Empresa_Receptora dadosEmpresaReceptora;

    /* Codigo do cadastro do cliente na empresa adquirente receptora
     * (empresa terceira). */
    private java.lang.String codigoClienteEmpresaReceptora;

    /* Data de início da vigência que o cliente/produto está autorizado
     * a transacionar na empresa adquirente receptora (empresa terceira). */
    private java.util.Date dataInicioVigencia;

    /* Data de fim da vigência que o cliente/produto está autorizado
     * a transacionar na empresa adquirente receptora (empresa terceira). */
    private java.util.Date dataFimVigencia;

    public ProdutoMultivanContratadoCliente() {
    }

    public ProdutoMultivanContratadoCliente(
           java.lang.Long codigoCliente,
           java.math.BigInteger codigoProduto,
           br.com.cielo.canonico.cadastro.v1.Empresa_Receptora dadosEmpresaReceptora,
           java.lang.String codigoClienteEmpresaReceptora,
           java.util.Date dataInicioVigencia,
           java.util.Date dataFimVigencia) {
           this.codigoCliente = codigoCliente;
           this.codigoProduto = codigoProduto;
           this.dadosEmpresaReceptora = dadosEmpresaReceptora;
           this.codigoClienteEmpresaReceptora = codigoClienteEmpresaReceptora;
           this.dataInicioVigencia = dataInicioVigencia;
           this.dataFimVigencia = dataFimVigencia;
    }


    /**
     * Gets the codigoCliente value for this ProdutoMultivanContratadoCliente.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this ProdutoMultivanContratadoCliente.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the codigoProduto value for this ProdutoMultivanContratadoCliente.
     * 
     * @return codigoProduto   * Codigo do produto oferecido pela Cielo aos seus clientes
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this ProdutoMultivanContratadoCliente.
     * 
     * @param codigoProduto   * Codigo do produto oferecido pela Cielo aos seus clientes
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the dadosEmpresaReceptora value for this ProdutoMultivanContratadoCliente.
     * 
     * @return dadosEmpresaReceptora   * Dados da empresa receptora.
     */
    public br.com.cielo.canonico.cadastro.v1.Empresa_Receptora getDadosEmpresaReceptora() {
        return dadosEmpresaReceptora;
    }


    /**
     * Sets the dadosEmpresaReceptora value for this ProdutoMultivanContratadoCliente.
     * 
     * @param dadosEmpresaReceptora   * Dados da empresa receptora.
     */
    public void setDadosEmpresaReceptora(br.com.cielo.canonico.cadastro.v1.Empresa_Receptora dadosEmpresaReceptora) {
        this.dadosEmpresaReceptora = dadosEmpresaReceptora;
    }


    /**
     * Gets the codigoClienteEmpresaReceptora value for this ProdutoMultivanContratadoCliente.
     * 
     * @return codigoClienteEmpresaReceptora   * Codigo do cadastro do cliente na empresa adquirente receptora
     * (empresa terceira).
     */
    public java.lang.String getCodigoClienteEmpresaReceptora() {
        return codigoClienteEmpresaReceptora;
    }


    /**
     * Sets the codigoClienteEmpresaReceptora value for this ProdutoMultivanContratadoCliente.
     * 
     * @param codigoClienteEmpresaReceptora   * Codigo do cadastro do cliente na empresa adquirente receptora
     * (empresa terceira).
     */
    public void setCodigoClienteEmpresaReceptora(java.lang.String codigoClienteEmpresaReceptora) {
        this.codigoClienteEmpresaReceptora = codigoClienteEmpresaReceptora;
    }


    /**
     * Gets the dataInicioVigencia value for this ProdutoMultivanContratadoCliente.
     * 
     * @return dataInicioVigencia   * Data de início da vigência que o cliente/produto está autorizado
     * a transacionar na empresa adquirente receptora (empresa terceira).
     */
    public java.util.Date getDataInicioVigencia() {
        return dataInicioVigencia;
    }


    /**
     * Sets the dataInicioVigencia value for this ProdutoMultivanContratadoCliente.
     * 
     * @param dataInicioVigencia   * Data de início da vigência que o cliente/produto está autorizado
     * a transacionar na empresa adquirente receptora (empresa terceira).
     */
    public void setDataInicioVigencia(java.util.Date dataInicioVigencia) {
        this.dataInicioVigencia = dataInicioVigencia;
    }


    /**
     * Gets the dataFimVigencia value for this ProdutoMultivanContratadoCliente.
     * 
     * @return dataFimVigencia   * Data de fim da vigência que o cliente/produto está autorizado
     * a transacionar na empresa adquirente receptora (empresa terceira).
     */
    public java.util.Date getDataFimVigencia() {
        return dataFimVigencia;
    }


    /**
     * Sets the dataFimVigencia value for this ProdutoMultivanContratadoCliente.
     * 
     * @param dataFimVigencia   * Data de fim da vigência que o cliente/produto está autorizado
     * a transacionar na empresa adquirente receptora (empresa terceira).
     */
    public void setDataFimVigencia(java.util.Date dataFimVigencia) {
        this.dataFimVigencia = dataFimVigencia;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProdutoMultivanContratadoCliente)) return false;
        ProdutoMultivanContratadoCliente other = (ProdutoMultivanContratadoCliente) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto()))) &&
            ((this.dadosEmpresaReceptora==null && other.getDadosEmpresaReceptora()==null) || 
             (this.dadosEmpresaReceptora!=null &&
              this.dadosEmpresaReceptora.equals(other.getDadosEmpresaReceptora()))) &&
            ((this.codigoClienteEmpresaReceptora==null && other.getCodigoClienteEmpresaReceptora()==null) || 
             (this.codigoClienteEmpresaReceptora!=null &&
              this.codigoClienteEmpresaReceptora.equals(other.getCodigoClienteEmpresaReceptora()))) &&
            ((this.dataInicioVigencia==null && other.getDataInicioVigencia()==null) || 
             (this.dataInicioVigencia!=null &&
              this.dataInicioVigencia.equals(other.getDataInicioVigencia()))) &&
            ((this.dataFimVigencia==null && other.getDataFimVigencia()==null) || 
             (this.dataFimVigencia!=null &&
              this.dataFimVigencia.equals(other.getDataFimVigencia())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        if (getDadosEmpresaReceptora() != null) {
            _hashCode += getDadosEmpresaReceptora().hashCode();
        }
        if (getCodigoClienteEmpresaReceptora() != null) {
            _hashCode += getCodigoClienteEmpresaReceptora().hashCode();
        }
        if (getDataInicioVigencia() != null) {
            _hashCode += getDataInicioVigencia().hashCode();
        }
        if (getDataFimVigencia() != null) {
            _hashCode += getDataFimVigencia().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProdutoMultivanContratadoCliente.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "ProdutoMultivanContratadoCliente"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "CodigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "CodigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEmpresaReceptora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DadosEmpresaReceptora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Empresa_Receptora"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoClienteEmpresaReceptora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "CodigoClienteEmpresaReceptora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataInicioVigencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DataInicioVigencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataFimVigencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DataFimVigencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
