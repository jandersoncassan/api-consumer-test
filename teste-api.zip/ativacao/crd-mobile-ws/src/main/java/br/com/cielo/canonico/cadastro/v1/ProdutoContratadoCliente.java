/**
 * ProdutoContratadoCliente.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class ProdutoContratadoCliente  implements java.io.Serializable {
    private java.lang.Long codigoCliente;

    private br.com.cielo.canonico.cadastro.v1.Produto dadosProduto;

    private java.lang.String nomeIndicadorLiquidacao;

    private java.lang.String indicadorContingenciaBatch;

    private java.lang.String indicadorAceitaTransacaoDigitada;

    public ProdutoContratadoCliente() {
    }

    public ProdutoContratadoCliente(
           java.lang.Long codigoCliente,
           br.com.cielo.canonico.cadastro.v1.Produto dadosProduto,
           java.lang.String nomeIndicadorLiquidacao,
           java.lang.String indicadorContingenciaBatch,
           java.lang.String indicadorAceitaTransacaoDigitada) {
           this.codigoCliente = codigoCliente;
           this.dadosProduto = dadosProduto;
           this.nomeIndicadorLiquidacao = nomeIndicadorLiquidacao;
           this.indicadorContingenciaBatch = indicadorContingenciaBatch;
           this.indicadorAceitaTransacaoDigitada = indicadorAceitaTransacaoDigitada;
    }


    /**
     * Gets the codigoCliente value for this ProdutoContratadoCliente.
     * 
     * @return codigoCliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this ProdutoContratadoCliente.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the dadosProduto value for this ProdutoContratadoCliente.
     * 
     * @return dadosProduto
     */
    public br.com.cielo.canonico.cadastro.v1.Produto getDadosProduto() {
        return dadosProduto;
    }


    /**
     * Sets the dadosProduto value for this ProdutoContratadoCliente.
     * 
     * @param dadosProduto
     */
    public void setDadosProduto(br.com.cielo.canonico.cadastro.v1.Produto dadosProduto) {
        this.dadosProduto = dadosProduto;
    }


    /**
     * Gets the nomeIndicadorLiquidacao value for this ProdutoContratadoCliente.
     * 
     * @return nomeIndicadorLiquidacao
     */
    public java.lang.String getNomeIndicadorLiquidacao() {
        return nomeIndicadorLiquidacao;
    }


    /**
     * Sets the nomeIndicadorLiquidacao value for this ProdutoContratadoCliente.
     * 
     * @param nomeIndicadorLiquidacao
     */
    public void setNomeIndicadorLiquidacao(java.lang.String nomeIndicadorLiquidacao) {
        this.nomeIndicadorLiquidacao = nomeIndicadorLiquidacao;
    }


    /**
     * Gets the indicadorContingenciaBatch value for this ProdutoContratadoCliente.
     * 
     * @return indicadorContingenciaBatch
     */
    public java.lang.String getIndicadorContingenciaBatch() {
        return indicadorContingenciaBatch;
    }


    /**
     * Sets the indicadorContingenciaBatch value for this ProdutoContratadoCliente.
     * 
     * @param indicadorContingenciaBatch
     */
    public void setIndicadorContingenciaBatch(java.lang.String indicadorContingenciaBatch) {
        this.indicadorContingenciaBatch = indicadorContingenciaBatch;
    }


    /**
     * Gets the indicadorAceitaTransacaoDigitada value for this ProdutoContratadoCliente.
     * 
     * @return indicadorAceitaTransacaoDigitada
     */
    public java.lang.String getIndicadorAceitaTransacaoDigitada() {
        return indicadorAceitaTransacaoDigitada;
    }


    /**
     * Sets the indicadorAceitaTransacaoDigitada value for this ProdutoContratadoCliente.
     * 
     * @param indicadorAceitaTransacaoDigitada
     */
    public void setIndicadorAceitaTransacaoDigitada(java.lang.String indicadorAceitaTransacaoDigitada) {
        this.indicadorAceitaTransacaoDigitada = indicadorAceitaTransacaoDigitada;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProdutoContratadoCliente)) return false;
        ProdutoContratadoCliente other = (ProdutoContratadoCliente) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.dadosProduto==null && other.getDadosProduto()==null) || 
             (this.dadosProduto!=null &&
              this.dadosProduto.equals(other.getDadosProduto()))) &&
            ((this.nomeIndicadorLiquidacao==null && other.getNomeIndicadorLiquidacao()==null) || 
             (this.nomeIndicadorLiquidacao!=null &&
              this.nomeIndicadorLiquidacao.equals(other.getNomeIndicadorLiquidacao()))) &&
            ((this.indicadorContingenciaBatch==null && other.getIndicadorContingenciaBatch()==null) || 
             (this.indicadorContingenciaBatch!=null &&
              this.indicadorContingenciaBatch.equals(other.getIndicadorContingenciaBatch()))) &&
            ((this.indicadorAceitaTransacaoDigitada==null && other.getIndicadorAceitaTransacaoDigitada()==null) || 
             (this.indicadorAceitaTransacaoDigitada!=null &&
              this.indicadorAceitaTransacaoDigitada.equals(other.getIndicadorAceitaTransacaoDigitada())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getDadosProduto() != null) {
            _hashCode += getDadosProduto().hashCode();
        }
        if (getNomeIndicadorLiquidacao() != null) {
            _hashCode += getNomeIndicadorLiquidacao().hashCode();
        }
        if (getIndicadorContingenciaBatch() != null) {
            _hashCode += getIndicadorContingenciaBatch().hashCode();
        }
        if (getIndicadorAceitaTransacaoDigitada() != null) {
            _hashCode += getIndicadorAceitaTransacaoDigitada().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProdutoContratadoCliente.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "ProdutoContratadoCliente"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeIndicadorLiquidacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeIndicadorLiquidacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorContingenciaBatch");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorContingenciaBatch"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAceitaTransacaoDigitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorAceitaTransacaoDigitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
