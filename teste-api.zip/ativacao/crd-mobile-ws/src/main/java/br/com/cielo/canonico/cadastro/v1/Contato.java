/**
 * Contato.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Entidade canonica do corporativo que representa a pessoa escolhida
 * como contato entre o Cliente e a Cielo. Ele e escolhido para ser o
 * representante do Cliente que a Cielo utilizara durante o relacionamento
 * entre as partes.
 */
public class Contato  implements java.io.Serializable {
    /* Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre as partes. */
    private java.lang.String nomeContato;

    /* Numero do DDI do telefone do contato do cliente com a Cielo */
    private java.lang.String numeroDDITelefoneContato;

    /* Numero do DDD do telefone do contato do cliente com a Cielo */
    private java.lang.String numeroDDDTelefoneContato;

    /* Numero do telefone do contato do cliente com a Cielo */
    private java.lang.String numeroTelefoneContato;

    /* Numero do DDI do fax do contato do cliente com a Cielo */
    private java.lang.String numeroDDIFax;

    /* Numero do Fax do contato do cliente com a Cielo */
    private java.lang.String numeroFax;

    /* Numero do DDD do fax do contato do cliente com a Cielo */
    private java.lang.String numeroDDDFax;

    /* Nome do endereco de email do contato do cliente com a Cielo */
    private java.lang.String nomeEmailContato;

    /* Tipo de Contato */
    private java.lang.String tipoContato;

    /* Tipo Telefone ( Fixo, Mobile, etc) */
    private java.lang.String tipoTelefone;

    public Contato() {
    }

    public Contato(
           java.lang.String nomeContato,
           java.lang.String numeroDDITelefoneContato,
           java.lang.String numeroDDDTelefoneContato,
           java.lang.String numeroTelefoneContato,
           java.lang.String numeroDDIFax,
           java.lang.String numeroFax,
           java.lang.String numeroDDDFax,
           java.lang.String nomeEmailContato,
           java.lang.String tipoContato,
           java.lang.String tipoTelefone) {
           this.nomeContato = nomeContato;
           this.numeroDDITelefoneContato = numeroDDITelefoneContato;
           this.numeroDDDTelefoneContato = numeroDDDTelefoneContato;
           this.numeroTelefoneContato = numeroTelefoneContato;
           this.numeroDDIFax = numeroDDIFax;
           this.numeroFax = numeroFax;
           this.numeroDDDFax = numeroDDDFax;
           this.nomeEmailContato = nomeEmailContato;
           this.tipoContato = tipoContato;
           this.tipoTelefone = tipoTelefone;
    }


    /**
     * Gets the nomeContato value for this Contato.
     * 
     * @return nomeContato   * Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre as partes.
     */
    public java.lang.String getNomeContato() {
        return nomeContato;
    }


    /**
     * Sets the nomeContato value for this Contato.
     * 
     * @param nomeContato   * Nome escolhido pelo Cliente da Cielo para ser o ponto de contato
     * entre as partes.
     */
    public void setNomeContato(java.lang.String nomeContato) {
        this.nomeContato = nomeContato;
    }


    /**
     * Gets the numeroDDITelefoneContato value for this Contato.
     * 
     * @return numeroDDITelefoneContato   * Numero do DDI do telefone do contato do cliente com a Cielo
     */
    public java.lang.String getNumeroDDITelefoneContato() {
        return numeroDDITelefoneContato;
    }


    /**
     * Sets the numeroDDITelefoneContato value for this Contato.
     * 
     * @param numeroDDITelefoneContato   * Numero do DDI do telefone do contato do cliente com a Cielo
     */
    public void setNumeroDDITelefoneContato(java.lang.String numeroDDITelefoneContato) {
        this.numeroDDITelefoneContato = numeroDDITelefoneContato;
    }


    /**
     * Gets the numeroDDDTelefoneContato value for this Contato.
     * 
     * @return numeroDDDTelefoneContato   * Numero do DDD do telefone do contato do cliente com a Cielo
     */
    public java.lang.String getNumeroDDDTelefoneContato() {
        return numeroDDDTelefoneContato;
    }


    /**
     * Sets the numeroDDDTelefoneContato value for this Contato.
     * 
     * @param numeroDDDTelefoneContato   * Numero do DDD do telefone do contato do cliente com a Cielo
     */
    public void setNumeroDDDTelefoneContato(java.lang.String numeroDDDTelefoneContato) {
        this.numeroDDDTelefoneContato = numeroDDDTelefoneContato;
    }


    /**
     * Gets the numeroTelefoneContato value for this Contato.
     * 
     * @return numeroTelefoneContato   * Numero do telefone do contato do cliente com a Cielo
     */
    public java.lang.String getNumeroTelefoneContato() {
        return numeroTelefoneContato;
    }


    /**
     * Sets the numeroTelefoneContato value for this Contato.
     * 
     * @param numeroTelefoneContato   * Numero do telefone do contato do cliente com a Cielo
     */
    public void setNumeroTelefoneContato(java.lang.String numeroTelefoneContato) {
        this.numeroTelefoneContato = numeroTelefoneContato;
    }


    /**
     * Gets the numeroDDIFax value for this Contato.
     * 
     * @return numeroDDIFax   * Numero do DDI do fax do contato do cliente com a Cielo
     */
    public java.lang.String getNumeroDDIFax() {
        return numeroDDIFax;
    }


    /**
     * Sets the numeroDDIFax value for this Contato.
     * 
     * @param numeroDDIFax   * Numero do DDI do fax do contato do cliente com a Cielo
     */
    public void setNumeroDDIFax(java.lang.String numeroDDIFax) {
        this.numeroDDIFax = numeroDDIFax;
    }


    /**
     * Gets the numeroFax value for this Contato.
     * 
     * @return numeroFax   * Numero do Fax do contato do cliente com a Cielo
     */
    public java.lang.String getNumeroFax() {
        return numeroFax;
    }


    /**
     * Sets the numeroFax value for this Contato.
     * 
     * @param numeroFax   * Numero do Fax do contato do cliente com a Cielo
     */
    public void setNumeroFax(java.lang.String numeroFax) {
        this.numeroFax = numeroFax;
    }


    /**
     * Gets the numeroDDDFax value for this Contato.
     * 
     * @return numeroDDDFax   * Numero do DDD do fax do contato do cliente com a Cielo
     */
    public java.lang.String getNumeroDDDFax() {
        return numeroDDDFax;
    }


    /**
     * Sets the numeroDDDFax value for this Contato.
     * 
     * @param numeroDDDFax   * Numero do DDD do fax do contato do cliente com a Cielo
     */
    public void setNumeroDDDFax(java.lang.String numeroDDDFax) {
        this.numeroDDDFax = numeroDDDFax;
    }


    /**
     * Gets the nomeEmailContato value for this Contato.
     * 
     * @return nomeEmailContato   * Nome do endereco de email do contato do cliente com a Cielo
     */
    public java.lang.String getNomeEmailContato() {
        return nomeEmailContato;
    }


    /**
     * Sets the nomeEmailContato value for this Contato.
     * 
     * @param nomeEmailContato   * Nome do endereco de email do contato do cliente com a Cielo
     */
    public void setNomeEmailContato(java.lang.String nomeEmailContato) {
        this.nomeEmailContato = nomeEmailContato;
    }


    /**
     * Gets the tipoContato value for this Contato.
     * 
     * @return tipoContato   * Tipo de Contato
     */
    public java.lang.String getTipoContato() {
        return tipoContato;
    }


    /**
     * Sets the tipoContato value for this Contato.
     * 
     * @param tipoContato   * Tipo de Contato
     */
    public void setTipoContato(java.lang.String tipoContato) {
        this.tipoContato = tipoContato;
    }


    /**
     * Gets the tipoTelefone value for this Contato.
     * 
     * @return tipoTelefone   * Tipo Telefone ( Fixo, Mobile, etc)
     */
    public java.lang.String getTipoTelefone() {
        return tipoTelefone;
    }


    /**
     * Sets the tipoTelefone value for this Contato.
     * 
     * @param tipoTelefone   * Tipo Telefone ( Fixo, Mobile, etc)
     */
    public void setTipoTelefone(java.lang.String tipoTelefone) {
        this.tipoTelefone = tipoTelefone;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Contato)) return false;
        Contato other = (Contato) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nomeContato==null && other.getNomeContato()==null) || 
             (this.nomeContato!=null &&
              this.nomeContato.equals(other.getNomeContato()))) &&
            ((this.numeroDDITelefoneContato==null && other.getNumeroDDITelefoneContato()==null) || 
             (this.numeroDDITelefoneContato!=null &&
              this.numeroDDITelefoneContato.equals(other.getNumeroDDITelefoneContato()))) &&
            ((this.numeroDDDTelefoneContato==null && other.getNumeroDDDTelefoneContato()==null) || 
             (this.numeroDDDTelefoneContato!=null &&
              this.numeroDDDTelefoneContato.equals(other.getNumeroDDDTelefoneContato()))) &&
            ((this.numeroTelefoneContato==null && other.getNumeroTelefoneContato()==null) || 
             (this.numeroTelefoneContato!=null &&
              this.numeroTelefoneContato.equals(other.getNumeroTelefoneContato()))) &&
            ((this.numeroDDIFax==null && other.getNumeroDDIFax()==null) || 
             (this.numeroDDIFax!=null &&
              this.numeroDDIFax.equals(other.getNumeroDDIFax()))) &&
            ((this.numeroFax==null && other.getNumeroFax()==null) || 
             (this.numeroFax!=null &&
              this.numeroFax.equals(other.getNumeroFax()))) &&
            ((this.numeroDDDFax==null && other.getNumeroDDDFax()==null) || 
             (this.numeroDDDFax!=null &&
              this.numeroDDDFax.equals(other.getNumeroDDDFax()))) &&
            ((this.nomeEmailContato==null && other.getNomeEmailContato()==null) || 
             (this.nomeEmailContato!=null &&
              this.nomeEmailContato.equals(other.getNomeEmailContato()))) &&
            ((this.tipoContato==null && other.getTipoContato()==null) || 
             (this.tipoContato!=null &&
              this.tipoContato.equals(other.getTipoContato()))) &&
            ((this.tipoTelefone==null && other.getTipoTelefone()==null) || 
             (this.tipoTelefone!=null &&
              this.tipoTelefone.equals(other.getTipoTelefone())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNomeContato() != null) {
            _hashCode += getNomeContato().hashCode();
        }
        if (getNumeroDDITelefoneContato() != null) {
            _hashCode += getNumeroDDITelefoneContato().hashCode();
        }
        if (getNumeroDDDTelefoneContato() != null) {
            _hashCode += getNumeroDDDTelefoneContato().hashCode();
        }
        if (getNumeroTelefoneContato() != null) {
            _hashCode += getNumeroTelefoneContato().hashCode();
        }
        if (getNumeroDDIFax() != null) {
            _hashCode += getNumeroDDIFax().hashCode();
        }
        if (getNumeroFax() != null) {
            _hashCode += getNumeroFax().hashCode();
        }
        if (getNumeroDDDFax() != null) {
            _hashCode += getNumeroDDDFax().hashCode();
        }
        if (getNomeEmailContato() != null) {
            _hashCode += getNomeEmailContato().hashCode();
        }
        if (getTipoContato() != null) {
            _hashCode += getTipoContato().hashCode();
        }
        if (getTipoTelefone() != null) {
            _hashCode += getTipoTelefone().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Contato.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDDITelefoneContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroDDITelefoneContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDDDTelefoneContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroDDDTelefoneContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefoneContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroTelefoneContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDDIFax");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroDDIFax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroFax");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroFax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDDDFax");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroDDDFax"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEmailContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeEmailContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "tipoContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "tipoTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
