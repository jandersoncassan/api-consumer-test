/**
 * BancoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;


/**
 * Tipo complexo que representa os dados do banco.
 */
public class BancoType  implements java.io.Serializable {
    private java.lang.String codigoBanco;

    private java.lang.String numeroAgencia;

    private java.lang.String numeroConta;

    /* Codigo do tipo de conta domicilio
     * 								' ' = C/C banco liquidante cielo (PAGFOR) 
     * 								0 = C/C banco liquidante cielo (PAGFOR) 
     * 								1 = C/C banco nao liquidante cielo (TED) 
     * 								2 = poupanca (TED)
     * 								3 = cartao pre-pago (NAO CONSTRUIDO) */
    private java.lang.String tipoConta;

    public BancoType() {
    }

    public BancoType(
           java.lang.String codigoBanco,
           java.lang.String numeroAgencia,
           java.lang.String numeroConta,
           java.lang.String tipoConta) {
           this.codigoBanco = codigoBanco;
           this.numeroAgencia = numeroAgencia;
           this.numeroConta = numeroConta;
           this.tipoConta = tipoConta;
    }


    /**
     * Gets the codigoBanco value for this BancoType.
     * 
     * @return codigoBanco
     */
    public java.lang.String getCodigoBanco() {
        return codigoBanco;
    }


    /**
     * Sets the codigoBanco value for this BancoType.
     * 
     * @param codigoBanco
     */
    public void setCodigoBanco(java.lang.String codigoBanco) {
        this.codigoBanco = codigoBanco;
    }


    /**
     * Gets the numeroAgencia value for this BancoType.
     * 
     * @return numeroAgencia
     */
    public java.lang.String getNumeroAgencia() {
        return numeroAgencia;
    }


    /**
     * Sets the numeroAgencia value for this BancoType.
     * 
     * @param numeroAgencia
     */
    public void setNumeroAgencia(java.lang.String numeroAgencia) {
        this.numeroAgencia = numeroAgencia;
    }


    /**
     * Gets the numeroConta value for this BancoType.
     * 
     * @return numeroConta
     */
    public java.lang.String getNumeroConta() {
        return numeroConta;
    }


    /**
     * Sets the numeroConta value for this BancoType.
     * 
     * @param numeroConta
     */
    public void setNumeroConta(java.lang.String numeroConta) {
        this.numeroConta = numeroConta;
    }


    /**
     * Gets the tipoConta value for this BancoType.
     * 
     * @return tipoConta   * Codigo do tipo de conta domicilio
     * 								' ' = C/C banco liquidante cielo (PAGFOR) 
     * 								0 = C/C banco liquidante cielo (PAGFOR) 
     * 								1 = C/C banco nao liquidante cielo (TED) 
     * 								2 = poupanca (TED)
     * 								3 = cartao pre-pago (NAO CONSTRUIDO)
     */
    public java.lang.String getTipoConta() {
        return tipoConta;
    }


    /**
     * Sets the tipoConta value for this BancoType.
     * 
     * @param tipoConta   * Codigo do tipo de conta domicilio
     * 								' ' = C/C banco liquidante cielo (PAGFOR) 
     * 								0 = C/C banco liquidante cielo (PAGFOR) 
     * 								1 = C/C banco nao liquidante cielo (TED) 
     * 								2 = poupanca (TED)
     * 								3 = cartao pre-pago (NAO CONSTRUIDO)
     */
    public void setTipoConta(java.lang.String tipoConta) {
        this.tipoConta = tipoConta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BancoType)) return false;
        BancoType other = (BancoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoBanco==null && other.getCodigoBanco()==null) || 
             (this.codigoBanco!=null &&
              this.codigoBanco.equals(other.getCodigoBanco()))) &&
            ((this.numeroAgencia==null && other.getNumeroAgencia()==null) || 
             (this.numeroAgencia!=null &&
              this.numeroAgencia.equals(other.getNumeroAgencia()))) &&
            ((this.numeroConta==null && other.getNumeroConta()==null) || 
             (this.numeroConta!=null &&
              this.numeroConta.equals(other.getNumeroConta()))) &&
            ((this.tipoConta==null && other.getTipoConta()==null) || 
             (this.tipoConta!=null &&
              this.tipoConta.equals(other.getTipoConta())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoBanco() != null) {
            _hashCode += getCodigoBanco().hashCode();
        }
        if (getNumeroAgencia() != null) {
            _hashCode += getNumeroAgencia().hashCode();
        }
        if (getNumeroConta() != null) {
            _hashCode += getNumeroConta().hashCode();
        }
        if (getTipoConta() != null) {
            _hashCode += getTipoConta().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BancoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "BancoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "codigoBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroAgencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "numeroAgencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "numeroConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "tipoConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
