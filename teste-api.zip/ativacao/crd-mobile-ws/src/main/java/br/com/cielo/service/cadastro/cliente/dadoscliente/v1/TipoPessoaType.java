/**
 * TipoPessoaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;


/**
 * Tipo complexo que representa o tipo do cliente. (J : Juridica ||
 * F : Fisica)
 */
public class TipoPessoaType  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TipoPessoaTypeCodigoTipoPessoa codigoTipoPessoa;

    public TipoPessoaType() {
    }

    public TipoPessoaType(
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TipoPessoaTypeCodigoTipoPessoa codigoTipoPessoa) {
           this.codigoTipoPessoa = codigoTipoPessoa;
    }


    /**
     * Gets the codigoTipoPessoa value for this TipoPessoaType.
     * 
     * @return codigoTipoPessoa
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TipoPessoaTypeCodigoTipoPessoa getCodigoTipoPessoa() {
        return codigoTipoPessoa;
    }


    /**
     * Sets the codigoTipoPessoa value for this TipoPessoaType.
     * 
     * @param codigoTipoPessoa
     */
    public void setCodigoTipoPessoa(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TipoPessoaTypeCodigoTipoPessoa codigoTipoPessoa) {
        this.codigoTipoPessoa = codigoTipoPessoa;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TipoPessoaType)) return false;
        TipoPessoaType other = (TipoPessoaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTipoPessoa==null && other.getCodigoTipoPessoa()==null) || 
             (this.codigoTipoPessoa!=null &&
              this.codigoTipoPessoa.equals(other.getCodigoTipoPessoa())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTipoPessoa() != null) {
            _hashCode += getCodigoTipoPessoa().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TipoPessoaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "TipoPessoaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "codigoTipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">TipoPessoaType>codigoTipoPessoa"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
