/**
 * Cliente.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class Cliente  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o Cliente */
    private java.lang.Long codigoCliente;

    /* Numero da inscricao estadual do cliente */
    private java.lang.String numeroInscricaoEstadual;

    /* Data na qual o cliente foi aberto na cielo */
    private java.util.Date dataAberturaCliente;

    private java.lang.Long codigoCadeia;

    private java.lang.String descricaoPOS;

    private java.lang.Boolean indicadorCessao;

    /* Descricao complementar definido pelas bandeiras Visa
     * 						e Mastercard ou pela Cielo para qualificar ainda mais o ramo
     * de
     * 						atividade do Cliente.para classificar o ramo de negocio dos
     * seus
     * 						clientes. */
    private java.lang.String descricaoComplementoRamoAtividade;

    private java.lang.Boolean indicadorCartaCircularizacao;

    private java.lang.Boolean indicadorAntecipacaoAutomatica;

    private java.lang.String nomeEnderecoSite;

    private java.lang.Boolean indicadorAntecipacaoSecuritizacao;

    /* Informacoes do proprietario da empresa pessoa
     * 						juridica Cliente da Cielo */
    private br.com.cielo.canonico.cadastro.v1.Proprietario[] dadosProprietarioCliente;

    /* Nome do cliente da Cielo que seja pessoa fisica */
    private java.lang.String nomeCliente;

    /* Produtos */
    private br.com.cielo.canonico.cadastro.v1.Produto[][] dadosProdutoCliente;

    private java.lang.String codigoTipoGarantia;

    /* Nome fantasia do cliente pessoa juridica */
    private java.lang.String nomeFantasia;

    private br.com.cielo.canonico.cadastro.v1.Contato dadosContatoCliente;

    private java.lang.Boolean indicadorEcommerce;

    private br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo[] codigoMoeda;

    private java.lang.Boolean indicadorMultiBandeira;

    private java.lang.String codigoPCT;

    private java.lang.Boolean indicadorSecuratizacao;

    private java.lang.Boolean indicadorTrava;

    private java.lang.Boolean indicadorMoto;

    private br.com.cielo.canonico.cadastro.v1.DadosBancarios[] dadosBancarioCliente;

    private br.com.cielo.canonico.cadastro.v1.Proprietario dadosProprietarioMobile;

    private java.lang.Double percentualAntecipacao;

    private java.lang.String descricaoLimite;

    private java.lang.Boolean indicadorVisaVale;

    private java.lang.Boolean indicadorJuridico;

    private java.lang.Double valorTarifaAgendamento;

    private java.lang.Integer quantidadePOS;

    private java.lang.Boolean indicadorSaldoConsolidado;

    /* Codigo definido pelas bandeiras Visa e Mastercard
     * 						para identificar um ramo de atividade Tambem conhecido como
     * MCC,
     * 						ele e adotado pela Cielo e por todos os adquirentes e emissores
     * do
     * 						mundo para classificar o ramo de negocio dos seus clientes. */
    private java.lang.String codigoRamoAtividade;

    private java.lang.Integer codigoBandeira;

    private java.lang.String codigoSegmento;

    private java.lang.Long codigoECAssociada;

    /* Nome da razao social do Cliente Pessoa Juridica */
    private java.lang.String nomeRazaoSocial;

    /* Numero do CNPJ do Cliente pessoa juridica */
    private java.lang.String numeroCNPJ;

    private java.lang.Boolean indicadorCadeia;

    private java.lang.Boolean indicadorTransmissao;

    private java.lang.String codigoTipoPagamento;

    private br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoFisicoCliente;

    /* Descricao definido pelas bandeiras Visa e Mastercard
     * 						para identificar um ramo de atividade. */
    private java.lang.String descricaoRamoAtividade;

    private java.lang.Boolean indicadorRecebimentoSMS;

    private br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEnderecoCorrespondenciaCliente;

    private java.lang.String codigoCategoriaAntecipacao;

    private java.lang.String codigoAluguelPOS;

    private java.lang.String codigoPeriodicidadeAntecipacaoAutomatica;

    private java.lang.Long codigoECPrincipal;

    private java.lang.Boolean indicadorParcelado;

    private java.lang.Boolean indicadorMobile;

    /* Numero do CPF do cliente Cielo */
    private java.lang.String numeroCPF;

    /* Codigo adotado pelo sistema STAR para identificar o
     * 						tipo de pessoa (fi­sica ou juri­dica) do cliente da Cielo. */
    private java.lang.String codigoTipoPessoa;

    private java.lang.String codigoClasseFaturamento;

    /* Codigo adotado pela American Express para
     * 						identificar o seu cliente que tambem e cliente da Cielo. */
    private java.lang.String codigoClienteAMEX;

    private br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente[] dadosSituacaoFuncionamentoCliente;

    private java.util.Date dataUltimaAlteracao;

    private br.com.cielo.canonico.cadastro.v1.Contato[] dadosContatoEnderecoCorrespondencia;

    /* Informacao de negocios necessaria para identificar
     * 						se o cliente aceitou ser elegivel a ingressar em projetoas piloto.
     * 						Esta informacao e gerada atraves de contrato diretamente com
     * o
     * 						cliente, e por isso esta sendo adicionada ao canonico. */
    private java.lang.Boolean indicadorPiloto;

    /* Informacoes do contato adicional do cliente.
     * 						Nao esta vinculado a nenhum dos contatos anteriormente adicionados,
     * 						podendo ser apenas um contato sem vinculo direto a um endereco. */
    private br.com.cielo.canonico.cadastro.v1.Contato dadosContatoAdicional;

    /* Informacaoes de endereco pertencentes ao contrato do
     * 						cliente. */
    private br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEnderecoContrato;

    /* Informacoes de contato referenciadas no contrato */
    private br.com.cielo.canonico.cadastro.v1.Contato dadosContatoContrato;

    /* O nome da situação de atividade do cliente
     * 						identifica a situação atual do estabelecimento quanto a captura
     * de
     * 						transações na máquina da Cielo. Exemplos de situação: EC Ativo
     * (A)
     * 						EC Inativo até um ano (I) Inativo ha um ano ou mais (Y) */
    private java.lang.String nomeSituacaoAtividadeCliente;

    /* Indica se estabelecimento comercial possui permissao para aderir
     * produto ARV */
    private java.lang.Boolean indicadorTravaARV;

    /* Endereco utilizado para entrega dos suprimentos ao cliente. */
    private br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoSuprimento;

    /* identifica o tipo de cadeia quanto a centralização: CENTRALIZADA,
     * DESCENTRALIZADA ou INDIVIDUAL. */
    private java.lang.String nomeTipoCadeia;

    /* Nome da situação de ativação do cliente durante o ciclo de
     * vida do cliente na Cielo, ou seja, reflete a situação do cliente desde
     * o início da afiliação até o encerramento do relacionamento com a Cielo. */
    private java.lang.String nomeSituacaoAtivacaoCliente;

    /* Dados de contato do cliente para envio de SMS. */
    private br.com.cielo.canonico.cadastro.v1.Contato dadosContatoSMSCliente;

    /* Codigo que identifica a situacao do EC para operar como Correspondente
     * Bancario (COBAN). */
    private java.lang.String codigoStatusCobanCaptura;

    /* Descricao do codigo que identifica a situacao do EC para operar
     * como Correspondente Bancario (COBAN). */
    private java.lang.String descricaoStatusCobanCaptura;

    /* Identifica a opcao de pagamento recorrente que o o cliente
     * (EC) esta habilitado. */
    private java.lang.String codigoPagamentoRecorrente;

    /* Descricao da opcao de pagamento recorrente que o o cliente
     * (EC) esta habilitado. */
    private java.lang.String descricaoPagamentoRecorrente;

    /* Codigo do Banco no qual o EC atua como Coban. */
    private java.lang.String codigoBancoCoban;

    /* Nome do Banco no qual o EC atua como Coban. */
    private java.lang.String nomeBancoCoban;

    /* Indicador de bloqueio de pagamento (Sim ou nao) */
    private java.lang.Boolean indicadorBloqueioPagamento;

    /* Codigo que indica os tipos de bloqueio de pagamento */
    private java.math.BigInteger motivoRetornoCodigo;

    /* Descricao do motivo de bloqueio de pagamento  
     * Ex: Valores em aberto */
    private java.lang.String motivoRetornoDescricao;

    /* Endereco Ponto de Venda */
    private br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoPontoVenda;

    public Cliente() {
    }

    public Cliente(
           java.lang.Long codigoCliente,
           java.lang.String numeroInscricaoEstadual,
           java.util.Date dataAberturaCliente,
           java.lang.Long codigoCadeia,
           java.lang.String descricaoPOS,
           java.lang.Boolean indicadorCessao,
           java.lang.String descricaoComplementoRamoAtividade,
           java.lang.Boolean indicadorCartaCircularizacao,
           java.lang.Boolean indicadorAntecipacaoAutomatica,
           java.lang.String nomeEnderecoSite,
           java.lang.Boolean indicadorAntecipacaoSecuritizacao,
           br.com.cielo.canonico.cadastro.v1.Proprietario[] dadosProprietarioCliente,
           java.lang.String nomeCliente,
           br.com.cielo.canonico.cadastro.v1.Produto[][] dadosProdutoCliente,
           java.lang.String codigoTipoGarantia,
           java.lang.String nomeFantasia,
           br.com.cielo.canonico.cadastro.v1.Contato dadosContatoCliente,
           java.lang.Boolean indicadorEcommerce,
           br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo[] codigoMoeda,
           java.lang.Boolean indicadorMultiBandeira,
           java.lang.String codigoPCT,
           java.lang.Boolean indicadorSecuratizacao,
           java.lang.Boolean indicadorTrava,
           java.lang.Boolean indicadorMoto,
           br.com.cielo.canonico.cadastro.v1.DadosBancarios[] dadosBancarioCliente,
           br.com.cielo.canonico.cadastro.v1.Proprietario dadosProprietarioMobile,
           java.lang.Double percentualAntecipacao,
           java.lang.String descricaoLimite,
           java.lang.Boolean indicadorVisaVale,
           java.lang.Boolean indicadorJuridico,
           java.lang.Double valorTarifaAgendamento,
           java.lang.Integer quantidadePOS,
           java.lang.Boolean indicadorSaldoConsolidado,
           java.lang.String codigoRamoAtividade,
           java.lang.Integer codigoBandeira,
           java.lang.String codigoSegmento,
           java.lang.Long codigoECAssociada,
           java.lang.String nomeRazaoSocial,
           java.lang.String numeroCNPJ,
           java.lang.Boolean indicadorCadeia,
           java.lang.Boolean indicadorTransmissao,
           java.lang.String codigoTipoPagamento,
           br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoFisicoCliente,
           java.lang.String descricaoRamoAtividade,
           java.lang.Boolean indicadorRecebimentoSMS,
           br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEnderecoCorrespondenciaCliente,
           java.lang.String codigoCategoriaAntecipacao,
           java.lang.String codigoAluguelPOS,
           java.lang.String codigoPeriodicidadeAntecipacaoAutomatica,
           java.lang.Long codigoECPrincipal,
           java.lang.Boolean indicadorParcelado,
           java.lang.Boolean indicadorMobile,
           java.lang.String numeroCPF,
           java.lang.String codigoTipoPessoa,
           java.lang.String codigoClasseFaturamento,
           java.lang.String codigoClienteAMEX,
           br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente[] dadosSituacaoFuncionamentoCliente,
           java.util.Date dataUltimaAlteracao,
           br.com.cielo.canonico.cadastro.v1.Contato[] dadosContatoEnderecoCorrespondencia,
           java.lang.Boolean indicadorPiloto,
           br.com.cielo.canonico.cadastro.v1.Contato dadosContatoAdicional,
           br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEnderecoContrato,
           br.com.cielo.canonico.cadastro.v1.Contato dadosContatoContrato,
           java.lang.String nomeSituacaoAtividadeCliente,
           java.lang.Boolean indicadorTravaARV,
           br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoSuprimento,
           java.lang.String nomeTipoCadeia,
           java.lang.String nomeSituacaoAtivacaoCliente,
           br.com.cielo.canonico.cadastro.v1.Contato dadosContatoSMSCliente,
           java.lang.String codigoStatusCobanCaptura,
           java.lang.String descricaoStatusCobanCaptura,
           java.lang.String codigoPagamentoRecorrente,
           java.lang.String descricaoPagamentoRecorrente,
           java.lang.String codigoBancoCoban,
           java.lang.String nomeBancoCoban,
           java.lang.Boolean indicadorBloqueioPagamento,
           java.math.BigInteger motivoRetornoCodigo,
           java.lang.String motivoRetornoDescricao,
           br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoPontoVenda) {
           this.codigoCliente = codigoCliente;
           this.numeroInscricaoEstadual = numeroInscricaoEstadual;
           this.dataAberturaCliente = dataAberturaCliente;
           this.codigoCadeia = codigoCadeia;
           this.descricaoPOS = descricaoPOS;
           this.indicadorCessao = indicadorCessao;
           this.descricaoComplementoRamoAtividade = descricaoComplementoRamoAtividade;
           this.indicadorCartaCircularizacao = indicadorCartaCircularizacao;
           this.indicadorAntecipacaoAutomatica = indicadorAntecipacaoAutomatica;
           this.nomeEnderecoSite = nomeEnderecoSite;
           this.indicadorAntecipacaoSecuritizacao = indicadorAntecipacaoSecuritizacao;
           this.dadosProprietarioCliente = dadosProprietarioCliente;
           this.nomeCliente = nomeCliente;
           this.dadosProdutoCliente = dadosProdutoCliente;
           this.codigoTipoGarantia = codigoTipoGarantia;
           this.nomeFantasia = nomeFantasia;
           this.dadosContatoCliente = dadosContatoCliente;
           this.indicadorEcommerce = indicadorEcommerce;
           this.codigoMoeda = codigoMoeda;
           this.indicadorMultiBandeira = indicadorMultiBandeira;
           this.codigoPCT = codigoPCT;
           this.indicadorSecuratizacao = indicadorSecuratizacao;
           this.indicadorTrava = indicadorTrava;
           this.indicadorMoto = indicadorMoto;
           this.dadosBancarioCliente = dadosBancarioCliente;
           this.dadosProprietarioMobile = dadosProprietarioMobile;
           this.percentualAntecipacao = percentualAntecipacao;
           this.descricaoLimite = descricaoLimite;
           this.indicadorVisaVale = indicadorVisaVale;
           this.indicadorJuridico = indicadorJuridico;
           this.valorTarifaAgendamento = valorTarifaAgendamento;
           this.quantidadePOS = quantidadePOS;
           this.indicadorSaldoConsolidado = indicadorSaldoConsolidado;
           this.codigoRamoAtividade = codigoRamoAtividade;
           this.codigoBandeira = codigoBandeira;
           this.codigoSegmento = codigoSegmento;
           this.codigoECAssociada = codigoECAssociada;
           this.nomeRazaoSocial = nomeRazaoSocial;
           this.numeroCNPJ = numeroCNPJ;
           this.indicadorCadeia = indicadorCadeia;
           this.indicadorTransmissao = indicadorTransmissao;
           this.codigoTipoPagamento = codigoTipoPagamento;
           this.dadosEnderecoFisicoCliente = dadosEnderecoFisicoCliente;
           this.descricaoRamoAtividade = descricaoRamoAtividade;
           this.indicadorRecebimentoSMS = indicadorRecebimentoSMS;
           this.dadosEnderecoCorrespondenciaCliente = dadosEnderecoCorrespondenciaCliente;
           this.codigoCategoriaAntecipacao = codigoCategoriaAntecipacao;
           this.codigoAluguelPOS = codigoAluguelPOS;
           this.codigoPeriodicidadeAntecipacaoAutomatica = codigoPeriodicidadeAntecipacaoAutomatica;
           this.codigoECPrincipal = codigoECPrincipal;
           this.indicadorParcelado = indicadorParcelado;
           this.indicadorMobile = indicadorMobile;
           this.numeroCPF = numeroCPF;
           this.codigoTipoPessoa = codigoTipoPessoa;
           this.codigoClasseFaturamento = codigoClasseFaturamento;
           this.codigoClienteAMEX = codigoClienteAMEX;
           this.dadosSituacaoFuncionamentoCliente = dadosSituacaoFuncionamentoCliente;
           this.dataUltimaAlteracao = dataUltimaAlteracao;
           this.dadosContatoEnderecoCorrespondencia = dadosContatoEnderecoCorrespondencia;
           this.indicadorPiloto = indicadorPiloto;
           this.dadosContatoAdicional = dadosContatoAdicional;
           this.dadosEnderecoContrato = dadosEnderecoContrato;
           this.dadosContatoContrato = dadosContatoContrato;
           this.nomeSituacaoAtividadeCliente = nomeSituacaoAtividadeCliente;
           this.indicadorTravaARV = indicadorTravaARV;
           this.dadosEnderecoSuprimento = dadosEnderecoSuprimento;
           this.nomeTipoCadeia = nomeTipoCadeia;
           this.nomeSituacaoAtivacaoCliente = nomeSituacaoAtivacaoCliente;
           this.dadosContatoSMSCliente = dadosContatoSMSCliente;
           this.codigoStatusCobanCaptura = codigoStatusCobanCaptura;
           this.descricaoStatusCobanCaptura = descricaoStatusCobanCaptura;
           this.codigoPagamentoRecorrente = codigoPagamentoRecorrente;
           this.descricaoPagamentoRecorrente = descricaoPagamentoRecorrente;
           this.codigoBancoCoban = codigoBancoCoban;
           this.nomeBancoCoban = nomeBancoCoban;
           this.indicadorBloqueioPagamento = indicadorBloqueioPagamento;
           this.motivoRetornoCodigo = motivoRetornoCodigo;
           this.motivoRetornoDescricao = motivoRetornoDescricao;
           this.dadosEnderecoPontoVenda = dadosEnderecoPontoVenda;
    }


    /**
     * Gets the codigoCliente value for this Cliente.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this Cliente.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the numeroInscricaoEstadual value for this Cliente.
     * 
     * @return numeroInscricaoEstadual   * Numero da inscricao estadual do cliente
     */
    public java.lang.String getNumeroInscricaoEstadual() {
        return numeroInscricaoEstadual;
    }


    /**
     * Sets the numeroInscricaoEstadual value for this Cliente.
     * 
     * @param numeroInscricaoEstadual   * Numero da inscricao estadual do cliente
     */
    public void setNumeroInscricaoEstadual(java.lang.String numeroInscricaoEstadual) {
        this.numeroInscricaoEstadual = numeroInscricaoEstadual;
    }


    /**
     * Gets the dataAberturaCliente value for this Cliente.
     * 
     * @return dataAberturaCliente   * Data na qual o cliente foi aberto na cielo
     */
    public java.util.Date getDataAberturaCliente() {
        return dataAberturaCliente;
    }


    /**
     * Sets the dataAberturaCliente value for this Cliente.
     * 
     * @param dataAberturaCliente   * Data na qual o cliente foi aberto na cielo
     */
    public void setDataAberturaCliente(java.util.Date dataAberturaCliente) {
        this.dataAberturaCliente = dataAberturaCliente;
    }


    /**
     * Gets the codigoCadeia value for this Cliente.
     * 
     * @return codigoCadeia
     */
    public java.lang.Long getCodigoCadeia() {
        return codigoCadeia;
    }


    /**
     * Sets the codigoCadeia value for this Cliente.
     * 
     * @param codigoCadeia
     */
    public void setCodigoCadeia(java.lang.Long codigoCadeia) {
        this.codigoCadeia = codigoCadeia;
    }


    /**
     * Gets the descricaoPOS value for this Cliente.
     * 
     * @return descricaoPOS
     */
    public java.lang.String getDescricaoPOS() {
        return descricaoPOS;
    }


    /**
     * Sets the descricaoPOS value for this Cliente.
     * 
     * @param descricaoPOS
     */
    public void setDescricaoPOS(java.lang.String descricaoPOS) {
        this.descricaoPOS = descricaoPOS;
    }


    /**
     * Gets the indicadorCessao value for this Cliente.
     * 
     * @return indicadorCessao
     */
    public java.lang.Boolean getIndicadorCessao() {
        return indicadorCessao;
    }


    /**
     * Sets the indicadorCessao value for this Cliente.
     * 
     * @param indicadorCessao
     */
    public void setIndicadorCessao(java.lang.Boolean indicadorCessao) {
        this.indicadorCessao = indicadorCessao;
    }


    /**
     * Gets the descricaoComplementoRamoAtividade value for this Cliente.
     * 
     * @return descricaoComplementoRamoAtividade   * Descricao complementar definido pelas bandeiras Visa
     * 						e Mastercard ou pela Cielo para qualificar ainda mais o ramo
     * de
     * 						atividade do Cliente.para classificar o ramo de negocio dos
     * seus
     * 						clientes.
     */
    public java.lang.String getDescricaoComplementoRamoAtividade() {
        return descricaoComplementoRamoAtividade;
    }


    /**
     * Sets the descricaoComplementoRamoAtividade value for this Cliente.
     * 
     * @param descricaoComplementoRamoAtividade   * Descricao complementar definido pelas bandeiras Visa
     * 						e Mastercard ou pela Cielo para qualificar ainda mais o ramo
     * de
     * 						atividade do Cliente.para classificar o ramo de negocio dos
     * seus
     * 						clientes.
     */
    public void setDescricaoComplementoRamoAtividade(java.lang.String descricaoComplementoRamoAtividade) {
        this.descricaoComplementoRamoAtividade = descricaoComplementoRamoAtividade;
    }


    /**
     * Gets the indicadorCartaCircularizacao value for this Cliente.
     * 
     * @return indicadorCartaCircularizacao
     */
    public java.lang.Boolean getIndicadorCartaCircularizacao() {
        return indicadorCartaCircularizacao;
    }


    /**
     * Sets the indicadorCartaCircularizacao value for this Cliente.
     * 
     * @param indicadorCartaCircularizacao
     */
    public void setIndicadorCartaCircularizacao(java.lang.Boolean indicadorCartaCircularizacao) {
        this.indicadorCartaCircularizacao = indicadorCartaCircularizacao;
    }


    /**
     * Gets the indicadorAntecipacaoAutomatica value for this Cliente.
     * 
     * @return indicadorAntecipacaoAutomatica
     */
    public java.lang.Boolean getIndicadorAntecipacaoAutomatica() {
        return indicadorAntecipacaoAutomatica;
    }


    /**
     * Sets the indicadorAntecipacaoAutomatica value for this Cliente.
     * 
     * @param indicadorAntecipacaoAutomatica
     */
    public void setIndicadorAntecipacaoAutomatica(java.lang.Boolean indicadorAntecipacaoAutomatica) {
        this.indicadorAntecipacaoAutomatica = indicadorAntecipacaoAutomatica;
    }


    /**
     * Gets the nomeEnderecoSite value for this Cliente.
     * 
     * @return nomeEnderecoSite
     */
    public java.lang.String getNomeEnderecoSite() {
        return nomeEnderecoSite;
    }


    /**
     * Sets the nomeEnderecoSite value for this Cliente.
     * 
     * @param nomeEnderecoSite
     */
    public void setNomeEnderecoSite(java.lang.String nomeEnderecoSite) {
        this.nomeEnderecoSite = nomeEnderecoSite;
    }


    /**
     * Gets the indicadorAntecipacaoSecuritizacao value for this Cliente.
     * 
     * @return indicadorAntecipacaoSecuritizacao
     */
    public java.lang.Boolean getIndicadorAntecipacaoSecuritizacao() {
        return indicadorAntecipacaoSecuritizacao;
    }


    /**
     * Sets the indicadorAntecipacaoSecuritizacao value for this Cliente.
     * 
     * @param indicadorAntecipacaoSecuritizacao
     */
    public void setIndicadorAntecipacaoSecuritizacao(java.lang.Boolean indicadorAntecipacaoSecuritizacao) {
        this.indicadorAntecipacaoSecuritizacao = indicadorAntecipacaoSecuritizacao;
    }


    /**
     * Gets the dadosProprietarioCliente value for this Cliente.
     * 
     * @return dadosProprietarioCliente   * Informacoes do proprietario da empresa pessoa
     * 						juridica Cliente da Cielo
     */
    public br.com.cielo.canonico.cadastro.v1.Proprietario[] getDadosProprietarioCliente() {
        return dadosProprietarioCliente;
    }


    /**
     * Sets the dadosProprietarioCliente value for this Cliente.
     * 
     * @param dadosProprietarioCliente   * Informacoes do proprietario da empresa pessoa
     * 						juridica Cliente da Cielo
     */
    public void setDadosProprietarioCliente(br.com.cielo.canonico.cadastro.v1.Proprietario[] dadosProprietarioCliente) {
        this.dadosProprietarioCliente = dadosProprietarioCliente;
    }

    public br.com.cielo.canonico.cadastro.v1.Proprietario getDadosProprietarioCliente(int i) {
        return this.dadosProprietarioCliente[i];
    }

    public void setDadosProprietarioCliente(int i, br.com.cielo.canonico.cadastro.v1.Proprietario _value) {
        this.dadosProprietarioCliente[i] = _value;
    }


    /**
     * Gets the nomeCliente value for this Cliente.
     * 
     * @return nomeCliente   * Nome do cliente da Cielo que seja pessoa fisica
     */
    public java.lang.String getNomeCliente() {
        return nomeCliente;
    }


    /**
     * Sets the nomeCliente value for this Cliente.
     * 
     * @param nomeCliente   * Nome do cliente da Cielo que seja pessoa fisica
     */
    public void setNomeCliente(java.lang.String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }


    /**
     * Gets the dadosProdutoCliente value for this Cliente.
     * 
     * @return dadosProdutoCliente   * Produtos
     */
    public br.com.cielo.canonico.cadastro.v1.Produto[][] getDadosProdutoCliente() {
        return dadosProdutoCliente;
    }


    /**
     * Sets the dadosProdutoCliente value for this Cliente.
     * 
     * @param dadosProdutoCliente   * Produtos
     */
    public void setDadosProdutoCliente(br.com.cielo.canonico.cadastro.v1.Produto[][] dadosProdutoCliente) {
        this.dadosProdutoCliente = dadosProdutoCliente;
    }

    public br.com.cielo.canonico.cadastro.v1.Produto[] getDadosProdutoCliente(int i) {
        return this.dadosProdutoCliente[i];
    }

    public void setDadosProdutoCliente(int i, br.com.cielo.canonico.cadastro.v1.Produto[] _value) {
        this.dadosProdutoCliente[i] = _value;
    }


    /**
     * Gets the codigoTipoGarantia value for this Cliente.
     * 
     * @return codigoTipoGarantia
     */
    public java.lang.String getCodigoTipoGarantia() {
        return codigoTipoGarantia;
    }


    /**
     * Sets the codigoTipoGarantia value for this Cliente.
     * 
     * @param codigoTipoGarantia
     */
    public void setCodigoTipoGarantia(java.lang.String codigoTipoGarantia) {
        this.codigoTipoGarantia = codigoTipoGarantia;
    }


    /**
     * Gets the nomeFantasia value for this Cliente.
     * 
     * @return nomeFantasia   * Nome fantasia do cliente pessoa juridica
     */
    public java.lang.String getNomeFantasia() {
        return nomeFantasia;
    }


    /**
     * Sets the nomeFantasia value for this Cliente.
     * 
     * @param nomeFantasia   * Nome fantasia do cliente pessoa juridica
     */
    public void setNomeFantasia(java.lang.String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }


    /**
     * Gets the dadosContatoCliente value for this Cliente.
     * 
     * @return dadosContatoCliente
     */
    public br.com.cielo.canonico.cadastro.v1.Contato getDadosContatoCliente() {
        return dadosContatoCliente;
    }


    /**
     * Sets the dadosContatoCliente value for this Cliente.
     * 
     * @param dadosContatoCliente
     */
    public void setDadosContatoCliente(br.com.cielo.canonico.cadastro.v1.Contato dadosContatoCliente) {
        this.dadosContatoCliente = dadosContatoCliente;
    }


    /**
     * Gets the indicadorEcommerce value for this Cliente.
     * 
     * @return indicadorEcommerce
     */
    public java.lang.Boolean getIndicadorEcommerce() {
        return indicadorEcommerce;
    }


    /**
     * Sets the indicadorEcommerce value for this Cliente.
     * 
     * @param indicadorEcommerce
     */
    public void setIndicadorEcommerce(java.lang.Boolean indicadorEcommerce) {
        this.indicadorEcommerce = indicadorEcommerce;
    }


    /**
     * Gets the codigoMoeda value for this Cliente.
     * 
     * @return codigoMoeda
     */
    public br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo[] getCodigoMoeda() {
        return codigoMoeda;
    }


    /**
     * Sets the codigoMoeda value for this Cliente.
     * 
     * @param codigoMoeda
     */
    public void setCodigoMoeda(br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo[] codigoMoeda) {
        this.codigoMoeda = codigoMoeda;
    }

    public br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo getCodigoMoeda(int i) {
        return this.codigoMoeda[i];
    }

    public void setCodigoMoeda(int i, br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo _value) {
        this.codigoMoeda[i] = _value;
    }


    /**
     * Gets the indicadorMultiBandeira value for this Cliente.
     * 
     * @return indicadorMultiBandeira
     */
    public java.lang.Boolean getIndicadorMultiBandeira() {
        return indicadorMultiBandeira;
    }


    /**
     * Sets the indicadorMultiBandeira value for this Cliente.
     * 
     * @param indicadorMultiBandeira
     */
    public void setIndicadorMultiBandeira(java.lang.Boolean indicadorMultiBandeira) {
        this.indicadorMultiBandeira = indicadorMultiBandeira;
    }


    /**
     * Gets the codigoPCT value for this Cliente.
     * 
     * @return codigoPCT
     */
    public java.lang.String getCodigoPCT() {
        return codigoPCT;
    }


    /**
     * Sets the codigoPCT value for this Cliente.
     * 
     * @param codigoPCT
     */
    public void setCodigoPCT(java.lang.String codigoPCT) {
        this.codigoPCT = codigoPCT;
    }


    /**
     * Gets the indicadorSecuratizacao value for this Cliente.
     * 
     * @return indicadorSecuratizacao
     */
    public java.lang.Boolean getIndicadorSecuratizacao() {
        return indicadorSecuratizacao;
    }


    /**
     * Sets the indicadorSecuratizacao value for this Cliente.
     * 
     * @param indicadorSecuratizacao
     */
    public void setIndicadorSecuratizacao(java.lang.Boolean indicadorSecuratizacao) {
        this.indicadorSecuratizacao = indicadorSecuratizacao;
    }


    /**
     * Gets the indicadorTrava value for this Cliente.
     * 
     * @return indicadorTrava
     */
    public java.lang.Boolean getIndicadorTrava() {
        return indicadorTrava;
    }


    /**
     * Sets the indicadorTrava value for this Cliente.
     * 
     * @param indicadorTrava
     */
    public void setIndicadorTrava(java.lang.Boolean indicadorTrava) {
        this.indicadorTrava = indicadorTrava;
    }


    /**
     * Gets the indicadorMoto value for this Cliente.
     * 
     * @return indicadorMoto
     */
    public java.lang.Boolean getIndicadorMoto() {
        return indicadorMoto;
    }


    /**
     * Sets the indicadorMoto value for this Cliente.
     * 
     * @param indicadorMoto
     */
    public void setIndicadorMoto(java.lang.Boolean indicadorMoto) {
        this.indicadorMoto = indicadorMoto;
    }


    /**
     * Gets the dadosBancarioCliente value for this Cliente.
     * 
     * @return dadosBancarioCliente
     */
    public br.com.cielo.canonico.cadastro.v1.DadosBancarios[] getDadosBancarioCliente() {
        return dadosBancarioCliente;
    }


    /**
     * Sets the dadosBancarioCliente value for this Cliente.
     * 
     * @param dadosBancarioCliente
     */
    public void setDadosBancarioCliente(br.com.cielo.canonico.cadastro.v1.DadosBancarios[] dadosBancarioCliente) {
        this.dadosBancarioCliente = dadosBancarioCliente;
    }

    public br.com.cielo.canonico.cadastro.v1.DadosBancarios getDadosBancarioCliente(int i) {
        return this.dadosBancarioCliente[i];
    }

    public void setDadosBancarioCliente(int i, br.com.cielo.canonico.cadastro.v1.DadosBancarios _value) {
        this.dadosBancarioCliente[i] = _value;
    }


    /**
     * Gets the dadosProprietarioMobile value for this Cliente.
     * 
     * @return dadosProprietarioMobile
     */
    public br.com.cielo.canonico.cadastro.v1.Proprietario getDadosProprietarioMobile() {
        return dadosProprietarioMobile;
    }


    /**
     * Sets the dadosProprietarioMobile value for this Cliente.
     * 
     * @param dadosProprietarioMobile
     */
    public void setDadosProprietarioMobile(br.com.cielo.canonico.cadastro.v1.Proprietario dadosProprietarioMobile) {
        this.dadosProprietarioMobile = dadosProprietarioMobile;
    }


    /**
     * Gets the percentualAntecipacao value for this Cliente.
     * 
     * @return percentualAntecipacao
     */
    public java.lang.Double getPercentualAntecipacao() {
        return percentualAntecipacao;
    }


    /**
     * Sets the percentualAntecipacao value for this Cliente.
     * 
     * @param percentualAntecipacao
     */
    public void setPercentualAntecipacao(java.lang.Double percentualAntecipacao) {
        this.percentualAntecipacao = percentualAntecipacao;
    }


    /**
     * Gets the descricaoLimite value for this Cliente.
     * 
     * @return descricaoLimite
     */
    public java.lang.String getDescricaoLimite() {
        return descricaoLimite;
    }


    /**
     * Sets the descricaoLimite value for this Cliente.
     * 
     * @param descricaoLimite
     */
    public void setDescricaoLimite(java.lang.String descricaoLimite) {
        this.descricaoLimite = descricaoLimite;
    }


    /**
     * Gets the indicadorVisaVale value for this Cliente.
     * 
     * @return indicadorVisaVale
     */
    public java.lang.Boolean getIndicadorVisaVale() {
        return indicadorVisaVale;
    }


    /**
     * Sets the indicadorVisaVale value for this Cliente.
     * 
     * @param indicadorVisaVale
     */
    public void setIndicadorVisaVale(java.lang.Boolean indicadorVisaVale) {
        this.indicadorVisaVale = indicadorVisaVale;
    }


    /**
     * Gets the indicadorJuridico value for this Cliente.
     * 
     * @return indicadorJuridico
     */
    public java.lang.Boolean getIndicadorJuridico() {
        return indicadorJuridico;
    }


    /**
     * Sets the indicadorJuridico value for this Cliente.
     * 
     * @param indicadorJuridico
     */
    public void setIndicadorJuridico(java.lang.Boolean indicadorJuridico) {
        this.indicadorJuridico = indicadorJuridico;
    }


    /**
     * Gets the valorTarifaAgendamento value for this Cliente.
     * 
     * @return valorTarifaAgendamento
     */
    public java.lang.Double getValorTarifaAgendamento() {
        return valorTarifaAgendamento;
    }


    /**
     * Sets the valorTarifaAgendamento value for this Cliente.
     * 
     * @param valorTarifaAgendamento
     */
    public void setValorTarifaAgendamento(java.lang.Double valorTarifaAgendamento) {
        this.valorTarifaAgendamento = valorTarifaAgendamento;
    }


    /**
     * Gets the quantidadePOS value for this Cliente.
     * 
     * @return quantidadePOS
     */
    public java.lang.Integer getQuantidadePOS() {
        return quantidadePOS;
    }


    /**
     * Sets the quantidadePOS value for this Cliente.
     * 
     * @param quantidadePOS
     */
    public void setQuantidadePOS(java.lang.Integer quantidadePOS) {
        this.quantidadePOS = quantidadePOS;
    }


    /**
     * Gets the indicadorSaldoConsolidado value for this Cliente.
     * 
     * @return indicadorSaldoConsolidado
     */
    public java.lang.Boolean getIndicadorSaldoConsolidado() {
        return indicadorSaldoConsolidado;
    }


    /**
     * Sets the indicadorSaldoConsolidado value for this Cliente.
     * 
     * @param indicadorSaldoConsolidado
     */
    public void setIndicadorSaldoConsolidado(java.lang.Boolean indicadorSaldoConsolidado) {
        this.indicadorSaldoConsolidado = indicadorSaldoConsolidado;
    }


    /**
     * Gets the codigoRamoAtividade value for this Cliente.
     * 
     * @return codigoRamoAtividade   * Codigo definido pelas bandeiras Visa e Mastercard
     * 						para identificar um ramo de atividade Tambem conhecido como
     * MCC,
     * 						ele e adotado pela Cielo e por todos os adquirentes e emissores
     * do
     * 						mundo para classificar o ramo de negocio dos seus clientes.
     */
    public java.lang.String getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this Cliente.
     * 
     * @param codigoRamoAtividade   * Codigo definido pelas bandeiras Visa e Mastercard
     * 						para identificar um ramo de atividade Tambem conhecido como
     * MCC,
     * 						ele e adotado pela Cielo e por todos os adquirentes e emissores
     * do
     * 						mundo para classificar o ramo de negocio dos seus clientes.
     */
    public void setCodigoRamoAtividade(java.lang.String codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the codigoBandeira value for this Cliente.
     * 
     * @return codigoBandeira
     */
    public java.lang.Integer getCodigoBandeira() {
        return codigoBandeira;
    }


    /**
     * Sets the codigoBandeira value for this Cliente.
     * 
     * @param codigoBandeira
     */
    public void setCodigoBandeira(java.lang.Integer codigoBandeira) {
        this.codigoBandeira = codigoBandeira;
    }


    /**
     * Gets the codigoSegmento value for this Cliente.
     * 
     * @return codigoSegmento
     */
    public java.lang.String getCodigoSegmento() {
        return codigoSegmento;
    }


    /**
     * Sets the codigoSegmento value for this Cliente.
     * 
     * @param codigoSegmento
     */
    public void setCodigoSegmento(java.lang.String codigoSegmento) {
        this.codigoSegmento = codigoSegmento;
    }


    /**
     * Gets the codigoECAssociada value for this Cliente.
     * 
     * @return codigoECAssociada
     */
    public java.lang.Long getCodigoECAssociada() {
        return codigoECAssociada;
    }


    /**
     * Sets the codigoECAssociada value for this Cliente.
     * 
     * @param codigoECAssociada
     */
    public void setCodigoECAssociada(java.lang.Long codigoECAssociada) {
        this.codigoECAssociada = codigoECAssociada;
    }


    /**
     * Gets the nomeRazaoSocial value for this Cliente.
     * 
     * @return nomeRazaoSocial   * Nome da razao social do Cliente Pessoa Juridica
     */
    public java.lang.String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }


    /**
     * Sets the nomeRazaoSocial value for this Cliente.
     * 
     * @param nomeRazaoSocial   * Nome da razao social do Cliente Pessoa Juridica
     */
    public void setNomeRazaoSocial(java.lang.String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }


    /**
     * Gets the numeroCNPJ value for this Cliente.
     * 
     * @return numeroCNPJ   * Numero do CNPJ do Cliente pessoa juridica
     */
    public java.lang.String getNumeroCNPJ() {
        return numeroCNPJ;
    }


    /**
     * Sets the numeroCNPJ value for this Cliente.
     * 
     * @param numeroCNPJ   * Numero do CNPJ do Cliente pessoa juridica
     */
    public void setNumeroCNPJ(java.lang.String numeroCNPJ) {
        this.numeroCNPJ = numeroCNPJ;
    }


    /**
     * Gets the indicadorCadeia value for this Cliente.
     * 
     * @return indicadorCadeia
     */
    public java.lang.Boolean getIndicadorCadeia() {
        return indicadorCadeia;
    }


    /**
     * Sets the indicadorCadeia value for this Cliente.
     * 
     * @param indicadorCadeia
     */
    public void setIndicadorCadeia(java.lang.Boolean indicadorCadeia) {
        this.indicadorCadeia = indicadorCadeia;
    }


    /**
     * Gets the indicadorTransmissao value for this Cliente.
     * 
     * @return indicadorTransmissao
     */
    public java.lang.Boolean getIndicadorTransmissao() {
        return indicadorTransmissao;
    }


    /**
     * Sets the indicadorTransmissao value for this Cliente.
     * 
     * @param indicadorTransmissao
     */
    public void setIndicadorTransmissao(java.lang.Boolean indicadorTransmissao) {
        this.indicadorTransmissao = indicadorTransmissao;
    }


    /**
     * Gets the codigoTipoPagamento value for this Cliente.
     * 
     * @return codigoTipoPagamento
     */
    public java.lang.String getCodigoTipoPagamento() {
        return codigoTipoPagamento;
    }


    /**
     * Sets the codigoTipoPagamento value for this Cliente.
     * 
     * @param codigoTipoPagamento
     */
    public void setCodigoTipoPagamento(java.lang.String codigoTipoPagamento) {
        this.codigoTipoPagamento = codigoTipoPagamento;
    }


    /**
     * Gets the dadosEnderecoFisicoCliente value for this Cliente.
     * 
     * @return dadosEnderecoFisicoCliente
     */
    public br.com.cielo.canonico.cadastro.v1.Endereco getDadosEnderecoFisicoCliente() {
        return dadosEnderecoFisicoCliente;
    }


    /**
     * Sets the dadosEnderecoFisicoCliente value for this Cliente.
     * 
     * @param dadosEnderecoFisicoCliente
     */
    public void setDadosEnderecoFisicoCliente(br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoFisicoCliente) {
        this.dadosEnderecoFisicoCliente = dadosEnderecoFisicoCliente;
    }


    /**
     * Gets the descricaoRamoAtividade value for this Cliente.
     * 
     * @return descricaoRamoAtividade   * Descricao definido pelas bandeiras Visa e Mastercard
     * 						para identificar um ramo de atividade.
     */
    public java.lang.String getDescricaoRamoAtividade() {
        return descricaoRamoAtividade;
    }


    /**
     * Sets the descricaoRamoAtividade value for this Cliente.
     * 
     * @param descricaoRamoAtividade   * Descricao definido pelas bandeiras Visa e Mastercard
     * 						para identificar um ramo de atividade.
     */
    public void setDescricaoRamoAtividade(java.lang.String descricaoRamoAtividade) {
        this.descricaoRamoAtividade = descricaoRamoAtividade;
    }


    /**
     * Gets the indicadorRecebimentoSMS value for this Cliente.
     * 
     * @return indicadorRecebimentoSMS
     */
    public java.lang.Boolean getIndicadorRecebimentoSMS() {
        return indicadorRecebimentoSMS;
    }


    /**
     * Sets the indicadorRecebimentoSMS value for this Cliente.
     * 
     * @param indicadorRecebimentoSMS
     */
    public void setIndicadorRecebimentoSMS(java.lang.Boolean indicadorRecebimentoSMS) {
        this.indicadorRecebimentoSMS = indicadorRecebimentoSMS;
    }


    /**
     * Gets the dadosEnderecoCorrespondenciaCliente value for this Cliente.
     * 
     * @return dadosEnderecoCorrespondenciaCliente
     */
    public br.com.cielo.canonico.cadastro.v1.Endereco[] getDadosEnderecoCorrespondenciaCliente() {
        return dadosEnderecoCorrespondenciaCliente;
    }


    /**
     * Sets the dadosEnderecoCorrespondenciaCliente value for this Cliente.
     * 
     * @param dadosEnderecoCorrespondenciaCliente
     */
    public void setDadosEnderecoCorrespondenciaCliente(br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEnderecoCorrespondenciaCliente) {
        this.dadosEnderecoCorrespondenciaCliente = dadosEnderecoCorrespondenciaCliente;
    }

    public br.com.cielo.canonico.cadastro.v1.Endereco getDadosEnderecoCorrespondenciaCliente(int i) {
        return this.dadosEnderecoCorrespondenciaCliente[i];
    }

    public void setDadosEnderecoCorrespondenciaCliente(int i, br.com.cielo.canonico.cadastro.v1.Endereco _value) {
        this.dadosEnderecoCorrespondenciaCliente[i] = _value;
    }


    /**
     * Gets the codigoCategoriaAntecipacao value for this Cliente.
     * 
     * @return codigoCategoriaAntecipacao
     */
    public java.lang.String getCodigoCategoriaAntecipacao() {
        return codigoCategoriaAntecipacao;
    }


    /**
     * Sets the codigoCategoriaAntecipacao value for this Cliente.
     * 
     * @param codigoCategoriaAntecipacao
     */
    public void setCodigoCategoriaAntecipacao(java.lang.String codigoCategoriaAntecipacao) {
        this.codigoCategoriaAntecipacao = codigoCategoriaAntecipacao;
    }


    /**
     * Gets the codigoAluguelPOS value for this Cliente.
     * 
     * @return codigoAluguelPOS
     */
    public java.lang.String getCodigoAluguelPOS() {
        return codigoAluguelPOS;
    }


    /**
     * Sets the codigoAluguelPOS value for this Cliente.
     * 
     * @param codigoAluguelPOS
     */
    public void setCodigoAluguelPOS(java.lang.String codigoAluguelPOS) {
        this.codigoAluguelPOS = codigoAluguelPOS;
    }


    /**
     * Gets the codigoPeriodicidadeAntecipacaoAutomatica value for this Cliente.
     * 
     * @return codigoPeriodicidadeAntecipacaoAutomatica
     */
    public java.lang.String getCodigoPeriodicidadeAntecipacaoAutomatica() {
        return codigoPeriodicidadeAntecipacaoAutomatica;
    }


    /**
     * Sets the codigoPeriodicidadeAntecipacaoAutomatica value for this Cliente.
     * 
     * @param codigoPeriodicidadeAntecipacaoAutomatica
     */
    public void setCodigoPeriodicidadeAntecipacaoAutomatica(java.lang.String codigoPeriodicidadeAntecipacaoAutomatica) {
        this.codigoPeriodicidadeAntecipacaoAutomatica = codigoPeriodicidadeAntecipacaoAutomatica;
    }


    /**
     * Gets the codigoECPrincipal value for this Cliente.
     * 
     * @return codigoECPrincipal
     */
    public java.lang.Long getCodigoECPrincipal() {
        return codigoECPrincipal;
    }


    /**
     * Sets the codigoECPrincipal value for this Cliente.
     * 
     * @param codigoECPrincipal
     */
    public void setCodigoECPrincipal(java.lang.Long codigoECPrincipal) {
        this.codigoECPrincipal = codigoECPrincipal;
    }


    /**
     * Gets the indicadorParcelado value for this Cliente.
     * 
     * @return indicadorParcelado
     */
    public java.lang.Boolean getIndicadorParcelado() {
        return indicadorParcelado;
    }


    /**
     * Sets the indicadorParcelado value for this Cliente.
     * 
     * @param indicadorParcelado
     */
    public void setIndicadorParcelado(java.lang.Boolean indicadorParcelado) {
        this.indicadorParcelado = indicadorParcelado;
    }


    /**
     * Gets the indicadorMobile value for this Cliente.
     * 
     * @return indicadorMobile
     */
    public java.lang.Boolean getIndicadorMobile() {
        return indicadorMobile;
    }


    /**
     * Sets the indicadorMobile value for this Cliente.
     * 
     * @param indicadorMobile
     */
    public void setIndicadorMobile(java.lang.Boolean indicadorMobile) {
        this.indicadorMobile = indicadorMobile;
    }


    /**
     * Gets the numeroCPF value for this Cliente.
     * 
     * @return numeroCPF   * Numero do CPF do cliente Cielo
     */
    public java.lang.String getNumeroCPF() {
        return numeroCPF;
    }


    /**
     * Sets the numeroCPF value for this Cliente.
     * 
     * @param numeroCPF   * Numero do CPF do cliente Cielo
     */
    public void setNumeroCPF(java.lang.String numeroCPF) {
        this.numeroCPF = numeroCPF;
    }


    /**
     * Gets the codigoTipoPessoa value for this Cliente.
     * 
     * @return codigoTipoPessoa   * Codigo adotado pelo sistema STAR para identificar o
     * 						tipo de pessoa (fi­sica ou juri­dica) do cliente da Cielo.
     */
    public java.lang.String getCodigoTipoPessoa() {
        return codigoTipoPessoa;
    }


    /**
     * Sets the codigoTipoPessoa value for this Cliente.
     * 
     * @param codigoTipoPessoa   * Codigo adotado pelo sistema STAR para identificar o
     * 						tipo de pessoa (fi­sica ou juri­dica) do cliente da Cielo.
     */
    public void setCodigoTipoPessoa(java.lang.String codigoTipoPessoa) {
        this.codigoTipoPessoa = codigoTipoPessoa;
    }


    /**
     * Gets the codigoClasseFaturamento value for this Cliente.
     * 
     * @return codigoClasseFaturamento
     */
    public java.lang.String getCodigoClasseFaturamento() {
        return codigoClasseFaturamento;
    }


    /**
     * Sets the codigoClasseFaturamento value for this Cliente.
     * 
     * @param codigoClasseFaturamento
     */
    public void setCodigoClasseFaturamento(java.lang.String codigoClasseFaturamento) {
        this.codigoClasseFaturamento = codigoClasseFaturamento;
    }


    /**
     * Gets the codigoClienteAMEX value for this Cliente.
     * 
     * @return codigoClienteAMEX   * Codigo adotado pela American Express para
     * 						identificar o seu cliente que tambem e cliente da Cielo.
     */
    public java.lang.String getCodigoClienteAMEX() {
        return codigoClienteAMEX;
    }


    /**
     * Sets the codigoClienteAMEX value for this Cliente.
     * 
     * @param codigoClienteAMEX   * Codigo adotado pela American Express para
     * 						identificar o seu cliente que tambem e cliente da Cielo.
     */
    public void setCodigoClienteAMEX(java.lang.String codigoClienteAMEX) {
        this.codigoClienteAMEX = codigoClienteAMEX;
    }


    /**
     * Gets the dadosSituacaoFuncionamentoCliente value for this Cliente.
     * 
     * @return dadosSituacaoFuncionamentoCliente
     */
    public br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente[] getDadosSituacaoFuncionamentoCliente() {
        return dadosSituacaoFuncionamentoCliente;
    }


    /**
     * Sets the dadosSituacaoFuncionamentoCliente value for this Cliente.
     * 
     * @param dadosSituacaoFuncionamentoCliente
     */
    public void setDadosSituacaoFuncionamentoCliente(br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente[] dadosSituacaoFuncionamentoCliente) {
        this.dadosSituacaoFuncionamentoCliente = dadosSituacaoFuncionamentoCliente;
    }

    public br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente getDadosSituacaoFuncionamentoCliente(int i) {
        return this.dadosSituacaoFuncionamentoCliente[i];
    }

    public void setDadosSituacaoFuncionamentoCliente(int i, br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente _value) {
        this.dadosSituacaoFuncionamentoCliente[i] = _value;
    }


    /**
     * Gets the dataUltimaAlteracao value for this Cliente.
     * 
     * @return dataUltimaAlteracao
     */
    public java.util.Date getDataUltimaAlteracao() {
        return dataUltimaAlteracao;
    }


    /**
     * Sets the dataUltimaAlteracao value for this Cliente.
     * 
     * @param dataUltimaAlteracao
     */
    public void setDataUltimaAlteracao(java.util.Date dataUltimaAlteracao) {
        this.dataUltimaAlteracao = dataUltimaAlteracao;
    }


    /**
     * Gets the dadosContatoEnderecoCorrespondencia value for this Cliente.
     * 
     * @return dadosContatoEnderecoCorrespondencia
     */
    public br.com.cielo.canonico.cadastro.v1.Contato[] getDadosContatoEnderecoCorrespondencia() {
        return dadosContatoEnderecoCorrespondencia;
    }


    /**
     * Sets the dadosContatoEnderecoCorrespondencia value for this Cliente.
     * 
     * @param dadosContatoEnderecoCorrespondencia
     */
    public void setDadosContatoEnderecoCorrespondencia(br.com.cielo.canonico.cadastro.v1.Contato[] dadosContatoEnderecoCorrespondencia) {
        this.dadosContatoEnderecoCorrespondencia = dadosContatoEnderecoCorrespondencia;
    }

    public br.com.cielo.canonico.cadastro.v1.Contato getDadosContatoEnderecoCorrespondencia(int i) {
        return this.dadosContatoEnderecoCorrespondencia[i];
    }

    public void setDadosContatoEnderecoCorrespondencia(int i, br.com.cielo.canonico.cadastro.v1.Contato _value) {
        this.dadosContatoEnderecoCorrespondencia[i] = _value;
    }


    /**
     * Gets the indicadorPiloto value for this Cliente.
     * 
     * @return indicadorPiloto   * Informacao de negocios necessaria para identificar
     * 						se o cliente aceitou ser elegivel a ingressar em projetoas piloto.
     * 						Esta informacao e gerada atraves de contrato diretamente com
     * o
     * 						cliente, e por isso esta sendo adicionada ao canonico.
     */
    public java.lang.Boolean getIndicadorPiloto() {
        return indicadorPiloto;
    }


    /**
     * Sets the indicadorPiloto value for this Cliente.
     * 
     * @param indicadorPiloto   * Informacao de negocios necessaria para identificar
     * 						se o cliente aceitou ser elegivel a ingressar em projetoas piloto.
     * 						Esta informacao e gerada atraves de contrato diretamente com
     * o
     * 						cliente, e por isso esta sendo adicionada ao canonico.
     */
    public void setIndicadorPiloto(java.lang.Boolean indicadorPiloto) {
        this.indicadorPiloto = indicadorPiloto;
    }


    /**
     * Gets the dadosContatoAdicional value for this Cliente.
     * 
     * @return dadosContatoAdicional   * Informacoes do contato adicional do cliente.
     * 						Nao esta vinculado a nenhum dos contatos anteriormente adicionados,
     * 						podendo ser apenas um contato sem vinculo direto a um endereco.
     */
    public br.com.cielo.canonico.cadastro.v1.Contato getDadosContatoAdicional() {
        return dadosContatoAdicional;
    }


    /**
     * Sets the dadosContatoAdicional value for this Cliente.
     * 
     * @param dadosContatoAdicional   * Informacoes do contato adicional do cliente.
     * 						Nao esta vinculado a nenhum dos contatos anteriormente adicionados,
     * 						podendo ser apenas um contato sem vinculo direto a um endereco.
     */
    public void setDadosContatoAdicional(br.com.cielo.canonico.cadastro.v1.Contato dadosContatoAdicional) {
        this.dadosContatoAdicional = dadosContatoAdicional;
    }


    /**
     * Gets the dadosEnderecoContrato value for this Cliente.
     * 
     * @return dadosEnderecoContrato   * Informacaoes de endereco pertencentes ao contrato do
     * 						cliente.
     */
    public br.com.cielo.canonico.cadastro.v1.Endereco[] getDadosEnderecoContrato() {
        return dadosEnderecoContrato;
    }


    /**
     * Sets the dadosEnderecoContrato value for this Cliente.
     * 
     * @param dadosEnderecoContrato   * Informacaoes de endereco pertencentes ao contrato do
     * 						cliente.
     */
    public void setDadosEnderecoContrato(br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEnderecoContrato) {
        this.dadosEnderecoContrato = dadosEnderecoContrato;
    }

    public br.com.cielo.canonico.cadastro.v1.Endereco getDadosEnderecoContrato(int i) {
        return this.dadosEnderecoContrato[i];
    }

    public void setDadosEnderecoContrato(int i, br.com.cielo.canonico.cadastro.v1.Endereco _value) {
        this.dadosEnderecoContrato[i] = _value;
    }


    /**
     * Gets the dadosContatoContrato value for this Cliente.
     * 
     * @return dadosContatoContrato   * Informacoes de contato referenciadas no contrato
     */
    public br.com.cielo.canonico.cadastro.v1.Contato getDadosContatoContrato() {
        return dadosContatoContrato;
    }


    /**
     * Sets the dadosContatoContrato value for this Cliente.
     * 
     * @param dadosContatoContrato   * Informacoes de contato referenciadas no contrato
     */
    public void setDadosContatoContrato(br.com.cielo.canonico.cadastro.v1.Contato dadosContatoContrato) {
        this.dadosContatoContrato = dadosContatoContrato;
    }


    /**
     * Gets the nomeSituacaoAtividadeCliente value for this Cliente.
     * 
     * @return nomeSituacaoAtividadeCliente   * O nome da situação de atividade do cliente
     * 						identifica a situação atual do estabelecimento quanto a captura
     * de
     * 						transações na máquina da Cielo. Exemplos de situação: EC Ativo
     * (A)
     * 						EC Inativo até um ano (I) Inativo ha um ano ou mais (Y)
     */
    public java.lang.String getNomeSituacaoAtividadeCliente() {
        return nomeSituacaoAtividadeCliente;
    }


    /**
     * Sets the nomeSituacaoAtividadeCliente value for this Cliente.
     * 
     * @param nomeSituacaoAtividadeCliente   * O nome da situação de atividade do cliente
     * 						identifica a situação atual do estabelecimento quanto a captura
     * de
     * 						transações na máquina da Cielo. Exemplos de situação: EC Ativo
     * (A)
     * 						EC Inativo até um ano (I) Inativo ha um ano ou mais (Y)
     */
    public void setNomeSituacaoAtividadeCliente(java.lang.String nomeSituacaoAtividadeCliente) {
        this.nomeSituacaoAtividadeCliente = nomeSituacaoAtividadeCliente;
    }


    /**
     * Gets the indicadorTravaARV value for this Cliente.
     * 
     * @return indicadorTravaARV   * Indica se estabelecimento comercial possui permissao para aderir
     * produto ARV
     */
    public java.lang.Boolean getIndicadorTravaARV() {
        return indicadorTravaARV;
    }


    /**
     * Sets the indicadorTravaARV value for this Cliente.
     * 
     * @param indicadorTravaARV   * Indica se estabelecimento comercial possui permissao para aderir
     * produto ARV
     */
    public void setIndicadorTravaARV(java.lang.Boolean indicadorTravaARV) {
        this.indicadorTravaARV = indicadorTravaARV;
    }


    /**
     * Gets the dadosEnderecoSuprimento value for this Cliente.
     * 
     * @return dadosEnderecoSuprimento   * Endereco utilizado para entrega dos suprimentos ao cliente.
     */
    public br.com.cielo.canonico.cadastro.v1.Endereco getDadosEnderecoSuprimento() {
        return dadosEnderecoSuprimento;
    }


    /**
     * Sets the dadosEnderecoSuprimento value for this Cliente.
     * 
     * @param dadosEnderecoSuprimento   * Endereco utilizado para entrega dos suprimentos ao cliente.
     */
    public void setDadosEnderecoSuprimento(br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoSuprimento) {
        this.dadosEnderecoSuprimento = dadosEnderecoSuprimento;
    }


    /**
     * Gets the nomeTipoCadeia value for this Cliente.
     * 
     * @return nomeTipoCadeia   * identifica o tipo de cadeia quanto a centralização: CENTRALIZADA,
     * DESCENTRALIZADA ou INDIVIDUAL.
     */
    public java.lang.String getNomeTipoCadeia() {
        return nomeTipoCadeia;
    }


    /**
     * Sets the nomeTipoCadeia value for this Cliente.
     * 
     * @param nomeTipoCadeia   * identifica o tipo de cadeia quanto a centralização: CENTRALIZADA,
     * DESCENTRALIZADA ou INDIVIDUAL.
     */
    public void setNomeTipoCadeia(java.lang.String nomeTipoCadeia) {
        this.nomeTipoCadeia = nomeTipoCadeia;
    }


    /**
     * Gets the nomeSituacaoAtivacaoCliente value for this Cliente.
     * 
     * @return nomeSituacaoAtivacaoCliente   * Nome da situação de ativação do cliente durante o ciclo de
     * vida do cliente na Cielo, ou seja, reflete a situação do cliente desde
     * o início da afiliação até o encerramento do relacionamento com a Cielo.
     */
    public java.lang.String getNomeSituacaoAtivacaoCliente() {
        return nomeSituacaoAtivacaoCliente;
    }


    /**
     * Sets the nomeSituacaoAtivacaoCliente value for this Cliente.
     * 
     * @param nomeSituacaoAtivacaoCliente   * Nome da situação de ativação do cliente durante o ciclo de
     * vida do cliente na Cielo, ou seja, reflete a situação do cliente desde
     * o início da afiliação até o encerramento do relacionamento com a Cielo.
     */
    public void setNomeSituacaoAtivacaoCliente(java.lang.String nomeSituacaoAtivacaoCliente) {
        this.nomeSituacaoAtivacaoCliente = nomeSituacaoAtivacaoCliente;
    }


    /**
     * Gets the dadosContatoSMSCliente value for this Cliente.
     * 
     * @return dadosContatoSMSCliente   * Dados de contato do cliente para envio de SMS.
     */
    public br.com.cielo.canonico.cadastro.v1.Contato getDadosContatoSMSCliente() {
        return dadosContatoSMSCliente;
    }


    /**
     * Sets the dadosContatoSMSCliente value for this Cliente.
     * 
     * @param dadosContatoSMSCliente   * Dados de contato do cliente para envio de SMS.
     */
    public void setDadosContatoSMSCliente(br.com.cielo.canonico.cadastro.v1.Contato dadosContatoSMSCliente) {
        this.dadosContatoSMSCliente = dadosContatoSMSCliente;
    }


    /**
     * Gets the codigoStatusCobanCaptura value for this Cliente.
     * 
     * @return codigoStatusCobanCaptura   * Codigo que identifica a situacao do EC para operar como Correspondente
     * Bancario (COBAN).
     */
    public java.lang.String getCodigoStatusCobanCaptura() {
        return codigoStatusCobanCaptura;
    }


    /**
     * Sets the codigoStatusCobanCaptura value for this Cliente.
     * 
     * @param codigoStatusCobanCaptura   * Codigo que identifica a situacao do EC para operar como Correspondente
     * Bancario (COBAN).
     */
    public void setCodigoStatusCobanCaptura(java.lang.String codigoStatusCobanCaptura) {
        this.codigoStatusCobanCaptura = codigoStatusCobanCaptura;
    }


    /**
     * Gets the descricaoStatusCobanCaptura value for this Cliente.
     * 
     * @return descricaoStatusCobanCaptura   * Descricao do codigo que identifica a situacao do EC para operar
     * como Correspondente Bancario (COBAN).
     */
    public java.lang.String getDescricaoStatusCobanCaptura() {
        return descricaoStatusCobanCaptura;
    }


    /**
     * Sets the descricaoStatusCobanCaptura value for this Cliente.
     * 
     * @param descricaoStatusCobanCaptura   * Descricao do codigo que identifica a situacao do EC para operar
     * como Correspondente Bancario (COBAN).
     */
    public void setDescricaoStatusCobanCaptura(java.lang.String descricaoStatusCobanCaptura) {
        this.descricaoStatusCobanCaptura = descricaoStatusCobanCaptura;
    }


    /**
     * Gets the codigoPagamentoRecorrente value for this Cliente.
     * 
     * @return codigoPagamentoRecorrente   * Identifica a opcao de pagamento recorrente que o o cliente
     * (EC) esta habilitado.
     */
    public java.lang.String getCodigoPagamentoRecorrente() {
        return codigoPagamentoRecorrente;
    }


    /**
     * Sets the codigoPagamentoRecorrente value for this Cliente.
     * 
     * @param codigoPagamentoRecorrente   * Identifica a opcao de pagamento recorrente que o o cliente
     * (EC) esta habilitado.
     */
    public void setCodigoPagamentoRecorrente(java.lang.String codigoPagamentoRecorrente) {
        this.codigoPagamentoRecorrente = codigoPagamentoRecorrente;
    }


    /**
     * Gets the descricaoPagamentoRecorrente value for this Cliente.
     * 
     * @return descricaoPagamentoRecorrente   * Descricao da opcao de pagamento recorrente que o o cliente
     * (EC) esta habilitado.
     */
    public java.lang.String getDescricaoPagamentoRecorrente() {
        return descricaoPagamentoRecorrente;
    }


    /**
     * Sets the descricaoPagamentoRecorrente value for this Cliente.
     * 
     * @param descricaoPagamentoRecorrente   * Descricao da opcao de pagamento recorrente que o o cliente
     * (EC) esta habilitado.
     */
    public void setDescricaoPagamentoRecorrente(java.lang.String descricaoPagamentoRecorrente) {
        this.descricaoPagamentoRecorrente = descricaoPagamentoRecorrente;
    }


    /**
     * Gets the codigoBancoCoban value for this Cliente.
     * 
     * @return codigoBancoCoban   * Codigo do Banco no qual o EC atua como Coban.
     */
    public java.lang.String getCodigoBancoCoban() {
        return codigoBancoCoban;
    }


    /**
     * Sets the codigoBancoCoban value for this Cliente.
     * 
     * @param codigoBancoCoban   * Codigo do Banco no qual o EC atua como Coban.
     */
    public void setCodigoBancoCoban(java.lang.String codigoBancoCoban) {
        this.codigoBancoCoban = codigoBancoCoban;
    }


    /**
     * Gets the nomeBancoCoban value for this Cliente.
     * 
     * @return nomeBancoCoban   * Nome do Banco no qual o EC atua como Coban.
     */
    public java.lang.String getNomeBancoCoban() {
        return nomeBancoCoban;
    }


    /**
     * Sets the nomeBancoCoban value for this Cliente.
     * 
     * @param nomeBancoCoban   * Nome do Banco no qual o EC atua como Coban.
     */
    public void setNomeBancoCoban(java.lang.String nomeBancoCoban) {
        this.nomeBancoCoban = nomeBancoCoban;
    }


    /**
     * Gets the indicadorBloqueioPagamento value for this Cliente.
     * 
     * @return indicadorBloqueioPagamento   * Indicador de bloqueio de pagamento (Sim ou nao)
     */
    public java.lang.Boolean getIndicadorBloqueioPagamento() {
        return indicadorBloqueioPagamento;
    }


    /**
     * Sets the indicadorBloqueioPagamento value for this Cliente.
     * 
     * @param indicadorBloqueioPagamento   * Indicador de bloqueio de pagamento (Sim ou nao)
     */
    public void setIndicadorBloqueioPagamento(java.lang.Boolean indicadorBloqueioPagamento) {
        this.indicadorBloqueioPagamento = indicadorBloqueioPagamento;
    }


    /**
     * Gets the motivoRetornoCodigo value for this Cliente.
     * 
     * @return motivoRetornoCodigo   * Codigo que indica os tipos de bloqueio de pagamento
     */
    public java.math.BigInteger getMotivoRetornoCodigo() {
        return motivoRetornoCodigo;
    }


    /**
     * Sets the motivoRetornoCodigo value for this Cliente.
     * 
     * @param motivoRetornoCodigo   * Codigo que indica os tipos de bloqueio de pagamento
     */
    public void setMotivoRetornoCodigo(java.math.BigInteger motivoRetornoCodigo) {
        this.motivoRetornoCodigo = motivoRetornoCodigo;
    }


    /**
     * Gets the motivoRetornoDescricao value for this Cliente.
     * 
     * @return motivoRetornoDescricao   * Descricao do motivo de bloqueio de pagamento  
     * Ex: Valores em aberto
     */
    public java.lang.String getMotivoRetornoDescricao() {
        return motivoRetornoDescricao;
    }


    /**
     * Sets the motivoRetornoDescricao value for this Cliente.
     * 
     * @param motivoRetornoDescricao   * Descricao do motivo de bloqueio de pagamento  
     * Ex: Valores em aberto
     */
    public void setMotivoRetornoDescricao(java.lang.String motivoRetornoDescricao) {
        this.motivoRetornoDescricao = motivoRetornoDescricao;
    }


    /**
     * Gets the dadosEnderecoPontoVenda value for this Cliente.
     * 
     * @return dadosEnderecoPontoVenda   * Endereco Ponto de Venda
     */
    public br.com.cielo.canonico.cadastro.v1.Endereco getDadosEnderecoPontoVenda() {
        return dadosEnderecoPontoVenda;
    }


    /**
     * Sets the dadosEnderecoPontoVenda value for this Cliente.
     * 
     * @param dadosEnderecoPontoVenda   * Endereco Ponto de Venda
     */
    public void setDadosEnderecoPontoVenda(br.com.cielo.canonico.cadastro.v1.Endereco dadosEnderecoPontoVenda) {
        this.dadosEnderecoPontoVenda = dadosEnderecoPontoVenda;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Cliente)) return false;
        Cliente other = (Cliente) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.numeroInscricaoEstadual==null && other.getNumeroInscricaoEstadual()==null) || 
             (this.numeroInscricaoEstadual!=null &&
              this.numeroInscricaoEstadual.equals(other.getNumeroInscricaoEstadual()))) &&
            ((this.dataAberturaCliente==null && other.getDataAberturaCliente()==null) || 
             (this.dataAberturaCliente!=null &&
              this.dataAberturaCliente.equals(other.getDataAberturaCliente()))) &&
            ((this.codigoCadeia==null && other.getCodigoCadeia()==null) || 
             (this.codigoCadeia!=null &&
              this.codigoCadeia.equals(other.getCodigoCadeia()))) &&
            ((this.descricaoPOS==null && other.getDescricaoPOS()==null) || 
             (this.descricaoPOS!=null &&
              this.descricaoPOS.equals(other.getDescricaoPOS()))) &&
            ((this.indicadorCessao==null && other.getIndicadorCessao()==null) || 
             (this.indicadorCessao!=null &&
              this.indicadorCessao.equals(other.getIndicadorCessao()))) &&
            ((this.descricaoComplementoRamoAtividade==null && other.getDescricaoComplementoRamoAtividade()==null) || 
             (this.descricaoComplementoRamoAtividade!=null &&
              this.descricaoComplementoRamoAtividade.equals(other.getDescricaoComplementoRamoAtividade()))) &&
            ((this.indicadorCartaCircularizacao==null && other.getIndicadorCartaCircularizacao()==null) || 
             (this.indicadorCartaCircularizacao!=null &&
              this.indicadorCartaCircularizacao.equals(other.getIndicadorCartaCircularizacao()))) &&
            ((this.indicadorAntecipacaoAutomatica==null && other.getIndicadorAntecipacaoAutomatica()==null) || 
             (this.indicadorAntecipacaoAutomatica!=null &&
              this.indicadorAntecipacaoAutomatica.equals(other.getIndicadorAntecipacaoAutomatica()))) &&
            ((this.nomeEnderecoSite==null && other.getNomeEnderecoSite()==null) || 
             (this.nomeEnderecoSite!=null &&
              this.nomeEnderecoSite.equals(other.getNomeEnderecoSite()))) &&
            ((this.indicadorAntecipacaoSecuritizacao==null && other.getIndicadorAntecipacaoSecuritizacao()==null) || 
             (this.indicadorAntecipacaoSecuritizacao!=null &&
              this.indicadorAntecipacaoSecuritizacao.equals(other.getIndicadorAntecipacaoSecuritizacao()))) &&
            ((this.dadosProprietarioCliente==null && other.getDadosProprietarioCliente()==null) || 
             (this.dadosProprietarioCliente!=null &&
              java.util.Arrays.equals(this.dadosProprietarioCliente, other.getDadosProprietarioCliente()))) &&
            ((this.nomeCliente==null && other.getNomeCliente()==null) || 
             (this.nomeCliente!=null &&
              this.nomeCliente.equals(other.getNomeCliente()))) &&
            ((this.dadosProdutoCliente==null && other.getDadosProdutoCliente()==null) || 
             (this.dadosProdutoCliente!=null &&
              java.util.Arrays.equals(this.dadosProdutoCliente, other.getDadosProdutoCliente()))) &&
            ((this.codigoTipoGarantia==null && other.getCodigoTipoGarantia()==null) || 
             (this.codigoTipoGarantia!=null &&
              this.codigoTipoGarantia.equals(other.getCodigoTipoGarantia()))) &&
            ((this.nomeFantasia==null && other.getNomeFantasia()==null) || 
             (this.nomeFantasia!=null &&
              this.nomeFantasia.equals(other.getNomeFantasia()))) &&
            ((this.dadosContatoCliente==null && other.getDadosContatoCliente()==null) || 
             (this.dadosContatoCliente!=null &&
              this.dadosContatoCliente.equals(other.getDadosContatoCliente()))) &&
            ((this.indicadorEcommerce==null && other.getIndicadorEcommerce()==null) || 
             (this.indicadorEcommerce!=null &&
              this.indicadorEcommerce.equals(other.getIndicadorEcommerce()))) &&
            ((this.codigoMoeda==null && other.getCodigoMoeda()==null) || 
             (this.codigoMoeda!=null &&
              java.util.Arrays.equals(this.codigoMoeda, other.getCodigoMoeda()))) &&
            ((this.indicadorMultiBandeira==null && other.getIndicadorMultiBandeira()==null) || 
             (this.indicadorMultiBandeira!=null &&
              this.indicadorMultiBandeira.equals(other.getIndicadorMultiBandeira()))) &&
            ((this.codigoPCT==null && other.getCodigoPCT()==null) || 
             (this.codigoPCT!=null &&
              this.codigoPCT.equals(other.getCodigoPCT()))) &&
            ((this.indicadorSecuratizacao==null && other.getIndicadorSecuratizacao()==null) || 
             (this.indicadorSecuratizacao!=null &&
              this.indicadorSecuratizacao.equals(other.getIndicadorSecuratizacao()))) &&
            ((this.indicadorTrava==null && other.getIndicadorTrava()==null) || 
             (this.indicadorTrava!=null &&
              this.indicadorTrava.equals(other.getIndicadorTrava()))) &&
            ((this.indicadorMoto==null && other.getIndicadorMoto()==null) || 
             (this.indicadorMoto!=null &&
              this.indicadorMoto.equals(other.getIndicadorMoto()))) &&
            ((this.dadosBancarioCliente==null && other.getDadosBancarioCliente()==null) || 
             (this.dadosBancarioCliente!=null &&
              java.util.Arrays.equals(this.dadosBancarioCliente, other.getDadosBancarioCliente()))) &&
            ((this.dadosProprietarioMobile==null && other.getDadosProprietarioMobile()==null) || 
             (this.dadosProprietarioMobile!=null &&
              this.dadosProprietarioMobile.equals(other.getDadosProprietarioMobile()))) &&
            ((this.percentualAntecipacao==null && other.getPercentualAntecipacao()==null) || 
             (this.percentualAntecipacao!=null &&
              this.percentualAntecipacao.equals(other.getPercentualAntecipacao()))) &&
            ((this.descricaoLimite==null && other.getDescricaoLimite()==null) || 
             (this.descricaoLimite!=null &&
              this.descricaoLimite.equals(other.getDescricaoLimite()))) &&
            ((this.indicadorVisaVale==null && other.getIndicadorVisaVale()==null) || 
             (this.indicadorVisaVale!=null &&
              this.indicadorVisaVale.equals(other.getIndicadorVisaVale()))) &&
            ((this.indicadorJuridico==null && other.getIndicadorJuridico()==null) || 
             (this.indicadorJuridico!=null &&
              this.indicadorJuridico.equals(other.getIndicadorJuridico()))) &&
            ((this.valorTarifaAgendamento==null && other.getValorTarifaAgendamento()==null) || 
             (this.valorTarifaAgendamento!=null &&
              this.valorTarifaAgendamento.equals(other.getValorTarifaAgendamento()))) &&
            ((this.quantidadePOS==null && other.getQuantidadePOS()==null) || 
             (this.quantidadePOS!=null &&
              this.quantidadePOS.equals(other.getQuantidadePOS()))) &&
            ((this.indicadorSaldoConsolidado==null && other.getIndicadorSaldoConsolidado()==null) || 
             (this.indicadorSaldoConsolidado!=null &&
              this.indicadorSaldoConsolidado.equals(other.getIndicadorSaldoConsolidado()))) &&
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade()))) &&
            ((this.codigoBandeira==null && other.getCodigoBandeira()==null) || 
             (this.codigoBandeira!=null &&
              this.codigoBandeira.equals(other.getCodigoBandeira()))) &&
            ((this.codigoSegmento==null && other.getCodigoSegmento()==null) || 
             (this.codigoSegmento!=null &&
              this.codigoSegmento.equals(other.getCodigoSegmento()))) &&
            ((this.codigoECAssociada==null && other.getCodigoECAssociada()==null) || 
             (this.codigoECAssociada!=null &&
              this.codigoECAssociada.equals(other.getCodigoECAssociada()))) &&
            ((this.nomeRazaoSocial==null && other.getNomeRazaoSocial()==null) || 
             (this.nomeRazaoSocial!=null &&
              this.nomeRazaoSocial.equals(other.getNomeRazaoSocial()))) &&
            ((this.numeroCNPJ==null && other.getNumeroCNPJ()==null) || 
             (this.numeroCNPJ!=null &&
              this.numeroCNPJ.equals(other.getNumeroCNPJ()))) &&
            ((this.indicadorCadeia==null && other.getIndicadorCadeia()==null) || 
             (this.indicadorCadeia!=null &&
              this.indicadorCadeia.equals(other.getIndicadorCadeia()))) &&
            ((this.indicadorTransmissao==null && other.getIndicadorTransmissao()==null) || 
             (this.indicadorTransmissao!=null &&
              this.indicadorTransmissao.equals(other.getIndicadorTransmissao()))) &&
            ((this.codigoTipoPagamento==null && other.getCodigoTipoPagamento()==null) || 
             (this.codigoTipoPagamento!=null &&
              this.codigoTipoPagamento.equals(other.getCodigoTipoPagamento()))) &&
            ((this.dadosEnderecoFisicoCliente==null && other.getDadosEnderecoFisicoCliente()==null) || 
             (this.dadosEnderecoFisicoCliente!=null &&
              this.dadosEnderecoFisicoCliente.equals(other.getDadosEnderecoFisicoCliente()))) &&
            ((this.descricaoRamoAtividade==null && other.getDescricaoRamoAtividade()==null) || 
             (this.descricaoRamoAtividade!=null &&
              this.descricaoRamoAtividade.equals(other.getDescricaoRamoAtividade()))) &&
            ((this.indicadorRecebimentoSMS==null && other.getIndicadorRecebimentoSMS()==null) || 
             (this.indicadorRecebimentoSMS!=null &&
              this.indicadorRecebimentoSMS.equals(other.getIndicadorRecebimentoSMS()))) &&
            ((this.dadosEnderecoCorrespondenciaCliente==null && other.getDadosEnderecoCorrespondenciaCliente()==null) || 
             (this.dadosEnderecoCorrespondenciaCliente!=null &&
              java.util.Arrays.equals(this.dadosEnderecoCorrespondenciaCliente, other.getDadosEnderecoCorrespondenciaCliente()))) &&
            ((this.codigoCategoriaAntecipacao==null && other.getCodigoCategoriaAntecipacao()==null) || 
             (this.codigoCategoriaAntecipacao!=null &&
              this.codigoCategoriaAntecipacao.equals(other.getCodigoCategoriaAntecipacao()))) &&
            ((this.codigoAluguelPOS==null && other.getCodigoAluguelPOS()==null) || 
             (this.codigoAluguelPOS!=null &&
              this.codigoAluguelPOS.equals(other.getCodigoAluguelPOS()))) &&
            ((this.codigoPeriodicidadeAntecipacaoAutomatica==null && other.getCodigoPeriodicidadeAntecipacaoAutomatica()==null) || 
             (this.codigoPeriodicidadeAntecipacaoAutomatica!=null &&
              this.codigoPeriodicidadeAntecipacaoAutomatica.equals(other.getCodigoPeriodicidadeAntecipacaoAutomatica()))) &&
            ((this.codigoECPrincipal==null && other.getCodigoECPrincipal()==null) || 
             (this.codigoECPrincipal!=null &&
              this.codigoECPrincipal.equals(other.getCodigoECPrincipal()))) &&
            ((this.indicadorParcelado==null && other.getIndicadorParcelado()==null) || 
             (this.indicadorParcelado!=null &&
              this.indicadorParcelado.equals(other.getIndicadorParcelado()))) &&
            ((this.indicadorMobile==null && other.getIndicadorMobile()==null) || 
             (this.indicadorMobile!=null &&
              this.indicadorMobile.equals(other.getIndicadorMobile()))) &&
            ((this.numeroCPF==null && other.getNumeroCPF()==null) || 
             (this.numeroCPF!=null &&
              this.numeroCPF.equals(other.getNumeroCPF()))) &&
            ((this.codigoTipoPessoa==null && other.getCodigoTipoPessoa()==null) || 
             (this.codigoTipoPessoa!=null &&
              this.codigoTipoPessoa.equals(other.getCodigoTipoPessoa()))) &&
            ((this.codigoClasseFaturamento==null && other.getCodigoClasseFaturamento()==null) || 
             (this.codigoClasseFaturamento!=null &&
              this.codigoClasseFaturamento.equals(other.getCodigoClasseFaturamento()))) &&
            ((this.codigoClienteAMEX==null && other.getCodigoClienteAMEX()==null) || 
             (this.codigoClienteAMEX!=null &&
              this.codigoClienteAMEX.equals(other.getCodigoClienteAMEX()))) &&
            ((this.dadosSituacaoFuncionamentoCliente==null && other.getDadosSituacaoFuncionamentoCliente()==null) || 
             (this.dadosSituacaoFuncionamentoCliente!=null &&
              java.util.Arrays.equals(this.dadosSituacaoFuncionamentoCliente, other.getDadosSituacaoFuncionamentoCliente()))) &&
            ((this.dataUltimaAlteracao==null && other.getDataUltimaAlteracao()==null) || 
             (this.dataUltimaAlteracao!=null &&
              this.dataUltimaAlteracao.equals(other.getDataUltimaAlteracao()))) &&
            ((this.dadosContatoEnderecoCorrespondencia==null && other.getDadosContatoEnderecoCorrespondencia()==null) || 
             (this.dadosContatoEnderecoCorrespondencia!=null &&
              java.util.Arrays.equals(this.dadosContatoEnderecoCorrespondencia, other.getDadosContatoEnderecoCorrespondencia()))) &&
            ((this.indicadorPiloto==null && other.getIndicadorPiloto()==null) || 
             (this.indicadorPiloto!=null &&
              this.indicadorPiloto.equals(other.getIndicadorPiloto()))) &&
            ((this.dadosContatoAdicional==null && other.getDadosContatoAdicional()==null) || 
             (this.dadosContatoAdicional!=null &&
              this.dadosContatoAdicional.equals(other.getDadosContatoAdicional()))) &&
            ((this.dadosEnderecoContrato==null && other.getDadosEnderecoContrato()==null) || 
             (this.dadosEnderecoContrato!=null &&
              java.util.Arrays.equals(this.dadosEnderecoContrato, other.getDadosEnderecoContrato()))) &&
            ((this.dadosContatoContrato==null && other.getDadosContatoContrato()==null) || 
             (this.dadosContatoContrato!=null &&
              this.dadosContatoContrato.equals(other.getDadosContatoContrato()))) &&
            ((this.nomeSituacaoAtividadeCliente==null && other.getNomeSituacaoAtividadeCliente()==null) || 
             (this.nomeSituacaoAtividadeCliente!=null &&
              this.nomeSituacaoAtividadeCliente.equals(other.getNomeSituacaoAtividadeCliente()))) &&
            ((this.indicadorTravaARV==null && other.getIndicadorTravaARV()==null) || 
             (this.indicadorTravaARV!=null &&
              this.indicadorTravaARV.equals(other.getIndicadorTravaARV()))) &&
            ((this.dadosEnderecoSuprimento==null && other.getDadosEnderecoSuprimento()==null) || 
             (this.dadosEnderecoSuprimento!=null &&
              this.dadosEnderecoSuprimento.equals(other.getDadosEnderecoSuprimento()))) &&
            ((this.nomeTipoCadeia==null && other.getNomeTipoCadeia()==null) || 
             (this.nomeTipoCadeia!=null &&
              this.nomeTipoCadeia.equals(other.getNomeTipoCadeia()))) &&
            ((this.nomeSituacaoAtivacaoCliente==null && other.getNomeSituacaoAtivacaoCliente()==null) || 
             (this.nomeSituacaoAtivacaoCliente!=null &&
              this.nomeSituacaoAtivacaoCliente.equals(other.getNomeSituacaoAtivacaoCliente()))) &&
            ((this.dadosContatoSMSCliente==null && other.getDadosContatoSMSCliente()==null) || 
             (this.dadosContatoSMSCliente!=null &&
              this.dadosContatoSMSCliente.equals(other.getDadosContatoSMSCliente()))) &&
            ((this.codigoStatusCobanCaptura==null && other.getCodigoStatusCobanCaptura()==null) || 
             (this.codigoStatusCobanCaptura!=null &&
              this.codigoStatusCobanCaptura.equals(other.getCodigoStatusCobanCaptura()))) &&
            ((this.descricaoStatusCobanCaptura==null && other.getDescricaoStatusCobanCaptura()==null) || 
             (this.descricaoStatusCobanCaptura!=null &&
              this.descricaoStatusCobanCaptura.equals(other.getDescricaoStatusCobanCaptura()))) &&
            ((this.codigoPagamentoRecorrente==null && other.getCodigoPagamentoRecorrente()==null) || 
             (this.codigoPagamentoRecorrente!=null &&
              this.codigoPagamentoRecorrente.equals(other.getCodigoPagamentoRecorrente()))) &&
            ((this.descricaoPagamentoRecorrente==null && other.getDescricaoPagamentoRecorrente()==null) || 
             (this.descricaoPagamentoRecorrente!=null &&
              this.descricaoPagamentoRecorrente.equals(other.getDescricaoPagamentoRecorrente()))) &&
            ((this.codigoBancoCoban==null && other.getCodigoBancoCoban()==null) || 
             (this.codigoBancoCoban!=null &&
              this.codigoBancoCoban.equals(other.getCodigoBancoCoban()))) &&
            ((this.nomeBancoCoban==null && other.getNomeBancoCoban()==null) || 
             (this.nomeBancoCoban!=null &&
              this.nomeBancoCoban.equals(other.getNomeBancoCoban()))) &&
            ((this.indicadorBloqueioPagamento==null && other.getIndicadorBloqueioPagamento()==null) || 
             (this.indicadorBloqueioPagamento!=null &&
              this.indicadorBloqueioPagamento.equals(other.getIndicadorBloqueioPagamento()))) &&
            ((this.motivoRetornoCodigo==null && other.getMotivoRetornoCodigo()==null) || 
             (this.motivoRetornoCodigo!=null &&
              this.motivoRetornoCodigo.equals(other.getMotivoRetornoCodigo()))) &&
            ((this.motivoRetornoDescricao==null && other.getMotivoRetornoDescricao()==null) || 
             (this.motivoRetornoDescricao!=null &&
              this.motivoRetornoDescricao.equals(other.getMotivoRetornoDescricao()))) &&
            ((this.dadosEnderecoPontoVenda==null && other.getDadosEnderecoPontoVenda()==null) || 
             (this.dadosEnderecoPontoVenda!=null &&
              this.dadosEnderecoPontoVenda.equals(other.getDadosEnderecoPontoVenda())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getNumeroInscricaoEstadual() != null) {
            _hashCode += getNumeroInscricaoEstadual().hashCode();
        }
        if (getDataAberturaCliente() != null) {
            _hashCode += getDataAberturaCliente().hashCode();
        }
        if (getCodigoCadeia() != null) {
            _hashCode += getCodigoCadeia().hashCode();
        }
        if (getDescricaoPOS() != null) {
            _hashCode += getDescricaoPOS().hashCode();
        }
        if (getIndicadorCessao() != null) {
            _hashCode += getIndicadorCessao().hashCode();
        }
        if (getDescricaoComplementoRamoAtividade() != null) {
            _hashCode += getDescricaoComplementoRamoAtividade().hashCode();
        }
        if (getIndicadorCartaCircularizacao() != null) {
            _hashCode += getIndicadorCartaCircularizacao().hashCode();
        }
        if (getIndicadorAntecipacaoAutomatica() != null) {
            _hashCode += getIndicadorAntecipacaoAutomatica().hashCode();
        }
        if (getNomeEnderecoSite() != null) {
            _hashCode += getNomeEnderecoSite().hashCode();
        }
        if (getIndicadorAntecipacaoSecuritizacao() != null) {
            _hashCode += getIndicadorAntecipacaoSecuritizacao().hashCode();
        }
        if (getDadosProprietarioCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosProprietarioCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosProprietarioCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNomeCliente() != null) {
            _hashCode += getNomeCliente().hashCode();
        }
        if (getDadosProdutoCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosProdutoCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosProdutoCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodigoTipoGarantia() != null) {
            _hashCode += getCodigoTipoGarantia().hashCode();
        }
        if (getNomeFantasia() != null) {
            _hashCode += getNomeFantasia().hashCode();
        }
        if (getDadosContatoCliente() != null) {
            _hashCode += getDadosContatoCliente().hashCode();
        }
        if (getIndicadorEcommerce() != null) {
            _hashCode += getIndicadorEcommerce().hashCode();
        }
        if (getCodigoMoeda() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCodigoMoeda());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCodigoMoeda(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndicadorMultiBandeira() != null) {
            _hashCode += getIndicadorMultiBandeira().hashCode();
        }
        if (getCodigoPCT() != null) {
            _hashCode += getCodigoPCT().hashCode();
        }
        if (getIndicadorSecuratizacao() != null) {
            _hashCode += getIndicadorSecuratizacao().hashCode();
        }
        if (getIndicadorTrava() != null) {
            _hashCode += getIndicadorTrava().hashCode();
        }
        if (getIndicadorMoto() != null) {
            _hashCode += getIndicadorMoto().hashCode();
        }
        if (getDadosBancarioCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosBancarioCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosBancarioCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDadosProprietarioMobile() != null) {
            _hashCode += getDadosProprietarioMobile().hashCode();
        }
        if (getPercentualAntecipacao() != null) {
            _hashCode += getPercentualAntecipacao().hashCode();
        }
        if (getDescricaoLimite() != null) {
            _hashCode += getDescricaoLimite().hashCode();
        }
        if (getIndicadorVisaVale() != null) {
            _hashCode += getIndicadorVisaVale().hashCode();
        }
        if (getIndicadorJuridico() != null) {
            _hashCode += getIndicadorJuridico().hashCode();
        }
        if (getValorTarifaAgendamento() != null) {
            _hashCode += getValorTarifaAgendamento().hashCode();
        }
        if (getQuantidadePOS() != null) {
            _hashCode += getQuantidadePOS().hashCode();
        }
        if (getIndicadorSaldoConsolidado() != null) {
            _hashCode += getIndicadorSaldoConsolidado().hashCode();
        }
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        if (getCodigoBandeira() != null) {
            _hashCode += getCodigoBandeira().hashCode();
        }
        if (getCodigoSegmento() != null) {
            _hashCode += getCodigoSegmento().hashCode();
        }
        if (getCodigoECAssociada() != null) {
            _hashCode += getCodigoECAssociada().hashCode();
        }
        if (getNomeRazaoSocial() != null) {
            _hashCode += getNomeRazaoSocial().hashCode();
        }
        if (getNumeroCNPJ() != null) {
            _hashCode += getNumeroCNPJ().hashCode();
        }
        if (getIndicadorCadeia() != null) {
            _hashCode += getIndicadorCadeia().hashCode();
        }
        if (getIndicadorTransmissao() != null) {
            _hashCode += getIndicadorTransmissao().hashCode();
        }
        if (getCodigoTipoPagamento() != null) {
            _hashCode += getCodigoTipoPagamento().hashCode();
        }
        if (getDadosEnderecoFisicoCliente() != null) {
            _hashCode += getDadosEnderecoFisicoCliente().hashCode();
        }
        if (getDescricaoRamoAtividade() != null) {
            _hashCode += getDescricaoRamoAtividade().hashCode();
        }
        if (getIndicadorRecebimentoSMS() != null) {
            _hashCode += getIndicadorRecebimentoSMS().hashCode();
        }
        if (getDadosEnderecoCorrespondenciaCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosEnderecoCorrespondenciaCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosEnderecoCorrespondenciaCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodigoCategoriaAntecipacao() != null) {
            _hashCode += getCodigoCategoriaAntecipacao().hashCode();
        }
        if (getCodigoAluguelPOS() != null) {
            _hashCode += getCodigoAluguelPOS().hashCode();
        }
        if (getCodigoPeriodicidadeAntecipacaoAutomatica() != null) {
            _hashCode += getCodigoPeriodicidadeAntecipacaoAutomatica().hashCode();
        }
        if (getCodigoECPrincipal() != null) {
            _hashCode += getCodigoECPrincipal().hashCode();
        }
        if (getIndicadorParcelado() != null) {
            _hashCode += getIndicadorParcelado().hashCode();
        }
        if (getIndicadorMobile() != null) {
            _hashCode += getIndicadorMobile().hashCode();
        }
        if (getNumeroCPF() != null) {
            _hashCode += getNumeroCPF().hashCode();
        }
        if (getCodigoTipoPessoa() != null) {
            _hashCode += getCodigoTipoPessoa().hashCode();
        }
        if (getCodigoClasseFaturamento() != null) {
            _hashCode += getCodigoClasseFaturamento().hashCode();
        }
        if (getCodigoClienteAMEX() != null) {
            _hashCode += getCodigoClienteAMEX().hashCode();
        }
        if (getDadosSituacaoFuncionamentoCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosSituacaoFuncionamentoCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosSituacaoFuncionamentoCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDataUltimaAlteracao() != null) {
            _hashCode += getDataUltimaAlteracao().hashCode();
        }
        if (getDadosContatoEnderecoCorrespondencia() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosContatoEnderecoCorrespondencia());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosContatoEnderecoCorrespondencia(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndicadorPiloto() != null) {
            _hashCode += getIndicadorPiloto().hashCode();
        }
        if (getDadosContatoAdicional() != null) {
            _hashCode += getDadosContatoAdicional().hashCode();
        }
        if (getDadosEnderecoContrato() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosEnderecoContrato());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosEnderecoContrato(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDadosContatoContrato() != null) {
            _hashCode += getDadosContatoContrato().hashCode();
        }
        if (getNomeSituacaoAtividadeCliente() != null) {
            _hashCode += getNomeSituacaoAtividadeCliente().hashCode();
        }
        if (getIndicadorTravaARV() != null) {
            _hashCode += getIndicadorTravaARV().hashCode();
        }
        if (getDadosEnderecoSuprimento() != null) {
            _hashCode += getDadosEnderecoSuprimento().hashCode();
        }
        if (getNomeTipoCadeia() != null) {
            _hashCode += getNomeTipoCadeia().hashCode();
        }
        if (getNomeSituacaoAtivacaoCliente() != null) {
            _hashCode += getNomeSituacaoAtivacaoCliente().hashCode();
        }
        if (getDadosContatoSMSCliente() != null) {
            _hashCode += getDadosContatoSMSCliente().hashCode();
        }
        if (getCodigoStatusCobanCaptura() != null) {
            _hashCode += getCodigoStatusCobanCaptura().hashCode();
        }
        if (getDescricaoStatusCobanCaptura() != null) {
            _hashCode += getDescricaoStatusCobanCaptura().hashCode();
        }
        if (getCodigoPagamentoRecorrente() != null) {
            _hashCode += getCodigoPagamentoRecorrente().hashCode();
        }
        if (getDescricaoPagamentoRecorrente() != null) {
            _hashCode += getDescricaoPagamentoRecorrente().hashCode();
        }
        if (getCodigoBancoCoban() != null) {
            _hashCode += getCodigoBancoCoban().hashCode();
        }
        if (getNomeBancoCoban() != null) {
            _hashCode += getNomeBancoCoban().hashCode();
        }
        if (getIndicadorBloqueioPagamento() != null) {
            _hashCode += getIndicadorBloqueioPagamento().hashCode();
        }
        if (getMotivoRetornoCodigo() != null) {
            _hashCode += getMotivoRetornoCodigo().hashCode();
        }
        if (getMotivoRetornoDescricao() != null) {
            _hashCode += getMotivoRetornoDescricao().hashCode();
        }
        if (getDadosEnderecoPontoVenda() != null) {
            _hashCode += getDadosEnderecoPontoVenda().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Cliente.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Cliente"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroInscricaoEstadual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroInscricaoEstadual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataAberturaCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataAberturaCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCadeia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCadeia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoPOS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoPOS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorCessao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorCessao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoComplementoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoComplementoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorCartaCircularizacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorCartaCircularizacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAntecipacaoAutomatica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorAntecipacaoAutomatica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEnderecoSite");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeEnderecoSite"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAntecipacaoSecuritizacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorAntecipacaoSecuritizacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosProprietarioCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosProprietarioCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Proprietario"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosProdutoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosProdutoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produtos"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoGarantia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoTipoGarantia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFantasia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeFantasia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorEcommerce");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorEcommerce"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoMoeda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoMoeda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Codigo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMultiBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorMultiBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoPCT");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoPCT"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorSecuratizacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorSecuratizacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorTrava");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorTrava"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMoto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorMoto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosBancarioCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosBancarioCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DadosBancarios"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosProprietarioMobile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosProprietarioMobile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Proprietario"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualAntecipacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualAntecipacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoLimite");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoLimite"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVisaVale");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorVisaVale"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorJuridico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorJuridico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorTarifaAgendamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "valorTarifaAgendamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadePOS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadePOS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorSaldoConsolidado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorSaldoConsolidado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSegmento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoSegmento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoECAssociada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoECAssociada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeRazaoSocial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeRazaoSocial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCNPJ");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroCNPJ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorCadeia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorCadeia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorTransmissao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorTransmissao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoTipoPagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEnderecoFisicoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosEnderecoFisicoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorRecebimentoSMS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorRecebimentoSMS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEnderecoCorrespondenciaCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosEnderecoCorrespondenciaCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCategoriaAntecipacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCategoriaAntecipacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoAluguelPOS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoAluguelPOS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoPeriodicidadeAntecipacaoAutomatica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoPeriodicidadeAntecipacaoAutomatica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoECPrincipal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoECPrincipal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorParcelado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorParcelado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMobile");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorMobile"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCPF");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroCPF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoTipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoClasseFaturamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoClasseFaturamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoClienteAMEX");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoClienteAMEX"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosSituacaoFuncionamentoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosSituacaoFuncionamentoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacaoFuncionamentoCliente"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataUltimaAlteracao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataUltimaAlteracao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoEnderecoCorrespondencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoEnderecoCorrespondencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorPiloto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorPiloto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoAdicional");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoAdicional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEnderecoContrato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosEnderecoContrato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoContrato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoContrato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeSituacaoAtividadeCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeSituacaoAtividadeCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorTravaARV");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorTravaARV"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEnderecoSuprimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosEnderecoSuprimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoCadeia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeTipoCadeia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeSituacaoAtivacaoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeSituacaoAtivacaoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoSMSCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoSMSCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoStatusCobanCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoStatusCobanCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoStatusCobanCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoStatusCobanCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoPagamentoRecorrente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoPagamentoRecorrente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoPagamentoRecorrente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoPagamentoRecorrente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBancoCoban");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoBancoCoban"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBancoCoban");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeBancoCoban"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorBloqueioPagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorBloqueioPagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("motivoRetornoCodigo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "motivoRetornoCodigo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("motivoRetornoDescricao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "motivoRetornoDescricao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEnderecoPontoVenda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosEnderecoPontoVenda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
