/**
 * Proprietario.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Entidade do modelo canonico que representa o proprietario do Estabelecimento
 * Comercial que e o Cliente da Cielo.
 */
public class Proprietario  implements java.io.Serializable {
    /* Nome do proprietario do estabelecimento comercial Cliente da
     * Cielo. */
    private java.lang.String nomeProprietario;

    /* Numero do CPF do proprietario */
    private java.lang.String numeroCPFProprietario;

    /* Data de nascimento do proprietario */
    private java.util.Date dataNascimentoProprietario;

    /* Informacoes de contatos referentes a este proprietario */
    private br.com.cielo.canonico.cadastro.v1.Contato[] dadosContatoProprietario;

    public Proprietario() {
    }

    public Proprietario(
           java.lang.String nomeProprietario,
           java.lang.String numeroCPFProprietario,
           java.util.Date dataNascimentoProprietario,
           br.com.cielo.canonico.cadastro.v1.Contato[] dadosContatoProprietario) {
           this.nomeProprietario = nomeProprietario;
           this.numeroCPFProprietario = numeroCPFProprietario;
           this.dataNascimentoProprietario = dataNascimentoProprietario;
           this.dadosContatoProprietario = dadosContatoProprietario;
    }


    /**
     * Gets the nomeProprietario value for this Proprietario.
     * 
     * @return nomeProprietario   * Nome do proprietario do estabelecimento comercial Cliente da
     * Cielo.
     */
    public java.lang.String getNomeProprietario() {
        return nomeProprietario;
    }


    /**
     * Sets the nomeProprietario value for this Proprietario.
     * 
     * @param nomeProprietario   * Nome do proprietario do estabelecimento comercial Cliente da
     * Cielo.
     */
    public void setNomeProprietario(java.lang.String nomeProprietario) {
        this.nomeProprietario = nomeProprietario;
    }


    /**
     * Gets the numeroCPFProprietario value for this Proprietario.
     * 
     * @return numeroCPFProprietario   * Numero do CPF do proprietario
     */
    public java.lang.String getNumeroCPFProprietario() {
        return numeroCPFProprietario;
    }


    /**
     * Sets the numeroCPFProprietario value for this Proprietario.
     * 
     * @param numeroCPFProprietario   * Numero do CPF do proprietario
     */
    public void setNumeroCPFProprietario(java.lang.String numeroCPFProprietario) {
        this.numeroCPFProprietario = numeroCPFProprietario;
    }


    /**
     * Gets the dataNascimentoProprietario value for this Proprietario.
     * 
     * @return dataNascimentoProprietario   * Data de nascimento do proprietario
     */
    public java.util.Date getDataNascimentoProprietario() {
        return dataNascimentoProprietario;
    }


    /**
     * Sets the dataNascimentoProprietario value for this Proprietario.
     * 
     * @param dataNascimentoProprietario   * Data de nascimento do proprietario
     */
    public void setDataNascimentoProprietario(java.util.Date dataNascimentoProprietario) {
        this.dataNascimentoProprietario = dataNascimentoProprietario;
    }


    /**
     * Gets the dadosContatoProprietario value for this Proprietario.
     * 
     * @return dadosContatoProprietario   * Informacoes de contatos referentes a este proprietario
     */
    public br.com.cielo.canonico.cadastro.v1.Contato[] getDadosContatoProprietario() {
        return dadosContatoProprietario;
    }


    /**
     * Sets the dadosContatoProprietario value for this Proprietario.
     * 
     * @param dadosContatoProprietario   * Informacoes de contatos referentes a este proprietario
     */
    public void setDadosContatoProprietario(br.com.cielo.canonico.cadastro.v1.Contato[] dadosContatoProprietario) {
        this.dadosContatoProprietario = dadosContatoProprietario;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Proprietario)) return false;
        Proprietario other = (Proprietario) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nomeProprietario==null && other.getNomeProprietario()==null) || 
             (this.nomeProprietario!=null &&
              this.nomeProprietario.equals(other.getNomeProprietario()))) &&
            ((this.numeroCPFProprietario==null && other.getNumeroCPFProprietario()==null) || 
             (this.numeroCPFProprietario!=null &&
              this.numeroCPFProprietario.equals(other.getNumeroCPFProprietario()))) &&
            ((this.dataNascimentoProprietario==null && other.getDataNascimentoProprietario()==null) || 
             (this.dataNascimentoProprietario!=null &&
              this.dataNascimentoProprietario.equals(other.getDataNascimentoProprietario()))) &&
            ((this.dadosContatoProprietario==null && other.getDadosContatoProprietario()==null) || 
             (this.dadosContatoProprietario!=null &&
              java.util.Arrays.equals(this.dadosContatoProprietario, other.getDadosContatoProprietario())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNomeProprietario() != null) {
            _hashCode += getNomeProprietario().hashCode();
        }
        if (getNumeroCPFProprietario() != null) {
            _hashCode += getNumeroCPFProprietario().hashCode();
        }
        if (getDataNascimentoProprietario() != null) {
            _hashCode += getDataNascimentoProprietario().hashCode();
        }
        if (getDadosContatoProprietario() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosContatoProprietario());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosContatoProprietario(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Proprietario.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Proprietario"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeProprietario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeProprietario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCPFProprietario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroCPFProprietario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataNascimentoProprietario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataNascimentoProprietario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoProprietario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoProprietario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "contato"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
