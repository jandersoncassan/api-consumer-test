/**
 * AlterarStatusClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class AlterarStatusClienteResponse  implements java.io.Serializable {
    private java.lang.String statusRetorno;

    private java.util.Date dataManutencao;

    private org.apache.axis.types.Time horaManutencao;

    public AlterarStatusClienteResponse() {
    }

    public AlterarStatusClienteResponse(
           java.lang.String statusRetorno,
           java.util.Date dataManutencao,
           org.apache.axis.types.Time horaManutencao) {
           this.statusRetorno = statusRetorno;
           this.dataManutencao = dataManutencao;
           this.horaManutencao = horaManutencao;
    }


    /**
     * Gets the statusRetorno value for this AlterarStatusClienteResponse.
     * 
     * @return statusRetorno
     */
    public java.lang.String getStatusRetorno() {
        return statusRetorno;
    }


    /**
     * Sets the statusRetorno value for this AlterarStatusClienteResponse.
     * 
     * @param statusRetorno
     */
    public void setStatusRetorno(java.lang.String statusRetorno) {
        this.statusRetorno = statusRetorno;
    }


    /**
     * Gets the dataManutencao value for this AlterarStatusClienteResponse.
     * 
     * @return dataManutencao
     */
    public java.util.Date getDataManutencao() {
        return dataManutencao;
    }


    /**
     * Sets the dataManutencao value for this AlterarStatusClienteResponse.
     * 
     * @param dataManutencao
     */
    public void setDataManutencao(java.util.Date dataManutencao) {
        this.dataManutencao = dataManutencao;
    }


    /**
     * Gets the horaManutencao value for this AlterarStatusClienteResponse.
     * 
     * @return horaManutencao
     */
    public org.apache.axis.types.Time getHoraManutencao() {
        return horaManutencao;
    }


    /**
     * Sets the horaManutencao value for this AlterarStatusClienteResponse.
     * 
     * @param horaManutencao
     */
    public void setHoraManutencao(org.apache.axis.types.Time horaManutencao) {
        this.horaManutencao = horaManutencao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarStatusClienteResponse)) return false;
        AlterarStatusClienteResponse other = (AlterarStatusClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.statusRetorno==null && other.getStatusRetorno()==null) || 
             (this.statusRetorno!=null &&
              this.statusRetorno.equals(other.getStatusRetorno()))) &&
            ((this.dataManutencao==null && other.getDataManutencao()==null) || 
             (this.dataManutencao!=null &&
              this.dataManutencao.equals(other.getDataManutencao()))) &&
            ((this.horaManutencao==null && other.getHoraManutencao()==null) || 
             (this.horaManutencao!=null &&
              this.horaManutencao.equals(other.getHoraManutencao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatusRetorno() != null) {
            _hashCode += getStatusRetorno().hashCode();
        }
        if (getDataManutencao() != null) {
            _hashCode += getDataManutencao().hashCode();
        }
        if (getHoraManutencao() != null) {
            _hashCode += getHoraManutencao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarStatusClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarStatusClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "statusRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataManutencao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "dataManutencao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horaManutencao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "horaManutencao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "time"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
