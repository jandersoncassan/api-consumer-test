/**
 * NotificarInstalacaoMobileServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile;

public interface NotificarInstalacaoMobileServicePortType extends java.rmi.Remote {

    /**
     * Operacao responsavel por criar um evento de notificacao no
     * SEC informando a instalacao de um Mobile
     */
    public br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileResponse notificarInstalacaoMobile(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
