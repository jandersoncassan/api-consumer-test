/**
 * NotificarInstalacaoMobileRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile;

public class NotificarInstalacaoMobileRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o Cliente */
    private long codigoCliente;

    private java.lang.String canalSolicitante;

    /* Numero logico gerado em REDES */
    private java.lang.String numeroLogico;

    /* Codigo de dependencia do evento, que indica quem ira tratar
     * o evento */
    private java.math.BigInteger codigoDependencia;

    /* Status com o qual o evento sera aberto */
    private java.lang.String statusEvento;

    public NotificarInstalacaoMobileRequest() {
    }

    public NotificarInstalacaoMobileRequest(
           long codigoCliente,
           java.lang.String canalSolicitante,
           java.lang.String numeroLogico,
           java.math.BigInteger codigoDependencia,
           java.lang.String statusEvento) {
           this.codigoCliente = codigoCliente;
           this.canalSolicitante = canalSolicitante;
           this.numeroLogico = numeroLogico;
           this.codigoDependencia = codigoDependencia;
           this.statusEvento = statusEvento;
    }


    /**
     * Gets the codigoCliente value for this NotificarInstalacaoMobileRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this NotificarInstalacaoMobileRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the canalSolicitante value for this NotificarInstalacaoMobileRequest.
     * 
     * @return canalSolicitante
     */
    public java.lang.String getCanalSolicitante() {
        return canalSolicitante;
    }


    /**
     * Sets the canalSolicitante value for this NotificarInstalacaoMobileRequest.
     * 
     * @param canalSolicitante
     */
    public void setCanalSolicitante(java.lang.String canalSolicitante) {
        this.canalSolicitante = canalSolicitante;
    }


    /**
     * Gets the numeroLogico value for this NotificarInstalacaoMobileRequest.
     * 
     * @return numeroLogico   * Numero logico gerado em REDES
     */
    public java.lang.String getNumeroLogico() {
        return numeroLogico;
    }


    /**
     * Sets the numeroLogico value for this NotificarInstalacaoMobileRequest.
     * 
     * @param numeroLogico   * Numero logico gerado em REDES
     */
    public void setNumeroLogico(java.lang.String numeroLogico) {
        this.numeroLogico = numeroLogico;
    }


    /**
     * Gets the codigoDependencia value for this NotificarInstalacaoMobileRequest.
     * 
     * @return codigoDependencia   * Codigo de dependencia do evento, que indica quem ira tratar
     * o evento
     */
    public java.math.BigInteger getCodigoDependencia() {
        return codigoDependencia;
    }


    /**
     * Sets the codigoDependencia value for this NotificarInstalacaoMobileRequest.
     * 
     * @param codigoDependencia   * Codigo de dependencia do evento, que indica quem ira tratar
     * o evento
     */
    public void setCodigoDependencia(java.math.BigInteger codigoDependencia) {
        this.codigoDependencia = codigoDependencia;
    }


    /**
     * Gets the statusEvento value for this NotificarInstalacaoMobileRequest.
     * 
     * @return statusEvento   * Status com o qual o evento sera aberto
     */
    public java.lang.String getStatusEvento() {
        return statusEvento;
    }


    /**
     * Sets the statusEvento value for this NotificarInstalacaoMobileRequest.
     * 
     * @param statusEvento   * Status com o qual o evento sera aberto
     */
    public void setStatusEvento(java.lang.String statusEvento) {
        this.statusEvento = statusEvento;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NotificarInstalacaoMobileRequest)) return false;
        NotificarInstalacaoMobileRequest other = (NotificarInstalacaoMobileRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.canalSolicitante==null && other.getCanalSolicitante()==null) || 
             (this.canalSolicitante!=null &&
              this.canalSolicitante.equals(other.getCanalSolicitante()))) &&
            ((this.numeroLogico==null && other.getNumeroLogico()==null) || 
             (this.numeroLogico!=null &&
              this.numeroLogico.equals(other.getNumeroLogico()))) &&
            ((this.codigoDependencia==null && other.getCodigoDependencia()==null) || 
             (this.codigoDependencia!=null &&
              this.codigoDependencia.equals(other.getCodigoDependencia()))) &&
            ((this.statusEvento==null && other.getStatusEvento()==null) || 
             (this.statusEvento!=null &&
              this.statusEvento.equals(other.getStatusEvento())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getCanalSolicitante() != null) {
            _hashCode += getCanalSolicitante().hashCode();
        }
        if (getNumeroLogico() != null) {
            _hashCode += getNumeroLogico().hashCode();
        }
        if (getCodigoDependencia() != null) {
            _hashCode += getCodigoDependencia().hashCode();
        }
        if (getStatusEvento() != null) {
            _hashCode += getStatusEvento().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NotificarInstalacaoMobileRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v5/notificarinstalacaomobile", ">NotificarInstalacaoMobileRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v5/notificarinstalacaomobile", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canalSolicitante");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v5/notificarinstalacaomobile", "canalSolicitante"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v5/notificarinstalacaomobile", "numeroLogico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoDependencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v5/notificarinstalacaomobile", "codigoDependencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusEvento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v5/notificarinstalacaomobile", "statusEvento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
