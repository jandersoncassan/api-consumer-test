/**
 * Produto.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class Produto  implements java.io.Serializable {
    private java.lang.String nomeProduto;

    private br.com.cielo.canonico.cadastro.v1.DadosBancarios dadosBancarios;

    private java.math.BigInteger codigoProduto;

    private java.lang.String numeroProduto;

    private java.math.BigDecimal percentualTaxa;

    private java.math.BigInteger quantidadeDiasPrazo;

    private java.lang.String descricaoProduto;

    private br.com.cielo.canonico.cadastro.v1.Tarifa dadosTarifa;

    private java.math.BigInteger codigoEmpresa;

    private java.lang.String numeroEmpresa;

    private java.math.BigInteger codigoBandeira;

    private java.lang.String numeroBandeira;

    private java.math.BigInteger codigoFormaPagamento;

    private java.lang.Boolean indicadorSecuratizacao;

    private java.lang.Boolean indicadorSecuratizacaoAntecipacao;

    private java.lang.String codigoLiquidacao;

    private java.lang.String nomeTipoCobranca;

    /* Situacao na qual a bandeira esta para este produto. Dominio:
     * Habilitada
     * Desabilitada */
    private java.lang.String nomeSituacaoBandeira;

    /* Nome da bandeira.
     * Exemplos: VISA; MASTER; AMEX; TICKET; SODEXO; SOROCRED; ELO;etc. */
    private java.lang.String nomeBandeira;

    /* Informa o responsavel pela liquidacao das operacoes para o
     * cliente: Adquirencia (Cielo) ou Van/MultiVan (Van responsavel). */
    private java.lang.String nomeTipoLiquidacao;

    /* Data de habilitação do produto contratado pelo cliente */
    private java.util.Date dataHabilitacaoProdutoCliente;

    /* Valor percentual dado de desconto ao produto */
    private java.math.BigDecimal percentualDesconto;

    /* indicador que indica se este produto permite transacoes de
     * venda digitadas */
    private java.lang.Boolean indicadorVendaDigitada;

    /* indicador que indica se para um determinado cliente este produto
     * esta habilitado para gerar transacoes de venda digitadas.
     * Este indicador podera ser positivo somente se o indicador que demonstra
     * que a venda digitada esta com seu valor verdadeiro. */
    private java.lang.Boolean indicadorVendaDigitadaHabilitada;

    public Produto() {
    }

    public Produto(
           java.lang.String nomeProduto,
           br.com.cielo.canonico.cadastro.v1.DadosBancarios dadosBancarios,
           java.math.BigInteger codigoProduto,
           java.lang.String numeroProduto,
           java.math.BigDecimal percentualTaxa,
           java.math.BigInteger quantidadeDiasPrazo,
           java.lang.String descricaoProduto,
           br.com.cielo.canonico.cadastro.v1.Tarifa dadosTarifa,
           java.math.BigInteger codigoEmpresa,
           java.lang.String numeroEmpresa,
           java.math.BigInteger codigoBandeira,
           java.lang.String numeroBandeira,
           java.math.BigInteger codigoFormaPagamento,
           java.lang.Boolean indicadorSecuratizacao,
           java.lang.Boolean indicadorSecuratizacaoAntecipacao,
           java.lang.String codigoLiquidacao,
           java.lang.String nomeTipoCobranca,
           java.lang.String nomeSituacaoBandeira,
           java.lang.String nomeBandeira,
           java.lang.String nomeTipoLiquidacao,
           java.util.Date dataHabilitacaoProdutoCliente,
           java.math.BigDecimal percentualDesconto,
           java.lang.Boolean indicadorVendaDigitada,
           java.lang.Boolean indicadorVendaDigitadaHabilitada) {
           this.nomeProduto = nomeProduto;
           this.dadosBancarios = dadosBancarios;
           this.codigoProduto = codigoProduto;
           this.numeroProduto = numeroProduto;
           this.percentualTaxa = percentualTaxa;
           this.quantidadeDiasPrazo = quantidadeDiasPrazo;
           this.descricaoProduto = descricaoProduto;
           this.dadosTarifa = dadosTarifa;
           this.codigoEmpresa = codigoEmpresa;
           this.numeroEmpresa = numeroEmpresa;
           this.codigoBandeira = codigoBandeira;
           this.numeroBandeira = numeroBandeira;
           this.codigoFormaPagamento = codigoFormaPagamento;
           this.indicadorSecuratizacao = indicadorSecuratizacao;
           this.indicadorSecuratizacaoAntecipacao = indicadorSecuratizacaoAntecipacao;
           this.codigoLiquidacao = codigoLiquidacao;
           this.nomeTipoCobranca = nomeTipoCobranca;
           this.nomeSituacaoBandeira = nomeSituacaoBandeira;
           this.nomeBandeira = nomeBandeira;
           this.nomeTipoLiquidacao = nomeTipoLiquidacao;
           this.dataHabilitacaoProdutoCliente = dataHabilitacaoProdutoCliente;
           this.percentualDesconto = percentualDesconto;
           this.indicadorVendaDigitada = indicadorVendaDigitada;
           this.indicadorVendaDigitadaHabilitada = indicadorVendaDigitadaHabilitada;
    }


    /**
     * Gets the nomeProduto value for this Produto.
     * 
     * @return nomeProduto
     */
    public java.lang.String getNomeProduto() {
        return nomeProduto;
    }


    /**
     * Sets the nomeProduto value for this Produto.
     * 
     * @param nomeProduto
     */
    public void setNomeProduto(java.lang.String nomeProduto) {
        this.nomeProduto = nomeProduto;
    }


    /**
     * Gets the dadosBancarios value for this Produto.
     * 
     * @return dadosBancarios
     */
    public br.com.cielo.canonico.cadastro.v1.DadosBancarios getDadosBancarios() {
        return dadosBancarios;
    }


    /**
     * Sets the dadosBancarios value for this Produto.
     * 
     * @param dadosBancarios
     */
    public void setDadosBancarios(br.com.cielo.canonico.cadastro.v1.DadosBancarios dadosBancarios) {
        this.dadosBancarios = dadosBancarios;
    }


    /**
     * Gets the codigoProduto value for this Produto.
     * 
     * @return codigoProduto
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this Produto.
     * 
     * @param codigoProduto
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the numeroProduto value for this Produto.
     * 
     * @return numeroProduto
     */
    public java.lang.String getNumeroProduto() {
        return numeroProduto;
    }


    /**
     * Sets the numeroProduto value for this Produto.
     * 
     * @param numeroProduto
     */
    public void setNumeroProduto(java.lang.String numeroProduto) {
        this.numeroProduto = numeroProduto;
    }


    /**
     * Gets the percentualTaxa value for this Produto.
     * 
     * @return percentualTaxa
     */
    public java.math.BigDecimal getPercentualTaxa() {
        return percentualTaxa;
    }


    /**
     * Sets the percentualTaxa value for this Produto.
     * 
     * @param percentualTaxa
     */
    public void setPercentualTaxa(java.math.BigDecimal percentualTaxa) {
        this.percentualTaxa = percentualTaxa;
    }


    /**
     * Gets the quantidadeDiasPrazo value for this Produto.
     * 
     * @return quantidadeDiasPrazo
     */
    public java.math.BigInteger getQuantidadeDiasPrazo() {
        return quantidadeDiasPrazo;
    }


    /**
     * Sets the quantidadeDiasPrazo value for this Produto.
     * 
     * @param quantidadeDiasPrazo
     */
    public void setQuantidadeDiasPrazo(java.math.BigInteger quantidadeDiasPrazo) {
        this.quantidadeDiasPrazo = quantidadeDiasPrazo;
    }


    /**
     * Gets the descricaoProduto value for this Produto.
     * 
     * @return descricaoProduto
     */
    public java.lang.String getDescricaoProduto() {
        return descricaoProduto;
    }


    /**
     * Sets the descricaoProduto value for this Produto.
     * 
     * @param descricaoProduto
     */
    public void setDescricaoProduto(java.lang.String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }


    /**
     * Gets the dadosTarifa value for this Produto.
     * 
     * @return dadosTarifa
     */
    public br.com.cielo.canonico.cadastro.v1.Tarifa getDadosTarifa() {
        return dadosTarifa;
    }


    /**
     * Sets the dadosTarifa value for this Produto.
     * 
     * @param dadosTarifa
     */
    public void setDadosTarifa(br.com.cielo.canonico.cadastro.v1.Tarifa dadosTarifa) {
        this.dadosTarifa = dadosTarifa;
    }


    /**
     * Gets the codigoEmpresa value for this Produto.
     * 
     * @return codigoEmpresa
     */
    public java.math.BigInteger getCodigoEmpresa() {
        return codigoEmpresa;
    }


    /**
     * Sets the codigoEmpresa value for this Produto.
     * 
     * @param codigoEmpresa
     */
    public void setCodigoEmpresa(java.math.BigInteger codigoEmpresa) {
        this.codigoEmpresa = codigoEmpresa;
    }


    /**
     * Gets the numeroEmpresa value for this Produto.
     * 
     * @return numeroEmpresa
     */
    public java.lang.String getNumeroEmpresa() {
        return numeroEmpresa;
    }


    /**
     * Sets the numeroEmpresa value for this Produto.
     * 
     * @param numeroEmpresa
     */
    public void setNumeroEmpresa(java.lang.String numeroEmpresa) {
        this.numeroEmpresa = numeroEmpresa;
    }


    /**
     * Gets the codigoBandeira value for this Produto.
     * 
     * @return codigoBandeira
     */
    public java.math.BigInteger getCodigoBandeira() {
        return codigoBandeira;
    }


    /**
     * Sets the codigoBandeira value for this Produto.
     * 
     * @param codigoBandeira
     */
    public void setCodigoBandeira(java.math.BigInteger codigoBandeira) {
        this.codigoBandeira = codigoBandeira;
    }


    /**
     * Gets the numeroBandeira value for this Produto.
     * 
     * @return numeroBandeira
     */
    public java.lang.String getNumeroBandeira() {
        return numeroBandeira;
    }


    /**
     * Sets the numeroBandeira value for this Produto.
     * 
     * @param numeroBandeira
     */
    public void setNumeroBandeira(java.lang.String numeroBandeira) {
        this.numeroBandeira = numeroBandeira;
    }


    /**
     * Gets the codigoFormaPagamento value for this Produto.
     * 
     * @return codigoFormaPagamento
     */
    public java.math.BigInteger getCodigoFormaPagamento() {
        return codigoFormaPagamento;
    }


    /**
     * Sets the codigoFormaPagamento value for this Produto.
     * 
     * @param codigoFormaPagamento
     */
    public void setCodigoFormaPagamento(java.math.BigInteger codigoFormaPagamento) {
        this.codigoFormaPagamento = codigoFormaPagamento;
    }


    /**
     * Gets the indicadorSecuratizacao value for this Produto.
     * 
     * @return indicadorSecuratizacao
     */
    public java.lang.Boolean getIndicadorSecuratizacao() {
        return indicadorSecuratizacao;
    }


    /**
     * Sets the indicadorSecuratizacao value for this Produto.
     * 
     * @param indicadorSecuratizacao
     */
    public void setIndicadorSecuratizacao(java.lang.Boolean indicadorSecuratizacao) {
        this.indicadorSecuratizacao = indicadorSecuratizacao;
    }


    /**
     * Gets the indicadorSecuratizacaoAntecipacao value for this Produto.
     * 
     * @return indicadorSecuratizacaoAntecipacao
     */
    public java.lang.Boolean getIndicadorSecuratizacaoAntecipacao() {
        return indicadorSecuratizacaoAntecipacao;
    }


    /**
     * Sets the indicadorSecuratizacaoAntecipacao value for this Produto.
     * 
     * @param indicadorSecuratizacaoAntecipacao
     */
    public void setIndicadorSecuratizacaoAntecipacao(java.lang.Boolean indicadorSecuratizacaoAntecipacao) {
        this.indicadorSecuratizacaoAntecipacao = indicadorSecuratizacaoAntecipacao;
    }


    /**
     * Gets the codigoLiquidacao value for this Produto.
     * 
     * @return codigoLiquidacao
     */
    public java.lang.String getCodigoLiquidacao() {
        return codigoLiquidacao;
    }


    /**
     * Sets the codigoLiquidacao value for this Produto.
     * 
     * @param codigoLiquidacao
     */
    public void setCodigoLiquidacao(java.lang.String codigoLiquidacao) {
        this.codigoLiquidacao = codigoLiquidacao;
    }


    /**
     * Gets the nomeTipoCobranca value for this Produto.
     * 
     * @return nomeTipoCobranca
     */
    public java.lang.String getNomeTipoCobranca() {
        return nomeTipoCobranca;
    }


    /**
     * Sets the nomeTipoCobranca value for this Produto.
     * 
     * @param nomeTipoCobranca
     */
    public void setNomeTipoCobranca(java.lang.String nomeTipoCobranca) {
        this.nomeTipoCobranca = nomeTipoCobranca;
    }


    /**
     * Gets the nomeSituacaoBandeira value for this Produto.
     * 
     * @return nomeSituacaoBandeira   * Situacao na qual a bandeira esta para este produto. Dominio:
     * Habilitada
     * Desabilitada
     */
    public java.lang.String getNomeSituacaoBandeira() {
        return nomeSituacaoBandeira;
    }


    /**
     * Sets the nomeSituacaoBandeira value for this Produto.
     * 
     * @param nomeSituacaoBandeira   * Situacao na qual a bandeira esta para este produto. Dominio:
     * Habilitada
     * Desabilitada
     */
    public void setNomeSituacaoBandeira(java.lang.String nomeSituacaoBandeira) {
        this.nomeSituacaoBandeira = nomeSituacaoBandeira;
    }


    /**
     * Gets the nomeBandeira value for this Produto.
     * 
     * @return nomeBandeira   * Nome da bandeira.
     * Exemplos: VISA; MASTER; AMEX; TICKET; SODEXO; SOROCRED; ELO;etc.
     */
    public java.lang.String getNomeBandeira() {
        return nomeBandeira;
    }


    /**
     * Sets the nomeBandeira value for this Produto.
     * 
     * @param nomeBandeira   * Nome da bandeira.
     * Exemplos: VISA; MASTER; AMEX; TICKET; SODEXO; SOROCRED; ELO;etc.
     */
    public void setNomeBandeira(java.lang.String nomeBandeira) {
        this.nomeBandeira = nomeBandeira;
    }


    /**
     * Gets the nomeTipoLiquidacao value for this Produto.
     * 
     * @return nomeTipoLiquidacao   * Informa o responsavel pela liquidacao das operacoes para o
     * cliente: Adquirencia (Cielo) ou Van/MultiVan (Van responsavel).
     */
    public java.lang.String getNomeTipoLiquidacao() {
        return nomeTipoLiquidacao;
    }


    /**
     * Sets the nomeTipoLiquidacao value for this Produto.
     * 
     * @param nomeTipoLiquidacao   * Informa o responsavel pela liquidacao das operacoes para o
     * cliente: Adquirencia (Cielo) ou Van/MultiVan (Van responsavel).
     */
    public void setNomeTipoLiquidacao(java.lang.String nomeTipoLiquidacao) {
        this.nomeTipoLiquidacao = nomeTipoLiquidacao;
    }


    /**
     * Gets the dataHabilitacaoProdutoCliente value for this Produto.
     * 
     * @return dataHabilitacaoProdutoCliente   * Data de habilitação do produto contratado pelo cliente
     */
    public java.util.Date getDataHabilitacaoProdutoCliente() {
        return dataHabilitacaoProdutoCliente;
    }


    /**
     * Sets the dataHabilitacaoProdutoCliente value for this Produto.
     * 
     * @param dataHabilitacaoProdutoCliente   * Data de habilitação do produto contratado pelo cliente
     */
    public void setDataHabilitacaoProdutoCliente(java.util.Date dataHabilitacaoProdutoCliente) {
        this.dataHabilitacaoProdutoCliente = dataHabilitacaoProdutoCliente;
    }


    /**
     * Gets the percentualDesconto value for this Produto.
     * 
     * @return percentualDesconto   * Valor percentual dado de desconto ao produto
     */
    public java.math.BigDecimal getPercentualDesconto() {
        return percentualDesconto;
    }


    /**
     * Sets the percentualDesconto value for this Produto.
     * 
     * @param percentualDesconto   * Valor percentual dado de desconto ao produto
     */
    public void setPercentualDesconto(java.math.BigDecimal percentualDesconto) {
        this.percentualDesconto = percentualDesconto;
    }


    /**
     * Gets the indicadorVendaDigitada value for this Produto.
     * 
     * @return indicadorVendaDigitada   * indicador que indica se este produto permite transacoes de
     * venda digitadas
     */
    public java.lang.Boolean getIndicadorVendaDigitada() {
        return indicadorVendaDigitada;
    }


    /**
     * Sets the indicadorVendaDigitada value for this Produto.
     * 
     * @param indicadorVendaDigitada   * indicador que indica se este produto permite transacoes de
     * venda digitadas
     */
    public void setIndicadorVendaDigitada(java.lang.Boolean indicadorVendaDigitada) {
        this.indicadorVendaDigitada = indicadorVendaDigitada;
    }


    /**
     * Gets the indicadorVendaDigitadaHabilitada value for this Produto.
     * 
     * @return indicadorVendaDigitadaHabilitada   * indicador que indica se para um determinado cliente este produto
     * esta habilitado para gerar transacoes de venda digitadas.
     * Este indicador podera ser positivo somente se o indicador que demonstra
     * que a venda digitada esta com seu valor verdadeiro.
     */
    public java.lang.Boolean getIndicadorVendaDigitadaHabilitada() {
        return indicadorVendaDigitadaHabilitada;
    }


    /**
     * Sets the indicadorVendaDigitadaHabilitada value for this Produto.
     * 
     * @param indicadorVendaDigitadaHabilitada   * indicador que indica se para um determinado cliente este produto
     * esta habilitado para gerar transacoes de venda digitadas.
     * Este indicador podera ser positivo somente se o indicador que demonstra
     * que a venda digitada esta com seu valor verdadeiro.
     */
    public void setIndicadorVendaDigitadaHabilitada(java.lang.Boolean indicadorVendaDigitadaHabilitada) {
        this.indicadorVendaDigitadaHabilitada = indicadorVendaDigitadaHabilitada;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Produto)) return false;
        Produto other = (Produto) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nomeProduto==null && other.getNomeProduto()==null) || 
             (this.nomeProduto!=null &&
              this.nomeProduto.equals(other.getNomeProduto()))) &&
            ((this.dadosBancarios==null && other.getDadosBancarios()==null) || 
             (this.dadosBancarios!=null &&
              this.dadosBancarios.equals(other.getDadosBancarios()))) &&
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto()))) &&
            ((this.numeroProduto==null && other.getNumeroProduto()==null) || 
             (this.numeroProduto!=null &&
              this.numeroProduto.equals(other.getNumeroProduto()))) &&
            ((this.percentualTaxa==null && other.getPercentualTaxa()==null) || 
             (this.percentualTaxa!=null &&
              this.percentualTaxa.equals(other.getPercentualTaxa()))) &&
            ((this.quantidadeDiasPrazo==null && other.getQuantidadeDiasPrazo()==null) || 
             (this.quantidadeDiasPrazo!=null &&
              this.quantidadeDiasPrazo.equals(other.getQuantidadeDiasPrazo()))) &&
            ((this.descricaoProduto==null && other.getDescricaoProduto()==null) || 
             (this.descricaoProduto!=null &&
              this.descricaoProduto.equals(other.getDescricaoProduto()))) &&
            ((this.dadosTarifa==null && other.getDadosTarifa()==null) || 
             (this.dadosTarifa!=null &&
              this.dadosTarifa.equals(other.getDadosTarifa()))) &&
            ((this.codigoEmpresa==null && other.getCodigoEmpresa()==null) || 
             (this.codigoEmpresa!=null &&
              this.codigoEmpresa.equals(other.getCodigoEmpresa()))) &&
            ((this.numeroEmpresa==null && other.getNumeroEmpresa()==null) || 
             (this.numeroEmpresa!=null &&
              this.numeroEmpresa.equals(other.getNumeroEmpresa()))) &&
            ((this.codigoBandeira==null && other.getCodigoBandeira()==null) || 
             (this.codigoBandeira!=null &&
              this.codigoBandeira.equals(other.getCodigoBandeira()))) &&
            ((this.numeroBandeira==null && other.getNumeroBandeira()==null) || 
             (this.numeroBandeira!=null &&
              this.numeroBandeira.equals(other.getNumeroBandeira()))) &&
            ((this.codigoFormaPagamento==null && other.getCodigoFormaPagamento()==null) || 
             (this.codigoFormaPagamento!=null &&
              this.codigoFormaPagamento.equals(other.getCodigoFormaPagamento()))) &&
            ((this.indicadorSecuratizacao==null && other.getIndicadorSecuratizacao()==null) || 
             (this.indicadorSecuratizacao!=null &&
              this.indicadorSecuratizacao.equals(other.getIndicadorSecuratizacao()))) &&
            ((this.indicadorSecuratizacaoAntecipacao==null && other.getIndicadorSecuratizacaoAntecipacao()==null) || 
             (this.indicadorSecuratizacaoAntecipacao!=null &&
              this.indicadorSecuratizacaoAntecipacao.equals(other.getIndicadorSecuratizacaoAntecipacao()))) &&
            ((this.codigoLiquidacao==null && other.getCodigoLiquidacao()==null) || 
             (this.codigoLiquidacao!=null &&
              this.codigoLiquidacao.equals(other.getCodigoLiquidacao()))) &&
            ((this.nomeTipoCobranca==null && other.getNomeTipoCobranca()==null) || 
             (this.nomeTipoCobranca!=null &&
              this.nomeTipoCobranca.equals(other.getNomeTipoCobranca()))) &&
            ((this.nomeSituacaoBandeira==null && other.getNomeSituacaoBandeira()==null) || 
             (this.nomeSituacaoBandeira!=null &&
              this.nomeSituacaoBandeira.equals(other.getNomeSituacaoBandeira()))) &&
            ((this.nomeBandeira==null && other.getNomeBandeira()==null) || 
             (this.nomeBandeira!=null &&
              this.nomeBandeira.equals(other.getNomeBandeira()))) &&
            ((this.nomeTipoLiquidacao==null && other.getNomeTipoLiquidacao()==null) || 
             (this.nomeTipoLiquidacao!=null &&
              this.nomeTipoLiquidacao.equals(other.getNomeTipoLiquidacao()))) &&
            ((this.dataHabilitacaoProdutoCliente==null && other.getDataHabilitacaoProdutoCliente()==null) || 
             (this.dataHabilitacaoProdutoCliente!=null &&
              this.dataHabilitacaoProdutoCliente.equals(other.getDataHabilitacaoProdutoCliente()))) &&
            ((this.percentualDesconto==null && other.getPercentualDesconto()==null) || 
             (this.percentualDesconto!=null &&
              this.percentualDesconto.equals(other.getPercentualDesconto()))) &&
            ((this.indicadorVendaDigitada==null && other.getIndicadorVendaDigitada()==null) || 
             (this.indicadorVendaDigitada!=null &&
              this.indicadorVendaDigitada.equals(other.getIndicadorVendaDigitada()))) &&
            ((this.indicadorVendaDigitadaHabilitada==null && other.getIndicadorVendaDigitadaHabilitada()==null) || 
             (this.indicadorVendaDigitadaHabilitada!=null &&
              this.indicadorVendaDigitadaHabilitada.equals(other.getIndicadorVendaDigitadaHabilitada())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNomeProduto() != null) {
            _hashCode += getNomeProduto().hashCode();
        }
        if (getDadosBancarios() != null) {
            _hashCode += getDadosBancarios().hashCode();
        }
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        if (getNumeroProduto() != null) {
            _hashCode += getNumeroProduto().hashCode();
        }
        if (getPercentualTaxa() != null) {
            _hashCode += getPercentualTaxa().hashCode();
        }
        if (getQuantidadeDiasPrazo() != null) {
            _hashCode += getQuantidadeDiasPrazo().hashCode();
        }
        if (getDescricaoProduto() != null) {
            _hashCode += getDescricaoProduto().hashCode();
        }
        if (getDadosTarifa() != null) {
            _hashCode += getDadosTarifa().hashCode();
        }
        if (getCodigoEmpresa() != null) {
            _hashCode += getCodigoEmpresa().hashCode();
        }
        if (getNumeroEmpresa() != null) {
            _hashCode += getNumeroEmpresa().hashCode();
        }
        if (getCodigoBandeira() != null) {
            _hashCode += getCodigoBandeira().hashCode();
        }
        if (getNumeroBandeira() != null) {
            _hashCode += getNumeroBandeira().hashCode();
        }
        if (getCodigoFormaPagamento() != null) {
            _hashCode += getCodigoFormaPagamento().hashCode();
        }
        if (getIndicadorSecuratizacao() != null) {
            _hashCode += getIndicadorSecuratizacao().hashCode();
        }
        if (getIndicadorSecuratizacaoAntecipacao() != null) {
            _hashCode += getIndicadorSecuratizacaoAntecipacao().hashCode();
        }
        if (getCodigoLiquidacao() != null) {
            _hashCode += getCodigoLiquidacao().hashCode();
        }
        if (getNomeTipoCobranca() != null) {
            _hashCode += getNomeTipoCobranca().hashCode();
        }
        if (getNomeSituacaoBandeira() != null) {
            _hashCode += getNomeSituacaoBandeira().hashCode();
        }
        if (getNomeBandeira() != null) {
            _hashCode += getNomeBandeira().hashCode();
        }
        if (getNomeTipoLiquidacao() != null) {
            _hashCode += getNomeTipoLiquidacao().hashCode();
        }
        if (getDataHabilitacaoProdutoCliente() != null) {
            _hashCode += getDataHabilitacaoProdutoCliente().hashCode();
        }
        if (getPercentualDesconto() != null) {
            _hashCode += getPercentualDesconto().hashCode();
        }
        if (getIndicadorVendaDigitada() != null) {
            _hashCode += getIndicadorVendaDigitada().hashCode();
        }
        if (getIndicadorVendaDigitadaHabilitada() != null) {
            _hashCode += getIndicadorVendaDigitadaHabilitada().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Produto.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosBancarios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosBancarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DadosBancarios"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeDiasPrazo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeDiasPrazo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosTarifa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosTarifa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Tarifa"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoEmpresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoEmpresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEmpresa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroEmpresa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFormaPagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoFormaPagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorSecuratizacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorSecuratizacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorSecuratizacaoAntecipacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorSecuratizacaoAntecipacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoLiquidacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoLiquidacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoCobranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeTipoCobranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeSituacaoBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeSituacaoBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoLiquidacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeTipoLiquidacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataHabilitacaoProdutoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataHabilitacaoProdutoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualDesconto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualDesconto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVendaDigitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorVendaDigitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVendaDigitadaHabilitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorVendaDigitadaHabilitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
