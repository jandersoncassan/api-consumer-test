/**
 * ProdutoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class ProdutoType  implements java.io.Serializable {
    private java.math.BigInteger codigoProduto;

    private java.math.BigDecimal percentualTaxaPadrao;

    private int quantideParcelaProduto;

    public ProdutoType() {
    }

    public ProdutoType(
           java.math.BigInteger codigoProduto,
           java.math.BigDecimal percentualTaxaPadrao,
           int quantideParcelaProduto) {
           this.codigoProduto = codigoProduto;
           this.percentualTaxaPadrao = percentualTaxaPadrao;
           this.quantideParcelaProduto = quantideParcelaProduto;
    }


    /**
     * Gets the codigoProduto value for this ProdutoType.
     * 
     * @return codigoProduto
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this ProdutoType.
     * 
     * @param codigoProduto
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the percentualTaxaPadrao value for this ProdutoType.
     * 
     * @return percentualTaxaPadrao
     */
    public java.math.BigDecimal getPercentualTaxaPadrao() {
        return percentualTaxaPadrao;
    }


    /**
     * Sets the percentualTaxaPadrao value for this ProdutoType.
     * 
     * @param percentualTaxaPadrao
     */
    public void setPercentualTaxaPadrao(java.math.BigDecimal percentualTaxaPadrao) {
        this.percentualTaxaPadrao = percentualTaxaPadrao;
    }


    /**
     * Gets the quantideParcelaProduto value for this ProdutoType.
     * 
     * @return quantideParcelaProduto
     */
    public int getQuantideParcelaProduto() {
        return quantideParcelaProduto;
    }


    /**
     * Sets the quantideParcelaProduto value for this ProdutoType.
     * 
     * @param quantideParcelaProduto
     */
    public void setQuantideParcelaProduto(int quantideParcelaProduto) {
        this.quantideParcelaProduto = quantideParcelaProduto;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProdutoType)) return false;
        ProdutoType other = (ProdutoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto()))) &&
            ((this.percentualTaxaPadrao==null && other.getPercentualTaxaPadrao()==null) || 
             (this.percentualTaxaPadrao!=null &&
              this.percentualTaxaPadrao.equals(other.getPercentualTaxaPadrao()))) &&
            this.quantideParcelaProduto == other.getQuantideParcelaProduto();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        if (getPercentualTaxaPadrao() != null) {
            _hashCode += getPercentualTaxaPadrao().hashCode();
        }
        _hashCode += getQuantideParcelaProduto();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProdutoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "produtoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaPadrao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "percentualTaxaPadrao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantideParcelaProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "quantideParcelaProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
