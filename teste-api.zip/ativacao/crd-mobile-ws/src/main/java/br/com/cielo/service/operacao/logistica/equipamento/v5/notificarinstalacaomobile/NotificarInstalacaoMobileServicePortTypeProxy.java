package br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile;

public class NotificarInstalacaoMobileServicePortTypeProxy implements br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileServicePortType {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileServicePortType notificarInstalacaoMobileServicePortType = null;
  
  public NotificarInstalacaoMobileServicePortTypeProxy() {
    _initNotificarInstalacaoMobileServicePortTypeProxy();
  }
  
  public NotificarInstalacaoMobileServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initNotificarInstalacaoMobileServicePortTypeProxy();
  }
  
  private void _initNotificarInstalacaoMobileServicePortTypeProxy() {
    try {
      notificarInstalacaoMobileServicePortType = (new br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileServiceSOAPBindingQSServiceLocator()).getNotificarInstalacaoMobileServiceSOAPBindingQSPort();
      if (notificarInstalacaoMobileServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)notificarInstalacaoMobileServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)notificarInstalacaoMobileServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (notificarInstalacaoMobileServicePortType != null)
      ((javax.xml.rpc.Stub)notificarInstalacaoMobileServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileServicePortType getNotificarInstalacaoMobileServicePortType() {
    if (notificarInstalacaoMobileServicePortType == null)
      _initNotificarInstalacaoMobileServicePortTypeProxy();
    return notificarInstalacaoMobileServicePortType;
  }
  
  public br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileResponse notificarInstalacaoMobile(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.logistica.equipamento.v5.notificarinstalacaomobile.NotificarInstalacaoMobileRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (notificarInstalacaoMobileServicePortType == null)
      _initNotificarInstalacaoMobileServicePortTypeProxy();
    return notificarInstalacaoMobileServicePortType.notificarInstalacaoMobile(header, parameters);
  }
  
  
}