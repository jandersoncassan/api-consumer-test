/**
 * ConsultarDomicilioBancarioResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ConsultarDomicilioBancarioResponse  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoType[] domiciliosBancarios;

    private java.lang.String proximoRegistro;  // attribute

    private java.lang.String chavePaginacao;  // attribute

    public ConsultarDomicilioBancarioResponse() {
    }

    public ConsultarDomicilioBancarioResponse(
           br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoType[] domiciliosBancarios,
           java.lang.String proximoRegistro,
           java.lang.String chavePaginacao) {
           this.domiciliosBancarios = domiciliosBancarios;
           this.proximoRegistro = proximoRegistro;
           this.chavePaginacao = chavePaginacao;
    }


    /**
     * Gets the domiciliosBancarios value for this ConsultarDomicilioBancarioResponse.
     * 
     * @return domiciliosBancarios
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoType[] getDomiciliosBancarios() {
        return domiciliosBancarios;
    }


    /**
     * Sets the domiciliosBancarios value for this ConsultarDomicilioBancarioResponse.
     * 
     * @param domiciliosBancarios
     */
    public void setDomiciliosBancarios(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoType[] domiciliosBancarios) {
        this.domiciliosBancarios = domiciliosBancarios;
    }


    /**
     * Gets the proximoRegistro value for this ConsultarDomicilioBancarioResponse.
     * 
     * @return proximoRegistro
     */
    public java.lang.String getProximoRegistro() {
        return proximoRegistro;
    }


    /**
     * Sets the proximoRegistro value for this ConsultarDomicilioBancarioResponse.
     * 
     * @param proximoRegistro
     */
    public void setProximoRegistro(java.lang.String proximoRegistro) {
        this.proximoRegistro = proximoRegistro;
    }


    /**
     * Gets the chavePaginacao value for this ConsultarDomicilioBancarioResponse.
     * 
     * @return chavePaginacao
     */
    public java.lang.String getChavePaginacao() {
        return chavePaginacao;
    }


    /**
     * Sets the chavePaginacao value for this ConsultarDomicilioBancarioResponse.
     * 
     * @param chavePaginacao
     */
    public void setChavePaginacao(java.lang.String chavePaginacao) {
        this.chavePaginacao = chavePaginacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDomicilioBancarioResponse)) return false;
        ConsultarDomicilioBancarioResponse other = (ConsultarDomicilioBancarioResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.domiciliosBancarios==null && other.getDomiciliosBancarios()==null) || 
             (this.domiciliosBancarios!=null &&
              java.util.Arrays.equals(this.domiciliosBancarios, other.getDomiciliosBancarios()))) &&
            ((this.proximoRegistro==null && other.getProximoRegistro()==null) || 
             (this.proximoRegistro!=null &&
              this.proximoRegistro.equals(other.getProximoRegistro()))) &&
            ((this.chavePaginacao==null && other.getChavePaginacao()==null) || 
             (this.chavePaginacao!=null &&
              this.chavePaginacao.equals(other.getChavePaginacao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDomiciliosBancarios() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDomiciliosBancarios());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDomiciliosBancarios(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProximoRegistro() != null) {
            _hashCode += getProximoRegistro().hashCode();
        }
        if (getChavePaginacao() != null) {
            _hashCode += getChavePaginacao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDomicilioBancarioResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioResponse"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("proximoRegistro");
        attrField.setXmlName(new javax.xml.namespace.QName("", "proximoRegistro"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("chavePaginacao");
        attrField.setXmlName(new javax.xml.namespace.QName("", "chavePaginacao"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domiciliosBancarios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "domiciliosBancarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioTruncadoType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "domicilioBancario"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
