/**
 * AlterarParcelaFaixaProdutoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class AlterarParcelaFaixaProdutoRequest  implements java.io.Serializable {
    /* Numero Protocolo do CRM */
    private java.lang.String protocolo;

    /* Codigo adotado pela Cielo para identificar o
     * 							Cliente */
    private java.lang.Long codigoCliente;

    /* Codigo do produto oferecido pela Cielo aos seus
     * 							clientes */
    private java.math.BigInteger codigoProduto;

    /* Quantidade de parcelas (parcelado) contrado pelo
     * 							client. */
    private java.math.BigInteger quantidadeParcelas;

    /* Percentual da taxa sobre o valor transacionado (que
     * 							serve de remuneracao pelo produto/servico prestado) contratado
     * 							pelo cliente.
     * 							Referencia: TBESPREC_PCTXA (SEC/ES). */
    private java.math.BigDecimal percentualTaxa;

    /* Lista de faixa de taxas de um produto parcelado
     * 							contradado pelo cliente. */
    private br.com.cielo.service.cadastro.produto.produto.v3.FaixaTaxaSegmentado[] dadosFaixaTaxaSegmentado;

    public AlterarParcelaFaixaProdutoRequest() {
    }

    public AlterarParcelaFaixaProdutoRequest(
           java.lang.String protocolo,
           java.lang.Long codigoCliente,
           java.math.BigInteger codigoProduto,
           java.math.BigInteger quantidadeParcelas,
           java.math.BigDecimal percentualTaxa,
           br.com.cielo.service.cadastro.produto.produto.v3.FaixaTaxaSegmentado[] dadosFaixaTaxaSegmentado) {
           this.protocolo = protocolo;
           this.codigoCliente = codigoCliente;
           this.codigoProduto = codigoProduto;
           this.quantidadeParcelas = quantidadeParcelas;
           this.percentualTaxa = percentualTaxa;
           this.dadosFaixaTaxaSegmentado = dadosFaixaTaxaSegmentado;
    }


    /**
     * Gets the protocolo value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @return protocolo   * Numero Protocolo do CRM
     */
    public java.lang.String getProtocolo() {
        return protocolo;
    }


    /**
     * Sets the protocolo value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @param protocolo   * Numero Protocolo do CRM
     */
    public void setProtocolo(java.lang.String protocolo) {
        this.protocolo = protocolo;
    }


    /**
     * Gets the codigoCliente value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the codigoProduto value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @return codigoProduto   * Codigo do produto oferecido pela Cielo aos seus
     * 							clientes
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @param codigoProduto   * Codigo do produto oferecido pela Cielo aos seus
     * 							clientes
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the quantidadeParcelas value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @return quantidadeParcelas   * Quantidade de parcelas (parcelado) contrado pelo
     * 							client.
     */
    public java.math.BigInteger getQuantidadeParcelas() {
        return quantidadeParcelas;
    }


    /**
     * Sets the quantidadeParcelas value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @param quantidadeParcelas   * Quantidade de parcelas (parcelado) contrado pelo
     * 							client.
     */
    public void setQuantidadeParcelas(java.math.BigInteger quantidadeParcelas) {
        this.quantidadeParcelas = quantidadeParcelas;
    }


    /**
     * Gets the percentualTaxa value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @return percentualTaxa   * Percentual da taxa sobre o valor transacionado (que
     * 							serve de remuneracao pelo produto/servico prestado) contratado
     * 							pelo cliente.
     * 							Referencia: TBESPREC_PCTXA (SEC/ES).
     */
    public java.math.BigDecimal getPercentualTaxa() {
        return percentualTaxa;
    }


    /**
     * Sets the percentualTaxa value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @param percentualTaxa   * Percentual da taxa sobre o valor transacionado (que
     * 							serve de remuneracao pelo produto/servico prestado) contratado
     * 							pelo cliente.
     * 							Referencia: TBESPREC_PCTXA (SEC/ES).
     */
    public void setPercentualTaxa(java.math.BigDecimal percentualTaxa) {
        this.percentualTaxa = percentualTaxa;
    }


    /**
     * Gets the dadosFaixaTaxaSegmentado value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @return dadosFaixaTaxaSegmentado   * Lista de faixa de taxas de um produto parcelado
     * 							contradado pelo cliente.
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.FaixaTaxaSegmentado[] getDadosFaixaTaxaSegmentado() {
        return dadosFaixaTaxaSegmentado;
    }


    /**
     * Sets the dadosFaixaTaxaSegmentado value for this AlterarParcelaFaixaProdutoRequest.
     * 
     * @param dadosFaixaTaxaSegmentado   * Lista de faixa de taxas de um produto parcelado
     * 							contradado pelo cliente.
     */
    public void setDadosFaixaTaxaSegmentado(br.com.cielo.service.cadastro.produto.produto.v3.FaixaTaxaSegmentado[] dadosFaixaTaxaSegmentado) {
        this.dadosFaixaTaxaSegmentado = dadosFaixaTaxaSegmentado;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarParcelaFaixaProdutoRequest)) return false;
        AlterarParcelaFaixaProdutoRequest other = (AlterarParcelaFaixaProdutoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.protocolo==null && other.getProtocolo()==null) || 
             (this.protocolo!=null &&
              this.protocolo.equals(other.getProtocolo()))) &&
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto()))) &&
            ((this.quantidadeParcelas==null && other.getQuantidadeParcelas()==null) || 
             (this.quantidadeParcelas!=null &&
              this.quantidadeParcelas.equals(other.getQuantidadeParcelas()))) &&
            ((this.percentualTaxa==null && other.getPercentualTaxa()==null) || 
             (this.percentualTaxa!=null &&
              this.percentualTaxa.equals(other.getPercentualTaxa()))) &&
            ((this.dadosFaixaTaxaSegmentado==null && other.getDadosFaixaTaxaSegmentado()==null) || 
             (this.dadosFaixaTaxaSegmentado!=null &&
              java.util.Arrays.equals(this.dadosFaixaTaxaSegmentado, other.getDadosFaixaTaxaSegmentado())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProtocolo() != null) {
            _hashCode += getProtocolo().hashCode();
        }
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        if (getQuantidadeParcelas() != null) {
            _hashCode += getQuantidadeParcelas().hashCode();
        }
        if (getPercentualTaxa() != null) {
            _hashCode += getPercentualTaxa().hashCode();
        }
        if (getDadosFaixaTaxaSegmentado() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosFaixaTaxaSegmentado());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosFaixaTaxaSegmentado(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarParcelaFaixaProdutoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">alterarParcelaFaixaProdutoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protocolo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "protocolo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeParcelas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "quantidadeParcelas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "percentualTaxa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosFaixaTaxaSegmentado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosFaixaTaxaSegmentado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "FaixaTaxaSegmentado"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosFaixaTaxaSegmentado"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
