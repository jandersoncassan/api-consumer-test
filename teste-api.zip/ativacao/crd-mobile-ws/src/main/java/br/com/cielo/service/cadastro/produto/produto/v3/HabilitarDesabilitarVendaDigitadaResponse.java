/**
 * HabilitarDesabilitarVendaDigitadaResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class HabilitarDesabilitarVendaDigitadaResponse  implements java.io.Serializable {
    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    public HabilitarDesabilitarVendaDigitadaResponse() {
    }

    public HabilitarDesabilitarVendaDigitadaResponse(
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem) {
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the codigoRetorno value for this HabilitarDesabilitarVendaDigitadaResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this HabilitarDesabilitarVendaDigitadaResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this HabilitarDesabilitarVendaDigitadaResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this HabilitarDesabilitarVendaDigitadaResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HabilitarDesabilitarVendaDigitadaResponse)) return false;
        HabilitarDesabilitarVendaDigitadaResponse other = (HabilitarDesabilitarVendaDigitadaResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HabilitarDesabilitarVendaDigitadaResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">habilitarDesabilitarVendaDigitadaResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
