/**
 * Servico.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Catalogo de servicos disponibilizado pela Cielo aos clientes, como
 * por exemplo: Cielo Promo, extrato de venda diario, programa de pontos,
 * etc.
 */
public class Servico  implements java.io.Serializable {
    /* Codigo que identifica o servico disponibilizado pela Cielo
     * aos clientes (estabelecimento comercial). */
    private java.math.BigInteger codigoServico;

    /* Nome do servico disponibilizado pela Cielo aos clientes */
    private java.lang.String nomeServico;

    /* Descricao explicativa do servico, de modo a auxiliar na explicacao
     * do servico. */
    private java.lang.String descricaoServico;

    /* Data na qual o servico foi habilitado para o cliente. */
    private java.util.Calendar dataHabilitacaoServico;

    public Servico() {
    }

    public Servico(
           java.math.BigInteger codigoServico,
           java.lang.String nomeServico,
           java.lang.String descricaoServico,
           java.util.Calendar dataHabilitacaoServico) {
           this.codigoServico = codigoServico;
           this.nomeServico = nomeServico;
           this.descricaoServico = descricaoServico;
           this.dataHabilitacaoServico = dataHabilitacaoServico;
    }


    /**
     * Gets the codigoServico value for this Servico.
     * 
     * @return codigoServico   * Codigo que identifica o servico disponibilizado pela Cielo
     * aos clientes (estabelecimento comercial).
     */
    public java.math.BigInteger getCodigoServico() {
        return codigoServico;
    }


    /**
     * Sets the codigoServico value for this Servico.
     * 
     * @param codigoServico   * Codigo que identifica o servico disponibilizado pela Cielo
     * aos clientes (estabelecimento comercial).
     */
    public void setCodigoServico(java.math.BigInteger codigoServico) {
        this.codigoServico = codigoServico;
    }


    /**
     * Gets the nomeServico value for this Servico.
     * 
     * @return nomeServico   * Nome do servico disponibilizado pela Cielo aos clientes
     */
    public java.lang.String getNomeServico() {
        return nomeServico;
    }


    /**
     * Sets the nomeServico value for this Servico.
     * 
     * @param nomeServico   * Nome do servico disponibilizado pela Cielo aos clientes
     */
    public void setNomeServico(java.lang.String nomeServico) {
        this.nomeServico = nomeServico;
    }


    /**
     * Gets the descricaoServico value for this Servico.
     * 
     * @return descricaoServico   * Descricao explicativa do servico, de modo a auxiliar na explicacao
     * do servico.
     */
    public java.lang.String getDescricaoServico() {
        return descricaoServico;
    }


    /**
     * Sets the descricaoServico value for this Servico.
     * 
     * @param descricaoServico   * Descricao explicativa do servico, de modo a auxiliar na explicacao
     * do servico.
     */
    public void setDescricaoServico(java.lang.String descricaoServico) {
        this.descricaoServico = descricaoServico;
    }


    /**
     * Gets the dataHabilitacaoServico value for this Servico.
     * 
     * @return dataHabilitacaoServico   * Data na qual o servico foi habilitado para o cliente.
     */
    public java.util.Calendar getDataHabilitacaoServico() {
        return dataHabilitacaoServico;
    }


    /**
     * Sets the dataHabilitacaoServico value for this Servico.
     * 
     * @param dataHabilitacaoServico   * Data na qual o servico foi habilitado para o cliente.
     */
    public void setDataHabilitacaoServico(java.util.Calendar dataHabilitacaoServico) {
        this.dataHabilitacaoServico = dataHabilitacaoServico;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Servico)) return false;
        Servico other = (Servico) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoServico==null && other.getCodigoServico()==null) || 
             (this.codigoServico!=null &&
              this.codigoServico.equals(other.getCodigoServico()))) &&
            ((this.nomeServico==null && other.getNomeServico()==null) || 
             (this.nomeServico!=null &&
              this.nomeServico.equals(other.getNomeServico()))) &&
            ((this.descricaoServico==null && other.getDescricaoServico()==null) || 
             (this.descricaoServico!=null &&
              this.descricaoServico.equals(other.getDescricaoServico()))) &&
            ((this.dataHabilitacaoServico==null && other.getDataHabilitacaoServico()==null) || 
             (this.dataHabilitacaoServico!=null &&
              this.dataHabilitacaoServico.equals(other.getDataHabilitacaoServico())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoServico() != null) {
            _hashCode += getCodigoServico().hashCode();
        }
        if (getNomeServico() != null) {
            _hashCode += getNomeServico().hashCode();
        }
        if (getDescricaoServico() != null) {
            _hashCode += getDescricaoServico().hashCode();
        }
        if (getDataHabilitacaoServico() != null) {
            _hashCode += getDataHabilitacaoServico().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Servico.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Servico"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataHabilitacaoServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataHabilitacaoServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
