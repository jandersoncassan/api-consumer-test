/**
 * IncluirClienteServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente;

public interface IncluirClienteServicePortType extends java.rmi.Remote {

    /**
     * Operacao responsavel por inserir um
     * 				estabelecimento comercial em REDES.
     */
    public br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteResponse incluirCliente(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
