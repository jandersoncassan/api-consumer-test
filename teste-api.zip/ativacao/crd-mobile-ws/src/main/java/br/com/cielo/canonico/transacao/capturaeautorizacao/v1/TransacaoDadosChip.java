/**
 * TransacaoDadosChip.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.transacao.capturaeautorizacao.v1;


/**
 * Entidade responsavel pelo envio de infomacoes sobre o chip.
 * Esta e uma entidade fraca, sendo considerada apenas uma representacao
 * de um complex type de retorno ao servico.
 */
public class TransacaoDadosChip  implements java.io.Serializable {
    /* Conhecido como Application Interchange Profile */
    private java.lang.String descricaoProfileComunicacaoAplicacao;

    /* Conhecido como Application Transaction Counter do Cartao */
    private java.lang.String descricaoContadorAplicacaoTransacaoCartao;

    /* Conhecido como Card Sequence Number */
    private java.lang.String descricaoNumeroViaPortador;

    /* Informa qual a capacidade terminal do chip */
    private java.lang.String descricaoCapacidadeTerminal;

    /* Indicador se teve um script de retorno da autorizacao da transacao */
    private java.lang.String indicadorScript;

    /* Informacao hexadecimal de controle de informacoes do emissor */
    private java.lang.String descricaoControleEmissorCartao;

    /* Conhecido como Cardholder Verification Method Result */
    private java.lang.String descricaoResultadoVerificacaoPortadorCartao;

    /* Nome do pais no qual foi realizada a transacao. exemplos:
     * Brasil
     * Argentina */
    private java.lang.String nomePais;

    /* Data em que foi realizada a transacao */
    private java.util.Calendar dataTransacao;

    /* Numero DOC */
    private java.lang.String numeroDOC;

    /* Informacao retornada em hexadecimal para determinada operação.
     * Exemplo: Alteração de Senha. */
    private java.lang.String descricaoResultadoScript;

    /* Codigo CID */
    private java.lang.String codigoCID;

    /* Valor aleatorio utilizado na criptografia */
    private java.lang.String descricaoValorAleatorio;

    /* descricaoChaveDerivacao */
    private java.lang.String descricaoChaveDerivacao;

    /* Informacao de criptograma */
    private java.lang.String descricaoCriptograma;

    /* Informacao do tipo de criptograma utilizado */
    private java.lang.String nomeTipoCriptograma;

    /* Versao aplicada do criptograma. Conhecido como Criptogram Version
     * Number */
    private java.lang.String descricaoVersaoCriptograma;

    /* Informacao que retorna o resultado da verificacao do cartao
     * na transacao. conhecido como Card Verification Results */
    private java.lang.String descricaoResultadoVerificacaoCartao;

    /* Informacao que retorna o resultado da verificacao do terminal
     * na transacao. conhecido como Terminal Verification Result */
    private java.lang.String descricaoResultadoVerificacaoTerminal;

    /* Codigo do Chip */
    private java.lang.String codigoChip;

    /* Descricao do Chip */
    private java.lang.String descricaoChip;

    public TransacaoDadosChip() {
    }

    public TransacaoDadosChip(
           java.lang.String descricaoProfileComunicacaoAplicacao,
           java.lang.String descricaoContadorAplicacaoTransacaoCartao,
           java.lang.String descricaoNumeroViaPortador,
           java.lang.String descricaoCapacidadeTerminal,
           java.lang.String indicadorScript,
           java.lang.String descricaoControleEmissorCartao,
           java.lang.String descricaoResultadoVerificacaoPortadorCartao,
           java.lang.String nomePais,
           java.util.Calendar dataTransacao,
           java.lang.String numeroDOC,
           java.lang.String descricaoResultadoScript,
           java.lang.String codigoCID,
           java.lang.String descricaoValorAleatorio,
           java.lang.String descricaoChaveDerivacao,
           java.lang.String descricaoCriptograma,
           java.lang.String nomeTipoCriptograma,
           java.lang.String descricaoVersaoCriptograma,
           java.lang.String descricaoResultadoVerificacaoCartao,
           java.lang.String descricaoResultadoVerificacaoTerminal,
           java.lang.String codigoChip,
           java.lang.String descricaoChip) {
           this.descricaoProfileComunicacaoAplicacao = descricaoProfileComunicacaoAplicacao;
           this.descricaoContadorAplicacaoTransacaoCartao = descricaoContadorAplicacaoTransacaoCartao;
           this.descricaoNumeroViaPortador = descricaoNumeroViaPortador;
           this.descricaoCapacidadeTerminal = descricaoCapacidadeTerminal;
           this.indicadorScript = indicadorScript;
           this.descricaoControleEmissorCartao = descricaoControleEmissorCartao;
           this.descricaoResultadoVerificacaoPortadorCartao = descricaoResultadoVerificacaoPortadorCartao;
           this.nomePais = nomePais;
           this.dataTransacao = dataTransacao;
           this.numeroDOC = numeroDOC;
           this.descricaoResultadoScript = descricaoResultadoScript;
           this.codigoCID = codigoCID;
           this.descricaoValorAleatorio = descricaoValorAleatorio;
           this.descricaoChaveDerivacao = descricaoChaveDerivacao;
           this.descricaoCriptograma = descricaoCriptograma;
           this.nomeTipoCriptograma = nomeTipoCriptograma;
           this.descricaoVersaoCriptograma = descricaoVersaoCriptograma;
           this.descricaoResultadoVerificacaoCartao = descricaoResultadoVerificacaoCartao;
           this.descricaoResultadoVerificacaoTerminal = descricaoResultadoVerificacaoTerminal;
           this.codigoChip = codigoChip;
           this.descricaoChip = descricaoChip;
    }


    /**
     * Gets the descricaoProfileComunicacaoAplicacao value for this TransacaoDadosChip.
     * 
     * @return descricaoProfileComunicacaoAplicacao   * Conhecido como Application Interchange Profile
     */
    public java.lang.String getDescricaoProfileComunicacaoAplicacao() {
        return descricaoProfileComunicacaoAplicacao;
    }


    /**
     * Sets the descricaoProfileComunicacaoAplicacao value for this TransacaoDadosChip.
     * 
     * @param descricaoProfileComunicacaoAplicacao   * Conhecido como Application Interchange Profile
     */
    public void setDescricaoProfileComunicacaoAplicacao(java.lang.String descricaoProfileComunicacaoAplicacao) {
        this.descricaoProfileComunicacaoAplicacao = descricaoProfileComunicacaoAplicacao;
    }


    /**
     * Gets the descricaoContadorAplicacaoTransacaoCartao value for this TransacaoDadosChip.
     * 
     * @return descricaoContadorAplicacaoTransacaoCartao   * Conhecido como Application Transaction Counter do Cartao
     */
    public java.lang.String getDescricaoContadorAplicacaoTransacaoCartao() {
        return descricaoContadorAplicacaoTransacaoCartao;
    }


    /**
     * Sets the descricaoContadorAplicacaoTransacaoCartao value for this TransacaoDadosChip.
     * 
     * @param descricaoContadorAplicacaoTransacaoCartao   * Conhecido como Application Transaction Counter do Cartao
     */
    public void setDescricaoContadorAplicacaoTransacaoCartao(java.lang.String descricaoContadorAplicacaoTransacaoCartao) {
        this.descricaoContadorAplicacaoTransacaoCartao = descricaoContadorAplicacaoTransacaoCartao;
    }


    /**
     * Gets the descricaoNumeroViaPortador value for this TransacaoDadosChip.
     * 
     * @return descricaoNumeroViaPortador   * Conhecido como Card Sequence Number
     */
    public java.lang.String getDescricaoNumeroViaPortador() {
        return descricaoNumeroViaPortador;
    }


    /**
     * Sets the descricaoNumeroViaPortador value for this TransacaoDadosChip.
     * 
     * @param descricaoNumeroViaPortador   * Conhecido como Card Sequence Number
     */
    public void setDescricaoNumeroViaPortador(java.lang.String descricaoNumeroViaPortador) {
        this.descricaoNumeroViaPortador = descricaoNumeroViaPortador;
    }


    /**
     * Gets the descricaoCapacidadeTerminal value for this TransacaoDadosChip.
     * 
     * @return descricaoCapacidadeTerminal   * Informa qual a capacidade terminal do chip
     */
    public java.lang.String getDescricaoCapacidadeTerminal() {
        return descricaoCapacidadeTerminal;
    }


    /**
     * Sets the descricaoCapacidadeTerminal value for this TransacaoDadosChip.
     * 
     * @param descricaoCapacidadeTerminal   * Informa qual a capacidade terminal do chip
     */
    public void setDescricaoCapacidadeTerminal(java.lang.String descricaoCapacidadeTerminal) {
        this.descricaoCapacidadeTerminal = descricaoCapacidadeTerminal;
    }


    /**
     * Gets the indicadorScript value for this TransacaoDadosChip.
     * 
     * @return indicadorScript   * Indicador se teve um script de retorno da autorizacao da transacao
     */
    public java.lang.String getIndicadorScript() {
        return indicadorScript;
    }


    /**
     * Sets the indicadorScript value for this TransacaoDadosChip.
     * 
     * @param indicadorScript   * Indicador se teve um script de retorno da autorizacao da transacao
     */
    public void setIndicadorScript(java.lang.String indicadorScript) {
        this.indicadorScript = indicadorScript;
    }


    /**
     * Gets the descricaoControleEmissorCartao value for this TransacaoDadosChip.
     * 
     * @return descricaoControleEmissorCartao   * Informacao hexadecimal de controle de informacoes do emissor
     */
    public java.lang.String getDescricaoControleEmissorCartao() {
        return descricaoControleEmissorCartao;
    }


    /**
     * Sets the descricaoControleEmissorCartao value for this TransacaoDadosChip.
     * 
     * @param descricaoControleEmissorCartao   * Informacao hexadecimal de controle de informacoes do emissor
     */
    public void setDescricaoControleEmissorCartao(java.lang.String descricaoControleEmissorCartao) {
        this.descricaoControleEmissorCartao = descricaoControleEmissorCartao;
    }


    /**
     * Gets the descricaoResultadoVerificacaoPortadorCartao value for this TransacaoDadosChip.
     * 
     * @return descricaoResultadoVerificacaoPortadorCartao   * Conhecido como Cardholder Verification Method Result
     */
    public java.lang.String getDescricaoResultadoVerificacaoPortadorCartao() {
        return descricaoResultadoVerificacaoPortadorCartao;
    }


    /**
     * Sets the descricaoResultadoVerificacaoPortadorCartao value for this TransacaoDadosChip.
     * 
     * @param descricaoResultadoVerificacaoPortadorCartao   * Conhecido como Cardholder Verification Method Result
     */
    public void setDescricaoResultadoVerificacaoPortadorCartao(java.lang.String descricaoResultadoVerificacaoPortadorCartao) {
        this.descricaoResultadoVerificacaoPortadorCartao = descricaoResultadoVerificacaoPortadorCartao;
    }


    /**
     * Gets the nomePais value for this TransacaoDadosChip.
     * 
     * @return nomePais   * Nome do pais no qual foi realizada a transacao. exemplos:
     * Brasil
     * Argentina
     */
    public java.lang.String getNomePais() {
        return nomePais;
    }


    /**
     * Sets the nomePais value for this TransacaoDadosChip.
     * 
     * @param nomePais   * Nome do pais no qual foi realizada a transacao. exemplos:
     * Brasil
     * Argentina
     */
    public void setNomePais(java.lang.String nomePais) {
        this.nomePais = nomePais;
    }


    /**
     * Gets the dataTransacao value for this TransacaoDadosChip.
     * 
     * @return dataTransacao   * Data em que foi realizada a transacao
     */
    public java.util.Calendar getDataTransacao() {
        return dataTransacao;
    }


    /**
     * Sets the dataTransacao value for this TransacaoDadosChip.
     * 
     * @param dataTransacao   * Data em que foi realizada a transacao
     */
    public void setDataTransacao(java.util.Calendar dataTransacao) {
        this.dataTransacao = dataTransacao;
    }


    /**
     * Gets the numeroDOC value for this TransacaoDadosChip.
     * 
     * @return numeroDOC   * Numero DOC
     */
    public java.lang.String getNumeroDOC() {
        return numeroDOC;
    }


    /**
     * Sets the numeroDOC value for this TransacaoDadosChip.
     * 
     * @param numeroDOC   * Numero DOC
     */
    public void setNumeroDOC(java.lang.String numeroDOC) {
        this.numeroDOC = numeroDOC;
    }


    /**
     * Gets the descricaoResultadoScript value for this TransacaoDadosChip.
     * 
     * @return descricaoResultadoScript   * Informacao retornada em hexadecimal para determinada operação.
     * Exemplo: Alteração de Senha.
     */
    public java.lang.String getDescricaoResultadoScript() {
        return descricaoResultadoScript;
    }


    /**
     * Sets the descricaoResultadoScript value for this TransacaoDadosChip.
     * 
     * @param descricaoResultadoScript   * Informacao retornada em hexadecimal para determinada operação.
     * Exemplo: Alteração de Senha.
     */
    public void setDescricaoResultadoScript(java.lang.String descricaoResultadoScript) {
        this.descricaoResultadoScript = descricaoResultadoScript;
    }


    /**
     * Gets the codigoCID value for this TransacaoDadosChip.
     * 
     * @return codigoCID   * Codigo CID
     */
    public java.lang.String getCodigoCID() {
        return codigoCID;
    }


    /**
     * Sets the codigoCID value for this TransacaoDadosChip.
     * 
     * @param codigoCID   * Codigo CID
     */
    public void setCodigoCID(java.lang.String codigoCID) {
        this.codigoCID = codigoCID;
    }


    /**
     * Gets the descricaoValorAleatorio value for this TransacaoDadosChip.
     * 
     * @return descricaoValorAleatorio   * Valor aleatorio utilizado na criptografia
     */
    public java.lang.String getDescricaoValorAleatorio() {
        return descricaoValorAleatorio;
    }


    /**
     * Sets the descricaoValorAleatorio value for this TransacaoDadosChip.
     * 
     * @param descricaoValorAleatorio   * Valor aleatorio utilizado na criptografia
     */
    public void setDescricaoValorAleatorio(java.lang.String descricaoValorAleatorio) {
        this.descricaoValorAleatorio = descricaoValorAleatorio;
    }


    /**
     * Gets the descricaoChaveDerivacao value for this TransacaoDadosChip.
     * 
     * @return descricaoChaveDerivacao   * descricaoChaveDerivacao
     */
    public java.lang.String getDescricaoChaveDerivacao() {
        return descricaoChaveDerivacao;
    }


    /**
     * Sets the descricaoChaveDerivacao value for this TransacaoDadosChip.
     * 
     * @param descricaoChaveDerivacao   * descricaoChaveDerivacao
     */
    public void setDescricaoChaveDerivacao(java.lang.String descricaoChaveDerivacao) {
        this.descricaoChaveDerivacao = descricaoChaveDerivacao;
    }


    /**
     * Gets the descricaoCriptograma value for this TransacaoDadosChip.
     * 
     * @return descricaoCriptograma   * Informacao de criptograma
     */
    public java.lang.String getDescricaoCriptograma() {
        return descricaoCriptograma;
    }


    /**
     * Sets the descricaoCriptograma value for this TransacaoDadosChip.
     * 
     * @param descricaoCriptograma   * Informacao de criptograma
     */
    public void setDescricaoCriptograma(java.lang.String descricaoCriptograma) {
        this.descricaoCriptograma = descricaoCriptograma;
    }


    /**
     * Gets the nomeTipoCriptograma value for this TransacaoDadosChip.
     * 
     * @return nomeTipoCriptograma   * Informacao do tipo de criptograma utilizado
     */
    public java.lang.String getNomeTipoCriptograma() {
        return nomeTipoCriptograma;
    }


    /**
     * Sets the nomeTipoCriptograma value for this TransacaoDadosChip.
     * 
     * @param nomeTipoCriptograma   * Informacao do tipo de criptograma utilizado
     */
    public void setNomeTipoCriptograma(java.lang.String nomeTipoCriptograma) {
        this.nomeTipoCriptograma = nomeTipoCriptograma;
    }


    /**
     * Gets the descricaoVersaoCriptograma value for this TransacaoDadosChip.
     * 
     * @return descricaoVersaoCriptograma   * Versao aplicada do criptograma. Conhecido como Criptogram Version
     * Number
     */
    public java.lang.String getDescricaoVersaoCriptograma() {
        return descricaoVersaoCriptograma;
    }


    /**
     * Sets the descricaoVersaoCriptograma value for this TransacaoDadosChip.
     * 
     * @param descricaoVersaoCriptograma   * Versao aplicada do criptograma. Conhecido como Criptogram Version
     * Number
     */
    public void setDescricaoVersaoCriptograma(java.lang.String descricaoVersaoCriptograma) {
        this.descricaoVersaoCriptograma = descricaoVersaoCriptograma;
    }


    /**
     * Gets the descricaoResultadoVerificacaoCartao value for this TransacaoDadosChip.
     * 
     * @return descricaoResultadoVerificacaoCartao   * Informacao que retorna o resultado da verificacao do cartao
     * na transacao. conhecido como Card Verification Results
     */
    public java.lang.String getDescricaoResultadoVerificacaoCartao() {
        return descricaoResultadoVerificacaoCartao;
    }


    /**
     * Sets the descricaoResultadoVerificacaoCartao value for this TransacaoDadosChip.
     * 
     * @param descricaoResultadoVerificacaoCartao   * Informacao que retorna o resultado da verificacao do cartao
     * na transacao. conhecido como Card Verification Results
     */
    public void setDescricaoResultadoVerificacaoCartao(java.lang.String descricaoResultadoVerificacaoCartao) {
        this.descricaoResultadoVerificacaoCartao = descricaoResultadoVerificacaoCartao;
    }


    /**
     * Gets the descricaoResultadoVerificacaoTerminal value for this TransacaoDadosChip.
     * 
     * @return descricaoResultadoVerificacaoTerminal   * Informacao que retorna o resultado da verificacao do terminal
     * na transacao. conhecido como Terminal Verification Result
     */
    public java.lang.String getDescricaoResultadoVerificacaoTerminal() {
        return descricaoResultadoVerificacaoTerminal;
    }


    /**
     * Sets the descricaoResultadoVerificacaoTerminal value for this TransacaoDadosChip.
     * 
     * @param descricaoResultadoVerificacaoTerminal   * Informacao que retorna o resultado da verificacao do terminal
     * na transacao. conhecido como Terminal Verification Result
     */
    public void setDescricaoResultadoVerificacaoTerminal(java.lang.String descricaoResultadoVerificacaoTerminal) {
        this.descricaoResultadoVerificacaoTerminal = descricaoResultadoVerificacaoTerminal;
    }


    /**
     * Gets the codigoChip value for this TransacaoDadosChip.
     * 
     * @return codigoChip   * Codigo do Chip
     */
    public java.lang.String getCodigoChip() {
        return codigoChip;
    }


    /**
     * Sets the codigoChip value for this TransacaoDadosChip.
     * 
     * @param codigoChip   * Codigo do Chip
     */
    public void setCodigoChip(java.lang.String codigoChip) {
        this.codigoChip = codigoChip;
    }


    /**
     * Gets the descricaoChip value for this TransacaoDadosChip.
     * 
     * @return descricaoChip   * Descricao do Chip
     */
    public java.lang.String getDescricaoChip() {
        return descricaoChip;
    }


    /**
     * Sets the descricaoChip value for this TransacaoDadosChip.
     * 
     * @param descricaoChip   * Descricao do Chip
     */
    public void setDescricaoChip(java.lang.String descricaoChip) {
        this.descricaoChip = descricaoChip;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TransacaoDadosChip)) return false;
        TransacaoDadosChip other = (TransacaoDadosChip) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.descricaoProfileComunicacaoAplicacao==null && other.getDescricaoProfileComunicacaoAplicacao()==null) || 
             (this.descricaoProfileComunicacaoAplicacao!=null &&
              this.descricaoProfileComunicacaoAplicacao.equals(other.getDescricaoProfileComunicacaoAplicacao()))) &&
            ((this.descricaoContadorAplicacaoTransacaoCartao==null && other.getDescricaoContadorAplicacaoTransacaoCartao()==null) || 
             (this.descricaoContadorAplicacaoTransacaoCartao!=null &&
              this.descricaoContadorAplicacaoTransacaoCartao.equals(other.getDescricaoContadorAplicacaoTransacaoCartao()))) &&
            ((this.descricaoNumeroViaPortador==null && other.getDescricaoNumeroViaPortador()==null) || 
             (this.descricaoNumeroViaPortador!=null &&
              this.descricaoNumeroViaPortador.equals(other.getDescricaoNumeroViaPortador()))) &&
            ((this.descricaoCapacidadeTerminal==null && other.getDescricaoCapacidadeTerminal()==null) || 
             (this.descricaoCapacidadeTerminal!=null &&
              this.descricaoCapacidadeTerminal.equals(other.getDescricaoCapacidadeTerminal()))) &&
            ((this.indicadorScript==null && other.getIndicadorScript()==null) || 
             (this.indicadorScript!=null &&
              this.indicadorScript.equals(other.getIndicadorScript()))) &&
            ((this.descricaoControleEmissorCartao==null && other.getDescricaoControleEmissorCartao()==null) || 
             (this.descricaoControleEmissorCartao!=null &&
              this.descricaoControleEmissorCartao.equals(other.getDescricaoControleEmissorCartao()))) &&
            ((this.descricaoResultadoVerificacaoPortadorCartao==null && other.getDescricaoResultadoVerificacaoPortadorCartao()==null) || 
             (this.descricaoResultadoVerificacaoPortadorCartao!=null &&
              this.descricaoResultadoVerificacaoPortadorCartao.equals(other.getDescricaoResultadoVerificacaoPortadorCartao()))) &&
            ((this.nomePais==null && other.getNomePais()==null) || 
             (this.nomePais!=null &&
              this.nomePais.equals(other.getNomePais()))) &&
            ((this.dataTransacao==null && other.getDataTransacao()==null) || 
             (this.dataTransacao!=null &&
              this.dataTransacao.equals(other.getDataTransacao()))) &&
            ((this.numeroDOC==null && other.getNumeroDOC()==null) || 
             (this.numeroDOC!=null &&
              this.numeroDOC.equals(other.getNumeroDOC()))) &&
            ((this.descricaoResultadoScript==null && other.getDescricaoResultadoScript()==null) || 
             (this.descricaoResultadoScript!=null &&
              this.descricaoResultadoScript.equals(other.getDescricaoResultadoScript()))) &&
            ((this.codigoCID==null && other.getCodigoCID()==null) || 
             (this.codigoCID!=null &&
              this.codigoCID.equals(other.getCodigoCID()))) &&
            ((this.descricaoValorAleatorio==null && other.getDescricaoValorAleatorio()==null) || 
             (this.descricaoValorAleatorio!=null &&
              this.descricaoValorAleatorio.equals(other.getDescricaoValorAleatorio()))) &&
            ((this.descricaoChaveDerivacao==null && other.getDescricaoChaveDerivacao()==null) || 
             (this.descricaoChaveDerivacao!=null &&
              this.descricaoChaveDerivacao.equals(other.getDescricaoChaveDerivacao()))) &&
            ((this.descricaoCriptograma==null && other.getDescricaoCriptograma()==null) || 
             (this.descricaoCriptograma!=null &&
              this.descricaoCriptograma.equals(other.getDescricaoCriptograma()))) &&
            ((this.nomeTipoCriptograma==null && other.getNomeTipoCriptograma()==null) || 
             (this.nomeTipoCriptograma!=null &&
              this.nomeTipoCriptograma.equals(other.getNomeTipoCriptograma()))) &&
            ((this.descricaoVersaoCriptograma==null && other.getDescricaoVersaoCriptograma()==null) || 
             (this.descricaoVersaoCriptograma!=null &&
              this.descricaoVersaoCriptograma.equals(other.getDescricaoVersaoCriptograma()))) &&
            ((this.descricaoResultadoVerificacaoCartao==null && other.getDescricaoResultadoVerificacaoCartao()==null) || 
             (this.descricaoResultadoVerificacaoCartao!=null &&
              this.descricaoResultadoVerificacaoCartao.equals(other.getDescricaoResultadoVerificacaoCartao()))) &&
            ((this.descricaoResultadoVerificacaoTerminal==null && other.getDescricaoResultadoVerificacaoTerminal()==null) || 
             (this.descricaoResultadoVerificacaoTerminal!=null &&
              this.descricaoResultadoVerificacaoTerminal.equals(other.getDescricaoResultadoVerificacaoTerminal()))) &&
            ((this.codigoChip==null && other.getCodigoChip()==null) || 
             (this.codigoChip!=null &&
              this.codigoChip.equals(other.getCodigoChip()))) &&
            ((this.descricaoChip==null && other.getDescricaoChip()==null) || 
             (this.descricaoChip!=null &&
              this.descricaoChip.equals(other.getDescricaoChip())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDescricaoProfileComunicacaoAplicacao() != null) {
            _hashCode += getDescricaoProfileComunicacaoAplicacao().hashCode();
        }
        if (getDescricaoContadorAplicacaoTransacaoCartao() != null) {
            _hashCode += getDescricaoContadorAplicacaoTransacaoCartao().hashCode();
        }
        if (getDescricaoNumeroViaPortador() != null) {
            _hashCode += getDescricaoNumeroViaPortador().hashCode();
        }
        if (getDescricaoCapacidadeTerminal() != null) {
            _hashCode += getDescricaoCapacidadeTerminal().hashCode();
        }
        if (getIndicadorScript() != null) {
            _hashCode += getIndicadorScript().hashCode();
        }
        if (getDescricaoControleEmissorCartao() != null) {
            _hashCode += getDescricaoControleEmissorCartao().hashCode();
        }
        if (getDescricaoResultadoVerificacaoPortadorCartao() != null) {
            _hashCode += getDescricaoResultadoVerificacaoPortadorCartao().hashCode();
        }
        if (getNomePais() != null) {
            _hashCode += getNomePais().hashCode();
        }
        if (getDataTransacao() != null) {
            _hashCode += getDataTransacao().hashCode();
        }
        if (getNumeroDOC() != null) {
            _hashCode += getNumeroDOC().hashCode();
        }
        if (getDescricaoResultadoScript() != null) {
            _hashCode += getDescricaoResultadoScript().hashCode();
        }
        if (getCodigoCID() != null) {
            _hashCode += getCodigoCID().hashCode();
        }
        if (getDescricaoValorAleatorio() != null) {
            _hashCode += getDescricaoValorAleatorio().hashCode();
        }
        if (getDescricaoChaveDerivacao() != null) {
            _hashCode += getDescricaoChaveDerivacao().hashCode();
        }
        if (getDescricaoCriptograma() != null) {
            _hashCode += getDescricaoCriptograma().hashCode();
        }
        if (getNomeTipoCriptograma() != null) {
            _hashCode += getNomeTipoCriptograma().hashCode();
        }
        if (getDescricaoVersaoCriptograma() != null) {
            _hashCode += getDescricaoVersaoCriptograma().hashCode();
        }
        if (getDescricaoResultadoVerificacaoCartao() != null) {
            _hashCode += getDescricaoResultadoVerificacaoCartao().hashCode();
        }
        if (getDescricaoResultadoVerificacaoTerminal() != null) {
            _hashCode += getDescricaoResultadoVerificacaoTerminal().hashCode();
        }
        if (getCodigoChip() != null) {
            _hashCode += getCodigoChip().hashCode();
        }
        if (getDescricaoChip() != null) {
            _hashCode += getDescricaoChip().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TransacaoDadosChip.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "TransacaoDadosChip"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoProfileComunicacaoAplicacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoProfileComunicacaoAplicacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoContadorAplicacaoTransacaoCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoContadorAplicacaoTransacaoCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoNumeroViaPortador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoNumeroViaPortador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoCapacidadeTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoCapacidadeTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorScript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "indicadorScript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoControleEmissorCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoControleEmissorCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoResultadoVerificacaoPortadorCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoResultadoVerificacaoPortadorCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomePais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dataTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDOC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroDOC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoResultadoScript");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoResultadoScript"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoCID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoValorAleatorio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoValorAleatorio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoChaveDerivacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoChaveDerivacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoCriptograma");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoCriptograma"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoCriptograma");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeTipoCriptograma"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoVersaoCriptograma");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoVersaoCriptograma"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoResultadoVerificacaoCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoResultadoVerificacaoCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoResultadoVerificacaoTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoResultadoVerificacaoTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoChip");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoChip"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoChip");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoChip"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
