/**
 * AlterarSMSClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class AlterarSMSClienteResponse  implements java.io.Serializable {
    private java.lang.Long codigoCliente;

    private java.lang.String dddTelefone;

    private java.lang.String numeroTelefone;

    private java.util.Date dataManutencaoTelefone;

    private org.apache.axis.types.Time horaManutencaoTelefone;

    private java.lang.String status;

    public AlterarSMSClienteResponse() {
    }

    public AlterarSMSClienteResponse(
           java.lang.Long codigoCliente,
           java.lang.String dddTelefone,
           java.lang.String numeroTelefone,
           java.util.Date dataManutencaoTelefone,
           org.apache.axis.types.Time horaManutencaoTelefone,
           java.lang.String status) {
           this.codigoCliente = codigoCliente;
           this.dddTelefone = dddTelefone;
           this.numeroTelefone = numeroTelefone;
           this.dataManutencaoTelefone = dataManutencaoTelefone;
           this.horaManutencaoTelefone = horaManutencaoTelefone;
           this.status = status;
    }


    /**
     * Gets the codigoCliente value for this AlterarSMSClienteResponse.
     * 
     * @return codigoCliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this AlterarSMSClienteResponse.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the dddTelefone value for this AlterarSMSClienteResponse.
     * 
     * @return dddTelefone
     */
    public java.lang.String getDddTelefone() {
        return dddTelefone;
    }


    /**
     * Sets the dddTelefone value for this AlterarSMSClienteResponse.
     * 
     * @param dddTelefone
     */
    public void setDddTelefone(java.lang.String dddTelefone) {
        this.dddTelefone = dddTelefone;
    }


    /**
     * Gets the numeroTelefone value for this AlterarSMSClienteResponse.
     * 
     * @return numeroTelefone
     */
    public java.lang.String getNumeroTelefone() {
        return numeroTelefone;
    }


    /**
     * Sets the numeroTelefone value for this AlterarSMSClienteResponse.
     * 
     * @param numeroTelefone
     */
    public void setNumeroTelefone(java.lang.String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }


    /**
     * Gets the dataManutencaoTelefone value for this AlterarSMSClienteResponse.
     * 
     * @return dataManutencaoTelefone
     */
    public java.util.Date getDataManutencaoTelefone() {
        return dataManutencaoTelefone;
    }


    /**
     * Sets the dataManutencaoTelefone value for this AlterarSMSClienteResponse.
     * 
     * @param dataManutencaoTelefone
     */
    public void setDataManutencaoTelefone(java.util.Date dataManutencaoTelefone) {
        this.dataManutencaoTelefone = dataManutencaoTelefone;
    }


    /**
     * Gets the horaManutencaoTelefone value for this AlterarSMSClienteResponse.
     * 
     * @return horaManutencaoTelefone
     */
    public org.apache.axis.types.Time getHoraManutencaoTelefone() {
        return horaManutencaoTelefone;
    }


    /**
     * Sets the horaManutencaoTelefone value for this AlterarSMSClienteResponse.
     * 
     * @param horaManutencaoTelefone
     */
    public void setHoraManutencaoTelefone(org.apache.axis.types.Time horaManutencaoTelefone) {
        this.horaManutencaoTelefone = horaManutencaoTelefone;
    }


    /**
     * Gets the status value for this AlterarSMSClienteResponse.
     * 
     * @return status
     */
    public java.lang.String getStatus() {
        return status;
    }


    /**
     * Sets the status value for this AlterarSMSClienteResponse.
     * 
     * @param status
     */
    public void setStatus(java.lang.String status) {
        this.status = status;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarSMSClienteResponse)) return false;
        AlterarSMSClienteResponse other = (AlterarSMSClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.dddTelefone==null && other.getDddTelefone()==null) || 
             (this.dddTelefone!=null &&
              this.dddTelefone.equals(other.getDddTelefone()))) &&
            ((this.numeroTelefone==null && other.getNumeroTelefone()==null) || 
             (this.numeroTelefone!=null &&
              this.numeroTelefone.equals(other.getNumeroTelefone()))) &&
            ((this.dataManutencaoTelefone==null && other.getDataManutencaoTelefone()==null) || 
             (this.dataManutencaoTelefone!=null &&
              this.dataManutencaoTelefone.equals(other.getDataManutencaoTelefone()))) &&
            ((this.horaManutencaoTelefone==null && other.getHoraManutencaoTelefone()==null) || 
             (this.horaManutencaoTelefone!=null &&
              this.horaManutencaoTelefone.equals(other.getHoraManutencaoTelefone()))) &&
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getDddTelefone() != null) {
            _hashCode += getDddTelefone().hashCode();
        }
        if (getNumeroTelefone() != null) {
            _hashCode += getNumeroTelefone().hashCode();
        }
        if (getDataManutencaoTelefone() != null) {
            _hashCode += getDataManutencaoTelefone().hashCode();
        }
        if (getHoraManutencaoTelefone() != null) {
            _hashCode += getHoraManutencaoTelefone().hashCode();
        }
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarSMSClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarSMSClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dddTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "dddTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataManutencaoTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "dataManutencaoTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horaManutencaoTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "horaManutencaoTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "time"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
