/**
 * IncluirNumeroLogico_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico;

public interface IncluirNumeroLogico_Service extends javax.xml.rpc.Service {
    public java.lang.String getIncluirNumeroLogicoSOAPAddress();

    public br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_PortType getIncluirNumeroLogicoSOAP() throws javax.xml.rpc.ServiceException;

    public br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_PortType getIncluirNumeroLogicoSOAP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
