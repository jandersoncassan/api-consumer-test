/**
 * ServicoHabilitacaoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.servico.servico.v1;


/**
 * Tipo complexo que representa o resultado da habilitacao de produto.
 */
public class ServicoHabilitacaoType  implements java.io.Serializable {
    /* Codigo do servico */
    private java.math.BigInteger codigoServico;

    /* servico habilitado. */
    private boolean servicoHabilitado;

    /* Codigo de inconsistencia. */
    private java.math.BigInteger codigoInconsistencia;

    public ServicoHabilitacaoType() {
    }

    public ServicoHabilitacaoType(
           java.math.BigInteger codigoServico,
           boolean servicoHabilitado,
           java.math.BigInteger codigoInconsistencia) {
           this.codigoServico = codigoServico;
           this.servicoHabilitado = servicoHabilitado;
           this.codigoInconsistencia = codigoInconsistencia;
    }


    /**
     * Gets the codigoServico value for this ServicoHabilitacaoType.
     * 
     * @return codigoServico   * Codigo do servico
     */
    public java.math.BigInteger getCodigoServico() {
        return codigoServico;
    }


    /**
     * Sets the codigoServico value for this ServicoHabilitacaoType.
     * 
     * @param codigoServico   * Codigo do servico
     */
    public void setCodigoServico(java.math.BigInteger codigoServico) {
        this.codigoServico = codigoServico;
    }


    /**
     * Gets the servicoHabilitado value for this ServicoHabilitacaoType.
     * 
     * @return servicoHabilitado   * servico habilitado.
     */
    public boolean isServicoHabilitado() {
        return servicoHabilitado;
    }


    /**
     * Sets the servicoHabilitado value for this ServicoHabilitacaoType.
     * 
     * @param servicoHabilitado   * servico habilitado.
     */
    public void setServicoHabilitado(boolean servicoHabilitado) {
        this.servicoHabilitado = servicoHabilitado;
    }


    /**
     * Gets the codigoInconsistencia value for this ServicoHabilitacaoType.
     * 
     * @return codigoInconsistencia   * Codigo de inconsistencia.
     */
    public java.math.BigInteger getCodigoInconsistencia() {
        return codigoInconsistencia;
    }


    /**
     * Sets the codigoInconsistencia value for this ServicoHabilitacaoType.
     * 
     * @param codigoInconsistencia   * Codigo de inconsistencia.
     */
    public void setCodigoInconsistencia(java.math.BigInteger codigoInconsistencia) {
        this.codigoInconsistencia = codigoInconsistencia;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ServicoHabilitacaoType)) return false;
        ServicoHabilitacaoType other = (ServicoHabilitacaoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoServico==null && other.getCodigoServico()==null) || 
             (this.codigoServico!=null &&
              this.codigoServico.equals(other.getCodigoServico()))) &&
            this.servicoHabilitado == other.isServicoHabilitado() &&
            ((this.codigoInconsistencia==null && other.getCodigoInconsistencia()==null) || 
             (this.codigoInconsistencia!=null &&
              this.codigoInconsistencia.equals(other.getCodigoInconsistencia())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoServico() != null) {
            _hashCode += getCodigoServico().hashCode();
        }
        _hashCode += (isServicoHabilitado() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getCodigoInconsistencia() != null) {
            _hashCode += getCodigoInconsistencia().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ServicoHabilitacaoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "ServicoHabilitacaoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "codigoServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("servicoHabilitado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "servicoHabilitado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoInconsistencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "codigoInconsistencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
