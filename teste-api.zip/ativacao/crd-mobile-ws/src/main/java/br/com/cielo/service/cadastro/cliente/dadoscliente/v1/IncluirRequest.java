/**
 * IncluirRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;

public class IncluirRequest  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.Cliente cliente;

    /* Indicador que demonstra se a pessoa a ser credenciada e do
     * tipo Microempreendedora Individual. */
    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorMicroEmpreendedorIndividual indicadorMicroEmpreendedorIndividual;

    private long codigoBancoCredenciamento;

    private java.lang.String codigoRamoAtividade;

    private java.lang.String nomePessoaContato;

    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoType[] dadosEnderecoCliente;

    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneType[] dadosTelefoneCliente;

    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosProprietarioType[] dadosProprietariosCliente;

    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.BancoType dadosBancariosCliente;

    private java.lang.String nomePlaqueta;

    private java.math.BigInteger regionalAfiliadora;

    /* Indicador de que persistência deverá ser feita (S/N) */
    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorPersistencia indicadorPersistencia;

    public IncluirRequest() {
    }

    public IncluirRequest(
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.Cliente cliente,
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorMicroEmpreendedorIndividual indicadorMicroEmpreendedorIndividual,
           long codigoBancoCredenciamento,
           java.lang.String codigoRamoAtividade,
           java.lang.String nomePessoaContato,
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoType[] dadosEnderecoCliente,
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneType[] dadosTelefoneCliente,
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosProprietarioType[] dadosProprietariosCliente,
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.BancoType dadosBancariosCliente,
           java.lang.String nomePlaqueta,
           java.math.BigInteger regionalAfiliadora,
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorPersistencia indicadorPersistencia) {
           this.cliente = cliente;
           this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
           this.codigoBancoCredenciamento = codigoBancoCredenciamento;
           this.codigoRamoAtividade = codigoRamoAtividade;
           this.nomePessoaContato = nomePessoaContato;
           this.dadosEnderecoCliente = dadosEnderecoCliente;
           this.dadosTelefoneCliente = dadosTelefoneCliente;
           this.dadosProprietariosCliente = dadosProprietariosCliente;
           this.dadosBancariosCliente = dadosBancariosCliente;
           this.nomePlaqueta = nomePlaqueta;
           this.regionalAfiliadora = regionalAfiliadora;
           this.indicadorPersistencia = indicadorPersistencia;
    }


    /**
     * Gets the cliente value for this IncluirRequest.
     * 
     * @return cliente
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.Cliente getCliente() {
        return cliente;
    }


    /**
     * Sets the cliente value for this IncluirRequest.
     * 
     * @param cliente
     */
    public void setCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.Cliente cliente) {
        this.cliente = cliente;
    }


    /**
     * Gets the indicadorMicroEmpreendedorIndividual value for this IncluirRequest.
     * 
     * @return indicadorMicroEmpreendedorIndividual   * Indicador que demonstra se a pessoa a ser credenciada e do
     * tipo Microempreendedora Individual.
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorMicroEmpreendedorIndividual getIndicadorMicroEmpreendedorIndividual() {
        return indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Sets the indicadorMicroEmpreendedorIndividual value for this IncluirRequest.
     * 
     * @param indicadorMicroEmpreendedorIndividual   * Indicador que demonstra se a pessoa a ser credenciada e do
     * tipo Microempreendedora Individual.
     */
    public void setIndicadorMicroEmpreendedorIndividual(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorMicroEmpreendedorIndividual indicadorMicroEmpreendedorIndividual) {
        this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Gets the codigoBancoCredenciamento value for this IncluirRequest.
     * 
     * @return codigoBancoCredenciamento
     */
    public long getCodigoBancoCredenciamento() {
        return codigoBancoCredenciamento;
    }


    /**
     * Sets the codigoBancoCredenciamento value for this IncluirRequest.
     * 
     * @param codigoBancoCredenciamento
     */
    public void setCodigoBancoCredenciamento(long codigoBancoCredenciamento) {
        this.codigoBancoCredenciamento = codigoBancoCredenciamento;
    }


    /**
     * Gets the codigoRamoAtividade value for this IncluirRequest.
     * 
     * @return codigoRamoAtividade
     */
    public java.lang.String getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this IncluirRequest.
     * 
     * @param codigoRamoAtividade
     */
    public void setCodigoRamoAtividade(java.lang.String codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the nomePessoaContato value for this IncluirRequest.
     * 
     * @return nomePessoaContato
     */
    public java.lang.String getNomePessoaContato() {
        return nomePessoaContato;
    }


    /**
     * Sets the nomePessoaContato value for this IncluirRequest.
     * 
     * @param nomePessoaContato
     */
    public void setNomePessoaContato(java.lang.String nomePessoaContato) {
        this.nomePessoaContato = nomePessoaContato;
    }


    /**
     * Gets the dadosEnderecoCliente value for this IncluirRequest.
     * 
     * @return dadosEnderecoCliente
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoType[] getDadosEnderecoCliente() {
        return dadosEnderecoCliente;
    }


    /**
     * Sets the dadosEnderecoCliente value for this IncluirRequest.
     * 
     * @param dadosEnderecoCliente
     */
    public void setDadosEnderecoCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoType[] dadosEnderecoCliente) {
        this.dadosEnderecoCliente = dadosEnderecoCliente;
    }


    /**
     * Gets the dadosTelefoneCliente value for this IncluirRequest.
     * 
     * @return dadosTelefoneCliente
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneType[] getDadosTelefoneCliente() {
        return dadosTelefoneCliente;
    }


    /**
     * Sets the dadosTelefoneCliente value for this IncluirRequest.
     * 
     * @param dadosTelefoneCliente
     */
    public void setDadosTelefoneCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.TelefoneType[] dadosTelefoneCliente) {
        this.dadosTelefoneCliente = dadosTelefoneCliente;
    }


    /**
     * Gets the dadosProprietariosCliente value for this IncluirRequest.
     * 
     * @return dadosProprietariosCliente
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosProprietarioType[] getDadosProprietariosCliente() {
        return dadosProprietariosCliente;
    }


    /**
     * Sets the dadosProprietariosCliente value for this IncluirRequest.
     * 
     * @param dadosProprietariosCliente
     */
    public void setDadosProprietariosCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosProprietarioType[] dadosProprietariosCliente) {
        this.dadosProprietariosCliente = dadosProprietariosCliente;
    }


    /**
     * Gets the dadosBancariosCliente value for this IncluirRequest.
     * 
     * @return dadosBancariosCliente
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.BancoType getDadosBancariosCliente() {
        return dadosBancariosCliente;
    }


    /**
     * Sets the dadosBancariosCliente value for this IncluirRequest.
     * 
     * @param dadosBancariosCliente
     */
    public void setDadosBancariosCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.BancoType dadosBancariosCliente) {
        this.dadosBancariosCliente = dadosBancariosCliente;
    }


    /**
     * Gets the nomePlaqueta value for this IncluirRequest.
     * 
     * @return nomePlaqueta
     */
    public java.lang.String getNomePlaqueta() {
        return nomePlaqueta;
    }


    /**
     * Sets the nomePlaqueta value for this IncluirRequest.
     * 
     * @param nomePlaqueta
     */
    public void setNomePlaqueta(java.lang.String nomePlaqueta) {
        this.nomePlaqueta = nomePlaqueta;
    }


    /**
     * Gets the regionalAfiliadora value for this IncluirRequest.
     * 
     * @return regionalAfiliadora
     */
    public java.math.BigInteger getRegionalAfiliadora() {
        return regionalAfiliadora;
    }


    /**
     * Sets the regionalAfiliadora value for this IncluirRequest.
     * 
     * @param regionalAfiliadora
     */
    public void setRegionalAfiliadora(java.math.BigInteger regionalAfiliadora) {
        this.regionalAfiliadora = regionalAfiliadora;
    }


    /**
     * Gets the indicadorPersistencia value for this IncluirRequest.
     * 
     * @return indicadorPersistencia   * Indicador de que persistência deverá ser feita (S/N)
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorPersistencia getIndicadorPersistencia() {
        return indicadorPersistencia;
    }


    /**
     * Sets the indicadorPersistencia value for this IncluirRequest.
     * 
     * @param indicadorPersistencia   * Indicador de que persistência deverá ser feita (S/N)
     */
    public void setIndicadorPersistencia(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequestIndicadorPersistencia indicadorPersistencia) {
        this.indicadorPersistencia = indicadorPersistencia;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IncluirRequest)) return false;
        IncluirRequest other = (IncluirRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cliente==null && other.getCliente()==null) || 
             (this.cliente!=null &&
              this.cliente.equals(other.getCliente()))) &&
            ((this.indicadorMicroEmpreendedorIndividual==null && other.getIndicadorMicroEmpreendedorIndividual()==null) || 
             (this.indicadorMicroEmpreendedorIndividual!=null &&
              this.indicadorMicroEmpreendedorIndividual.equals(other.getIndicadorMicroEmpreendedorIndividual()))) &&
            this.codigoBancoCredenciamento == other.getCodigoBancoCredenciamento() &&
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade()))) &&
            ((this.nomePessoaContato==null && other.getNomePessoaContato()==null) || 
             (this.nomePessoaContato!=null &&
              this.nomePessoaContato.equals(other.getNomePessoaContato()))) &&
            ((this.dadosEnderecoCliente==null && other.getDadosEnderecoCliente()==null) || 
             (this.dadosEnderecoCliente!=null &&
              java.util.Arrays.equals(this.dadosEnderecoCliente, other.getDadosEnderecoCliente()))) &&
            ((this.dadosTelefoneCliente==null && other.getDadosTelefoneCliente()==null) || 
             (this.dadosTelefoneCliente!=null &&
              java.util.Arrays.equals(this.dadosTelefoneCliente, other.getDadosTelefoneCliente()))) &&
            ((this.dadosProprietariosCliente==null && other.getDadosProprietariosCliente()==null) || 
             (this.dadosProprietariosCliente!=null &&
              java.util.Arrays.equals(this.dadosProprietariosCliente, other.getDadosProprietariosCliente()))) &&
            ((this.dadosBancariosCliente==null && other.getDadosBancariosCliente()==null) || 
             (this.dadosBancariosCliente!=null &&
              this.dadosBancariosCliente.equals(other.getDadosBancariosCliente()))) &&
            ((this.nomePlaqueta==null && other.getNomePlaqueta()==null) || 
             (this.nomePlaqueta!=null &&
              this.nomePlaqueta.equals(other.getNomePlaqueta()))) &&
            ((this.regionalAfiliadora==null && other.getRegionalAfiliadora()==null) || 
             (this.regionalAfiliadora!=null &&
              this.regionalAfiliadora.equals(other.getRegionalAfiliadora()))) &&
            ((this.indicadorPersistencia==null && other.getIndicadorPersistencia()==null) || 
             (this.indicadorPersistencia!=null &&
              this.indicadorPersistencia.equals(other.getIndicadorPersistencia())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCliente() != null) {
            _hashCode += getCliente().hashCode();
        }
        if (getIndicadorMicroEmpreendedorIndividual() != null) {
            _hashCode += getIndicadorMicroEmpreendedorIndividual().hashCode();
        }
        _hashCode += new Long(getCodigoBancoCredenciamento()).hashCode();
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        if (getNomePessoaContato() != null) {
            _hashCode += getNomePessoaContato().hashCode();
        }
        if (getDadosEnderecoCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosEnderecoCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosEnderecoCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDadosTelefoneCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosTelefoneCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosTelefoneCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDadosProprietariosCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosProprietariosCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosProprietariosCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDadosBancariosCliente() != null) {
            _hashCode += getDadosBancariosCliente().hashCode();
        }
        if (getNomePlaqueta() != null) {
            _hashCode += getNomePlaqueta().hashCode();
        }
        if (getRegionalAfiliadora() != null) {
            _hashCode += getRegionalAfiliadora().hashCode();
        }
        if (getIndicadorPersistencia() != null) {
            _hashCode += getIndicadorPersistencia().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IncluirRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">incluirRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "cliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "Cliente"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMicroEmpreendedorIndividual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "indicadorMicroEmpreendedorIndividual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">>incluirRequest>indicadorMicroEmpreendedorIndividual"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBancoCredenciamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "codigoBancoCredenciamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePessoaContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "nomePessoaContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEnderecoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "dadosEnderecoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecoType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "endereco"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosTelefoneCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "dadosTelefoneCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "TelefoneType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "telefone"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosProprietariosCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "dadosProprietariosCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "DadosProprietarioType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "dadosProprietario"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosBancariosCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "dadosBancariosCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "BancoType"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePlaqueta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "nomePlaqueta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("regionalAfiliadora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "regionalAfiliadora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorPersistencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "indicadorPersistencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", ">>incluirRequest>indicadorPersistencia"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
