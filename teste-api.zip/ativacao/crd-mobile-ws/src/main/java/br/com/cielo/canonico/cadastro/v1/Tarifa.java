/**
 * Tarifa.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class Tarifa  implements java.io.Serializable {
    private java.math.BigInteger codigoTarifa;

    private java.lang.String nomeTipoTarifa;

    private java.lang.Double valorTarifa;

    private java.lang.Double valorItem;

    private java.math.BigInteger quantidadeParcelasLoja;

    private java.math.BigInteger quantidadeParcelasAdministradora;

    private java.lang.Double valorRemuneracao;

    private java.lang.Double valorTaxaGarantia;

    private java.lang.Double percentualTaxaGarantia;

    private java.math.BigInteger codigoGarantia;

    /* Percentual da taxa mdr (merchant discount rate) padrao definida
     * para o produto. */
    private java.lang.Double percentualTaxaPadrao;

    /* Percentual da taxa mdr (merchant discount rate) do produto
     * negociado para a matriz (para a cadeia centralizada). */
    private java.lang.Double percentualTaxaMatriz;

    /* Percentual de taxa mínima aceita para contratação do produto. */
    private java.lang.Double percentualTaxaMinima;

    /* Percentual de taxa máxima aceita para contratação do produto */
    private java.lang.Double percentualTaxaMaxima;

    /* Lista de faixa de taxas de um produto parcelado contratado
     * pelo cliente. */
    private br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado[] dadosFaixasTaxaSegmentado;

    public Tarifa() {
    }

    public Tarifa(
           java.math.BigInteger codigoTarifa,
           java.lang.String nomeTipoTarifa,
           java.lang.Double valorTarifa,
           java.lang.Double valorItem,
           java.math.BigInteger quantidadeParcelasLoja,
           java.math.BigInteger quantidadeParcelasAdministradora,
           java.lang.Double valorRemuneracao,
           java.lang.Double valorTaxaGarantia,
           java.lang.Double percentualTaxaGarantia,
           java.math.BigInteger codigoGarantia,
           java.lang.Double percentualTaxaPadrao,
           java.lang.Double percentualTaxaMatriz,
           java.lang.Double percentualTaxaMinima,
           java.lang.Double percentualTaxaMaxima,
           br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado[] dadosFaixasTaxaSegmentado) {
           this.codigoTarifa = codigoTarifa;
           this.nomeTipoTarifa = nomeTipoTarifa;
           this.valorTarifa = valorTarifa;
           this.valorItem = valorItem;
           this.quantidadeParcelasLoja = quantidadeParcelasLoja;
           this.quantidadeParcelasAdministradora = quantidadeParcelasAdministradora;
           this.valorRemuneracao = valorRemuneracao;
           this.valorTaxaGarantia = valorTaxaGarantia;
           this.percentualTaxaGarantia = percentualTaxaGarantia;
           this.codigoGarantia = codigoGarantia;
           this.percentualTaxaPadrao = percentualTaxaPadrao;
           this.percentualTaxaMatriz = percentualTaxaMatriz;
           this.percentualTaxaMinima = percentualTaxaMinima;
           this.percentualTaxaMaxima = percentualTaxaMaxima;
           this.dadosFaixasTaxaSegmentado = dadosFaixasTaxaSegmentado;
    }


    /**
     * Gets the codigoTarifa value for this Tarifa.
     * 
     * @return codigoTarifa
     */
    public java.math.BigInteger getCodigoTarifa() {
        return codigoTarifa;
    }


    /**
     * Sets the codigoTarifa value for this Tarifa.
     * 
     * @param codigoTarifa
     */
    public void setCodigoTarifa(java.math.BigInteger codigoTarifa) {
        this.codigoTarifa = codigoTarifa;
    }


    /**
     * Gets the nomeTipoTarifa value for this Tarifa.
     * 
     * @return nomeTipoTarifa
     */
    public java.lang.String getNomeTipoTarifa() {
        return nomeTipoTarifa;
    }


    /**
     * Sets the nomeTipoTarifa value for this Tarifa.
     * 
     * @param nomeTipoTarifa
     */
    public void setNomeTipoTarifa(java.lang.String nomeTipoTarifa) {
        this.nomeTipoTarifa = nomeTipoTarifa;
    }


    /**
     * Gets the valorTarifa value for this Tarifa.
     * 
     * @return valorTarifa
     */
    public java.lang.Double getValorTarifa() {
        return valorTarifa;
    }


    /**
     * Sets the valorTarifa value for this Tarifa.
     * 
     * @param valorTarifa
     */
    public void setValorTarifa(java.lang.Double valorTarifa) {
        this.valorTarifa = valorTarifa;
    }


    /**
     * Gets the valorItem value for this Tarifa.
     * 
     * @return valorItem
     */
    public java.lang.Double getValorItem() {
        return valorItem;
    }


    /**
     * Sets the valorItem value for this Tarifa.
     * 
     * @param valorItem
     */
    public void setValorItem(java.lang.Double valorItem) {
        this.valorItem = valorItem;
    }


    /**
     * Gets the quantidadeParcelasLoja value for this Tarifa.
     * 
     * @return quantidadeParcelasLoja
     */
    public java.math.BigInteger getQuantidadeParcelasLoja() {
        return quantidadeParcelasLoja;
    }


    /**
     * Sets the quantidadeParcelasLoja value for this Tarifa.
     * 
     * @param quantidadeParcelasLoja
     */
    public void setQuantidadeParcelasLoja(java.math.BigInteger quantidadeParcelasLoja) {
        this.quantidadeParcelasLoja = quantidadeParcelasLoja;
    }


    /**
     * Gets the quantidadeParcelasAdministradora value for this Tarifa.
     * 
     * @return quantidadeParcelasAdministradora
     */
    public java.math.BigInteger getQuantidadeParcelasAdministradora() {
        return quantidadeParcelasAdministradora;
    }


    /**
     * Sets the quantidadeParcelasAdministradora value for this Tarifa.
     * 
     * @param quantidadeParcelasAdministradora
     */
    public void setQuantidadeParcelasAdministradora(java.math.BigInteger quantidadeParcelasAdministradora) {
        this.quantidadeParcelasAdministradora = quantidadeParcelasAdministradora;
    }


    /**
     * Gets the valorRemuneracao value for this Tarifa.
     * 
     * @return valorRemuneracao
     */
    public java.lang.Double getValorRemuneracao() {
        return valorRemuneracao;
    }


    /**
     * Sets the valorRemuneracao value for this Tarifa.
     * 
     * @param valorRemuneracao
     */
    public void setValorRemuneracao(java.lang.Double valorRemuneracao) {
        this.valorRemuneracao = valorRemuneracao;
    }


    /**
     * Gets the valorTaxaGarantia value for this Tarifa.
     * 
     * @return valorTaxaGarantia
     */
    public java.lang.Double getValorTaxaGarantia() {
        return valorTaxaGarantia;
    }


    /**
     * Sets the valorTaxaGarantia value for this Tarifa.
     * 
     * @param valorTaxaGarantia
     */
    public void setValorTaxaGarantia(java.lang.Double valorTaxaGarantia) {
        this.valorTaxaGarantia = valorTaxaGarantia;
    }


    /**
     * Gets the percentualTaxaGarantia value for this Tarifa.
     * 
     * @return percentualTaxaGarantia
     */
    public java.lang.Double getPercentualTaxaGarantia() {
        return percentualTaxaGarantia;
    }


    /**
     * Sets the percentualTaxaGarantia value for this Tarifa.
     * 
     * @param percentualTaxaGarantia
     */
    public void setPercentualTaxaGarantia(java.lang.Double percentualTaxaGarantia) {
        this.percentualTaxaGarantia = percentualTaxaGarantia;
    }


    /**
     * Gets the codigoGarantia value for this Tarifa.
     * 
     * @return codigoGarantia
     */
    public java.math.BigInteger getCodigoGarantia() {
        return codigoGarantia;
    }


    /**
     * Sets the codigoGarantia value for this Tarifa.
     * 
     * @param codigoGarantia
     */
    public void setCodigoGarantia(java.math.BigInteger codigoGarantia) {
        this.codigoGarantia = codigoGarantia;
    }


    /**
     * Gets the percentualTaxaPadrao value for this Tarifa.
     * 
     * @return percentualTaxaPadrao   * Percentual da taxa mdr (merchant discount rate) padrao definida
     * para o produto.
     */
    public java.lang.Double getPercentualTaxaPadrao() {
        return percentualTaxaPadrao;
    }


    /**
     * Sets the percentualTaxaPadrao value for this Tarifa.
     * 
     * @param percentualTaxaPadrao   * Percentual da taxa mdr (merchant discount rate) padrao definida
     * para o produto.
     */
    public void setPercentualTaxaPadrao(java.lang.Double percentualTaxaPadrao) {
        this.percentualTaxaPadrao = percentualTaxaPadrao;
    }


    /**
     * Gets the percentualTaxaMatriz value for this Tarifa.
     * 
     * @return percentualTaxaMatriz   * Percentual da taxa mdr (merchant discount rate) do produto
     * negociado para a matriz (para a cadeia centralizada).
     */
    public java.lang.Double getPercentualTaxaMatriz() {
        return percentualTaxaMatriz;
    }


    /**
     * Sets the percentualTaxaMatriz value for this Tarifa.
     * 
     * @param percentualTaxaMatriz   * Percentual da taxa mdr (merchant discount rate) do produto
     * negociado para a matriz (para a cadeia centralizada).
     */
    public void setPercentualTaxaMatriz(java.lang.Double percentualTaxaMatriz) {
        this.percentualTaxaMatriz = percentualTaxaMatriz;
    }


    /**
     * Gets the percentualTaxaMinima value for this Tarifa.
     * 
     * @return percentualTaxaMinima   * Percentual de taxa mínima aceita para contratação do produto.
     */
    public java.lang.Double getPercentualTaxaMinima() {
        return percentualTaxaMinima;
    }


    /**
     * Sets the percentualTaxaMinima value for this Tarifa.
     * 
     * @param percentualTaxaMinima   * Percentual de taxa mínima aceita para contratação do produto.
     */
    public void setPercentualTaxaMinima(java.lang.Double percentualTaxaMinima) {
        this.percentualTaxaMinima = percentualTaxaMinima;
    }


    /**
     * Gets the percentualTaxaMaxima value for this Tarifa.
     * 
     * @return percentualTaxaMaxima   * Percentual de taxa máxima aceita para contratação do produto
     */
    public java.lang.Double getPercentualTaxaMaxima() {
        return percentualTaxaMaxima;
    }


    /**
     * Sets the percentualTaxaMaxima value for this Tarifa.
     * 
     * @param percentualTaxaMaxima   * Percentual de taxa máxima aceita para contratação do produto
     */
    public void setPercentualTaxaMaxima(java.lang.Double percentualTaxaMaxima) {
        this.percentualTaxaMaxima = percentualTaxaMaxima;
    }


    /**
     * Gets the dadosFaixasTaxaSegmentado value for this Tarifa.
     * 
     * @return dadosFaixasTaxaSegmentado   * Lista de faixa de taxas de um produto parcelado contratado
     * pelo cliente.
     */
    public br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado[] getDadosFaixasTaxaSegmentado() {
        return dadosFaixasTaxaSegmentado;
    }


    /**
     * Sets the dadosFaixasTaxaSegmentado value for this Tarifa.
     * 
     * @param dadosFaixasTaxaSegmentado   * Lista de faixa de taxas de um produto parcelado contratado
     * pelo cliente.
     */
    public void setDadosFaixasTaxaSegmentado(br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado[] dadosFaixasTaxaSegmentado) {
        this.dadosFaixasTaxaSegmentado = dadosFaixasTaxaSegmentado;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Tarifa)) return false;
        Tarifa other = (Tarifa) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTarifa==null && other.getCodigoTarifa()==null) || 
             (this.codigoTarifa!=null &&
              this.codigoTarifa.equals(other.getCodigoTarifa()))) &&
            ((this.nomeTipoTarifa==null && other.getNomeTipoTarifa()==null) || 
             (this.nomeTipoTarifa!=null &&
              this.nomeTipoTarifa.equals(other.getNomeTipoTarifa()))) &&
            ((this.valorTarifa==null && other.getValorTarifa()==null) || 
             (this.valorTarifa!=null &&
              this.valorTarifa.equals(other.getValorTarifa()))) &&
            ((this.valorItem==null && other.getValorItem()==null) || 
             (this.valorItem!=null &&
              this.valorItem.equals(other.getValorItem()))) &&
            ((this.quantidadeParcelasLoja==null && other.getQuantidadeParcelasLoja()==null) || 
             (this.quantidadeParcelasLoja!=null &&
              this.quantidadeParcelasLoja.equals(other.getQuantidadeParcelasLoja()))) &&
            ((this.quantidadeParcelasAdministradora==null && other.getQuantidadeParcelasAdministradora()==null) || 
             (this.quantidadeParcelasAdministradora!=null &&
              this.quantidadeParcelasAdministradora.equals(other.getQuantidadeParcelasAdministradora()))) &&
            ((this.valorRemuneracao==null && other.getValorRemuneracao()==null) || 
             (this.valorRemuneracao!=null &&
              this.valorRemuneracao.equals(other.getValorRemuneracao()))) &&
            ((this.valorTaxaGarantia==null && other.getValorTaxaGarantia()==null) || 
             (this.valorTaxaGarantia!=null &&
              this.valorTaxaGarantia.equals(other.getValorTaxaGarantia()))) &&
            ((this.percentualTaxaGarantia==null && other.getPercentualTaxaGarantia()==null) || 
             (this.percentualTaxaGarantia!=null &&
              this.percentualTaxaGarantia.equals(other.getPercentualTaxaGarantia()))) &&
            ((this.codigoGarantia==null && other.getCodigoGarantia()==null) || 
             (this.codigoGarantia!=null &&
              this.codigoGarantia.equals(other.getCodigoGarantia()))) &&
            ((this.percentualTaxaPadrao==null && other.getPercentualTaxaPadrao()==null) || 
             (this.percentualTaxaPadrao!=null &&
              this.percentualTaxaPadrao.equals(other.getPercentualTaxaPadrao()))) &&
            ((this.percentualTaxaMatriz==null && other.getPercentualTaxaMatriz()==null) || 
             (this.percentualTaxaMatriz!=null &&
              this.percentualTaxaMatriz.equals(other.getPercentualTaxaMatriz()))) &&
            ((this.percentualTaxaMinima==null && other.getPercentualTaxaMinima()==null) || 
             (this.percentualTaxaMinima!=null &&
              this.percentualTaxaMinima.equals(other.getPercentualTaxaMinima()))) &&
            ((this.percentualTaxaMaxima==null && other.getPercentualTaxaMaxima()==null) || 
             (this.percentualTaxaMaxima!=null &&
              this.percentualTaxaMaxima.equals(other.getPercentualTaxaMaxima()))) &&
            ((this.dadosFaixasTaxaSegmentado==null && other.getDadosFaixasTaxaSegmentado()==null) || 
             (this.dadosFaixasTaxaSegmentado!=null &&
              java.util.Arrays.equals(this.dadosFaixasTaxaSegmentado, other.getDadosFaixasTaxaSegmentado())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTarifa() != null) {
            _hashCode += getCodigoTarifa().hashCode();
        }
        if (getNomeTipoTarifa() != null) {
            _hashCode += getNomeTipoTarifa().hashCode();
        }
        if (getValorTarifa() != null) {
            _hashCode += getValorTarifa().hashCode();
        }
        if (getValorItem() != null) {
            _hashCode += getValorItem().hashCode();
        }
        if (getQuantidadeParcelasLoja() != null) {
            _hashCode += getQuantidadeParcelasLoja().hashCode();
        }
        if (getQuantidadeParcelasAdministradora() != null) {
            _hashCode += getQuantidadeParcelasAdministradora().hashCode();
        }
        if (getValorRemuneracao() != null) {
            _hashCode += getValorRemuneracao().hashCode();
        }
        if (getValorTaxaGarantia() != null) {
            _hashCode += getValorTaxaGarantia().hashCode();
        }
        if (getPercentualTaxaGarantia() != null) {
            _hashCode += getPercentualTaxaGarantia().hashCode();
        }
        if (getCodigoGarantia() != null) {
            _hashCode += getCodigoGarantia().hashCode();
        }
        if (getPercentualTaxaPadrao() != null) {
            _hashCode += getPercentualTaxaPadrao().hashCode();
        }
        if (getPercentualTaxaMatriz() != null) {
            _hashCode += getPercentualTaxaMatriz().hashCode();
        }
        if (getPercentualTaxaMinima() != null) {
            _hashCode += getPercentualTaxaMinima().hashCode();
        }
        if (getPercentualTaxaMaxima() != null) {
            _hashCode += getPercentualTaxaMaxima().hashCode();
        }
        if (getDadosFaixasTaxaSegmentado() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosFaixasTaxaSegmentado());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosFaixasTaxaSegmentado(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Tarifa.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Tarifa"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTarifa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoTarifa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoTarifa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeTipoTarifa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorTarifa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "valorTarifa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorItem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "valorItem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeParcelasLoja");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeParcelasLoja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeParcelasAdministradora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeParcelasAdministradora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorRemuneracao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "valorRemuneracao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorTaxaGarantia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "valorTaxaGarantia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaGarantia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxaGarantia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoGarantia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoGarantia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaPadrao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxaPadrao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaMatriz");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxaMatriz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaMinima");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxaMinima"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("percentualTaxaMaxima");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "percentualTaxaMaxima"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosFaixasTaxaSegmentado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosFaixasTaxaSegmentado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixaTaxaSegmentado"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosFaixaTaxaSegmentado"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
