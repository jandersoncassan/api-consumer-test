/**
 * NoHierarquiaCliente.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Entidade que define um no de hierarquia para um cliente.
 * Um no fica necessariamente em um nivel da hierarquia, que atualmente
 * pode ser os seguintes:
 * Cliente individual; Grupo pagamento; Grupo comercial; Grupo de relacionamento;
 * Grupo gerencial.
 */
public class NoHierarquiaCliente  implements java.io.Serializable {
    /* Codigo que identifica o no.
     * Como o codigo nao e um dominio e sim um identificador, que sera necessario
     * reenviar para os outros sistemas. */
    private java.lang.Long codigoNoHierarquia;

    /* Nome dado para este no da hierarquia.
     * Normalmwente este nome e delineado pelo cliente. */
    private java.lang.String nomeNoHierarquia;

    /* Codigo que identifica o no pai do no atual. */
    private java.lang.Long codigoNoHierarquiaPai;

    /* Codigo que indica o nivel hierarquico.
     * Atualmente, temos sua definicao no caso de uso UC2669, na regra de
     * negocio RN12684, e seus niveis atuais sao:
     * Cliente individual; Grupo pagamento; Grupo comercial; Grupo de relacionamento;
     * Grupo gerencial. */
    private java.lang.Long codigoNivelHierarquico;

    /* Nome do nivel hierarquico.
     * Atualmente, temos sua definicao no caso de uso UC2669, na regra de
     * negocio RN12684, e seus niveis atuais sao:
     * Cliente individual; Grupo pagamento; Grupo comercial; Grupo de relacionamento;
     * Grupo gerencial. */
    private java.lang.String nomeNivelHierarquico;

    /* Quantidade de nos filhos que este no contem.
     * Utilizado principalmente para o calculo de exibicao em tela. */
    private java.math.BigInteger quantidadeNoFilho;

    /* Codigo adotado pela Cielo para identificar o Cliente.
     * Este codigo sera apenas apresentado se o no estiver no ultimo nivel
     * possivel (nivel folha). */
    private java.lang.Long codigoCliente;

    /* Codigo que identifica uma visao da hierarquia, para manter
     * a mesma formacao durante a execucao de relatorios e calculos que encessitem
     * da hierarquia se mantenha com a mesma formacao. */
    private java.lang.Long codigoCiclo;

    /* Nome da forma de recebimento atrelada a este no, sendo preenchido
     * apenas quando o nivel da hierarquia for grupo de pagamento.
     * Dominio: Centralizada; Individual */
    private java.lang.String nomeFormaRecebimento;

    public NoHierarquiaCliente() {
    }

    public NoHierarquiaCliente(
           java.lang.Long codigoNoHierarquia,
           java.lang.String nomeNoHierarquia,
           java.lang.Long codigoNoHierarquiaPai,
           java.lang.Long codigoNivelHierarquico,
           java.lang.String nomeNivelHierarquico,
           java.math.BigInteger quantidadeNoFilho,
           java.lang.Long codigoCliente,
           java.lang.Long codigoCiclo,
           java.lang.String nomeFormaRecebimento) {
           this.codigoNoHierarquia = codigoNoHierarquia;
           this.nomeNoHierarquia = nomeNoHierarquia;
           this.codigoNoHierarquiaPai = codigoNoHierarquiaPai;
           this.codigoNivelHierarquico = codigoNivelHierarquico;
           this.nomeNivelHierarquico = nomeNivelHierarquico;
           this.quantidadeNoFilho = quantidadeNoFilho;
           this.codigoCliente = codigoCliente;
           this.codigoCiclo = codigoCiclo;
           this.nomeFormaRecebimento = nomeFormaRecebimento;
    }


    /**
     * Gets the codigoNoHierarquia value for this NoHierarquiaCliente.
     * 
     * @return codigoNoHierarquia   * Codigo que identifica o no.
     * Como o codigo nao e um dominio e sim um identificador, que sera necessario
     * reenviar para os outros sistemas.
     */
    public java.lang.Long getCodigoNoHierarquia() {
        return codigoNoHierarquia;
    }


    /**
     * Sets the codigoNoHierarquia value for this NoHierarquiaCliente.
     * 
     * @param codigoNoHierarquia   * Codigo que identifica o no.
     * Como o codigo nao e um dominio e sim um identificador, que sera necessario
     * reenviar para os outros sistemas.
     */
    public void setCodigoNoHierarquia(java.lang.Long codigoNoHierarquia) {
        this.codigoNoHierarquia = codigoNoHierarquia;
    }


    /**
     * Gets the nomeNoHierarquia value for this NoHierarquiaCliente.
     * 
     * @return nomeNoHierarquia   * Nome dado para este no da hierarquia.
     * Normalmwente este nome e delineado pelo cliente.
     */
    public java.lang.String getNomeNoHierarquia() {
        return nomeNoHierarquia;
    }


    /**
     * Sets the nomeNoHierarquia value for this NoHierarquiaCliente.
     * 
     * @param nomeNoHierarquia   * Nome dado para este no da hierarquia.
     * Normalmwente este nome e delineado pelo cliente.
     */
    public void setNomeNoHierarquia(java.lang.String nomeNoHierarquia) {
        this.nomeNoHierarquia = nomeNoHierarquia;
    }


    /**
     * Gets the codigoNoHierarquiaPai value for this NoHierarquiaCliente.
     * 
     * @return codigoNoHierarquiaPai   * Codigo que identifica o no pai do no atual.
     */
    public java.lang.Long getCodigoNoHierarquiaPai() {
        return codigoNoHierarquiaPai;
    }


    /**
     * Sets the codigoNoHierarquiaPai value for this NoHierarquiaCliente.
     * 
     * @param codigoNoHierarquiaPai   * Codigo que identifica o no pai do no atual.
     */
    public void setCodigoNoHierarquiaPai(java.lang.Long codigoNoHierarquiaPai) {
        this.codigoNoHierarquiaPai = codigoNoHierarquiaPai;
    }


    /**
     * Gets the codigoNivelHierarquico value for this NoHierarquiaCliente.
     * 
     * @return codigoNivelHierarquico   * Codigo que indica o nivel hierarquico.
     * Atualmente, temos sua definicao no caso de uso UC2669, na regra de
     * negocio RN12684, e seus niveis atuais sao:
     * Cliente individual; Grupo pagamento; Grupo comercial; Grupo de relacionamento;
     * Grupo gerencial.
     */
    public java.lang.Long getCodigoNivelHierarquico() {
        return codigoNivelHierarquico;
    }


    /**
     * Sets the codigoNivelHierarquico value for this NoHierarquiaCliente.
     * 
     * @param codigoNivelHierarquico   * Codigo que indica o nivel hierarquico.
     * Atualmente, temos sua definicao no caso de uso UC2669, na regra de
     * negocio RN12684, e seus niveis atuais sao:
     * Cliente individual; Grupo pagamento; Grupo comercial; Grupo de relacionamento;
     * Grupo gerencial.
     */
    public void setCodigoNivelHierarquico(java.lang.Long codigoNivelHierarquico) {
        this.codigoNivelHierarquico = codigoNivelHierarquico;
    }


    /**
     * Gets the nomeNivelHierarquico value for this NoHierarquiaCliente.
     * 
     * @return nomeNivelHierarquico   * Nome do nivel hierarquico.
     * Atualmente, temos sua definicao no caso de uso UC2669, na regra de
     * negocio RN12684, e seus niveis atuais sao:
     * Cliente individual; Grupo pagamento; Grupo comercial; Grupo de relacionamento;
     * Grupo gerencial.
     */
    public java.lang.String getNomeNivelHierarquico() {
        return nomeNivelHierarquico;
    }


    /**
     * Sets the nomeNivelHierarquico value for this NoHierarquiaCliente.
     * 
     * @param nomeNivelHierarquico   * Nome do nivel hierarquico.
     * Atualmente, temos sua definicao no caso de uso UC2669, na regra de
     * negocio RN12684, e seus niveis atuais sao:
     * Cliente individual; Grupo pagamento; Grupo comercial; Grupo de relacionamento;
     * Grupo gerencial.
     */
    public void setNomeNivelHierarquico(java.lang.String nomeNivelHierarquico) {
        this.nomeNivelHierarquico = nomeNivelHierarquico;
    }


    /**
     * Gets the quantidadeNoFilho value for this NoHierarquiaCliente.
     * 
     * @return quantidadeNoFilho   * Quantidade de nos filhos que este no contem.
     * Utilizado principalmente para o calculo de exibicao em tela.
     */
    public java.math.BigInteger getQuantidadeNoFilho() {
        return quantidadeNoFilho;
    }


    /**
     * Sets the quantidadeNoFilho value for this NoHierarquiaCliente.
     * 
     * @param quantidadeNoFilho   * Quantidade de nos filhos que este no contem.
     * Utilizado principalmente para o calculo de exibicao em tela.
     */
    public void setQuantidadeNoFilho(java.math.BigInteger quantidadeNoFilho) {
        this.quantidadeNoFilho = quantidadeNoFilho;
    }


    /**
     * Gets the codigoCliente value for this NoHierarquiaCliente.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente.
     * Este codigo sera apenas apresentado se o no estiver no ultimo nivel
     * possivel (nivel folha).
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this NoHierarquiaCliente.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente.
     * Este codigo sera apenas apresentado se o no estiver no ultimo nivel
     * possivel (nivel folha).
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the codigoCiclo value for this NoHierarquiaCliente.
     * 
     * @return codigoCiclo   * Codigo que identifica uma visao da hierarquia, para manter
     * a mesma formacao durante a execucao de relatorios e calculos que encessitem
     * da hierarquia se mantenha com a mesma formacao.
     */
    public java.lang.Long getCodigoCiclo() {
        return codigoCiclo;
    }


    /**
     * Sets the codigoCiclo value for this NoHierarquiaCliente.
     * 
     * @param codigoCiclo   * Codigo que identifica uma visao da hierarquia, para manter
     * a mesma formacao durante a execucao de relatorios e calculos que encessitem
     * da hierarquia se mantenha com a mesma formacao.
     */
    public void setCodigoCiclo(java.lang.Long codigoCiclo) {
        this.codigoCiclo = codigoCiclo;
    }


    /**
     * Gets the nomeFormaRecebimento value for this NoHierarquiaCliente.
     * 
     * @return nomeFormaRecebimento   * Nome da forma de recebimento atrelada a este no, sendo preenchido
     * apenas quando o nivel da hierarquia for grupo de pagamento.
     * Dominio: Centralizada; Individual
     */
    public java.lang.String getNomeFormaRecebimento() {
        return nomeFormaRecebimento;
    }


    /**
     * Sets the nomeFormaRecebimento value for this NoHierarquiaCliente.
     * 
     * @param nomeFormaRecebimento   * Nome da forma de recebimento atrelada a este no, sendo preenchido
     * apenas quando o nivel da hierarquia for grupo de pagamento.
     * Dominio: Centralizada; Individual
     */
    public void setNomeFormaRecebimento(java.lang.String nomeFormaRecebimento) {
        this.nomeFormaRecebimento = nomeFormaRecebimento;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NoHierarquiaCliente)) return false;
        NoHierarquiaCliente other = (NoHierarquiaCliente) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoNoHierarquia==null && other.getCodigoNoHierarquia()==null) || 
             (this.codigoNoHierarquia!=null &&
              this.codigoNoHierarquia.equals(other.getCodigoNoHierarquia()))) &&
            ((this.nomeNoHierarquia==null && other.getNomeNoHierarquia()==null) || 
             (this.nomeNoHierarquia!=null &&
              this.nomeNoHierarquia.equals(other.getNomeNoHierarquia()))) &&
            ((this.codigoNoHierarquiaPai==null && other.getCodigoNoHierarquiaPai()==null) || 
             (this.codigoNoHierarquiaPai!=null &&
              this.codigoNoHierarquiaPai.equals(other.getCodigoNoHierarquiaPai()))) &&
            ((this.codigoNivelHierarquico==null && other.getCodigoNivelHierarquico()==null) || 
             (this.codigoNivelHierarquico!=null &&
              this.codigoNivelHierarquico.equals(other.getCodigoNivelHierarquico()))) &&
            ((this.nomeNivelHierarquico==null && other.getNomeNivelHierarquico()==null) || 
             (this.nomeNivelHierarquico!=null &&
              this.nomeNivelHierarquico.equals(other.getNomeNivelHierarquico()))) &&
            ((this.quantidadeNoFilho==null && other.getQuantidadeNoFilho()==null) || 
             (this.quantidadeNoFilho!=null &&
              this.quantidadeNoFilho.equals(other.getQuantidadeNoFilho()))) &&
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.codigoCiclo==null && other.getCodigoCiclo()==null) || 
             (this.codigoCiclo!=null &&
              this.codigoCiclo.equals(other.getCodigoCiclo()))) &&
            ((this.nomeFormaRecebimento==null && other.getNomeFormaRecebimento()==null) || 
             (this.nomeFormaRecebimento!=null &&
              this.nomeFormaRecebimento.equals(other.getNomeFormaRecebimento())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoNoHierarquia() != null) {
            _hashCode += getCodigoNoHierarquia().hashCode();
        }
        if (getNomeNoHierarquia() != null) {
            _hashCode += getNomeNoHierarquia().hashCode();
        }
        if (getCodigoNoHierarquiaPai() != null) {
            _hashCode += getCodigoNoHierarquiaPai().hashCode();
        }
        if (getCodigoNivelHierarquico() != null) {
            _hashCode += getCodigoNivelHierarquico().hashCode();
        }
        if (getNomeNivelHierarquico() != null) {
            _hashCode += getNomeNivelHierarquico().hashCode();
        }
        if (getQuantidadeNoFilho() != null) {
            _hashCode += getQuantidadeNoFilho().hashCode();
        }
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getCodigoCiclo() != null) {
            _hashCode += getCodigoCiclo().hashCode();
        }
        if (getNomeFormaRecebimento() != null) {
            _hashCode += getNomeFormaRecebimento().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NoHierarquiaCliente.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "NoHierarquiaCliente"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoNoHierarquia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoNoHierarquia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeNoHierarquia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeNoHierarquia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoNoHierarquiaPai");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoNoHierarquiaPai"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoNivelHierarquico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoNivelHierarquico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeNivelHierarquico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeNivelHierarquico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeNoFilho");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeNoFilho"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCiclo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCiclo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFormaRecebimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeFormaRecebimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
