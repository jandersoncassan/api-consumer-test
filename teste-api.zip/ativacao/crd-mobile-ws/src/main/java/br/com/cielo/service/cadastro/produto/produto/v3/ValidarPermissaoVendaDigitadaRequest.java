/**
 * ValidarPermissaoVendaDigitadaRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ValidarPermissaoVendaDigitadaRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o
     * 							Cliente */
    private java.lang.Long codigoCliente;

    /* Indica se a validação é para operação de Habilitar
     * 							ou Desabilitar (H/D) */
    private java.lang.String indicaOperacao;

    /* Codigo definido pelas bandeiras Visa e Mastercard
     * 							para identificar um ramo de atividade Tambem conhecido como
     * MCC,
     * 							ele e adotado pela Cielo e por todos os adquirentes e emissores
     * 							do
     * 							mundo para classificar o ramo de negocio dos seus clientes. */
    private java.lang.String codigoRamoAtividade;

    public ValidarPermissaoVendaDigitadaRequest() {
    }

    public ValidarPermissaoVendaDigitadaRequest(
           java.lang.Long codigoCliente,
           java.lang.String indicaOperacao,
           java.lang.String codigoRamoAtividade) {
           this.codigoCliente = codigoCliente;
           this.indicaOperacao = indicaOperacao;
           this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the codigoCliente value for this ValidarPermissaoVendaDigitadaRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this ValidarPermissaoVendaDigitadaRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the indicaOperacao value for this ValidarPermissaoVendaDigitadaRequest.
     * 
     * @return indicaOperacao   * Indica se a validação é para operação de Habilitar
     * 							ou Desabilitar (H/D)
     */
    public java.lang.String getIndicaOperacao() {
        return indicaOperacao;
    }


    /**
     * Sets the indicaOperacao value for this ValidarPermissaoVendaDigitadaRequest.
     * 
     * @param indicaOperacao   * Indica se a validação é para operação de Habilitar
     * 							ou Desabilitar (H/D)
     */
    public void setIndicaOperacao(java.lang.String indicaOperacao) {
        this.indicaOperacao = indicaOperacao;
    }


    /**
     * Gets the codigoRamoAtividade value for this ValidarPermissaoVendaDigitadaRequest.
     * 
     * @return codigoRamoAtividade   * Codigo definido pelas bandeiras Visa e Mastercard
     * 							para identificar um ramo de atividade Tambem conhecido como
     * MCC,
     * 							ele e adotado pela Cielo e por todos os adquirentes e emissores
     * 							do
     * 							mundo para classificar o ramo de negocio dos seus clientes.
     */
    public java.lang.String getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this ValidarPermissaoVendaDigitadaRequest.
     * 
     * @param codigoRamoAtividade   * Codigo definido pelas bandeiras Visa e Mastercard
     * 							para identificar um ramo de atividade Tambem conhecido como
     * MCC,
     * 							ele e adotado pela Cielo e por todos os adquirentes e emissores
     * 							do
     * 							mundo para classificar o ramo de negocio dos seus clientes.
     */
    public void setCodigoRamoAtividade(java.lang.String codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidarPermissaoVendaDigitadaRequest)) return false;
        ValidarPermissaoVendaDigitadaRequest other = (ValidarPermissaoVendaDigitadaRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.indicaOperacao==null && other.getIndicaOperacao()==null) || 
             (this.indicaOperacao!=null &&
              this.indicaOperacao.equals(other.getIndicaOperacao()))) &&
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getIndicaOperacao() != null) {
            _hashCode += getIndicaOperacao().hashCode();
        }
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidarPermissaoVendaDigitadaRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">validarPermissaoVendaDigitadaRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicaOperacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "indicaOperacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
