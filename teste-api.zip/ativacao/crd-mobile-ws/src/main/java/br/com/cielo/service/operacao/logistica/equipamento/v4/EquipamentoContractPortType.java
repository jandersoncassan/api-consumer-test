/**
 * EquipamentoContractPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.logistica.equipamento.v4;

public interface EquipamentoContractPortType extends java.rmi.Remote {
    public br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoResponse notificarInstalacaoEquipamento(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarInstalacaoEquipamentoRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
    public br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCResponseType notificarNumeroLogicoGTeC(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.logistica.equipamento.v4.NotificarNumeroLogicoGTeCRequestType parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
