/**
 * VerificarExistenciaClienteRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class VerificarExistenciaClienteRequest  implements java.io.Serializable {
    /* Numero do CPF ou CNPJ a ser validado */
    private java.lang.String numeroCpfCnpj;

    public VerificarExistenciaClienteRequest() {
    }

    public VerificarExistenciaClienteRequest(
           java.lang.String numeroCpfCnpj) {
           this.numeroCpfCnpj = numeroCpfCnpj;
    }


    /**
     * Gets the numeroCpfCnpj value for this VerificarExistenciaClienteRequest.
     * 
     * @return numeroCpfCnpj   * Numero do CPF ou CNPJ a ser validado
     */
    public java.lang.String getNumeroCpfCnpj() {
        return numeroCpfCnpj;
    }


    /**
     * Sets the numeroCpfCnpj value for this VerificarExistenciaClienteRequest.
     * 
     * @param numeroCpfCnpj   * Numero do CPF ou CNPJ a ser validado
     */
    public void setNumeroCpfCnpj(java.lang.String numeroCpfCnpj) {
        this.numeroCpfCnpj = numeroCpfCnpj;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof VerificarExistenciaClienteRequest)) return false;
        VerificarExistenciaClienteRequest other = (VerificarExistenciaClienteRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroCpfCnpj==null && other.getNumeroCpfCnpj()==null) || 
             (this.numeroCpfCnpj!=null &&
              this.numeroCpfCnpj.equals(other.getNumeroCpfCnpj())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroCpfCnpj() != null) {
            _hashCode += getNumeroCpfCnpj().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(VerificarExistenciaClienteRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">verificarExistenciaClienteRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCpfCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroCpfCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
