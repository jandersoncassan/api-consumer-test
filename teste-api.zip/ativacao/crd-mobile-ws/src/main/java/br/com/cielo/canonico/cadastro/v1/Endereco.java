/**
 * Endereco.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class Endereco  implements java.io.Serializable {
    private java.lang.String nomeLogradouro;

    private java.lang.String descricaoComplementoEndereco;

    private java.lang.String nomeBairro;

    private java.lang.String nomeCidade;

    private java.lang.String siglaEstado;

    private java.lang.String numeroCEP;

    private java.lang.String numeroLogradouro;

    /* Nome do tipo do logradouro aplicado ao endereco. Exemplos:
     * Rua
     * Avenida
     * Praca */
    private java.lang.String nomeTipoLogradouro;

    /* Nome do pais no qual o endereco existe. exemplos:
     * Brasil
     * Argentina
     * Inglaterra */
    private java.lang.String nomePais;

    /* Numero Complemento CEP */
    private java.lang.String nomeComplementoCEP;

    /* Trecho Logradouro. (range) */
    private java.lang.String numeroComplementoCEP;

    /* Trecho Logradouro */
    private java.lang.String trechoLogradouro;

    /* Nome Categoria do Endereco */
    private java.lang.String[] categoriaEndereco;

    /* Nome do contato principal do endereco */
    private java.lang.String[] contatoEndereco;

    /* Telefone do contato principal do endereco */
    private java.lang.String[] telefoneContato;

    public Endereco() {
    }

    public Endereco(
           java.lang.String nomeLogradouro,
           java.lang.String descricaoComplementoEndereco,
           java.lang.String nomeBairro,
           java.lang.String nomeCidade,
           java.lang.String siglaEstado,
           java.lang.String numeroCEP,
           java.lang.String numeroLogradouro,
           java.lang.String nomeTipoLogradouro,
           java.lang.String nomePais,
           java.lang.String nomeComplementoCEP,
           java.lang.String numeroComplementoCEP,
           java.lang.String trechoLogradouro,
           java.lang.String[] categoriaEndereco,
           java.lang.String[] contatoEndereco,
           java.lang.String[] telefoneContato) {
           this.nomeLogradouro = nomeLogradouro;
           this.descricaoComplementoEndereco = descricaoComplementoEndereco;
           this.nomeBairro = nomeBairro;
           this.nomeCidade = nomeCidade;
           this.siglaEstado = siglaEstado;
           this.numeroCEP = numeroCEP;
           this.numeroLogradouro = numeroLogradouro;
           this.nomeTipoLogradouro = nomeTipoLogradouro;
           this.nomePais = nomePais;
           this.nomeComplementoCEP = nomeComplementoCEP;
           this.numeroComplementoCEP = numeroComplementoCEP;
           this.trechoLogradouro = trechoLogradouro;
           this.categoriaEndereco = categoriaEndereco;
           this.contatoEndereco = contatoEndereco;
           this.telefoneContato = telefoneContato;
    }


    /**
     * Gets the nomeLogradouro value for this Endereco.
     * 
     * @return nomeLogradouro
     */
    public java.lang.String getNomeLogradouro() {
        return nomeLogradouro;
    }


    /**
     * Sets the nomeLogradouro value for this Endereco.
     * 
     * @param nomeLogradouro
     */
    public void setNomeLogradouro(java.lang.String nomeLogradouro) {
        this.nomeLogradouro = nomeLogradouro;
    }


    /**
     * Gets the descricaoComplementoEndereco value for this Endereco.
     * 
     * @return descricaoComplementoEndereco
     */
    public java.lang.String getDescricaoComplementoEndereco() {
        return descricaoComplementoEndereco;
    }


    /**
     * Sets the descricaoComplementoEndereco value for this Endereco.
     * 
     * @param descricaoComplementoEndereco
     */
    public void setDescricaoComplementoEndereco(java.lang.String descricaoComplementoEndereco) {
        this.descricaoComplementoEndereco = descricaoComplementoEndereco;
    }


    /**
     * Gets the nomeBairro value for this Endereco.
     * 
     * @return nomeBairro
     */
    public java.lang.String getNomeBairro() {
        return nomeBairro;
    }


    /**
     * Sets the nomeBairro value for this Endereco.
     * 
     * @param nomeBairro
     */
    public void setNomeBairro(java.lang.String nomeBairro) {
        this.nomeBairro = nomeBairro;
    }


    /**
     * Gets the nomeCidade value for this Endereco.
     * 
     * @return nomeCidade
     */
    public java.lang.String getNomeCidade() {
        return nomeCidade;
    }


    /**
     * Sets the nomeCidade value for this Endereco.
     * 
     * @param nomeCidade
     */
    public void setNomeCidade(java.lang.String nomeCidade) {
        this.nomeCidade = nomeCidade;
    }


    /**
     * Gets the siglaEstado value for this Endereco.
     * 
     * @return siglaEstado
     */
    public java.lang.String getSiglaEstado() {
        return siglaEstado;
    }


    /**
     * Sets the siglaEstado value for this Endereco.
     * 
     * @param siglaEstado
     */
    public void setSiglaEstado(java.lang.String siglaEstado) {
        this.siglaEstado = siglaEstado;
    }


    /**
     * Gets the numeroCEP value for this Endereco.
     * 
     * @return numeroCEP
     */
    public java.lang.String getNumeroCEP() {
        return numeroCEP;
    }


    /**
     * Sets the numeroCEP value for this Endereco.
     * 
     * @param numeroCEP
     */
    public void setNumeroCEP(java.lang.String numeroCEP) {
        this.numeroCEP = numeroCEP;
    }


    /**
     * Gets the numeroLogradouro value for this Endereco.
     * 
     * @return numeroLogradouro
     */
    public java.lang.String getNumeroLogradouro() {
        return numeroLogradouro;
    }


    /**
     * Sets the numeroLogradouro value for this Endereco.
     * 
     * @param numeroLogradouro
     */
    public void setNumeroLogradouro(java.lang.String numeroLogradouro) {
        this.numeroLogradouro = numeroLogradouro;
    }


    /**
     * Gets the nomeTipoLogradouro value for this Endereco.
     * 
     * @return nomeTipoLogradouro   * Nome do tipo do logradouro aplicado ao endereco. Exemplos:
     * Rua
     * Avenida
     * Praca
     */
    public java.lang.String getNomeTipoLogradouro() {
        return nomeTipoLogradouro;
    }


    /**
     * Sets the nomeTipoLogradouro value for this Endereco.
     * 
     * @param nomeTipoLogradouro   * Nome do tipo do logradouro aplicado ao endereco. Exemplos:
     * Rua
     * Avenida
     * Praca
     */
    public void setNomeTipoLogradouro(java.lang.String nomeTipoLogradouro) {
        this.nomeTipoLogradouro = nomeTipoLogradouro;
    }


    /**
     * Gets the nomePais value for this Endereco.
     * 
     * @return nomePais   * Nome do pais no qual o endereco existe. exemplos:
     * Brasil
     * Argentina
     * Inglaterra
     */
    public java.lang.String getNomePais() {
        return nomePais;
    }


    /**
     * Sets the nomePais value for this Endereco.
     * 
     * @param nomePais   * Nome do pais no qual o endereco existe. exemplos:
     * Brasil
     * Argentina
     * Inglaterra
     */
    public void setNomePais(java.lang.String nomePais) {
        this.nomePais = nomePais;
    }


    /**
     * Gets the nomeComplementoCEP value for this Endereco.
     * 
     * @return nomeComplementoCEP   * Numero Complemento CEP
     */
    public java.lang.String getNomeComplementoCEP() {
        return nomeComplementoCEP;
    }


    /**
     * Sets the nomeComplementoCEP value for this Endereco.
     * 
     * @param nomeComplementoCEP   * Numero Complemento CEP
     */
    public void setNomeComplementoCEP(java.lang.String nomeComplementoCEP) {
        this.nomeComplementoCEP = nomeComplementoCEP;
    }


    /**
     * Gets the numeroComplementoCEP value for this Endereco.
     * 
     * @return numeroComplementoCEP   * Trecho Logradouro. (range)
     */
    public java.lang.String getNumeroComplementoCEP() {
        return numeroComplementoCEP;
    }


    /**
     * Sets the numeroComplementoCEP value for this Endereco.
     * 
     * @param numeroComplementoCEP   * Trecho Logradouro. (range)
     */
    public void setNumeroComplementoCEP(java.lang.String numeroComplementoCEP) {
        this.numeroComplementoCEP = numeroComplementoCEP;
    }


    /**
     * Gets the trechoLogradouro value for this Endereco.
     * 
     * @return trechoLogradouro   * Trecho Logradouro
     */
    public java.lang.String getTrechoLogradouro() {
        return trechoLogradouro;
    }


    /**
     * Sets the trechoLogradouro value for this Endereco.
     * 
     * @param trechoLogradouro   * Trecho Logradouro
     */
    public void setTrechoLogradouro(java.lang.String trechoLogradouro) {
        this.trechoLogradouro = trechoLogradouro;
    }


    /**
     * Gets the categoriaEndereco value for this Endereco.
     * 
     * @return categoriaEndereco   * Nome Categoria do Endereco
     */
    public java.lang.String[] getCategoriaEndereco() {
        return categoriaEndereco;
    }


    /**
     * Sets the categoriaEndereco value for this Endereco.
     * 
     * @param categoriaEndereco   * Nome Categoria do Endereco
     */
    public void setCategoriaEndereco(java.lang.String[] categoriaEndereco) {
        this.categoriaEndereco = categoriaEndereco;
    }

    public java.lang.String getCategoriaEndereco(int i) {
        return this.categoriaEndereco[i];
    }

    public void setCategoriaEndereco(int i, java.lang.String _value) {
        this.categoriaEndereco[i] = _value;
    }


    /**
     * Gets the contatoEndereco value for this Endereco.
     * 
     * @return contatoEndereco   * Nome do contato principal do endereco
     */
    public java.lang.String[] getContatoEndereco() {
        return contatoEndereco;
    }


    /**
     * Sets the contatoEndereco value for this Endereco.
     * 
     * @param contatoEndereco   * Nome do contato principal do endereco
     */
    public void setContatoEndereco(java.lang.String[] contatoEndereco) {
        this.contatoEndereco = contatoEndereco;
    }

    public java.lang.String getContatoEndereco(int i) {
        return this.contatoEndereco[i];
    }

    public void setContatoEndereco(int i, java.lang.String _value) {
        this.contatoEndereco[i] = _value;
    }


    /**
     * Gets the telefoneContato value for this Endereco.
     * 
     * @return telefoneContato   * Telefone do contato principal do endereco
     */
    public java.lang.String[] getTelefoneContato() {
        return telefoneContato;
    }


    /**
     * Sets the telefoneContato value for this Endereco.
     * 
     * @param telefoneContato   * Telefone do contato principal do endereco
     */
    public void setTelefoneContato(java.lang.String[] telefoneContato) {
        this.telefoneContato = telefoneContato;
    }

    public java.lang.String getTelefoneContato(int i) {
        return this.telefoneContato[i];
    }

    public void setTelefoneContato(int i, java.lang.String _value) {
        this.telefoneContato[i] = _value;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Endereco)) return false;
        Endereco other = (Endereco) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nomeLogradouro==null && other.getNomeLogradouro()==null) || 
             (this.nomeLogradouro!=null &&
              this.nomeLogradouro.equals(other.getNomeLogradouro()))) &&
            ((this.descricaoComplementoEndereco==null && other.getDescricaoComplementoEndereco()==null) || 
             (this.descricaoComplementoEndereco!=null &&
              this.descricaoComplementoEndereco.equals(other.getDescricaoComplementoEndereco()))) &&
            ((this.nomeBairro==null && other.getNomeBairro()==null) || 
             (this.nomeBairro!=null &&
              this.nomeBairro.equals(other.getNomeBairro()))) &&
            ((this.nomeCidade==null && other.getNomeCidade()==null) || 
             (this.nomeCidade!=null &&
              this.nomeCidade.equals(other.getNomeCidade()))) &&
            ((this.siglaEstado==null && other.getSiglaEstado()==null) || 
             (this.siglaEstado!=null &&
              this.siglaEstado.equals(other.getSiglaEstado()))) &&
            ((this.numeroCEP==null && other.getNumeroCEP()==null) || 
             (this.numeroCEP!=null &&
              this.numeroCEP.equals(other.getNumeroCEP()))) &&
            ((this.numeroLogradouro==null && other.getNumeroLogradouro()==null) || 
             (this.numeroLogradouro!=null &&
              this.numeroLogradouro.equals(other.getNumeroLogradouro()))) &&
            ((this.nomeTipoLogradouro==null && other.getNomeTipoLogradouro()==null) || 
             (this.nomeTipoLogradouro!=null &&
              this.nomeTipoLogradouro.equals(other.getNomeTipoLogradouro()))) &&
            ((this.nomePais==null && other.getNomePais()==null) || 
             (this.nomePais!=null &&
              this.nomePais.equals(other.getNomePais()))) &&
            ((this.nomeComplementoCEP==null && other.getNomeComplementoCEP()==null) || 
             (this.nomeComplementoCEP!=null &&
              this.nomeComplementoCEP.equals(other.getNomeComplementoCEP()))) &&
            ((this.numeroComplementoCEP==null && other.getNumeroComplementoCEP()==null) || 
             (this.numeroComplementoCEP!=null &&
              this.numeroComplementoCEP.equals(other.getNumeroComplementoCEP()))) &&
            ((this.trechoLogradouro==null && other.getTrechoLogradouro()==null) || 
             (this.trechoLogradouro!=null &&
              this.trechoLogradouro.equals(other.getTrechoLogradouro()))) &&
            ((this.categoriaEndereco==null && other.getCategoriaEndereco()==null) || 
             (this.categoriaEndereco!=null &&
              java.util.Arrays.equals(this.categoriaEndereco, other.getCategoriaEndereco()))) &&
            ((this.contatoEndereco==null && other.getContatoEndereco()==null) || 
             (this.contatoEndereco!=null &&
              java.util.Arrays.equals(this.contatoEndereco, other.getContatoEndereco()))) &&
            ((this.telefoneContato==null && other.getTelefoneContato()==null) || 
             (this.telefoneContato!=null &&
              java.util.Arrays.equals(this.telefoneContato, other.getTelefoneContato())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNomeLogradouro() != null) {
            _hashCode += getNomeLogradouro().hashCode();
        }
        if (getDescricaoComplementoEndereco() != null) {
            _hashCode += getDescricaoComplementoEndereco().hashCode();
        }
        if (getNomeBairro() != null) {
            _hashCode += getNomeBairro().hashCode();
        }
        if (getNomeCidade() != null) {
            _hashCode += getNomeCidade().hashCode();
        }
        if (getSiglaEstado() != null) {
            _hashCode += getSiglaEstado().hashCode();
        }
        if (getNumeroCEP() != null) {
            _hashCode += getNumeroCEP().hashCode();
        }
        if (getNumeroLogradouro() != null) {
            _hashCode += getNumeroLogradouro().hashCode();
        }
        if (getNomeTipoLogradouro() != null) {
            _hashCode += getNomeTipoLogradouro().hashCode();
        }
        if (getNomePais() != null) {
            _hashCode += getNomePais().hashCode();
        }
        if (getNomeComplementoCEP() != null) {
            _hashCode += getNomeComplementoCEP().hashCode();
        }
        if (getNumeroComplementoCEP() != null) {
            _hashCode += getNumeroComplementoCEP().hashCode();
        }
        if (getTrechoLogradouro() != null) {
            _hashCode += getTrechoLogradouro().hashCode();
        }
        if (getCategoriaEndereco() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCategoriaEndereco());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCategoriaEndereco(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getContatoEndereco() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getContatoEndereco());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getContatoEndereco(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTelefoneContato() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTelefoneContato());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTelefoneContato(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Endereco.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeLogradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeLogradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoComplementoEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "descricaoComplementoEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBairro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeBairro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeCidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeCidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("siglaEstado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "siglaEstado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCEP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroCEP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroLogradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoLogradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeTipoLogradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePais");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomePais"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeComplementoCEP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeComplementoCEP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroComplementoCEP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroComplementoCEP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("trechoLogradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "trechoLogradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("categoriaEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "categoriaEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contatoEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "contatoEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telefoneContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "telefoneContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
