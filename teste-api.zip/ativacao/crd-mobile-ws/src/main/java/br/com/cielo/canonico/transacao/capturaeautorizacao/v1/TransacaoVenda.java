/**
 * TransacaoVenda.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.transacao.capturaeautorizacao.v1;

public class TransacaoVenda  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar seu cliente. */
    private java.lang.Long codigoCliente;

    /* Numero que identifica um terminal de POS utilizado pelo cliente
     * da Cielo, onde atraves dele se realiza uma transacao de venda que
     * utiliza um cartao de credito, debito ou voucher */
    private java.lang.String numeroTerminal;

    /* Numero de referencia que identifica uma transacao capturada
     * pelo terminal POS do Cliente da Cielo. */
    private java.lang.String numeroReferenciaUnico;

    /* Valor bruto da venda realizada pelo cliente e que utilizou
     * o terminal da Cielo como forma  de pagamento. */
    private java.lang.Double valorBrutoVenda;

    /* Valor da comissao aplicado sobre o valor bruto da venda  realizada
     * pelo cliente utilizando o terminal da Cielo. */
    private java.lang.Double valorComissao;

    /* Valor subtraido do valor da comisscao que e repassado para
     * a Bandeira e para o emissor do cartao que foi utilizado na venda realizada
     * pelo cliente utilizando o terminal da Cielo. */
    private java.lang.Double valorIntercambio;

    /* Valor calculoda atraves da subtraacao do valor da comissao
     * e do intercambio sobre o valor bruto da venda realizada pelo cliente
     * utilizando o terminal da Cielo. */
    private java.lang.Double valorLiquido;

    /* Data da captura da transacao atribui�da pelos sistemas de redes
     * da Cielo. */
    private java.util.Date dataCaptura;

    /* Numero unico atribuido a uma transacao de venda pelo sistema
     * STAR  no momento em que e processada a sua captura. Este numero nao
     * corresponde ao NSU e nem ao Reference Number. */
    private java.lang.String codigoVenda;

    /* Data em que a transacao foi autorizada e o sistema de redes
     * a capturou transacao atribuida pelos sistemas de redes da Cielo. */
    private java.util.Calendar dataAutorizacao;

    /* Numero atribuido pelo sistema de redes durante o processamento
     * on-line da Base I. tambem conhecido como NSU. */
    private java.math.BigDecimal numeroSequenciaUnico;

    /* Numero do cartaoo utilizado na transacao armazenado de forma
     * criptografada. */
    private java.lang.String numeroCartaoCriptografado;

    /* Nome da bandeira do cartao que foi utilizado na venda realizada
     * pelo cliente utilizando o terminal da Cielo. (VISA/MASTERCARD/ELO/DINNERS/AMEX) */
    private java.lang.String nomeBandeira;

    /* Nome do tipo de maquina (Maquina (POS) ou TEF) */
    private java.lang.String nomeTipoMaquina;

    /* Identifica quem foi responsavel pela autorizacao */
    private java.lang.String nomeAutorizadora;

    /* Numero do cartao truncado do portador utilizada nesta transacao
     * de venda. */
    private java.lang.String numeroCartaoTruncado;

    /* Informacoes das parcelas de uma transacao de venda a credito. */
    private br.com.cielo.canonico.transacao.capturaeautorizacao.v1.ParcelaTransacaoVenda[] dadosParcela;

    /* Nome do tipo de pagamento que equivale ao tipo de produto do
     * cartao emitido pelo emissor. (CREDITO/DEBITO/PARCELADO) */
    private java.lang.String nomeTipoPagamento;

    /* Tambem chamado de Codigo de Adquirente, indica caracteristica
     * do equipamento/terminal utilizado. */
    private java.lang.String descricaoVersaoTerminal;

    /* Versao do aplicativo utilizado no Canal (Solucao de Captura) */
    private java.lang.String descricaoVersaoAplicativo;

    /* Descricao da resposta retornada no CVV2 */
    private java.lang.String descricaoRespostaCVV2;

    /* Codigo Identificador da transacao na Bandeira */
    private java.lang.String codigoTransacaoBandeira;

    /* Codigo gerado pela Cielo para identificar a autorizacao da
     * transacao no momento em que ela esta sendo realizada. */
    private java.lang.String codigoAutorizacao;

    /* Quantidade de parcelas que a venda a�credito pode ter sido
     * realizada. */
    private java.lang.Integer quantidadeParcela;

    /* Descricao que identifica a transacao como online, offline e
     * tambem o financiamento da venda ou cancelamento */
    private java.lang.String nomeTipoTransacao;

    /* Terminal Capability, indica capacidade do terminal */
    private java.lang.String descricaoCapacidadeTerminal;

    /* Descricao de envio de CVV2 */
    private java.lang.String descricaoInformacaoCVV2;

    /* Nome do Emissor do cartao */
    private java.lang.String nomeEmissor;

    /* Uma colecao de eventos do ciclo de vida de uma transacao de
     * venda desde a sua autorizacao ate qualquer contestacao que ocorra
     * apos sua liquidacao (cancelamento de venda, chargeback, etc) */
    private br.com.cielo.canonico.transacao.capturaeautorizacao.v1.EventoTransacaoVenda[] dadosEventosTransacaoFinanceira;

    /* Codigo Service Code, indica o modo de leitura do meio de pagamento */
    private java.lang.String codigoServico;

    /* versao do POS, ou do terminal, que o estabelecimento esta usando */
    private java.lang.String descricaoTipoTerminal;

    /* Texto de detalhamento da autorizacao */
    private java.lang.String descricaoObservacao;

    /* Descricao do metodo de entrada da transacao */
    private java.lang.String descricaoMetodoEntrada;

    /* Descricao da resposta da autorizacao */
    private java.lang.String descricaoResposta;

    /* Codigo que identifica como foi lido o cartao */
    private java.lang.String codigoPontoServico;

    /* Mensagem exibida no POS no processo de autorizacao */
    private java.lang.String descricaoMensagemPOS;

    /* Descricao da forma de entrada da transacao */
    private java.lang.String descricaoFormaEntrada;

    /* Nivel de seguranca da transacao */
    private java.lang.String nomeNivelSeguranca;

    /* Data no momento nop qual foi capturada a transacao na maquina */
    private java.util.Calendar dataCapturaTransacao;

    private java.math.BigInteger codigoProduto;

    /* Nivel de seguranca da transacao */
    private java.lang.String codigoNivelSeguranca;

    /* Descricao do conceito, regras e benefi�cios deste produto */
    private java.lang.String descricaoProduto;

    /* Numero do cartao aberto (visivel) do portador utilizada nesta
     * transacao de venda. */
    private java.lang.String numeroCartaoAberto;

    /* Data de vencimento do cartao MMAA */
    private java.math.BigInteger vencimentoCartao;

    /* Transaction id the commerce
     * Identificador que o ecommerce gera na transacao. */
    private java.lang.String numeroTID;

    /* Valor de entrada de uma transacao Ex: Entrada + 12x */
    private java.lang.Double valorEntrada;

    /* Se trata de um codigo de validacao da transacao que a bandeira
     * retorna para a Cielo, caso essa transacao seja efetuada. */
    private java.lang.String codigoValidacaoTransacao;

    /* quantidade de digitos contidas em um cartao, geralmente sao
     * 16, porem com casos de ter mais caracteres */
    private java.math.BigInteger quantidadeDigitosCartao;

    private java.lang.String numeroReferenciaOriginalAutorizacao;

    /* Taxa utilizada para transacao de companhia a�rea */
    private java.lang.Double valorTaxaEmbarque;

    /* Numero Serial Unico: Identificador que o terminal gera a cada
     * transacao. */
    private java.lang.String numeroNSU;

    /* Se trata de um codigo na qual a bandeira retorna para a Cielo,
     * validando o codigo de seguranca do cartao utilizado na transacao. */
    private java.lang.String codigoValidacaoCodigoSeguranca;

    /* Status da situacao da Reclamacao da Transacao. */
    private java.lang.String statusSituacaoReclamacaoTransacao;

    /* codigo seguranca do cartao */
    private java.math.BigInteger codigoSeguranca;

    /* E a taxa cobrada pela cielo por cada transacao */
    private java.lang.Double taxaValorMDR;

    /* Valor do prazo flexivel */
    private java.lang.Double valorPrazoFlexivel;

    private java.lang.String categoriaPagamento;

    /* indicador que indica se este produto permite transacoes de
     * venda digitadas */
    private java.lang.Boolean indicadorVendaDigitada;

    public TransacaoVenda() {
    }

    public TransacaoVenda(
           java.lang.Long codigoCliente,
           java.lang.String numeroTerminal,
           java.lang.String numeroReferenciaUnico,
           java.lang.Double valorBrutoVenda,
           java.lang.Double valorComissao,
           java.lang.Double valorIntercambio,
           java.lang.Double valorLiquido,
           java.util.Date dataCaptura,
           java.lang.String codigoVenda,
           java.util.Calendar dataAutorizacao,
           java.math.BigDecimal numeroSequenciaUnico,
           java.lang.String numeroCartaoCriptografado,
           java.lang.String nomeBandeira,
           java.lang.String nomeTipoMaquina,
           java.lang.String nomeAutorizadora,
           java.lang.String numeroCartaoTruncado,
           br.com.cielo.canonico.transacao.capturaeautorizacao.v1.ParcelaTransacaoVenda[] dadosParcela,
           java.lang.String nomeTipoPagamento,
           java.lang.String descricaoVersaoTerminal,
           java.lang.String descricaoVersaoAplicativo,
           java.lang.String descricaoRespostaCVV2,
           java.lang.String codigoTransacaoBandeira,
           java.lang.String codigoAutorizacao,
           java.lang.Integer quantidadeParcela,
           java.lang.String nomeTipoTransacao,
           java.lang.String descricaoCapacidadeTerminal,
           java.lang.String descricaoInformacaoCVV2,
           java.lang.String nomeEmissor,
           br.com.cielo.canonico.transacao.capturaeautorizacao.v1.EventoTransacaoVenda[] dadosEventosTransacaoFinanceira,
           java.lang.String codigoServico,
           java.lang.String descricaoTipoTerminal,
           java.lang.String descricaoObservacao,
           java.lang.String descricaoMetodoEntrada,
           java.lang.String descricaoResposta,
           java.lang.String codigoPontoServico,
           java.lang.String descricaoMensagemPOS,
           java.lang.String descricaoFormaEntrada,
           java.lang.String nomeNivelSeguranca,
           java.util.Calendar dataCapturaTransacao,
           java.math.BigInteger codigoProduto,
           java.lang.String codigoNivelSeguranca,
           java.lang.String descricaoProduto,
           java.lang.String numeroCartaoAberto,
           java.math.BigInteger vencimentoCartao,
           java.lang.String numeroTID,
           java.lang.Double valorEntrada,
           java.lang.String codigoValidacaoTransacao,
           java.math.BigInteger quantidadeDigitosCartao,
           java.lang.String numeroReferenciaOriginalAutorizacao,
           java.lang.Double valorTaxaEmbarque,
           java.lang.String numeroNSU,
           java.lang.String codigoValidacaoCodigoSeguranca,
           java.lang.String statusSituacaoReclamacaoTransacao,
           java.math.BigInteger codigoSeguranca,
           java.lang.Double taxaValorMDR,
           java.lang.Double valorPrazoFlexivel,
           java.lang.String categoriaPagamento,
           java.lang.Boolean indicadorVendaDigitada) {
           this.codigoCliente = codigoCliente;
           this.numeroTerminal = numeroTerminal;
           this.numeroReferenciaUnico = numeroReferenciaUnico;
           this.valorBrutoVenda = valorBrutoVenda;
           this.valorComissao = valorComissao;
           this.valorIntercambio = valorIntercambio;
           this.valorLiquido = valorLiquido;
           this.dataCaptura = dataCaptura;
           this.codigoVenda = codigoVenda;
           this.dataAutorizacao = dataAutorizacao;
           this.numeroSequenciaUnico = numeroSequenciaUnico;
           this.numeroCartaoCriptografado = numeroCartaoCriptografado;
           this.nomeBandeira = nomeBandeira;
           this.nomeTipoMaquina = nomeTipoMaquina;
           this.nomeAutorizadora = nomeAutorizadora;
           this.numeroCartaoTruncado = numeroCartaoTruncado;
           this.dadosParcela = dadosParcela;
           this.nomeTipoPagamento = nomeTipoPagamento;
           this.descricaoVersaoTerminal = descricaoVersaoTerminal;
           this.descricaoVersaoAplicativo = descricaoVersaoAplicativo;
           this.descricaoRespostaCVV2 = descricaoRespostaCVV2;
           this.codigoTransacaoBandeira = codigoTransacaoBandeira;
           this.codigoAutorizacao = codigoAutorizacao;
           this.quantidadeParcela = quantidadeParcela;
           this.nomeTipoTransacao = nomeTipoTransacao;
           this.descricaoCapacidadeTerminal = descricaoCapacidadeTerminal;
           this.descricaoInformacaoCVV2 = descricaoInformacaoCVV2;
           this.nomeEmissor = nomeEmissor;
           this.dadosEventosTransacaoFinanceira = dadosEventosTransacaoFinanceira;
           this.codigoServico = codigoServico;
           this.descricaoTipoTerminal = descricaoTipoTerminal;
           this.descricaoObservacao = descricaoObservacao;
           this.descricaoMetodoEntrada = descricaoMetodoEntrada;
           this.descricaoResposta = descricaoResposta;
           this.codigoPontoServico = codigoPontoServico;
           this.descricaoMensagemPOS = descricaoMensagemPOS;
           this.descricaoFormaEntrada = descricaoFormaEntrada;
           this.nomeNivelSeguranca = nomeNivelSeguranca;
           this.dataCapturaTransacao = dataCapturaTransacao;
           this.codigoProduto = codigoProduto;
           this.codigoNivelSeguranca = codigoNivelSeguranca;
           this.descricaoProduto = descricaoProduto;
           this.numeroCartaoAberto = numeroCartaoAberto;
           this.vencimentoCartao = vencimentoCartao;
           this.numeroTID = numeroTID;
           this.valorEntrada = valorEntrada;
           this.codigoValidacaoTransacao = codigoValidacaoTransacao;
           this.quantidadeDigitosCartao = quantidadeDigitosCartao;
           this.numeroReferenciaOriginalAutorizacao = numeroReferenciaOriginalAutorizacao;
           this.valorTaxaEmbarque = valorTaxaEmbarque;
           this.numeroNSU = numeroNSU;
           this.codigoValidacaoCodigoSeguranca = codigoValidacaoCodigoSeguranca;
           this.statusSituacaoReclamacaoTransacao = statusSituacaoReclamacaoTransacao;
           this.codigoSeguranca = codigoSeguranca;
           this.taxaValorMDR = taxaValorMDR;
           this.valorPrazoFlexivel = valorPrazoFlexivel;
           this.categoriaPagamento = categoriaPagamento;
           this.indicadorVendaDigitada = indicadorVendaDigitada;
    }


    /**
     * Gets the codigoCliente value for this TransacaoVenda.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar seu cliente.
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this TransacaoVenda.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar seu cliente.
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the numeroTerminal value for this TransacaoVenda.
     * 
     * @return numeroTerminal   * Numero que identifica um terminal de POS utilizado pelo cliente
     * da Cielo, onde atraves dele se realiza uma transacao de venda que
     * utiliza um cartao de credito, debito ou voucher
     */
    public java.lang.String getNumeroTerminal() {
        return numeroTerminal;
    }


    /**
     * Sets the numeroTerminal value for this TransacaoVenda.
     * 
     * @param numeroTerminal   * Numero que identifica um terminal de POS utilizado pelo cliente
     * da Cielo, onde atraves dele se realiza uma transacao de venda que
     * utiliza um cartao de credito, debito ou voucher
     */
    public void setNumeroTerminal(java.lang.String numeroTerminal) {
        this.numeroTerminal = numeroTerminal;
    }


    /**
     * Gets the numeroReferenciaUnico value for this TransacaoVenda.
     * 
     * @return numeroReferenciaUnico   * Numero de referencia que identifica uma transacao capturada
     * pelo terminal POS do Cliente da Cielo.
     */
    public java.lang.String getNumeroReferenciaUnico() {
        return numeroReferenciaUnico;
    }


    /**
     * Sets the numeroReferenciaUnico value for this TransacaoVenda.
     * 
     * @param numeroReferenciaUnico   * Numero de referencia que identifica uma transacao capturada
     * pelo terminal POS do Cliente da Cielo.
     */
    public void setNumeroReferenciaUnico(java.lang.String numeroReferenciaUnico) {
        this.numeroReferenciaUnico = numeroReferenciaUnico;
    }


    /**
     * Gets the valorBrutoVenda value for this TransacaoVenda.
     * 
     * @return valorBrutoVenda   * Valor bruto da venda realizada pelo cliente e que utilizou
     * o terminal da Cielo como forma  de pagamento.
     */
    public java.lang.Double getValorBrutoVenda() {
        return valorBrutoVenda;
    }


    /**
     * Sets the valorBrutoVenda value for this TransacaoVenda.
     * 
     * @param valorBrutoVenda   * Valor bruto da venda realizada pelo cliente e que utilizou
     * o terminal da Cielo como forma  de pagamento.
     */
    public void setValorBrutoVenda(java.lang.Double valorBrutoVenda) {
        this.valorBrutoVenda = valorBrutoVenda;
    }


    /**
     * Gets the valorComissao value for this TransacaoVenda.
     * 
     * @return valorComissao   * Valor da comissao aplicado sobre o valor bruto da venda  realizada
     * pelo cliente utilizando o terminal da Cielo.
     */
    public java.lang.Double getValorComissao() {
        return valorComissao;
    }


    /**
     * Sets the valorComissao value for this TransacaoVenda.
     * 
     * @param valorComissao   * Valor da comissao aplicado sobre o valor bruto da venda  realizada
     * pelo cliente utilizando o terminal da Cielo.
     */
    public void setValorComissao(java.lang.Double valorComissao) {
        this.valorComissao = valorComissao;
    }


    /**
     * Gets the valorIntercambio value for this TransacaoVenda.
     * 
     * @return valorIntercambio   * Valor subtraido do valor da comisscao que e repassado para
     * a Bandeira e para o emissor do cartao que foi utilizado na venda realizada
     * pelo cliente utilizando o terminal da Cielo.
     */
    public java.lang.Double getValorIntercambio() {
        return valorIntercambio;
    }


    /**
     * Sets the valorIntercambio value for this TransacaoVenda.
     * 
     * @param valorIntercambio   * Valor subtraido do valor da comisscao que e repassado para
     * a Bandeira e para o emissor do cartao que foi utilizado na venda realizada
     * pelo cliente utilizando o terminal da Cielo.
     */
    public void setValorIntercambio(java.lang.Double valorIntercambio) {
        this.valorIntercambio = valorIntercambio;
    }


    /**
     * Gets the valorLiquido value for this TransacaoVenda.
     * 
     * @return valorLiquido   * Valor calculoda atraves da subtraacao do valor da comissao
     * e do intercambio sobre o valor bruto da venda realizada pelo cliente
     * utilizando o terminal da Cielo.
     */
    public java.lang.Double getValorLiquido() {
        return valorLiquido;
    }


    /**
     * Sets the valorLiquido value for this TransacaoVenda.
     * 
     * @param valorLiquido   * Valor calculoda atraves da subtraacao do valor da comissao
     * e do intercambio sobre o valor bruto da venda realizada pelo cliente
     * utilizando o terminal da Cielo.
     */
    public void setValorLiquido(java.lang.Double valorLiquido) {
        this.valorLiquido = valorLiquido;
    }


    /**
     * Gets the dataCaptura value for this TransacaoVenda.
     * 
     * @return dataCaptura   * Data da captura da transacao atribui�da pelos sistemas de redes
     * da Cielo.
     */
    public java.util.Date getDataCaptura() {
        return dataCaptura;
    }


    /**
     * Sets the dataCaptura value for this TransacaoVenda.
     * 
     * @param dataCaptura   * Data da captura da transacao atribui�da pelos sistemas de redes
     * da Cielo.
     */
    public void setDataCaptura(java.util.Date dataCaptura) {
        this.dataCaptura = dataCaptura;
    }


    /**
     * Gets the codigoVenda value for this TransacaoVenda.
     * 
     * @return codigoVenda   * Numero unico atribuido a uma transacao de venda pelo sistema
     * STAR  no momento em que e processada a sua captura. Este numero nao
     * corresponde ao NSU e nem ao Reference Number.
     */
    public java.lang.String getCodigoVenda() {
        return codigoVenda;
    }


    /**
     * Sets the codigoVenda value for this TransacaoVenda.
     * 
     * @param codigoVenda   * Numero unico atribuido a uma transacao de venda pelo sistema
     * STAR  no momento em que e processada a sua captura. Este numero nao
     * corresponde ao NSU e nem ao Reference Number.
     */
    public void setCodigoVenda(java.lang.String codigoVenda) {
        this.codigoVenda = codigoVenda;
    }


    /**
     * Gets the dataAutorizacao value for this TransacaoVenda.
     * 
     * @return dataAutorizacao   * Data em que a transacao foi autorizada e o sistema de redes
     * a capturou transacao atribuida pelos sistemas de redes da Cielo.
     */
    public java.util.Calendar getDataAutorizacao() {
        return dataAutorizacao;
    }


    /**
     * Sets the dataAutorizacao value for this TransacaoVenda.
     * 
     * @param dataAutorizacao   * Data em que a transacao foi autorizada e o sistema de redes
     * a capturou transacao atribuida pelos sistemas de redes da Cielo.
     */
    public void setDataAutorizacao(java.util.Calendar dataAutorizacao) {
        this.dataAutorizacao = dataAutorizacao;
    }


    /**
     * Gets the numeroSequenciaUnico value for this TransacaoVenda.
     * 
     * @return numeroSequenciaUnico   * Numero atribuido pelo sistema de redes durante o processamento
     * on-line da Base I. tambem conhecido como NSU.
     */
    public java.math.BigDecimal getNumeroSequenciaUnico() {
        return numeroSequenciaUnico;
    }


    /**
     * Sets the numeroSequenciaUnico value for this TransacaoVenda.
     * 
     * @param numeroSequenciaUnico   * Numero atribuido pelo sistema de redes durante o processamento
     * on-line da Base I. tambem conhecido como NSU.
     */
    public void setNumeroSequenciaUnico(java.math.BigDecimal numeroSequenciaUnico) {
        this.numeroSequenciaUnico = numeroSequenciaUnico;
    }


    /**
     * Gets the numeroCartaoCriptografado value for this TransacaoVenda.
     * 
     * @return numeroCartaoCriptografado   * Numero do cartaoo utilizado na transacao armazenado de forma
     * criptografada.
     */
    public java.lang.String getNumeroCartaoCriptografado() {
        return numeroCartaoCriptografado;
    }


    /**
     * Sets the numeroCartaoCriptografado value for this TransacaoVenda.
     * 
     * @param numeroCartaoCriptografado   * Numero do cartaoo utilizado na transacao armazenado de forma
     * criptografada.
     */
    public void setNumeroCartaoCriptografado(java.lang.String numeroCartaoCriptografado) {
        this.numeroCartaoCriptografado = numeroCartaoCriptografado;
    }


    /**
     * Gets the nomeBandeira value for this TransacaoVenda.
     * 
     * @return nomeBandeira   * Nome da bandeira do cartao que foi utilizado na venda realizada
     * pelo cliente utilizando o terminal da Cielo. (VISA/MASTERCARD/ELO/DINNERS/AMEX)
     */
    public java.lang.String getNomeBandeira() {
        return nomeBandeira;
    }


    /**
     * Sets the nomeBandeira value for this TransacaoVenda.
     * 
     * @param nomeBandeira   * Nome da bandeira do cartao que foi utilizado na venda realizada
     * pelo cliente utilizando o terminal da Cielo. (VISA/MASTERCARD/ELO/DINNERS/AMEX)
     */
    public void setNomeBandeira(java.lang.String nomeBandeira) {
        this.nomeBandeira = nomeBandeira;
    }


    /**
     * Gets the nomeTipoMaquina value for this TransacaoVenda.
     * 
     * @return nomeTipoMaquina   * Nome do tipo de maquina (Maquina (POS) ou TEF)
     */
    public java.lang.String getNomeTipoMaquina() {
        return nomeTipoMaquina;
    }


    /**
     * Sets the nomeTipoMaquina value for this TransacaoVenda.
     * 
     * @param nomeTipoMaquina   * Nome do tipo de maquina (Maquina (POS) ou TEF)
     */
    public void setNomeTipoMaquina(java.lang.String nomeTipoMaquina) {
        this.nomeTipoMaquina = nomeTipoMaquina;
    }


    /**
     * Gets the nomeAutorizadora value for this TransacaoVenda.
     * 
     * @return nomeAutorizadora   * Identifica quem foi responsavel pela autorizacao
     */
    public java.lang.String getNomeAutorizadora() {
        return nomeAutorizadora;
    }


    /**
     * Sets the nomeAutorizadora value for this TransacaoVenda.
     * 
     * @param nomeAutorizadora   * Identifica quem foi responsavel pela autorizacao
     */
    public void setNomeAutorizadora(java.lang.String nomeAutorizadora) {
        this.nomeAutorizadora = nomeAutorizadora;
    }


    /**
     * Gets the numeroCartaoTruncado value for this TransacaoVenda.
     * 
     * @return numeroCartaoTruncado   * Numero do cartao truncado do portador utilizada nesta transacao
     * de venda.
     */
    public java.lang.String getNumeroCartaoTruncado() {
        return numeroCartaoTruncado;
    }


    /**
     * Sets the numeroCartaoTruncado value for this TransacaoVenda.
     * 
     * @param numeroCartaoTruncado   * Numero do cartao truncado do portador utilizada nesta transacao
     * de venda.
     */
    public void setNumeroCartaoTruncado(java.lang.String numeroCartaoTruncado) {
        this.numeroCartaoTruncado = numeroCartaoTruncado;
    }


    /**
     * Gets the dadosParcela value for this TransacaoVenda.
     * 
     * @return dadosParcela   * Informacoes das parcelas de uma transacao de venda a credito.
     */
    public br.com.cielo.canonico.transacao.capturaeautorizacao.v1.ParcelaTransacaoVenda[] getDadosParcela() {
        return dadosParcela;
    }


    /**
     * Sets the dadosParcela value for this TransacaoVenda.
     * 
     * @param dadosParcela   * Informacoes das parcelas de uma transacao de venda a credito.
     */
    public void setDadosParcela(br.com.cielo.canonico.transacao.capturaeautorizacao.v1.ParcelaTransacaoVenda[] dadosParcela) {
        this.dadosParcela = dadosParcela;
    }

    public br.com.cielo.canonico.transacao.capturaeautorizacao.v1.ParcelaTransacaoVenda getDadosParcela(int i) {
        return this.dadosParcela[i];
    }

    public void setDadosParcela(int i, br.com.cielo.canonico.transacao.capturaeautorizacao.v1.ParcelaTransacaoVenda _value) {
        this.dadosParcela[i] = _value;
    }


    /**
     * Gets the nomeTipoPagamento value for this TransacaoVenda.
     * 
     * @return nomeTipoPagamento   * Nome do tipo de pagamento que equivale ao tipo de produto do
     * cartao emitido pelo emissor. (CREDITO/DEBITO/PARCELADO)
     */
    public java.lang.String getNomeTipoPagamento() {
        return nomeTipoPagamento;
    }


    /**
     * Sets the nomeTipoPagamento value for this TransacaoVenda.
     * 
     * @param nomeTipoPagamento   * Nome do tipo de pagamento que equivale ao tipo de produto do
     * cartao emitido pelo emissor. (CREDITO/DEBITO/PARCELADO)
     */
    public void setNomeTipoPagamento(java.lang.String nomeTipoPagamento) {
        this.nomeTipoPagamento = nomeTipoPagamento;
    }


    /**
     * Gets the descricaoVersaoTerminal value for this TransacaoVenda.
     * 
     * @return descricaoVersaoTerminal   * Tambem chamado de Codigo de Adquirente, indica caracteristica
     * do equipamento/terminal utilizado.
     */
    public java.lang.String getDescricaoVersaoTerminal() {
        return descricaoVersaoTerminal;
    }


    /**
     * Sets the descricaoVersaoTerminal value for this TransacaoVenda.
     * 
     * @param descricaoVersaoTerminal   * Tambem chamado de Codigo de Adquirente, indica caracteristica
     * do equipamento/terminal utilizado.
     */
    public void setDescricaoVersaoTerminal(java.lang.String descricaoVersaoTerminal) {
        this.descricaoVersaoTerminal = descricaoVersaoTerminal;
    }


    /**
     * Gets the descricaoVersaoAplicativo value for this TransacaoVenda.
     * 
     * @return descricaoVersaoAplicativo   * Versao do aplicativo utilizado no Canal (Solucao de Captura)
     */
    public java.lang.String getDescricaoVersaoAplicativo() {
        return descricaoVersaoAplicativo;
    }


    /**
     * Sets the descricaoVersaoAplicativo value for this TransacaoVenda.
     * 
     * @param descricaoVersaoAplicativo   * Versao do aplicativo utilizado no Canal (Solucao de Captura)
     */
    public void setDescricaoVersaoAplicativo(java.lang.String descricaoVersaoAplicativo) {
        this.descricaoVersaoAplicativo = descricaoVersaoAplicativo;
    }


    /**
     * Gets the descricaoRespostaCVV2 value for this TransacaoVenda.
     * 
     * @return descricaoRespostaCVV2   * Descricao da resposta retornada no CVV2
     */
    public java.lang.String getDescricaoRespostaCVV2() {
        return descricaoRespostaCVV2;
    }


    /**
     * Sets the descricaoRespostaCVV2 value for this TransacaoVenda.
     * 
     * @param descricaoRespostaCVV2   * Descricao da resposta retornada no CVV2
     */
    public void setDescricaoRespostaCVV2(java.lang.String descricaoRespostaCVV2) {
        this.descricaoRespostaCVV2 = descricaoRespostaCVV2;
    }


    /**
     * Gets the codigoTransacaoBandeira value for this TransacaoVenda.
     * 
     * @return codigoTransacaoBandeira   * Codigo Identificador da transacao na Bandeira
     */
    public java.lang.String getCodigoTransacaoBandeira() {
        return codigoTransacaoBandeira;
    }


    /**
     * Sets the codigoTransacaoBandeira value for this TransacaoVenda.
     * 
     * @param codigoTransacaoBandeira   * Codigo Identificador da transacao na Bandeira
     */
    public void setCodigoTransacaoBandeira(java.lang.String codigoTransacaoBandeira) {
        this.codigoTransacaoBandeira = codigoTransacaoBandeira;
    }


    /**
     * Gets the codigoAutorizacao value for this TransacaoVenda.
     * 
     * @return codigoAutorizacao   * Codigo gerado pela Cielo para identificar a autorizacao da
     * transacao no momento em que ela esta sendo realizada.
     */
    public java.lang.String getCodigoAutorizacao() {
        return codigoAutorizacao;
    }


    /**
     * Sets the codigoAutorizacao value for this TransacaoVenda.
     * 
     * @param codigoAutorizacao   * Codigo gerado pela Cielo para identificar a autorizacao da
     * transacao no momento em que ela esta sendo realizada.
     */
    public void setCodigoAutorizacao(java.lang.String codigoAutorizacao) {
        this.codigoAutorizacao = codigoAutorizacao;
    }


    /**
     * Gets the quantidadeParcela value for this TransacaoVenda.
     * 
     * @return quantidadeParcela   * Quantidade de parcelas que a venda a�credito pode ter sido
     * realizada.
     */
    public java.lang.Integer getQuantidadeParcela() {
        return quantidadeParcela;
    }


    /**
     * Sets the quantidadeParcela value for this TransacaoVenda.
     * 
     * @param quantidadeParcela   * Quantidade de parcelas que a venda a�credito pode ter sido
     * realizada.
     */
    public void setQuantidadeParcela(java.lang.Integer quantidadeParcela) {
        this.quantidadeParcela = quantidadeParcela;
    }


    /**
     * Gets the nomeTipoTransacao value for this TransacaoVenda.
     * 
     * @return nomeTipoTransacao   * Descricao que identifica a transacao como online, offline e
     * tambem o financiamento da venda ou cancelamento
     */
    public java.lang.String getNomeTipoTransacao() {
        return nomeTipoTransacao;
    }


    /**
     * Sets the nomeTipoTransacao value for this TransacaoVenda.
     * 
     * @param nomeTipoTransacao   * Descricao que identifica a transacao como online, offline e
     * tambem o financiamento da venda ou cancelamento
     */
    public void setNomeTipoTransacao(java.lang.String nomeTipoTransacao) {
        this.nomeTipoTransacao = nomeTipoTransacao;
    }


    /**
     * Gets the descricaoCapacidadeTerminal value for this TransacaoVenda.
     * 
     * @return descricaoCapacidadeTerminal   * Terminal Capability, indica capacidade do terminal
     */
    public java.lang.String getDescricaoCapacidadeTerminal() {
        return descricaoCapacidadeTerminal;
    }


    /**
     * Sets the descricaoCapacidadeTerminal value for this TransacaoVenda.
     * 
     * @param descricaoCapacidadeTerminal   * Terminal Capability, indica capacidade do terminal
     */
    public void setDescricaoCapacidadeTerminal(java.lang.String descricaoCapacidadeTerminal) {
        this.descricaoCapacidadeTerminal = descricaoCapacidadeTerminal;
    }


    /**
     * Gets the descricaoInformacaoCVV2 value for this TransacaoVenda.
     * 
     * @return descricaoInformacaoCVV2   * Descricao de envio de CVV2
     */
    public java.lang.String getDescricaoInformacaoCVV2() {
        return descricaoInformacaoCVV2;
    }


    /**
     * Sets the descricaoInformacaoCVV2 value for this TransacaoVenda.
     * 
     * @param descricaoInformacaoCVV2   * Descricao de envio de CVV2
     */
    public void setDescricaoInformacaoCVV2(java.lang.String descricaoInformacaoCVV2) {
        this.descricaoInformacaoCVV2 = descricaoInformacaoCVV2;
    }


    /**
     * Gets the nomeEmissor value for this TransacaoVenda.
     * 
     * @return nomeEmissor   * Nome do Emissor do cartao
     */
    public java.lang.String getNomeEmissor() {
        return nomeEmissor;
    }


    /**
     * Sets the nomeEmissor value for this TransacaoVenda.
     * 
     * @param nomeEmissor   * Nome do Emissor do cartao
     */
    public void setNomeEmissor(java.lang.String nomeEmissor) {
        this.nomeEmissor = nomeEmissor;
    }


    /**
     * Gets the dadosEventosTransacaoFinanceira value for this TransacaoVenda.
     * 
     * @return dadosEventosTransacaoFinanceira   * Uma colecao de eventos do ciclo de vida de uma transacao de
     * venda desde a sua autorizacao ate qualquer contestacao que ocorra
     * apos sua liquidacao (cancelamento de venda, chargeback, etc)
     */
    public br.com.cielo.canonico.transacao.capturaeautorizacao.v1.EventoTransacaoVenda[] getDadosEventosTransacaoFinanceira() {
        return dadosEventosTransacaoFinanceira;
    }


    /**
     * Sets the dadosEventosTransacaoFinanceira value for this TransacaoVenda.
     * 
     * @param dadosEventosTransacaoFinanceira   * Uma colecao de eventos do ciclo de vida de uma transacao de
     * venda desde a sua autorizacao ate qualquer contestacao que ocorra
     * apos sua liquidacao (cancelamento de venda, chargeback, etc)
     */
    public void setDadosEventosTransacaoFinanceira(br.com.cielo.canonico.transacao.capturaeautorizacao.v1.EventoTransacaoVenda[] dadosEventosTransacaoFinanceira) {
        this.dadosEventosTransacaoFinanceira = dadosEventosTransacaoFinanceira;
    }


    /**
     * Gets the codigoServico value for this TransacaoVenda.
     * 
     * @return codigoServico   * Codigo Service Code, indica o modo de leitura do meio de pagamento
     */
    public java.lang.String getCodigoServico() {
        return codigoServico;
    }


    /**
     * Sets the codigoServico value for this TransacaoVenda.
     * 
     * @param codigoServico   * Codigo Service Code, indica o modo de leitura do meio de pagamento
     */
    public void setCodigoServico(java.lang.String codigoServico) {
        this.codigoServico = codigoServico;
    }


    /**
     * Gets the descricaoTipoTerminal value for this TransacaoVenda.
     * 
     * @return descricaoTipoTerminal   * versao do POS, ou do terminal, que o estabelecimento esta usando
     */
    public java.lang.String getDescricaoTipoTerminal() {
        return descricaoTipoTerminal;
    }


    /**
     * Sets the descricaoTipoTerminal value for this TransacaoVenda.
     * 
     * @param descricaoTipoTerminal   * versao do POS, ou do terminal, que o estabelecimento esta usando
     */
    public void setDescricaoTipoTerminal(java.lang.String descricaoTipoTerminal) {
        this.descricaoTipoTerminal = descricaoTipoTerminal;
    }


    /**
     * Gets the descricaoObservacao value for this TransacaoVenda.
     * 
     * @return descricaoObservacao   * Texto de detalhamento da autorizacao
     */
    public java.lang.String getDescricaoObservacao() {
        return descricaoObservacao;
    }


    /**
     * Sets the descricaoObservacao value for this TransacaoVenda.
     * 
     * @param descricaoObservacao   * Texto de detalhamento da autorizacao
     */
    public void setDescricaoObservacao(java.lang.String descricaoObservacao) {
        this.descricaoObservacao = descricaoObservacao;
    }


    /**
     * Gets the descricaoMetodoEntrada value for this TransacaoVenda.
     * 
     * @return descricaoMetodoEntrada   * Descricao do metodo de entrada da transacao
     */
    public java.lang.String getDescricaoMetodoEntrada() {
        return descricaoMetodoEntrada;
    }


    /**
     * Sets the descricaoMetodoEntrada value for this TransacaoVenda.
     * 
     * @param descricaoMetodoEntrada   * Descricao do metodo de entrada da transacao
     */
    public void setDescricaoMetodoEntrada(java.lang.String descricaoMetodoEntrada) {
        this.descricaoMetodoEntrada = descricaoMetodoEntrada;
    }


    /**
     * Gets the descricaoResposta value for this TransacaoVenda.
     * 
     * @return descricaoResposta   * Descricao da resposta da autorizacao
     */
    public java.lang.String getDescricaoResposta() {
        return descricaoResposta;
    }


    /**
     * Sets the descricaoResposta value for this TransacaoVenda.
     * 
     * @param descricaoResposta   * Descricao da resposta da autorizacao
     */
    public void setDescricaoResposta(java.lang.String descricaoResposta) {
        this.descricaoResposta = descricaoResposta;
    }


    /**
     * Gets the codigoPontoServico value for this TransacaoVenda.
     * 
     * @return codigoPontoServico   * Codigo que identifica como foi lido o cartao
     */
    public java.lang.String getCodigoPontoServico() {
        return codigoPontoServico;
    }


    /**
     * Sets the codigoPontoServico value for this TransacaoVenda.
     * 
     * @param codigoPontoServico   * Codigo que identifica como foi lido o cartao
     */
    public void setCodigoPontoServico(java.lang.String codigoPontoServico) {
        this.codigoPontoServico = codigoPontoServico;
    }


    /**
     * Gets the descricaoMensagemPOS value for this TransacaoVenda.
     * 
     * @return descricaoMensagemPOS   * Mensagem exibida no POS no processo de autorizacao
     */
    public java.lang.String getDescricaoMensagemPOS() {
        return descricaoMensagemPOS;
    }


    /**
     * Sets the descricaoMensagemPOS value for this TransacaoVenda.
     * 
     * @param descricaoMensagemPOS   * Mensagem exibida no POS no processo de autorizacao
     */
    public void setDescricaoMensagemPOS(java.lang.String descricaoMensagemPOS) {
        this.descricaoMensagemPOS = descricaoMensagemPOS;
    }


    /**
     * Gets the descricaoFormaEntrada value for this TransacaoVenda.
     * 
     * @return descricaoFormaEntrada   * Descricao da forma de entrada da transacao
     */
    public java.lang.String getDescricaoFormaEntrada() {
        return descricaoFormaEntrada;
    }


    /**
     * Sets the descricaoFormaEntrada value for this TransacaoVenda.
     * 
     * @param descricaoFormaEntrada   * Descricao da forma de entrada da transacao
     */
    public void setDescricaoFormaEntrada(java.lang.String descricaoFormaEntrada) {
        this.descricaoFormaEntrada = descricaoFormaEntrada;
    }


    /**
     * Gets the nomeNivelSeguranca value for this TransacaoVenda.
     * 
     * @return nomeNivelSeguranca   * Nivel de seguranca da transacao
     */
    public java.lang.String getNomeNivelSeguranca() {
        return nomeNivelSeguranca;
    }


    /**
     * Sets the nomeNivelSeguranca value for this TransacaoVenda.
     * 
     * @param nomeNivelSeguranca   * Nivel de seguranca da transacao
     */
    public void setNomeNivelSeguranca(java.lang.String nomeNivelSeguranca) {
        this.nomeNivelSeguranca = nomeNivelSeguranca;
    }


    /**
     * Gets the dataCapturaTransacao value for this TransacaoVenda.
     * 
     * @return dataCapturaTransacao   * Data no momento nop qual foi capturada a transacao na maquina
     */
    public java.util.Calendar getDataCapturaTransacao() {
        return dataCapturaTransacao;
    }


    /**
     * Sets the dataCapturaTransacao value for this TransacaoVenda.
     * 
     * @param dataCapturaTransacao   * Data no momento nop qual foi capturada a transacao na maquina
     */
    public void setDataCapturaTransacao(java.util.Calendar dataCapturaTransacao) {
        this.dataCapturaTransacao = dataCapturaTransacao;
    }


    /**
     * Gets the codigoProduto value for this TransacaoVenda.
     * 
     * @return codigoProduto
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this TransacaoVenda.
     * 
     * @param codigoProduto
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the codigoNivelSeguranca value for this TransacaoVenda.
     * 
     * @return codigoNivelSeguranca   * Nivel de seguranca da transacao
     */
    public java.lang.String getCodigoNivelSeguranca() {
        return codigoNivelSeguranca;
    }


    /**
     * Sets the codigoNivelSeguranca value for this TransacaoVenda.
     * 
     * @param codigoNivelSeguranca   * Nivel de seguranca da transacao
     */
    public void setCodigoNivelSeguranca(java.lang.String codigoNivelSeguranca) {
        this.codigoNivelSeguranca = codigoNivelSeguranca;
    }


    /**
     * Gets the descricaoProduto value for this TransacaoVenda.
     * 
     * @return descricaoProduto   * Descricao do conceito, regras e benefi�cios deste produto
     */
    public java.lang.String getDescricaoProduto() {
        return descricaoProduto;
    }


    /**
     * Sets the descricaoProduto value for this TransacaoVenda.
     * 
     * @param descricaoProduto   * Descricao do conceito, regras e benefi�cios deste produto
     */
    public void setDescricaoProduto(java.lang.String descricaoProduto) {
        this.descricaoProduto = descricaoProduto;
    }


    /**
     * Gets the numeroCartaoAberto value for this TransacaoVenda.
     * 
     * @return numeroCartaoAberto   * Numero do cartao aberto (visivel) do portador utilizada nesta
     * transacao de venda.
     */
    public java.lang.String getNumeroCartaoAberto() {
        return numeroCartaoAberto;
    }


    /**
     * Sets the numeroCartaoAberto value for this TransacaoVenda.
     * 
     * @param numeroCartaoAberto   * Numero do cartao aberto (visivel) do portador utilizada nesta
     * transacao de venda.
     */
    public void setNumeroCartaoAberto(java.lang.String numeroCartaoAberto) {
        this.numeroCartaoAberto = numeroCartaoAberto;
    }


    /**
     * Gets the vencimentoCartao value for this TransacaoVenda.
     * 
     * @return vencimentoCartao   * Data de vencimento do cartao MMAA
     */
    public java.math.BigInteger getVencimentoCartao() {
        return vencimentoCartao;
    }


    /**
     * Sets the vencimentoCartao value for this TransacaoVenda.
     * 
     * @param vencimentoCartao   * Data de vencimento do cartao MMAA
     */
    public void setVencimentoCartao(java.math.BigInteger vencimentoCartao) {
        this.vencimentoCartao = vencimentoCartao;
    }


    /**
     * Gets the numeroTID value for this TransacaoVenda.
     * 
     * @return numeroTID   * Transaction id the commerce
     * Identificador que o ecommerce gera na transacao.
     */
    public java.lang.String getNumeroTID() {
        return numeroTID;
    }


    /**
     * Sets the numeroTID value for this TransacaoVenda.
     * 
     * @param numeroTID   * Transaction id the commerce
     * Identificador que o ecommerce gera na transacao.
     */
    public void setNumeroTID(java.lang.String numeroTID) {
        this.numeroTID = numeroTID;
    }


    /**
     * Gets the valorEntrada value for this TransacaoVenda.
     * 
     * @return valorEntrada   * Valor de entrada de uma transacao Ex: Entrada + 12x
     */
    public java.lang.Double getValorEntrada() {
        return valorEntrada;
    }


    /**
     * Sets the valorEntrada value for this TransacaoVenda.
     * 
     * @param valorEntrada   * Valor de entrada de uma transacao Ex: Entrada + 12x
     */
    public void setValorEntrada(java.lang.Double valorEntrada) {
        this.valorEntrada = valorEntrada;
    }


    /**
     * Gets the codigoValidacaoTransacao value for this TransacaoVenda.
     * 
     * @return codigoValidacaoTransacao   * Se trata de um codigo de validacao da transacao que a bandeira
     * retorna para a Cielo, caso essa transacao seja efetuada.
     */
    public java.lang.String getCodigoValidacaoTransacao() {
        return codigoValidacaoTransacao;
    }


    /**
     * Sets the codigoValidacaoTransacao value for this TransacaoVenda.
     * 
     * @param codigoValidacaoTransacao   * Se trata de um codigo de validacao da transacao que a bandeira
     * retorna para a Cielo, caso essa transacao seja efetuada.
     */
    public void setCodigoValidacaoTransacao(java.lang.String codigoValidacaoTransacao) {
        this.codigoValidacaoTransacao = codigoValidacaoTransacao;
    }


    /**
     * Gets the quantidadeDigitosCartao value for this TransacaoVenda.
     * 
     * @return quantidadeDigitosCartao   * quantidade de digitos contidas em um cartao, geralmente sao
     * 16, porem com casos de ter mais caracteres
     */
    public java.math.BigInteger getQuantidadeDigitosCartao() {
        return quantidadeDigitosCartao;
    }


    /**
     * Sets the quantidadeDigitosCartao value for this TransacaoVenda.
     * 
     * @param quantidadeDigitosCartao   * quantidade de digitos contidas em um cartao, geralmente sao
     * 16, porem com casos de ter mais caracteres
     */
    public void setQuantidadeDigitosCartao(java.math.BigInteger quantidadeDigitosCartao) {
        this.quantidadeDigitosCartao = quantidadeDigitosCartao;
    }


    /**
     * Gets the numeroReferenciaOriginalAutorizacao value for this TransacaoVenda.
     * 
     * @return numeroReferenciaOriginalAutorizacao
     */
    public java.lang.String getNumeroReferenciaOriginalAutorizacao() {
        return numeroReferenciaOriginalAutorizacao;
    }


    /**
     * Sets the numeroReferenciaOriginalAutorizacao value for this TransacaoVenda.
     * 
     * @param numeroReferenciaOriginalAutorizacao
     */
    public void setNumeroReferenciaOriginalAutorizacao(java.lang.String numeroReferenciaOriginalAutorizacao) {
        this.numeroReferenciaOriginalAutorizacao = numeroReferenciaOriginalAutorizacao;
    }


    /**
     * Gets the valorTaxaEmbarque value for this TransacaoVenda.
     * 
     * @return valorTaxaEmbarque   * Taxa utilizada para transacao de companhia a�rea
     */
    public java.lang.Double getValorTaxaEmbarque() {
        return valorTaxaEmbarque;
    }


    /**
     * Sets the valorTaxaEmbarque value for this TransacaoVenda.
     * 
     * @param valorTaxaEmbarque   * Taxa utilizada para transacao de companhia a�rea
     */
    public void setValorTaxaEmbarque(java.lang.Double valorTaxaEmbarque) {
        this.valorTaxaEmbarque = valorTaxaEmbarque;
    }


    /**
     * Gets the numeroNSU value for this TransacaoVenda.
     * 
     * @return numeroNSU   * Numero Serial Unico: Identificador que o terminal gera a cada
     * transacao.
     */
    public java.lang.String getNumeroNSU() {
        return numeroNSU;
    }


    /**
     * Sets the numeroNSU value for this TransacaoVenda.
     * 
     * @param numeroNSU   * Numero Serial Unico: Identificador que o terminal gera a cada
     * transacao.
     */
    public void setNumeroNSU(java.lang.String numeroNSU) {
        this.numeroNSU = numeroNSU;
    }


    /**
     * Gets the codigoValidacaoCodigoSeguranca value for this TransacaoVenda.
     * 
     * @return codigoValidacaoCodigoSeguranca   * Se trata de um codigo na qual a bandeira retorna para a Cielo,
     * validando o codigo de seguranca do cartao utilizado na transacao.
     */
    public java.lang.String getCodigoValidacaoCodigoSeguranca() {
        return codigoValidacaoCodigoSeguranca;
    }


    /**
     * Sets the codigoValidacaoCodigoSeguranca value for this TransacaoVenda.
     * 
     * @param codigoValidacaoCodigoSeguranca   * Se trata de um codigo na qual a bandeira retorna para a Cielo,
     * validando o codigo de seguranca do cartao utilizado na transacao.
     */
    public void setCodigoValidacaoCodigoSeguranca(java.lang.String codigoValidacaoCodigoSeguranca) {
        this.codigoValidacaoCodigoSeguranca = codigoValidacaoCodigoSeguranca;
    }


    /**
     * Gets the statusSituacaoReclamacaoTransacao value for this TransacaoVenda.
     * 
     * @return statusSituacaoReclamacaoTransacao   * Status da situacao da Reclamacao da Transacao.
     */
    public java.lang.String getStatusSituacaoReclamacaoTransacao() {
        return statusSituacaoReclamacaoTransacao;
    }


    /**
     * Sets the statusSituacaoReclamacaoTransacao value for this TransacaoVenda.
     * 
     * @param statusSituacaoReclamacaoTransacao   * Status da situacao da Reclamacao da Transacao.
     */
    public void setStatusSituacaoReclamacaoTransacao(java.lang.String statusSituacaoReclamacaoTransacao) {
        this.statusSituacaoReclamacaoTransacao = statusSituacaoReclamacaoTransacao;
    }


    /**
     * Gets the codigoSeguranca value for this TransacaoVenda.
     * 
     * @return codigoSeguranca   * codigo seguranca do cartao
     */
    public java.math.BigInteger getCodigoSeguranca() {
        return codigoSeguranca;
    }


    /**
     * Sets the codigoSeguranca value for this TransacaoVenda.
     * 
     * @param codigoSeguranca   * codigo seguranca do cartao
     */
    public void setCodigoSeguranca(java.math.BigInteger codigoSeguranca) {
        this.codigoSeguranca = codigoSeguranca;
    }


    /**
     * Gets the taxaValorMDR value for this TransacaoVenda.
     * 
     * @return taxaValorMDR   * E a taxa cobrada pela cielo por cada transacao
     */
    public java.lang.Double getTaxaValorMDR() {
        return taxaValorMDR;
    }


    /**
     * Sets the taxaValorMDR value for this TransacaoVenda.
     * 
     * @param taxaValorMDR   * E a taxa cobrada pela cielo por cada transacao
     */
    public void setTaxaValorMDR(java.lang.Double taxaValorMDR) {
        this.taxaValorMDR = taxaValorMDR;
    }


    /**
     * Gets the valorPrazoFlexivel value for this TransacaoVenda.
     * 
     * @return valorPrazoFlexivel   * Valor do prazo flexivel
     */
    public java.lang.Double getValorPrazoFlexivel() {
        return valorPrazoFlexivel;
    }


    /**
     * Sets the valorPrazoFlexivel value for this TransacaoVenda.
     * 
     * @param valorPrazoFlexivel   * Valor do prazo flexivel
     */
    public void setValorPrazoFlexivel(java.lang.Double valorPrazoFlexivel) {
        this.valorPrazoFlexivel = valorPrazoFlexivel;
    }


    /**
     * Gets the categoriaPagamento value for this TransacaoVenda.
     * 
     * @return categoriaPagamento
     */
    public java.lang.String getCategoriaPagamento() {
        return categoriaPagamento;
    }


    /**
     * Sets the categoriaPagamento value for this TransacaoVenda.
     * 
     * @param categoriaPagamento
     */
    public void setCategoriaPagamento(java.lang.String categoriaPagamento) {
        this.categoriaPagamento = categoriaPagamento;
    }


    /**
     * Gets the indicadorVendaDigitada value for this TransacaoVenda.
     * 
     * @return indicadorVendaDigitada   * indicador que indica se este produto permite transacoes de
     * venda digitadas
     */
    public java.lang.Boolean getIndicadorVendaDigitada() {
        return indicadorVendaDigitada;
    }


    /**
     * Sets the indicadorVendaDigitada value for this TransacaoVenda.
     * 
     * @param indicadorVendaDigitada   * indicador que indica se este produto permite transacoes de
     * venda digitadas
     */
    public void setIndicadorVendaDigitada(java.lang.Boolean indicadorVendaDigitada) {
        this.indicadorVendaDigitada = indicadorVendaDigitada;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TransacaoVenda)) return false;
        TransacaoVenda other = (TransacaoVenda) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.numeroTerminal==null && other.getNumeroTerminal()==null) || 
             (this.numeroTerminal!=null &&
              this.numeroTerminal.equals(other.getNumeroTerminal()))) &&
            ((this.numeroReferenciaUnico==null && other.getNumeroReferenciaUnico()==null) || 
             (this.numeroReferenciaUnico!=null &&
              this.numeroReferenciaUnico.equals(other.getNumeroReferenciaUnico()))) &&
            ((this.valorBrutoVenda==null && other.getValorBrutoVenda()==null) || 
             (this.valorBrutoVenda!=null &&
              this.valorBrutoVenda.equals(other.getValorBrutoVenda()))) &&
            ((this.valorComissao==null && other.getValorComissao()==null) || 
             (this.valorComissao!=null &&
              this.valorComissao.equals(other.getValorComissao()))) &&
            ((this.valorIntercambio==null && other.getValorIntercambio()==null) || 
             (this.valorIntercambio!=null &&
              this.valorIntercambio.equals(other.getValorIntercambio()))) &&
            ((this.valorLiquido==null && other.getValorLiquido()==null) || 
             (this.valorLiquido!=null &&
              this.valorLiquido.equals(other.getValorLiquido()))) &&
            ((this.dataCaptura==null && other.getDataCaptura()==null) || 
             (this.dataCaptura!=null &&
              this.dataCaptura.equals(other.getDataCaptura()))) &&
            ((this.codigoVenda==null && other.getCodigoVenda()==null) || 
             (this.codigoVenda!=null &&
              this.codigoVenda.equals(other.getCodigoVenda()))) &&
            ((this.dataAutorizacao==null && other.getDataAutorizacao()==null) || 
             (this.dataAutorizacao!=null &&
              this.dataAutorizacao.equals(other.getDataAutorizacao()))) &&
            ((this.numeroSequenciaUnico==null && other.getNumeroSequenciaUnico()==null) || 
             (this.numeroSequenciaUnico!=null &&
              this.numeroSequenciaUnico.equals(other.getNumeroSequenciaUnico()))) &&
            ((this.numeroCartaoCriptografado==null && other.getNumeroCartaoCriptografado()==null) || 
             (this.numeroCartaoCriptografado!=null &&
              this.numeroCartaoCriptografado.equals(other.getNumeroCartaoCriptografado()))) &&
            ((this.nomeBandeira==null && other.getNomeBandeira()==null) || 
             (this.nomeBandeira!=null &&
              this.nomeBandeira.equals(other.getNomeBandeira()))) &&
            ((this.nomeTipoMaquina==null && other.getNomeTipoMaquina()==null) || 
             (this.nomeTipoMaquina!=null &&
              this.nomeTipoMaquina.equals(other.getNomeTipoMaquina()))) &&
            ((this.nomeAutorizadora==null && other.getNomeAutorizadora()==null) || 
             (this.nomeAutorizadora!=null &&
              this.nomeAutorizadora.equals(other.getNomeAutorizadora()))) &&
            ((this.numeroCartaoTruncado==null && other.getNumeroCartaoTruncado()==null) || 
             (this.numeroCartaoTruncado!=null &&
              this.numeroCartaoTruncado.equals(other.getNumeroCartaoTruncado()))) &&
            ((this.dadosParcela==null && other.getDadosParcela()==null) || 
             (this.dadosParcela!=null &&
              java.util.Arrays.equals(this.dadosParcela, other.getDadosParcela()))) &&
            ((this.nomeTipoPagamento==null && other.getNomeTipoPagamento()==null) || 
             (this.nomeTipoPagamento!=null &&
              this.nomeTipoPagamento.equals(other.getNomeTipoPagamento()))) &&
            ((this.descricaoVersaoTerminal==null && other.getDescricaoVersaoTerminal()==null) || 
             (this.descricaoVersaoTerminal!=null &&
              this.descricaoVersaoTerminal.equals(other.getDescricaoVersaoTerminal()))) &&
            ((this.descricaoVersaoAplicativo==null && other.getDescricaoVersaoAplicativo()==null) || 
             (this.descricaoVersaoAplicativo!=null &&
              this.descricaoVersaoAplicativo.equals(other.getDescricaoVersaoAplicativo()))) &&
            ((this.descricaoRespostaCVV2==null && other.getDescricaoRespostaCVV2()==null) || 
             (this.descricaoRespostaCVV2!=null &&
              this.descricaoRespostaCVV2.equals(other.getDescricaoRespostaCVV2()))) &&
            ((this.codigoTransacaoBandeira==null && other.getCodigoTransacaoBandeira()==null) || 
             (this.codigoTransacaoBandeira!=null &&
              this.codigoTransacaoBandeira.equals(other.getCodigoTransacaoBandeira()))) &&
            ((this.codigoAutorizacao==null && other.getCodigoAutorizacao()==null) || 
             (this.codigoAutorizacao!=null &&
              this.codigoAutorizacao.equals(other.getCodigoAutorizacao()))) &&
            ((this.quantidadeParcela==null && other.getQuantidadeParcela()==null) || 
             (this.quantidadeParcela!=null &&
              this.quantidadeParcela.equals(other.getQuantidadeParcela()))) &&
            ((this.nomeTipoTransacao==null && other.getNomeTipoTransacao()==null) || 
             (this.nomeTipoTransacao!=null &&
              this.nomeTipoTransacao.equals(other.getNomeTipoTransacao()))) &&
            ((this.descricaoCapacidadeTerminal==null && other.getDescricaoCapacidadeTerminal()==null) || 
             (this.descricaoCapacidadeTerminal!=null &&
              this.descricaoCapacidadeTerminal.equals(other.getDescricaoCapacidadeTerminal()))) &&
            ((this.descricaoInformacaoCVV2==null && other.getDescricaoInformacaoCVV2()==null) || 
             (this.descricaoInformacaoCVV2!=null &&
              this.descricaoInformacaoCVV2.equals(other.getDescricaoInformacaoCVV2()))) &&
            ((this.nomeEmissor==null && other.getNomeEmissor()==null) || 
             (this.nomeEmissor!=null &&
              this.nomeEmissor.equals(other.getNomeEmissor()))) &&
            ((this.dadosEventosTransacaoFinanceira==null && other.getDadosEventosTransacaoFinanceira()==null) || 
             (this.dadosEventosTransacaoFinanceira!=null &&
              java.util.Arrays.equals(this.dadosEventosTransacaoFinanceira, other.getDadosEventosTransacaoFinanceira()))) &&
            ((this.codigoServico==null && other.getCodigoServico()==null) || 
             (this.codigoServico!=null &&
              this.codigoServico.equals(other.getCodigoServico()))) &&
            ((this.descricaoTipoTerminal==null && other.getDescricaoTipoTerminal()==null) || 
             (this.descricaoTipoTerminal!=null &&
              this.descricaoTipoTerminal.equals(other.getDescricaoTipoTerminal()))) &&
            ((this.descricaoObservacao==null && other.getDescricaoObservacao()==null) || 
             (this.descricaoObservacao!=null &&
              this.descricaoObservacao.equals(other.getDescricaoObservacao()))) &&
            ((this.descricaoMetodoEntrada==null && other.getDescricaoMetodoEntrada()==null) || 
             (this.descricaoMetodoEntrada!=null &&
              this.descricaoMetodoEntrada.equals(other.getDescricaoMetodoEntrada()))) &&
            ((this.descricaoResposta==null && other.getDescricaoResposta()==null) || 
             (this.descricaoResposta!=null &&
              this.descricaoResposta.equals(other.getDescricaoResposta()))) &&
            ((this.codigoPontoServico==null && other.getCodigoPontoServico()==null) || 
             (this.codigoPontoServico!=null &&
              this.codigoPontoServico.equals(other.getCodigoPontoServico()))) &&
            ((this.descricaoMensagemPOS==null && other.getDescricaoMensagemPOS()==null) || 
             (this.descricaoMensagemPOS!=null &&
              this.descricaoMensagemPOS.equals(other.getDescricaoMensagemPOS()))) &&
            ((this.descricaoFormaEntrada==null && other.getDescricaoFormaEntrada()==null) || 
             (this.descricaoFormaEntrada!=null &&
              this.descricaoFormaEntrada.equals(other.getDescricaoFormaEntrada()))) &&
            ((this.nomeNivelSeguranca==null && other.getNomeNivelSeguranca()==null) || 
             (this.nomeNivelSeguranca!=null &&
              this.nomeNivelSeguranca.equals(other.getNomeNivelSeguranca()))) &&
            ((this.dataCapturaTransacao==null && other.getDataCapturaTransacao()==null) || 
             (this.dataCapturaTransacao!=null &&
              this.dataCapturaTransacao.equals(other.getDataCapturaTransacao()))) &&
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto()))) &&
            ((this.codigoNivelSeguranca==null && other.getCodigoNivelSeguranca()==null) || 
             (this.codigoNivelSeguranca!=null &&
              this.codigoNivelSeguranca.equals(other.getCodigoNivelSeguranca()))) &&
            ((this.descricaoProduto==null && other.getDescricaoProduto()==null) || 
             (this.descricaoProduto!=null &&
              this.descricaoProduto.equals(other.getDescricaoProduto()))) &&
            ((this.numeroCartaoAberto==null && other.getNumeroCartaoAberto()==null) || 
             (this.numeroCartaoAberto!=null &&
              this.numeroCartaoAberto.equals(other.getNumeroCartaoAberto()))) &&
            ((this.vencimentoCartao==null && other.getVencimentoCartao()==null) || 
             (this.vencimentoCartao!=null &&
              this.vencimentoCartao.equals(other.getVencimentoCartao()))) &&
            ((this.numeroTID==null && other.getNumeroTID()==null) || 
             (this.numeroTID!=null &&
              this.numeroTID.equals(other.getNumeroTID()))) &&
            ((this.valorEntrada==null && other.getValorEntrada()==null) || 
             (this.valorEntrada!=null &&
              this.valorEntrada.equals(other.getValorEntrada()))) &&
            ((this.codigoValidacaoTransacao==null && other.getCodigoValidacaoTransacao()==null) || 
             (this.codigoValidacaoTransacao!=null &&
              this.codigoValidacaoTransacao.equals(other.getCodigoValidacaoTransacao()))) &&
            ((this.quantidadeDigitosCartao==null && other.getQuantidadeDigitosCartao()==null) || 
             (this.quantidadeDigitosCartao!=null &&
              this.quantidadeDigitosCartao.equals(other.getQuantidadeDigitosCartao()))) &&
            ((this.numeroReferenciaOriginalAutorizacao==null && other.getNumeroReferenciaOriginalAutorizacao()==null) || 
             (this.numeroReferenciaOriginalAutorizacao!=null &&
              this.numeroReferenciaOriginalAutorizacao.equals(other.getNumeroReferenciaOriginalAutorizacao()))) &&
            ((this.valorTaxaEmbarque==null && other.getValorTaxaEmbarque()==null) || 
             (this.valorTaxaEmbarque!=null &&
              this.valorTaxaEmbarque.equals(other.getValorTaxaEmbarque()))) &&
            ((this.numeroNSU==null && other.getNumeroNSU()==null) || 
             (this.numeroNSU!=null &&
              this.numeroNSU.equals(other.getNumeroNSU()))) &&
            ((this.codigoValidacaoCodigoSeguranca==null && other.getCodigoValidacaoCodigoSeguranca()==null) || 
             (this.codigoValidacaoCodigoSeguranca!=null &&
              this.codigoValidacaoCodigoSeguranca.equals(other.getCodigoValidacaoCodigoSeguranca()))) &&
            ((this.statusSituacaoReclamacaoTransacao==null && other.getStatusSituacaoReclamacaoTransacao()==null) || 
             (this.statusSituacaoReclamacaoTransacao!=null &&
              this.statusSituacaoReclamacaoTransacao.equals(other.getStatusSituacaoReclamacaoTransacao()))) &&
            ((this.codigoSeguranca==null && other.getCodigoSeguranca()==null) || 
             (this.codigoSeguranca!=null &&
              this.codigoSeguranca.equals(other.getCodigoSeguranca()))) &&
            ((this.taxaValorMDR==null && other.getTaxaValorMDR()==null) || 
             (this.taxaValorMDR!=null &&
              this.taxaValorMDR.equals(other.getTaxaValorMDR()))) &&
            ((this.valorPrazoFlexivel==null && other.getValorPrazoFlexivel()==null) || 
             (this.valorPrazoFlexivel!=null &&
              this.valorPrazoFlexivel.equals(other.getValorPrazoFlexivel()))) &&
            ((this.categoriaPagamento==null && other.getCategoriaPagamento()==null) || 
             (this.categoriaPagamento!=null &&
              this.categoriaPagamento.equals(other.getCategoriaPagamento()))) &&
            ((this.indicadorVendaDigitada==null && other.getIndicadorVendaDigitada()==null) || 
             (this.indicadorVendaDigitada!=null &&
              this.indicadorVendaDigitada.equals(other.getIndicadorVendaDigitada())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getNumeroTerminal() != null) {
            _hashCode += getNumeroTerminal().hashCode();
        }
        if (getNumeroReferenciaUnico() != null) {
            _hashCode += getNumeroReferenciaUnico().hashCode();
        }
        if (getValorBrutoVenda() != null) {
            _hashCode += getValorBrutoVenda().hashCode();
        }
        if (getValorComissao() != null) {
            _hashCode += getValorComissao().hashCode();
        }
        if (getValorIntercambio() != null) {
            _hashCode += getValorIntercambio().hashCode();
        }
        if (getValorLiquido() != null) {
            _hashCode += getValorLiquido().hashCode();
        }
        if (getDataCaptura() != null) {
            _hashCode += getDataCaptura().hashCode();
        }
        if (getCodigoVenda() != null) {
            _hashCode += getCodigoVenda().hashCode();
        }
        if (getDataAutorizacao() != null) {
            _hashCode += getDataAutorizacao().hashCode();
        }
        if (getNumeroSequenciaUnico() != null) {
            _hashCode += getNumeroSequenciaUnico().hashCode();
        }
        if (getNumeroCartaoCriptografado() != null) {
            _hashCode += getNumeroCartaoCriptografado().hashCode();
        }
        if (getNomeBandeira() != null) {
            _hashCode += getNomeBandeira().hashCode();
        }
        if (getNomeTipoMaquina() != null) {
            _hashCode += getNomeTipoMaquina().hashCode();
        }
        if (getNomeAutorizadora() != null) {
            _hashCode += getNomeAutorizadora().hashCode();
        }
        if (getNumeroCartaoTruncado() != null) {
            _hashCode += getNumeroCartaoTruncado().hashCode();
        }
        if (getDadosParcela() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosParcela());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosParcela(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNomeTipoPagamento() != null) {
            _hashCode += getNomeTipoPagamento().hashCode();
        }
        if (getDescricaoVersaoTerminal() != null) {
            _hashCode += getDescricaoVersaoTerminal().hashCode();
        }
        if (getDescricaoVersaoAplicativo() != null) {
            _hashCode += getDescricaoVersaoAplicativo().hashCode();
        }
        if (getDescricaoRespostaCVV2() != null) {
            _hashCode += getDescricaoRespostaCVV2().hashCode();
        }
        if (getCodigoTransacaoBandeira() != null) {
            _hashCode += getCodigoTransacaoBandeira().hashCode();
        }
        if (getCodigoAutorizacao() != null) {
            _hashCode += getCodigoAutorizacao().hashCode();
        }
        if (getQuantidadeParcela() != null) {
            _hashCode += getQuantidadeParcela().hashCode();
        }
        if (getNomeTipoTransacao() != null) {
            _hashCode += getNomeTipoTransacao().hashCode();
        }
        if (getDescricaoCapacidadeTerminal() != null) {
            _hashCode += getDescricaoCapacidadeTerminal().hashCode();
        }
        if (getDescricaoInformacaoCVV2() != null) {
            _hashCode += getDescricaoInformacaoCVV2().hashCode();
        }
        if (getNomeEmissor() != null) {
            _hashCode += getNomeEmissor().hashCode();
        }
        if (getDadosEventosTransacaoFinanceira() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosEventosTransacaoFinanceira());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosEventosTransacaoFinanceira(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodigoServico() != null) {
            _hashCode += getCodigoServico().hashCode();
        }
        if (getDescricaoTipoTerminal() != null) {
            _hashCode += getDescricaoTipoTerminal().hashCode();
        }
        if (getDescricaoObservacao() != null) {
            _hashCode += getDescricaoObservacao().hashCode();
        }
        if (getDescricaoMetodoEntrada() != null) {
            _hashCode += getDescricaoMetodoEntrada().hashCode();
        }
        if (getDescricaoResposta() != null) {
            _hashCode += getDescricaoResposta().hashCode();
        }
        if (getCodigoPontoServico() != null) {
            _hashCode += getCodigoPontoServico().hashCode();
        }
        if (getDescricaoMensagemPOS() != null) {
            _hashCode += getDescricaoMensagemPOS().hashCode();
        }
        if (getDescricaoFormaEntrada() != null) {
            _hashCode += getDescricaoFormaEntrada().hashCode();
        }
        if (getNomeNivelSeguranca() != null) {
            _hashCode += getNomeNivelSeguranca().hashCode();
        }
        if (getDataCapturaTransacao() != null) {
            _hashCode += getDataCapturaTransacao().hashCode();
        }
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        if (getCodigoNivelSeguranca() != null) {
            _hashCode += getCodigoNivelSeguranca().hashCode();
        }
        if (getDescricaoProduto() != null) {
            _hashCode += getDescricaoProduto().hashCode();
        }
        if (getNumeroCartaoAberto() != null) {
            _hashCode += getNumeroCartaoAberto().hashCode();
        }
        if (getVencimentoCartao() != null) {
            _hashCode += getVencimentoCartao().hashCode();
        }
        if (getNumeroTID() != null) {
            _hashCode += getNumeroTID().hashCode();
        }
        if (getValorEntrada() != null) {
            _hashCode += getValorEntrada().hashCode();
        }
        if (getCodigoValidacaoTransacao() != null) {
            _hashCode += getCodigoValidacaoTransacao().hashCode();
        }
        if (getQuantidadeDigitosCartao() != null) {
            _hashCode += getQuantidadeDigitosCartao().hashCode();
        }
        if (getNumeroReferenciaOriginalAutorizacao() != null) {
            _hashCode += getNumeroReferenciaOriginalAutorizacao().hashCode();
        }
        if (getValorTaxaEmbarque() != null) {
            _hashCode += getValorTaxaEmbarque().hashCode();
        }
        if (getNumeroNSU() != null) {
            _hashCode += getNumeroNSU().hashCode();
        }
        if (getCodigoValidacaoCodigoSeguranca() != null) {
            _hashCode += getCodigoValidacaoCodigoSeguranca().hashCode();
        }
        if (getStatusSituacaoReclamacaoTransacao() != null) {
            _hashCode += getStatusSituacaoReclamacaoTransacao().hashCode();
        }
        if (getCodigoSeguranca() != null) {
            _hashCode += getCodigoSeguranca().hashCode();
        }
        if (getTaxaValorMDR() != null) {
            _hashCode += getTaxaValorMDR().hashCode();
        }
        if (getValorPrazoFlexivel() != null) {
            _hashCode += getValorPrazoFlexivel().hashCode();
        }
        if (getCategoriaPagamento() != null) {
            _hashCode += getCategoriaPagamento().hashCode();
        }
        if (getIndicadorVendaDigitada() != null) {
            _hashCode += getIndicadorVendaDigitada().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TransacaoVenda.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "TransacaoVenda"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroReferenciaUnico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroReferenciaUnico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorBrutoVenda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorBrutoVenda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorComissao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorComissao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorIntercambio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorIntercambio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorLiquido");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorLiquido"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dataCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoVenda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoVenda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataAutorizacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dataAutorizacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroSequenciaUnico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroSequenciaUnico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCartaoCriptografado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroCartaoCriptografado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoMaquina");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeTipoMaquina"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeAutorizadora");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeAutorizadora"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCartaoTruncado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroCartaoTruncado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosParcela");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dadosParcela"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "ParcelaTransacaoVenda"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoPagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeTipoPagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoVersaoTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoVersaoTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoVersaoAplicativo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoVersaoAplicativo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRespostaCVV2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoRespostaCVV2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTransacaoBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoTransacaoBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoAutorizacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoAutorizacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeParcela");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "quantidadeParcela"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeTipoTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeTipoTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoCapacidadeTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoCapacidadeTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoInformacaoCVV2");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoInformacaoCVV2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEmissor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeEmissor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEventosTransacaoFinanceira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dadosEventosTransacaoFinanceira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "EventoTransacaoVenda"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "eventoTransacaoVenda"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoTipoTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoTipoTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoObservacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoObservacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoMetodoEntrada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoMetodoEntrada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoResposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoResposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoPontoServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoPontoServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoMensagemPOS");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoMensagemPOS"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoFormaEntrada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoFormaEntrada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeNivelSeguranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "nomeNivelSeguranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataCapturaTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dataCapturaTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoNivelSeguranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoNivelSeguranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCartaoAberto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroCartaoAberto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vencimentoCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "vencimentoCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroTID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorEntrada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorEntrada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoValidacaoTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoValidacaoTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeDigitosCartao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "quantidadeDigitosCartao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroReferenciaOriginalAutorizacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroReferenciaOriginalAutorizacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorTaxaEmbarque");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorTaxaEmbarque"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroNSU");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroNSU"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoValidacaoCodigoSeguranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoValidacaoCodigoSeguranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusSituacaoReclamacaoTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "statusSituacaoReclamacaoTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSeguranca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "codigoSeguranca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaValorMDR");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "taxaValorMDR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("categoriaPagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "categoriaPagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVendaDigitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "indicadorVendaDigitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
