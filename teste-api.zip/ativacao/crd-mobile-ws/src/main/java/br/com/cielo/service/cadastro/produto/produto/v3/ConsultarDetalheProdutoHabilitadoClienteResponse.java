/**
 * ConsultarDetalheProdutoHabilitadoClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarDetalheProdutoHabilitadoClienteResponse  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] produtoContratadoCliente;

    private br.com.cielo.canonico.cadastro.v1.Produto produto;

    private br.com.cielo.canonico.cadastro.v1.Banco banco;

    private br.com.cielo.canonico.cadastro.v1.Cliente cliente;

    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    public ConsultarDetalheProdutoHabilitadoClienteResponse() {
    }

    public ConsultarDetalheProdutoHabilitadoClienteResponse(
           br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] produtoContratadoCliente,
           br.com.cielo.canonico.cadastro.v1.Produto produto,
           br.com.cielo.canonico.cadastro.v1.Banco banco,
           br.com.cielo.canonico.cadastro.v1.Cliente cliente,
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem) {
           this.produtoContratadoCliente = produtoContratadoCliente;
           this.produto = produto;
           this.banco = banco;
           this.cliente = cliente;
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the produtoContratadoCliente value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @return produtoContratadoCliente
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] getProdutoContratadoCliente() {
        return produtoContratadoCliente;
    }


    /**
     * Sets the produtoContratadoCliente value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @param produtoContratadoCliente
     */
    public void setProdutoContratadoCliente(br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] produtoContratadoCliente) {
        this.produtoContratadoCliente = produtoContratadoCliente;
    }


    /**
     * Gets the produto value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @return produto
     */
    public br.com.cielo.canonico.cadastro.v1.Produto getProduto() {
        return produto;
    }


    /**
     * Sets the produto value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @param produto
     */
    public void setProduto(br.com.cielo.canonico.cadastro.v1.Produto produto) {
        this.produto = produto;
    }


    /**
     * Gets the banco value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @return banco
     */
    public br.com.cielo.canonico.cadastro.v1.Banco getBanco() {
        return banco;
    }


    /**
     * Sets the banco value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @param banco
     */
    public void setBanco(br.com.cielo.canonico.cadastro.v1.Banco banco) {
        this.banco = banco;
    }


    /**
     * Gets the cliente value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @return cliente
     */
    public br.com.cielo.canonico.cadastro.v1.Cliente getCliente() {
        return cliente;
    }


    /**
     * Sets the cliente value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @param cliente
     */
    public void setCliente(br.com.cielo.canonico.cadastro.v1.Cliente cliente) {
        this.cliente = cliente;
    }


    /**
     * Gets the codigoRetorno value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this ConsultarDetalheProdutoHabilitadoClienteResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDetalheProdutoHabilitadoClienteResponse)) return false;
        ConsultarDetalheProdutoHabilitadoClienteResponse other = (ConsultarDetalheProdutoHabilitadoClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.produtoContratadoCliente==null && other.getProdutoContratadoCliente()==null) || 
             (this.produtoContratadoCliente!=null &&
              java.util.Arrays.equals(this.produtoContratadoCliente, other.getProdutoContratadoCliente()))) &&
            ((this.produto==null && other.getProduto()==null) || 
             (this.produto!=null &&
              this.produto.equals(other.getProduto()))) &&
            ((this.banco==null && other.getBanco()==null) || 
             (this.banco!=null &&
              this.banco.equals(other.getBanco()))) &&
            ((this.cliente==null && other.getCliente()==null) || 
             (this.cliente!=null &&
              this.cliente.equals(other.getCliente()))) &&
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProdutoContratadoCliente() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProdutoContratadoCliente());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProdutoContratadoCliente(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProduto() != null) {
            _hashCode += getProduto().hashCode();
        }
        if (getBanco() != null) {
            _hashCode += getBanco().hashCode();
        }
        if (getCliente() != null) {
            _hashCode += getCliente().hashCode();
        }
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDetalheProdutoHabilitadoClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarDetalheProdutoHabilitadoClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produtoContratadoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtoContratadoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ProdutoContratadoClienteType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtoContratadoCliente"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("banco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "banco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Banco"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "cliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Cliente"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
