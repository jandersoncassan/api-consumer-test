/**
 * HabilitarProdutoResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class HabilitarProdutoResponse  implements java.io.Serializable {
    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    private java.lang.String statusRetorno;

    private java.lang.String sistemaLegado;

    private br.com.cielo.canonico.canalrelacionamento.atendimentoassistido.v1.SolicitacaoCentralAtendimento solicitacaoCentralAtendimento;

    public HabilitarProdutoResponse() {
    }

    public HabilitarProdutoResponse(
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem,
           java.lang.String statusRetorno,
           java.lang.String sistemaLegado,
           br.com.cielo.canonico.canalrelacionamento.atendimentoassistido.v1.SolicitacaoCentralAtendimento solicitacaoCentralAtendimento) {
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
           this.statusRetorno = statusRetorno;
           this.sistemaLegado = sistemaLegado;
           this.solicitacaoCentralAtendimento = solicitacaoCentralAtendimento;
    }


    /**
     * Gets the codigoRetorno value for this HabilitarProdutoResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this HabilitarProdutoResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this HabilitarProdutoResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this HabilitarProdutoResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the statusRetorno value for this HabilitarProdutoResponse.
     * 
     * @return statusRetorno
     */
    public java.lang.String getStatusRetorno() {
        return statusRetorno;
    }


    /**
     * Sets the statusRetorno value for this HabilitarProdutoResponse.
     * 
     * @param statusRetorno
     */
    public void setStatusRetorno(java.lang.String statusRetorno) {
        this.statusRetorno = statusRetorno;
    }


    /**
     * Gets the sistemaLegado value for this HabilitarProdutoResponse.
     * 
     * @return sistemaLegado
     */
    public java.lang.String getSistemaLegado() {
        return sistemaLegado;
    }


    /**
     * Sets the sistemaLegado value for this HabilitarProdutoResponse.
     * 
     * @param sistemaLegado
     */
    public void setSistemaLegado(java.lang.String sistemaLegado) {
        this.sistemaLegado = sistemaLegado;
    }


    /**
     * Gets the solicitacaoCentralAtendimento value for this HabilitarProdutoResponse.
     * 
     * @return solicitacaoCentralAtendimento
     */
    public br.com.cielo.canonico.canalrelacionamento.atendimentoassistido.v1.SolicitacaoCentralAtendimento getSolicitacaoCentralAtendimento() {
        return solicitacaoCentralAtendimento;
    }


    /**
     * Sets the solicitacaoCentralAtendimento value for this HabilitarProdutoResponse.
     * 
     * @param solicitacaoCentralAtendimento
     */
    public void setSolicitacaoCentralAtendimento(br.com.cielo.canonico.canalrelacionamento.atendimentoassistido.v1.SolicitacaoCentralAtendimento solicitacaoCentralAtendimento) {
        this.solicitacaoCentralAtendimento = solicitacaoCentralAtendimento;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HabilitarProdutoResponse)) return false;
        HabilitarProdutoResponse other = (HabilitarProdutoResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem()))) &&
            ((this.statusRetorno==null && other.getStatusRetorno()==null) || 
             (this.statusRetorno!=null &&
              this.statusRetorno.equals(other.getStatusRetorno()))) &&
            ((this.sistemaLegado==null && other.getSistemaLegado()==null) || 
             (this.sistemaLegado!=null &&
              this.sistemaLegado.equals(other.getSistemaLegado()))) &&
            ((this.solicitacaoCentralAtendimento==null && other.getSolicitacaoCentralAtendimento()==null) || 
             (this.solicitacaoCentralAtendimento!=null &&
              this.solicitacaoCentralAtendimento.equals(other.getSolicitacaoCentralAtendimento())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        if (getStatusRetorno() != null) {
            _hashCode += getStatusRetorno().hashCode();
        }
        if (getSistemaLegado() != null) {
            _hashCode += getSistemaLegado().hashCode();
        }
        if (getSolicitacaoCentralAtendimento() != null) {
            _hashCode += getSolicitacaoCentralAtendimento().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HabilitarProdutoResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">habilitarProdutoResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "statusRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sistemaLegado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "sistemaLegado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solicitacaoCentralAtendimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "solicitacaoCentralAtendimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/canalrelacionamento/atendimentoassistido/v1", "SolicitacaoCentralAtendimento"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
