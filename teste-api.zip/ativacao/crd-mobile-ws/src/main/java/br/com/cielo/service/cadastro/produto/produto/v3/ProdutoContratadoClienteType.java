/**
 * ProdutoContratadoClienteType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ProdutoContratadoClienteType  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.ProdutoContratadoCliente produtoContratadoCliente;

    private java.lang.Boolean indicadorVendaUltimoMes;

    private java.math.BigInteger ordemApresentacao;

    private java.lang.String tipoGrupoProduto;

    /* Grupo de produtos de prazo flexível. */
    private br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType grupoProdutoPrazoFlexivel;

    /* Canal do produto adquirido. */
    private java.lang.String descricaoCanalVenda;

    /* Informa se o produto possui cobrança de taxas de forma segmentada. */
    private java.lang.Boolean indicadorTaxaSegmentada;

    /* Informa se o produto possui prazo flexível. */
    private java.lang.Boolean indicadorPrazoFlexivel;

    /* Exibe o modelo comercial do produto (VAN/Adquirência) */
    private java.lang.String nomeModeloComercial;

    public ProdutoContratadoClienteType() {
    }

    public ProdutoContratadoClienteType(
           br.com.cielo.canonico.cadastro.v1.ProdutoContratadoCliente produtoContratadoCliente,
           java.lang.Boolean indicadorVendaUltimoMes,
           java.math.BigInteger ordemApresentacao,
           java.lang.String tipoGrupoProduto,
           br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType grupoProdutoPrazoFlexivel,
           java.lang.String descricaoCanalVenda,
           java.lang.Boolean indicadorTaxaSegmentada,
           java.lang.Boolean indicadorPrazoFlexivel,
           java.lang.String nomeModeloComercial) {
           this.produtoContratadoCliente = produtoContratadoCliente;
           this.indicadorVendaUltimoMes = indicadorVendaUltimoMes;
           this.ordemApresentacao = ordemApresentacao;
           this.tipoGrupoProduto = tipoGrupoProduto;
           this.grupoProdutoPrazoFlexivel = grupoProdutoPrazoFlexivel;
           this.descricaoCanalVenda = descricaoCanalVenda;
           this.indicadorTaxaSegmentada = indicadorTaxaSegmentada;
           this.indicadorPrazoFlexivel = indicadorPrazoFlexivel;
           this.nomeModeloComercial = nomeModeloComercial;
    }


    /**
     * Gets the produtoContratadoCliente value for this ProdutoContratadoClienteType.
     * 
     * @return produtoContratadoCliente
     */
    public br.com.cielo.canonico.cadastro.v1.ProdutoContratadoCliente getProdutoContratadoCliente() {
        return produtoContratadoCliente;
    }


    /**
     * Sets the produtoContratadoCliente value for this ProdutoContratadoClienteType.
     * 
     * @param produtoContratadoCliente
     */
    public void setProdutoContratadoCliente(br.com.cielo.canonico.cadastro.v1.ProdutoContratadoCliente produtoContratadoCliente) {
        this.produtoContratadoCliente = produtoContratadoCliente;
    }


    /**
     * Gets the indicadorVendaUltimoMes value for this ProdutoContratadoClienteType.
     * 
     * @return indicadorVendaUltimoMes
     */
    public java.lang.Boolean getIndicadorVendaUltimoMes() {
        return indicadorVendaUltimoMes;
    }


    /**
     * Sets the indicadorVendaUltimoMes value for this ProdutoContratadoClienteType.
     * 
     * @param indicadorVendaUltimoMes
     */
    public void setIndicadorVendaUltimoMes(java.lang.Boolean indicadorVendaUltimoMes) {
        this.indicadorVendaUltimoMes = indicadorVendaUltimoMes;
    }


    /**
     * Gets the ordemApresentacao value for this ProdutoContratadoClienteType.
     * 
     * @return ordemApresentacao
     */
    public java.math.BigInteger getOrdemApresentacao() {
        return ordemApresentacao;
    }


    /**
     * Sets the ordemApresentacao value for this ProdutoContratadoClienteType.
     * 
     * @param ordemApresentacao
     */
    public void setOrdemApresentacao(java.math.BigInteger ordemApresentacao) {
        this.ordemApresentacao = ordemApresentacao;
    }


    /**
     * Gets the tipoGrupoProduto value for this ProdutoContratadoClienteType.
     * 
     * @return tipoGrupoProduto
     */
    public java.lang.String getTipoGrupoProduto() {
        return tipoGrupoProduto;
    }


    /**
     * Sets the tipoGrupoProduto value for this ProdutoContratadoClienteType.
     * 
     * @param tipoGrupoProduto
     */
    public void setTipoGrupoProduto(java.lang.String tipoGrupoProduto) {
        this.tipoGrupoProduto = tipoGrupoProduto;
    }


    /**
     * Gets the grupoProdutoPrazoFlexivel value for this ProdutoContratadoClienteType.
     * 
     * @return grupoProdutoPrazoFlexivel   * Grupo de produtos de prazo flexível.
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType getGrupoProdutoPrazoFlexivel() {
        return grupoProdutoPrazoFlexivel;
    }


    /**
     * Sets the grupoProdutoPrazoFlexivel value for this ProdutoContratadoClienteType.
     * 
     * @param grupoProdutoPrazoFlexivel   * Grupo de produtos de prazo flexível.
     */
    public void setGrupoProdutoPrazoFlexivel(br.com.cielo.service.cadastro.produto.produto.v3.GrupoProdutoPrazoFlexivelType grupoProdutoPrazoFlexivel) {
        this.grupoProdutoPrazoFlexivel = grupoProdutoPrazoFlexivel;
    }


    /**
     * Gets the descricaoCanalVenda value for this ProdutoContratadoClienteType.
     * 
     * @return descricaoCanalVenda   * Canal do produto adquirido.
     */
    public java.lang.String getDescricaoCanalVenda() {
        return descricaoCanalVenda;
    }


    /**
     * Sets the descricaoCanalVenda value for this ProdutoContratadoClienteType.
     * 
     * @param descricaoCanalVenda   * Canal do produto adquirido.
     */
    public void setDescricaoCanalVenda(java.lang.String descricaoCanalVenda) {
        this.descricaoCanalVenda = descricaoCanalVenda;
    }


    /**
     * Gets the indicadorTaxaSegmentada value for this ProdutoContratadoClienteType.
     * 
     * @return indicadorTaxaSegmentada   * Informa se o produto possui cobrança de taxas de forma segmentada.
     */
    public java.lang.Boolean getIndicadorTaxaSegmentada() {
        return indicadorTaxaSegmentada;
    }


    /**
     * Sets the indicadorTaxaSegmentada value for this ProdutoContratadoClienteType.
     * 
     * @param indicadorTaxaSegmentada   * Informa se o produto possui cobrança de taxas de forma segmentada.
     */
    public void setIndicadorTaxaSegmentada(java.lang.Boolean indicadorTaxaSegmentada) {
        this.indicadorTaxaSegmentada = indicadorTaxaSegmentada;
    }


    /**
     * Gets the indicadorPrazoFlexivel value for this ProdutoContratadoClienteType.
     * 
     * @return indicadorPrazoFlexivel   * Informa se o produto possui prazo flexível.
     */
    public java.lang.Boolean getIndicadorPrazoFlexivel() {
        return indicadorPrazoFlexivel;
    }


    /**
     * Sets the indicadorPrazoFlexivel value for this ProdutoContratadoClienteType.
     * 
     * @param indicadorPrazoFlexivel   * Informa se o produto possui prazo flexível.
     */
    public void setIndicadorPrazoFlexivel(java.lang.Boolean indicadorPrazoFlexivel) {
        this.indicadorPrazoFlexivel = indicadorPrazoFlexivel;
    }


    /**
     * Gets the nomeModeloComercial value for this ProdutoContratadoClienteType.
     * 
     * @return nomeModeloComercial   * Exibe o modelo comercial do produto (VAN/Adquirência)
     */
    public java.lang.String getNomeModeloComercial() {
        return nomeModeloComercial;
    }


    /**
     * Sets the nomeModeloComercial value for this ProdutoContratadoClienteType.
     * 
     * @param nomeModeloComercial   * Exibe o modelo comercial do produto (VAN/Adquirência)
     */
    public void setNomeModeloComercial(java.lang.String nomeModeloComercial) {
        this.nomeModeloComercial = nomeModeloComercial;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProdutoContratadoClienteType)) return false;
        ProdutoContratadoClienteType other = (ProdutoContratadoClienteType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.produtoContratadoCliente==null && other.getProdutoContratadoCliente()==null) || 
             (this.produtoContratadoCliente!=null &&
              this.produtoContratadoCliente.equals(other.getProdutoContratadoCliente()))) &&
            ((this.indicadorVendaUltimoMes==null && other.getIndicadorVendaUltimoMes()==null) || 
             (this.indicadorVendaUltimoMes!=null &&
              this.indicadorVendaUltimoMes.equals(other.getIndicadorVendaUltimoMes()))) &&
            ((this.ordemApresentacao==null && other.getOrdemApresentacao()==null) || 
             (this.ordemApresentacao!=null &&
              this.ordemApresentacao.equals(other.getOrdemApresentacao()))) &&
            ((this.tipoGrupoProduto==null && other.getTipoGrupoProduto()==null) || 
             (this.tipoGrupoProduto!=null &&
              this.tipoGrupoProduto.equals(other.getTipoGrupoProduto()))) &&
            ((this.grupoProdutoPrazoFlexivel==null && other.getGrupoProdutoPrazoFlexivel()==null) || 
             (this.grupoProdutoPrazoFlexivel!=null &&
              this.grupoProdutoPrazoFlexivel.equals(other.getGrupoProdutoPrazoFlexivel()))) &&
            ((this.descricaoCanalVenda==null && other.getDescricaoCanalVenda()==null) || 
             (this.descricaoCanalVenda!=null &&
              this.descricaoCanalVenda.equals(other.getDescricaoCanalVenda()))) &&
            ((this.indicadorTaxaSegmentada==null && other.getIndicadorTaxaSegmentada()==null) || 
             (this.indicadorTaxaSegmentada!=null &&
              this.indicadorTaxaSegmentada.equals(other.getIndicadorTaxaSegmentada()))) &&
            ((this.indicadorPrazoFlexivel==null && other.getIndicadorPrazoFlexivel()==null) || 
             (this.indicadorPrazoFlexivel!=null &&
              this.indicadorPrazoFlexivel.equals(other.getIndicadorPrazoFlexivel()))) &&
            ((this.nomeModeloComercial==null && other.getNomeModeloComercial()==null) || 
             (this.nomeModeloComercial!=null &&
              this.nomeModeloComercial.equals(other.getNomeModeloComercial())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProdutoContratadoCliente() != null) {
            _hashCode += getProdutoContratadoCliente().hashCode();
        }
        if (getIndicadorVendaUltimoMes() != null) {
            _hashCode += getIndicadorVendaUltimoMes().hashCode();
        }
        if (getOrdemApresentacao() != null) {
            _hashCode += getOrdemApresentacao().hashCode();
        }
        if (getTipoGrupoProduto() != null) {
            _hashCode += getTipoGrupoProduto().hashCode();
        }
        if (getGrupoProdutoPrazoFlexivel() != null) {
            _hashCode += getGrupoProdutoPrazoFlexivel().hashCode();
        }
        if (getDescricaoCanalVenda() != null) {
            _hashCode += getDescricaoCanalVenda().hashCode();
        }
        if (getIndicadorTaxaSegmentada() != null) {
            _hashCode += getIndicadorTaxaSegmentada().hashCode();
        }
        if (getIndicadorPrazoFlexivel() != null) {
            _hashCode += getIndicadorPrazoFlexivel().hashCode();
        }
        if (getNomeModeloComercial() != null) {
            _hashCode += getNomeModeloComercial().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProdutoContratadoClienteType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ProdutoContratadoClienteType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produtoContratadoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtoContratadoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "ProdutoContratadoCliente"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVendaUltimoMes");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "indicadorVendaUltimoMes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ordemApresentacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ordemApresentacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoGrupoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "tipoGrupoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grupoProdutoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "grupoProdutoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "GrupoProdutoPrazoFlexivelType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoCanalVenda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoCanalVenda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorTaxaSegmentada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "indicadorTaxaSegmentada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "indicadorPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeModeloComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "nomeModeloComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
