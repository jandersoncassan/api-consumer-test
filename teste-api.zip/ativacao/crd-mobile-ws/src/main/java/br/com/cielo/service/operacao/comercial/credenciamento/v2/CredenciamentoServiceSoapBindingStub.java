/**
 * CredenciamentoServiceSoapBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class CredenciamentoServiceSoapBindingStub extends org.apache.axis.client.Stub implements br.com.cielo.service.operacao.comercial.credenciamento.v2.CredenciamentoPortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[5];
        _initOperationDesc1();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("verificarExistenciaDomicilioBancario");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "verificarExistenciaDomicilioBancarioRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">verificarExistenciaDomicilioBancarioRequest"), br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">verificarExistenciaDomicilioBancarioResponse"));
        oper.setReturnClass(br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "verificarExistenciaDomicilioBancarioResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("incluirProposta");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "incluirPropostaRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">incluirPropostaRequest"), br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">incluirPropostaResponse"));
        oper.setReturnClass(br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "incluirPropostaResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("alterarProposta");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "alterarPropostaRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">alterarPropostaRequest"), br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">alterarPropostaResponse"));
        oper.setReturnClass(br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "alterarPropostaResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("ligarAlarmeExcecao");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "ligarAlarmeExcecaoRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">ligarAlarmeExcecaoRequest"), br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">ligarAlarmeExcecaoResponse"));
        oper.setReturnClass(br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "ligarAlarmeExcecaoResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("desligarAlarmeExcecao");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "desligarAlarmeExcecaoRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">desligarAlarmeExcecaoRequest"), br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">desligarAlarmeExcecaoResponse"));
        oper.setReturnClass(br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "desligarAlarmeExcecaoResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[4] = oper;

    }

    public CredenciamentoServiceSoapBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public CredenciamentoServiceSoapBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public CredenciamentoServiceSoapBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.Fault.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "FaultDetail");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.FaultDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Tipo");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.Tipo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "faultcode");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.Faultcode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "IdentificacaoRequestType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.IdentificacaoRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "UsuarioType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>alterarPropostaRequest>categoriaCredenciamento");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCategoriaCredenciamento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>alterarPropostaRequest>codigoTipoPessoa");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestCodigoTipoPessoa.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>alterarPropostaRequest>prioridadeProposta");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequestPrioridadeProposta.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>incluirPropostaRequest>categoriaCredenciamento");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequestCategoriaCredenciamento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>incluirPropostaRequest>codigoTipoPessoa");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequestCodigoTipoPessoa.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">>incluirPropostaRequest>prioridadeProposta");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequestPrioridadeProposta.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">alterarPropostaRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">alterarPropostaResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">desligarAlarmeExcecaoRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">desligarAlarmeExcecaoResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">enderecoType>tipoEndereco");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoTypeTipoEndereco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">incluirPropostaRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">incluirPropostaResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">ligarAlarmeExcecaoRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">ligarAlarmeExcecaoResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">solucaoCapturaAlterarPropostaType>melhorDiaIntalacao");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaTypeMelhorDiaIntalacao.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">solucaoCapturaType>melhorDiaIntalacao");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaTypeMelhorDiaIntalacao.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">telefoneType>tipoTelefone");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneTypeTipoTelefone.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">verificarExistenciaDomicilioBancarioRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">verificarExistenciaDomicilioBancarioResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "bancoType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.BancoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "dadosProprietarioType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.DadosProprietarioType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "enderecoType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.EnderecoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "produtoAlterarPropostaType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoAlterarPropostaType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "produtoType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.ProdutoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "servicoAlterarPropostaType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoAlterarPropostaType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "servicoType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.ServicoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "solucaoCapturaAlterarPropostaType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "solucaoCapturaType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "telefoneType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.operacao.comercial.credenciamento.v2.TelefoneType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse verificarExistenciaDomicilioBancario(br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://service.cielo.com.br/operacao/comercial/credenciamento/v2/verificarExistenciaDomicilioBancario");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "verificarExistenciaDomicilioBancario"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse incluirProposta(br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://service.cielo.com.br/operacao/comercial/credenciamento/v2/incluirProposta");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "incluirProposta"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse alterarProposta(br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://service.cielo.com.br/operacao/comercial/credenciamento/v2/incluirProposta");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "alterarProposta"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse ligarAlarmeExcecao(br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://service.cielo.com.br/operacao/comercial/credenciamento/v2/ligarAlarmeExcecao");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "ligarAlarmeExcecao"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse desligarAlarmeExcecao(br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setUseSOAPAction(true);
        _call.setSOAPActionURI("http://service.cielo.com.br/operacao/comercial/credenciamento/v2/ligarAlarmeExcecao");
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "desligarAlarmeExcecao"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
