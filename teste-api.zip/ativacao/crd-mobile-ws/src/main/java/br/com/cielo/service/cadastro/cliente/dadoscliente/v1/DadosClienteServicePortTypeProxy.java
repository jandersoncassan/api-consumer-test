package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;

public class DadosClienteServicePortTypeProxy implements br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteServicePortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteServicePortType dadosClienteServicePortType = null;
  
  public DadosClienteServicePortTypeProxy() {
    _initDadosClienteServicePortTypeProxy();
  }
  
  public DadosClienteServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initDadosClienteServicePortTypeProxy();
  }
  
  private void _initDadosClienteServicePortTypeProxy() {
    try {
      dadosClienteServicePortType = (new br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteServiceLocator()).getDadosClienteServiceSOAPPort();
      if (dadosClienteServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)dadosClienteServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)dadosClienteServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (dadosClienteServicePortType != null)
      ((javax.xml.rpc.Stub)dadosClienteServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.DadosClienteServicePortType getDadosClienteServicePortType() {
    if (dadosClienteServicePortType == null)
      _initDadosClienteServicePortTypeProxy();
    return dadosClienteServicePortType;
  }
  
  public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse incluir(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (dadosClienteServicePortType == null)
      _initDadosClienteServicePortTypeProxy();
    return dadosClienteServicePortType.incluir(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType consultarDadosCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteRequestType parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (dadosClienteServicePortType == null)
      _initDadosClienteServicePortTypeProxy();
    return dadosClienteServicePortType.consultarDadosCliente(parameters);
  }
  
  
}