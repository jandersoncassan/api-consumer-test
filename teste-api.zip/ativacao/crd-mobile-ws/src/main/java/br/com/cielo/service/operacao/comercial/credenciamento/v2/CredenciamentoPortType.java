/**
 * CredenciamentoPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public interface CredenciamentoPortType extends java.rmi.Remote {

    /**
     * Operacao responsavel pro verificar se o domilicio bancario
     * informado,
     * 				ja pertence a algum cliente.
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse verificarExistenciaDomicilioBancario(br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel incluir a proposta no sistema CRD.
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse incluirProposta(br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel alterar a proposta no sistema CRD.
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse alterarProposta(br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel em ligar o alarme de erro (Sistema Spectrun).
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse ligarAlarmeExcecao(br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel em desligar o alarme de erro (Sistema
     * Spectrun).
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse desligarAlarmeExcecao(br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
