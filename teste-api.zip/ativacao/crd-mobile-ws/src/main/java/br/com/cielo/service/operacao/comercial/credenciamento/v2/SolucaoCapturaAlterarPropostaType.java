/**
 * SolucaoCapturaAlterarPropostaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class SolucaoCapturaAlterarPropostaType  implements java.io.Serializable {
    private java.lang.String codigoTipoTerminal;

    private java.lang.String codigoDefault;

    private java.math.BigInteger codigoNomeclaturaMarketing;

    private java.math.BigInteger codigoGrupoSolucaoCaptura;

    private java.lang.Integer numeroChamadoInstalacao;

    private java.lang.Integer numeroLogicoEquipamento;

    private java.util.Calendar dataInstalacaoEquipamento;

    private java.util.Calendar dataCancelamentoInstalacaoEquipamento;

    private java.lang.Integer codigoMotivoCancelamentoinstalacao;

    private br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaTypeMelhorDiaIntalacao melhorDiaIntalacao;

    private java.lang.Integer codigoMelhorPeriodoInstalacao;

    public SolucaoCapturaAlterarPropostaType() {
    }

    public SolucaoCapturaAlterarPropostaType(
           java.lang.String codigoTipoTerminal,
           java.lang.String codigoDefault,
           java.math.BigInteger codigoNomeclaturaMarketing,
           java.math.BigInteger codigoGrupoSolucaoCaptura,
           java.lang.Integer numeroChamadoInstalacao,
           java.lang.Integer numeroLogicoEquipamento,
           java.util.Calendar dataInstalacaoEquipamento,
           java.util.Calendar dataCancelamentoInstalacaoEquipamento,
           java.lang.Integer codigoMotivoCancelamentoinstalacao,
           br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaTypeMelhorDiaIntalacao melhorDiaIntalacao,
           java.lang.Integer codigoMelhorPeriodoInstalacao) {
           this.codigoTipoTerminal = codigoTipoTerminal;
           this.codigoDefault = codigoDefault;
           this.codigoNomeclaturaMarketing = codigoNomeclaturaMarketing;
           this.codigoGrupoSolucaoCaptura = codigoGrupoSolucaoCaptura;
           this.numeroChamadoInstalacao = numeroChamadoInstalacao;
           this.numeroLogicoEquipamento = numeroLogicoEquipamento;
           this.dataInstalacaoEquipamento = dataInstalacaoEquipamento;
           this.dataCancelamentoInstalacaoEquipamento = dataCancelamentoInstalacaoEquipamento;
           this.codigoMotivoCancelamentoinstalacao = codigoMotivoCancelamentoinstalacao;
           this.melhorDiaIntalacao = melhorDiaIntalacao;
           this.codigoMelhorPeriodoInstalacao = codigoMelhorPeriodoInstalacao;
    }


    /**
     * Gets the codigoTipoTerminal value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return codigoTipoTerminal
     */
    public java.lang.String getCodigoTipoTerminal() {
        return codigoTipoTerminal;
    }


    /**
     * Sets the codigoTipoTerminal value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param codigoTipoTerminal
     */
    public void setCodigoTipoTerminal(java.lang.String codigoTipoTerminal) {
        this.codigoTipoTerminal = codigoTipoTerminal;
    }


    /**
     * Gets the codigoDefault value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return codigoDefault
     */
    public java.lang.String getCodigoDefault() {
        return codigoDefault;
    }


    /**
     * Sets the codigoDefault value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param codigoDefault
     */
    public void setCodigoDefault(java.lang.String codigoDefault) {
        this.codigoDefault = codigoDefault;
    }


    /**
     * Gets the codigoNomeclaturaMarketing value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return codigoNomeclaturaMarketing
     */
    public java.math.BigInteger getCodigoNomeclaturaMarketing() {
        return codigoNomeclaturaMarketing;
    }


    /**
     * Sets the codigoNomeclaturaMarketing value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param codigoNomeclaturaMarketing
     */
    public void setCodigoNomeclaturaMarketing(java.math.BigInteger codigoNomeclaturaMarketing) {
        this.codigoNomeclaturaMarketing = codigoNomeclaturaMarketing;
    }


    /**
     * Gets the codigoGrupoSolucaoCaptura value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return codigoGrupoSolucaoCaptura
     */
    public java.math.BigInteger getCodigoGrupoSolucaoCaptura() {
        return codigoGrupoSolucaoCaptura;
    }


    /**
     * Sets the codigoGrupoSolucaoCaptura value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param codigoGrupoSolucaoCaptura
     */
    public void setCodigoGrupoSolucaoCaptura(java.math.BigInteger codigoGrupoSolucaoCaptura) {
        this.codigoGrupoSolucaoCaptura = codigoGrupoSolucaoCaptura;
    }


    /**
     * Gets the numeroChamadoInstalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return numeroChamadoInstalacao
     */
    public java.lang.Integer getNumeroChamadoInstalacao() {
        return numeroChamadoInstalacao;
    }


    /**
     * Sets the numeroChamadoInstalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param numeroChamadoInstalacao
     */
    public void setNumeroChamadoInstalacao(java.lang.Integer numeroChamadoInstalacao) {
        this.numeroChamadoInstalacao = numeroChamadoInstalacao;
    }


    /**
     * Gets the numeroLogicoEquipamento value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return numeroLogicoEquipamento
     */
    public java.lang.Integer getNumeroLogicoEquipamento() {
        return numeroLogicoEquipamento;
    }


    /**
     * Sets the numeroLogicoEquipamento value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param numeroLogicoEquipamento
     */
    public void setNumeroLogicoEquipamento(java.lang.Integer numeroLogicoEquipamento) {
        this.numeroLogicoEquipamento = numeroLogicoEquipamento;
    }


    /**
     * Gets the dataInstalacaoEquipamento value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return dataInstalacaoEquipamento
     */
    public java.util.Calendar getDataInstalacaoEquipamento() {
        return dataInstalacaoEquipamento;
    }


    /**
     * Sets the dataInstalacaoEquipamento value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param dataInstalacaoEquipamento
     */
    public void setDataInstalacaoEquipamento(java.util.Calendar dataInstalacaoEquipamento) {
        this.dataInstalacaoEquipamento = dataInstalacaoEquipamento;
    }


    /**
     * Gets the dataCancelamentoInstalacaoEquipamento value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return dataCancelamentoInstalacaoEquipamento
     */
    public java.util.Calendar getDataCancelamentoInstalacaoEquipamento() {
        return dataCancelamentoInstalacaoEquipamento;
    }


    /**
     * Sets the dataCancelamentoInstalacaoEquipamento value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param dataCancelamentoInstalacaoEquipamento
     */
    public void setDataCancelamentoInstalacaoEquipamento(java.util.Calendar dataCancelamentoInstalacaoEquipamento) {
        this.dataCancelamentoInstalacaoEquipamento = dataCancelamentoInstalacaoEquipamento;
    }


    /**
     * Gets the codigoMotivoCancelamentoinstalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return codigoMotivoCancelamentoinstalacao
     */
    public java.lang.Integer getCodigoMotivoCancelamentoinstalacao() {
        return codigoMotivoCancelamentoinstalacao;
    }


    /**
     * Sets the codigoMotivoCancelamentoinstalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param codigoMotivoCancelamentoinstalacao
     */
    public void setCodigoMotivoCancelamentoinstalacao(java.lang.Integer codigoMotivoCancelamentoinstalacao) {
        this.codigoMotivoCancelamentoinstalacao = codigoMotivoCancelamentoinstalacao;
    }


    /**
     * Gets the melhorDiaIntalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return melhorDiaIntalacao
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaTypeMelhorDiaIntalacao getMelhorDiaIntalacao() {
        return melhorDiaIntalacao;
    }


    /**
     * Sets the melhorDiaIntalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param melhorDiaIntalacao
     */
    public void setMelhorDiaIntalacao(br.com.cielo.service.operacao.comercial.credenciamento.v2.SolucaoCapturaAlterarPropostaTypeMelhorDiaIntalacao melhorDiaIntalacao) {
        this.melhorDiaIntalacao = melhorDiaIntalacao;
    }


    /**
     * Gets the codigoMelhorPeriodoInstalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @return codigoMelhorPeriodoInstalacao
     */
    public java.lang.Integer getCodigoMelhorPeriodoInstalacao() {
        return codigoMelhorPeriodoInstalacao;
    }


    /**
     * Sets the codigoMelhorPeriodoInstalacao value for this SolucaoCapturaAlterarPropostaType.
     * 
     * @param codigoMelhorPeriodoInstalacao
     */
    public void setCodigoMelhorPeriodoInstalacao(java.lang.Integer codigoMelhorPeriodoInstalacao) {
        this.codigoMelhorPeriodoInstalacao = codigoMelhorPeriodoInstalacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SolucaoCapturaAlterarPropostaType)) return false;
        SolucaoCapturaAlterarPropostaType other = (SolucaoCapturaAlterarPropostaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTipoTerminal==null && other.getCodigoTipoTerminal()==null) || 
             (this.codigoTipoTerminal!=null &&
              this.codigoTipoTerminal.equals(other.getCodigoTipoTerminal()))) &&
            ((this.codigoDefault==null && other.getCodigoDefault()==null) || 
             (this.codigoDefault!=null &&
              this.codigoDefault.equals(other.getCodigoDefault()))) &&
            ((this.codigoNomeclaturaMarketing==null && other.getCodigoNomeclaturaMarketing()==null) || 
             (this.codigoNomeclaturaMarketing!=null &&
              this.codigoNomeclaturaMarketing.equals(other.getCodigoNomeclaturaMarketing()))) &&
            ((this.codigoGrupoSolucaoCaptura==null && other.getCodigoGrupoSolucaoCaptura()==null) || 
             (this.codigoGrupoSolucaoCaptura!=null &&
              this.codigoGrupoSolucaoCaptura.equals(other.getCodigoGrupoSolucaoCaptura()))) &&
            ((this.numeroChamadoInstalacao==null && other.getNumeroChamadoInstalacao()==null) || 
             (this.numeroChamadoInstalacao!=null &&
              this.numeroChamadoInstalacao.equals(other.getNumeroChamadoInstalacao()))) &&
            ((this.numeroLogicoEquipamento==null && other.getNumeroLogicoEquipamento()==null) || 
             (this.numeroLogicoEquipamento!=null &&
              this.numeroLogicoEquipamento.equals(other.getNumeroLogicoEquipamento()))) &&
            ((this.dataInstalacaoEquipamento==null && other.getDataInstalacaoEquipamento()==null) || 
             (this.dataInstalacaoEquipamento!=null &&
              this.dataInstalacaoEquipamento.equals(other.getDataInstalacaoEquipamento()))) &&
            ((this.dataCancelamentoInstalacaoEquipamento==null && other.getDataCancelamentoInstalacaoEquipamento()==null) || 
             (this.dataCancelamentoInstalacaoEquipamento!=null &&
              this.dataCancelamentoInstalacaoEquipamento.equals(other.getDataCancelamentoInstalacaoEquipamento()))) &&
            ((this.codigoMotivoCancelamentoinstalacao==null && other.getCodigoMotivoCancelamentoinstalacao()==null) || 
             (this.codigoMotivoCancelamentoinstalacao!=null &&
              this.codigoMotivoCancelamentoinstalacao.equals(other.getCodigoMotivoCancelamentoinstalacao()))) &&
            ((this.melhorDiaIntalacao==null && other.getMelhorDiaIntalacao()==null) || 
             (this.melhorDiaIntalacao!=null &&
              this.melhorDiaIntalacao.equals(other.getMelhorDiaIntalacao()))) &&
            ((this.codigoMelhorPeriodoInstalacao==null && other.getCodigoMelhorPeriodoInstalacao()==null) || 
             (this.codigoMelhorPeriodoInstalacao!=null &&
              this.codigoMelhorPeriodoInstalacao.equals(other.getCodigoMelhorPeriodoInstalacao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTipoTerminal() != null) {
            _hashCode += getCodigoTipoTerminal().hashCode();
        }
        if (getCodigoDefault() != null) {
            _hashCode += getCodigoDefault().hashCode();
        }
        if (getCodigoNomeclaturaMarketing() != null) {
            _hashCode += getCodigoNomeclaturaMarketing().hashCode();
        }
        if (getCodigoGrupoSolucaoCaptura() != null) {
            _hashCode += getCodigoGrupoSolucaoCaptura().hashCode();
        }
        if (getNumeroChamadoInstalacao() != null) {
            _hashCode += getNumeroChamadoInstalacao().hashCode();
        }
        if (getNumeroLogicoEquipamento() != null) {
            _hashCode += getNumeroLogicoEquipamento().hashCode();
        }
        if (getDataInstalacaoEquipamento() != null) {
            _hashCode += getDataInstalacaoEquipamento().hashCode();
        }
        if (getDataCancelamentoInstalacaoEquipamento() != null) {
            _hashCode += getDataCancelamentoInstalacaoEquipamento().hashCode();
        }
        if (getCodigoMotivoCancelamentoinstalacao() != null) {
            _hashCode += getCodigoMotivoCancelamentoinstalacao().hashCode();
        }
        if (getMelhorDiaIntalacao() != null) {
            _hashCode += getMelhorDiaIntalacao().hashCode();
        }
        if (getCodigoMelhorPeriodoInstalacao() != null) {
            _hashCode += getCodigoMelhorPeriodoInstalacao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SolucaoCapturaAlterarPropostaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "solucaoCapturaAlterarPropostaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoTipoTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoDefault");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoDefault"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoNomeclaturaMarketing");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoNomeclaturaMarketing"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoGrupoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoGrupoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroChamadoInstalacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "numeroChamadoInstalacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogicoEquipamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "numeroLogicoEquipamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataInstalacaoEquipamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "dataInstalacaoEquipamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataCancelamentoInstalacaoEquipamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "dataCancelamentoInstalacaoEquipamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoMotivoCancelamentoinstalacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoMotivoCancelamentoinstalacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("melhorDiaIntalacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "melhorDiaIntalacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">solucaoCapturaAlterarPropostaType>melhorDiaIntalacao"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoMelhorPeriodoInstalacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "codigoMelhorPeriodoInstalacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
