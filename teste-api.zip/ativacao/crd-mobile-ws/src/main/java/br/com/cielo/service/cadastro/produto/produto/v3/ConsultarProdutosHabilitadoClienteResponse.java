/**
 * ConsultarProdutosHabilitadoClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarProdutosHabilitadoClienteResponse  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] produtos;

    private java.lang.Long numeroTotalRegistros;

    private java.util.Date dataUltimaTransacao;

    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    public ConsultarProdutosHabilitadoClienteResponse() {
    }

    public ConsultarProdutosHabilitadoClienteResponse(
           br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] produtos,
           java.lang.Long numeroTotalRegistros,
           java.util.Date dataUltimaTransacao,
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem) {
           this.produtos = produtos;
           this.numeroTotalRegistros = numeroTotalRegistros;
           this.dataUltimaTransacao = dataUltimaTransacao;
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the produtos value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @return produtos
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] getProdutos() {
        return produtos;
    }


    /**
     * Sets the produtos value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @param produtos
     */
    public void setProdutos(br.com.cielo.service.cadastro.produto.produto.v3.ProdutoContratadoClienteType[] produtos) {
        this.produtos = produtos;
    }


    /**
     * Gets the numeroTotalRegistros value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @return numeroTotalRegistros
     */
    public java.lang.Long getNumeroTotalRegistros() {
        return numeroTotalRegistros;
    }


    /**
     * Sets the numeroTotalRegistros value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @param numeroTotalRegistros
     */
    public void setNumeroTotalRegistros(java.lang.Long numeroTotalRegistros) {
        this.numeroTotalRegistros = numeroTotalRegistros;
    }


    /**
     * Gets the dataUltimaTransacao value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @return dataUltimaTransacao
     */
    public java.util.Date getDataUltimaTransacao() {
        return dataUltimaTransacao;
    }


    /**
     * Sets the dataUltimaTransacao value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @param dataUltimaTransacao
     */
    public void setDataUltimaTransacao(java.util.Date dataUltimaTransacao) {
        this.dataUltimaTransacao = dataUltimaTransacao;
    }


    /**
     * Gets the codigoRetorno value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this ConsultarProdutosHabilitadoClienteResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarProdutosHabilitadoClienteResponse)) return false;
        ConsultarProdutosHabilitadoClienteResponse other = (ConsultarProdutosHabilitadoClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.produtos==null && other.getProdutos()==null) || 
             (this.produtos!=null &&
              java.util.Arrays.equals(this.produtos, other.getProdutos()))) &&
            ((this.numeroTotalRegistros==null && other.getNumeroTotalRegistros()==null) || 
             (this.numeroTotalRegistros!=null &&
              this.numeroTotalRegistros.equals(other.getNumeroTotalRegistros()))) &&
            ((this.dataUltimaTransacao==null && other.getDataUltimaTransacao()==null) || 
             (this.dataUltimaTransacao!=null &&
              this.dataUltimaTransacao.equals(other.getDataUltimaTransacao()))) &&
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getProdutos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProdutos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProdutos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNumeroTotalRegistros() != null) {
            _hashCode += getNumeroTotalRegistros().hashCode();
        }
        if (getDataUltimaTransacao() != null) {
            _hashCode += getDataUltimaTransacao().hashCode();
        }
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarProdutosHabilitadoClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarProdutosHabilitadoClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produtos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ProdutoContratadoClienteType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtoContratadoCliente"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTotalRegistros");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "numeroTotalRegistros"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataUltimaTransacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dataUltimaTransacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
