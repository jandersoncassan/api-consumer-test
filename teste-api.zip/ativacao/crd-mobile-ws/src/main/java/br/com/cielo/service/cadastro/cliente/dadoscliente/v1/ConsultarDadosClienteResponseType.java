/**
 * ConsultarDadosClienteResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;


/**
 * Informacoes de retorno para consultar dados cadastrais do cliente
 */
public class ConsultarDadosClienteResponseType  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.Cliente cliente;

    private br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoCategoria[] enderecosCategorias;

    private java.lang.String digitoCNPJCPF;

    private br.com.cielo.canonico.cadastro.v1.Filial filial;

    private br.com.cielo.canonico.cadastro.v1.NoHierarquiaCliente noHierarquiaCliente;

    private java.lang.String descricaoSegmento;

    private java.util.Date[] dataBloqueioPagamento;

    private java.lang.Long codigoColaborador;

    private java.lang.String nomeColaborador;

    private java.lang.Boolean indicadorMatriz;

    public ConsultarDadosClienteResponseType() {
    }

    public ConsultarDadosClienteResponseType(
           br.com.cielo.canonico.cadastro.v1.Cliente cliente,
           br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoCategoria[] enderecosCategorias,
           java.lang.String digitoCNPJCPF,
           br.com.cielo.canonico.cadastro.v1.Filial filial,
           br.com.cielo.canonico.cadastro.v1.NoHierarquiaCliente noHierarquiaCliente,
           java.lang.String descricaoSegmento,
           java.util.Date[] dataBloqueioPagamento,
           java.lang.Long codigoColaborador,
           java.lang.String nomeColaborador,
           java.lang.Boolean indicadorMatriz) {
           this.cliente = cliente;
           this.enderecosCategorias = enderecosCategorias;
           this.digitoCNPJCPF = digitoCNPJCPF;
           this.filial = filial;
           this.noHierarquiaCliente = noHierarquiaCliente;
           this.descricaoSegmento = descricaoSegmento;
           this.dataBloqueioPagamento = dataBloqueioPagamento;
           this.codigoColaborador = codigoColaborador;
           this.nomeColaborador = nomeColaborador;
           this.indicadorMatriz = indicadorMatriz;
    }


    /**
     * Gets the cliente value for this ConsultarDadosClienteResponseType.
     * 
     * @return cliente
     */
    public br.com.cielo.canonico.cadastro.v1.Cliente getCliente() {
        return cliente;
    }


    /**
     * Sets the cliente value for this ConsultarDadosClienteResponseType.
     * 
     * @param cliente
     */
    public void setCliente(br.com.cielo.canonico.cadastro.v1.Cliente cliente) {
        this.cliente = cliente;
    }


    /**
     * Gets the enderecosCategorias value for this ConsultarDadosClienteResponseType.
     * 
     * @return enderecosCategorias
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoCategoria[] getEnderecosCategorias() {
        return enderecosCategorias;
    }


    /**
     * Sets the enderecosCategorias value for this ConsultarDadosClienteResponseType.
     * 
     * @param enderecosCategorias
     */
    public void setEnderecosCategorias(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.EnderecoCategoria[] enderecosCategorias) {
        this.enderecosCategorias = enderecosCategorias;
    }


    /**
     * Gets the digitoCNPJCPF value for this ConsultarDadosClienteResponseType.
     * 
     * @return digitoCNPJCPF
     */
    public java.lang.String getDigitoCNPJCPF() {
        return digitoCNPJCPF;
    }


    /**
     * Sets the digitoCNPJCPF value for this ConsultarDadosClienteResponseType.
     * 
     * @param digitoCNPJCPF
     */
    public void setDigitoCNPJCPF(java.lang.String digitoCNPJCPF) {
        this.digitoCNPJCPF = digitoCNPJCPF;
    }


    /**
     * Gets the filial value for this ConsultarDadosClienteResponseType.
     * 
     * @return filial
     */
    public br.com.cielo.canonico.cadastro.v1.Filial getFilial() {
        return filial;
    }


    /**
     * Sets the filial value for this ConsultarDadosClienteResponseType.
     * 
     * @param filial
     */
    public void setFilial(br.com.cielo.canonico.cadastro.v1.Filial filial) {
        this.filial = filial;
    }


    /**
     * Gets the noHierarquiaCliente value for this ConsultarDadosClienteResponseType.
     * 
     * @return noHierarquiaCliente
     */
    public br.com.cielo.canonico.cadastro.v1.NoHierarquiaCliente getNoHierarquiaCliente() {
        return noHierarquiaCliente;
    }


    /**
     * Sets the noHierarquiaCliente value for this ConsultarDadosClienteResponseType.
     * 
     * @param noHierarquiaCliente
     */
    public void setNoHierarquiaCliente(br.com.cielo.canonico.cadastro.v1.NoHierarquiaCliente noHierarquiaCliente) {
        this.noHierarquiaCliente = noHierarquiaCliente;
    }


    /**
     * Gets the descricaoSegmento value for this ConsultarDadosClienteResponseType.
     * 
     * @return descricaoSegmento
     */
    public java.lang.String getDescricaoSegmento() {
        return descricaoSegmento;
    }


    /**
     * Sets the descricaoSegmento value for this ConsultarDadosClienteResponseType.
     * 
     * @param descricaoSegmento
     */
    public void setDescricaoSegmento(java.lang.String descricaoSegmento) {
        this.descricaoSegmento = descricaoSegmento;
    }


    /**
     * Gets the dataBloqueioPagamento value for this ConsultarDadosClienteResponseType.
     * 
     * @return dataBloqueioPagamento
     */
    public java.util.Date[] getDataBloqueioPagamento() {
        return dataBloqueioPagamento;
    }


    /**
     * Sets the dataBloqueioPagamento value for this ConsultarDadosClienteResponseType.
     * 
     * @param dataBloqueioPagamento
     */
    public void setDataBloqueioPagamento(java.util.Date[] dataBloqueioPagamento) {
        this.dataBloqueioPagamento = dataBloqueioPagamento;
    }

    public java.util.Date getDataBloqueioPagamento(int i) {
        return this.dataBloqueioPagamento[i];
    }

    public void setDataBloqueioPagamento(int i, java.util.Date _value) {
        this.dataBloqueioPagamento[i] = _value;
    }


    /**
     * Gets the codigoColaborador value for this ConsultarDadosClienteResponseType.
     * 
     * @return codigoColaborador
     */
    public java.lang.Long getCodigoColaborador() {
        return codigoColaborador;
    }


    /**
     * Sets the codigoColaborador value for this ConsultarDadosClienteResponseType.
     * 
     * @param codigoColaborador
     */
    public void setCodigoColaborador(java.lang.Long codigoColaborador) {
        this.codigoColaborador = codigoColaborador;
    }


    /**
     * Gets the nomeColaborador value for this ConsultarDadosClienteResponseType.
     * 
     * @return nomeColaborador
     */
    public java.lang.String getNomeColaborador() {
        return nomeColaborador;
    }


    /**
     * Sets the nomeColaborador value for this ConsultarDadosClienteResponseType.
     * 
     * @param nomeColaborador
     */
    public void setNomeColaborador(java.lang.String nomeColaborador) {
        this.nomeColaborador = nomeColaborador;
    }


    /**
     * Gets the indicadorMatriz value for this ConsultarDadosClienteResponseType.
     * 
     * @return indicadorMatriz
     */
    public java.lang.Boolean getIndicadorMatriz() {
        return indicadorMatriz;
    }


    /**
     * Sets the indicadorMatriz value for this ConsultarDadosClienteResponseType.
     * 
     * @param indicadorMatriz
     */
    public void setIndicadorMatriz(java.lang.Boolean indicadorMatriz) {
        this.indicadorMatriz = indicadorMatriz;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDadosClienteResponseType)) return false;
        ConsultarDadosClienteResponseType other = (ConsultarDadosClienteResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cliente==null && other.getCliente()==null) || 
             (this.cliente!=null &&
              this.cliente.equals(other.getCliente()))) &&
            ((this.enderecosCategorias==null && other.getEnderecosCategorias()==null) || 
             (this.enderecosCategorias!=null &&
              java.util.Arrays.equals(this.enderecosCategorias, other.getEnderecosCategorias()))) &&
            ((this.digitoCNPJCPF==null && other.getDigitoCNPJCPF()==null) || 
             (this.digitoCNPJCPF!=null &&
              this.digitoCNPJCPF.equals(other.getDigitoCNPJCPF()))) &&
            ((this.filial==null && other.getFilial()==null) || 
             (this.filial!=null &&
              this.filial.equals(other.getFilial()))) &&
            ((this.noHierarquiaCliente==null && other.getNoHierarquiaCliente()==null) || 
             (this.noHierarquiaCliente!=null &&
              this.noHierarquiaCliente.equals(other.getNoHierarquiaCliente()))) &&
            ((this.descricaoSegmento==null && other.getDescricaoSegmento()==null) || 
             (this.descricaoSegmento!=null &&
              this.descricaoSegmento.equals(other.getDescricaoSegmento()))) &&
            ((this.dataBloqueioPagamento==null && other.getDataBloqueioPagamento()==null) || 
             (this.dataBloqueioPagamento!=null &&
              java.util.Arrays.equals(this.dataBloqueioPagamento, other.getDataBloqueioPagamento()))) &&
            ((this.codigoColaborador==null && other.getCodigoColaborador()==null) || 
             (this.codigoColaborador!=null &&
              this.codigoColaborador.equals(other.getCodigoColaborador()))) &&
            ((this.nomeColaborador==null && other.getNomeColaborador()==null) || 
             (this.nomeColaborador!=null &&
              this.nomeColaborador.equals(other.getNomeColaborador()))) &&
            ((this.indicadorMatriz==null && other.getIndicadorMatriz()==null) || 
             (this.indicadorMatriz!=null &&
              this.indicadorMatriz.equals(other.getIndicadorMatriz())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCliente() != null) {
            _hashCode += getCliente().hashCode();
        }
        if (getEnderecosCategorias() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEnderecosCategorias());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEnderecosCategorias(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getDigitoCNPJCPF() != null) {
            _hashCode += getDigitoCNPJCPF().hashCode();
        }
        if (getFilial() != null) {
            _hashCode += getFilial().hashCode();
        }
        if (getNoHierarquiaCliente() != null) {
            _hashCode += getNoHierarquiaCliente().hashCode();
        }
        if (getDescricaoSegmento() != null) {
            _hashCode += getDescricaoSegmento().hashCode();
        }
        if (getDataBloqueioPagamento() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDataBloqueioPagamento());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDataBloqueioPagamento(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodigoColaborador() != null) {
            _hashCode += getCodigoColaborador().hashCode();
        }
        if (getNomeColaborador() != null) {
            _hashCode += getNomeColaborador().hashCode();
        }
        if (getIndicadorMatriz() != null) {
            _hashCode += getIndicadorMatriz().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDadosClienteResponseType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "consultarDadosClienteResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "Cliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Cliente"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enderecosCategorias");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "enderecosCategorias"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecoCategoria"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "enderecoCategoria"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digitoCNPJCPF");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "digitoCNPJCPF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("filial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "Filial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filial"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noHierarquiaCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "NoHierarquiaCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "NoHierarquiaCliente"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoSegmento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "descricaoSegmento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataBloqueioPagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "dataBloqueioPagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoColaborador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "codigoColaborador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeColaborador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "nomeColaborador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMatriz");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "indicadorMatriz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
