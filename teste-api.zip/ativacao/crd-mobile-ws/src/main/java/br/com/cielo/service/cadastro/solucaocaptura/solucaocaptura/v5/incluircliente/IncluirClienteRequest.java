/**
 * IncluirClienteRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente;

public class IncluirClienteRequest  implements java.io.Serializable {
    private java.lang.String ferramentaOrigemChamada;

    private long codigoCliente;

    private java.math.BigInteger lojaEstabelecimentoComercial;

    private java.lang.String tipoTecnologia;

    private java.lang.String indicadorInformacoesCompletas;

    private java.lang.String descricaoCompletaEC;

    private java.lang.String descricaoResumidaEC;

    private java.lang.String logradouro;

    private java.lang.String cep;

    private java.lang.String cidade;

    private java.lang.String siglaUF;

    private java.lang.String bairro;

    private java.math.BigInteger dddNumeroTelefone;

    private java.math.BigInteger numeroTelefone;

    private java.lang.String tipoPessoa;

    private java.math.BigInteger numeroCPFCNPJ;

    private java.math.BigInteger codigoRamoAtividade;

    private java.lang.Boolean indicadorCartaoPresente;

    private java.lang.String statusEC;

    private java.lang.String motivoStatusEC;

    private java.lang.Boolean indicadorCartaoInternacional;

    private java.lang.Boolean indicadorVendaCartaoInternacional;

    private java.lang.Boolean indicadorVendaDigitada;

    public IncluirClienteRequest() {
    }

    public IncluirClienteRequest(
           java.lang.String ferramentaOrigemChamada,
           long codigoCliente,
           java.math.BigInteger lojaEstabelecimentoComercial,
           java.lang.String tipoTecnologia,
           java.lang.String indicadorInformacoesCompletas,
           java.lang.String descricaoCompletaEC,
           java.lang.String descricaoResumidaEC,
           java.lang.String logradouro,
           java.lang.String cep,
           java.lang.String cidade,
           java.lang.String siglaUF,
           java.lang.String bairro,
           java.math.BigInteger dddNumeroTelefone,
           java.math.BigInteger numeroTelefone,
           java.lang.String tipoPessoa,
           java.math.BigInteger numeroCPFCNPJ,
           java.math.BigInteger codigoRamoAtividade,
           java.lang.Boolean indicadorCartaoPresente,
           java.lang.String statusEC,
           java.lang.String motivoStatusEC,
           java.lang.Boolean indicadorCartaoInternacional,
           java.lang.Boolean indicadorVendaCartaoInternacional,
           java.lang.Boolean indicadorVendaDigitada) {
           this.ferramentaOrigemChamada = ferramentaOrigemChamada;
           this.codigoCliente = codigoCliente;
           this.lojaEstabelecimentoComercial = lojaEstabelecimentoComercial;
           this.tipoTecnologia = tipoTecnologia;
           this.indicadorInformacoesCompletas = indicadorInformacoesCompletas;
           this.descricaoCompletaEC = descricaoCompletaEC;
           this.descricaoResumidaEC = descricaoResumidaEC;
           this.logradouro = logradouro;
           this.cep = cep;
           this.cidade = cidade;
           this.siglaUF = siglaUF;
           this.bairro = bairro;
           this.dddNumeroTelefone = dddNumeroTelefone;
           this.numeroTelefone = numeroTelefone;
           this.tipoPessoa = tipoPessoa;
           this.numeroCPFCNPJ = numeroCPFCNPJ;
           this.codigoRamoAtividade = codigoRamoAtividade;
           this.indicadorCartaoPresente = indicadorCartaoPresente;
           this.statusEC = statusEC;
           this.motivoStatusEC = motivoStatusEC;
           this.indicadorCartaoInternacional = indicadorCartaoInternacional;
           this.indicadorVendaCartaoInternacional = indicadorVendaCartaoInternacional;
           this.indicadorVendaDigitada = indicadorVendaDigitada;
    }


    /**
     * Gets the ferramentaOrigemChamada value for this IncluirClienteRequest.
     * 
     * @return ferramentaOrigemChamada
     */
    public java.lang.String getFerramentaOrigemChamada() {
        return ferramentaOrigemChamada;
    }


    /**
     * Sets the ferramentaOrigemChamada value for this IncluirClienteRequest.
     * 
     * @param ferramentaOrigemChamada
     */
    public void setFerramentaOrigemChamada(java.lang.String ferramentaOrigemChamada) {
        this.ferramentaOrigemChamada = ferramentaOrigemChamada;
    }


    /**
     * Gets the codigoCliente value for this IncluirClienteRequest.
     * 
     * @return codigoCliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this IncluirClienteRequest.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the lojaEstabelecimentoComercial value for this IncluirClienteRequest.
     * 
     * @return lojaEstabelecimentoComercial
     */
    public java.math.BigInteger getLojaEstabelecimentoComercial() {
        return lojaEstabelecimentoComercial;
    }


    /**
     * Sets the lojaEstabelecimentoComercial value for this IncluirClienteRequest.
     * 
     * @param lojaEstabelecimentoComercial
     */
    public void setLojaEstabelecimentoComercial(java.math.BigInteger lojaEstabelecimentoComercial) {
        this.lojaEstabelecimentoComercial = lojaEstabelecimentoComercial;
    }


    /**
     * Gets the tipoTecnologia value for this IncluirClienteRequest.
     * 
     * @return tipoTecnologia
     */
    public java.lang.String getTipoTecnologia() {
        return tipoTecnologia;
    }


    /**
     * Sets the tipoTecnologia value for this IncluirClienteRequest.
     * 
     * @param tipoTecnologia
     */
    public void setTipoTecnologia(java.lang.String tipoTecnologia) {
        this.tipoTecnologia = tipoTecnologia;
    }


    /**
     * Gets the indicadorInformacoesCompletas value for this IncluirClienteRequest.
     * 
     * @return indicadorInformacoesCompletas
     */
    public java.lang.String getIndicadorInformacoesCompletas() {
        return indicadorInformacoesCompletas;
    }


    /**
     * Sets the indicadorInformacoesCompletas value for this IncluirClienteRequest.
     * 
     * @param indicadorInformacoesCompletas
     */
    public void setIndicadorInformacoesCompletas(java.lang.String indicadorInformacoesCompletas) {
        this.indicadorInformacoesCompletas = indicadorInformacoesCompletas;
    }


    /**
     * Gets the descricaoCompletaEC value for this IncluirClienteRequest.
     * 
     * @return descricaoCompletaEC
     */
    public java.lang.String getDescricaoCompletaEC() {
        return descricaoCompletaEC;
    }


    /**
     * Sets the descricaoCompletaEC value for this IncluirClienteRequest.
     * 
     * @param descricaoCompletaEC
     */
    public void setDescricaoCompletaEC(java.lang.String descricaoCompletaEC) {
        this.descricaoCompletaEC = descricaoCompletaEC;
    }


    /**
     * Gets the descricaoResumidaEC value for this IncluirClienteRequest.
     * 
     * @return descricaoResumidaEC
     */
    public java.lang.String getDescricaoResumidaEC() {
        return descricaoResumidaEC;
    }


    /**
     * Sets the descricaoResumidaEC value for this IncluirClienteRequest.
     * 
     * @param descricaoResumidaEC
     */
    public void setDescricaoResumidaEC(java.lang.String descricaoResumidaEC) {
        this.descricaoResumidaEC = descricaoResumidaEC;
    }


    /**
     * Gets the logradouro value for this IncluirClienteRequest.
     * 
     * @return logradouro
     */
    public java.lang.String getLogradouro() {
        return logradouro;
    }


    /**
     * Sets the logradouro value for this IncluirClienteRequest.
     * 
     * @param logradouro
     */
    public void setLogradouro(java.lang.String logradouro) {
        this.logradouro = logradouro;
    }


    /**
     * Gets the cep value for this IncluirClienteRequest.
     * 
     * @return cep
     */
    public java.lang.String getCep() {
        return cep;
    }


    /**
     * Sets the cep value for this IncluirClienteRequest.
     * 
     * @param cep
     */
    public void setCep(java.lang.String cep) {
        this.cep = cep;
    }


    /**
     * Gets the cidade value for this IncluirClienteRequest.
     * 
     * @return cidade
     */
    public java.lang.String getCidade() {
        return cidade;
    }


    /**
     * Sets the cidade value for this IncluirClienteRequest.
     * 
     * @param cidade
     */
    public void setCidade(java.lang.String cidade) {
        this.cidade = cidade;
    }


    /**
     * Gets the siglaUF value for this IncluirClienteRequest.
     * 
     * @return siglaUF
     */
    public java.lang.String getSiglaUF() {
        return siglaUF;
    }


    /**
     * Sets the siglaUF value for this IncluirClienteRequest.
     * 
     * @param siglaUF
     */
    public void setSiglaUF(java.lang.String siglaUF) {
        this.siglaUF = siglaUF;
    }


    /**
     * Gets the bairro value for this IncluirClienteRequest.
     * 
     * @return bairro
     */
    public java.lang.String getBairro() {
        return bairro;
    }


    /**
     * Sets the bairro value for this IncluirClienteRequest.
     * 
     * @param bairro
     */
    public void setBairro(java.lang.String bairro) {
        this.bairro = bairro;
    }


    /**
     * Gets the dddNumeroTelefone value for this IncluirClienteRequest.
     * 
     * @return dddNumeroTelefone
     */
    public java.math.BigInteger getDddNumeroTelefone() {
        return dddNumeroTelefone;
    }


    /**
     * Sets the dddNumeroTelefone value for this IncluirClienteRequest.
     * 
     * @param dddNumeroTelefone
     */
    public void setDddNumeroTelefone(java.math.BigInteger dddNumeroTelefone) {
        this.dddNumeroTelefone = dddNumeroTelefone;
    }


    /**
     * Gets the numeroTelefone value for this IncluirClienteRequest.
     * 
     * @return numeroTelefone
     */
    public java.math.BigInteger getNumeroTelefone() {
        return numeroTelefone;
    }


    /**
     * Sets the numeroTelefone value for this IncluirClienteRequest.
     * 
     * @param numeroTelefone
     */
    public void setNumeroTelefone(java.math.BigInteger numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }


    /**
     * Gets the tipoPessoa value for this IncluirClienteRequest.
     * 
     * @return tipoPessoa
     */
    public java.lang.String getTipoPessoa() {
        return tipoPessoa;
    }


    /**
     * Sets the tipoPessoa value for this IncluirClienteRequest.
     * 
     * @param tipoPessoa
     */
    public void setTipoPessoa(java.lang.String tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }


    /**
     * Gets the numeroCPFCNPJ value for this IncluirClienteRequest.
     * 
     * @return numeroCPFCNPJ
     */
    public java.math.BigInteger getNumeroCPFCNPJ() {
        return numeroCPFCNPJ;
    }


    /**
     * Sets the numeroCPFCNPJ value for this IncluirClienteRequest.
     * 
     * @param numeroCPFCNPJ
     */
    public void setNumeroCPFCNPJ(java.math.BigInteger numeroCPFCNPJ) {
        this.numeroCPFCNPJ = numeroCPFCNPJ;
    }


    /**
     * Gets the codigoRamoAtividade value for this IncluirClienteRequest.
     * 
     * @return codigoRamoAtividade
     */
    public java.math.BigInteger getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this IncluirClienteRequest.
     * 
     * @param codigoRamoAtividade
     */
    public void setCodigoRamoAtividade(java.math.BigInteger codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the indicadorCartaoPresente value for this IncluirClienteRequest.
     * 
     * @return indicadorCartaoPresente
     */
    public java.lang.Boolean getIndicadorCartaoPresente() {
        return indicadorCartaoPresente;
    }


    /**
     * Sets the indicadorCartaoPresente value for this IncluirClienteRequest.
     * 
     * @param indicadorCartaoPresente
     */
    public void setIndicadorCartaoPresente(java.lang.Boolean indicadorCartaoPresente) {
        this.indicadorCartaoPresente = indicadorCartaoPresente;
    }


    /**
     * Gets the statusEC value for this IncluirClienteRequest.
     * 
     * @return statusEC
     */
    public java.lang.String getStatusEC() {
        return statusEC;
    }


    /**
     * Sets the statusEC value for this IncluirClienteRequest.
     * 
     * @param statusEC
     */
    public void setStatusEC(java.lang.String statusEC) {
        this.statusEC = statusEC;
    }


    /**
     * Gets the motivoStatusEC value for this IncluirClienteRequest.
     * 
     * @return motivoStatusEC
     */
    public java.lang.String getMotivoStatusEC() {
        return motivoStatusEC;
    }


    /**
     * Sets the motivoStatusEC value for this IncluirClienteRequest.
     * 
     * @param motivoStatusEC
     */
    public void setMotivoStatusEC(java.lang.String motivoStatusEC) {
        this.motivoStatusEC = motivoStatusEC;
    }


    /**
     * Gets the indicadorCartaoInternacional value for this IncluirClienteRequest.
     * 
     * @return indicadorCartaoInternacional
     */
    public java.lang.Boolean getIndicadorCartaoInternacional() {
        return indicadorCartaoInternacional;
    }


    /**
     * Sets the indicadorCartaoInternacional value for this IncluirClienteRequest.
     * 
     * @param indicadorCartaoInternacional
     */
    public void setIndicadorCartaoInternacional(java.lang.Boolean indicadorCartaoInternacional) {
        this.indicadorCartaoInternacional = indicadorCartaoInternacional;
    }


    /**
     * Gets the indicadorVendaCartaoInternacional value for this IncluirClienteRequest.
     * 
     * @return indicadorVendaCartaoInternacional
     */
    public java.lang.Boolean getIndicadorVendaCartaoInternacional() {
        return indicadorVendaCartaoInternacional;
    }


    /**
     * Sets the indicadorVendaCartaoInternacional value for this IncluirClienteRequest.
     * 
     * @param indicadorVendaCartaoInternacional
     */
    public void setIndicadorVendaCartaoInternacional(java.lang.Boolean indicadorVendaCartaoInternacional) {
        this.indicadorVendaCartaoInternacional = indicadorVendaCartaoInternacional;
    }


    /**
     * Gets the indicadorVendaDigitada value for this IncluirClienteRequest.
     * 
     * @return indicadorVendaDigitada
     */
    public java.lang.Boolean getIndicadorVendaDigitada() {
        return indicadorVendaDigitada;
    }


    /**
     * Sets the indicadorVendaDigitada value for this IncluirClienteRequest.
     * 
     * @param indicadorVendaDigitada
     */
    public void setIndicadorVendaDigitada(java.lang.Boolean indicadorVendaDigitada) {
        this.indicadorVendaDigitada = indicadorVendaDigitada;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IncluirClienteRequest)) return false;
        IncluirClienteRequest other = (IncluirClienteRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.ferramentaOrigemChamada==null && other.getFerramentaOrigemChamada()==null) || 
             (this.ferramentaOrigemChamada!=null &&
              this.ferramentaOrigemChamada.equals(other.getFerramentaOrigemChamada()))) &&
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.lojaEstabelecimentoComercial==null && other.getLojaEstabelecimentoComercial()==null) || 
             (this.lojaEstabelecimentoComercial!=null &&
              this.lojaEstabelecimentoComercial.equals(other.getLojaEstabelecimentoComercial()))) &&
            ((this.tipoTecnologia==null && other.getTipoTecnologia()==null) || 
             (this.tipoTecnologia!=null &&
              this.tipoTecnologia.equals(other.getTipoTecnologia()))) &&
            ((this.indicadorInformacoesCompletas==null && other.getIndicadorInformacoesCompletas()==null) || 
             (this.indicadorInformacoesCompletas!=null &&
              this.indicadorInformacoesCompletas.equals(other.getIndicadorInformacoesCompletas()))) &&
            ((this.descricaoCompletaEC==null && other.getDescricaoCompletaEC()==null) || 
             (this.descricaoCompletaEC!=null &&
              this.descricaoCompletaEC.equals(other.getDescricaoCompletaEC()))) &&
            ((this.descricaoResumidaEC==null && other.getDescricaoResumidaEC()==null) || 
             (this.descricaoResumidaEC!=null &&
              this.descricaoResumidaEC.equals(other.getDescricaoResumidaEC()))) &&
            ((this.logradouro==null && other.getLogradouro()==null) || 
             (this.logradouro!=null &&
              this.logradouro.equals(other.getLogradouro()))) &&
            ((this.cep==null && other.getCep()==null) || 
             (this.cep!=null &&
              this.cep.equals(other.getCep()))) &&
            ((this.cidade==null && other.getCidade()==null) || 
             (this.cidade!=null &&
              this.cidade.equals(other.getCidade()))) &&
            ((this.siglaUF==null && other.getSiglaUF()==null) || 
             (this.siglaUF!=null &&
              this.siglaUF.equals(other.getSiglaUF()))) &&
            ((this.bairro==null && other.getBairro()==null) || 
             (this.bairro!=null &&
              this.bairro.equals(other.getBairro()))) &&
            ((this.dddNumeroTelefone==null && other.getDddNumeroTelefone()==null) || 
             (this.dddNumeroTelefone!=null &&
              this.dddNumeroTelefone.equals(other.getDddNumeroTelefone()))) &&
            ((this.numeroTelefone==null && other.getNumeroTelefone()==null) || 
             (this.numeroTelefone!=null &&
              this.numeroTelefone.equals(other.getNumeroTelefone()))) &&
            ((this.tipoPessoa==null && other.getTipoPessoa()==null) || 
             (this.tipoPessoa!=null &&
              this.tipoPessoa.equals(other.getTipoPessoa()))) &&
            ((this.numeroCPFCNPJ==null && other.getNumeroCPFCNPJ()==null) || 
             (this.numeroCPFCNPJ!=null &&
              this.numeroCPFCNPJ.equals(other.getNumeroCPFCNPJ()))) &&
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade()))) &&
            ((this.indicadorCartaoPresente==null && other.getIndicadorCartaoPresente()==null) || 
             (this.indicadorCartaoPresente!=null &&
              this.indicadorCartaoPresente.equals(other.getIndicadorCartaoPresente()))) &&
            ((this.statusEC==null && other.getStatusEC()==null) || 
             (this.statusEC!=null &&
              this.statusEC.equals(other.getStatusEC()))) &&
            ((this.motivoStatusEC==null && other.getMotivoStatusEC()==null) || 
             (this.motivoStatusEC!=null &&
              this.motivoStatusEC.equals(other.getMotivoStatusEC()))) &&
            ((this.indicadorCartaoInternacional==null && other.getIndicadorCartaoInternacional()==null) || 
             (this.indicadorCartaoInternacional!=null &&
              this.indicadorCartaoInternacional.equals(other.getIndicadorCartaoInternacional()))) &&
            ((this.indicadorVendaCartaoInternacional==null && other.getIndicadorVendaCartaoInternacional()==null) || 
             (this.indicadorVendaCartaoInternacional!=null &&
              this.indicadorVendaCartaoInternacional.equals(other.getIndicadorVendaCartaoInternacional()))) &&
            ((this.indicadorVendaDigitada==null && other.getIndicadorVendaDigitada()==null) || 
             (this.indicadorVendaDigitada!=null &&
              this.indicadorVendaDigitada.equals(other.getIndicadorVendaDigitada())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFerramentaOrigemChamada() != null) {
            _hashCode += getFerramentaOrigemChamada().hashCode();
        }
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getLojaEstabelecimentoComercial() != null) {
            _hashCode += getLojaEstabelecimentoComercial().hashCode();
        }
        if (getTipoTecnologia() != null) {
            _hashCode += getTipoTecnologia().hashCode();
        }
        if (getIndicadorInformacoesCompletas() != null) {
            _hashCode += getIndicadorInformacoesCompletas().hashCode();
        }
        if (getDescricaoCompletaEC() != null) {
            _hashCode += getDescricaoCompletaEC().hashCode();
        }
        if (getDescricaoResumidaEC() != null) {
            _hashCode += getDescricaoResumidaEC().hashCode();
        }
        if (getLogradouro() != null) {
            _hashCode += getLogradouro().hashCode();
        }
        if (getCep() != null) {
            _hashCode += getCep().hashCode();
        }
        if (getCidade() != null) {
            _hashCode += getCidade().hashCode();
        }
        if (getSiglaUF() != null) {
            _hashCode += getSiglaUF().hashCode();
        }
        if (getBairro() != null) {
            _hashCode += getBairro().hashCode();
        }
        if (getDddNumeroTelefone() != null) {
            _hashCode += getDddNumeroTelefone().hashCode();
        }
        if (getNumeroTelefone() != null) {
            _hashCode += getNumeroTelefone().hashCode();
        }
        if (getTipoPessoa() != null) {
            _hashCode += getTipoPessoa().hashCode();
        }
        if (getNumeroCPFCNPJ() != null) {
            _hashCode += getNumeroCPFCNPJ().hashCode();
        }
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        if (getIndicadorCartaoPresente() != null) {
            _hashCode += getIndicadorCartaoPresente().hashCode();
        }
        if (getStatusEC() != null) {
            _hashCode += getStatusEC().hashCode();
        }
        if (getMotivoStatusEC() != null) {
            _hashCode += getMotivoStatusEC().hashCode();
        }
        if (getIndicadorCartaoInternacional() != null) {
            _hashCode += getIndicadorCartaoInternacional().hashCode();
        }
        if (getIndicadorVendaCartaoInternacional() != null) {
            _hashCode += getIndicadorVendaCartaoInternacional().hashCode();
        }
        if (getIndicadorVendaDigitada() != null) {
            _hashCode += getIndicadorVendaDigitada().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IncluirClienteRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", ">IncluirClienteRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("ferramentaOrigemChamada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "ferramentaOrigemChamada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lojaEstabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "lojaEstabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoTecnologia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "tipoTecnologia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorInformacoesCompletas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "indicadorInformacoesCompletas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoCompletaEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "descricaoCompletaEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoResumidaEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "descricaoResumidaEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "logradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cep");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "cep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "cidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("siglaUF");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "siglaUF"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bairro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "bairro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dddNumeroTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "dddNumeroTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "numeroTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "tipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCPFCNPJ");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "numeroCPFCNPJ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorCartaoPresente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "indicadorCartaoPresente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "statusEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("motivoStatusEC");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "motivoStatusEC"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorCartaoInternacional");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "indicadorCartaoInternacional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVendaCartaoInternacional");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "indicadorVendaCartaoInternacional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorVendaDigitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v5/incluircliente", "indicadorVendaDigitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
