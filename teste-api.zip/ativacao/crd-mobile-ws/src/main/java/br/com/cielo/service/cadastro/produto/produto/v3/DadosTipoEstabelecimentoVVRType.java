/**
 * DadosTipoEstabelecimentoVVRType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class DadosTipoEstabelecimentoVVRType  implements java.io.Serializable {
    /* BAR */
    private java.lang.Boolean bar;

    /* FastFood */
    private java.lang.Boolean fastFood;

    /* Lanchonete */
    private java.lang.Boolean lanchonete;

    /* Restaurante */
    private java.lang.Boolean restaurante;

    public DadosTipoEstabelecimentoVVRType() {
    }

    public DadosTipoEstabelecimentoVVRType(
           java.lang.Boolean bar,
           java.lang.Boolean fastFood,
           java.lang.Boolean lanchonete,
           java.lang.Boolean restaurante) {
           this.bar = bar;
           this.fastFood = fastFood;
           this.lanchonete = lanchonete;
           this.restaurante = restaurante;
    }


    /**
     * Gets the bar value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @return bar   * BAR
     */
    public java.lang.Boolean getBar() {
        return bar;
    }


    /**
     * Sets the bar value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @param bar   * BAR
     */
    public void setBar(java.lang.Boolean bar) {
        this.bar = bar;
    }


    /**
     * Gets the fastFood value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @return fastFood   * FastFood
     */
    public java.lang.Boolean getFastFood() {
        return fastFood;
    }


    /**
     * Sets the fastFood value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @param fastFood   * FastFood
     */
    public void setFastFood(java.lang.Boolean fastFood) {
        this.fastFood = fastFood;
    }


    /**
     * Gets the lanchonete value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @return lanchonete   * Lanchonete
     */
    public java.lang.Boolean getLanchonete() {
        return lanchonete;
    }


    /**
     * Sets the lanchonete value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @param lanchonete   * Lanchonete
     */
    public void setLanchonete(java.lang.Boolean lanchonete) {
        this.lanchonete = lanchonete;
    }


    /**
     * Gets the restaurante value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @return restaurante   * Restaurante
     */
    public java.lang.Boolean getRestaurante() {
        return restaurante;
    }


    /**
     * Sets the restaurante value for this DadosTipoEstabelecimentoVVRType.
     * 
     * @param restaurante   * Restaurante
     */
    public void setRestaurante(java.lang.Boolean restaurante) {
        this.restaurante = restaurante;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosTipoEstabelecimentoVVRType)) return false;
        DadosTipoEstabelecimentoVVRType other = (DadosTipoEstabelecimentoVVRType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.bar==null && other.getBar()==null) || 
             (this.bar!=null &&
              this.bar.equals(other.getBar()))) &&
            ((this.fastFood==null && other.getFastFood()==null) || 
             (this.fastFood!=null &&
              this.fastFood.equals(other.getFastFood()))) &&
            ((this.lanchonete==null && other.getLanchonete()==null) || 
             (this.lanchonete!=null &&
              this.lanchonete.equals(other.getLanchonete()))) &&
            ((this.restaurante==null && other.getRestaurante()==null) || 
             (this.restaurante!=null &&
              this.restaurante.equals(other.getRestaurante())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getBar() != null) {
            _hashCode += getBar().hashCode();
        }
        if (getFastFood() != null) {
            _hashCode += getFastFood().hashCode();
        }
        if (getLanchonete() != null) {
            _hashCode += getLanchonete().hashCode();
        }
        if (getRestaurante() != null) {
            _hashCode += getRestaurante().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosTipoEstabelecimentoVVRType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosTipoEstabelecimentoVVRType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bar");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "bar"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fastFood");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "fastFood"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lanchonete");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "lanchonete"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("restaurante");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "restaurante"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
