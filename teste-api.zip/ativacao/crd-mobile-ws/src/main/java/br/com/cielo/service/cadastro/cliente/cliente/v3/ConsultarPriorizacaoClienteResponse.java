/**
 * ConsultarPriorizacaoClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ConsultarPriorizacaoClienteResponse  implements java.io.Serializable {
    private java.lang.Boolean flagDerrubaTalker;

    private java.lang.Boolean flagCallback;

    private java.math.BigInteger prioridadeFuraFila;

    public ConsultarPriorizacaoClienteResponse() {
    }

    public ConsultarPriorizacaoClienteResponse(
           java.lang.Boolean flagDerrubaTalker,
           java.lang.Boolean flagCallback,
           java.math.BigInteger prioridadeFuraFila) {
           this.flagDerrubaTalker = flagDerrubaTalker;
           this.flagCallback = flagCallback;
           this.prioridadeFuraFila = prioridadeFuraFila;
    }


    /**
     * Gets the flagDerrubaTalker value for this ConsultarPriorizacaoClienteResponse.
     * 
     * @return flagDerrubaTalker
     */
    public java.lang.Boolean getFlagDerrubaTalker() {
        return flagDerrubaTalker;
    }


    /**
     * Sets the flagDerrubaTalker value for this ConsultarPriorizacaoClienteResponse.
     * 
     * @param flagDerrubaTalker
     */
    public void setFlagDerrubaTalker(java.lang.Boolean flagDerrubaTalker) {
        this.flagDerrubaTalker = flagDerrubaTalker;
    }


    /**
     * Gets the flagCallback value for this ConsultarPriorizacaoClienteResponse.
     * 
     * @return flagCallback
     */
    public java.lang.Boolean getFlagCallback() {
        return flagCallback;
    }


    /**
     * Sets the flagCallback value for this ConsultarPriorizacaoClienteResponse.
     * 
     * @param flagCallback
     */
    public void setFlagCallback(java.lang.Boolean flagCallback) {
        this.flagCallback = flagCallback;
    }


    /**
     * Gets the prioridadeFuraFila value for this ConsultarPriorizacaoClienteResponse.
     * 
     * @return prioridadeFuraFila
     */
    public java.math.BigInteger getPrioridadeFuraFila() {
        return prioridadeFuraFila;
    }


    /**
     * Sets the prioridadeFuraFila value for this ConsultarPriorizacaoClienteResponse.
     * 
     * @param prioridadeFuraFila
     */
    public void setPrioridadeFuraFila(java.math.BigInteger prioridadeFuraFila) {
        this.prioridadeFuraFila = prioridadeFuraFila;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarPriorizacaoClienteResponse)) return false;
        ConsultarPriorizacaoClienteResponse other = (ConsultarPriorizacaoClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.flagDerrubaTalker==null && other.getFlagDerrubaTalker()==null) || 
             (this.flagDerrubaTalker!=null &&
              this.flagDerrubaTalker.equals(other.getFlagDerrubaTalker()))) &&
            ((this.flagCallback==null && other.getFlagCallback()==null) || 
             (this.flagCallback!=null &&
              this.flagCallback.equals(other.getFlagCallback()))) &&
            ((this.prioridadeFuraFila==null && other.getPrioridadeFuraFila()==null) || 
             (this.prioridadeFuraFila!=null &&
              this.prioridadeFuraFila.equals(other.getPrioridadeFuraFila())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFlagDerrubaTalker() != null) {
            _hashCode += getFlagDerrubaTalker().hashCode();
        }
        if (getFlagCallback() != null) {
            _hashCode += getFlagCallback().hashCode();
        }
        if (getPrioridadeFuraFila() != null) {
            _hashCode += getPrioridadeFuraFila().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarPriorizacaoClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPriorizacaoClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flagDerrubaTalker");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "flagDerrubaTalker"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("flagCallback");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "flagCallback"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("prioridadeFuraFila");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "prioridadeFuraFila"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
