/**
 * DadosPatAleloCommonType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class DadosPatAleloCommonType  implements java.io.Serializable {
    /* HORARIO DE FUNCIONAMENTO - 24 HORAS (S/N) */
    private java.lang.Boolean aberto24Horas;

    /* HORARIO DE FUNCIONAMENTO - COMERCIAL (S/N) */
    private java.lang.Boolean horarioComercial;

    /* DIAS DE FUNCIONAMENTO - DOMINGO (S/N) */
    private java.lang.Boolean domingo;

    /* HORARIO DE FUNCIONAMENTO - NOTURNO (S/N) */
    private java.lang.Boolean noturno;

    /* DIAS DE FUNCIONAMENTO - SABADO (S/N) */
    private java.lang.Boolean sabado;

    /* DIAS DE FUNCIONAMENTO - SEGUNDA A SEXTA (S/N) */
    private java.lang.Boolean segundaSexta;

    /* Padaria */
    private java.lang.Boolean padaria;

    /* OUTROS */
    private java.lang.Boolean outros;

    public DadosPatAleloCommonType() {
    }

    public DadosPatAleloCommonType(
           java.lang.Boolean aberto24Horas,
           java.lang.Boolean horarioComercial,
           java.lang.Boolean domingo,
           java.lang.Boolean noturno,
           java.lang.Boolean sabado,
           java.lang.Boolean segundaSexta,
           java.lang.Boolean padaria,
           java.lang.Boolean outros) {
           this.aberto24Horas = aberto24Horas;
           this.horarioComercial = horarioComercial;
           this.domingo = domingo;
           this.noturno = noturno;
           this.sabado = sabado;
           this.segundaSexta = segundaSexta;
           this.padaria = padaria;
           this.outros = outros;
    }


    /**
     * Gets the aberto24Horas value for this DadosPatAleloCommonType.
     * 
     * @return aberto24Horas   * HORARIO DE FUNCIONAMENTO - 24 HORAS (S/N)
     */
    public java.lang.Boolean getAberto24Horas() {
        return aberto24Horas;
    }


    /**
     * Sets the aberto24Horas value for this DadosPatAleloCommonType.
     * 
     * @param aberto24Horas   * HORARIO DE FUNCIONAMENTO - 24 HORAS (S/N)
     */
    public void setAberto24Horas(java.lang.Boolean aberto24Horas) {
        this.aberto24Horas = aberto24Horas;
    }


    /**
     * Gets the horarioComercial value for this DadosPatAleloCommonType.
     * 
     * @return horarioComercial   * HORARIO DE FUNCIONAMENTO - COMERCIAL (S/N)
     */
    public java.lang.Boolean getHorarioComercial() {
        return horarioComercial;
    }


    /**
     * Sets the horarioComercial value for this DadosPatAleloCommonType.
     * 
     * @param horarioComercial   * HORARIO DE FUNCIONAMENTO - COMERCIAL (S/N)
     */
    public void setHorarioComercial(java.lang.Boolean horarioComercial) {
        this.horarioComercial = horarioComercial;
    }


    /**
     * Gets the domingo value for this DadosPatAleloCommonType.
     * 
     * @return domingo   * DIAS DE FUNCIONAMENTO - DOMINGO (S/N)
     */
    public java.lang.Boolean getDomingo() {
        return domingo;
    }


    /**
     * Sets the domingo value for this DadosPatAleloCommonType.
     * 
     * @param domingo   * DIAS DE FUNCIONAMENTO - DOMINGO (S/N)
     */
    public void setDomingo(java.lang.Boolean domingo) {
        this.domingo = domingo;
    }


    /**
     * Gets the noturno value for this DadosPatAleloCommonType.
     * 
     * @return noturno   * HORARIO DE FUNCIONAMENTO - NOTURNO (S/N)
     */
    public java.lang.Boolean getNoturno() {
        return noturno;
    }


    /**
     * Sets the noturno value for this DadosPatAleloCommonType.
     * 
     * @param noturno   * HORARIO DE FUNCIONAMENTO - NOTURNO (S/N)
     */
    public void setNoturno(java.lang.Boolean noturno) {
        this.noturno = noturno;
    }


    /**
     * Gets the sabado value for this DadosPatAleloCommonType.
     * 
     * @return sabado   * DIAS DE FUNCIONAMENTO - SABADO (S/N)
     */
    public java.lang.Boolean getSabado() {
        return sabado;
    }


    /**
     * Sets the sabado value for this DadosPatAleloCommonType.
     * 
     * @param sabado   * DIAS DE FUNCIONAMENTO - SABADO (S/N)
     */
    public void setSabado(java.lang.Boolean sabado) {
        this.sabado = sabado;
    }


    /**
     * Gets the segundaSexta value for this DadosPatAleloCommonType.
     * 
     * @return segundaSexta   * DIAS DE FUNCIONAMENTO - SEGUNDA A SEXTA (S/N)
     */
    public java.lang.Boolean getSegundaSexta() {
        return segundaSexta;
    }


    /**
     * Sets the segundaSexta value for this DadosPatAleloCommonType.
     * 
     * @param segundaSexta   * DIAS DE FUNCIONAMENTO - SEGUNDA A SEXTA (S/N)
     */
    public void setSegundaSexta(java.lang.Boolean segundaSexta) {
        this.segundaSexta = segundaSexta;
    }


    /**
     * Gets the padaria value for this DadosPatAleloCommonType.
     * 
     * @return padaria   * Padaria
     */
    public java.lang.Boolean getPadaria() {
        return padaria;
    }


    /**
     * Sets the padaria value for this DadosPatAleloCommonType.
     * 
     * @param padaria   * Padaria
     */
    public void setPadaria(java.lang.Boolean padaria) {
        this.padaria = padaria;
    }


    /**
     * Gets the outros value for this DadosPatAleloCommonType.
     * 
     * @return outros   * OUTROS
     */
    public java.lang.Boolean getOutros() {
        return outros;
    }


    /**
     * Sets the outros value for this DadosPatAleloCommonType.
     * 
     * @param outros   * OUTROS
     */
    public void setOutros(java.lang.Boolean outros) {
        this.outros = outros;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosPatAleloCommonType)) return false;
        DadosPatAleloCommonType other = (DadosPatAleloCommonType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.aberto24Horas==null && other.getAberto24Horas()==null) || 
             (this.aberto24Horas!=null &&
              this.aberto24Horas.equals(other.getAberto24Horas()))) &&
            ((this.horarioComercial==null && other.getHorarioComercial()==null) || 
             (this.horarioComercial!=null &&
              this.horarioComercial.equals(other.getHorarioComercial()))) &&
            ((this.domingo==null && other.getDomingo()==null) || 
             (this.domingo!=null &&
              this.domingo.equals(other.getDomingo()))) &&
            ((this.noturno==null && other.getNoturno()==null) || 
             (this.noturno!=null &&
              this.noturno.equals(other.getNoturno()))) &&
            ((this.sabado==null && other.getSabado()==null) || 
             (this.sabado!=null &&
              this.sabado.equals(other.getSabado()))) &&
            ((this.segundaSexta==null && other.getSegundaSexta()==null) || 
             (this.segundaSexta!=null &&
              this.segundaSexta.equals(other.getSegundaSexta()))) &&
            ((this.padaria==null && other.getPadaria()==null) || 
             (this.padaria!=null &&
              this.padaria.equals(other.getPadaria()))) &&
            ((this.outros==null && other.getOutros()==null) || 
             (this.outros!=null &&
              this.outros.equals(other.getOutros())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAberto24Horas() != null) {
            _hashCode += getAberto24Horas().hashCode();
        }
        if (getHorarioComercial() != null) {
            _hashCode += getHorarioComercial().hashCode();
        }
        if (getDomingo() != null) {
            _hashCode += getDomingo().hashCode();
        }
        if (getNoturno() != null) {
            _hashCode += getNoturno().hashCode();
        }
        if (getSabado() != null) {
            _hashCode += getSabado().hashCode();
        }
        if (getSegundaSexta() != null) {
            _hashCode += getSegundaSexta().hashCode();
        }
        if (getPadaria() != null) {
            _hashCode += getPadaria().hashCode();
        }
        if (getOutros() != null) {
            _hashCode += getOutros().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosPatAleloCommonType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloCommonType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aberto24Horas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "aberto24Horas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horarioComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "horarioComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domingo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "domingo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("noturno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "noturno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sabado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "sabado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("segundaSexta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "segundaSexta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("padaria");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "padaria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("outros");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "outros"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
