/**
 * DadosPatAleloVVRType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class DadosPatAleloVVRType  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.PatAlelo patAlelo;

    private br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo;

    private br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVRType dadosTipoEstabelecimentoVVR;

    public DadosPatAleloVVRType() {
    }

    public DadosPatAleloVVRType(
           br.com.cielo.canonico.cadastro.v1.PatAlelo patAlelo,
           br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo,
           br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVRType dadosTipoEstabelecimentoVVR) {
           this.patAlelo = patAlelo;
           this.dadosPatAlelo = dadosPatAlelo;
           this.dadosTipoEstabelecimentoVVR = dadosTipoEstabelecimentoVVR;
    }


    /**
     * Gets the patAlelo value for this DadosPatAleloVVRType.
     * 
     * @return patAlelo
     */
    public br.com.cielo.canonico.cadastro.v1.PatAlelo getPatAlelo() {
        return patAlelo;
    }


    /**
     * Sets the patAlelo value for this DadosPatAleloVVRType.
     * 
     * @param patAlelo
     */
    public void setPatAlelo(br.com.cielo.canonico.cadastro.v1.PatAlelo patAlelo) {
        this.patAlelo = patAlelo;
    }


    /**
     * Gets the dadosPatAlelo value for this DadosPatAleloVVRType.
     * 
     * @return dadosPatAlelo
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType getDadosPatAlelo() {
        return dadosPatAlelo;
    }


    /**
     * Sets the dadosPatAlelo value for this DadosPatAleloVVRType.
     * 
     * @param dadosPatAlelo
     */
    public void setDadosPatAlelo(br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo) {
        this.dadosPatAlelo = dadosPatAlelo;
    }


    /**
     * Gets the dadosTipoEstabelecimentoVVR value for this DadosPatAleloVVRType.
     * 
     * @return dadosTipoEstabelecimentoVVR
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVRType getDadosTipoEstabelecimentoVVR() {
        return dadosTipoEstabelecimentoVVR;
    }


    /**
     * Sets the dadosTipoEstabelecimentoVVR value for this DadosPatAleloVVRType.
     * 
     * @param dadosTipoEstabelecimentoVVR
     */
    public void setDadosTipoEstabelecimentoVVR(br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVRType dadosTipoEstabelecimentoVVR) {
        this.dadosTipoEstabelecimentoVVR = dadosTipoEstabelecimentoVVR;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosPatAleloVVRType)) return false;
        DadosPatAleloVVRType other = (DadosPatAleloVVRType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.patAlelo==null && other.getPatAlelo()==null) || 
             (this.patAlelo!=null &&
              this.patAlelo.equals(other.getPatAlelo()))) &&
            ((this.dadosPatAlelo==null && other.getDadosPatAlelo()==null) || 
             (this.dadosPatAlelo!=null &&
              this.dadosPatAlelo.equals(other.getDadosPatAlelo()))) &&
            ((this.dadosTipoEstabelecimentoVVR==null && other.getDadosTipoEstabelecimentoVVR()==null) || 
             (this.dadosTipoEstabelecimentoVVR!=null &&
              this.dadosTipoEstabelecimentoVVR.equals(other.getDadosTipoEstabelecimentoVVR())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPatAlelo() != null) {
            _hashCode += getPatAlelo().hashCode();
        }
        if (getDadosPatAlelo() != null) {
            _hashCode += getDadosPatAlelo().hashCode();
        }
        if (getDadosTipoEstabelecimentoVVR() != null) {
            _hashCode += getDadosTipoEstabelecimentoVVR().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosPatAleloVVRType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloVVRType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("patAlelo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "patAlelo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "PatAlelo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosPatAlelo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosPatAlelo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloCommonType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosTipoEstabelecimentoVVR");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosTipoEstabelecimentoVVR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosTipoEstabelecimentoVVRType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
