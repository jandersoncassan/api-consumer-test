/**
 * HabilitarListaServicoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.servico.servico.v1;

public class HabilitarListaServicoRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o Cliente */
    private long codigoCliente;

    /* Informacoes dos servicos oferecido pela Cielo aos seus clientes */
    private br.com.cielo.service.cadastro.servico.servico.v1.ServicoType[] dadosServicoClienteHabilitacao;

    /* Indicador de que persistência deverá ser feita (S/N) */
    private br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequestIndicadorPersistencia indicadorPersistencia;

    /* Identificação da chave de correlação entre serviços. */
    private java.lang.String correlationId;

    public HabilitarListaServicoRequest() {
    }

    public HabilitarListaServicoRequest(
           long codigoCliente,
           br.com.cielo.service.cadastro.servico.servico.v1.ServicoType[] dadosServicoClienteHabilitacao,
           br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequestIndicadorPersistencia indicadorPersistencia,
           java.lang.String correlationId) {
           this.codigoCliente = codigoCliente;
           this.dadosServicoClienteHabilitacao = dadosServicoClienteHabilitacao;
           this.indicadorPersistencia = indicadorPersistencia;
           this.correlationId = correlationId;
    }


    /**
     * Gets the codigoCliente value for this HabilitarListaServicoRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this HabilitarListaServicoRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the dadosServicoClienteHabilitacao value for this HabilitarListaServicoRequest.
     * 
     * @return dadosServicoClienteHabilitacao   * Informacoes dos servicos oferecido pela Cielo aos seus clientes
     */
    public br.com.cielo.service.cadastro.servico.servico.v1.ServicoType[] getDadosServicoClienteHabilitacao() {
        return dadosServicoClienteHabilitacao;
    }


    /**
     * Sets the dadosServicoClienteHabilitacao value for this HabilitarListaServicoRequest.
     * 
     * @param dadosServicoClienteHabilitacao   * Informacoes dos servicos oferecido pela Cielo aos seus clientes
     */
    public void setDadosServicoClienteHabilitacao(br.com.cielo.service.cadastro.servico.servico.v1.ServicoType[] dadosServicoClienteHabilitacao) {
        this.dadosServicoClienteHabilitacao = dadosServicoClienteHabilitacao;
    }


    /**
     * Gets the indicadorPersistencia value for this HabilitarListaServicoRequest.
     * 
     * @return indicadorPersistencia   * Indicador de que persistência deverá ser feita (S/N)
     */
    public br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequestIndicadorPersistencia getIndicadorPersistencia() {
        return indicadorPersistencia;
    }


    /**
     * Sets the indicadorPersistencia value for this HabilitarListaServicoRequest.
     * 
     * @param indicadorPersistencia   * Indicador de que persistência deverá ser feita (S/N)
     */
    public void setIndicadorPersistencia(br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequestIndicadorPersistencia indicadorPersistencia) {
        this.indicadorPersistencia = indicadorPersistencia;
    }


    /**
     * Gets the correlationId value for this HabilitarListaServicoRequest.
     * 
     * @return correlationId   * Identificação da chave de correlação entre serviços.
     */
    public java.lang.String getCorrelationId() {
        return correlationId;
    }


    /**
     * Sets the correlationId value for this HabilitarListaServicoRequest.
     * 
     * @param correlationId   * Identificação da chave de correlação entre serviços.
     */
    public void setCorrelationId(java.lang.String correlationId) {
        this.correlationId = correlationId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HabilitarListaServicoRequest)) return false;
        HabilitarListaServicoRequest other = (HabilitarListaServicoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.dadosServicoClienteHabilitacao==null && other.getDadosServicoClienteHabilitacao()==null) || 
             (this.dadosServicoClienteHabilitacao!=null &&
              java.util.Arrays.equals(this.dadosServicoClienteHabilitacao, other.getDadosServicoClienteHabilitacao()))) &&
            ((this.indicadorPersistencia==null && other.getIndicadorPersistencia()==null) || 
             (this.indicadorPersistencia!=null &&
              this.indicadorPersistencia.equals(other.getIndicadorPersistencia()))) &&
            ((this.correlationId==null && other.getCorrelationId()==null) || 
             (this.correlationId!=null &&
              this.correlationId.equals(other.getCorrelationId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getDadosServicoClienteHabilitacao() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosServicoClienteHabilitacao());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosServicoClienteHabilitacao(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndicadorPersistencia() != null) {
            _hashCode += getIndicadorPersistencia().hashCode();
        }
        if (getCorrelationId() != null) {
            _hashCode += getCorrelationId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HabilitarListaServicoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", ">habilitarListaServicoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosServicoClienteHabilitacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "dadosServicoClienteHabilitacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "ServicoType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "servico"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorPersistencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "indicadorPersistencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", ">>habilitarListaServicoRequest>indicadorPersistencia"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correlationId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/servico/servico/v1", "correlationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
