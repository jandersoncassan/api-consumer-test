/**
 * Banco.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class Banco  implements java.io.Serializable {
    /* Numero que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN. */
    private java.lang.String codigoBanco;

    /* Nome que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN. */
    private java.lang.String nomeBanco;

    /* Indica se o Banco é parceiro ou não da Cielo */
    private java.lang.Boolean indicadorParceiro;

    /* Dados do contato principal com a instituicao bancaria. */
    private br.com.cielo.canonico.cadastro.v1.Contato dadosContatoPrincipal;

    /* Dados do contato adicional com a instituicao bancaria. */
    private br.com.cielo.canonico.cadastro.v1.Contato dadosContatoAdicional;

    /* Codigo do CNPJ do banco */
    private java.lang.String codigoCNPJ;

    public Banco() {
    }

    public Banco(
           java.lang.String codigoBanco,
           java.lang.String nomeBanco,
           java.lang.Boolean indicadorParceiro,
           br.com.cielo.canonico.cadastro.v1.Contato dadosContatoPrincipal,
           br.com.cielo.canonico.cadastro.v1.Contato dadosContatoAdicional,
           java.lang.String codigoCNPJ) {
           this.codigoBanco = codigoBanco;
           this.nomeBanco = nomeBanco;
           this.indicadorParceiro = indicadorParceiro;
           this.dadosContatoPrincipal = dadosContatoPrincipal;
           this.dadosContatoAdicional = dadosContatoAdicional;
           this.codigoCNPJ = codigoCNPJ;
    }


    /**
     * Gets the codigoBanco value for this Banco.
     * 
     * @return codigoBanco   * Numero que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public java.lang.String getCodigoBanco() {
        return codigoBanco;
    }


    /**
     * Sets the codigoBanco value for this Banco.
     * 
     * @param codigoBanco   * Numero que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public void setCodigoBanco(java.lang.String codigoBanco) {
        this.codigoBanco = codigoBanco;
    }


    /**
     * Gets the nomeBanco value for this Banco.
     * 
     * @return nomeBanco   * Nome que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public java.lang.String getNomeBanco() {
        return nomeBanco;
    }


    /**
     * Sets the nomeBanco value for this Banco.
     * 
     * @param nomeBanco   * Nome que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public void setNomeBanco(java.lang.String nomeBanco) {
        this.nomeBanco = nomeBanco;
    }


    /**
     * Gets the indicadorParceiro value for this Banco.
     * 
     * @return indicadorParceiro   * Indica se o Banco é parceiro ou não da Cielo
     */
    public java.lang.Boolean getIndicadorParceiro() {
        return indicadorParceiro;
    }


    /**
     * Sets the indicadorParceiro value for this Banco.
     * 
     * @param indicadorParceiro   * Indica se o Banco é parceiro ou não da Cielo
     */
    public void setIndicadorParceiro(java.lang.Boolean indicadorParceiro) {
        this.indicadorParceiro = indicadorParceiro;
    }


    /**
     * Gets the dadosContatoPrincipal value for this Banco.
     * 
     * @return dadosContatoPrincipal   * Dados do contato principal com a instituicao bancaria.
     */
    public br.com.cielo.canonico.cadastro.v1.Contato getDadosContatoPrincipal() {
        return dadosContatoPrincipal;
    }


    /**
     * Sets the dadosContatoPrincipal value for this Banco.
     * 
     * @param dadosContatoPrincipal   * Dados do contato principal com a instituicao bancaria.
     */
    public void setDadosContatoPrincipal(br.com.cielo.canonico.cadastro.v1.Contato dadosContatoPrincipal) {
        this.dadosContatoPrincipal = dadosContatoPrincipal;
    }


    /**
     * Gets the dadosContatoAdicional value for this Banco.
     * 
     * @return dadosContatoAdicional   * Dados do contato adicional com a instituicao bancaria.
     */
    public br.com.cielo.canonico.cadastro.v1.Contato getDadosContatoAdicional() {
        return dadosContatoAdicional;
    }


    /**
     * Sets the dadosContatoAdicional value for this Banco.
     * 
     * @param dadosContatoAdicional   * Dados do contato adicional com a instituicao bancaria.
     */
    public void setDadosContatoAdicional(br.com.cielo.canonico.cadastro.v1.Contato dadosContatoAdicional) {
        this.dadosContatoAdicional = dadosContatoAdicional;
    }


    /**
     * Gets the codigoCNPJ value for this Banco.
     * 
     * @return codigoCNPJ   * Codigo do CNPJ do banco
     */
    public java.lang.String getCodigoCNPJ() {
        return codigoCNPJ;
    }


    /**
     * Sets the codigoCNPJ value for this Banco.
     * 
     * @param codigoCNPJ   * Codigo do CNPJ do banco
     */
    public void setCodigoCNPJ(java.lang.String codigoCNPJ) {
        this.codigoCNPJ = codigoCNPJ;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Banco)) return false;
        Banco other = (Banco) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoBanco==null && other.getCodigoBanco()==null) || 
             (this.codigoBanco!=null &&
              this.codigoBanco.equals(other.getCodigoBanco()))) &&
            ((this.nomeBanco==null && other.getNomeBanco()==null) || 
             (this.nomeBanco!=null &&
              this.nomeBanco.equals(other.getNomeBanco()))) &&
            ((this.indicadorParceiro==null && other.getIndicadorParceiro()==null) || 
             (this.indicadorParceiro!=null &&
              this.indicadorParceiro.equals(other.getIndicadorParceiro()))) &&
            ((this.dadosContatoPrincipal==null && other.getDadosContatoPrincipal()==null) || 
             (this.dadosContatoPrincipal!=null &&
              this.dadosContatoPrincipal.equals(other.getDadosContatoPrincipal()))) &&
            ((this.dadosContatoAdicional==null && other.getDadosContatoAdicional()==null) || 
             (this.dadosContatoAdicional!=null &&
              this.dadosContatoAdicional.equals(other.getDadosContatoAdicional()))) &&
            ((this.codigoCNPJ==null && other.getCodigoCNPJ()==null) || 
             (this.codigoCNPJ!=null &&
              this.codigoCNPJ.equals(other.getCodigoCNPJ())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoBanco() != null) {
            _hashCode += getCodigoBanco().hashCode();
        }
        if (getNomeBanco() != null) {
            _hashCode += getNomeBanco().hashCode();
        }
        if (getIndicadorParceiro() != null) {
            _hashCode += getIndicadorParceiro().hashCode();
        }
        if (getDadosContatoPrincipal() != null) {
            _hashCode += getDadosContatoPrincipal().hashCode();
        }
        if (getDadosContatoAdicional() != null) {
            _hashCode += getDadosContatoAdicional().hashCode();
        }
        if (getCodigoCNPJ() != null) {
            _hashCode += getCodigoCNPJ().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Banco.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Banco"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorParceiro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorParceiro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoPrincipal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoPrincipal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosContatoAdicional");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosContatoAdicional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCNPJ");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoCNPJ"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
