/**
 * DadosBancarios.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class DadosBancarios  implements java.io.Serializable {
    private java.math.BigInteger codigoBanco;

    private java.math.BigInteger numeroAgencia;

    private java.lang.String numeroContaCorrente;

    private java.lang.String numeroDACAgencia;

    private java.lang.String numeroDACContaCorrente;

    /* Lista com o nome das bandeiras que estao travadas neste domicilio
     * bancarios */
    private java.lang.String[] nomeBandeiraTrava;

    /* Nome que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN. */
    private java.lang.String nomeBanco;

    public DadosBancarios() {
    }

    public DadosBancarios(
           java.math.BigInteger codigoBanco,
           java.math.BigInteger numeroAgencia,
           java.lang.String numeroContaCorrente,
           java.lang.String numeroDACAgencia,
           java.lang.String numeroDACContaCorrente,
           java.lang.String[] nomeBandeiraTrava,
           java.lang.String nomeBanco) {
           this.codigoBanco = codigoBanco;
           this.numeroAgencia = numeroAgencia;
           this.numeroContaCorrente = numeroContaCorrente;
           this.numeroDACAgencia = numeroDACAgencia;
           this.numeroDACContaCorrente = numeroDACContaCorrente;
           this.nomeBandeiraTrava = nomeBandeiraTrava;
           this.nomeBanco = nomeBanco;
    }


    /**
     * Gets the codigoBanco value for this DadosBancarios.
     * 
     * @return codigoBanco
     */
    public java.math.BigInteger getCodigoBanco() {
        return codigoBanco;
    }


    /**
     * Sets the codigoBanco value for this DadosBancarios.
     * 
     * @param codigoBanco
     */
    public void setCodigoBanco(java.math.BigInteger codigoBanco) {
        this.codigoBanco = codigoBanco;
    }


    /**
     * Gets the numeroAgencia value for this DadosBancarios.
     * 
     * @return numeroAgencia
     */
    public java.math.BigInteger getNumeroAgencia() {
        return numeroAgencia;
    }


    /**
     * Sets the numeroAgencia value for this DadosBancarios.
     * 
     * @param numeroAgencia
     */
    public void setNumeroAgencia(java.math.BigInteger numeroAgencia) {
        this.numeroAgencia = numeroAgencia;
    }


    /**
     * Gets the numeroContaCorrente value for this DadosBancarios.
     * 
     * @return numeroContaCorrente
     */
    public java.lang.String getNumeroContaCorrente() {
        return numeroContaCorrente;
    }


    /**
     * Sets the numeroContaCorrente value for this DadosBancarios.
     * 
     * @param numeroContaCorrente
     */
    public void setNumeroContaCorrente(java.lang.String numeroContaCorrente) {
        this.numeroContaCorrente = numeroContaCorrente;
    }


    /**
     * Gets the numeroDACAgencia value for this DadosBancarios.
     * 
     * @return numeroDACAgencia
     */
    public java.lang.String getNumeroDACAgencia() {
        return numeroDACAgencia;
    }


    /**
     * Sets the numeroDACAgencia value for this DadosBancarios.
     * 
     * @param numeroDACAgencia
     */
    public void setNumeroDACAgencia(java.lang.String numeroDACAgencia) {
        this.numeroDACAgencia = numeroDACAgencia;
    }


    /**
     * Gets the numeroDACContaCorrente value for this DadosBancarios.
     * 
     * @return numeroDACContaCorrente
     */
    public java.lang.String getNumeroDACContaCorrente() {
        return numeroDACContaCorrente;
    }


    /**
     * Sets the numeroDACContaCorrente value for this DadosBancarios.
     * 
     * @param numeroDACContaCorrente
     */
    public void setNumeroDACContaCorrente(java.lang.String numeroDACContaCorrente) {
        this.numeroDACContaCorrente = numeroDACContaCorrente;
    }


    /**
     * Gets the nomeBandeiraTrava value for this DadosBancarios.
     * 
     * @return nomeBandeiraTrava   * Lista com o nome das bandeiras que estao travadas neste domicilio
     * bancarios
     */
    public java.lang.String[] getNomeBandeiraTrava() {
        return nomeBandeiraTrava;
    }


    /**
     * Sets the nomeBandeiraTrava value for this DadosBancarios.
     * 
     * @param nomeBandeiraTrava   * Lista com o nome das bandeiras que estao travadas neste domicilio
     * bancarios
     */
    public void setNomeBandeiraTrava(java.lang.String[] nomeBandeiraTrava) {
        this.nomeBandeiraTrava = nomeBandeiraTrava;
    }

    public java.lang.String getNomeBandeiraTrava(int i) {
        return this.nomeBandeiraTrava[i];
    }

    public void setNomeBandeiraTrava(int i, java.lang.String _value) {
        this.nomeBandeiraTrava[i] = _value;
    }


    /**
     * Gets the nomeBanco value for this DadosBancarios.
     * 
     * @return nomeBanco   * Nome que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public java.lang.String getNomeBanco() {
        return nomeBanco;
    }


    /**
     * Sets the nomeBanco value for this DadosBancarios.
     * 
     * @param nomeBanco   * Nome que identifica o banco dentro do sistema de compensacao
     * nacional controlado pelo BACEN.
     */
    public void setNomeBanco(java.lang.String nomeBanco) {
        this.nomeBanco = nomeBanco;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosBancarios)) return false;
        DadosBancarios other = (DadosBancarios) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoBanco==null && other.getCodigoBanco()==null) || 
             (this.codigoBanco!=null &&
              this.codigoBanco.equals(other.getCodigoBanco()))) &&
            ((this.numeroAgencia==null && other.getNumeroAgencia()==null) || 
             (this.numeroAgencia!=null &&
              this.numeroAgencia.equals(other.getNumeroAgencia()))) &&
            ((this.numeroContaCorrente==null && other.getNumeroContaCorrente()==null) || 
             (this.numeroContaCorrente!=null &&
              this.numeroContaCorrente.equals(other.getNumeroContaCorrente()))) &&
            ((this.numeroDACAgencia==null && other.getNumeroDACAgencia()==null) || 
             (this.numeroDACAgencia!=null &&
              this.numeroDACAgencia.equals(other.getNumeroDACAgencia()))) &&
            ((this.numeroDACContaCorrente==null && other.getNumeroDACContaCorrente()==null) || 
             (this.numeroDACContaCorrente!=null &&
              this.numeroDACContaCorrente.equals(other.getNumeroDACContaCorrente()))) &&
            ((this.nomeBandeiraTrava==null && other.getNomeBandeiraTrava()==null) || 
             (this.nomeBandeiraTrava!=null &&
              java.util.Arrays.equals(this.nomeBandeiraTrava, other.getNomeBandeiraTrava()))) &&
            ((this.nomeBanco==null && other.getNomeBanco()==null) || 
             (this.nomeBanco!=null &&
              this.nomeBanco.equals(other.getNomeBanco())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoBanco() != null) {
            _hashCode += getCodigoBanco().hashCode();
        }
        if (getNumeroAgencia() != null) {
            _hashCode += getNumeroAgencia().hashCode();
        }
        if (getNumeroContaCorrente() != null) {
            _hashCode += getNumeroContaCorrente().hashCode();
        }
        if (getNumeroDACAgencia() != null) {
            _hashCode += getNumeroDACAgencia().hashCode();
        }
        if (getNumeroDACContaCorrente() != null) {
            _hashCode += getNumeroDACContaCorrente().hashCode();
        }
        if (getNomeBandeiraTrava() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNomeBandeiraTrava());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNomeBandeiraTrava(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getNomeBanco() != null) {
            _hashCode += getNomeBanco().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosBancarios.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DadosBancarios"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroAgencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroAgencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroContaCorrente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroContaCorrente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDACAgencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroDACAgencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDACContaCorrente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroDACContaCorrente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBandeiraTrava");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeBandeiraTrava"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
