/**
 * ClienteServiceSOAPBindingStub.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ClienteServiceSOAPBindingStub extends org.apache.axis.client.Stub implements br.com.cielo.service.cadastro.cliente.cliente.v3.ClienteServicePortType {
    private java.util.Vector cachedSerClasses = new java.util.Vector();
    private java.util.Vector cachedSerQNames = new java.util.Vector();
    private java.util.Vector cachedSerFactories = new java.util.Vector();
    private java.util.Vector cachedDeserFactories = new java.util.Vector();

    static org.apache.axis.description.OperationDesc [] _operations;

    static {
        _operations = new org.apache.axis.description.OperationDesc[18];
        _initOperationDesc1();
        _initOperationDesc2();
    }

    private static void _initOperationDesc1(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarDadosCadastraisCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDadosCadastraisClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDadosCadastraisClienteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDadosCadastraisClienteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDadosCadastraisClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[0] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarFiliais");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarFiliaisRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarFiliaisRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarFiliaisResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarFiliaisResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[1] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarCadastroSite");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarCadastroSiteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarCadastroSiteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarCadastroSiteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarCadastroSiteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[2] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("alterarTerceiroTelefoneCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarTerceiroTelefoneClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarTerceiroTelefoneClienteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarTerceiroTelefoneClienteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarTerceiroTelefoneClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[3] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("checarPreAutorizacaoMCC");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "checarPreAutorizacaoMCCRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">checarPreAutorizacaoMCCRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">checarPreAutorizacaoMCCResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "checarPreAutorizacaoMCCResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[4] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("alterarStatusCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarStatusClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarStatusClienteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarStatusClienteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarStatusClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[5] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("alterarDadosCadastraisCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarDadosCadastraisClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDadosCadastraisClienteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDadosCadastraisClienteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarDadosCadastraisClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[6] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarDomicilioBancario");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[7] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarPriorizacaoCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarPriorizacaoClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPriorizacaoClienteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPriorizacaoClienteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarPriorizacaoClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[8] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarDomicilioBancarioTruncado");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioTruncadoRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioTruncadoRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioTruncadoResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioTruncadoResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[9] = oper;

    }

    private static void _initOperationDesc2(){
        org.apache.axis.description.OperationDesc oper;
        org.apache.axis.description.ParameterDesc param;
        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("solicitaAnaliseAlvara");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "solicitaAnaliseAlvaraRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">solicitaAnaliseAlvaraRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">solicitaAnaliseAlvaraResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "solicitaAnaliseAlvaraResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[10] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("manterPrazoFlexivel");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "manterPrazoFlexivelRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">manterPrazoFlexivelRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">manterPrazoFlexivelResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "manterPrazoFlexivelResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[11] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarPrazosTaxasPrazoFlexivel");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarPrazosTaxasPrazoFlexivelRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPrazosTaxasPrazoFlexivelRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPrazosTaxasPrazoFlexivelResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarPrazosTaxasPrazoFlexivelResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[12] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("alterarDomicilioBancario");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarDomicilioBancarioRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDomicilioBancarioRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDomicilioBancarioResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarDomicilioBancarioResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[13] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("alterarRamoAtividade");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarRamoAtividadeRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarRamoAtividadeRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarRamoAtividadeResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarRamoAtividadeResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[14] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("alterarSMSCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarSMSClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarSMSClienteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarSMSClienteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "alterarSMSClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[15] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("consultarECCompanhiaAerea");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarECCompanhiaAereaRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarECCompanhiaAereaRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaRequest.class, false, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarECCompanhiaAereaResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarECCompanhiaAereaResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[16] = oper;

        oper = new org.apache.axis.description.OperationDesc();
        oper.setName("verificarExistenciaCliente");
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "verificarExistenciaClienteRequest"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">verificarExistenciaClienteRequest"), br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteRequest.class, false, false);
        oper.addParameter(param);
        param = new org.apache.axis.description.ParameterDesc(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "cieloSoapHeader"), org.apache.axis.description.ParameterDesc.IN, new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"), br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class, true, false);
        oper.addParameter(param);
        oper.setReturnType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">verificarExistenciaClienteResponse"));
        oper.setReturnClass(br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse.class);
        oper.setReturnQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "verificarExistenciaClienteResponse"));
        oper.setStyle(org.apache.axis.constants.Style.DOCUMENT);
        oper.setUse(org.apache.axis.constants.Use.LITERAL);
        oper.addFault(new org.apache.axis.description.FaultDesc(
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "fault"),
                      "br.com.cielo.canonico.comum.v1.Fault",
                      new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"), 
                      true
                     ));
        _operations[17] = oper;

    }

    public ClienteServiceSOAPBindingStub() throws org.apache.axis.AxisFault {
         this(null);
    }

    public ClienteServiceSOAPBindingStub(java.net.URL endpointURL, javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
         this(service);
         super.cachedEndpoint = endpointURL;
    }

    public ClienteServiceSOAPBindingStub(javax.xml.rpc.Service service) throws org.apache.axis.AxisFault {
        if (service == null) {
            super.service = new org.apache.axis.client.Service();
        } else {
            super.service = service;
        }
        ((org.apache.axis.client.Service)super.service).setTypeMappingVersion("1.2");
            java.lang.Class cls;
            javax.xml.namespace.QName qName;
            javax.xml.namespace.QName qName2;
            java.lang.Class beansf = org.apache.axis.encoding.ser.BeanSerializerFactory.class;
            java.lang.Class beandf = org.apache.axis.encoding.ser.BeanDeserializerFactory.class;
            java.lang.Class enumsf = org.apache.axis.encoding.ser.EnumSerializerFactory.class;
            java.lang.Class enumdf = org.apache.axis.encoding.ser.EnumDeserializerFactory.class;
            java.lang.Class arraysf = org.apache.axis.encoding.ser.ArraySerializerFactory.class;
            java.lang.Class arraydf = org.apache.axis.encoding.ser.ArrayDeserializerFactory.class;
            java.lang.Class simplesf = org.apache.axis.encoding.ser.SimpleSerializerFactory.class;
            java.lang.Class simpledf = org.apache.axis.encoding.ser.SimpleDeserializerFactory.class;
            java.lang.Class simplelistsf = org.apache.axis.encoding.ser.SimpleListSerializerFactory.class;
            java.lang.Class simplelistdf = org.apache.axis.encoding.ser.SimpleListDeserializerFactory.class;
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Codigo");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Moeda");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Moeda.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Cliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Cliente.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Contato.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contatos");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Contato[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Contato");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "contato");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Credenciamento");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Credenciamento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DadosBancarios");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.DadosBancarios.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Endereco.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Enderecos");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Endereco[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "enderecos");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixasTaxaSegmentado");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixaTaxaSegmentado");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosFaixaTaxaSegmentado");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "FaixaTaxaSegmentado");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.FaixaTaxaSegmentado.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filiais");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Filial[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filial");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "filial");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filial");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Filial.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GrupoProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GruposProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GrupoProdutoPrazoFlexivel");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosGrupoProdutoPrazoFlexivel");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Produto.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produtos");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Produto[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Produto");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "produto");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Proprietario");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Proprietario.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Proprietarios");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Proprietarios.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacaoFuncionamentoCliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacoesFuncionamentoCliente");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.SituacaoFuncionamentoCliente[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "SituacaoFuncionamentoCliente");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "situacaoFuncionamentoCliente");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Tarifa");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.Tarifa.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifaGrupoProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifasGrupoProdutoPrazoFlexivel");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.cadastro.v1.TarifaGrupoProdutoPrazoFlexivel[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "TarifaGrupoProdutoPrazoFlexivel");
            qName2 = new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosTarifaGrupoProdutoPrazoFlexivel");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/canalrelacionamento/atendimentoassistido/v1", "SolicitacaoCentralAtendimento");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.canalrelacionamento.atendimentoassistido.v1.SolicitacaoCentralAtendimento.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.Fault.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "FaultDetail");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.FaultDetail.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Tipo");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.comum.v1.Tipo.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "faultcode");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.Faultcode.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(enumsf);
            cachedDeserFactories.add(enumdf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "IdentificacaoRequestType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.IdentificacaoRequestType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "UsuarioType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDadosCadastraisClienteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDadosCadastraisClienteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDomicilioBancarioRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDomicilioBancarioResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarRamoAtividadeRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarRamoAtividadeResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarSMSClienteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarSMSClienteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarStatusClienteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarStatusClienteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarTerceiroTelefoneClienteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarTerceiroTelefoneClienteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">checarPreAutorizacaoMCCRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">checarPreAutorizacaoMCCResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarCadastroSiteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarCadastroSiteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDadosCadastraisClienteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDadosCadastraisClienteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioTruncadoRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDomicilioBancarioTruncadoResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarECCompanhiaAereaRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarECCompanhiaAereaResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarFiliaisRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarFiliaisResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPrazosTaxasPrazoFlexivelRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPrazosTaxasPrazoFlexivelResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPriorizacaoClienteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarPriorizacaoClienteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">DomicilioBancarioType>numeroContaCorrente");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">IdentificacaoClienteType>CNPJ");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">IdentificacaoClienteType>CPF");
            cachedSerQNames.add(qName);
            cls = java.lang.String.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(org.apache.axis.encoding.ser.BaseSerializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleSerializerFactory.class, cls, qName));
            cachedDeserFactories.add(org.apache.axis.encoding.ser.BaseDeserializerFactory.createFactory(org.apache.axis.encoding.ser.SimpleDeserializerFactory.class, cls, qName));

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">manterPrazoFlexivelRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">manterPrazoFlexivelResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">solicitaAnaliseAlvaraRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">solicitaAnaliseAlvaraResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">verificarExistenciaClienteRequest");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteRequest.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">verificarExistenciaClienteResponse");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioTruncadoType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "DadosGrupoProdutoPrazoFlexivelType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.DadosGrupoProdutoPrazoFlexivelType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "DomicilioBancarioType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.DomicilioBancarioType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "DomiciliosBancariosType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioTruncadoType");
            qName2 = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "domicilioBancario");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "GruposProdutoPrazoFlexivelType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.DadosGrupoProdutoPrazoFlexivelType[].class;
            cachedSerClasses.add(cls);
            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "DadosGrupoProdutoPrazoFlexivelType");
            qName2 = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "dadosGrupoProdutoPrazoFlexivel");
            cachedSerFactories.add(new org.apache.axis.encoding.ser.ArraySerializerFactory(qName, qName2));
            cachedDeserFactories.add(new org.apache.axis.encoding.ser.ArrayDeserializerFactory());

            qName = new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "IdentificacaoClienteType");
            cachedSerQNames.add(qName);
            cls = br.com.cielo.service.cadastro.cliente.cliente.v3.IdentificacaoClienteType.class;
            cachedSerClasses.add(cls);
            cachedSerFactories.add(beansf);
            cachedDeserFactories.add(beandf);

    }

    protected org.apache.axis.client.Call createCall() throws java.rmi.RemoteException {
        try {
            org.apache.axis.client.Call _call = super._createCall();
            if (super.maintainSessionSet) {
                _call.setMaintainSession(super.maintainSession);
            }
            if (super.cachedUsername != null) {
                _call.setUsername(super.cachedUsername);
            }
            if (super.cachedPassword != null) {
                _call.setPassword(super.cachedPassword);
            }
            if (super.cachedEndpoint != null) {
                _call.setTargetEndpointAddress(super.cachedEndpoint);
            }
            if (super.cachedTimeout != null) {
                _call.setTimeout(super.cachedTimeout);
            }
            if (super.cachedPortName != null) {
                _call.setPortName(super.cachedPortName);
            }
            java.util.Enumeration keys = super.cachedProperties.keys();
            while (keys.hasMoreElements()) {
                java.lang.String key = (java.lang.String) keys.nextElement();
                _call.setProperty(key, super.cachedProperties.get(key));
            }
            // All the type mapping information is registered
            // when the first call is made.
            // The type mapping information is actually registered in
            // the TypeMappingRegistry of the service, which
            // is the reason why registration is only needed for the first call.
            synchronized (this) {
                if (firstCall()) {
                    // must set encoding style before registering serializers
                    _call.setEncodingStyle(null);
                    for (int i = 0; i < cachedSerFactories.size(); ++i) {
                        java.lang.Class cls = (java.lang.Class) cachedSerClasses.get(i);
                        javax.xml.namespace.QName qName =
                                (javax.xml.namespace.QName) cachedSerQNames.get(i);
                        java.lang.Object x = cachedSerFactories.get(i);
                        if (x instanceof Class) {
                            java.lang.Class sf = (java.lang.Class)
                                 cachedSerFactories.get(i);
                            java.lang.Class df = (java.lang.Class)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                        else if (x instanceof javax.xml.rpc.encoding.SerializerFactory) {
                            org.apache.axis.encoding.SerializerFactory sf = (org.apache.axis.encoding.SerializerFactory)
                                 cachedSerFactories.get(i);
                            org.apache.axis.encoding.DeserializerFactory df = (org.apache.axis.encoding.DeserializerFactory)
                                 cachedDeserFactories.get(i);
                            _call.registerTypeMapping(cls, qName, sf, df, false);
                        }
                    }
                }
            }
            return _call;
        }
        catch (java.lang.Throwable _t) {
            throw new org.apache.axis.AxisFault("Failure trying to get the Call object", _t);
        }
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse consultarDadosCadastraisCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[0]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarDadosCadastraisCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse consultarFiliais(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[1]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarFiliais"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse consultarCadastroSite(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[2]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarCadastroSite"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse alterarTerceiroTelefoneCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[3]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "alterarTerceiroTelefoneCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse checarPreAutorizacaoMCC(br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[4]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "checarPreAutorizacaoMCC"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse alterarStatusCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[5]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "alterarStatusCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse alterarDadosCadastraisCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[6]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "alterarDadosCadastraisCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse consultarDomicilioBancario(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[7]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarDomicilioBancario"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse consultarPriorizacaoCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[8]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarPriorizacaoCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse consultarDomicilioBancarioTruncado(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[9]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarDomicilioBancarioTruncado"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse solicitaAnaliseAlvara(br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[10]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "solicitaAnaliseAlvara"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse manterPrazoFlexivel(br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[11]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "manterPrazoFlexivel"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse consultarPrazosTaxasPrazoFlexivel(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[12]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarPrazosTaxasPrazoFlexivel"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse alterarDomicilioBancario(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[13]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "alterarDomicilioBancario"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse alterarRamoAtividade(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[14]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "alterarRamoAtividade"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse alterarSMSCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[15]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "alterarSMSCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse consultarECCompanhiaAerea(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[16]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "consultarECCompanhiaAerea"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

    public br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse verificarExistenciaCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault {
        if (super.cachedEndpoint == null) {
            throw new org.apache.axis.NoEndPointException();
        }
        org.apache.axis.client.Call _call = createCall();
        _call.setOperation(_operations[17]);
        _call.setEncodingStyle(null);
        _call.setProperty(org.apache.axis.client.Call.SEND_TYPE_ATTR, Boolean.FALSE);
        _call.setProperty(org.apache.axis.AxisEngine.PROP_DOMULTIREFS, Boolean.FALSE);
        _call.setSOAPVersion(org.apache.axis.soap.SOAPConstants.SOAP11_CONSTANTS);
        _call.setOperationName(new javax.xml.namespace.QName("", "verificarExistenciaCliente"));

        setRequestHeaders(_call);
        setAttachments(_call);
 try {        java.lang.Object _resp = _call.invoke(new java.lang.Object[] {parameters, header});

        if (_resp instanceof java.rmi.RemoteException) {
            throw (java.rmi.RemoteException)_resp;
        }
        else {
            extractAttachments(_call);
            try {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse) _resp;
            } catch (java.lang.Exception _exception) {
                return (br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse) org.apache.axis.utils.JavaUtils.convert(_resp, br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse.class);
            }
        }
  } catch (org.apache.axis.AxisFault axisFaultException) {
    if (axisFaultException.detail != null) {
        if (axisFaultException.detail instanceof java.rmi.RemoteException) {
              throw (java.rmi.RemoteException) axisFaultException.detail;
         }
        if (axisFaultException.detail instanceof br.com.cielo.canonico.comum.v1.Fault) {
              throw (br.com.cielo.canonico.comum.v1.Fault) axisFaultException.detail;
         }
   }
  throw axisFaultException;
}
    }

}
