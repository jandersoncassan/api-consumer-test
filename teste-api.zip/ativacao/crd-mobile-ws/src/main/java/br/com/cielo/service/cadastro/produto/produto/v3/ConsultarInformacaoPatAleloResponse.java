/**
 * ConsultarInformacaoPatAleloResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarInformacaoPatAleloResponse  implements java.io.Serializable {
    private br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVRType dadosPatAleloVVR;

    private br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVAType dadosPatAleloVVA;

    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    public ConsultarInformacaoPatAleloResponse() {
    }

    public ConsultarInformacaoPatAleloResponse(
           br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVRType dadosPatAleloVVR,
           br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVAType dadosPatAleloVVA,
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem) {
           this.dadosPatAleloVVR = dadosPatAleloVVR;
           this.dadosPatAleloVVA = dadosPatAleloVVA;
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the dadosPatAleloVVR value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @return dadosPatAleloVVR
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVRType getDadosPatAleloVVR() {
        return dadosPatAleloVVR;
    }


    /**
     * Sets the dadosPatAleloVVR value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @param dadosPatAleloVVR
     */
    public void setDadosPatAleloVVR(br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVRType dadosPatAleloVVR) {
        this.dadosPatAleloVVR = dadosPatAleloVVR;
    }


    /**
     * Gets the dadosPatAleloVVA value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @return dadosPatAleloVVA
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVAType getDadosPatAleloVVA() {
        return dadosPatAleloVVA;
    }


    /**
     * Sets the dadosPatAleloVVA value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @param dadosPatAleloVVA
     */
    public void setDadosPatAleloVVA(br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloVVAType dadosPatAleloVVA) {
        this.dadosPatAleloVVA = dadosPatAleloVVA;
    }


    /**
     * Gets the codigoRetorno value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this ConsultarInformacaoPatAleloResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarInformacaoPatAleloResponse)) return false;
        ConsultarInformacaoPatAleloResponse other = (ConsultarInformacaoPatAleloResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dadosPatAleloVVR==null && other.getDadosPatAleloVVR()==null) || 
             (this.dadosPatAleloVVR!=null &&
              this.dadosPatAleloVVR.equals(other.getDadosPatAleloVVR()))) &&
            ((this.dadosPatAleloVVA==null && other.getDadosPatAleloVVA()==null) || 
             (this.dadosPatAleloVVA!=null &&
              this.dadosPatAleloVVA.equals(other.getDadosPatAleloVVA()))) &&
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDadosPatAleloVVR() != null) {
            _hashCode += getDadosPatAleloVVR().hashCode();
        }
        if (getDadosPatAleloVVA() != null) {
            _hashCode += getDadosPatAleloVVA().hashCode();
        }
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarInformacaoPatAleloResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarInformacaoPatAleloResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosPatAleloVVR");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosPatAleloVVR"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloVVRType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosPatAleloVVA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosPatAleloVVA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloVVAType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
