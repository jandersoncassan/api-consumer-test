/**
 * ClienteServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public interface ClienteServicePortType extends java.rmi.Remote {

    /**
     * Operacao responsavel consultar dados cadastrais do cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteResponse consultarDadosCadastraisCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDadosCadastraisClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel consultar as filiais de um cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisResponse consultarFiliais(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarFiliaisRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel consulta de cadastro no Site Cielo.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteResponse consultarCadastroSite(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarCadastroSiteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por alterar do terceiro telefone do cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteResponse alterarTerceiroTelefoneCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarTerceiroTelefoneClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por checar da pre autorizacao do MCC.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCResponse checarPreAutorizacaoMCC(br.com.cielo.service.cadastro.cliente.cliente.v3.ChecarPreAutorizacaoMCCRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por alterar status cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteResponse alterarStatusCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarStatusClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por alterar Dados Cadastrais.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteResponse alterarDadosCadastraisCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDadosCadastraisClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por consultar domicilio bancario.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioResponse consultarDomicilioBancario(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por consultar a priorizacao do cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteResponse consultarPriorizacaoCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPriorizacaoClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por consultar domicilio bancario.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoResponse consultarDomicilioBancarioTruncado(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarDomicilioBancarioTruncadoRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por solicita Analise de Alvara.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraResponse solicitaAnaliseAlvara(br.com.cielo.service.cadastro.cliente.cliente.v3.SolicitaAnaliseAlvaraRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por Manter Prazo Flexivel.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelResponse manterPrazoFlexivel(br.com.cielo.service.cadastro.cliente.cliente.v3.ManterPrazoFlexivelRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por Consultar Prazos e Taxas - Prazo Flexivel.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelResponse consultarPrazosTaxasPrazoFlexivel(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarPrazosTaxasPrazoFlexivelRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel pela alteracao do domicilio bancario do
     * cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioResponse alterarDomicilioBancario(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarDomicilioBancarioRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel pela alteracao do Ramo de Atividade (MCC).
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeResponse alterarRamoAtividade(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarRamoAtividadeRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por alterar o SMS do cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteResponse alterarSMSCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.AlterarSMSClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel por consulta de Clientes (Companhia
     * 				aerea) atraves do codigoIATA, retornar o nome da companhia e o
     * 				codigo do cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaResponse consultarECCompanhiaAerea(br.com.cielo.service.cadastro.cliente.cliente.v3.ConsultarECCompanhiaAereaRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operacao responsavel verificar se o CNPJ ou CPF já pertence
     * a algum cliente.
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteResponse verificarExistenciaCliente(br.com.cielo.service.cadastro.cliente.cliente.v3.VerificarExistenciaClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
