/**
 * Filial.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class Filial  implements java.io.Serializable {
    private java.lang.Long numeroMatriz;

    private java.lang.Long numeroFilial;

    private java.lang.String nomeFantasia;

    private br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEndereco;

    public Filial() {
    }

    public Filial(
           java.lang.Long numeroMatriz,
           java.lang.Long numeroFilial,
           java.lang.String nomeFantasia,
           br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEndereco) {
           this.numeroMatriz = numeroMatriz;
           this.numeroFilial = numeroFilial;
           this.nomeFantasia = nomeFantasia;
           this.dadosEndereco = dadosEndereco;
    }


    /**
     * Gets the numeroMatriz value for this Filial.
     * 
     * @return numeroMatriz
     */
    public java.lang.Long getNumeroMatriz() {
        return numeroMatriz;
    }


    /**
     * Sets the numeroMatriz value for this Filial.
     * 
     * @param numeroMatriz
     */
    public void setNumeroMatriz(java.lang.Long numeroMatriz) {
        this.numeroMatriz = numeroMatriz;
    }


    /**
     * Gets the numeroFilial value for this Filial.
     * 
     * @return numeroFilial
     */
    public java.lang.Long getNumeroFilial() {
        return numeroFilial;
    }


    /**
     * Sets the numeroFilial value for this Filial.
     * 
     * @param numeroFilial
     */
    public void setNumeroFilial(java.lang.Long numeroFilial) {
        this.numeroFilial = numeroFilial;
    }


    /**
     * Gets the nomeFantasia value for this Filial.
     * 
     * @return nomeFantasia
     */
    public java.lang.String getNomeFantasia() {
        return nomeFantasia;
    }


    /**
     * Sets the nomeFantasia value for this Filial.
     * 
     * @param nomeFantasia
     */
    public void setNomeFantasia(java.lang.String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }


    /**
     * Gets the dadosEndereco value for this Filial.
     * 
     * @return dadosEndereco
     */
    public br.com.cielo.canonico.cadastro.v1.Endereco[] getDadosEndereco() {
        return dadosEndereco;
    }


    /**
     * Sets the dadosEndereco value for this Filial.
     * 
     * @param dadosEndereco
     */
    public void setDadosEndereco(br.com.cielo.canonico.cadastro.v1.Endereco[] dadosEndereco) {
        this.dadosEndereco = dadosEndereco;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Filial)) return false;
        Filial other = (Filial) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroMatriz==null && other.getNumeroMatriz()==null) || 
             (this.numeroMatriz!=null &&
              this.numeroMatriz.equals(other.getNumeroMatriz()))) &&
            ((this.numeroFilial==null && other.getNumeroFilial()==null) || 
             (this.numeroFilial!=null &&
              this.numeroFilial.equals(other.getNumeroFilial()))) &&
            ((this.nomeFantasia==null && other.getNomeFantasia()==null) || 
             (this.nomeFantasia!=null &&
              this.nomeFantasia.equals(other.getNomeFantasia()))) &&
            ((this.dadosEndereco==null && other.getDadosEndereco()==null) || 
             (this.dadosEndereco!=null &&
              java.util.Arrays.equals(this.dadosEndereco, other.getDadosEndereco())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroMatriz() != null) {
            _hashCode += getNumeroMatriz().hashCode();
        }
        if (getNumeroFilial() != null) {
            _hashCode += getNumeroFilial().hashCode();
        }
        if (getNomeFantasia() != null) {
            _hashCode += getNomeFantasia().hashCode();
        }
        if (getDadosEndereco() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosEndereco());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosEndereco(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Filial.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Filial"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroMatriz");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroMatriz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroFilial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroFilial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFantasia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomeFantasia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dadosEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "enderecos"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
