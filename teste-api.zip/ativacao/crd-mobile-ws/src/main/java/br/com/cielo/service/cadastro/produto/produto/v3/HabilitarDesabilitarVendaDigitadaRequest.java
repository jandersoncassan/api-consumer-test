/**
 * HabilitarDesabilitarVendaDigitadaRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class HabilitarDesabilitarVendaDigitadaRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o
     * 							Cliente */
    private java.lang.Long codigoCliente;

    /* Indica se a validação é para operação de Habilitar
     * 							ou Desabilitar (H/D) */
    private java.lang.String indicaOperacao;

    /* Lista que indica se o produto deverá ser Adicionado
     * 							ou Removido (S - Adicionar/N - Remover) */
    private br.com.cielo.service.cadastro.produto.produto.v3.VendaDigitadaType[] dadosVendaDigitada;

    public HabilitarDesabilitarVendaDigitadaRequest() {
    }

    public HabilitarDesabilitarVendaDigitadaRequest(
           java.lang.Long codigoCliente,
           java.lang.String indicaOperacao,
           br.com.cielo.service.cadastro.produto.produto.v3.VendaDigitadaType[] dadosVendaDigitada) {
           this.codigoCliente = codigoCliente;
           this.indicaOperacao = indicaOperacao;
           this.dadosVendaDigitada = dadosVendaDigitada;
    }


    /**
     * Gets the codigoCliente value for this HabilitarDesabilitarVendaDigitadaRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this HabilitarDesabilitarVendaDigitadaRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the indicaOperacao value for this HabilitarDesabilitarVendaDigitadaRequest.
     * 
     * @return indicaOperacao   * Indica se a validação é para operação de Habilitar
     * 							ou Desabilitar (H/D)
     */
    public java.lang.String getIndicaOperacao() {
        return indicaOperacao;
    }


    /**
     * Sets the indicaOperacao value for this HabilitarDesabilitarVendaDigitadaRequest.
     * 
     * @param indicaOperacao   * Indica se a validação é para operação de Habilitar
     * 							ou Desabilitar (H/D)
     */
    public void setIndicaOperacao(java.lang.String indicaOperacao) {
        this.indicaOperacao = indicaOperacao;
    }


    /**
     * Gets the dadosVendaDigitada value for this HabilitarDesabilitarVendaDigitadaRequest.
     * 
     * @return dadosVendaDigitada   * Lista que indica se o produto deverá ser Adicionado
     * 							ou Removido (S - Adicionar/N - Remover)
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.VendaDigitadaType[] getDadosVendaDigitada() {
        return dadosVendaDigitada;
    }


    /**
     * Sets the dadosVendaDigitada value for this HabilitarDesabilitarVendaDigitadaRequest.
     * 
     * @param dadosVendaDigitada   * Lista que indica se o produto deverá ser Adicionado
     * 							ou Removido (S - Adicionar/N - Remover)
     */
    public void setDadosVendaDigitada(br.com.cielo.service.cadastro.produto.produto.v3.VendaDigitadaType[] dadosVendaDigitada) {
        this.dadosVendaDigitada = dadosVendaDigitada;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HabilitarDesabilitarVendaDigitadaRequest)) return false;
        HabilitarDesabilitarVendaDigitadaRequest other = (HabilitarDesabilitarVendaDigitadaRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.indicaOperacao==null && other.getIndicaOperacao()==null) || 
             (this.indicaOperacao!=null &&
              this.indicaOperacao.equals(other.getIndicaOperacao()))) &&
            ((this.dadosVendaDigitada==null && other.getDadosVendaDigitada()==null) || 
             (this.dadosVendaDigitada!=null &&
              java.util.Arrays.equals(this.dadosVendaDigitada, other.getDadosVendaDigitada())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getIndicaOperacao() != null) {
            _hashCode += getIndicaOperacao().hashCode();
        }
        if (getDadosVendaDigitada() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosVendaDigitada());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosVendaDigitada(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HabilitarDesabilitarVendaDigitadaRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">habilitarDesabilitarVendaDigitadaRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicaOperacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "indicaOperacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosVendaDigitada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosVendaDigitada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "VendaDigitadaType"));
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "vendaDigitada"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
