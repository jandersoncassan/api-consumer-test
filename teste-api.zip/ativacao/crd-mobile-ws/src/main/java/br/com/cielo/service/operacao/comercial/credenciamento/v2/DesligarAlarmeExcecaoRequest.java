/**
 * DesligarAlarmeExcecaoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class DesligarAlarmeExcecaoRequest  implements java.io.Serializable {
    /* CorrelationId do COI (numero da instancia do processo) */
    private java.lang.String identificadorIncidente;

    /* CorrelationId do CRD que e enviado na fila de entrada do COI
     * ou numero da proposta. */
    private java.lang.String identificadorProcessoCredenciamento;

    private java.lang.String servicoOperacaoOrigem;

    private java.lang.String sistemaProvedor;

    public DesligarAlarmeExcecaoRequest() {
    }

    public DesligarAlarmeExcecaoRequest(
           java.lang.String identificadorIncidente,
           java.lang.String identificadorProcessoCredenciamento,
           java.lang.String servicoOperacaoOrigem,
           java.lang.String sistemaProvedor) {
           this.identificadorIncidente = identificadorIncidente;
           this.identificadorProcessoCredenciamento = identificadorProcessoCredenciamento;
           this.servicoOperacaoOrigem = servicoOperacaoOrigem;
           this.sistemaProvedor = sistemaProvedor;
    }


    /**
     * Gets the identificadorIncidente value for this DesligarAlarmeExcecaoRequest.
     * 
     * @return identificadorIncidente   * CorrelationId do COI (numero da instancia do processo)
     */
    public java.lang.String getIdentificadorIncidente() {
        return identificadorIncidente;
    }


    /**
     * Sets the identificadorIncidente value for this DesligarAlarmeExcecaoRequest.
     * 
     * @param identificadorIncidente   * CorrelationId do COI (numero da instancia do processo)
     */
    public void setIdentificadorIncidente(java.lang.String identificadorIncidente) {
        this.identificadorIncidente = identificadorIncidente;
    }


    /**
     * Gets the identificadorProcessoCredenciamento value for this DesligarAlarmeExcecaoRequest.
     * 
     * @return identificadorProcessoCredenciamento   * CorrelationId do CRD que e enviado na fila de entrada do COI
     * ou numero da proposta.
     */
    public java.lang.String getIdentificadorProcessoCredenciamento() {
        return identificadorProcessoCredenciamento;
    }


    /**
     * Sets the identificadorProcessoCredenciamento value for this DesligarAlarmeExcecaoRequest.
     * 
     * @param identificadorProcessoCredenciamento   * CorrelationId do CRD que e enviado na fila de entrada do COI
     * ou numero da proposta.
     */
    public void setIdentificadorProcessoCredenciamento(java.lang.String identificadorProcessoCredenciamento) {
        this.identificadorProcessoCredenciamento = identificadorProcessoCredenciamento;
    }


    /**
     * Gets the servicoOperacaoOrigem value for this DesligarAlarmeExcecaoRequest.
     * 
     * @return servicoOperacaoOrigem
     */
    public java.lang.String getServicoOperacaoOrigem() {
        return servicoOperacaoOrigem;
    }


    /**
     * Sets the servicoOperacaoOrigem value for this DesligarAlarmeExcecaoRequest.
     * 
     * @param servicoOperacaoOrigem
     */
    public void setServicoOperacaoOrigem(java.lang.String servicoOperacaoOrigem) {
        this.servicoOperacaoOrigem = servicoOperacaoOrigem;
    }


    /**
     * Gets the sistemaProvedor value for this DesligarAlarmeExcecaoRequest.
     * 
     * @return sistemaProvedor
     */
    public java.lang.String getSistemaProvedor() {
        return sistemaProvedor;
    }


    /**
     * Sets the sistemaProvedor value for this DesligarAlarmeExcecaoRequest.
     * 
     * @param sistemaProvedor
     */
    public void setSistemaProvedor(java.lang.String sistemaProvedor) {
        this.sistemaProvedor = sistemaProvedor;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DesligarAlarmeExcecaoRequest)) return false;
        DesligarAlarmeExcecaoRequest other = (DesligarAlarmeExcecaoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.identificadorIncidente==null && other.getIdentificadorIncidente()==null) || 
             (this.identificadorIncidente!=null &&
              this.identificadorIncidente.equals(other.getIdentificadorIncidente()))) &&
            ((this.identificadorProcessoCredenciamento==null && other.getIdentificadorProcessoCredenciamento()==null) || 
             (this.identificadorProcessoCredenciamento!=null &&
              this.identificadorProcessoCredenciamento.equals(other.getIdentificadorProcessoCredenciamento()))) &&
            ((this.servicoOperacaoOrigem==null && other.getServicoOperacaoOrigem()==null) || 
             (this.servicoOperacaoOrigem!=null &&
              this.servicoOperacaoOrigem.equals(other.getServicoOperacaoOrigem()))) &&
            ((this.sistemaProvedor==null && other.getSistemaProvedor()==null) || 
             (this.sistemaProvedor!=null &&
              this.sistemaProvedor.equals(other.getSistemaProvedor())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdentificadorIncidente() != null) {
            _hashCode += getIdentificadorIncidente().hashCode();
        }
        if (getIdentificadorProcessoCredenciamento() != null) {
            _hashCode += getIdentificadorProcessoCredenciamento().hashCode();
        }
        if (getServicoOperacaoOrigem() != null) {
            _hashCode += getServicoOperacaoOrigem().hashCode();
        }
        if (getSistemaProvedor() != null) {
            _hashCode += getSistemaProvedor().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DesligarAlarmeExcecaoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">desligarAlarmeExcecaoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identificadorIncidente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "identificadorIncidente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identificadorProcessoCredenciamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "identificadorProcessoCredenciamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("servicoOperacaoOrigem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "servicoOperacaoOrigem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sistemaProvedor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "sistemaProvedor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
