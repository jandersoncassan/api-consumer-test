/**
 * LojaFisica.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;


/**
 * Características da loja física onde é realizado o atendimento aos
 * clientes do estabelecimento comercial.
 */
public class LojaFisica  implements java.io.Serializable {
    /* Quantidade de mesas disponíveis na loja física para que os
     * clientes do estabelecimento comercial possam realizar as refeições. */
    private java.math.BigInteger quantidadeMesa;

    /* Quantidade de assentos disponíveis na loja física para que
     * os clientes do estabelecimento comercial possam realizar as refeições. */
    private java.math.BigInteger quantidadeAssento;

    /* Quantidade máxima de refeições por dia que o estabelecimento
     * comercial consegue fornecer nesta loja física. */
    private java.math.BigInteger quantidadeMaximaRefeicao;

    /* Valor, em metros quadrado, da área destinado ao atendimento
     * ao público que frequenta a loja física do estabelecimento comercial. */
    private java.math.BigInteger valorAreaAtendimentoPublico;

    public LojaFisica() {
    }

    public LojaFisica(
           java.math.BigInteger quantidadeMesa,
           java.math.BigInteger quantidadeAssento,
           java.math.BigInteger quantidadeMaximaRefeicao,
           java.math.BigInteger valorAreaAtendimentoPublico) {
           this.quantidadeMesa = quantidadeMesa;
           this.quantidadeAssento = quantidadeAssento;
           this.quantidadeMaximaRefeicao = quantidadeMaximaRefeicao;
           this.valorAreaAtendimentoPublico = valorAreaAtendimentoPublico;
    }


    /**
     * Gets the quantidadeMesa value for this LojaFisica.
     * 
     * @return quantidadeMesa   * Quantidade de mesas disponíveis na loja física para que os
     * clientes do estabelecimento comercial possam realizar as refeições.
     */
    public java.math.BigInteger getQuantidadeMesa() {
        return quantidadeMesa;
    }


    /**
     * Sets the quantidadeMesa value for this LojaFisica.
     * 
     * @param quantidadeMesa   * Quantidade de mesas disponíveis na loja física para que os
     * clientes do estabelecimento comercial possam realizar as refeições.
     */
    public void setQuantidadeMesa(java.math.BigInteger quantidadeMesa) {
        this.quantidadeMesa = quantidadeMesa;
    }


    /**
     * Gets the quantidadeAssento value for this LojaFisica.
     * 
     * @return quantidadeAssento   * Quantidade de assentos disponíveis na loja física para que
     * os clientes do estabelecimento comercial possam realizar as refeições.
     */
    public java.math.BigInteger getQuantidadeAssento() {
        return quantidadeAssento;
    }


    /**
     * Sets the quantidadeAssento value for this LojaFisica.
     * 
     * @param quantidadeAssento   * Quantidade de assentos disponíveis na loja física para que
     * os clientes do estabelecimento comercial possam realizar as refeições.
     */
    public void setQuantidadeAssento(java.math.BigInteger quantidadeAssento) {
        this.quantidadeAssento = quantidadeAssento;
    }


    /**
     * Gets the quantidadeMaximaRefeicao value for this LojaFisica.
     * 
     * @return quantidadeMaximaRefeicao   * Quantidade máxima de refeições por dia que o estabelecimento
     * comercial consegue fornecer nesta loja física.
     */
    public java.math.BigInteger getQuantidadeMaximaRefeicao() {
        return quantidadeMaximaRefeicao;
    }


    /**
     * Sets the quantidadeMaximaRefeicao value for this LojaFisica.
     * 
     * @param quantidadeMaximaRefeicao   * Quantidade máxima de refeições por dia que o estabelecimento
     * comercial consegue fornecer nesta loja física.
     */
    public void setQuantidadeMaximaRefeicao(java.math.BigInteger quantidadeMaximaRefeicao) {
        this.quantidadeMaximaRefeicao = quantidadeMaximaRefeicao;
    }


    /**
     * Gets the valorAreaAtendimentoPublico value for this LojaFisica.
     * 
     * @return valorAreaAtendimentoPublico   * Valor, em metros quadrado, da área destinado ao atendimento
     * ao público que frequenta a loja física do estabelecimento comercial.
     */
    public java.math.BigInteger getValorAreaAtendimentoPublico() {
        return valorAreaAtendimentoPublico;
    }


    /**
     * Sets the valorAreaAtendimentoPublico value for this LojaFisica.
     * 
     * @param valorAreaAtendimentoPublico   * Valor, em metros quadrado, da área destinado ao atendimento
     * ao público que frequenta a loja física do estabelecimento comercial.
     */
    public void setValorAreaAtendimentoPublico(java.math.BigInteger valorAreaAtendimentoPublico) {
        this.valorAreaAtendimentoPublico = valorAreaAtendimentoPublico;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LojaFisica)) return false;
        LojaFisica other = (LojaFisica) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.quantidadeMesa==null && other.getQuantidadeMesa()==null) || 
             (this.quantidadeMesa!=null &&
              this.quantidadeMesa.equals(other.getQuantidadeMesa()))) &&
            ((this.quantidadeAssento==null && other.getQuantidadeAssento()==null) || 
             (this.quantidadeAssento!=null &&
              this.quantidadeAssento.equals(other.getQuantidadeAssento()))) &&
            ((this.quantidadeMaximaRefeicao==null && other.getQuantidadeMaximaRefeicao()==null) || 
             (this.quantidadeMaximaRefeicao!=null &&
              this.quantidadeMaximaRefeicao.equals(other.getQuantidadeMaximaRefeicao()))) &&
            ((this.valorAreaAtendimentoPublico==null && other.getValorAreaAtendimentoPublico()==null) || 
             (this.valorAreaAtendimentoPublico!=null &&
              this.valorAreaAtendimentoPublico.equals(other.getValorAreaAtendimentoPublico())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getQuantidadeMesa() != null) {
            _hashCode += getQuantidadeMesa().hashCode();
        }
        if (getQuantidadeAssento() != null) {
            _hashCode += getQuantidadeAssento().hashCode();
        }
        if (getQuantidadeMaximaRefeicao() != null) {
            _hashCode += getQuantidadeMaximaRefeicao().hashCode();
        }
        if (getValorAreaAtendimentoPublico() != null) {
            _hashCode += getValorAreaAtendimentoPublico().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LojaFisica.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "LojaFisica"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeMesa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeMesa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeAssento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeAssento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeMaximaRefeicao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeMaximaRefeicao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorAreaAtendimentoPublico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "valorAreaAtendimentoPublico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
