/**
 * DadosTipoEstabelecimentoVVAType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class DadosTipoEstabelecimentoVVAType  implements java.io.Serializable {
    /* Açougue */
    private java.lang.Boolean acougue;

    /* Armazém */
    private java.lang.Boolean armazem;

    /* Hipermercado */
    private java.lang.Boolean hipermercado;

    /* Hortimercado */
    private java.lang.Boolean hortimercado;

    /* Laticínio-Frios */
    private java.lang.Boolean laticinioFrios;

    /* Mercearia */
    private java.lang.Boolean mercearia;

    /* Peixaria */
    private java.lang.Boolean peixaria;

    /* Supermercado */
    private java.lang.Boolean supermercado;

    public DadosTipoEstabelecimentoVVAType() {
    }

    public DadosTipoEstabelecimentoVVAType(
           java.lang.Boolean acougue,
           java.lang.Boolean armazem,
           java.lang.Boolean hipermercado,
           java.lang.Boolean hortimercado,
           java.lang.Boolean laticinioFrios,
           java.lang.Boolean mercearia,
           java.lang.Boolean peixaria,
           java.lang.Boolean supermercado) {
           this.acougue = acougue;
           this.armazem = armazem;
           this.hipermercado = hipermercado;
           this.hortimercado = hortimercado;
           this.laticinioFrios = laticinioFrios;
           this.mercearia = mercearia;
           this.peixaria = peixaria;
           this.supermercado = supermercado;
    }


    /**
     * Gets the acougue value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return acougue   * Açougue
     */
    public java.lang.Boolean getAcougue() {
        return acougue;
    }


    /**
     * Sets the acougue value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param acougue   * Açougue
     */
    public void setAcougue(java.lang.Boolean acougue) {
        this.acougue = acougue;
    }


    /**
     * Gets the armazem value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return armazem   * Armazém
     */
    public java.lang.Boolean getArmazem() {
        return armazem;
    }


    /**
     * Sets the armazem value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param armazem   * Armazém
     */
    public void setArmazem(java.lang.Boolean armazem) {
        this.armazem = armazem;
    }


    /**
     * Gets the hipermercado value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return hipermercado   * Hipermercado
     */
    public java.lang.Boolean getHipermercado() {
        return hipermercado;
    }


    /**
     * Sets the hipermercado value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param hipermercado   * Hipermercado
     */
    public void setHipermercado(java.lang.Boolean hipermercado) {
        this.hipermercado = hipermercado;
    }


    /**
     * Gets the hortimercado value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return hortimercado   * Hortimercado
     */
    public java.lang.Boolean getHortimercado() {
        return hortimercado;
    }


    /**
     * Sets the hortimercado value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param hortimercado   * Hortimercado
     */
    public void setHortimercado(java.lang.Boolean hortimercado) {
        this.hortimercado = hortimercado;
    }


    /**
     * Gets the laticinioFrios value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return laticinioFrios   * Laticínio-Frios
     */
    public java.lang.Boolean getLaticinioFrios() {
        return laticinioFrios;
    }


    /**
     * Sets the laticinioFrios value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param laticinioFrios   * Laticínio-Frios
     */
    public void setLaticinioFrios(java.lang.Boolean laticinioFrios) {
        this.laticinioFrios = laticinioFrios;
    }


    /**
     * Gets the mercearia value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return mercearia   * Mercearia
     */
    public java.lang.Boolean getMercearia() {
        return mercearia;
    }


    /**
     * Sets the mercearia value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param mercearia   * Mercearia
     */
    public void setMercearia(java.lang.Boolean mercearia) {
        this.mercearia = mercearia;
    }


    /**
     * Gets the peixaria value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return peixaria   * Peixaria
     */
    public java.lang.Boolean getPeixaria() {
        return peixaria;
    }


    /**
     * Sets the peixaria value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param peixaria   * Peixaria
     */
    public void setPeixaria(java.lang.Boolean peixaria) {
        this.peixaria = peixaria;
    }


    /**
     * Gets the supermercado value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @return supermercado   * Supermercado
     */
    public java.lang.Boolean getSupermercado() {
        return supermercado;
    }


    /**
     * Sets the supermercado value for this DadosTipoEstabelecimentoVVAType.
     * 
     * @param supermercado   * Supermercado
     */
    public void setSupermercado(java.lang.Boolean supermercado) {
        this.supermercado = supermercado;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosTipoEstabelecimentoVVAType)) return false;
        DadosTipoEstabelecimentoVVAType other = (DadosTipoEstabelecimentoVVAType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.acougue==null && other.getAcougue()==null) || 
             (this.acougue!=null &&
              this.acougue.equals(other.getAcougue()))) &&
            ((this.armazem==null && other.getArmazem()==null) || 
             (this.armazem!=null &&
              this.armazem.equals(other.getArmazem()))) &&
            ((this.hipermercado==null && other.getHipermercado()==null) || 
             (this.hipermercado!=null &&
              this.hipermercado.equals(other.getHipermercado()))) &&
            ((this.hortimercado==null && other.getHortimercado()==null) || 
             (this.hortimercado!=null &&
              this.hortimercado.equals(other.getHortimercado()))) &&
            ((this.laticinioFrios==null && other.getLaticinioFrios()==null) || 
             (this.laticinioFrios!=null &&
              this.laticinioFrios.equals(other.getLaticinioFrios()))) &&
            ((this.mercearia==null && other.getMercearia()==null) || 
             (this.mercearia!=null &&
              this.mercearia.equals(other.getMercearia()))) &&
            ((this.peixaria==null && other.getPeixaria()==null) || 
             (this.peixaria!=null &&
              this.peixaria.equals(other.getPeixaria()))) &&
            ((this.supermercado==null && other.getSupermercado()==null) || 
             (this.supermercado!=null &&
              this.supermercado.equals(other.getSupermercado())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getAcougue() != null) {
            _hashCode += getAcougue().hashCode();
        }
        if (getArmazem() != null) {
            _hashCode += getArmazem().hashCode();
        }
        if (getHipermercado() != null) {
            _hashCode += getHipermercado().hashCode();
        }
        if (getHortimercado() != null) {
            _hashCode += getHortimercado().hashCode();
        }
        if (getLaticinioFrios() != null) {
            _hashCode += getLaticinioFrios().hashCode();
        }
        if (getMercearia() != null) {
            _hashCode += getMercearia().hashCode();
        }
        if (getPeixaria() != null) {
            _hashCode += getPeixaria().hashCode();
        }
        if (getSupermercado() != null) {
            _hashCode += getSupermercado().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosTipoEstabelecimentoVVAType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosTipoEstabelecimentoVVAType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("acougue");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "acougue"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("armazem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "armazem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hipermercado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "hipermercado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("hortimercado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "hortimercado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("laticinioFrios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "laticinioFrios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mercearia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "mercearia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("peixaria");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "peixaria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("supermercado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "supermercado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
