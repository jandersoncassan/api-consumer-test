/**
 * NotificarInstalacaoEquipamentoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.logistica.equipamento.v4;

public class NotificarInstalacaoEquipamentoRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o Cliente */
    private long codigoCliente;

    private java.lang.String canalSolicitante;

    /* descricao da solucao captura perante ao evento */
    private java.lang.String descricaoSolucaoCaptura;

    private java.lang.String numeroLogico;

    public NotificarInstalacaoEquipamentoRequest() {
    }

    public NotificarInstalacaoEquipamentoRequest(
           long codigoCliente,
           java.lang.String canalSolicitante,
           java.lang.String descricaoSolucaoCaptura,
           java.lang.String numeroLogico) {
           this.codigoCliente = codigoCliente;
           this.canalSolicitante = canalSolicitante;
           this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
           this.numeroLogico = numeroLogico;
    }


    /**
     * Gets the codigoCliente value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o Cliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the canalSolicitante value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @return canalSolicitante
     */
    public java.lang.String getCanalSolicitante() {
        return canalSolicitante;
    }


    /**
     * Sets the canalSolicitante value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @param canalSolicitante
     */
    public void setCanalSolicitante(java.lang.String canalSolicitante) {
        this.canalSolicitante = canalSolicitante;
    }


    /**
     * Gets the descricaoSolucaoCaptura value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @return descricaoSolucaoCaptura   * descricao da solucao captura perante ao evento
     */
    public java.lang.String getDescricaoSolucaoCaptura() {
        return descricaoSolucaoCaptura;
    }


    /**
     * Sets the descricaoSolucaoCaptura value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @param descricaoSolucaoCaptura   * descricao da solucao captura perante ao evento
     */
    public void setDescricaoSolucaoCaptura(java.lang.String descricaoSolucaoCaptura) {
        this.descricaoSolucaoCaptura = descricaoSolucaoCaptura;
    }


    /**
     * Gets the numeroLogico value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @return numeroLogico
     */
    public java.lang.String getNumeroLogico() {
        return numeroLogico;
    }


    /**
     * Sets the numeroLogico value for this NotificarInstalacaoEquipamentoRequest.
     * 
     * @param numeroLogico
     */
    public void setNumeroLogico(java.lang.String numeroLogico) {
        this.numeroLogico = numeroLogico;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof NotificarInstalacaoEquipamentoRequest)) return false;
        NotificarInstalacaoEquipamentoRequest other = (NotificarInstalacaoEquipamentoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.canalSolicitante==null && other.getCanalSolicitante()==null) || 
             (this.canalSolicitante!=null &&
              this.canalSolicitante.equals(other.getCanalSolicitante()))) &&
            ((this.descricaoSolucaoCaptura==null && other.getDescricaoSolucaoCaptura()==null) || 
             (this.descricaoSolucaoCaptura!=null &&
              this.descricaoSolucaoCaptura.equals(other.getDescricaoSolucaoCaptura()))) &&
            ((this.numeroLogico==null && other.getNumeroLogico()==null) || 
             (this.numeroLogico!=null &&
              this.numeroLogico.equals(other.getNumeroLogico())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getCanalSolicitante() != null) {
            _hashCode += getCanalSolicitante().hashCode();
        }
        if (getDescricaoSolucaoCaptura() != null) {
            _hashCode += getDescricaoSolucaoCaptura().hashCode();
        }
        if (getNumeroLogico() != null) {
            _hashCode += getNumeroLogico().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(NotificarInstalacaoEquipamentoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", ">notificarInstalacaoEquipamentoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("canalSolicitante");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "canalSolicitante"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "descricaoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/logistica/equipamento/v4", "numeroLogico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
