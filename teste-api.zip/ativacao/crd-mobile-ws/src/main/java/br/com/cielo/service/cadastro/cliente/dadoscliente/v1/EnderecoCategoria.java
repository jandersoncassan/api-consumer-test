/**
 * EnderecoCategoria.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;

public class EnderecoCategoria  implements java.io.Serializable {
    private java.lang.String categoriaEndereco;

    private java.lang.String contatoEndereco;

    private java.lang.String numeroTelefoneContratado;

    public EnderecoCategoria() {
    }

    public EnderecoCategoria(
           java.lang.String categoriaEndereco,
           java.lang.String contatoEndereco,
           java.lang.String numeroTelefoneContratado) {
           this.categoriaEndereco = categoriaEndereco;
           this.contatoEndereco = contatoEndereco;
           this.numeroTelefoneContratado = numeroTelefoneContratado;
    }


    /**
     * Gets the categoriaEndereco value for this EnderecoCategoria.
     * 
     * @return categoriaEndereco
     */
    public java.lang.String getCategoriaEndereco() {
        return categoriaEndereco;
    }


    /**
     * Sets the categoriaEndereco value for this EnderecoCategoria.
     * 
     * @param categoriaEndereco
     */
    public void setCategoriaEndereco(java.lang.String categoriaEndereco) {
        this.categoriaEndereco = categoriaEndereco;
    }


    /**
     * Gets the contatoEndereco value for this EnderecoCategoria.
     * 
     * @return contatoEndereco
     */
    public java.lang.String getContatoEndereco() {
        return contatoEndereco;
    }


    /**
     * Sets the contatoEndereco value for this EnderecoCategoria.
     * 
     * @param contatoEndereco
     */
    public void setContatoEndereco(java.lang.String contatoEndereco) {
        this.contatoEndereco = contatoEndereco;
    }


    /**
     * Gets the numeroTelefoneContratado value for this EnderecoCategoria.
     * 
     * @return numeroTelefoneContratado
     */
    public java.lang.String getNumeroTelefoneContratado() {
        return numeroTelefoneContratado;
    }


    /**
     * Sets the numeroTelefoneContratado value for this EnderecoCategoria.
     * 
     * @param numeroTelefoneContratado
     */
    public void setNumeroTelefoneContratado(java.lang.String numeroTelefoneContratado) {
        this.numeroTelefoneContratado = numeroTelefoneContratado;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EnderecoCategoria)) return false;
        EnderecoCategoria other = (EnderecoCategoria) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.categoriaEndereco==null && other.getCategoriaEndereco()==null) || 
             (this.categoriaEndereco!=null &&
              this.categoriaEndereco.equals(other.getCategoriaEndereco()))) &&
            ((this.contatoEndereco==null && other.getContatoEndereco()==null) || 
             (this.contatoEndereco!=null &&
              this.contatoEndereco.equals(other.getContatoEndereco()))) &&
            ((this.numeroTelefoneContratado==null && other.getNumeroTelefoneContratado()==null) || 
             (this.numeroTelefoneContratado!=null &&
              this.numeroTelefoneContratado.equals(other.getNumeroTelefoneContratado())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCategoriaEndereco() != null) {
            _hashCode += getCategoriaEndereco().hashCode();
        }
        if (getContatoEndereco() != null) {
            _hashCode += getContatoEndereco().hashCode();
        }
        if (getNumeroTelefoneContratado() != null) {
            _hashCode += getNumeroTelefoneContratado().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EnderecoCategoria.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "EnderecoCategoria"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("categoriaEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "categoriaEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("contatoEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "contatoEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefoneContratado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v1", "numeroTelefoneContratado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
