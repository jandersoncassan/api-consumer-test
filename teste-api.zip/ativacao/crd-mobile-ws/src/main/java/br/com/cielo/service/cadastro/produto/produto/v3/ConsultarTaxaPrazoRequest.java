/**
 * ConsultarTaxaPrazoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarTaxaPrazoRequest  implements java.io.Serializable {
    /* MCC (Ramo de atividade do estabelecimento) */
    private java.lang.String codigoRamoAtividade;

    /* Indicador que demonstra se a pessoa a ser
     * 							credenciada e do tipo Microempreendedora Individual. */
    private br.com.cielo.service.cadastro.produto.produto.v3.ConsultarTaxaPrazoRequestIndicadorMicroEmpreendedorIndividual indicadorMicroEmpreendedorIndividual;

    /* Grupo de solução de captura (POS / TEF / MOBILE) */
    private java.math.BigInteger grupoSolucaoCaptura;

    /* Produtos que serao consultados */
    private br.com.cielo.service.cadastro.produto.produto.v3.ProdutoConsultarTaxaPrazoRequestType[] produtos;

    private java.lang.String proximoRegistro;  // attribute

    private java.lang.String chavePaginacao;  // attribute

    public ConsultarTaxaPrazoRequest() {
    }

    public ConsultarTaxaPrazoRequest(
           java.lang.String codigoRamoAtividade,
           br.com.cielo.service.cadastro.produto.produto.v3.ConsultarTaxaPrazoRequestIndicadorMicroEmpreendedorIndividual indicadorMicroEmpreendedorIndividual,
           java.math.BigInteger grupoSolucaoCaptura,
           br.com.cielo.service.cadastro.produto.produto.v3.ProdutoConsultarTaxaPrazoRequestType[] produtos,
           java.lang.String proximoRegistro,
           java.lang.String chavePaginacao) {
           this.codigoRamoAtividade = codigoRamoAtividade;
           this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
           this.grupoSolucaoCaptura = grupoSolucaoCaptura;
           this.produtos = produtos;
           this.proximoRegistro = proximoRegistro;
           this.chavePaginacao = chavePaginacao;
    }


    /**
     * Gets the codigoRamoAtividade value for this ConsultarTaxaPrazoRequest.
     * 
     * @return codigoRamoAtividade   * MCC (Ramo de atividade do estabelecimento)
     */
    public java.lang.String getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this ConsultarTaxaPrazoRequest.
     * 
     * @param codigoRamoAtividade   * MCC (Ramo de atividade do estabelecimento)
     */
    public void setCodigoRamoAtividade(java.lang.String codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the indicadorMicroEmpreendedorIndividual value for this ConsultarTaxaPrazoRequest.
     * 
     * @return indicadorMicroEmpreendedorIndividual   * Indicador que demonstra se a pessoa a ser
     * 							credenciada e do tipo Microempreendedora Individual.
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.ConsultarTaxaPrazoRequestIndicadorMicroEmpreendedorIndividual getIndicadorMicroEmpreendedorIndividual() {
        return indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Sets the indicadorMicroEmpreendedorIndividual value for this ConsultarTaxaPrazoRequest.
     * 
     * @param indicadorMicroEmpreendedorIndividual   * Indicador que demonstra se a pessoa a ser
     * 							credenciada e do tipo Microempreendedora Individual.
     */
    public void setIndicadorMicroEmpreendedorIndividual(br.com.cielo.service.cadastro.produto.produto.v3.ConsultarTaxaPrazoRequestIndicadorMicroEmpreendedorIndividual indicadorMicroEmpreendedorIndividual) {
        this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Gets the grupoSolucaoCaptura value for this ConsultarTaxaPrazoRequest.
     * 
     * @return grupoSolucaoCaptura   * Grupo de solução de captura (POS / TEF / MOBILE)
     */
    public java.math.BigInteger getGrupoSolucaoCaptura() {
        return grupoSolucaoCaptura;
    }


    /**
     * Sets the grupoSolucaoCaptura value for this ConsultarTaxaPrazoRequest.
     * 
     * @param grupoSolucaoCaptura   * Grupo de solução de captura (POS / TEF / MOBILE)
     */
    public void setGrupoSolucaoCaptura(java.math.BigInteger grupoSolucaoCaptura) {
        this.grupoSolucaoCaptura = grupoSolucaoCaptura;
    }


    /**
     * Gets the produtos value for this ConsultarTaxaPrazoRequest.
     * 
     * @return produtos   * Produtos que serao consultados
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.ProdutoConsultarTaxaPrazoRequestType[] getProdutos() {
        return produtos;
    }


    /**
     * Sets the produtos value for this ConsultarTaxaPrazoRequest.
     * 
     * @param produtos   * Produtos que serao consultados
     */
    public void setProdutos(br.com.cielo.service.cadastro.produto.produto.v3.ProdutoConsultarTaxaPrazoRequestType[] produtos) {
        this.produtos = produtos;
    }


    /**
     * Gets the proximoRegistro value for this ConsultarTaxaPrazoRequest.
     * 
     * @return proximoRegistro
     */
    public java.lang.String getProximoRegistro() {
        return proximoRegistro;
    }


    /**
     * Sets the proximoRegistro value for this ConsultarTaxaPrazoRequest.
     * 
     * @param proximoRegistro
     */
    public void setProximoRegistro(java.lang.String proximoRegistro) {
        this.proximoRegistro = proximoRegistro;
    }


    /**
     * Gets the chavePaginacao value for this ConsultarTaxaPrazoRequest.
     * 
     * @return chavePaginacao
     */
    public java.lang.String getChavePaginacao() {
        return chavePaginacao;
    }


    /**
     * Sets the chavePaginacao value for this ConsultarTaxaPrazoRequest.
     * 
     * @param chavePaginacao
     */
    public void setChavePaginacao(java.lang.String chavePaginacao) {
        this.chavePaginacao = chavePaginacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarTaxaPrazoRequest)) return false;
        ConsultarTaxaPrazoRequest other = (ConsultarTaxaPrazoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade()))) &&
            ((this.indicadorMicroEmpreendedorIndividual==null && other.getIndicadorMicroEmpreendedorIndividual()==null) || 
             (this.indicadorMicroEmpreendedorIndividual!=null &&
              this.indicadorMicroEmpreendedorIndividual.equals(other.getIndicadorMicroEmpreendedorIndividual()))) &&
            ((this.grupoSolucaoCaptura==null && other.getGrupoSolucaoCaptura()==null) || 
             (this.grupoSolucaoCaptura!=null &&
              this.grupoSolucaoCaptura.equals(other.getGrupoSolucaoCaptura()))) &&
            ((this.produtos==null && other.getProdutos()==null) || 
             (this.produtos!=null &&
              java.util.Arrays.equals(this.produtos, other.getProdutos()))) &&
            ((this.proximoRegistro==null && other.getProximoRegistro()==null) || 
             (this.proximoRegistro!=null &&
              this.proximoRegistro.equals(other.getProximoRegistro()))) &&
            ((this.chavePaginacao==null && other.getChavePaginacao()==null) || 
             (this.chavePaginacao!=null &&
              this.chavePaginacao.equals(other.getChavePaginacao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        if (getIndicadorMicroEmpreendedorIndividual() != null) {
            _hashCode += getIndicadorMicroEmpreendedorIndividual().hashCode();
        }
        if (getGrupoSolucaoCaptura() != null) {
            _hashCode += getGrupoSolucaoCaptura().hashCode();
        }
        if (getProdutos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProdutos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProdutos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProximoRegistro() != null) {
            _hashCode += getProximoRegistro().hashCode();
        }
        if (getChavePaginacao() != null) {
            _hashCode += getChavePaginacao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarTaxaPrazoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarTaxaPrazoRequest"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("proximoRegistro");
        attrField.setXmlName(new javax.xml.namespace.QName("", "proximoRegistro"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("chavePaginacao");
        attrField.setXmlName(new javax.xml.namespace.QName("", "chavePaginacao"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMicroEmpreendedorIndividual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "indicadorMicroEmpreendedorIndividual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">>consultarTaxaPrazoRequest>indicadorMicroEmpreendedorIndividual"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grupoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "grupoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produtos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ProdutoConsultarTaxaPrazoRequestType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produto"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
