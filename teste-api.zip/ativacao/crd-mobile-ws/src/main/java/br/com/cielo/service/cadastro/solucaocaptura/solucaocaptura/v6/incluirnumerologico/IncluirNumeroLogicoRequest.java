/**
 * IncluirNumeroLogicoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico;

public class IncluirNumeroLogicoRequest  implements java.io.Serializable {
    private long codigoCliente;

    private java.lang.String tipoTerminal;

    private java.lang.String grupoSolucaoCaptura;

    private java.lang.String sistemaOrigem;

    public IncluirNumeroLogicoRequest() {
    }

    public IncluirNumeroLogicoRequest(
           long codigoCliente,
           java.lang.String tipoTerminal,
           java.lang.String grupoSolucaoCaptura,
           java.lang.String sistemaOrigem) {
           this.codigoCliente = codigoCliente;
           this.tipoTerminal = tipoTerminal;
           this.grupoSolucaoCaptura = grupoSolucaoCaptura;
           this.sistemaOrigem = sistemaOrigem;
    }


    /**
     * Gets the codigoCliente value for this IncluirNumeroLogicoRequest.
     * 
     * @return codigoCliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this IncluirNumeroLogicoRequest.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the tipoTerminal value for this IncluirNumeroLogicoRequest.
     * 
     * @return tipoTerminal
     */
    public java.lang.String getTipoTerminal() {
        return tipoTerminal;
    }


    /**
     * Sets the tipoTerminal value for this IncluirNumeroLogicoRequest.
     * 
     * @param tipoTerminal
     */
    public void setTipoTerminal(java.lang.String tipoTerminal) {
        this.tipoTerminal = tipoTerminal;
    }


    /**
     * Gets the grupoSolucaoCaptura value for this IncluirNumeroLogicoRequest.
     * 
     * @return grupoSolucaoCaptura
     */
    public java.lang.String getGrupoSolucaoCaptura() {
        return grupoSolucaoCaptura;
    }


    /**
     * Sets the grupoSolucaoCaptura value for this IncluirNumeroLogicoRequest.
     * 
     * @param grupoSolucaoCaptura
     */
    public void setGrupoSolucaoCaptura(java.lang.String grupoSolucaoCaptura) {
        this.grupoSolucaoCaptura = grupoSolucaoCaptura;
    }


    /**
     * Gets the sistemaOrigem value for this IncluirNumeroLogicoRequest.
     * 
     * @return sistemaOrigem
     */
    public java.lang.String getSistemaOrigem() {
        return sistemaOrigem;
    }


    /**
     * Sets the sistemaOrigem value for this IncluirNumeroLogicoRequest.
     * 
     * @param sistemaOrigem
     */
    public void setSistemaOrigem(java.lang.String sistemaOrigem) {
        this.sistemaOrigem = sistemaOrigem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IncluirNumeroLogicoRequest)) return false;
        IncluirNumeroLogicoRequest other = (IncluirNumeroLogicoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.tipoTerminal==null && other.getTipoTerminal()==null) || 
             (this.tipoTerminal!=null &&
              this.tipoTerminal.equals(other.getTipoTerminal()))) &&
            ((this.grupoSolucaoCaptura==null && other.getGrupoSolucaoCaptura()==null) || 
             (this.grupoSolucaoCaptura!=null &&
              this.grupoSolucaoCaptura.equals(other.getGrupoSolucaoCaptura()))) &&
            ((this.sistemaOrigem==null && other.getSistemaOrigem()==null) || 
             (this.sistemaOrigem!=null &&
              this.sistemaOrigem.equals(other.getSistemaOrigem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getTipoTerminal() != null) {
            _hashCode += getTipoTerminal().hashCode();
        }
        if (getGrupoSolucaoCaptura() != null) {
            _hashCode += getGrupoSolucaoCaptura().hashCode();
        }
        if (getSistemaOrigem() != null) {
            _hashCode += getSistemaOrigem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IncluirNumeroLogicoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", ">IncluirNumeroLogicoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "tipoTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grupoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "grupoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sistemaOrigem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "sistemaOrigem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
