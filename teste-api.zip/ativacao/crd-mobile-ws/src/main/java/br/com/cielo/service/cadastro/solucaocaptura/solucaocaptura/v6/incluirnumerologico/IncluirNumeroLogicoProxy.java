package br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico;

public class IncluirNumeroLogicoProxy implements br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_PortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_PortType incluirNumeroLogico_PortType = null;
  
  public IncluirNumeroLogicoProxy() {
    _initIncluirNumeroLogicoProxy();
  }
  
  public IncluirNumeroLogicoProxy(String endpoint) {
    _endpoint = endpoint;
    _initIncluirNumeroLogicoProxy();
  }
  
  private void _initIncluirNumeroLogicoProxy() {
    try {
      incluirNumeroLogico_PortType = (new br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_ServiceLocator()).getIncluirNumeroLogicoSOAP();
      if (incluirNumeroLogico_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)incluirNumeroLogico_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)incluirNumeroLogico_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (incluirNumeroLogico_PortType != null)
      ((javax.xml.rpc.Stub)incluirNumeroLogico_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogico_PortType getIncluirNumeroLogico_PortType() {
    if (incluirNumeroLogico_PortType == null)
      _initIncluirNumeroLogicoProxy();
    return incluirNumeroLogico_PortType;
  }
  
  public br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoResponse incluirNumeroLogico(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico.IncluirNumeroLogicoRequest parameters) throws java.rmi.RemoteException{
    if (incluirNumeroLogico_PortType == null)
      _initIncluirNumeroLogicoProxy();
    return incluirNumeroLogico_PortType.incluirNumeroLogico(header, parameters);
  }
  
  
}