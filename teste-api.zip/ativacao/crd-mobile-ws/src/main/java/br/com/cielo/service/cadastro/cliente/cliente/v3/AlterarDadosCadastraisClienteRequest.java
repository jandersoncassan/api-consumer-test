/**
 * AlterarDadosCadastraisClienteRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class AlterarDadosCadastraisClienteRequest  implements java.io.Serializable {
    private java.lang.String codigoCliente;

    private java.lang.String nomePlaqueta;

    private java.lang.String nomeFantasia;

    private java.lang.String email;

    private java.lang.String numeroDDDTelefoneEstabelecimento;

    private java.lang.String numeroTelefoneEstabelecimento;

    private java.lang.String numeroDDDTelefoneAlternativo;

    private java.lang.String numeroTelefoneAlternativo;

    private java.lang.String tipoEnderecoAlterado;

    private java.lang.String logradouro;

    private java.lang.String complemento;

    private java.lang.String cidade;

    private java.lang.String estado;

    private java.lang.String cep;

    public AlterarDadosCadastraisClienteRequest() {
    }

    public AlterarDadosCadastraisClienteRequest(
           java.lang.String codigoCliente,
           java.lang.String nomePlaqueta,
           java.lang.String nomeFantasia,
           java.lang.String email,
           java.lang.String numeroDDDTelefoneEstabelecimento,
           java.lang.String numeroTelefoneEstabelecimento,
           java.lang.String numeroDDDTelefoneAlternativo,
           java.lang.String numeroTelefoneAlternativo,
           java.lang.String tipoEnderecoAlterado,
           java.lang.String logradouro,
           java.lang.String complemento,
           java.lang.String cidade,
           java.lang.String estado,
           java.lang.String cep) {
           this.codigoCliente = codigoCliente;
           this.nomePlaqueta = nomePlaqueta;
           this.nomeFantasia = nomeFantasia;
           this.email = email;
           this.numeroDDDTelefoneEstabelecimento = numeroDDDTelefoneEstabelecimento;
           this.numeroTelefoneEstabelecimento = numeroTelefoneEstabelecimento;
           this.numeroDDDTelefoneAlternativo = numeroDDDTelefoneAlternativo;
           this.numeroTelefoneAlternativo = numeroTelefoneAlternativo;
           this.tipoEnderecoAlterado = tipoEnderecoAlterado;
           this.logradouro = logradouro;
           this.complemento = complemento;
           this.cidade = cidade;
           this.estado = estado;
           this.cep = cep;
    }


    /**
     * Gets the codigoCliente value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return codigoCliente
     */
    public java.lang.String getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(java.lang.String codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the nomePlaqueta value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return nomePlaqueta
     */
    public java.lang.String getNomePlaqueta() {
        return nomePlaqueta;
    }


    /**
     * Sets the nomePlaqueta value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param nomePlaqueta
     */
    public void setNomePlaqueta(java.lang.String nomePlaqueta) {
        this.nomePlaqueta = nomePlaqueta;
    }


    /**
     * Gets the nomeFantasia value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return nomeFantasia
     */
    public java.lang.String getNomeFantasia() {
        return nomeFantasia;
    }


    /**
     * Sets the nomeFantasia value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param nomeFantasia
     */
    public void setNomeFantasia(java.lang.String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }


    /**
     * Gets the email value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the numeroDDDTelefoneEstabelecimento value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return numeroDDDTelefoneEstabelecimento
     */
    public java.lang.String getNumeroDDDTelefoneEstabelecimento() {
        return numeroDDDTelefoneEstabelecimento;
    }


    /**
     * Sets the numeroDDDTelefoneEstabelecimento value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param numeroDDDTelefoneEstabelecimento
     */
    public void setNumeroDDDTelefoneEstabelecimento(java.lang.String numeroDDDTelefoneEstabelecimento) {
        this.numeroDDDTelefoneEstabelecimento = numeroDDDTelefoneEstabelecimento;
    }


    /**
     * Gets the numeroTelefoneEstabelecimento value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return numeroTelefoneEstabelecimento
     */
    public java.lang.String getNumeroTelefoneEstabelecimento() {
        return numeroTelefoneEstabelecimento;
    }


    /**
     * Sets the numeroTelefoneEstabelecimento value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param numeroTelefoneEstabelecimento
     */
    public void setNumeroTelefoneEstabelecimento(java.lang.String numeroTelefoneEstabelecimento) {
        this.numeroTelefoneEstabelecimento = numeroTelefoneEstabelecimento;
    }


    /**
     * Gets the numeroDDDTelefoneAlternativo value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return numeroDDDTelefoneAlternativo
     */
    public java.lang.String getNumeroDDDTelefoneAlternativo() {
        return numeroDDDTelefoneAlternativo;
    }


    /**
     * Sets the numeroDDDTelefoneAlternativo value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param numeroDDDTelefoneAlternativo
     */
    public void setNumeroDDDTelefoneAlternativo(java.lang.String numeroDDDTelefoneAlternativo) {
        this.numeroDDDTelefoneAlternativo = numeroDDDTelefoneAlternativo;
    }


    /**
     * Gets the numeroTelefoneAlternativo value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return numeroTelefoneAlternativo
     */
    public java.lang.String getNumeroTelefoneAlternativo() {
        return numeroTelefoneAlternativo;
    }


    /**
     * Sets the numeroTelefoneAlternativo value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param numeroTelefoneAlternativo
     */
    public void setNumeroTelefoneAlternativo(java.lang.String numeroTelefoneAlternativo) {
        this.numeroTelefoneAlternativo = numeroTelefoneAlternativo;
    }


    /**
     * Gets the tipoEnderecoAlterado value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return tipoEnderecoAlterado
     */
    public java.lang.String getTipoEnderecoAlterado() {
        return tipoEnderecoAlterado;
    }


    /**
     * Sets the tipoEnderecoAlterado value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param tipoEnderecoAlterado
     */
    public void setTipoEnderecoAlterado(java.lang.String tipoEnderecoAlterado) {
        this.tipoEnderecoAlterado = tipoEnderecoAlterado;
    }


    /**
     * Gets the logradouro value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return logradouro
     */
    public java.lang.String getLogradouro() {
        return logradouro;
    }


    /**
     * Sets the logradouro value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param logradouro
     */
    public void setLogradouro(java.lang.String logradouro) {
        this.logradouro = logradouro;
    }


    /**
     * Gets the complemento value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return complemento
     */
    public java.lang.String getComplemento() {
        return complemento;
    }


    /**
     * Sets the complemento value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param complemento
     */
    public void setComplemento(java.lang.String complemento) {
        this.complemento = complemento;
    }


    /**
     * Gets the cidade value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return cidade
     */
    public java.lang.String getCidade() {
        return cidade;
    }


    /**
     * Sets the cidade value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param cidade
     */
    public void setCidade(java.lang.String cidade) {
        this.cidade = cidade;
    }


    /**
     * Gets the estado value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return estado
     */
    public java.lang.String getEstado() {
        return estado;
    }


    /**
     * Sets the estado value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param estado
     */
    public void setEstado(java.lang.String estado) {
        this.estado = estado;
    }


    /**
     * Gets the cep value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @return cep
     */
    public java.lang.String getCep() {
        return cep;
    }


    /**
     * Sets the cep value for this AlterarDadosCadastraisClienteRequest.
     * 
     * @param cep
     */
    public void setCep(java.lang.String cep) {
        this.cep = cep;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarDadosCadastraisClienteRequest)) return false;
        AlterarDadosCadastraisClienteRequest other = (AlterarDadosCadastraisClienteRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.nomePlaqueta==null && other.getNomePlaqueta()==null) || 
             (this.nomePlaqueta!=null &&
              this.nomePlaqueta.equals(other.getNomePlaqueta()))) &&
            ((this.nomeFantasia==null && other.getNomeFantasia()==null) || 
             (this.nomeFantasia!=null &&
              this.nomeFantasia.equals(other.getNomeFantasia()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.numeroDDDTelefoneEstabelecimento==null && other.getNumeroDDDTelefoneEstabelecimento()==null) || 
             (this.numeroDDDTelefoneEstabelecimento!=null &&
              this.numeroDDDTelefoneEstabelecimento.equals(other.getNumeroDDDTelefoneEstabelecimento()))) &&
            ((this.numeroTelefoneEstabelecimento==null && other.getNumeroTelefoneEstabelecimento()==null) || 
             (this.numeroTelefoneEstabelecimento!=null &&
              this.numeroTelefoneEstabelecimento.equals(other.getNumeroTelefoneEstabelecimento()))) &&
            ((this.numeroDDDTelefoneAlternativo==null && other.getNumeroDDDTelefoneAlternativo()==null) || 
             (this.numeroDDDTelefoneAlternativo!=null &&
              this.numeroDDDTelefoneAlternativo.equals(other.getNumeroDDDTelefoneAlternativo()))) &&
            ((this.numeroTelefoneAlternativo==null && other.getNumeroTelefoneAlternativo()==null) || 
             (this.numeroTelefoneAlternativo!=null &&
              this.numeroTelefoneAlternativo.equals(other.getNumeroTelefoneAlternativo()))) &&
            ((this.tipoEnderecoAlterado==null && other.getTipoEnderecoAlterado()==null) || 
             (this.tipoEnderecoAlterado!=null &&
              this.tipoEnderecoAlterado.equals(other.getTipoEnderecoAlterado()))) &&
            ((this.logradouro==null && other.getLogradouro()==null) || 
             (this.logradouro!=null &&
              this.logradouro.equals(other.getLogradouro()))) &&
            ((this.complemento==null && other.getComplemento()==null) || 
             (this.complemento!=null &&
              this.complemento.equals(other.getComplemento()))) &&
            ((this.cidade==null && other.getCidade()==null) || 
             (this.cidade!=null &&
              this.cidade.equals(other.getCidade()))) &&
            ((this.estado==null && other.getEstado()==null) || 
             (this.estado!=null &&
              this.estado.equals(other.getEstado()))) &&
            ((this.cep==null && other.getCep()==null) || 
             (this.cep!=null &&
              this.cep.equals(other.getCep())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getNomePlaqueta() != null) {
            _hashCode += getNomePlaqueta().hashCode();
        }
        if (getNomeFantasia() != null) {
            _hashCode += getNomeFantasia().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getNumeroDDDTelefoneEstabelecimento() != null) {
            _hashCode += getNumeroDDDTelefoneEstabelecimento().hashCode();
        }
        if (getNumeroTelefoneEstabelecimento() != null) {
            _hashCode += getNumeroTelefoneEstabelecimento().hashCode();
        }
        if (getNumeroDDDTelefoneAlternativo() != null) {
            _hashCode += getNumeroDDDTelefoneAlternativo().hashCode();
        }
        if (getNumeroTelefoneAlternativo() != null) {
            _hashCode += getNumeroTelefoneAlternativo().hashCode();
        }
        if (getTipoEnderecoAlterado() != null) {
            _hashCode += getTipoEnderecoAlterado().hashCode();
        }
        if (getLogradouro() != null) {
            _hashCode += getLogradouro().hashCode();
        }
        if (getComplemento() != null) {
            _hashCode += getComplemento().hashCode();
        }
        if (getCidade() != null) {
            _hashCode += getCidade().hashCode();
        }
        if (getEstado() != null) {
            _hashCode += getEstado().hashCode();
        }
        if (getCep() != null) {
            _hashCode += getCep().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarDadosCadastraisClienteRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarDadosCadastraisClienteRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePlaqueta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "nomePlaqueta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFantasia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "nomeFantasia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDDDTelefoneEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroDDDTelefoneEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefoneEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroTelefoneEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDDDTelefoneAlternativo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroDDDTelefoneAlternativo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefoneAlternativo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroTelefoneAlternativo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoEnderecoAlterado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "tipoEnderecoAlterado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "logradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complemento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "complemento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "cidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "estado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cep");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "cep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
