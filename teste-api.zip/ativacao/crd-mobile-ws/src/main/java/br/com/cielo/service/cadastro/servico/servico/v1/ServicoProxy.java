package br.com.cielo.service.cadastro.servico.servico.v1;

public class ServicoProxy implements br.com.cielo.service.cadastro.servico.servico.v1.Servico_PortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.servico.servico.v1.Servico_PortType servico_PortType = null;
  
  public ServicoProxy() {
    _initServicoProxy();
  }
  
  public ServicoProxy(String endpoint) {
    _endpoint = endpoint;
    _initServicoProxy();
  }
  
  private void _initServicoProxy() {
    try {
      servico_PortType = (new br.com.cielo.service.cadastro.servico.servico.v1.Servico_ServiceLocator()).getServicoSOAP();
      if (servico_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)servico_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)servico_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (servico_PortType != null)
      ((javax.xml.rpc.Stub)servico_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.servico.servico.v1.Servico_PortType getServico_PortType() {
    if (servico_PortType == null)
      _initServicoProxy();
    return servico_PortType;
  }
  
  public br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoHabilitadoClienteResponse consultarServicoHabilitadoCliente(br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoHabilitadoClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (servico_PortType == null)
      _initServicoProxy();
    return servico_PortType.consultarServicoHabilitadoCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoElegivelClienteResponse consultarServicoElegivelCliente(br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoElegivelClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (servico_PortType == null)
      _initServicoProxy();
    return servico_PortType.consultarServicoElegivelCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoNaoElegivelClienteResponse consultarServicoNaoElegivelCliente(br.com.cielo.service.cadastro.servico.servico.v1.ConsultarServicoNaoElegivelClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (servico_PortType == null)
      _initServicoProxy();
    return servico_PortType.consultarServicoNaoElegivelCliente(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.servico.servico.v1.HabilitarServicoResponse habilitarServico(br.com.cielo.service.cadastro.servico.servico.v1.HabilitarServicoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (servico_PortType == null)
      _initServicoProxy();
    return servico_PortType.habilitarServico(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.servico.servico.v1.DesabilitarServicoResponse desabilitarServico(br.com.cielo.service.cadastro.servico.servico.v1.DesabilitarServicoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (servico_PortType == null)
      _initServicoProxy();
    return servico_PortType.desabilitarServico(parameters, header);
  }
  
  public br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoResponse habilitarListaServico(br.com.cielo.service.cadastro.servico.servico.v1.HabilitarListaServicoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (servico_PortType == null)
      _initServicoProxy();
    return servico_PortType.habilitarListaServico(parameters, header);
  }
  
  
}