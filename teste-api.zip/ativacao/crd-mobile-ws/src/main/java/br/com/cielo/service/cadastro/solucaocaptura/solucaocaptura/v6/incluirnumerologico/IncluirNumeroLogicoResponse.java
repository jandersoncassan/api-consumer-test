/**
 * IncluirNumeroLogicoResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v6.incluirnumerologico;

public class IncluirNumeroLogicoResponse  implements java.io.Serializable {
    private java.lang.Long numeroLogico;

    private java.lang.Integer digitoNumeroLogico;

    private java.lang.String codigoRetorno;

    private java.lang.String descricaoRetorno;

    public IncluirNumeroLogicoResponse() {
    }

    public IncluirNumeroLogicoResponse(
           java.lang.Long numeroLogico,
           java.lang.Integer digitoNumeroLogico,
           java.lang.String codigoRetorno,
           java.lang.String descricaoRetorno) {
           this.numeroLogico = numeroLogico;
           this.digitoNumeroLogico = digitoNumeroLogico;
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetorno = descricaoRetorno;
    }


    /**
     * Gets the numeroLogico value for this IncluirNumeroLogicoResponse.
     * 
     * @return numeroLogico
     */
    public java.lang.Long getNumeroLogico() {
        return numeroLogico;
    }


    /**
     * Sets the numeroLogico value for this IncluirNumeroLogicoResponse.
     * 
     * @param numeroLogico
     */
    public void setNumeroLogico(java.lang.Long numeroLogico) {
        this.numeroLogico = numeroLogico;
    }


    /**
     * Gets the digitoNumeroLogico value for this IncluirNumeroLogicoResponse.
     * 
     * @return digitoNumeroLogico
     */
    public java.lang.Integer getDigitoNumeroLogico() {
        return digitoNumeroLogico;
    }


    /**
     * Sets the digitoNumeroLogico value for this IncluirNumeroLogicoResponse.
     * 
     * @param digitoNumeroLogico
     */
    public void setDigitoNumeroLogico(java.lang.Integer digitoNumeroLogico) {
        this.digitoNumeroLogico = digitoNumeroLogico;
    }


    /**
     * Gets the codigoRetorno value for this IncluirNumeroLogicoResponse.
     * 
     * @return codigoRetorno
     */
    public java.lang.String getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this IncluirNumeroLogicoResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.lang.String codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetorno value for this IncluirNumeroLogicoResponse.
     * 
     * @return descricaoRetorno
     */
    public java.lang.String getDescricaoRetorno() {
        return descricaoRetorno;
    }


    /**
     * Sets the descricaoRetorno value for this IncluirNumeroLogicoResponse.
     * 
     * @param descricaoRetorno
     */
    public void setDescricaoRetorno(java.lang.String descricaoRetorno) {
        this.descricaoRetorno = descricaoRetorno;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof IncluirNumeroLogicoResponse)) return false;
        IncluirNumeroLogicoResponse other = (IncluirNumeroLogicoResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroLogico==null && other.getNumeroLogico()==null) || 
             (this.numeroLogico!=null &&
              this.numeroLogico.equals(other.getNumeroLogico()))) &&
            ((this.digitoNumeroLogico==null && other.getDigitoNumeroLogico()==null) || 
             (this.digitoNumeroLogico!=null &&
              this.digitoNumeroLogico.equals(other.getDigitoNumeroLogico()))) &&
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetorno==null && other.getDescricaoRetorno()==null) || 
             (this.descricaoRetorno!=null &&
              this.descricaoRetorno.equals(other.getDescricaoRetorno())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroLogico() != null) {
            _hashCode += getNumeroLogico().hashCode();
        }
        if (getDigitoNumeroLogico() != null) {
            _hashCode += getDigitoNumeroLogico().hashCode();
        }
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetorno() != null) {
            _hashCode += getDescricaoRetorno().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(IncluirNumeroLogicoResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", ">IncluirNumeroLogicoResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "numeroLogico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("digitoNumeroLogico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "digitoNumeroLogico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/solucaocaptura/solucaocaptura/v6/incluirnumerologico", "descricaoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
