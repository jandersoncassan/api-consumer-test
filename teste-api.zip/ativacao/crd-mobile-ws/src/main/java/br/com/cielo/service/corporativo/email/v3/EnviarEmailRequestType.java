/**
 * EnviarEmailRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.corporativo.email.v3;

public class EnviarEmailRequestType  implements java.io.Serializable {
    /* Provedores disponiveis para envio de email */
    private br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeConteudo conteudo;

    /* Charset do e-mail. */
    private br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeCharset charset;

    private java.lang.String deEmail;

    private java.lang.String deNome;

    private java.lang.String[] para;

    private java.lang.String[] cc;

    private java.lang.String assunto;

    private java.lang.String mensagem;

    public EnviarEmailRequestType() {
    }

    public EnviarEmailRequestType(
           br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeConteudo conteudo,
           br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeCharset charset,
           java.lang.String deEmail,
           java.lang.String deNome,
           java.lang.String[] para,
           java.lang.String[] cc,
           java.lang.String assunto,
           java.lang.String mensagem) {
           this.conteudo = conteudo;
           this.charset = charset;
           this.deEmail = deEmail;
           this.deNome = deNome;
           this.para = para;
           this.cc = cc;
           this.assunto = assunto;
           this.mensagem = mensagem;
    }


    /**
     * Gets the conteudo value for this EnviarEmailRequestType.
     * 
     * @return conteudo   * Provedores disponiveis para envio de email
     */
    public br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeConteudo getConteudo() {
        return conteudo;
    }


    /**
     * Sets the conteudo value for this EnviarEmailRequestType.
     * 
     * @param conteudo   * Provedores disponiveis para envio de email
     */
    public void setConteudo(br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeConteudo conteudo) {
        this.conteudo = conteudo;
    }


    /**
     * Gets the charset value for this EnviarEmailRequestType.
     * 
     * @return charset   * Charset do e-mail.
     */
    public br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeCharset getCharset() {
        return charset;
    }


    /**
     * Sets the charset value for this EnviarEmailRequestType.
     * 
     * @param charset   * Charset do e-mail.
     */
    public void setCharset(br.com.cielo.service.corporativo.email.v3.EnviarEmailRequestTypeCharset charset) {
        this.charset = charset;
    }


    /**
     * Gets the deEmail value for this EnviarEmailRequestType.
     * 
     * @return deEmail
     */
    public java.lang.String getDeEmail() {
        return deEmail;
    }


    /**
     * Sets the deEmail value for this EnviarEmailRequestType.
     * 
     * @param deEmail
     */
    public void setDeEmail(java.lang.String deEmail) {
        this.deEmail = deEmail;
    }


    /**
     * Gets the deNome value for this EnviarEmailRequestType.
     * 
     * @return deNome
     */
    public java.lang.String getDeNome() {
        return deNome;
    }


    /**
     * Sets the deNome value for this EnviarEmailRequestType.
     * 
     * @param deNome
     */
    public void setDeNome(java.lang.String deNome) {
        this.deNome = deNome;
    }


    /**
     * Gets the para value for this EnviarEmailRequestType.
     * 
     * @return para
     */
    public java.lang.String[] getPara() {
        return para;
    }


    /**
     * Sets the para value for this EnviarEmailRequestType.
     * 
     * @param para
     */
    public void setPara(java.lang.String[] para) {
        this.para = para;
    }

    public java.lang.String getPara(int i) {
        return this.para[i];
    }

    public void setPara(int i, java.lang.String _value) {
        this.para[i] = _value;
    }


    /**
     * Gets the cc value for this EnviarEmailRequestType.
     * 
     * @return cc
     */
    public java.lang.String[] getCc() {
        return cc;
    }


    /**
     * Sets the cc value for this EnviarEmailRequestType.
     * 
     * @param cc
     */
    public void setCc(java.lang.String[] cc) {
        this.cc = cc;
    }

    public java.lang.String getCc(int i) {
        return this.cc[i];
    }

    public void setCc(int i, java.lang.String _value) {
        this.cc[i] = _value;
    }


    /**
     * Gets the assunto value for this EnviarEmailRequestType.
     * 
     * @return assunto
     */
    public java.lang.String getAssunto() {
        return assunto;
    }


    /**
     * Sets the assunto value for this EnviarEmailRequestType.
     * 
     * @param assunto
     */
    public void setAssunto(java.lang.String assunto) {
        this.assunto = assunto;
    }


    /**
     * Gets the mensagem value for this EnviarEmailRequestType.
     * 
     * @return mensagem
     */
    public java.lang.String getMensagem() {
        return mensagem;
    }


    /**
     * Sets the mensagem value for this EnviarEmailRequestType.
     * 
     * @param mensagem
     */
    public void setMensagem(java.lang.String mensagem) {
        this.mensagem = mensagem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EnviarEmailRequestType)) return false;
        EnviarEmailRequestType other = (EnviarEmailRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.conteudo==null && other.getConteudo()==null) || 
             (this.conteudo!=null &&
              this.conteudo.equals(other.getConteudo()))) &&
            ((this.charset==null && other.getCharset()==null) || 
             (this.charset!=null &&
              this.charset.equals(other.getCharset()))) &&
            ((this.deEmail==null && other.getDeEmail()==null) || 
             (this.deEmail!=null &&
              this.deEmail.equals(other.getDeEmail()))) &&
            ((this.deNome==null && other.getDeNome()==null) || 
             (this.deNome!=null &&
              this.deNome.equals(other.getDeNome()))) &&
            ((this.para==null && other.getPara()==null) || 
             (this.para!=null &&
              java.util.Arrays.equals(this.para, other.getPara()))) &&
            ((this.cc==null && other.getCc()==null) || 
             (this.cc!=null &&
              java.util.Arrays.equals(this.cc, other.getCc()))) &&
            ((this.assunto==null && other.getAssunto()==null) || 
             (this.assunto!=null &&
              this.assunto.equals(other.getAssunto()))) &&
            ((this.mensagem==null && other.getMensagem()==null) || 
             (this.mensagem!=null &&
              this.mensagem.equals(other.getMensagem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getConteudo() != null) {
            _hashCode += getConteudo().hashCode();
        }
        if (getCharset() != null) {
            _hashCode += getCharset().hashCode();
        }
        if (getDeEmail() != null) {
            _hashCode += getDeEmail().hashCode();
        }
        if (getDeNome() != null) {
            _hashCode += getDeNome().hashCode();
        }
        if (getPara() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getPara());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getPara(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCc() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCc());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCc(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getAssunto() != null) {
            _hashCode += getAssunto().hashCode();
        }
        if (getMensagem() != null) {
            _hashCode += getMensagem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EnviarEmailRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", ">EnviarEmailRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conteudo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "conteudo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", ">>EnviarEmailRequestType>conteudo"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("charset");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "charset"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", ">>EnviarEmailRequestType>charset"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deEmail");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "deEmail"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("deNome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "deNome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("para");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "para"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "cc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setMaxOccursUnbounded(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("assunto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "assunto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/corporativo/email/v3", "mensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
