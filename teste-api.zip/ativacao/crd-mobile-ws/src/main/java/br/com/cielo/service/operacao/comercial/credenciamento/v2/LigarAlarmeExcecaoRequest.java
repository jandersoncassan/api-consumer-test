/**
 * LigarAlarmeExcecaoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class LigarAlarmeExcecaoRequest  implements java.io.Serializable {
    private java.lang.String descricaoErroProvedor;

    /* CorrelationId do COI (numero da instancia do processo) */
    private java.lang.String identificadorIncidente;

    /* CorrelationId do CRD que e enviado na fila de entrada do COI
     * ou numero da proposta. */
    private java.lang.String identificadorProcessoCredenciamento;

    private java.lang.String servicoOperacaoOrigem;

    private java.lang.String sistemaProvedor;

    /* Tipo do Processamento que gerou a requisao (A = Assincrono
     * || S = Sincrono). */
    private java.lang.String tipoProcesso;

    private java.lang.Long numeroProposta;

    public LigarAlarmeExcecaoRequest() {
    }

    public LigarAlarmeExcecaoRequest(
           java.lang.String descricaoErroProvedor,
           java.lang.String identificadorIncidente,
           java.lang.String identificadorProcessoCredenciamento,
           java.lang.String servicoOperacaoOrigem,
           java.lang.String sistemaProvedor,
           java.lang.String tipoProcesso,
           java.lang.Long numeroProposta) {
           this.descricaoErroProvedor = descricaoErroProvedor;
           this.identificadorIncidente = identificadorIncidente;
           this.identificadorProcessoCredenciamento = identificadorProcessoCredenciamento;
           this.servicoOperacaoOrigem = servicoOperacaoOrigem;
           this.sistemaProvedor = sistemaProvedor;
           this.tipoProcesso = tipoProcesso;
           this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the descricaoErroProvedor value for this LigarAlarmeExcecaoRequest.
     * 
     * @return descricaoErroProvedor
     */
    public java.lang.String getDescricaoErroProvedor() {
        return descricaoErroProvedor;
    }


    /**
     * Sets the descricaoErroProvedor value for this LigarAlarmeExcecaoRequest.
     * 
     * @param descricaoErroProvedor
     */
    public void setDescricaoErroProvedor(java.lang.String descricaoErroProvedor) {
        this.descricaoErroProvedor = descricaoErroProvedor;
    }


    /**
     * Gets the identificadorIncidente value for this LigarAlarmeExcecaoRequest.
     * 
     * @return identificadorIncidente   * CorrelationId do COI (numero da instancia do processo)
     */
    public java.lang.String getIdentificadorIncidente() {
        return identificadorIncidente;
    }


    /**
     * Sets the identificadorIncidente value for this LigarAlarmeExcecaoRequest.
     * 
     * @param identificadorIncidente   * CorrelationId do COI (numero da instancia do processo)
     */
    public void setIdentificadorIncidente(java.lang.String identificadorIncidente) {
        this.identificadorIncidente = identificadorIncidente;
    }


    /**
     * Gets the identificadorProcessoCredenciamento value for this LigarAlarmeExcecaoRequest.
     * 
     * @return identificadorProcessoCredenciamento   * CorrelationId do CRD que e enviado na fila de entrada do COI
     * ou numero da proposta.
     */
    public java.lang.String getIdentificadorProcessoCredenciamento() {
        return identificadorProcessoCredenciamento;
    }


    /**
     * Sets the identificadorProcessoCredenciamento value for this LigarAlarmeExcecaoRequest.
     * 
     * @param identificadorProcessoCredenciamento   * CorrelationId do CRD que e enviado na fila de entrada do COI
     * ou numero da proposta.
     */
    public void setIdentificadorProcessoCredenciamento(java.lang.String identificadorProcessoCredenciamento) {
        this.identificadorProcessoCredenciamento = identificadorProcessoCredenciamento;
    }


    /**
     * Gets the servicoOperacaoOrigem value for this LigarAlarmeExcecaoRequest.
     * 
     * @return servicoOperacaoOrigem
     */
    public java.lang.String getServicoOperacaoOrigem() {
        return servicoOperacaoOrigem;
    }


    /**
     * Sets the servicoOperacaoOrigem value for this LigarAlarmeExcecaoRequest.
     * 
     * @param servicoOperacaoOrigem
     */
    public void setServicoOperacaoOrigem(java.lang.String servicoOperacaoOrigem) {
        this.servicoOperacaoOrigem = servicoOperacaoOrigem;
    }


    /**
     * Gets the sistemaProvedor value for this LigarAlarmeExcecaoRequest.
     * 
     * @return sistemaProvedor
     */
    public java.lang.String getSistemaProvedor() {
        return sistemaProvedor;
    }


    /**
     * Sets the sistemaProvedor value for this LigarAlarmeExcecaoRequest.
     * 
     * @param sistemaProvedor
     */
    public void setSistemaProvedor(java.lang.String sistemaProvedor) {
        this.sistemaProvedor = sistemaProvedor;
    }


    /**
     * Gets the tipoProcesso value for this LigarAlarmeExcecaoRequest.
     * 
     * @return tipoProcesso   * Tipo do Processamento que gerou a requisao (A = Assincrono
     * || S = Sincrono).
     */
    public java.lang.String getTipoProcesso() {
        return tipoProcesso;
    }


    /**
     * Sets the tipoProcesso value for this LigarAlarmeExcecaoRequest.
     * 
     * @param tipoProcesso   * Tipo do Processamento que gerou a requisao (A = Assincrono
     * || S = Sincrono).
     */
    public void setTipoProcesso(java.lang.String tipoProcesso) {
        this.tipoProcesso = tipoProcesso;
    }


    /**
     * Gets the numeroProposta value for this LigarAlarmeExcecaoRequest.
     * 
     * @return numeroProposta
     */
    public java.lang.Long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this LigarAlarmeExcecaoRequest.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(java.lang.Long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof LigarAlarmeExcecaoRequest)) return false;
        LigarAlarmeExcecaoRequest other = (LigarAlarmeExcecaoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.descricaoErroProvedor==null && other.getDescricaoErroProvedor()==null) || 
             (this.descricaoErroProvedor!=null &&
              this.descricaoErroProvedor.equals(other.getDescricaoErroProvedor()))) &&
            ((this.identificadorIncidente==null && other.getIdentificadorIncidente()==null) || 
             (this.identificadorIncidente!=null &&
              this.identificadorIncidente.equals(other.getIdentificadorIncidente()))) &&
            ((this.identificadorProcessoCredenciamento==null && other.getIdentificadorProcessoCredenciamento()==null) || 
             (this.identificadorProcessoCredenciamento!=null &&
              this.identificadorProcessoCredenciamento.equals(other.getIdentificadorProcessoCredenciamento()))) &&
            ((this.servicoOperacaoOrigem==null && other.getServicoOperacaoOrigem()==null) || 
             (this.servicoOperacaoOrigem!=null &&
              this.servicoOperacaoOrigem.equals(other.getServicoOperacaoOrigem()))) &&
            ((this.sistemaProvedor==null && other.getSistemaProvedor()==null) || 
             (this.sistemaProvedor!=null &&
              this.sistemaProvedor.equals(other.getSistemaProvedor()))) &&
            ((this.tipoProcesso==null && other.getTipoProcesso()==null) || 
             (this.tipoProcesso!=null &&
              this.tipoProcesso.equals(other.getTipoProcesso()))) &&
            ((this.numeroProposta==null && other.getNumeroProposta()==null) || 
             (this.numeroProposta!=null &&
              this.numeroProposta.equals(other.getNumeroProposta())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDescricaoErroProvedor() != null) {
            _hashCode += getDescricaoErroProvedor().hashCode();
        }
        if (getIdentificadorIncidente() != null) {
            _hashCode += getIdentificadorIncidente().hashCode();
        }
        if (getIdentificadorProcessoCredenciamento() != null) {
            _hashCode += getIdentificadorProcessoCredenciamento().hashCode();
        }
        if (getServicoOperacaoOrigem() != null) {
            _hashCode += getServicoOperacaoOrigem().hashCode();
        }
        if (getSistemaProvedor() != null) {
            _hashCode += getSistemaProvedor().hashCode();
        }
        if (getTipoProcesso() != null) {
            _hashCode += getTipoProcesso().hashCode();
        }
        if (getNumeroProposta() != null) {
            _hashCode += getNumeroProposta().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(LigarAlarmeExcecaoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", ">ligarAlarmeExcecaoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoErroProvedor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "descricaoErroProvedor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identificadorIncidente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "identificadorIncidente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identificadorProcessoCredenciamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "identificadorProcessoCredenciamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("servicoOperacaoOrigem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "servicoOperacaoOrigem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sistemaProvedor");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "sistemaProvedor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoProcesso");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "tipoProcesso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v2", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
