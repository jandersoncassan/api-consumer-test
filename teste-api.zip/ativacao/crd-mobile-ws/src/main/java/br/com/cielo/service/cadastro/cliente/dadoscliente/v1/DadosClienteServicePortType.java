/**
 * DadosClienteServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v1;

public interface DadosClienteServicePortType extends java.rmi.Remote {

    /**
     * Operacao responsavel por inserir um cliente.
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirResponse incluir(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.IncluirRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;

    /**
     * Operação responsavel por atualizar os dados cadastrais do cliente
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteResponseType consultarDadosCliente(br.com.cielo.service.cadastro.cliente.dadoscliente.v1.ConsultarDadosClienteRequestType parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
