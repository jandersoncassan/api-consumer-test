package br.com.cielo.service.operacao.comercial.credenciamento.v2;

public class CredenciamentoPortTypeProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v2.CredenciamentoPortType {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v2.CredenciamentoPortType credenciamentoPortType = null;
  
  public CredenciamentoPortTypeProxy() {
    _initCredenciamentoPortTypeProxy();
  }
  
  public CredenciamentoPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamentoPortTypeProxy();
  }
  
  private void _initCredenciamentoPortTypeProxy() {
    try {
      credenciamentoPortType = (new br.com.cielo.service.operacao.comercial.credenciamento.v2.CredenciamentoServiceLocator()).getCredenciamentoSoapPort();
      if (credenciamentoPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamentoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamentoPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamentoPortType != null)
      ((javax.xml.rpc.Stub)credenciamentoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v2.CredenciamentoPortType getCredenciamentoPortType() {
    if (credenciamentoPortType == null)
      _initCredenciamentoPortTypeProxy();
    return credenciamentoPortType;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioResponse verificarExistenciaDomicilioBancario(br.com.cielo.service.operacao.comercial.credenciamento.v2.VerificarExistenciaDomicilioBancarioRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamentoPortType == null)
      _initCredenciamentoPortTypeProxy();
    return credenciamentoPortType.verificarExistenciaDomicilioBancario(parameters, header);
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaResponse incluirProposta(br.com.cielo.service.operacao.comercial.credenciamento.v2.IncluirPropostaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamentoPortType == null)
      _initCredenciamentoPortTypeProxy();
    return credenciamentoPortType.incluirProposta(parameters, header);
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaResponse alterarProposta(br.com.cielo.service.operacao.comercial.credenciamento.v2.AlterarPropostaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamentoPortType == null)
      _initCredenciamentoPortTypeProxy();
    return credenciamentoPortType.alterarProposta(parameters, header);
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoResponse ligarAlarmeExcecao(br.com.cielo.service.operacao.comercial.credenciamento.v2.LigarAlarmeExcecaoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamentoPortType == null)
      _initCredenciamentoPortTypeProxy();
    return credenciamentoPortType.ligarAlarmeExcecao(parameters, header);
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoResponse desligarAlarmeExcecao(br.com.cielo.service.operacao.comercial.credenciamento.v2.DesligarAlarmeExcecaoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamentoPortType == null)
      _initCredenciamentoPortTypeProxy();
    return credenciamentoPortType.desligarAlarmeExcecao(parameters, header);
  }
  
  
}