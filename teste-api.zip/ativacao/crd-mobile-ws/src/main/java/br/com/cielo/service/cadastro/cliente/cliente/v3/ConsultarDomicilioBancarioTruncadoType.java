/**
 * ConsultarDomicilioBancarioTruncadoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ConsultarDomicilioBancarioTruncadoType  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.DadosBancarios dadosBancarios;

    private java.lang.String numeroContaCorrenteTrucando;

    private java.math.BigInteger codigoBandeira;

    private br.com.cielo.canonico.cadastro.v1.Cliente cliente;

    private java.lang.String indicadorTrava;

    private java.lang.String indicadorTravaARV;

    private java.lang.String indicadorAntecipacaoRecebiveis;

    public ConsultarDomicilioBancarioTruncadoType() {
    }

    public ConsultarDomicilioBancarioTruncadoType(
           br.com.cielo.canonico.cadastro.v1.DadosBancarios dadosBancarios,
           java.lang.String numeroContaCorrenteTrucando,
           java.math.BigInteger codigoBandeira,
           br.com.cielo.canonico.cadastro.v1.Cliente cliente,
           java.lang.String indicadorTrava,
           java.lang.String indicadorTravaARV,
           java.lang.String indicadorAntecipacaoRecebiveis) {
           this.dadosBancarios = dadosBancarios;
           this.numeroContaCorrenteTrucando = numeroContaCorrenteTrucando;
           this.codigoBandeira = codigoBandeira;
           this.cliente = cliente;
           this.indicadorTrava = indicadorTrava;
           this.indicadorTravaARV = indicadorTravaARV;
           this.indicadorAntecipacaoRecebiveis = indicadorAntecipacaoRecebiveis;
    }


    /**
     * Gets the dadosBancarios value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @return dadosBancarios
     */
    public br.com.cielo.canonico.cadastro.v1.DadosBancarios getDadosBancarios() {
        return dadosBancarios;
    }


    /**
     * Sets the dadosBancarios value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @param dadosBancarios
     */
    public void setDadosBancarios(br.com.cielo.canonico.cadastro.v1.DadosBancarios dadosBancarios) {
        this.dadosBancarios = dadosBancarios;
    }


    /**
     * Gets the numeroContaCorrenteTrucando value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @return numeroContaCorrenteTrucando
     */
    public java.lang.String getNumeroContaCorrenteTrucando() {
        return numeroContaCorrenteTrucando;
    }


    /**
     * Sets the numeroContaCorrenteTrucando value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @param numeroContaCorrenteTrucando
     */
    public void setNumeroContaCorrenteTrucando(java.lang.String numeroContaCorrenteTrucando) {
        this.numeroContaCorrenteTrucando = numeroContaCorrenteTrucando;
    }


    /**
     * Gets the codigoBandeira value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @return codigoBandeira
     */
    public java.math.BigInteger getCodigoBandeira() {
        return codigoBandeira;
    }


    /**
     * Sets the codigoBandeira value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @param codigoBandeira
     */
    public void setCodigoBandeira(java.math.BigInteger codigoBandeira) {
        this.codigoBandeira = codigoBandeira;
    }


    /**
     * Gets the cliente value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @return cliente
     */
    public br.com.cielo.canonico.cadastro.v1.Cliente getCliente() {
        return cliente;
    }


    /**
     * Sets the cliente value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @param cliente
     */
    public void setCliente(br.com.cielo.canonico.cadastro.v1.Cliente cliente) {
        this.cliente = cliente;
    }


    /**
     * Gets the indicadorTrava value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @return indicadorTrava
     */
    public java.lang.String getIndicadorTrava() {
        return indicadorTrava;
    }


    /**
     * Sets the indicadorTrava value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @param indicadorTrava
     */
    public void setIndicadorTrava(java.lang.String indicadorTrava) {
        this.indicadorTrava = indicadorTrava;
    }


    /**
     * Gets the indicadorTravaARV value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @return indicadorTravaARV
     */
    public java.lang.String getIndicadorTravaARV() {
        return indicadorTravaARV;
    }


    /**
     * Sets the indicadorTravaARV value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @param indicadorTravaARV
     */
    public void setIndicadorTravaARV(java.lang.String indicadorTravaARV) {
        this.indicadorTravaARV = indicadorTravaARV;
    }


    /**
     * Gets the indicadorAntecipacaoRecebiveis value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @return indicadorAntecipacaoRecebiveis
     */
    public java.lang.String getIndicadorAntecipacaoRecebiveis() {
        return indicadorAntecipacaoRecebiveis;
    }


    /**
     * Sets the indicadorAntecipacaoRecebiveis value for this ConsultarDomicilioBancarioTruncadoType.
     * 
     * @param indicadorAntecipacaoRecebiveis
     */
    public void setIndicadorAntecipacaoRecebiveis(java.lang.String indicadorAntecipacaoRecebiveis) {
        this.indicadorAntecipacaoRecebiveis = indicadorAntecipacaoRecebiveis;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDomicilioBancarioTruncadoType)) return false;
        ConsultarDomicilioBancarioTruncadoType other = (ConsultarDomicilioBancarioTruncadoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.dadosBancarios==null && other.getDadosBancarios()==null) || 
             (this.dadosBancarios!=null &&
              this.dadosBancarios.equals(other.getDadosBancarios()))) &&
            ((this.numeroContaCorrenteTrucando==null && other.getNumeroContaCorrenteTrucando()==null) || 
             (this.numeroContaCorrenteTrucando!=null &&
              this.numeroContaCorrenteTrucando.equals(other.getNumeroContaCorrenteTrucando()))) &&
            ((this.codigoBandeira==null && other.getCodigoBandeira()==null) || 
             (this.codigoBandeira!=null &&
              this.codigoBandeira.equals(other.getCodigoBandeira()))) &&
            ((this.cliente==null && other.getCliente()==null) || 
             (this.cliente!=null &&
              this.cliente.equals(other.getCliente()))) &&
            ((this.indicadorTrava==null && other.getIndicadorTrava()==null) || 
             (this.indicadorTrava!=null &&
              this.indicadorTrava.equals(other.getIndicadorTrava()))) &&
            ((this.indicadorTravaARV==null && other.getIndicadorTravaARV()==null) || 
             (this.indicadorTravaARV!=null &&
              this.indicadorTravaARV.equals(other.getIndicadorTravaARV()))) &&
            ((this.indicadorAntecipacaoRecebiveis==null && other.getIndicadorAntecipacaoRecebiveis()==null) || 
             (this.indicadorAntecipacaoRecebiveis!=null &&
              this.indicadorAntecipacaoRecebiveis.equals(other.getIndicadorAntecipacaoRecebiveis())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getDadosBancarios() != null) {
            _hashCode += getDadosBancarios().hashCode();
        }
        if (getNumeroContaCorrenteTrucando() != null) {
            _hashCode += getNumeroContaCorrenteTrucando().hashCode();
        }
        if (getCodigoBandeira() != null) {
            _hashCode += getCodigoBandeira().hashCode();
        }
        if (getCliente() != null) {
            _hashCode += getCliente().hashCode();
        }
        if (getIndicadorTrava() != null) {
            _hashCode += getIndicadorTrava().hashCode();
        }
        if (getIndicadorTravaARV() != null) {
            _hashCode += getIndicadorTravaARV().hashCode();
        }
        if (getIndicadorAntecipacaoRecebiveis() != null) {
            _hashCode += getIndicadorAntecipacaoRecebiveis().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDomicilioBancarioTruncadoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "consultarDomicilioBancarioTruncadoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosBancarios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "dadosBancarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "DadosBancarios"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroContaCorrenteTrucando");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroContaCorrenteTrucando"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "cliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Cliente"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorTrava");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "indicadorTrava"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorTravaARV");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "indicadorTravaARV"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAntecipacaoRecebiveis");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "indicadorAntecipacaoRecebiveis"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
