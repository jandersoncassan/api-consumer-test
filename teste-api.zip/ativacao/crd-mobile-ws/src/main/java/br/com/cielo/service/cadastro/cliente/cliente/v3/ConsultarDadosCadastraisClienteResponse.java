/**
 * ConsultarDadosCadastraisClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class ConsultarDadosCadastraisClienteResponse  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.Cliente cliente;

    private br.com.cielo.canonico.cadastro.v1.Credenciamento afiliacao;

    private java.lang.Long numeroMatriz;

    private java.lang.String indicadorMultivan;

    private java.lang.Boolean indicadorAlteracaoDiario;

    private java.lang.Boolean indicadorAssinaturaArquivo;

    private java.lang.String nomeEmailContatoAdicional;

    private java.lang.Boolean indicadorBloqueioSuprimentos;

    public ConsultarDadosCadastraisClienteResponse() {
    }

    public ConsultarDadosCadastraisClienteResponse(
           br.com.cielo.canonico.cadastro.v1.Cliente cliente,
           br.com.cielo.canonico.cadastro.v1.Credenciamento afiliacao,
           java.lang.Long numeroMatriz,
           java.lang.String indicadorMultivan,
           java.lang.Boolean indicadorAlteracaoDiario,
           java.lang.Boolean indicadorAssinaturaArquivo,
           java.lang.String nomeEmailContatoAdicional,
           java.lang.Boolean indicadorBloqueioSuprimentos) {
           this.cliente = cliente;
           this.afiliacao = afiliacao;
           this.numeroMatriz = numeroMatriz;
           this.indicadorMultivan = indicadorMultivan;
           this.indicadorAlteracaoDiario = indicadorAlteracaoDiario;
           this.indicadorAssinaturaArquivo = indicadorAssinaturaArquivo;
           this.nomeEmailContatoAdicional = nomeEmailContatoAdicional;
           this.indicadorBloqueioSuprimentos = indicadorBloqueioSuprimentos;
    }


    /**
     * Gets the cliente value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return cliente
     */
    public br.com.cielo.canonico.cadastro.v1.Cliente getCliente() {
        return cliente;
    }


    /**
     * Sets the cliente value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param cliente
     */
    public void setCliente(br.com.cielo.canonico.cadastro.v1.Cliente cliente) {
        this.cliente = cliente;
    }


    /**
     * Gets the afiliacao value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return afiliacao
     */
    public br.com.cielo.canonico.cadastro.v1.Credenciamento getAfiliacao() {
        return afiliacao;
    }


    /**
     * Sets the afiliacao value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param afiliacao
     */
    public void setAfiliacao(br.com.cielo.canonico.cadastro.v1.Credenciamento afiliacao) {
        this.afiliacao = afiliacao;
    }


    /**
     * Gets the numeroMatriz value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return numeroMatriz
     */
    public java.lang.Long getNumeroMatriz() {
        return numeroMatriz;
    }


    /**
     * Sets the numeroMatriz value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param numeroMatriz
     */
    public void setNumeroMatriz(java.lang.Long numeroMatriz) {
        this.numeroMatriz = numeroMatriz;
    }


    /**
     * Gets the indicadorMultivan value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return indicadorMultivan
     */
    public java.lang.String getIndicadorMultivan() {
        return indicadorMultivan;
    }


    /**
     * Sets the indicadorMultivan value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param indicadorMultivan
     */
    public void setIndicadorMultivan(java.lang.String indicadorMultivan) {
        this.indicadorMultivan = indicadorMultivan;
    }


    /**
     * Gets the indicadorAlteracaoDiario value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return indicadorAlteracaoDiario
     */
    public java.lang.Boolean getIndicadorAlteracaoDiario() {
        return indicadorAlteracaoDiario;
    }


    /**
     * Sets the indicadorAlteracaoDiario value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param indicadorAlteracaoDiario
     */
    public void setIndicadorAlteracaoDiario(java.lang.Boolean indicadorAlteracaoDiario) {
        this.indicadorAlteracaoDiario = indicadorAlteracaoDiario;
    }


    /**
     * Gets the indicadorAssinaturaArquivo value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return indicadorAssinaturaArquivo
     */
    public java.lang.Boolean getIndicadorAssinaturaArquivo() {
        return indicadorAssinaturaArquivo;
    }


    /**
     * Sets the indicadorAssinaturaArquivo value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param indicadorAssinaturaArquivo
     */
    public void setIndicadorAssinaturaArquivo(java.lang.Boolean indicadorAssinaturaArquivo) {
        this.indicadorAssinaturaArquivo = indicadorAssinaturaArquivo;
    }


    /**
     * Gets the nomeEmailContatoAdicional value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return nomeEmailContatoAdicional
     */
    public java.lang.String getNomeEmailContatoAdicional() {
        return nomeEmailContatoAdicional;
    }


    /**
     * Sets the nomeEmailContatoAdicional value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param nomeEmailContatoAdicional
     */
    public void setNomeEmailContatoAdicional(java.lang.String nomeEmailContatoAdicional) {
        this.nomeEmailContatoAdicional = nomeEmailContatoAdicional;
    }


    /**
     * Gets the indicadorBloqueioSuprimentos value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @return indicadorBloqueioSuprimentos
     */
    public java.lang.Boolean getIndicadorBloqueioSuprimentos() {
        return indicadorBloqueioSuprimentos;
    }


    /**
     * Sets the indicadorBloqueioSuprimentos value for this ConsultarDadosCadastraisClienteResponse.
     * 
     * @param indicadorBloqueioSuprimentos
     */
    public void setIndicadorBloqueioSuprimentos(java.lang.Boolean indicadorBloqueioSuprimentos) {
        this.indicadorBloqueioSuprimentos = indicadorBloqueioSuprimentos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDadosCadastraisClienteResponse)) return false;
        ConsultarDadosCadastraisClienteResponse other = (ConsultarDadosCadastraisClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.cliente==null && other.getCliente()==null) || 
             (this.cliente!=null &&
              this.cliente.equals(other.getCliente()))) &&
            ((this.afiliacao==null && other.getAfiliacao()==null) || 
             (this.afiliacao!=null &&
              this.afiliacao.equals(other.getAfiliacao()))) &&
            ((this.numeroMatriz==null && other.getNumeroMatriz()==null) || 
             (this.numeroMatriz!=null &&
              this.numeroMatriz.equals(other.getNumeroMatriz()))) &&
            ((this.indicadorMultivan==null && other.getIndicadorMultivan()==null) || 
             (this.indicadorMultivan!=null &&
              this.indicadorMultivan.equals(other.getIndicadorMultivan()))) &&
            ((this.indicadorAlteracaoDiario==null && other.getIndicadorAlteracaoDiario()==null) || 
             (this.indicadorAlteracaoDiario!=null &&
              this.indicadorAlteracaoDiario.equals(other.getIndicadorAlteracaoDiario()))) &&
            ((this.indicadorAssinaturaArquivo==null && other.getIndicadorAssinaturaArquivo()==null) || 
             (this.indicadorAssinaturaArquivo!=null &&
              this.indicadorAssinaturaArquivo.equals(other.getIndicadorAssinaturaArquivo()))) &&
            ((this.nomeEmailContatoAdicional==null && other.getNomeEmailContatoAdicional()==null) || 
             (this.nomeEmailContatoAdicional!=null &&
              this.nomeEmailContatoAdicional.equals(other.getNomeEmailContatoAdicional()))) &&
            ((this.indicadorBloqueioSuprimentos==null && other.getIndicadorBloqueioSuprimentos()==null) || 
             (this.indicadorBloqueioSuprimentos!=null &&
              this.indicadorBloqueioSuprimentos.equals(other.getIndicadorBloqueioSuprimentos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCliente() != null) {
            _hashCode += getCliente().hashCode();
        }
        if (getAfiliacao() != null) {
            _hashCode += getAfiliacao().hashCode();
        }
        if (getNumeroMatriz() != null) {
            _hashCode += getNumeroMatriz().hashCode();
        }
        if (getIndicadorMultivan() != null) {
            _hashCode += getIndicadorMultivan().hashCode();
        }
        if (getIndicadorAlteracaoDiario() != null) {
            _hashCode += getIndicadorAlteracaoDiario().hashCode();
        }
        if (getIndicadorAssinaturaArquivo() != null) {
            _hashCode += getIndicadorAssinaturaArquivo().hashCode();
        }
        if (getNomeEmailContatoAdicional() != null) {
            _hashCode += getNomeEmailContatoAdicional().hashCode();
        }
        if (getIndicadorBloqueioSuprimentos() != null) {
            _hashCode += getIndicadorBloqueioSuprimentos().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDadosCadastraisClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">consultarDadosCadastraisClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "cliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Cliente"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("afiliacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "afiliacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Credenciamento"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroMatriz");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroMatriz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMultivan");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "indicadorMultivan"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAlteracaoDiario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "indicadorAlteracaoDiario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAssinaturaArquivo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "indicadorAssinaturaArquivo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeEmailContatoAdicional");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "nomeEmailContatoAdicional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorBloqueioSuprimentos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "indicadorBloqueioSuprimentos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
