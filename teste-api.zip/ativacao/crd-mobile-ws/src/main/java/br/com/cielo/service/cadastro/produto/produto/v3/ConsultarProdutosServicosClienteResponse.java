/**
 * ConsultarProdutosServicosClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarProdutosServicosClienteResponse  implements java.io.Serializable {
    private java.math.BigInteger codigoRetornoMensagem;

    private java.lang.String descricaoRetornoMensagem;

    private java.lang.Long codigoCliente;

    private java.math.BigInteger lojaEstabelecimento;

    private java.lang.String nomeGrupoSolucaoCaptura;

    private br.com.cielo.service.cadastro.produto.produto.v3.ProdutoServicoClienteType[] produtosServicos;

    public ConsultarProdutosServicosClienteResponse() {
    }

    public ConsultarProdutosServicosClienteResponse(
           java.math.BigInteger codigoRetornoMensagem,
           java.lang.String descricaoRetornoMensagem,
           java.lang.Long codigoCliente,
           java.math.BigInteger lojaEstabelecimento,
           java.lang.String nomeGrupoSolucaoCaptura,
           br.com.cielo.service.cadastro.produto.produto.v3.ProdutoServicoClienteType[] produtosServicos) {
           this.codigoRetornoMensagem = codigoRetornoMensagem;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
           this.codigoCliente = codigoCliente;
           this.lojaEstabelecimento = lojaEstabelecimento;
           this.nomeGrupoSolucaoCaptura = nomeGrupoSolucaoCaptura;
           this.produtosServicos = produtosServicos;
    }


    /**
     * Gets the codigoRetornoMensagem value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @return codigoRetornoMensagem
     */
    public java.math.BigInteger getCodigoRetornoMensagem() {
        return codigoRetornoMensagem;
    }


    /**
     * Sets the codigoRetornoMensagem value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @param codigoRetornoMensagem
     */
    public void setCodigoRetornoMensagem(java.math.BigInteger codigoRetornoMensagem) {
        this.codigoRetornoMensagem = codigoRetornoMensagem;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the codigoCliente value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @return codigoCliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the lojaEstabelecimento value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @return lojaEstabelecimento
     */
    public java.math.BigInteger getLojaEstabelecimento() {
        return lojaEstabelecimento;
    }


    /**
     * Sets the lojaEstabelecimento value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @param lojaEstabelecimento
     */
    public void setLojaEstabelecimento(java.math.BigInteger lojaEstabelecimento) {
        this.lojaEstabelecimento = lojaEstabelecimento;
    }


    /**
     * Gets the nomeGrupoSolucaoCaptura value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @return nomeGrupoSolucaoCaptura
     */
    public java.lang.String getNomeGrupoSolucaoCaptura() {
        return nomeGrupoSolucaoCaptura;
    }


    /**
     * Sets the nomeGrupoSolucaoCaptura value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @param nomeGrupoSolucaoCaptura
     */
    public void setNomeGrupoSolucaoCaptura(java.lang.String nomeGrupoSolucaoCaptura) {
        this.nomeGrupoSolucaoCaptura = nomeGrupoSolucaoCaptura;
    }


    /**
     * Gets the produtosServicos value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @return produtosServicos
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.ProdutoServicoClienteType[] getProdutosServicos() {
        return produtosServicos;
    }


    /**
     * Sets the produtosServicos value for this ConsultarProdutosServicosClienteResponse.
     * 
     * @param produtosServicos
     */
    public void setProdutosServicos(br.com.cielo.service.cadastro.produto.produto.v3.ProdutoServicoClienteType[] produtosServicos) {
        this.produtosServicos = produtosServicos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarProdutosServicosClienteResponse)) return false;
        ConsultarProdutosServicosClienteResponse other = (ConsultarProdutosServicosClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoRetornoMensagem==null && other.getCodigoRetornoMensagem()==null) || 
             (this.codigoRetornoMensagem!=null &&
              this.codigoRetornoMensagem.equals(other.getCodigoRetornoMensagem()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem()))) &&
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.lojaEstabelecimento==null && other.getLojaEstabelecimento()==null) || 
             (this.lojaEstabelecimento!=null &&
              this.lojaEstabelecimento.equals(other.getLojaEstabelecimento()))) &&
            ((this.nomeGrupoSolucaoCaptura==null && other.getNomeGrupoSolucaoCaptura()==null) || 
             (this.nomeGrupoSolucaoCaptura!=null &&
              this.nomeGrupoSolucaoCaptura.equals(other.getNomeGrupoSolucaoCaptura()))) &&
            ((this.produtosServicos==null && other.getProdutosServicos()==null) || 
             (this.produtosServicos!=null &&
              java.util.Arrays.equals(this.produtosServicos, other.getProdutosServicos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoRetornoMensagem() != null) {
            _hashCode += getCodigoRetornoMensagem().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getLojaEstabelecimento() != null) {
            _hashCode += getLojaEstabelecimento().hashCode();
        }
        if (getNomeGrupoSolucaoCaptura() != null) {
            _hashCode += getNomeGrupoSolucaoCaptura().hashCode();
        }
        if (getProdutosServicos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProdutosServicos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProdutosServicos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarProdutosServicosClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarProdutosServicosClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lojaEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "lojaEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeGrupoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "nomeGrupoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("produtosServicos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtosServicos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ProdutoServicoClienteType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produtoServicoCliente"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
