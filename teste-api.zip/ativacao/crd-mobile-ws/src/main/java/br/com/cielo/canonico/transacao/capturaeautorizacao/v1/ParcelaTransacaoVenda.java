/**
 * ParcelaTransacaoVenda.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.transacao.capturaeautorizacao.v1;


/**
 * Entidade das informacoes de cada parcela da transacao de venda
 */
public class ParcelaTransacaoVenda  implements java.io.Serializable {
    /* Numero sequencial de parcela. */
    private java.math.BigInteger numeroParcela;

    /* Data de vencimento desta parcela da transacao de venda */
    private java.util.Date dataVencimentoParcela;

    /* Valor da parcela */
    private java.lang.Double valorParcela;

    /* Valor da comissao desta parcela */
    private java.lang.Double valorComissao;

    /* Valor de intercambio para esta parcela */
    private java.lang.Double valorIntercambio;

    /* Quantidade de parcelas pendentes de envio a bandeira */
    private java.math.BigInteger quantidadeParcelasPendentesEnvioBandeira;

    /* Valor pendente para envio da bandeira, Somando as parcelas. */
    private java.lang.Double valorPendenteEnvioBandeira;

    /* Contera o numero da parcela mais o total de parcelas.Ex. 1/2 */
    private java.lang.String descricaoParcela;

    /* Valor Liquido desta parcela. */
    private java.lang.Double valorLiquido;

    /* Descritivo da situacao da parcela. */
    private java.lang.String descricaoSituacaoParcela;

    public ParcelaTransacaoVenda() {
    }

    public ParcelaTransacaoVenda(
           java.math.BigInteger numeroParcela,
           java.util.Date dataVencimentoParcela,
           java.lang.Double valorParcela,
           java.lang.Double valorComissao,
           java.lang.Double valorIntercambio,
           java.math.BigInteger quantidadeParcelasPendentesEnvioBandeira,
           java.lang.Double valorPendenteEnvioBandeira,
           java.lang.String descricaoParcela,
           java.lang.Double valorLiquido,
           java.lang.String descricaoSituacaoParcela) {
           this.numeroParcela = numeroParcela;
           this.dataVencimentoParcela = dataVencimentoParcela;
           this.valorParcela = valorParcela;
           this.valorComissao = valorComissao;
           this.valorIntercambio = valorIntercambio;
           this.quantidadeParcelasPendentesEnvioBandeira = quantidadeParcelasPendentesEnvioBandeira;
           this.valorPendenteEnvioBandeira = valorPendenteEnvioBandeira;
           this.descricaoParcela = descricaoParcela;
           this.valorLiquido = valorLiquido;
           this.descricaoSituacaoParcela = descricaoSituacaoParcela;
    }


    /**
     * Gets the numeroParcela value for this ParcelaTransacaoVenda.
     * 
     * @return numeroParcela   * Numero sequencial de parcela.
     */
    public java.math.BigInteger getNumeroParcela() {
        return numeroParcela;
    }


    /**
     * Sets the numeroParcela value for this ParcelaTransacaoVenda.
     * 
     * @param numeroParcela   * Numero sequencial de parcela.
     */
    public void setNumeroParcela(java.math.BigInteger numeroParcela) {
        this.numeroParcela = numeroParcela;
    }


    /**
     * Gets the dataVencimentoParcela value for this ParcelaTransacaoVenda.
     * 
     * @return dataVencimentoParcela   * Data de vencimento desta parcela da transacao de venda
     */
    public java.util.Date getDataVencimentoParcela() {
        return dataVencimentoParcela;
    }


    /**
     * Sets the dataVencimentoParcela value for this ParcelaTransacaoVenda.
     * 
     * @param dataVencimentoParcela   * Data de vencimento desta parcela da transacao de venda
     */
    public void setDataVencimentoParcela(java.util.Date dataVencimentoParcela) {
        this.dataVencimentoParcela = dataVencimentoParcela;
    }


    /**
     * Gets the valorParcela value for this ParcelaTransacaoVenda.
     * 
     * @return valorParcela   * Valor da parcela
     */
    public java.lang.Double getValorParcela() {
        return valorParcela;
    }


    /**
     * Sets the valorParcela value for this ParcelaTransacaoVenda.
     * 
     * @param valorParcela   * Valor da parcela
     */
    public void setValorParcela(java.lang.Double valorParcela) {
        this.valorParcela = valorParcela;
    }


    /**
     * Gets the valorComissao value for this ParcelaTransacaoVenda.
     * 
     * @return valorComissao   * Valor da comissao desta parcela
     */
    public java.lang.Double getValorComissao() {
        return valorComissao;
    }


    /**
     * Sets the valorComissao value for this ParcelaTransacaoVenda.
     * 
     * @param valorComissao   * Valor da comissao desta parcela
     */
    public void setValorComissao(java.lang.Double valorComissao) {
        this.valorComissao = valorComissao;
    }


    /**
     * Gets the valorIntercambio value for this ParcelaTransacaoVenda.
     * 
     * @return valorIntercambio   * Valor de intercambio para esta parcela
     */
    public java.lang.Double getValorIntercambio() {
        return valorIntercambio;
    }


    /**
     * Sets the valorIntercambio value for this ParcelaTransacaoVenda.
     * 
     * @param valorIntercambio   * Valor de intercambio para esta parcela
     */
    public void setValorIntercambio(java.lang.Double valorIntercambio) {
        this.valorIntercambio = valorIntercambio;
    }


    /**
     * Gets the quantidadeParcelasPendentesEnvioBandeira value for this ParcelaTransacaoVenda.
     * 
     * @return quantidadeParcelasPendentesEnvioBandeira   * Quantidade de parcelas pendentes de envio a bandeira
     */
    public java.math.BigInteger getQuantidadeParcelasPendentesEnvioBandeira() {
        return quantidadeParcelasPendentesEnvioBandeira;
    }


    /**
     * Sets the quantidadeParcelasPendentesEnvioBandeira value for this ParcelaTransacaoVenda.
     * 
     * @param quantidadeParcelasPendentesEnvioBandeira   * Quantidade de parcelas pendentes de envio a bandeira
     */
    public void setQuantidadeParcelasPendentesEnvioBandeira(java.math.BigInteger quantidadeParcelasPendentesEnvioBandeira) {
        this.quantidadeParcelasPendentesEnvioBandeira = quantidadeParcelasPendentesEnvioBandeira;
    }


    /**
     * Gets the valorPendenteEnvioBandeira value for this ParcelaTransacaoVenda.
     * 
     * @return valorPendenteEnvioBandeira   * Valor pendente para envio da bandeira, Somando as parcelas.
     */
    public java.lang.Double getValorPendenteEnvioBandeira() {
        return valorPendenteEnvioBandeira;
    }


    /**
     * Sets the valorPendenteEnvioBandeira value for this ParcelaTransacaoVenda.
     * 
     * @param valorPendenteEnvioBandeira   * Valor pendente para envio da bandeira, Somando as parcelas.
     */
    public void setValorPendenteEnvioBandeira(java.lang.Double valorPendenteEnvioBandeira) {
        this.valorPendenteEnvioBandeira = valorPendenteEnvioBandeira;
    }


    /**
     * Gets the descricaoParcela value for this ParcelaTransacaoVenda.
     * 
     * @return descricaoParcela   * Contera o numero da parcela mais o total de parcelas.Ex. 1/2
     */
    public java.lang.String getDescricaoParcela() {
        return descricaoParcela;
    }


    /**
     * Sets the descricaoParcela value for this ParcelaTransacaoVenda.
     * 
     * @param descricaoParcela   * Contera o numero da parcela mais o total de parcelas.Ex. 1/2
     */
    public void setDescricaoParcela(java.lang.String descricaoParcela) {
        this.descricaoParcela = descricaoParcela;
    }


    /**
     * Gets the valorLiquido value for this ParcelaTransacaoVenda.
     * 
     * @return valorLiquido   * Valor Liquido desta parcela.
     */
    public java.lang.Double getValorLiquido() {
        return valorLiquido;
    }


    /**
     * Sets the valorLiquido value for this ParcelaTransacaoVenda.
     * 
     * @param valorLiquido   * Valor Liquido desta parcela.
     */
    public void setValorLiquido(java.lang.Double valorLiquido) {
        this.valorLiquido = valorLiquido;
    }


    /**
     * Gets the descricaoSituacaoParcela value for this ParcelaTransacaoVenda.
     * 
     * @return descricaoSituacaoParcela   * Descritivo da situacao da parcela.
     */
    public java.lang.String getDescricaoSituacaoParcela() {
        return descricaoSituacaoParcela;
    }


    /**
     * Sets the descricaoSituacaoParcela value for this ParcelaTransacaoVenda.
     * 
     * @param descricaoSituacaoParcela   * Descritivo da situacao da parcela.
     */
    public void setDescricaoSituacaoParcela(java.lang.String descricaoSituacaoParcela) {
        this.descricaoSituacaoParcela = descricaoSituacaoParcela;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ParcelaTransacaoVenda)) return false;
        ParcelaTransacaoVenda other = (ParcelaTransacaoVenda) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroParcela==null && other.getNumeroParcela()==null) || 
             (this.numeroParcela!=null &&
              this.numeroParcela.equals(other.getNumeroParcela()))) &&
            ((this.dataVencimentoParcela==null && other.getDataVencimentoParcela()==null) || 
             (this.dataVencimentoParcela!=null &&
              this.dataVencimentoParcela.equals(other.getDataVencimentoParcela()))) &&
            ((this.valorParcela==null && other.getValorParcela()==null) || 
             (this.valorParcela!=null &&
              this.valorParcela.equals(other.getValorParcela()))) &&
            ((this.valorComissao==null && other.getValorComissao()==null) || 
             (this.valorComissao!=null &&
              this.valorComissao.equals(other.getValorComissao()))) &&
            ((this.valorIntercambio==null && other.getValorIntercambio()==null) || 
             (this.valorIntercambio!=null &&
              this.valorIntercambio.equals(other.getValorIntercambio()))) &&
            ((this.quantidadeParcelasPendentesEnvioBandeira==null && other.getQuantidadeParcelasPendentesEnvioBandeira()==null) || 
             (this.quantidadeParcelasPendentesEnvioBandeira!=null &&
              this.quantidadeParcelasPendentesEnvioBandeira.equals(other.getQuantidadeParcelasPendentesEnvioBandeira()))) &&
            ((this.valorPendenteEnvioBandeira==null && other.getValorPendenteEnvioBandeira()==null) || 
             (this.valorPendenteEnvioBandeira!=null &&
              this.valorPendenteEnvioBandeira.equals(other.getValorPendenteEnvioBandeira()))) &&
            ((this.descricaoParcela==null && other.getDescricaoParcela()==null) || 
             (this.descricaoParcela!=null &&
              this.descricaoParcela.equals(other.getDescricaoParcela()))) &&
            ((this.valorLiquido==null && other.getValorLiquido()==null) || 
             (this.valorLiquido!=null &&
              this.valorLiquido.equals(other.getValorLiquido()))) &&
            ((this.descricaoSituacaoParcela==null && other.getDescricaoSituacaoParcela()==null) || 
             (this.descricaoSituacaoParcela!=null &&
              this.descricaoSituacaoParcela.equals(other.getDescricaoSituacaoParcela())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroParcela() != null) {
            _hashCode += getNumeroParcela().hashCode();
        }
        if (getDataVencimentoParcela() != null) {
            _hashCode += getDataVencimentoParcela().hashCode();
        }
        if (getValorParcela() != null) {
            _hashCode += getValorParcela().hashCode();
        }
        if (getValorComissao() != null) {
            _hashCode += getValorComissao().hashCode();
        }
        if (getValorIntercambio() != null) {
            _hashCode += getValorIntercambio().hashCode();
        }
        if (getQuantidadeParcelasPendentesEnvioBandeira() != null) {
            _hashCode += getQuantidadeParcelasPendentesEnvioBandeira().hashCode();
        }
        if (getValorPendenteEnvioBandeira() != null) {
            _hashCode += getValorPendenteEnvioBandeira().hashCode();
        }
        if (getDescricaoParcela() != null) {
            _hashCode += getDescricaoParcela().hashCode();
        }
        if (getValorLiquido() != null) {
            _hashCode += getValorLiquido().hashCode();
        }
        if (getDescricaoSituacaoParcela() != null) {
            _hashCode += getDescricaoSituacaoParcela().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ParcelaTransacaoVenda.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "ParcelaTransacaoVenda"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroParcela");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "numeroParcela"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataVencimentoParcela");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "dataVencimentoParcela"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorParcela");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorParcela"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorComissao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorComissao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorIntercambio");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorIntercambio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeParcelasPendentesEnvioBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "quantidadeParcelasPendentesEnvioBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorPendenteEnvioBandeira");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorPendenteEnvioBandeira"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoParcela");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoParcela"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorLiquido");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "valorLiquido"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "double"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoSituacaoParcela");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/transacao/capturaeautorizacao/v1", "descricaoSituacaoParcela"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
