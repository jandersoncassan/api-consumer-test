package br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente;

public class IncluirClienteServicePortTypeProxy implements br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteServicePortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteServicePortType incluirClienteServicePortType = null;
  
  public IncluirClienteServicePortTypeProxy() {
    _initIncluirClienteServicePortTypeProxy();
  }
  
  public IncluirClienteServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initIncluirClienteServicePortTypeProxy();
  }
  
  private void _initIncluirClienteServicePortTypeProxy() {
    try {
      incluirClienteServicePortType = (new br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteServiceLocator()).getIncluirClienteServiceSOAPPort();
      if (incluirClienteServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)incluirClienteServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)incluirClienteServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (incluirClienteServicePortType != null)
      ((javax.xml.rpc.Stub)incluirClienteServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteServicePortType getIncluirClienteServicePortType() {
    if (incluirClienteServicePortType == null)
      _initIncluirClienteServicePortTypeProxy();
    return incluirClienteServicePortType;
  }
  
  public br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteResponse incluirCliente(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.cadastro.solucaocaptura.solucaocaptura.v5.incluircliente.IncluirClienteRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (incluirClienteServicePortType == null)
      _initIncluirClienteServicePortTypeProxy();
    return incluirClienteServicePortType.incluirCliente(header, parameters);
  }
  
  
}