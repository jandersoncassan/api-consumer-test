/**
 * AlterarSMSClienteRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v3;

public class AlterarSMSClienteRequest  implements java.io.Serializable {
    private long codigoCliente;

    private java.lang.String dddTelefone;

    private java.lang.String numeroCliente;

    private java.lang.String protocolo;

    public AlterarSMSClienteRequest() {
    }

    public AlterarSMSClienteRequest(
           long codigoCliente,
           java.lang.String dddTelefone,
           java.lang.String numeroCliente,
           java.lang.String protocolo) {
           this.codigoCliente = codigoCliente;
           this.dddTelefone = dddTelefone;
           this.numeroCliente = numeroCliente;
           this.protocolo = protocolo;
    }


    /**
     * Gets the codigoCliente value for this AlterarSMSClienteRequest.
     * 
     * @return codigoCliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this AlterarSMSClienteRequest.
     * 
     * @param codigoCliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the dddTelefone value for this AlterarSMSClienteRequest.
     * 
     * @return dddTelefone
     */
    public java.lang.String getDddTelefone() {
        return dddTelefone;
    }


    /**
     * Sets the dddTelefone value for this AlterarSMSClienteRequest.
     * 
     * @param dddTelefone
     */
    public void setDddTelefone(java.lang.String dddTelefone) {
        this.dddTelefone = dddTelefone;
    }


    /**
     * Gets the numeroCliente value for this AlterarSMSClienteRequest.
     * 
     * @return numeroCliente
     */
    public java.lang.String getNumeroCliente() {
        return numeroCliente;
    }


    /**
     * Sets the numeroCliente value for this AlterarSMSClienteRequest.
     * 
     * @param numeroCliente
     */
    public void setNumeroCliente(java.lang.String numeroCliente) {
        this.numeroCliente = numeroCliente;
    }


    /**
     * Gets the protocolo value for this AlterarSMSClienteRequest.
     * 
     * @return protocolo
     */
    public java.lang.String getProtocolo() {
        return protocolo;
    }


    /**
     * Sets the protocolo value for this AlterarSMSClienteRequest.
     * 
     * @param protocolo
     */
    public void setProtocolo(java.lang.String protocolo) {
        this.protocolo = protocolo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AlterarSMSClienteRequest)) return false;
        AlterarSMSClienteRequest other = (AlterarSMSClienteRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.dddTelefone==null && other.getDddTelefone()==null) || 
             (this.dddTelefone!=null &&
              this.dddTelefone.equals(other.getDddTelefone()))) &&
            ((this.numeroCliente==null && other.getNumeroCliente()==null) || 
             (this.numeroCliente!=null &&
              this.numeroCliente.equals(other.getNumeroCliente()))) &&
            ((this.protocolo==null && other.getProtocolo()==null) || 
             (this.protocolo!=null &&
              this.protocolo.equals(other.getProtocolo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getDddTelefone() != null) {
            _hashCode += getDddTelefone().hashCode();
        }
        if (getNumeroCliente() != null) {
            _hashCode += getNumeroCliente().hashCode();
        }
        if (getProtocolo() != null) {
            _hashCode += getProtocolo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AlterarSMSClienteRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", ">alterarSMSClienteRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dddTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "dddTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "numeroCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("protocolo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v3/", "protocolo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
