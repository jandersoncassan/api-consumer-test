/**
 * ValidarPermissaoVendaDigitadaResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ValidarPermissaoVendaDigitadaResponse  implements java.io.Serializable {
    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    /* Tipo de Mensagem (E - Erro / A - Alerta) */
    private java.lang.String tipoMensagemRetorno;

    public ValidarPermissaoVendaDigitadaResponse() {
    }

    public ValidarPermissaoVendaDigitadaResponse(
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem,
           java.lang.String tipoMensagemRetorno) {
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
           this.tipoMensagemRetorno = tipoMensagemRetorno;
    }


    /**
     * Gets the codigoRetorno value for this ValidarPermissaoVendaDigitadaResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this ValidarPermissaoVendaDigitadaResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this ValidarPermissaoVendaDigitadaResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this ValidarPermissaoVendaDigitadaResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the tipoMensagemRetorno value for this ValidarPermissaoVendaDigitadaResponse.
     * 
     * @return tipoMensagemRetorno   * Tipo de Mensagem (E - Erro / A - Alerta)
     */
    public java.lang.String getTipoMensagemRetorno() {
        return tipoMensagemRetorno;
    }


    /**
     * Sets the tipoMensagemRetorno value for this ValidarPermissaoVendaDigitadaResponse.
     * 
     * @param tipoMensagemRetorno   * Tipo de Mensagem (E - Erro / A - Alerta)
     */
    public void setTipoMensagemRetorno(java.lang.String tipoMensagemRetorno) {
        this.tipoMensagemRetorno = tipoMensagemRetorno;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidarPermissaoVendaDigitadaResponse)) return false;
        ValidarPermissaoVendaDigitadaResponse other = (ValidarPermissaoVendaDigitadaResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem()))) &&
            ((this.tipoMensagemRetorno==null && other.getTipoMensagemRetorno()==null) || 
             (this.tipoMensagemRetorno!=null &&
              this.tipoMensagemRetorno.equals(other.getTipoMensagemRetorno())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        if (getTipoMensagemRetorno() != null) {
            _hashCode += getTipoMensagemRetorno().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidarPermissaoVendaDigitadaResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">validarPermissaoVendaDigitadaResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoMensagemRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "tipoMensagemRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
