/**
 * Moeda.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1;

public class Moeda  implements java.io.Serializable {
    private br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo codigoMoedaISO4217;

    private java.lang.String codigoSimboloMoeda;

    public Moeda() {
    }

    public Moeda(
           br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo codigoMoedaISO4217,
           java.lang.String codigoSimboloMoeda) {
           this.codigoMoedaISO4217 = codigoMoedaISO4217;
           this.codigoSimboloMoeda = codigoSimboloMoeda;
    }


    /**
     * Gets the codigoMoedaISO4217 value for this Moeda.
     * 
     * @return codigoMoedaISO4217
     */
    public br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo getCodigoMoedaISO4217() {
        return codigoMoedaISO4217;
    }


    /**
     * Sets the codigoMoedaISO4217 value for this Moeda.
     * 
     * @param codigoMoedaISO4217
     */
    public void setCodigoMoedaISO4217(br.com.cielo.canonico.administracaorecursosfinanceiros.moeda.v1.Codigo codigoMoedaISO4217) {
        this.codigoMoedaISO4217 = codigoMoedaISO4217;
    }


    /**
     * Gets the codigoSimboloMoeda value for this Moeda.
     * 
     * @return codigoSimboloMoeda
     */
    public java.lang.String getCodigoSimboloMoeda() {
        return codigoSimboloMoeda;
    }


    /**
     * Sets the codigoSimboloMoeda value for this Moeda.
     * 
     * @param codigoSimboloMoeda
     */
    public void setCodigoSimboloMoeda(java.lang.String codigoSimboloMoeda) {
        this.codigoSimboloMoeda = codigoSimboloMoeda;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Moeda)) return false;
        Moeda other = (Moeda) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoMoedaISO4217==null && other.getCodigoMoedaISO4217()==null) || 
             (this.codigoMoedaISO4217!=null &&
              this.codigoMoedaISO4217.equals(other.getCodigoMoedaISO4217()))) &&
            ((this.codigoSimboloMoeda==null && other.getCodigoSimboloMoeda()==null) || 
             (this.codigoSimboloMoeda!=null &&
              this.codigoSimboloMoeda.equals(other.getCodigoSimboloMoeda())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoMoedaISO4217() != null) {
            _hashCode += getCodigoMoedaISO4217().hashCode();
        }
        if (getCodigoSimboloMoeda() != null) {
            _hashCode += getCodigoSimboloMoeda().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Moeda.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Moeda"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoMoedaISO4217");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "codigoMoedaISO4217"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "Codigo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSimboloMoeda");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/administracaorecursosfinanceiros/moeda/v1", "codigoSimboloMoeda"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
