package br.com.cielo.service._interface.banco.banco.v1;

public class BancoPortTypeProxy implements br.com.cielo.service._interface.banco.banco.v1.BancoPortType {
  private String _endpoint = null;
  private br.com.cielo.service._interface.banco.banco.v1.BancoPortType bancoPortType = null;
  
  public BancoPortTypeProxy() {
    _initBancoPortTypeProxy();
  }
  
  public BancoPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initBancoPortTypeProxy();
  }
  
  private void _initBancoPortTypeProxy() {
    try {
      bancoPortType = (new br.com.cielo.service._interface.banco.banco.v1.BancoLocator()).getBancoSOAP();
      if (bancoPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)bancoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)bancoPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (bancoPortType != null)
      ((javax.xml.rpc.Stub)bancoPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service._interface.banco.banco.v1.BancoPortType getBancoPortType() {
    if (bancoPortType == null)
      _initBancoPortTypeProxy();
    return bancoPortType;
  }
  
  public br.com.cielo.service._interface.banco.banco.v1.ValidarDigitoAgenciaContaResponse validarDigitoAgenciaConta(br.com.cielo.service._interface.banco.banco.v1.ValidarDigitoAgenciaContaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (bancoPortType == null)
      _initBancoPortTypeProxy();
    return bancoPortType.validarDigitoAgenciaConta(parameters, header);
  }
  
  
}