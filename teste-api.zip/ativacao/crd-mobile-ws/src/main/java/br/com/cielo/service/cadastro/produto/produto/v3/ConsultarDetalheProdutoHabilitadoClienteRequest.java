/**
 * ConsultarDetalheProdutoHabilitadoClienteRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarDetalheProdutoHabilitadoClienteRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o
     * 							Cliente */
    private java.lang.Long codigoCliente;

    /* Codigo do produto oferecido pela Cielo aos seus
     * 							clientes */
    private java.math.BigInteger codigoProduto;

    public ConsultarDetalheProdutoHabilitadoClienteRequest() {
    }

    public ConsultarDetalheProdutoHabilitadoClienteRequest(
           java.lang.Long codigoCliente,
           java.math.BigInteger codigoProduto) {
           this.codigoCliente = codigoCliente;
           this.codigoProduto = codigoProduto;
    }


    /**
     * Gets the codigoCliente value for this ConsultarDetalheProdutoHabilitadoClienteRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public java.lang.Long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this ConsultarDetalheProdutoHabilitadoClienteRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public void setCodigoCliente(java.lang.Long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the codigoProduto value for this ConsultarDetalheProdutoHabilitadoClienteRequest.
     * 
     * @return codigoProduto   * Codigo do produto oferecido pela Cielo aos seus
     * 							clientes
     */
    public java.math.BigInteger getCodigoProduto() {
        return codigoProduto;
    }


    /**
     * Sets the codigoProduto value for this ConsultarDetalheProdutoHabilitadoClienteRequest.
     * 
     * @param codigoProduto   * Codigo do produto oferecido pela Cielo aos seus
     * 							clientes
     */
    public void setCodigoProduto(java.math.BigInteger codigoProduto) {
        this.codigoProduto = codigoProduto;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarDetalheProdutoHabilitadoClienteRequest)) return false;
        ConsultarDetalheProdutoHabilitadoClienteRequest other = (ConsultarDetalheProdutoHabilitadoClienteRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCliente==null && other.getCodigoCliente()==null) || 
             (this.codigoCliente!=null &&
              this.codigoCliente.equals(other.getCodigoCliente()))) &&
            ((this.codigoProduto==null && other.getCodigoProduto()==null) || 
             (this.codigoProduto!=null &&
              this.codigoProduto.equals(other.getCodigoProduto())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCliente() != null) {
            _hashCode += getCodigoCliente().hashCode();
        }
        if (getCodigoProduto() != null) {
            _hashCode += getCodigoProduto().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarDetalheProdutoHabilitadoClienteRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarDetalheProdutoHabilitadoClienteRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoProduto");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoProduto"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
