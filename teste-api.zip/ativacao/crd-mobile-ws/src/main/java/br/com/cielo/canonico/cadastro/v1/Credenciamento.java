/**
 * Credenciamento.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.cadastro.v1;

public class Credenciamento  implements java.io.Serializable {
    private java.lang.String codigoTipoCredenciamento;

    private java.util.Date dataCredenciamento;

    private java.lang.Integer codigoBanco;

    private java.lang.String numeroAgencia;

    private java.lang.String codigoRegional;

    private java.lang.String nomePlaqueta;

    private java.lang.Boolean indicadorCentroCompras;

    private java.lang.String codigoTipoTerminal;

    private java.lang.Integer quantidadeTerminal;

    public Credenciamento() {
    }

    public Credenciamento(
           java.lang.String codigoTipoCredenciamento,
           java.util.Date dataCredenciamento,
           java.lang.Integer codigoBanco,
           java.lang.String numeroAgencia,
           java.lang.String codigoRegional,
           java.lang.String nomePlaqueta,
           java.lang.Boolean indicadorCentroCompras,
           java.lang.String codigoTipoTerminal,
           java.lang.Integer quantidadeTerminal) {
           this.codigoTipoCredenciamento = codigoTipoCredenciamento;
           this.dataCredenciamento = dataCredenciamento;
           this.codigoBanco = codigoBanco;
           this.numeroAgencia = numeroAgencia;
           this.codigoRegional = codigoRegional;
           this.nomePlaqueta = nomePlaqueta;
           this.indicadorCentroCompras = indicadorCentroCompras;
           this.codigoTipoTerminal = codigoTipoTerminal;
           this.quantidadeTerminal = quantidadeTerminal;
    }


    /**
     * Gets the codigoTipoCredenciamento value for this Credenciamento.
     * 
     * @return codigoTipoCredenciamento
     */
    public java.lang.String getCodigoTipoCredenciamento() {
        return codigoTipoCredenciamento;
    }


    /**
     * Sets the codigoTipoCredenciamento value for this Credenciamento.
     * 
     * @param codigoTipoCredenciamento
     */
    public void setCodigoTipoCredenciamento(java.lang.String codigoTipoCredenciamento) {
        this.codigoTipoCredenciamento = codigoTipoCredenciamento;
    }


    /**
     * Gets the dataCredenciamento value for this Credenciamento.
     * 
     * @return dataCredenciamento
     */
    public java.util.Date getDataCredenciamento() {
        return dataCredenciamento;
    }


    /**
     * Sets the dataCredenciamento value for this Credenciamento.
     * 
     * @param dataCredenciamento
     */
    public void setDataCredenciamento(java.util.Date dataCredenciamento) {
        this.dataCredenciamento = dataCredenciamento;
    }


    /**
     * Gets the codigoBanco value for this Credenciamento.
     * 
     * @return codigoBanco
     */
    public java.lang.Integer getCodigoBanco() {
        return codigoBanco;
    }


    /**
     * Sets the codigoBanco value for this Credenciamento.
     * 
     * @param codigoBanco
     */
    public void setCodigoBanco(java.lang.Integer codigoBanco) {
        this.codigoBanco = codigoBanco;
    }


    /**
     * Gets the numeroAgencia value for this Credenciamento.
     * 
     * @return numeroAgencia
     */
    public java.lang.String getNumeroAgencia() {
        return numeroAgencia;
    }


    /**
     * Sets the numeroAgencia value for this Credenciamento.
     * 
     * @param numeroAgencia
     */
    public void setNumeroAgencia(java.lang.String numeroAgencia) {
        this.numeroAgencia = numeroAgencia;
    }


    /**
     * Gets the codigoRegional value for this Credenciamento.
     * 
     * @return codigoRegional
     */
    public java.lang.String getCodigoRegional() {
        return codigoRegional;
    }


    /**
     * Sets the codigoRegional value for this Credenciamento.
     * 
     * @param codigoRegional
     */
    public void setCodigoRegional(java.lang.String codigoRegional) {
        this.codigoRegional = codigoRegional;
    }


    /**
     * Gets the nomePlaqueta value for this Credenciamento.
     * 
     * @return nomePlaqueta
     */
    public java.lang.String getNomePlaqueta() {
        return nomePlaqueta;
    }


    /**
     * Sets the nomePlaqueta value for this Credenciamento.
     * 
     * @param nomePlaqueta
     */
    public void setNomePlaqueta(java.lang.String nomePlaqueta) {
        this.nomePlaqueta = nomePlaqueta;
    }


    /**
     * Gets the indicadorCentroCompras value for this Credenciamento.
     * 
     * @return indicadorCentroCompras
     */
    public java.lang.Boolean getIndicadorCentroCompras() {
        return indicadorCentroCompras;
    }


    /**
     * Sets the indicadorCentroCompras value for this Credenciamento.
     * 
     * @param indicadorCentroCompras
     */
    public void setIndicadorCentroCompras(java.lang.Boolean indicadorCentroCompras) {
        this.indicadorCentroCompras = indicadorCentroCompras;
    }


    /**
     * Gets the codigoTipoTerminal value for this Credenciamento.
     * 
     * @return codigoTipoTerminal
     */
    public java.lang.String getCodigoTipoTerminal() {
        return codigoTipoTerminal;
    }


    /**
     * Sets the codigoTipoTerminal value for this Credenciamento.
     * 
     * @param codigoTipoTerminal
     */
    public void setCodigoTipoTerminal(java.lang.String codigoTipoTerminal) {
        this.codigoTipoTerminal = codigoTipoTerminal;
    }


    /**
     * Gets the quantidadeTerminal value for this Credenciamento.
     * 
     * @return quantidadeTerminal
     */
    public java.lang.Integer getQuantidadeTerminal() {
        return quantidadeTerminal;
    }


    /**
     * Sets the quantidadeTerminal value for this Credenciamento.
     * 
     * @param quantidadeTerminal
     */
    public void setQuantidadeTerminal(java.lang.Integer quantidadeTerminal) {
        this.quantidadeTerminal = quantidadeTerminal;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Credenciamento)) return false;
        Credenciamento other = (Credenciamento) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTipoCredenciamento==null && other.getCodigoTipoCredenciamento()==null) || 
             (this.codigoTipoCredenciamento!=null &&
              this.codigoTipoCredenciamento.equals(other.getCodigoTipoCredenciamento()))) &&
            ((this.dataCredenciamento==null && other.getDataCredenciamento()==null) || 
             (this.dataCredenciamento!=null &&
              this.dataCredenciamento.equals(other.getDataCredenciamento()))) &&
            ((this.codigoBanco==null && other.getCodigoBanco()==null) || 
             (this.codigoBanco!=null &&
              this.codigoBanco.equals(other.getCodigoBanco()))) &&
            ((this.numeroAgencia==null && other.getNumeroAgencia()==null) || 
             (this.numeroAgencia!=null &&
              this.numeroAgencia.equals(other.getNumeroAgencia()))) &&
            ((this.codigoRegional==null && other.getCodigoRegional()==null) || 
             (this.codigoRegional!=null &&
              this.codigoRegional.equals(other.getCodigoRegional()))) &&
            ((this.nomePlaqueta==null && other.getNomePlaqueta()==null) || 
             (this.nomePlaqueta!=null &&
              this.nomePlaqueta.equals(other.getNomePlaqueta()))) &&
            ((this.indicadorCentroCompras==null && other.getIndicadorCentroCompras()==null) || 
             (this.indicadorCentroCompras!=null &&
              this.indicadorCentroCompras.equals(other.getIndicadorCentroCompras()))) &&
            ((this.codigoTipoTerminal==null && other.getCodigoTipoTerminal()==null) || 
             (this.codigoTipoTerminal!=null &&
              this.codigoTipoTerminal.equals(other.getCodigoTipoTerminal()))) &&
            ((this.quantidadeTerminal==null && other.getQuantidadeTerminal()==null) || 
             (this.quantidadeTerminal!=null &&
              this.quantidadeTerminal.equals(other.getQuantidadeTerminal())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTipoCredenciamento() != null) {
            _hashCode += getCodigoTipoCredenciamento().hashCode();
        }
        if (getDataCredenciamento() != null) {
            _hashCode += getDataCredenciamento().hashCode();
        }
        if (getCodigoBanco() != null) {
            _hashCode += getCodigoBanco().hashCode();
        }
        if (getNumeroAgencia() != null) {
            _hashCode += getNumeroAgencia().hashCode();
        }
        if (getCodigoRegional() != null) {
            _hashCode += getCodigoRegional().hashCode();
        }
        if (getNomePlaqueta() != null) {
            _hashCode += getNomePlaqueta().hashCode();
        }
        if (getIndicadorCentroCompras() != null) {
            _hashCode += getIndicadorCentroCompras().hashCode();
        }
        if (getCodigoTipoTerminal() != null) {
            _hashCode += getCodigoTipoTerminal().hashCode();
        }
        if (getQuantidadeTerminal() != null) {
            _hashCode += getQuantidadeTerminal().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Credenciamento.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Credenciamento"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoCredenciamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoTipoCredenciamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataCredenciamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "dataCredenciamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroAgencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "numeroAgencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRegional");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoRegional"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePlaqueta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "nomePlaqueta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorCentroCompras");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "indicadorCentroCompras"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "codigoTipoTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeTerminal");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "quantidadeTerminal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
