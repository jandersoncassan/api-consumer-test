/**
 * HabilitarListaProdutoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class HabilitarListaProdutoRequest  implements java.io.Serializable {
    /* Codigo adotado pela Cielo para identificar o
     * 							Cliente */
    private long codigoCliente;

    /* Informacoes dos produtos oferecido pela Cielo aos
     * 							seus clientes */
    private br.com.cielo.service.cadastro.produto.produto.v3.ProdutoType[] dadosProdutosClienteHabilitacao;

    /* Indicador de que persistência deverá ser feita
     * 							(S/N) */
    private br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequestIndicadorPersistencia indicadorPersistencia;

    /* Identificação da chave de correlação entre
     * 							serviços. */
    private java.lang.String correlationId;

    public HabilitarListaProdutoRequest() {
    }

    public HabilitarListaProdutoRequest(
           long codigoCliente,
           br.com.cielo.service.cadastro.produto.produto.v3.ProdutoType[] dadosProdutosClienteHabilitacao,
           br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequestIndicadorPersistencia indicadorPersistencia,
           java.lang.String correlationId) {
           this.codigoCliente = codigoCliente;
           this.dadosProdutosClienteHabilitacao = dadosProdutosClienteHabilitacao;
           this.indicadorPersistencia = indicadorPersistencia;
           this.correlationId = correlationId;
    }


    /**
     * Gets the codigoCliente value for this HabilitarListaProdutoRequest.
     * 
     * @return codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public long getCodigoCliente() {
        return codigoCliente;
    }


    /**
     * Sets the codigoCliente value for this HabilitarListaProdutoRequest.
     * 
     * @param codigoCliente   * Codigo adotado pela Cielo para identificar o
     * 							Cliente
     */
    public void setCodigoCliente(long codigoCliente) {
        this.codigoCliente = codigoCliente;
    }


    /**
     * Gets the dadosProdutosClienteHabilitacao value for this HabilitarListaProdutoRequest.
     * 
     * @return dadosProdutosClienteHabilitacao   * Informacoes dos produtos oferecido pela Cielo aos
     * 							seus clientes
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.ProdutoType[] getDadosProdutosClienteHabilitacao() {
        return dadosProdutosClienteHabilitacao;
    }


    /**
     * Sets the dadosProdutosClienteHabilitacao value for this HabilitarListaProdutoRequest.
     * 
     * @param dadosProdutosClienteHabilitacao   * Informacoes dos produtos oferecido pela Cielo aos
     * 							seus clientes
     */
    public void setDadosProdutosClienteHabilitacao(br.com.cielo.service.cadastro.produto.produto.v3.ProdutoType[] dadosProdutosClienteHabilitacao) {
        this.dadosProdutosClienteHabilitacao = dadosProdutosClienteHabilitacao;
    }


    /**
     * Gets the indicadorPersistencia value for this HabilitarListaProdutoRequest.
     * 
     * @return indicadorPersistencia   * Indicador de que persistência deverá ser feita
     * 							(S/N)
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequestIndicadorPersistencia getIndicadorPersistencia() {
        return indicadorPersistencia;
    }


    /**
     * Sets the indicadorPersistencia value for this HabilitarListaProdutoRequest.
     * 
     * @param indicadorPersistencia   * Indicador de que persistência deverá ser feita
     * 							(S/N)
     */
    public void setIndicadorPersistencia(br.com.cielo.service.cadastro.produto.produto.v3.HabilitarListaProdutoRequestIndicadorPersistencia indicadorPersistencia) {
        this.indicadorPersistencia = indicadorPersistencia;
    }


    /**
     * Gets the correlationId value for this HabilitarListaProdutoRequest.
     * 
     * @return correlationId   * Identificação da chave de correlação entre
     * 							serviços.
     */
    public java.lang.String getCorrelationId() {
        return correlationId;
    }


    /**
     * Sets the correlationId value for this HabilitarListaProdutoRequest.
     * 
     * @param correlationId   * Identificação da chave de correlação entre
     * 							serviços.
     */
    public void setCorrelationId(java.lang.String correlationId) {
        this.correlationId = correlationId;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof HabilitarListaProdutoRequest)) return false;
        HabilitarListaProdutoRequest other = (HabilitarListaProdutoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.codigoCliente == other.getCodigoCliente() &&
            ((this.dadosProdutosClienteHabilitacao==null && other.getDadosProdutosClienteHabilitacao()==null) || 
             (this.dadosProdutosClienteHabilitacao!=null &&
              java.util.Arrays.equals(this.dadosProdutosClienteHabilitacao, other.getDadosProdutosClienteHabilitacao()))) &&
            ((this.indicadorPersistencia==null && other.getIndicadorPersistencia()==null) || 
             (this.indicadorPersistencia!=null &&
              this.indicadorPersistencia.equals(other.getIndicadorPersistencia()))) &&
            ((this.correlationId==null && other.getCorrelationId()==null) || 
             (this.correlationId!=null &&
              this.correlationId.equals(other.getCorrelationId())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getCodigoCliente()).hashCode();
        if (getDadosProdutosClienteHabilitacao() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDadosProdutosClienteHabilitacao());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDadosProdutosClienteHabilitacao(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndicadorPersistencia() != null) {
            _hashCode += getIndicadorPersistencia().hashCode();
        }
        if (getCorrelationId() != null) {
            _hashCode += getCorrelationId().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(HabilitarListaProdutoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">habilitarListaProdutoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCliente");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoCliente"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosProdutosClienteHabilitacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosProdutosClienteHabilitacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "ProdutoType"));
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "produto"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorPersistencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "indicadorPersistencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">>habilitarListaProdutoRequest>indicadorPersistencia"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correlationId");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "correlationId"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
