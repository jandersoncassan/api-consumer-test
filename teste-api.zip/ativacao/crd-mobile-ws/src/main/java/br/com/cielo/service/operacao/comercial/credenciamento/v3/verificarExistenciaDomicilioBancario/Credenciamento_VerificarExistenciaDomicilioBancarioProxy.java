package br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario;

public class Credenciamento_VerificarExistenciaDomicilioBancarioProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancario {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancario credenciamento_VerificarExistenciaDomicilioBancario = null;
  
  public Credenciamento_VerificarExistenciaDomicilioBancarioProxy() {
    _initCredenciamento_VerificarExistenciaDomicilioBancarioProxy();
  }
  
  public Credenciamento_VerificarExistenciaDomicilioBancarioProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamento_VerificarExistenciaDomicilioBancarioProxy();
  }
  
  private void _initCredenciamento_VerificarExistenciaDomicilioBancarioProxy() {
    try {
      credenciamento_VerificarExistenciaDomicilioBancario = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancarioServiceLocator()).getCredenciamento_VerificarExistenciaDomicilioBancarioServiceSoapPort();
      if (credenciamento_VerificarExistenciaDomicilioBancario != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamento_VerificarExistenciaDomicilioBancario)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamento_VerificarExistenciaDomicilioBancario)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamento_VerificarExistenciaDomicilioBancario != null)
      ((javax.xml.rpc.Stub)credenciamento_VerificarExistenciaDomicilioBancario)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancario getCredenciamento_VerificarExistenciaDomicilioBancario() {
    if (credenciamento_VerificarExistenciaDomicilioBancario == null)
      _initCredenciamento_VerificarExistenciaDomicilioBancarioProxy();
    return credenciamento_VerificarExistenciaDomicilioBancario;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioResponse verificarExistenciaDomicilioBancario(br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamento_VerificarExistenciaDomicilioBancario == null)
      _initCredenciamento_VerificarExistenciaDomicilioBancarioProxy();
    return credenciamento_VerificarExistenciaDomicilioBancario.verificarExistenciaDomicilioBancario(parameters, header);
  }
  
  
}