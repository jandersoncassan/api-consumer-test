/**
 * ValidarDigitoAgenciaContaResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service._interface.banco.banco.v1;

public class ValidarDigitoAgenciaContaResponse  implements java.io.Serializable {
    private boolean indicadorDigitoValido;

    /* Codigo do status do processamento da mensagem. Somente será
     * preenchido
     * 							quando o valor do atributo indicadorDigitoValido for igual
     * false.
     * 							Conforme o retorno da mensagem 1074
     * 							- 1: Banco não associado;
     * 							- 2: Banco inválido;
     * 							- 3: Agência inválida;
     * 							- 4: Conta inválida; */
    private java.math.BigInteger codigoStatusProcessamento;

    public ValidarDigitoAgenciaContaResponse() {
    }

    public ValidarDigitoAgenciaContaResponse(
           boolean indicadorDigitoValido,
           java.math.BigInteger codigoStatusProcessamento) {
           this.indicadorDigitoValido = indicadorDigitoValido;
           this.codigoStatusProcessamento = codigoStatusProcessamento;
    }


    /**
     * Gets the indicadorDigitoValido value for this ValidarDigitoAgenciaContaResponse.
     * 
     * @return indicadorDigitoValido
     */
    public boolean isIndicadorDigitoValido() {
        return indicadorDigitoValido;
    }


    /**
     * Sets the indicadorDigitoValido value for this ValidarDigitoAgenciaContaResponse.
     * 
     * @param indicadorDigitoValido
     */
    public void setIndicadorDigitoValido(boolean indicadorDigitoValido) {
        this.indicadorDigitoValido = indicadorDigitoValido;
    }


    /**
     * Gets the codigoStatusProcessamento value for this ValidarDigitoAgenciaContaResponse.
     * 
     * @return codigoStatusProcessamento   * Codigo do status do processamento da mensagem. Somente será
     * preenchido
     * 							quando o valor do atributo indicadorDigitoValido for igual
     * false.
     * 							Conforme o retorno da mensagem 1074
     * 							- 1: Banco não associado;
     * 							- 2: Banco inválido;
     * 							- 3: Agência inválida;
     * 							- 4: Conta inválida;
     */
    public java.math.BigInteger getCodigoStatusProcessamento() {
        return codigoStatusProcessamento;
    }


    /**
     * Sets the codigoStatusProcessamento value for this ValidarDigitoAgenciaContaResponse.
     * 
     * @param codigoStatusProcessamento   * Codigo do status do processamento da mensagem. Somente será
     * preenchido
     * 							quando o valor do atributo indicadorDigitoValido for igual
     * false.
     * 							Conforme o retorno da mensagem 1074
     * 							- 1: Banco não associado;
     * 							- 2: Banco inválido;
     * 							- 3: Agência inválida;
     * 							- 4: Conta inválida;
     */
    public void setCodigoStatusProcessamento(java.math.BigInteger codigoStatusProcessamento) {
        this.codigoStatusProcessamento = codigoStatusProcessamento;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidarDigitoAgenciaContaResponse)) return false;
        ValidarDigitoAgenciaContaResponse other = (ValidarDigitoAgenciaContaResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.indicadorDigitoValido == other.isIndicadorDigitoValido() &&
            ((this.codigoStatusProcessamento==null && other.getCodigoStatusProcessamento()==null) || 
             (this.codigoStatusProcessamento!=null &&
              this.codigoStatusProcessamento.equals(other.getCodigoStatusProcessamento())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += (isIndicadorDigitoValido() ? Boolean.TRUE : Boolean.FALSE).hashCode();
        if (getCodigoStatusProcessamento() != null) {
            _hashCode += getCodigoStatusProcessamento().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidarDigitoAgenciaContaResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v1", ">validarDigitoAgenciaContaResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorDigitoValido");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v1", "indicadorDigitoValido"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoStatusProcessamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v1", "codigoStatusProcessamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
