/**
 * DadosPatAleloVVAType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class DadosPatAleloVVAType  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.PatAlelo patAlelo;

    private br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo;

    private br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVAType dadosTipoEstabelecimentoVVA;

    /* QUANTIDADE DE CHECKOUTS NA LOJA */
    private java.math.BigInteger checkOutsLoja;

    public DadosPatAleloVVAType() {
    }

    public DadosPatAleloVVAType(
           br.com.cielo.canonico.cadastro.v1.PatAlelo patAlelo,
           br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo,
           br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVAType dadosTipoEstabelecimentoVVA,
           java.math.BigInteger checkOutsLoja) {
           this.patAlelo = patAlelo;
           this.dadosPatAlelo = dadosPatAlelo;
           this.dadosTipoEstabelecimentoVVA = dadosTipoEstabelecimentoVVA;
           this.checkOutsLoja = checkOutsLoja;
    }


    /**
     * Gets the patAlelo value for this DadosPatAleloVVAType.
     * 
     * @return patAlelo
     */
    public br.com.cielo.canonico.cadastro.v1.PatAlelo getPatAlelo() {
        return patAlelo;
    }


    /**
     * Sets the patAlelo value for this DadosPatAleloVVAType.
     * 
     * @param patAlelo
     */
    public void setPatAlelo(br.com.cielo.canonico.cadastro.v1.PatAlelo patAlelo) {
        this.patAlelo = patAlelo;
    }


    /**
     * Gets the dadosPatAlelo value for this DadosPatAleloVVAType.
     * 
     * @return dadosPatAlelo
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType getDadosPatAlelo() {
        return dadosPatAlelo;
    }


    /**
     * Sets the dadosPatAlelo value for this DadosPatAleloVVAType.
     * 
     * @param dadosPatAlelo
     */
    public void setDadosPatAlelo(br.com.cielo.service.cadastro.produto.produto.v3.DadosPatAleloCommonType dadosPatAlelo) {
        this.dadosPatAlelo = dadosPatAlelo;
    }


    /**
     * Gets the dadosTipoEstabelecimentoVVA value for this DadosPatAleloVVAType.
     * 
     * @return dadosTipoEstabelecimentoVVA
     */
    public br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVAType getDadosTipoEstabelecimentoVVA() {
        return dadosTipoEstabelecimentoVVA;
    }


    /**
     * Sets the dadosTipoEstabelecimentoVVA value for this DadosPatAleloVVAType.
     * 
     * @param dadosTipoEstabelecimentoVVA
     */
    public void setDadosTipoEstabelecimentoVVA(br.com.cielo.service.cadastro.produto.produto.v3.DadosTipoEstabelecimentoVVAType dadosTipoEstabelecimentoVVA) {
        this.dadosTipoEstabelecimentoVVA = dadosTipoEstabelecimentoVVA;
    }


    /**
     * Gets the checkOutsLoja value for this DadosPatAleloVVAType.
     * 
     * @return checkOutsLoja   * QUANTIDADE DE CHECKOUTS NA LOJA
     */
    public java.math.BigInteger getCheckOutsLoja() {
        return checkOutsLoja;
    }


    /**
     * Sets the checkOutsLoja value for this DadosPatAleloVVAType.
     * 
     * @param checkOutsLoja   * QUANTIDADE DE CHECKOUTS NA LOJA
     */
    public void setCheckOutsLoja(java.math.BigInteger checkOutsLoja) {
        this.checkOutsLoja = checkOutsLoja;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosPatAleloVVAType)) return false;
        DadosPatAleloVVAType other = (DadosPatAleloVVAType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.patAlelo==null && other.getPatAlelo()==null) || 
             (this.patAlelo!=null &&
              this.patAlelo.equals(other.getPatAlelo()))) &&
            ((this.dadosPatAlelo==null && other.getDadosPatAlelo()==null) || 
             (this.dadosPatAlelo!=null &&
              this.dadosPatAlelo.equals(other.getDadosPatAlelo()))) &&
            ((this.dadosTipoEstabelecimentoVVA==null && other.getDadosTipoEstabelecimentoVVA()==null) || 
             (this.dadosTipoEstabelecimentoVVA!=null &&
              this.dadosTipoEstabelecimentoVVA.equals(other.getDadosTipoEstabelecimentoVVA()))) &&
            ((this.checkOutsLoja==null && other.getCheckOutsLoja()==null) || 
             (this.checkOutsLoja!=null &&
              this.checkOutsLoja.equals(other.getCheckOutsLoja())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPatAlelo() != null) {
            _hashCode += getPatAlelo().hashCode();
        }
        if (getDadosPatAlelo() != null) {
            _hashCode += getDadosPatAlelo().hashCode();
        }
        if (getDadosTipoEstabelecimentoVVA() != null) {
            _hashCode += getDadosTipoEstabelecimentoVVA().hashCode();
        }
        if (getCheckOutsLoja() != null) {
            _hashCode += getCheckOutsLoja().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosPatAleloVVAType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloVVAType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("patAlelo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "patAlelo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "PatAlelo"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosPatAlelo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosPatAlelo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosPatAleloCommonType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dadosTipoEstabelecimentoVVA");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "dadosTipoEstabelecimentoVVA"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "DadosTipoEstabelecimentoVVAType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("checkOutsLoja");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "checkOutsLoja"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
