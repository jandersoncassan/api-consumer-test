/**
 * ConsultarProdutosPrazoFlexivelResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v3;

public class ConsultarProdutosPrazoFlexivelResponse  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel grupoProdutoPrazoFlexivel;

    private java.math.BigInteger codigoRetorno;

    private java.lang.String descricaoRetornoMensagem;

    private java.lang.String proximoRegistro;  // attribute

    private java.lang.String chavePaginacao;  // attribute

    public ConsultarProdutosPrazoFlexivelResponse() {
    }

    public ConsultarProdutosPrazoFlexivelResponse(
           br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel grupoProdutoPrazoFlexivel,
           java.math.BigInteger codigoRetorno,
           java.lang.String descricaoRetornoMensagem,
           java.lang.String proximoRegistro,
           java.lang.String chavePaginacao) {
           this.grupoProdutoPrazoFlexivel = grupoProdutoPrazoFlexivel;
           this.codigoRetorno = codigoRetorno;
           this.descricaoRetornoMensagem = descricaoRetornoMensagem;
           this.proximoRegistro = proximoRegistro;
           this.chavePaginacao = chavePaginacao;
    }


    /**
     * Gets the grupoProdutoPrazoFlexivel value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @return grupoProdutoPrazoFlexivel
     */
    public br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel getGrupoProdutoPrazoFlexivel() {
        return grupoProdutoPrazoFlexivel;
    }


    /**
     * Sets the grupoProdutoPrazoFlexivel value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @param grupoProdutoPrazoFlexivel
     */
    public void setGrupoProdutoPrazoFlexivel(br.com.cielo.canonico.cadastro.v1.GrupoProdutoPrazoFlexivel grupoProdutoPrazoFlexivel) {
        this.grupoProdutoPrazoFlexivel = grupoProdutoPrazoFlexivel;
    }


    /**
     * Gets the codigoRetorno value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @return codigoRetorno
     */
    public java.math.BigInteger getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @param codigoRetorno
     */
    public void setCodigoRetorno(java.math.BigInteger codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the descricaoRetornoMensagem value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @return descricaoRetornoMensagem
     */
    public java.lang.String getDescricaoRetornoMensagem() {
        return descricaoRetornoMensagem;
    }


    /**
     * Sets the descricaoRetornoMensagem value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @param descricaoRetornoMensagem
     */
    public void setDescricaoRetornoMensagem(java.lang.String descricaoRetornoMensagem) {
        this.descricaoRetornoMensagem = descricaoRetornoMensagem;
    }


    /**
     * Gets the proximoRegistro value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @return proximoRegistro
     */
    public java.lang.String getProximoRegistro() {
        return proximoRegistro;
    }


    /**
     * Sets the proximoRegistro value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @param proximoRegistro
     */
    public void setProximoRegistro(java.lang.String proximoRegistro) {
        this.proximoRegistro = proximoRegistro;
    }


    /**
     * Gets the chavePaginacao value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @return chavePaginacao
     */
    public java.lang.String getChavePaginacao() {
        return chavePaginacao;
    }


    /**
     * Sets the chavePaginacao value for this ConsultarProdutosPrazoFlexivelResponse.
     * 
     * @param chavePaginacao
     */
    public void setChavePaginacao(java.lang.String chavePaginacao) {
        this.chavePaginacao = chavePaginacao;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarProdutosPrazoFlexivelResponse)) return false;
        ConsultarProdutosPrazoFlexivelResponse other = (ConsultarProdutosPrazoFlexivelResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.grupoProdutoPrazoFlexivel==null && other.getGrupoProdutoPrazoFlexivel()==null) || 
             (this.grupoProdutoPrazoFlexivel!=null &&
              this.grupoProdutoPrazoFlexivel.equals(other.getGrupoProdutoPrazoFlexivel()))) &&
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.descricaoRetornoMensagem==null && other.getDescricaoRetornoMensagem()==null) || 
             (this.descricaoRetornoMensagem!=null &&
              this.descricaoRetornoMensagem.equals(other.getDescricaoRetornoMensagem()))) &&
            ((this.proximoRegistro==null && other.getProximoRegistro()==null) || 
             (this.proximoRegistro!=null &&
              this.proximoRegistro.equals(other.getProximoRegistro()))) &&
            ((this.chavePaginacao==null && other.getChavePaginacao()==null) || 
             (this.chavePaginacao!=null &&
              this.chavePaginacao.equals(other.getChavePaginacao())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getGrupoProdutoPrazoFlexivel() != null) {
            _hashCode += getGrupoProdutoPrazoFlexivel().hashCode();
        }
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getDescricaoRetornoMensagem() != null) {
            _hashCode += getDescricaoRetornoMensagem().hashCode();
        }
        if (getProximoRegistro() != null) {
            _hashCode += getProximoRegistro().hashCode();
        }
        if (getChavePaginacao() != null) {
            _hashCode += getChavePaginacao().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarProdutosPrazoFlexivelResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", ">consultarProdutosPrazoFlexivelResponse"));
        org.apache.axis.description.AttributeDesc attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("proximoRegistro");
        attrField.setXmlName(new javax.xml.namespace.QName("", "proximoRegistro"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        attrField = new org.apache.axis.description.AttributeDesc();
        attrField.setFieldName("chavePaginacao");
        attrField.setXmlName(new javax.xml.namespace.QName("", "chavePaginacao"));
        attrField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        typeDesc.addFieldDesc(attrField);
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("grupoProdutoPrazoFlexivel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "grupoProdutoPrazoFlexivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "GrupoProdutoPrazoFlexivel"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoRetornoMensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v3", "descricaoRetornoMensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
