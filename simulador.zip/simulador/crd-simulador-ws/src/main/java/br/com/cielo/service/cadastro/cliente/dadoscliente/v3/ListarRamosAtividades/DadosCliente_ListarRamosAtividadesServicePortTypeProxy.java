package br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades;

public class DadosCliente_ListarRamosAtividadesServicePortTypeProxy implements br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.DadosCliente_ListarRamosAtividadesServicePortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.DadosCliente_ListarRamosAtividadesServicePortType dadosCliente_ListarRamosAtividadesServicePortType = null;
  
  public DadosCliente_ListarRamosAtividadesServicePortTypeProxy() {
    _initDadosCliente_ListarRamosAtividadesServicePortTypeProxy();
  }
  
  public DadosCliente_ListarRamosAtividadesServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initDadosCliente_ListarRamosAtividadesServicePortTypeProxy();
  }
  
  private void _initDadosCliente_ListarRamosAtividadesServicePortTypeProxy() {
    try {
      dadosCliente_ListarRamosAtividadesServicePortType = (new br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.DadosCliente_ListarRamosAtividadesServiceLocator()).getDadosCliente_ListarRamosAtividadesServiceSOAPPort();
      if (dadosCliente_ListarRamosAtividadesServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)dadosCliente_ListarRamosAtividadesServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)dadosCliente_ListarRamosAtividadesServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (dadosCliente_ListarRamosAtividadesServicePortType != null)
      ((javax.xml.rpc.Stub)dadosCliente_ListarRamosAtividadesServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.DadosCliente_ListarRamosAtividadesServicePortType getDadosCliente_ListarRamosAtividadesServicePortType() {
    if (dadosCliente_ListarRamosAtividadesServicePortType == null)
      _initDadosCliente_ListarRamosAtividadesServicePortTypeProxy();
    return dadosCliente_ListarRamosAtividadesServicePortType;
  }
  
  public br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.ListarRamosAtividadesResponse listarRamosAtividades(java.lang.Object parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (dadosCliente_ListarRamosAtividadesServicePortType == null)
      _initDadosCliente_ListarRamosAtividadesServicePortTypeProxy();
    return dadosCliente_ListarRamosAtividadesServicePortType.listarRamosAtividades(parameters, header);
  }
  
  
}