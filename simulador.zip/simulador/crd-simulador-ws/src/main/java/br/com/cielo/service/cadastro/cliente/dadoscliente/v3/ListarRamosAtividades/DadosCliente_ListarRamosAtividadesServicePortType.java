/**
 * DadosCliente_ListarRamosAtividadesServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades;

public interface DadosCliente_ListarRamosAtividadesServicePortType extends java.rmi.Remote {

    /**
     * Operacao responsavel por listar os Ramos de Atividade.
     */
    public br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.ListarRamosAtividadesResponse listarRamosAtividades(java.lang.Object parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
