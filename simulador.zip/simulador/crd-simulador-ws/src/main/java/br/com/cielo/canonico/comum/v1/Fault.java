/**
 * Fault.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.comum.v1;


/**
 * Entidade do modelo canonico corporativo, tem como funcao padronizar
 * o layout de excecoes.
 * 				Versao: 1.0
 * 				Autor: Andre Souza
 * 	
 * 				Historico de revisao:
 * 				1.0 25-06.2014 Criacao da Entidade
 */
public class Fault  extends org.apache.axis.AxisFault  implements java.io.Serializable {
    private java.lang.String codigo;

    private java.lang.String descricao;

    private br.com.cielo.canonico.comum.v1.Tipo tipo;

    private java.lang.String sistemaOrigem;

    private java.lang.String servicoOrigem;

    private br.com.cielo.canonico.comum.v1.FaultDetail detalhe;

    public Fault() {
    }

    public Fault(
           java.lang.String codigo,
           java.lang.String descricao,
           br.com.cielo.canonico.comum.v1.Tipo tipo,
           java.lang.String sistemaOrigem,
           java.lang.String servicoOrigem,
           br.com.cielo.canonico.comum.v1.FaultDetail detalhe) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.tipo = tipo;
        this.sistemaOrigem = sistemaOrigem;
        this.servicoOrigem = servicoOrigem;
        this.detalhe = detalhe;
    }


    /**
     * Gets the codigo value for this Fault.
     * 
     * @return codigo
     */
    public java.lang.String getCodigo() {
        return codigo;
    }


    /**
     * Sets the codigo value for this Fault.
     * 
     * @param codigo
     */
    public void setCodigo(java.lang.String codigo) {
        this.codigo = codigo;
    }


    /**
     * Gets the descricao value for this Fault.
     * 
     * @return descricao
     */
    public java.lang.String getDescricao() {
        return descricao;
    }


    /**
     * Sets the descricao value for this Fault.
     * 
     * @param descricao
     */
    public void setDescricao(java.lang.String descricao) {
        this.descricao = descricao;
    }


    /**
     * Gets the tipo value for this Fault.
     * 
     * @return tipo
     */
    public br.com.cielo.canonico.comum.v1.Tipo getTipo() {
        return tipo;
    }


    /**
     * Sets the tipo value for this Fault.
     * 
     * @param tipo
     */
    public void setTipo(br.com.cielo.canonico.comum.v1.Tipo tipo) {
        this.tipo = tipo;
    }


    /**
     * Gets the sistemaOrigem value for this Fault.
     * 
     * @return sistemaOrigem
     */
    public java.lang.String getSistemaOrigem() {
        return sistemaOrigem;
    }


    /**
     * Sets the sistemaOrigem value for this Fault.
     * 
     * @param sistemaOrigem
     */
    public void setSistemaOrigem(java.lang.String sistemaOrigem) {
        this.sistemaOrigem = sistemaOrigem;
    }


    /**
     * Gets the servicoOrigem value for this Fault.
     * 
     * @return servicoOrigem
     */
    public java.lang.String getServicoOrigem() {
        return servicoOrigem;
    }


    /**
     * Sets the servicoOrigem value for this Fault.
     * 
     * @param servicoOrigem
     */
    public void setServicoOrigem(java.lang.String servicoOrigem) {
        this.servicoOrigem = servicoOrigem;
    }


    /**
     * Gets the detalhe value for this Fault.
     * 
     * @return detalhe
     */
    public br.com.cielo.canonico.comum.v1.FaultDetail getDetalhe() {
        return detalhe;
    }


    /**
     * Sets the detalhe value for this Fault.
     * 
     * @param detalhe
     */
    public void setDetalhe(br.com.cielo.canonico.comum.v1.FaultDetail detalhe) {
        this.detalhe = detalhe;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Fault)) return false;
        Fault other = (Fault) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigo==null && other.getCodigo()==null) || 
             (this.codigo!=null &&
              this.codigo.equals(other.getCodigo()))) &&
            ((this.descricao==null && other.getDescricao()==null) || 
             (this.descricao!=null &&
              this.descricao.equals(other.getDescricao()))) &&
            ((this.tipo==null && other.getTipo()==null) || 
             (this.tipo!=null &&
              this.tipo.equals(other.getTipo()))) &&
            ((this.sistemaOrigem==null && other.getSistemaOrigem()==null) || 
             (this.sistemaOrigem!=null &&
              this.sistemaOrigem.equals(other.getSistemaOrigem()))) &&
            ((this.servicoOrigem==null && other.getServicoOrigem()==null) || 
             (this.servicoOrigem!=null &&
              this.servicoOrigem.equals(other.getServicoOrigem()))) &&
            ((this.detalhe==null && other.getDetalhe()==null) || 
             (this.detalhe!=null &&
              this.detalhe.equals(other.getDetalhe())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigo() != null) {
            _hashCode += getCodigo().hashCode();
        }
        if (getDescricao() != null) {
            _hashCode += getDescricao().hashCode();
        }
        if (getTipo() != null) {
            _hashCode += getTipo().hashCode();
        }
        if (getSistemaOrigem() != null) {
            _hashCode += getSistemaOrigem().hashCode();
        }
        if (getServicoOrigem() != null) {
            _hashCode += getServicoOrigem().hashCode();
        }
        if (getDetalhe() != null) {
            _hashCode += getDetalhe().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Fault.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Fault"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "codigo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "descricao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "tipo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "Tipo"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("sistemaOrigem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "sistemaOrigem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("servicoOrigem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "servicoOrigem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("detalhe");
        elemField.setXmlName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "detalhe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/comum/v1", "FaultDetail"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }


    /**
     * Writes the exception data to the faultDetails
     */
    public void writeDetails(javax.xml.namespace.QName qname, org.apache.axis.encoding.SerializationContext context) throws java.io.IOException {
        context.serialize(qname, null, this);
    }
}
