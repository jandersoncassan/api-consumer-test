/**
 * StatusProcessamentoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades;

public class StatusProcessamentoType  implements java.io.Serializable {
    /* Código de retorno. */
    private java.lang.Integer codigoRetorno;

    /* 1 – Success | 2 – Error, no caso do 2 */
    private java.lang.String statusProcessamento;

    /* Mensagem caso aconteça algum erro. */
    private java.lang.String mensagem;

    public StatusProcessamentoType() {
    }

    public StatusProcessamentoType(
           java.lang.Integer codigoRetorno,
           java.lang.String statusProcessamento,
           java.lang.String mensagem) {
           this.codigoRetorno = codigoRetorno;
           this.statusProcessamento = statusProcessamento;
           this.mensagem = mensagem;
    }


    /**
     * Gets the codigoRetorno value for this StatusProcessamentoType.
     * 
     * @return codigoRetorno   * Código de retorno.
     */
    public java.lang.Integer getCodigoRetorno() {
        return codigoRetorno;
    }


    /**
     * Sets the codigoRetorno value for this StatusProcessamentoType.
     * 
     * @param codigoRetorno   * Código de retorno.
     */
    public void setCodigoRetorno(java.lang.Integer codigoRetorno) {
        this.codigoRetorno = codigoRetorno;
    }


    /**
     * Gets the statusProcessamento value for this StatusProcessamentoType.
     * 
     * @return statusProcessamento   * 1 – Success | 2 – Error, no caso do 2
     */
    public java.lang.String getStatusProcessamento() {
        return statusProcessamento;
    }


    /**
     * Sets the statusProcessamento value for this StatusProcessamentoType.
     * 
     * @param statusProcessamento   * 1 – Success | 2 – Error, no caso do 2
     */
    public void setStatusProcessamento(java.lang.String statusProcessamento) {
        this.statusProcessamento = statusProcessamento;
    }


    /**
     * Gets the mensagem value for this StatusProcessamentoType.
     * 
     * @return mensagem   * Mensagem caso aconteça algum erro.
     */
    public java.lang.String getMensagem() {
        return mensagem;
    }


    /**
     * Sets the mensagem value for this StatusProcessamentoType.
     * 
     * @param mensagem   * Mensagem caso aconteça algum erro.
     */
    public void setMensagem(java.lang.String mensagem) {
        this.mensagem = mensagem;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof StatusProcessamentoType)) return false;
        StatusProcessamentoType other = (StatusProcessamentoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoRetorno==null && other.getCodigoRetorno()==null) || 
             (this.codigoRetorno!=null &&
              this.codigoRetorno.equals(other.getCodigoRetorno()))) &&
            ((this.statusProcessamento==null && other.getStatusProcessamento()==null) || 
             (this.statusProcessamento!=null &&
              this.statusProcessamento.equals(other.getStatusProcessamento()))) &&
            ((this.mensagem==null && other.getMensagem()==null) || 
             (this.mensagem!=null &&
              this.mensagem.equals(other.getMensagem())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoRetorno() != null) {
            _hashCode += getCodigoRetorno().hashCode();
        }
        if (getStatusProcessamento() != null) {
            _hashCode += getStatusProcessamento().hashCode();
        }
        if (getMensagem() != null) {
            _hashCode += getMensagem().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(StatusProcessamentoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v3/ListarRamosAtividades", "StatusProcessamentoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRetorno");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v3/ListarRamosAtividades", "codigoRetorno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("statusProcessamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v3/ListarRamosAtividades", "statusProcessamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mensagem");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/dadoscliente/v3/ListarRamosAtividades", "mensagem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
