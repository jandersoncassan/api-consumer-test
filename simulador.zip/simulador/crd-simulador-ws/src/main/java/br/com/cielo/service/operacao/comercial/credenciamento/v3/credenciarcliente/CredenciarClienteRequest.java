/**
 * CredenciarClienteRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente;

public class CredenciarClienteRequest  implements java.io.Serializable {
    /* 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE */
    private java.lang.Integer codigoFerramenta;

    private java.lang.String indicadorAgro;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucoesCaptura solucoesCaptura;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EstabelecimentoComercialType estabelecimentoComercial;

    private java.lang.String correlationID;

    private java.lang.String loginUsuario;

    private java.lang.Integer codigoTipoPerfilSmart;

    private java.lang.String nomeExecutivo;

    public CredenciarClienteRequest() {
    }

    public CredenciarClienteRequest(
           java.lang.Integer codigoFerramenta,
           java.lang.String indicadorAgro,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucoesCaptura solucoesCaptura,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EstabelecimentoComercialType estabelecimentoComercial,
           java.lang.String correlationID,
           java.lang.String loginUsuario,
           java.lang.Integer codigoTipoPerfilSmart,
           java.lang.String nomeExecutivo) {
           this.codigoFerramenta = codigoFerramenta;
           this.indicadorAgro = indicadorAgro;
           this.solucoesCaptura = solucoesCaptura;
           this.estabelecimentoComercial = estabelecimentoComercial;
           this.correlationID = correlationID;
           this.loginUsuario = loginUsuario;
           this.codigoTipoPerfilSmart = codigoTipoPerfilSmart;
           this.nomeExecutivo = nomeExecutivo;
    }


    /**
     * Gets the codigoFerramenta value for this CredenciarClienteRequest.
     * 
     * @return codigoFerramenta   * 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE
     */
    public java.lang.Integer getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this CredenciarClienteRequest.
     * 
     * @param codigoFerramenta   * 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE
     */
    public void setCodigoFerramenta(java.lang.Integer codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the indicadorAgro value for this CredenciarClienteRequest.
     * 
     * @return indicadorAgro
     */
    public java.lang.String getIndicadorAgro() {
        return indicadorAgro;
    }


    /**
     * Sets the indicadorAgro value for this CredenciarClienteRequest.
     * 
     * @param indicadorAgro
     */
    public void setIndicadorAgro(java.lang.String indicadorAgro) {
        this.indicadorAgro = indicadorAgro;
    }


    /**
     * Gets the solucoesCaptura value for this CredenciarClienteRequest.
     * 
     * @return solucoesCaptura
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucoesCaptura getSolucoesCaptura() {
        return solucoesCaptura;
    }


    /**
     * Sets the solucoesCaptura value for this CredenciarClienteRequest.
     * 
     * @param solucoesCaptura
     */
    public void setSolucoesCaptura(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucoesCaptura solucoesCaptura) {
        this.solucoesCaptura = solucoesCaptura;
    }


    /**
     * Gets the estabelecimentoComercial value for this CredenciarClienteRequest.
     * 
     * @return estabelecimentoComercial
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EstabelecimentoComercialType getEstabelecimentoComercial() {
        return estabelecimentoComercial;
    }


    /**
     * Sets the estabelecimentoComercial value for this CredenciarClienteRequest.
     * 
     * @param estabelecimentoComercial
     */
    public void setEstabelecimentoComercial(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EstabelecimentoComercialType estabelecimentoComercial) {
        this.estabelecimentoComercial = estabelecimentoComercial;
    }


    /**
     * Gets the correlationID value for this CredenciarClienteRequest.
     * 
     * @return correlationID
     */
    public java.lang.String getCorrelationID() {
        return correlationID;
    }


    /**
     * Sets the correlationID value for this CredenciarClienteRequest.
     * 
     * @param correlationID
     */
    public void setCorrelationID(java.lang.String correlationID) {
        this.correlationID = correlationID;
    }


    /**
     * Gets the loginUsuario value for this CredenciarClienteRequest.
     * 
     * @return loginUsuario
     */
    public java.lang.String getLoginUsuario() {
        return loginUsuario;
    }


    /**
     * Sets the loginUsuario value for this CredenciarClienteRequest.
     * 
     * @param loginUsuario
     */
    public void setLoginUsuario(java.lang.String loginUsuario) {
        this.loginUsuario = loginUsuario;
    }


    /**
     * Gets the codigoTipoPerfilSmart value for this CredenciarClienteRequest.
     * 
     * @return codigoTipoPerfilSmart
     */
    public java.lang.Integer getCodigoTipoPerfilSmart() {
        return codigoTipoPerfilSmart;
    }


    /**
     * Sets the codigoTipoPerfilSmart value for this CredenciarClienteRequest.
     * 
     * @param codigoTipoPerfilSmart
     */
    public void setCodigoTipoPerfilSmart(java.lang.Integer codigoTipoPerfilSmart) {
        this.codigoTipoPerfilSmart = codigoTipoPerfilSmart;
    }


    /**
     * Gets the nomeExecutivo value for this CredenciarClienteRequest.
     * 
     * @return nomeExecutivo
     */
    public java.lang.String getNomeExecutivo() {
        return nomeExecutivo;
    }


    /**
     * Sets the nomeExecutivo value for this CredenciarClienteRequest.
     * 
     * @param nomeExecutivo
     */
    public void setNomeExecutivo(java.lang.String nomeExecutivo) {
        this.nomeExecutivo = nomeExecutivo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CredenciarClienteRequest)) return false;
        CredenciarClienteRequest other = (CredenciarClienteRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoFerramenta==null && other.getCodigoFerramenta()==null) || 
             (this.codigoFerramenta!=null &&
              this.codigoFerramenta.equals(other.getCodigoFerramenta()))) &&
            ((this.indicadorAgro==null && other.getIndicadorAgro()==null) || 
             (this.indicadorAgro!=null &&
              this.indicadorAgro.equals(other.getIndicadorAgro()))) &&
            ((this.solucoesCaptura==null && other.getSolucoesCaptura()==null) || 
             (this.solucoesCaptura!=null &&
              this.solucoesCaptura.equals(other.getSolucoesCaptura()))) &&
            ((this.estabelecimentoComercial==null && other.getEstabelecimentoComercial()==null) || 
             (this.estabelecimentoComercial!=null &&
              this.estabelecimentoComercial.equals(other.getEstabelecimentoComercial()))) &&
            ((this.correlationID==null && other.getCorrelationID()==null) || 
             (this.correlationID!=null &&
              this.correlationID.equals(other.getCorrelationID()))) &&
            ((this.loginUsuario==null && other.getLoginUsuario()==null) || 
             (this.loginUsuario!=null &&
              this.loginUsuario.equals(other.getLoginUsuario()))) &&
            ((this.codigoTipoPerfilSmart==null && other.getCodigoTipoPerfilSmart()==null) || 
             (this.codigoTipoPerfilSmart!=null &&
              this.codigoTipoPerfilSmart.equals(other.getCodigoTipoPerfilSmart()))) &&
            ((this.nomeExecutivo==null && other.getNomeExecutivo()==null) || 
             (this.nomeExecutivo!=null &&
              this.nomeExecutivo.equals(other.getNomeExecutivo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoFerramenta() != null) {
            _hashCode += getCodigoFerramenta().hashCode();
        }
        if (getIndicadorAgro() != null) {
            _hashCode += getIndicadorAgro().hashCode();
        }
        if (getSolucoesCaptura() != null) {
            _hashCode += getSolucoesCaptura().hashCode();
        }
        if (getEstabelecimentoComercial() != null) {
            _hashCode += getEstabelecimentoComercial().hashCode();
        }
        if (getCorrelationID() != null) {
            _hashCode += getCorrelationID().hashCode();
        }
        if (getLoginUsuario() != null) {
            _hashCode += getLoginUsuario().hashCode();
        }
        if (getCodigoTipoPerfilSmart() != null) {
            _hashCode += getCodigoTipoPerfilSmart().hashCode();
        }
        if (getNomeExecutivo() != null) {
            _hashCode += getNomeExecutivo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CredenciarClienteRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", ">credenciarClienteRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAgro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "indicadorAgro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucoesCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "solucoesCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "solucoesCaptura"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "estabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "estabelecimentoComercialType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("correlationID");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "correlationID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loginUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "loginUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPerfilSmart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoTipoPerfilSmart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeExecutivo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomeExecutivo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
