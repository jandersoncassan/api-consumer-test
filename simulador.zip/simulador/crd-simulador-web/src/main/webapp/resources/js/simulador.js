$(function() {
	//TRATAMENTO CAMPO DATA 
	$('.datePicker')
			.datepicker(
					{
						dateFormat : "dd/mm/yy",
						weekStart : 0,
						yearRange: "-100:+0", 
						todayBtn : true,
						language : "pt-BR",
						multidateSeparator : ",",
						monthNames : [ "Janeiro", "Fevereiro", "Mar&ccedil;o",
								"Abril", "Maio", "Junho", "Julho", "Agosto",
								"Setembro", "Outubro", "Novembro", "Dezembro" ],
						monthNamesShort : [ "Jan", "Fev", "Mar", "Abr", "Mai",
								"Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez" ],
						dayNamesMin : [ "Dom", "Seg", "Ter", "Qua", "Qui",
								"Sex", "S&aacute;b" ],
						changeMonth : true,
						changeYear : true,
						onClose : function() {
							var reg = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[012])\/((1|2)[0-9][0-9]{2})$/;
							var date = $(this).val();
							if (date != '' && !date.match(reg)) {
								$(this)
										.after(
												'<div class="msgDateError alert alert-danger" role="alert"><i class="glyphicon glyphicon-exclamation-sign"></i>'
														+ unescape('&nbsp;Data inv&#225;lida !')
														+ '</div>');
								$(this).val('');
								setTimeout(function() {
									$('.msgDateError').fadeOut('600');
								}, 3000);
							}
							;
						}
					});

	$("#instFinanceira").hide();
	//MASCARA TRATAMENTO CAMPO NUMERICO
	$(".onlyNumber").keypress(function(e) {
		if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			/*
			 * $("#errmsg").html("Somente
			 * numeros").addClass("color","red").show().fadeOut("slow");
			 */
			return false;
		}
	});

	//INFORMACOES COMPLEMENTARES BANCOS ONLINE / SITE	
	hideFieldsTipoFerramenta = function(){
		var $tipoFerramenta = $('#tipoFerramenta').val();
		if($tipoFerramenta == ''){
			$(".complementar").hide();
			$(".codigoAfiliador").hide();
			$(".perfilSmart").hide();
			$(".indicadorAgro").hide(); 
			$(".enderecoNumero").hide();
			$(".qtdadeEquipamento").hide();
			$(".emailContato").hide();
			$(".indicadorPagamentoPorLink").hide();
		}
	}
	hideFieldsTipoFerramenta();
	//SITE
	showFieldsSite = function(){
		//SHOW
		$(".codigoAfiliador").show();
		$(".emailContato").show();
		$(".qtdadeEquipamento").show();
		$(".enderecoNumero").show();
		$(".indicadorPagamentoPorLink").show();
		//HIDE
		//$(".numInstituicao").hide();
		$(".indicadorAgro").hide();
		$(".perfilSmart").hide();
	}
	
	//BANCOS ONLINE 
	showFieldsBancosOnline = function(){
		//SHOW
		//$(".numInstituicao").show();
		$(".indicadorAgro").show();
		//HIDE
		$(".indicadorPagamentoPorLink").hide();
		$(".codigoAfiliador").hide();
		$(".perfilSmart").hide();
		$(".qtdadeEquipamento").hide();
		$(".enderecoNumero").hide();
		$(".emailContato").hide();
	}
	
	//SMART
	showFieldsSmart = function(){
		showFieldsSite();
		$(".perfilSmart").show();
	}
	
	//TIPO FERRAMENTA
	$('#tipoFerramenta').change(function() {
		var valueTpFerramenta = $(this).val();
		//BANCOS ONLINE
		if (valueTpFerramenta == '2') {
			$(".complementar").show();
			showFieldsBancosOnline();
		//SITE E OUTROS
		}else if(valueTpFerramenta == '3' || valueTpFerramenta == '4' || valueTpFerramenta == '5' || valueTpFerramenta == '6'){
			$(".complementar").show();			
			showFieldsSite();
			
		}else if(valueTpFerramenta == '7'){
			$(".complementar").show();
			showFieldsSmart();
			
		}else{
			hideFieldsTipoFerramenta();
		}
	});

	
	var valueTpFerramenta = $("#tipoFerramenta").val(); 
	if (valueTpFerramenta == '2') {
		$(".complementar").show();
		showFieldsBancosOnline();
	}else if(valueTpFerramenta == '3' || valueTpFerramenta == '4' || valueTpFerramenta == '5' || valueTpFerramenta == '6'){
		$(".complementar").show();
		showFieldsSite();
	}
	
	// CLIENTE MEI
	$("#clienteMei").hide();

	// TRATAMENTO CAMPO CPFCNPJ DE ACORDO COM O TIPO DE PESSOA SELECIONADO
	$("#numCpfCnpj").prop("disabled", true);

	$('#tipoPessoa').change(function() {
		$("#numCpfCnpj").val('');
		var valueTpPessoa = $(this).val();
		if (tipoPessoaSelected(valueTpPessoa)) {
			if (valueTpPessoa == 'F') {
				$("#numCpfCnpj").mask("999.999.999-99");
				$("#clienteMei").hide();
			} else if(valueTpPessoa == 'J'){
				$("#numCpfCnpj").mask("99.999.999/9999-99");
				$("#clienteMei").show();
			}
			$("#numCpfCnpj").prop("disabled", false);
		}
	});

	var valorTpPessoa = $('#tipoPessoa').val();
	if(valorTpPessoa != ""){
		$("#numCpfCnpj").prop("disabled", false);
		if(valorTpPessoa =="F"){
			$("#numCpfCnpj").mask("999.999.999-99");
		}else{
			$("#numCpfCnpj").mask("99.999.999/9999-99");
		}
	}

	// TRATMENTO CAMPO TIPO PESSOA
	tipoPessoaSelected = function(val) {
		if (val == '') {
			$("#numCpfCnpj").prop("disabled", true);
			$("#clienteMei").hide();
			return false;
		}
		return true;
	}
	
	// TRATAMENTO BLOCO ENDERECO CORRESPONDECIA
	$("#chkEndDuplicar").prop('checked', true);
	$("#endCorrespondecia").hide();

	//CORRESPONDENCIA
	$("#chkEndDuplicar").change(function() {
		if ($(this).is(':checked')) {
			$("#endCorrespondecia").hide();
		} else {
			$("#endCorrespondecia").show();
			$("#logradourroCorrespondencia").val('');
			$("#complementoCorrespondencia").val('');
			$("#cidadeCorrespondencia").val('');
			$("#estadoCorrespondencia").val('');
			$("#cepCorrespondencia").val('');
		}
	});
	

	//CORRESPONDENCIA
	$("#chkIndOfertaAssociada").change(function() {
		if ($(this).is(':checked')) {
			$('.ofertaCondicional').removeClass('hide');
		} else {
			$('.ofertaCondicional').addClass('hide');
			$("#nivelOferta").val('');
			$("#codigoOferta").val('');
			$('#chkIndAceiteOferta').prop('checked', false);
		}
	});
	
	
	//ENCADEAMENTO	
	$("#chkIndEncadeamento").change(function() {
		if ($(this).is(':checked')) {
			$('.infoEncadeamento').removeClass('hide');
		} else {
			$('.infoEncadeamento').addClass('hide');
		}
	});
	
	//TRATAMENTO PLANO CONTA
	tratarPlanoCielo = function(prop, valueInput, valueOption){
		$(".ctrlDisabled").prop("disabled", prop);	
		$("#fxFaturamento").val(valueInput);
		$("#qtdadeDias").val(valueOption);
	}

	//MASCARA CAMPOS
	$(".maskCep").mask("99999-999")
	$(".maskCpf").mask("999.999.999-99");
	$("#fxFaturamento").mask("##.###.###.##0,00", {reverse: true});
	$("#taxaArv").mask("#0,00", {reverse: true});	
	
	
	$(".ddd").mask("(##)");
	var lengthDDD = $(".ddd").val().length;
	if(lengthDDD==3){
		$(".ddd").val($(".ddd").val()+")"); 
	}
	
	$(".telComercial").mask("#0000-0000");
	$(".telCelular").mask("#0000-0000"); 
	
	$(".telComercial").on("keyup", function(){
		var tamanho = $(this).val().length;
		if(tamanho > 10){
			$(this).val($(this).val().substring(0,10));
		}
	});
	$(".telCelular").on("keyup", function(){
		var tamanho = $(this).val().length;
		if(tamanho > 10){
			$(this).val($(this).val().substring(0,10));
		}
	});

	
	//TRATAR CARACTERES ESPECIAIS
	$(".ascii").on("change paste keyup onkeypress", function(event) {
		var value = foldToASCII(event.target.value).toUpperCase();
		value = value.replace(/[^0-9A-Za-z -]/g,'')
		event.target.value = value;
	});

	//TRATAR CAMPO INSTITUICAO
	tratarCamposObrigatorios = function(){
		var ferramenta = $("#tipoFerramenta").val();
		//BANCOS ONLINE
		if(ferramenta == 2){
			$("#emailContato").val(" ")
		}
		//SITE
		if(ferramenta == 3  || ferramenta == 4 || ferramenta == 5 || ferramenta == 6){
			$("#numInstituicao").val(" "); 
		}
	}
	
	//SUBMIT FORM	
	$('form').bind('submit', function(){
	    //$(this).find('.ctrlDisabled').prop('disabled', false);
		$(this).prop("disabled", true);
	    $(".loader").show();
	    $(".panel").css({ opacity: 0.4 }); 
	    tratarCamposObrigatorios();
	});

	$(".loader").hide();
	
	if (typeof (history.pushState) != "undefined"){	
		var protocol = window.location.protocol;
		var host= window.location.host;
        var obj = { Title: "CRD-Simulador", Url:  protocol+'//'+host+'/'+"crd-simulador/"};
        history.pushState(obj, obj.Title, obj.Url);
    } else {
        console.log("Browser does not support HTML5.");
    }
	
});