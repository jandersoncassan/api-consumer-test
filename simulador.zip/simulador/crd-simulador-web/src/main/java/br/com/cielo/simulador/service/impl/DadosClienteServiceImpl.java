package br.com.cielo.simulador.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.model.Cliente;
import br.com.cielo.simulador.model.DadosFixos;
import br.com.cielo.simulador.model.DomicilioBancario;
import br.com.cielo.simulador.model.Endereco;
import br.com.cielo.simulador.model.Proprietario;
import br.com.cielo.simulador.model.SolucaoCapturaPlano;
import br.com.cielo.simulador.model.Telefone;
import br.com.cielo.simulador.service.IClientService;
import br.com.cielo.simulador.service.IDadosClienteService;
import br.com.cielo.simulador.service.IDadosFixos;
import br.com.cielo.simulador.service.IDomicilioBancarioService;
import br.com.cielo.simulador.service.IEnderecoService;
import br.com.cielo.simulador.service.IProprietarioService;
import br.com.cielo.simulador.service.ISolucaoCapturaService;
import br.com.cielo.simulador.service.ITelefoneService;

@Service
public class DadosClienteServiceImpl implements IDadosClienteService{

	private static final Logger LOG = LoggerFactory.getLogger(DadosClienteServiceImpl.class);

	@Autowired
	private IDadosFixos dadosFixosService;
	
	@Autowired
	private IClientService clienteService;
	
	@Autowired
	private IDomicilioBancarioService domBancarioService;
	
	@Autowired
	private ISolucaoCapturaService solucaoCapturaService;
	
	@Autowired
	private IEnderecoService enderecoService;
	
	@Autowired
	private ITelefoneService telefoneService;
	
	@Autowired
	private IProprietarioService proprietarioService;

	@Override
	public void tratarInfoCredenciamento(CredenciamentoDTO infoCredenciamento, StringBuffer messageCics) {
		initPopularDadosCliente(infoCredenciamento, messageCics);
	}
	
	/**
	 * Método responsavel pelas consiostências das informações de credenciamento
	 * @param infoCredenciamento
	 * @param messageCics
	 */
	private void initPopularDadosCliente(CredenciamentoDTO infoCredenciamento, StringBuffer messageCics){
		LOG.info("INIT POPULAR INFORMACOES CREDENCIAMENTO");
		tratarInfoDadosFixos(messageCics, new DadosFixos());
		tratarInfoCliente(messageCics, infoCredenciamento.getCliente());
		tratarInfoDomBancario(messageCics, infoCredenciamento.getDomicilioBancario());
		tratarInfoSolCaptura(messageCics, infoCredenciamento.getSolPlano());
		tratarInfoEndereco(messageCics, infoCredenciamento.getEndereco());
		tratarInfoTelefone(messageCics, infoCredenciamento.getTelefone());
		tratarInfoProprietarios(messageCics, infoCredenciamento.getProprietario());
	}

	/**
	 * Método responsavel por tratar as informações do Cliente
	 * @param messageCics
	 * @param cliente
	 */
	private void tratarInfoDadosFixos(StringBuffer messageCics, DadosFixos dadosFixos){
		dadosFixosService.tratarInformacoes(messageCics, dadosFixos);		
	}

	/**
	 * Método responsavel por tratar as informações do Cliente
	 * @param messageCics
	 * @param cliente
	 */
	private void tratarInfoCliente(StringBuffer messageCics, Cliente cliente){
		clienteService.tratarInformacoes(messageCics, cliente);		
	}
	
	/**
	 * Método responsavel por tratar as informações de Domicilio Bancario
	 * @param messageCics
	 * @param domBancario
	 */
	private void tratarInfoDomBancario(StringBuffer messageCics, DomicilioBancario domBancario){
		domBancarioService.tratarInformacoes(messageCics, domBancario);		
	}
	
	/**
	 * Método responsavel por tratar as informações de Solução Captura
	 * @param messageCics
	 * @param solCaptura
	 */
	private void tratarInfoSolCaptura(StringBuffer messageCics, SolucaoCapturaPlano solCaptura){
		solucaoCapturaService.tratarInformacoes(messageCics, solCaptura);		
	}

	/**
	 * Método responsavel por tratar as informações de Endereço
	 * @param messageCics
	 * @param endereco
	 */
	private void tratarInfoEndereco(StringBuffer messageCics, Endereco endereco){
		enderecoService.tratarInformacoes(messageCics, endereco);		
	}

	/**
	 * Método responsavel por tratar as informações de Telefone
	 * @param messageCics
	 * @param telefone
	 */
	private void tratarInfoTelefone(StringBuffer messageCics, Telefone telefone){
		telefoneService.tratarInformacoes(messageCics, telefone);		
	}

	/**
	 * Método responsavel por tratar as informações de Proprietários
	 * @param messageCics
	 * @param proprietario
	 */
	private void tratarInfoProprietarios(StringBuffer messageCics, Proprietario proprietario){
		proprietarioService.tratarInformacoes(messageCics, proprietario);		
	}

}
