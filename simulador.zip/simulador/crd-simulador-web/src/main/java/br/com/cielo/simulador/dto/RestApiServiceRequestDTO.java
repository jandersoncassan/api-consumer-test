package br.com.cielo.simulador.dto;

import java.util.List;

import br.com.cielo.simulador.model.common.ClienteType;
import br.com.cielo.simulador.model.common.SolucaoCapturaType;

public class RestApiServiceRequestDTO {

	private Integer codigoFerramenta;
	private boolean indicadorAgro;
	private List<SolucaoCapturaType> solucoesCaptura;
	private ClienteType cliente;
	/**
	 * @return the codigoFerramenta
	 */
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}
	/**
	 * @param codigoFerramenta the codigoFerramenta to set
	 */
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
	}
	/**
	 * @return the indicadorAgro
	 */
	public boolean isIndicadorAgro() {
		return indicadorAgro;
	}
	/**
	 * @param indicadorAgro the indicadorAgro to set
	 */
	public void setIndicadorAgro(boolean indicadorAgro) {
		this.indicadorAgro = indicadorAgro;
	}
	/**
	 * @return the solucoesCaptura
	 */
	public List<SolucaoCapturaType> getSolucoesCaptura() {
		return solucoesCaptura;
	}
	/**
	 * @param solucoesCaptura the solucoesCaptura to set
	 */
	public void setSolucoesCaptura(List<SolucaoCapturaType> solucoesCaptura) {
		this.solucoesCaptura = solucoesCaptura;
	}
	/**
	 * @return the cliente
	 */
	public ClienteType getCliente() {
		return cliente;
	}
	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(ClienteType cliente) {
		this.cliente = cliente;
	}
	
	

}
