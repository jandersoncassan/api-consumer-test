package br.com.cielo.simulador.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.dto.RestApiServiceRequestDTO;
import br.com.cielo.simulador.dto.RestApiServiceResponseDTO;
import br.com.cielo.simulador.enums.StatusProcessamento;
import br.com.cielo.simulador.model.Campos;
import br.com.cielo.simulador.model.Criticas;
import br.com.cielo.simulador.model.DadosInconsistentes;
import br.com.cielo.simulador.model.MessageLayoutResponse;
import br.com.cielo.simulador.service.IRestApiClientService;
import br.com.cielo.simulador.service.core.RestApiClient;
import br.com.cielo.simulador.utils.SimuladorFile;
import br.com.cielo.simulador.utils.SimuladorUtils;


/**
 * Classe responsavel pela implementação do serviço de chamada a API Gateway
 * @author janderson@cielo
 */
@Service
public class RestApiClientServiceImpl extends RestApiClient implements IRestApiClientService{

	private static final Logger LOG = LogManager.getLogger(RestApiClientServiceImpl.class);
	
	private final String ENDPOINT_API = "endpoint.api.credenciamento";
	private final String URI_INCLUIR_PROPOSTA = "uri.incluir.proposta";

	@Override
	public MessageLayoutResponse incluirProposta(RestApiServiceRequestDTO infoCliente) {
		String jsonRequest = tratarObjectToJson(infoCliente);
		String jsonResponse = execute(getEndpointIncluirProposta(), HttpMethod.POST, jsonRequest);
		LOG.info("INFORMACOES JSON (Response) : \n" + jsonResponse);	
		RestApiServiceResponseDTO response = (RestApiServiceResponseDTO) SimuladorUtils.jsonToObject(jsonResponse, RestApiServiceResponseDTO.class);
		return tratarMessageResponse(response);
	}

	@Override
	public String tratarObjectToJson(Object object) {
		String json = SimuladorUtils.objectToJson(object);
		LOG.info("INFORMACOES JSON (Request) : \n" + json);
		return json;
	}
	
	/**
	 * Método responsavel por obter o endpoint da API Gateway Inclusão de Proposta
	 * @return
	 */
	private String getEndpointIncluirProposta(){
		String endpoint = SimuladorFile.getInstance().getMessageExternal(ENDPOINT_API);
		String uri = SimuladorFile.getInstance().getMessageExternal(URI_INCLUIR_PROPOSTA);
		return endpoint.concat(uri);
	}
	
	/**
	 * Método responsavel por popular as informações da mensagem de retorno
	 * @param response
	 * @return
	 */
	private MessageLayoutResponse tratarMessageResponse(RestApiServiceResponseDTO objResponse){
		MessageLayoutResponse response = new MessageLayoutResponse();
		Integer codigoRetorno = objResponse.getStatus().getCodigo();
		response.setCodigoProcessamento(getStatusProcessamento(codigoRetorno));
		popularInfoResponse(response, objResponse);
		return response;
	}
	
	/**
	 * Método responsavel por popular as informações de acordo com o status do processamento
	 * @param response
	 * @param objResponse
	 */
	private void popularInfoResponse(MessageLayoutResponse response, RestApiServiceResponseDTO objResponse){
		switch (response.getCodigoProcessamento()) {
		case SUCESSO:
			response.setNumeroEc(objResponse.getCliente().getCodigo().toString());		
			break;
		case INCONSISTENTE:
			popularStatusInconsistente(response, objResponse);
			break;
		default://ERRO SISTEMICO
			response.setMensagemErro(objResponse.getStatus().getDescricao());
			break;
		}
	}
	
	/**
	 * Método responsavel por popular as informações de processamento 'INCONSISTENTE'
	 * @param response
	 * @param objResponse
	 */
	private void popularStatusInconsistente(MessageLayoutResponse response, RestApiServiceResponseDTO objResponse){
			
			List<DadosInconsistentes> dadosInconsistencias= new ArrayList<DadosInconsistentes>();			
			for (Criticas critica : objResponse.getCriticas()) {
				DadosInconsistentes dados = new DadosInconsistentes();
				dados.setCodigo(critica.getCodigo());
				dados.setMensagem(critica.getDescricao());				
				for(Campos campo : critica.getCampos()){
					dados.setCampo(campo.getReferencia());
				}	
				dadosInconsistencias.add(dados);
			} 
			response.setDadosInconsistencias(dadosInconsistencias);
	}

	/**
	 * Método responsavel por efetuar o tratarmento do status de processamento
	 * @param codigoRetorno
	 * @return
	 */
	private StatusProcessamento getStatusProcessamento(Integer codigoRetorno){
		switch (codigoRetorno) {
		case 1: //SUCESSO
			return StatusProcessamento.SUCESSO;
		case 2: //INCONSISTENTE
			return StatusProcessamento.INCONSISTENTE;
		default: // ERRO SISTEMICO (99)
			return StatusProcessamento.PROBLEMA_SISTEMICO;
		}
	}
}
