package br.com.cielo.simulador.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.model.Proprietario;
import br.com.cielo.simulador.service.IProprietarioService;
import br.com.cielo.simulador.service.core.InfoClienteAbstractService;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Service
public class ProprietarioServiceImpl extends InfoClienteAbstractService<Proprietario> implements IProprietarioService{

	private static final Logger LOG = LoggerFactory.getLogger(ProprietarioServiceImpl.class);

	@Override
	public StringBuffer tratarInformacoes(StringBuffer messageCics, Object objProprietario) {
		return init(messageCics, objProprietario);
	}

	/**
	 * Método responsavel pelas informações dos proprietários
	 * @param messageCics
	 * @param proprietario
	 * @return StringBuffer
	 */
	private StringBuffer init(StringBuffer messageCics, Object objProprietario){
		LOG.info("CONSISTIR INFORMACOES DOS PROPRIETARIOS");
		Proprietario proprietario = (Proprietario) objProprietario;
		return popularInfoProprietarios(messageCics, proprietario);
	}
	
	/**
	 * Método responsavel por popular as informações de proprietarios
	 * @param messageCics
	 * @param proprietario
	 * @return StringBuffer
	 */
	private StringBuffer popularInfoProprietarios(StringBuffer messageCics, Proprietario proprietario) {
		tratarInfoProprietarios(proprietario);
		return tratarConteudoMessage(messageCics, proprietario);
	}
	
	/**
	 * Tratar informações CpfCnpj
	 * @param cliente
	 */
	private void tratarInfoProprietarios(Proprietario proprietario){
		//TRATAR CPF
		proprietario.setCpf(proprietario.getCpf().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));
		proprietario.setCpf2(SimuladorUtils.tratarStringNull(proprietario.getCpf2()));
		proprietario.setCpf3(SimuladorUtils.tratarStringNull(proprietario.getCpf3()));
		if(!proprietario.getCpf2().isEmpty())
			proprietario.setCpf2(proprietario.getCpf2().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));
		if(!proprietario.getCpf3().isEmpty())
			proprietario.setCpf3(proprietario.getCpf3().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));

		//TRATAR NOME
		proprietario.setNome2(SimuladorUtils.tratarStringNull(proprietario.getNome2()));
		proprietario.setNome3(SimuladorUtils.tratarStringNull(proprietario.getNome3()));

		//TRATAR Data Nascimento
		proprietario.setDataNascimento(null != proprietario.getDtNascimento() ? SimuladorUtils.dateToStringCics(proprietario.getDtNascimento()):SimuladorUtils.STRING_VAZIA);
		proprietario.setDataNascimento2(null != proprietario.getDtNascimento2() ? SimuladorUtils.dateToStringCics(proprietario.getDtNascimento2()):SimuladorUtils.STRING_VAZIA);
		proprietario.setDataNascimento3(null != proprietario.getDtNascimento3() ? SimuladorUtils.dateToStringCics(proprietario.getDtNascimento3()):SimuladorUtils.STRING_VAZIA);
	}


}
