package br.com.cielo.simulador.service;

import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.simulador.model.MessageLayoutResponse;

public interface ISoapClientService {

	/**
	 * Método responsavel pela inclusão da proposta no CRD via SOAP Service
	 * @param request
	 * @return
	 */
	MessageLayoutResponse incluirProposta(CredenciarClienteRequest request);
}
