package br.com.cielo.simulador.enums;

public enum StatusProcessamento {
	
	SUCESSO("00"),INCONSISTENTE("01"),PROBLEMA_SISTEMICO("99");
	
	private String codigo;
	
	private StatusProcessamento(String codProcessamento){
		this.codigo = codProcessamento;
	}

	public String getCodigo(){
		return codigo;
	}
}
