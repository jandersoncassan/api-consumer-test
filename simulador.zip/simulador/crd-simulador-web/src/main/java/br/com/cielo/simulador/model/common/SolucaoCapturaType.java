package br.com.cielo.simulador.model.common;

public class SolucaoCapturaType {

	private Integer codigo;
	private Integer quantidade;
	private Integer codigoPacoteEcommerce;
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the quantidade
	 */
	public Integer getQuantidade() {
		return quantidade;
	}
	/**
	 * @param quantidade the quantidade to set
	 */
	public void setQuantidade(Integer quantidade) {
		this.quantidade = quantidade;
	}
	/**
	 * @return the codigoPacoteEcommerce
	 */
	public Integer getCodigoPacoteEcommerce() {
		return codigoPacoteEcommerce;
	}
	/**
	 * @param codigoPacoteEcommerce the codigoPacoteEcommerce to set
	 */
	public void setCodigoPacoteEcommerce(Integer codigoPacoteEcommerce) {
		this.codigoPacoteEcommerce = codigoPacoteEcommerce;
	}


	
}
