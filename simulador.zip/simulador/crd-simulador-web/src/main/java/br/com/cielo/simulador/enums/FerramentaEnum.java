package br.com.cielo.simulador.enums;

public enum FerramentaEnum {

    BANCOS_ONLINE(2), SITE(3), CENTRAL(4), VENDING_MACHINE(5), DESENVOLVEDORES_LIO(6), SMART(7), FEIRAS(8);

    private Integer codigo;

    private FerramentaEnum(Integer codigo) {
        this.codigo = codigo;
    }

    public Integer getCodigo() {
        return codigo;
    }
    
	/**
	 * Método responsavel por verificar se trata-se da ferramenta smart
	 * @param codigo
	 * @return
	 */
    public static Boolean isSmart(Integer codigo){
    	return SMART.getCodigo().equals(codigo);
    }
}
