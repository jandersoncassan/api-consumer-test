package br.com.cielo.simulador.service.core;

import java.nio.charset.Charset;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.web.client.RestTemplate;

public abstract class RestApiClient {

	private RestTemplate rest;
	private HttpHeaders headers;
	private HttpStatus status;

	/**
	 * Método responsavel por tratar o object for JSON
	 * 
	 * @param object
	 * @return String
	 */
	public abstract String tratarObjectToJson(Object object);

	/**
	 * Método responsavel por iniciar as configurações da chamada a API
	 */
	public void initConfig() {
		if(null == rest || null == headers){
			this.rest = new RestTemplate();
			rest.getMessageConverters().add(0, new StringHttpMessageConverter(Charset.forName("UTF-8")));
			this.headers = new HttpHeaders();
			headers.add("Content-Type", "application/json");
			headers.add("Accept", "application/json");
			headers.add("client_id", "mbE0Q0fAuk5F"); //api-mobile(Og83ZDTmgVvo)
		}
	}

	/**
	 * Método responsavel por executar a chamada a API Gateway
	 * @param endpointUri
	 * @param method
	 * @return
	 */
	public String execute(String endpointUri, HttpMethod method, String param) {
		initConfig();
		HttpEntity<String> requestEntity = new HttpEntity<String>(param, headers);
		ResponseEntity<String> responseEntity = rest.exchange(endpointUri, method, requestEntity, String.class);
		this.setStatus(responseEntity.getStatusCode());
		return responseEntity.getBody();
	}

	/**
	 * Método responsavel por obter o status HTTP da execução
	 * @return
	 */
	public HttpStatus getStatus() {
		return status;
	}

	/**
	 * Método responsavel por setar o status HTTP da execução
	 * @param status
	 */
	public void setStatus(HttpStatus status) {
		this.status = status;
	}

}
