package br.com.cielo.simulador.model;

public class EstabelComercial {

	private Long codigo; // NUMERO DO EC

	/**
	 * @return the codigo
	 */
	public Long getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Long codigo) {
		this.codigo = codigo;
	}
	
}
