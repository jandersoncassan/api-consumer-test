package br.com.cielo.simulador.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.model.DomicilioBancario;
import br.com.cielo.simulador.service.IDomicilioBancarioService;
import br.com.cielo.simulador.service.core.InfoClienteAbstractService;

@Service
public class DomicilioBancarioServiceImpl extends InfoClienteAbstractService<DomicilioBancario> implements IDomicilioBancarioService{

	private static final Logger LOG = LoggerFactory.getLogger(DomicilioBancarioServiceImpl.class);

	@Override
	public StringBuffer tratarInformacoes(StringBuffer messageCics, Object objDomBancario) {
		return init(messageCics, objDomBancario);	}

	/**
	 * Método responsavel pelas informações do Domicilio Bancario
	 * @param messageCics
	 * @param domBancario
	 * @return StringBuffer
	 */
	private StringBuffer init(StringBuffer messageCics, Object objDomBancario){
		LOG.info("CONSISTIR INFORMAÇÕES DO DOMICILIO BANCARIO");
		DomicilioBancario domBancario = (DomicilioBancario) objDomBancario;
		return popularInformacoesCliente(messageCics, domBancario);
	}
	
	/**
	 * Método responsavel por popular as informações de Domicilio Bancario
	 * @param messageCics
	 * @param domBancario
	 * @return StringBuffer
	 */
	private StringBuffer popularInformacoesCliente(StringBuffer messageCics, DomicilioBancario domBancario) {
		tratarInfoDomBancario(domBancario);
		return tratarConteudoMessage(messageCics, domBancario);
	}
	
	/**
	 * Tratar informações Domicilio Bancario
	 * @param cliente
	 */
	private void tratarInfoDomBancario(DomicilioBancario domBancario){
		domBancario.setNumeroConta(domBancario.getNumeroConta().replace("-", ""));
	}



}
