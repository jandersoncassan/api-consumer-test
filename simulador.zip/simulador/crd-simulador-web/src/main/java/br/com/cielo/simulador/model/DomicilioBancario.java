package br.com.cielo.simulador.model;

import org.hibernate.validator.constraints.NotEmpty;

import br.com.cielo.simulador.annotation.FieldCrd;

public class DomicilioBancario {

	@FieldCrd(tipo="N", tamanho=3, posInicial=35, posFinal=37)
	@NotEmpty(message="{campo.codigo.banco}")
	private String codBanco;

	@FieldCrd(tipo="N", tamanho=5, posInicial=481, posFinal=485)
	@NotEmpty(message="{campo.codigo.agencia}")
	private String codAgencia;

	@FieldCrd(tamanho=14, posInicial=488, posFinal=501)
	@NotEmpty(message="{campo.numero.conta}")
	private String numeroConta;
	
	@FieldCrd(tamanho=1, posInicial=748, posFinal=748)
	private String tipoConta;

	@FieldCrd(tamanho=4, posInicial=4, posFinal=7)
	private String numInstFinanceira;

	/**
	 * @return the codBanco
	 */
	public String getCodBanco() {
		return codBanco;
	}

	/**
	 * @param codBanco the codBanco to set
	 */
	public void setCodBanco(String codBanco) {
		this.codBanco = codBanco;
	}

	/**
	 * @return the codAgencia
	 */
	public String getCodAgencia() {
		return codAgencia;
	}

	/**
	 * @param codAgencia the codAgencia to set
	 */
	public void setCodAgencia(String codAgencia) {
		this.codAgencia = codAgencia;
	}

	/**
	 * @return the numeroConta
	 */
	public String getNumeroConta() {
		return numeroConta;
	}

	/**
	 * @param numeroConta the numeroConta to set
	 */
	public void setNumeroConta(String numeroConta) {
		this.numeroConta = numeroConta;
	}

	/**
	 * @return the tipoConta
	 */
	public String getTipoConta() {
		return tipoConta;
	}

	/**
	 * @param tipoConta the tipoConta to set
	 */
	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	/**
	 * @return the numInstFinanceira
	 */
	public String getNumInstFinanceira() {
		return "9999";
	}

	/**
	 * @param numInstFinanceira the numInstFinanceira to set
	 */
	public void setNumInstFinanceira(String numInstFinanceira) {
		this.numInstFinanceira = numInstFinanceira;
	}

	
}
