package br.com.cielo.simulador.dto;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import br.com.cielo.simulador.model.Cliente;
import br.com.cielo.simulador.model.DomicilioBancario;
import br.com.cielo.simulador.model.Endereco;
import br.com.cielo.simulador.model.Proprietario;
import br.com.cielo.simulador.model.SolucaoCapturaPlano;
import br.com.cielo.simulador.model.Telefone;

public class CredenciamentoDTO {
	
	@NotNull(message="{codigo.tipo.ferramenta}")
	private Integer tipoFerramenta;
	
	private Long codigoAfiliador;
	
	@Valid
	private Cliente cliente;
	
	@Valid
	private DomicilioBancario domicilioBancario;
	
	@Valid
	private SolucaoCapturaPlano solPlano;
	
	@Valid
	private Endereco endereco;
	
	@Valid
	private Proprietario proprietario;
	
	@Valid
	private Telefone telefone;
	
	private String loginUsuarioOperador;
	
	private String codPerfilSmart;
	
	private String nomeExecutivo;

	/**
	 * @return the tipoFerramenta
	 */
	public Integer getTipoFerramenta() {
		return tipoFerramenta;
	}

	/**
	 * @param tipoFerramenta the tipoFerramenta to set
	 */
	public void setTipoFerramenta(Integer tipoFerramenta) {
		this.tipoFerramenta = tipoFerramenta;
	}

	/**
	 * @return the codigoAfiliador
	 */
	public Long getCodigoAfiliador() {
		return codigoAfiliador;
	}

	/**
	 * @param codigoAfiliador the codigoAfiliador to set
	 */
	public void setCodigoAfiliador(Long codigoAfiliador) {
		this.codigoAfiliador = codigoAfiliador;
	}

	/**
	 * @return the cliente
	 */
	public Cliente getCliente() {
		return cliente;
	}

	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	/**
	 * @return the domicilioBancario
	 */
	public DomicilioBancario getDomicilioBancario() {
		return domicilioBancario;
	}

	/**
	 * @param domicilioBancario the domicilioBancario to set
	 */
	public void setDomicilioBancario(DomicilioBancario domicilioBancario) {
		this.domicilioBancario = domicilioBancario;
	}

	/**
	 * @return the solPlano
	 */
	public SolucaoCapturaPlano getSolPlano() {
		return solPlano;
	}

	/**
	 * @param solPlano the solPlano to set
	 */
	public void setSolPlano(SolucaoCapturaPlano solPlano) {
		this.solPlano = solPlano;
	}

	/**
	 * @return the endereco
	 */
	public Endereco getEndereco() {
		return endereco;
	}

	/**
	 * @param endereco the endereco to set
	 */
	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}

	/**
	 * @return the proprietario
	 */
	public Proprietario getProprietario() {
		return proprietario;
	}

	/**
	 * @param proprietario the proprietario to set
	 */
	public void setProprietario(Proprietario proprietario) {
		this.proprietario = proprietario;
	}

	/**
	 * @return the telefone
	 */
	public Telefone getTelefone() {
		return telefone;
	}

	/**
	 * @param telefone the telefone to set
	 */
	public void setTelefone(Telefone telefone) {
		this.telefone = telefone;
	}

	/**
	 * @return the loginUsuarioOperador
	 */
	public String getLoginUsuarioOperador() {
		return loginUsuarioOperador;
	}

	/**
	 * @param loginUsuarioOperador the loginUsuarioOperador to set
	 */
	public void setLoginUsuarioOperador(String loginUsuarioOperador) {
		this.loginUsuarioOperador = loginUsuarioOperador;
	}

	/**
	 * @return the codPerfilSmart
	 */
	public String getCodPerfilSmart() {
		return codPerfilSmart;
	}

	/**
	 * @param codPerfilSmart the codPerfilSmart to set
	 */
	public void setCodPerfilSmart(String codPerfilSmart) {
		this.codPerfilSmart = codPerfilSmart;
	}

	
	/**
	 * @return the nomeExecutivo
	 */
	public String getNomeExecutivo() {
		return nomeExecutivo;
	}

	/**
	 * @param nomeExecutivo the nomeExecutivo to set
	 */
	public void setNomeExecutivo(String nomeExecutivo) {
		this.nomeExecutivo = nomeExecutivo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CredenciamentoDTO [tipoFerramenta=" + tipoFerramenta + ", codigoAfiliador=" + codigoAfiliador
				+ ", cliente=" + cliente + ", domicilioBancario=" + domicilioBancario + ", solPlano=" + solPlano
				+ ", endereco=" + endereco + ", proprietario=" + proprietario + ", telefone=" + telefone
				+ ", loginUsuarioOperador=" + loginUsuarioOperador + ", codPerfilSmart=" + codPerfilSmart
				+ ", nomeExecutivo=" + nomeExecutivo + "]";
	}

	
	
}
