package br.com.cielo.simulador.model.common;

import java.math.BigDecimal;
import java.util.List;

public class ClienteType {

	private String tipoPessoa;
	private Long cpfCnpj;
	private String nome; 
	private String razaoSocial;
	private boolean indicadorMEI;
	private Long inscricaoEstadual;
	private RamoAtividadeType ramoAtividade;	
	private List<DomicilioBancarioType> contasCorrentes;
	private String nomePlaqueta;
	private String nomeContato;
	private String emailContato;
	private List<TelefoneType> telefones;
	private List<EnderecoType> enderecos;
	private List<ProprietarioType> proprietarios;
	private String codigoAfiliador;
	private BigDecimal faturamentoMedio;
	private Integer codigoTipoPlanoCielo;
	private Integer quantidadeDiasLiquidacao;
	private BigDecimal taxaArv;
	
	/**
	 * @return the tipoPessoa
	 */
	public String getTipoPessoa() {
		return tipoPessoa;
	}
	/**
	 * @param tipoPessoa the tipoPessoa to set
	 */
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}
	/**
	 * @return the cpfCnpj
	 */
	public Long getCpfCnpj() {
		return cpfCnpj;
	}
	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(Long cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}
	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return the razaoSocial
	 */
	public String getRazaoSocial() {
		return razaoSocial;
	}
	/**
	 * @param razaoSocial the razaoSocial to set
	 */
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	/**
	 * @return the indicadorMEI
	 */
	public boolean isIndicadorMEI() {
		return indicadorMEI;
	}
	/**
	 * @param indicadorMEI the indicadorMEI to set
	 */
	public void setIndicadorMEI(boolean indicadorMEI) {
		this.indicadorMEI = indicadorMEI;
	}
	/**
	 * @return the inscricaoEstadual
	 */
	public Long getInscricaoEstadual() {
		return inscricaoEstadual;
	}
	/**
	 * @param inscricaoEstadual the inscricaoEstadual to set
	 */
	public void setInscricaoEstadual(Long inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}
	/**
	 * @return the ramoAtividade
	 */
	public RamoAtividadeType getRamoAtividade() {
		return ramoAtividade;
	}
	/**
	 * @param ramoAtividade the ramoAtividade to set
	 */
	public void setRamoAtividade(RamoAtividadeType ramoAtividade) {
		this.ramoAtividade = ramoAtividade;
	}
	/**
	 * @return the contasCorrentes
	 */
	public List<DomicilioBancarioType> getContasCorrentes() {
		return contasCorrentes;
	}
	/**
	 * @param contasCorrentes the contasCorrentes to set
	 */
	public void setContasCorrentes(List<DomicilioBancarioType> contasCorrentes) {
		this.contasCorrentes = contasCorrentes;
	}
	/**
	 * @return the nomePlaqueta
	 */
	public String getNomePlaqueta() {
		return nomePlaqueta;
	}
	/**
	 * @param nomePlaqueta the nomePlaqueta to set
	 */
	public void setNomePlaqueta(String nomePlaqueta) {
		this.nomePlaqueta = nomePlaqueta;
	}
	/**
	 * @return the nomeContato
	 */
	public String getNomeContato() {
		return nomeContato;
	}
	/**
	 * @param nomeContato the nomeContato to set
	 */
	public void setNomeContato(String nomeContato) {
		this.nomeContato = nomeContato;
	}
	/**
	 * @return the emailContato
	 */
	public String getEmailContato() {
		return emailContato;
	}
	/**
	 * @param emailContato the emailContato to set
	 */
	public void setEmailContato(String emailContato) {
		this.emailContato = emailContato;
	}
	/**
	 * @return the telefones
	 */
	public List<TelefoneType> getTelefones() {
		return telefones;
	}
	/**
	 * @param telefones the telefones to set
	 */
	public void setTelefones(List<TelefoneType> telefones) {
		this.telefones = telefones;
	}
	/**
	 * @return the enderecos
	 */
	public List<EnderecoType> getEnderecos() {
		return enderecos;
	}
	/**
	 * @param enderecos the enderecos to set
	 */
	public void setEnderecos(List<EnderecoType> enderecos) {
		this.enderecos = enderecos;
	}
	/**
	 * @return the proprietarios
	 */
	public List<ProprietarioType> getProprietarios() {
		return proprietarios;
	}
	/**
	 * @param proprietarios the proprietarios to set
	 */
	public void setProprietarios(List<ProprietarioType> proprietarios) {
		this.proprietarios = proprietarios;
	}
	/**
	 * @return the codigoAfiliador
	 */
	public String getCodigoAfiliador() {
		return codigoAfiliador;
	}
	/**
	 * @param codigoAfiliador the codigoAfiliador to set
	 */
	public void setCodigoAfiliador(String codigoAfiliador) {
		this.codigoAfiliador = codigoAfiliador;
	}
	/**
	 * @return the faturamentoMedio
	 */
	public BigDecimal getFaturamentoMedio() {
		return faturamentoMedio;
	}
	/**
	 * @param faturamentoMedio the faturamentoMedio to set
	 */
	public void setFaturamentoMedio(BigDecimal faturamentoMedio) {
		this.faturamentoMedio = faturamentoMedio;
	}
	/**
	 * @return the codigoTipoPlanoCielo
	 */
	public Integer getCodigoTipoPlanoCielo() {
		return codigoTipoPlanoCielo;
	}
	/**
	 * @param codigoTipoPlanoCielo the codigoTipoPlanoCielo to set
	 */
	public void setCodigoTipoPlanoCielo(Integer codigoTipoPlanoCielo) {
		this.codigoTipoPlanoCielo = codigoTipoPlanoCielo;
	}
	/**
	 * @return the quantidadeDiasLiquidacao
	 */
	public Integer getQuantidadeDiasLiquidacao() {
		return quantidadeDiasLiquidacao;
	}
	/**
	 * @param quantidadeDiasLiquidacao the quantidadeDiasLiquidacao to set
	 */
	public void setQuantidadeDiasLiquidacao(Integer quantidadeDiasLiquidacao) {
		this.quantidadeDiasLiquidacao = quantidadeDiasLiquidacao;
	}
    public BigDecimal getTaxaArv() {
        return taxaArv;
    }
    public void setTaxaArv(BigDecimal taxaArv) {
        this.taxaArv = taxaArv;
    }

	
}
