package br.com.cielo.simulador.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.model.Cliente;
import br.com.cielo.simulador.service.IClientService;
import br.com.cielo.simulador.service.core.InfoClienteAbstractService;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Service
public class ClienteServiceImpl extends InfoClienteAbstractService<Cliente> implements IClientService{

	private static final Logger LOG = LoggerFactory.getLogger(ClienteServiceImpl.class);
	
	@Override
	public StringBuffer tratarInformacoes(StringBuffer messageCics, Object objCliente) {
		return init(messageCics, objCliente);
	}

	/**
	 * Método responsavel pelas informações do cliente
	 * @param messageCics
	 * @param cliente
	 * @return StringBuffer
	 */
	private StringBuffer init(StringBuffer messageCics, Object objCliente){
		LOG.info("CONSISTIR INFORMACOES DO CLIENTE");
		Cliente cliente = (Cliente) objCliente;
		return popularInformacoesCliente(messageCics, cliente);
	}
	
	/**
	 * Método responsavel por popular as informações de cliente
	 * @param messageCics
	 * @param cliente
	 * @return StringBuffer
	 */
	private StringBuffer popularInformacoesCliente(StringBuffer messageCics, Cliente cliente) {
		tratarInfoCliente(cliente);
		return tratarConteudoMessage(messageCics, cliente);
	}
	
	/**
	 * Tratar informações CpfCnpj
	 * @param cliente
	 */
	private void tratarInfoCliente(Cliente cliente){
		cliente.setCpfCnpj(cliente.getCpfCnpj().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));
		cliente.setIndicadorMei(null == cliente.getIndicadorMei() ? "N": cliente.getIndicadorMei());
	}

}
