package br.com.cielo.simulador.model;

import org.hibernate.validator.constraints.NotEmpty;

import br.com.cielo.simulador.annotation.FieldCrd;

public class Endereco {
	
	@FieldCrd(tamanho=32, posInicial=262, posFinal=293)
	@NotEmpty(message="{campo.logradouro}")
	private String logradouro;

	private String numero;

	@FieldCrd(tamanho=32, posInicial=294, posFinal=325)
	@NotEmpty(message="{campo.complemento}")
	private String complemento;
	
	@FieldCrd(tamanho=28, posInicial=328, posFinal=355)
	@NotEmpty(message="{campo.cidade}")
	private String cidade;
	
	@FieldCrd(tamanho=2, posInicial=358, posFinal=359)
	@NotEmpty(message="{campo.estado}")
	private String estado;
	
	@FieldCrd(tipo="N", tamanho=8, posInicial=362, posFinal=369)
	@NotEmpty(message="{campo.cep}")
	private String cep;
	
	private String duplicarEndereco;

	@FieldCrd(tamanho=32, posInicial=84, posFinal=115)
	private String logradouroC;

	private String numeroC;
	
	@FieldCrd(tamanho=32, posInicial=116, posFinal=147)
	private String complementoC;

	@FieldCrd(tamanho=28, posInicial=150, posFinal=177)
	private String cidadeC;
	
	@FieldCrd(tamanho=2, posInicial=180, posFinal=181)
	private String estadoC;
	
	@FieldCrd(tipo="N", tamanho=8, posInicial=184, posFinal=191)
	private String cepC;

	/**
	 * @return the logradouro
	 */
	public String getLogradouro() {
		return logradouro;
	}

	/**
	 * @param logradouro the logradouro to set
	 */
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	/**
	 * @return the numero
	 */
	public String getNumero() {
		return numero;
	}

	/**
	 * @param numero the numero to set
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}

	/**
	 * @return the complemento
	 */
	public String getComplemento() {
		return complemento;
	}

	/**
	 * @param complemento the complemento to set
	 */
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}

	/**
	 * @return the cidade
	 */
	public String getCidade() {
		return cidade;
	}

	/**
	 * @param cidade the cidade to set
	 */
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	/**
	 * @return the cep
	 */
	public String getCep() {
		return cep;
	}

	/**
	 * @param cep the cep to set
	 */
	public void setCep(String cep) {
		this.cep = cep;
	}

	/**
	 * @return the duplicarEndereco
	 */
	public String getDuplicarEndereco() {
		return duplicarEndereco;
	}

	/**
	 * @param duplicarEndereco the duplicarEndereco to set
	 */
	public void setDuplicarEndereco(String duplicarEndereco) {
		this.duplicarEndereco = duplicarEndereco;
	}

	/**
	 * @return the logradouroC
	 */
	public String getLogradouroC() {
		return logradouroC;
	}

	/**
	 * @param logradouroC the logradouroC to set
	 */
	public void setLogradouroC(String logradouroC) {
		this.logradouroC = logradouroC;
	}

	/**
	 * @return the numeroC
	 */
	public String getNumeroC() {
		return numeroC;
	}

	/**
	 * @param numeroC the numeroC to set
	 */
	public void setNumeroC(String numeroC) {
		this.numeroC = numeroC;
	}

	/**
	 * @return the complementoC
	 */
	public String getComplementoC() {
		return complementoC;
	}

	/**
	 * @param complementoC the complementoC to set
	 */
	public void setComplementoC(String complementoC) {
		this.complementoC = complementoC;
	}

	/**
	 * @return the cidadeC
	 */
	public String getCidadeC() {
		return cidadeC;
	}

	/**
	 * @param cidadeC the cidadeC to set
	 */
	public void setCidadeC(String cidadeC) {
		this.cidadeC = cidadeC;
	}

	/**
	 * @return the estadoC
	 */
	public String getEstadoC() {
		return estadoC;
	}

	/**
	 * @param estadoC the estadoC to set
	 */
	public void setEstadoC(String estadoC) {
		this.estadoC = estadoC;
	}

	/**
	 * @return the cepC
	 */
	public String getCepC() {
		return cepC;
	}

	/**
	 * @param cepC the cepC to set
	 */
	public void setCepC(String cepC) {
		this.cepC = cepC;
	}

	
}
