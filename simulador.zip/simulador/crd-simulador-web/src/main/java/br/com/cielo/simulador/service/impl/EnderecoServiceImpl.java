package br.com.cielo.simulador.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.model.Endereco;
import br.com.cielo.simulador.service.IEnderecoService;
import br.com.cielo.simulador.service.core.InfoClienteAbstractService;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Service
public class EnderecoServiceImpl extends InfoClienteAbstractService<Endereco> implements IEnderecoService{

	private static final Logger LOG = LoggerFactory.getLogger(EnderecoServiceImpl.class);

	@Override
	public StringBuffer tratarInformacoes(StringBuffer messageCics, Object objEndereco) {
		return  init(messageCics, objEndereco);
	}

	/**
	 * Método responsavel pelas informações do cliente
	 * @param messageCics
	 * @param cliente
	 * @return StringBuffer
	 */
	private StringBuffer init(StringBuffer messageCics, Object objEndereco){
		LOG.info("CONSISTIR INFORMACOES DE ENDERECO");
		Endereco endereco = (Endereco) objEndereco;
		return popularInformacoesEndereco(messageCics, endereco);
	}
	
	/**
	 * Método responsavel por popular as informações de cliente
	 * @param messageCics
	 * @param cliente
	 * @return StringBuffer
	 */
	private StringBuffer popularInformacoesEndereco(StringBuffer messageCics, Endereco endereco) {
		tratarInfoEnderecoCliente(endereco);
		return tratarConteudoMessage(messageCics, endereco);
	}
	
	/**
	 * Tratar informações CpfCnpj
	 * @param cliente
	 */
	private void tratarInfoEnderecoCliente(Endereco endereco){
		endereco.setCep(endereco.getCep().replace(SimuladorUtils.TRACO, SimuladorUtils.STRING_VAZIA));
		endereco.setEstado(endereco.getEstado().equals("NF")?"":endereco.getEstado());
		//CLIENTE SOLICITOU PARA DUPLICAR O ENDERECO COMERCIAL & cORRESPONDECIA
		if(null != endereco.getDuplicarEndereco()){
			endereco.setLogradouroC(endereco.getLogradouro());
			endereco.setComplementoC(endereco.getComplemento());
			endereco.setCidadeC(endereco.getCidade());
			endereco.setEstadoC(endereco.getEstado());
			endereco.setCepC(endereco.getCep());
		}
		if(endereco.getCepC()!=null){
			endereco.setCepC(endereco.getCepC().replace(SimuladorUtils.TRACO, SimuladorUtils.STRING_VAZIA));
		}
		
	}

}
