package br.com.cielo.simulador.service;

public interface IDomicilioBancarioService extends IMessageCore{

}
