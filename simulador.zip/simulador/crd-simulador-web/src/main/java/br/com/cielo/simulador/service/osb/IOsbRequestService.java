package br.com.cielo.simulador.service.osb;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.ListarRamosAtividadesResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;

public interface IOsbRequestService {

    /**
     * Método responsavel por devolver a lista de MCC cadastrados no STAR
     * 
     * @return
     * @throws MalformedURLException
     * @throws ServiceException
     * @throws RemoteException
     */
    ListarRamosAtividadesResponse obterListaMccStar() throws MalformedURLException, ServiceException, RemoteException;

    /**
     * Método responsavel pela inclusão da proposta de credenciamento
     * 
     * @throws MalformedURLException
     * @throws ServiceException
     * @throws RemoteException
     */
    public CredenciarClienteResponse incluirProposta(CredenciarClienteRequest request)
            throws MalformedURLException, ServiceException, RemoteException;

}
