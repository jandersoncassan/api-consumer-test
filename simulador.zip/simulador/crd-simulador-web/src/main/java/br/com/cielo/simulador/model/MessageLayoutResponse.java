package br.com.cielo.simulador.model;

import java.util.List;

import br.com.cielo.simulador.enums.StatusProcessamento;

public class MessageLayoutResponse {

	private StatusProcessamento codigoProcessamento;	
	private String numeroEc;
	private String mensagemErro;
	private List<DadosInconsistentes> dadosInconsistencias;
	
	/**
	 * @return the codigoProcessamento
	 */
	public StatusProcessamento getCodigoProcessamento() {
		return codigoProcessamento;
	}
	
	/**
	 * @param codigoProcessamento the codigoProcessamento to set
	 */
	public void setCodigoProcessamento(StatusProcessamento codigoProcessamento) {
		this.codigoProcessamento = codigoProcessamento;
	}
	
	/**
	 * @return the numeroEc
	 */
	public String getNumeroEc() {
		return numeroEc;
	}
	
	/**
	 * @param numeroEc the numeroEc to set
	 */
	public void setNumeroEc(String numeroEc) {
		this.numeroEc = numeroEc;
	}
	
	/**
	 * @return the mensagemErro
	 */
	public String getMensagemErro() {
		return mensagemErro;
	}
	
	/**
	 * @param mensagemErro the mensagemErro to set
	 */
	public void setMensagemErro(String mensagemErro) {
		this.mensagemErro = mensagemErro;
	}
	
	/**
	 * @return the dadosInconsistencias
	 */
	public List<DadosInconsistentes> getDadosInconsistencias() {
		return dadosInconsistencias;
	}
	
	/**
	 * @param dadosInconsistencias the dadosInconsistencias to set
	 */
	public void setDadosInconsistencias(List<DadosInconsistentes> dadosInconsistencias) {
		this.dadosInconsistencias = dadosInconsistencias;
	}

	
}
