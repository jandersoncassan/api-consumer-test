package br.com.cielo.simulador.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.enums.StatusProcessamento;
import br.com.cielo.simulador.model.DadosInconsistentes;
import br.com.cielo.simulador.model.MessageLayoutResponse;
import br.com.cielo.simulador.service.IDadosClienteService;
import br.com.cielo.simulador.service.IMessageService;
import br.com.cielo.simulador.service.core.SocketCicsService;
import br.com.cielo.simulador.utils.SimuladorFile;
import br.com.cielo.simulador.utils.SimuladorUtils;

/**
 * Classe responsavel pela implementação do serviço do match da mensagem
 * @author janderson@cielo
 */
@Service
public class MessageServiceImpl implements IMessageService{

	private static final Logger LOG = LogManager.getLogger(MessageServiceImpl.class);

	@Autowired
	private IDadosClienteService infoClienteService;
	
	@Autowired
	private SocketCicsService socketCicsService;
	
	private final String FLAGS_CAMPOS="flags.campos";
	
	@Override
	public MessageLayoutResponse messageToCicsLink(CredenciamentoDTO infoCredenciamento) {
		StringBuffer messageCics = createStringToCics();
		System.out.println("INICIAL : " + messageCics);
		System.out.println("TAMANHO : " + messageCics.length());
		LOG.info("MATCH DAS INFORMACOES LAYOUT");
		infoClienteService.tratarInfoCredenciamento(infoCredenciamento, messageCics);
		System.out.println("FINAL : " + messageCics);
		System.out.println("TAMANHO : " + messageCics.length());		
		//ENVIAR INFORMAÇÕES PARA CRDENCIAMENTO
		return enviarMensagemCredenciamento(messageCics);
	}

	/**
	 * Método responsavel por gerar a String no layout do SEC
	 * @param messageCics
	 * @return StringBuffer
	 */
	private StringBuffer createStringToCics(){
		String message = StringUtils.repeat(SimuladorUtils.STRING_ZERO, 1920);
		StringBuffer stringToCics = new StringBuffer(message); 
		return stringToCics;
	}
	
	/**
	 * Método responsavel por enviar as informações do cliente para credenciamento
	 * @param layoutCliente
	 * @return 
	 */
	private MessageLayoutResponse enviarMensagemCredenciamento(StringBuffer layoutCliente){
		try{
			LOG.info("ENVIAR INFORMACOES PARA CREDENCIAMENTO CICS-LINK");
			String messageCics = socketCicsService.sendMessageCics(layoutCliente.toString());
			return getMessageRespose(messageCics);

		}catch (RuntimeException ex){
			LOG.error("ERRO ENVIO MENSAGEM PROCESSAMENTO", ex);
			return tratarRuntimeErroSistemico();
		}
	}
	
	/**
	 * Método responsavel pelo tratamento do retorno
	 * @param messageCics
	 * @return
	 */
	private MessageLayoutResponse getMessageRespose(String messageCics){

		MessageLayoutResponse response = new MessageLayoutResponse();
		
		String codProcess = getCodProcessamento(messageCics, SimuladorUtils.NUM_TRINTA_UM, SimuladorUtils.NUM_TRINTA_DOIS);
		String numeroEc = getNumeroEc(messageCics, SimuladorUtils.NUM_TRINTA_SETE, SimuladorUtils.NUM_QUARENTA_SETE);
		
		//CODIGO DE PROCESSAMENTO SUCESSO E POSSUI NUMERO DO EC
		if(!codProcess.equals(StatusProcessamento.PROBLEMA_SISTEMICO.getCodigo())){
			if(codProcess.equals(StatusProcessamento.SUCESSO.getCodigo()) && 
					!numeroEc.equals(SimuladorUtils.EC_ZERADO)){
				response.setCodigoProcessamento(StatusProcessamento.SUCESSO);
				response.setNumeroEc(numeroEc);			
			}else if(codProcess.equals(SimuladorUtils.STRING_ZERO_SETE)){
				tratarInstFinanInvalida(response);
			}else{
				response.setCodigoProcessamento(StatusProcessamento.INCONSISTENTE);
				response.setDadosInconsistencias(getListaInconsistencias(messageCics));
			}
		}else {
			response.setCodigoProcessamento(StatusProcessamento.PROBLEMA_SISTEMICO);
			response.setMensagemErro(getDescricaoErro(SimuladorUtils.ERRO_SISTEMICO));
		}
		return response;
	}
	
	/**
	 * Método responsavel por obter o código de processamento do credenciamento
	 * 00 == SUCESSO | 01 == Campo(s) com erro <> PROBLEMA SISTEMICO
	 * @param messageCics
	 * @return
	 */
	private String getCodProcessamento(String messageCics, int posInicial, int posFinal){
		return messageCics.substring(posInicial-1, posFinal);
	}
	
	/**
	 * Método responsavel por obter a lista de criticas
	 * @param messageCics
	 * @return
	 */
	private List<DadosInconsistentes> getListaInconsistencias(String messageCics){
		
		List<DadosInconsistentes> dadosInconsistencias= new ArrayList<DadosInconsistentes>();
		
		String flagsCampos = SimuladorFile.getInstance().getMessageInternal(FLAGS_CAMPOS);
		
		String[]flags = flagsCampos.split(Pattern.quote(","));
		List<String> listaFlags = Arrays.asList(flags);
		
		for (String string : listaFlags) {
			String[]campo = string.split(";");
			int posInicial = Integer.parseInt(campo[1]);
			int posFinal = Integer.parseInt(campo[2]);			
			String codErro = messageCics.substring(posInicial-1, posFinal);
			if(!codErro.equals("00")){
				DadosInconsistentes campoErro = new DadosInconsistentes();
				campoErro.setCampo(campo[0]);
				campoErro.setCodigo(codErro);
				campoErro.setMensagem(getDescricaoErro(codErro));
				dadosInconsistencias.add(campoErro);
			}
		}
		return dadosInconsistencias;
	}
	
	/**
	 * Método responsavel por obter o numero do EC retornado do SEC
	 * @param messageCics
	 * @return String
	 */
	private String getNumeroEc(String messageCics, int posInicial, int posFinal){
		return messageCics.substring(posInicial, posFinal);
	}
	
	/**
	 * Método responsavel por obter a descrição das informações de erro
	 * @param key
	 * @return
	 */
	private String getDescricaoErro(String key){
		return SimuladorFile.getInstance().getMessageInternal(key);
	}
	
	/**
	 * Método responsavel por tratar as execeções de Runtime
	 * @return
	 */
	private MessageLayoutResponse tratarRuntimeErroSistemico(){
		MessageLayoutResponse response = new MessageLayoutResponse();
		response.setCodigoProcessamento(StatusProcessamento.PROBLEMA_SISTEMICO);
		response.setMensagemErro("ERRO SISTEMICO");
		return response;
	}
	
	/**
	 * Caso a instituição financeira esteja inválida, o SEC retorna o código "07"
	 */
	private void tratarInstFinanInvalida(MessageLayoutResponse response){
		response.setCodigoProcessamento(StatusProcessamento.INCONSISTENTE);
		List<DadosInconsistentes> dadosInconsistencias= new ArrayList<DadosInconsistentes>();
		DadosInconsistentes dados = new DadosInconsistentes();
		dados.setCodigo("07");
		dados.setCampo("Instituição Financeira");
		dados.setMensagem("Instituição Financeira Inválida");
		dadosInconsistencias.add(dados);
		response.setDadosInconsistencias(dadosInconsistencias);
	}
}
