package br.com.cielo.simulador.model;

import org.apache.commons.lang3.StringUtils;

public class RamoAtividadeMcc {

	private Integer codigo;
	private String descricao;
	
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	public String getDescricao() {		
		String codigoFormat =  codigo.toString();
		codigoFormat =  StringUtils.leftPad(codigoFormat, 4, "0");
		return codigoFormat.concat(" - ").concat(descricao);
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
	
	
}
