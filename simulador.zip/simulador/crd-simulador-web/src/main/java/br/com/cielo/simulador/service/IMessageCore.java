package br.com.cielo.simulador.service;

/**
 * Interface core responsável pelo tratamento do bloco de informações
 * @author janderson@cielo
 */
public interface IMessageCore{

	/**
	 * Método responsavel por tratar as informações do model
	 * @param messageCics
	 * @param model
	 */
	StringBuffer tratarInformacoes(StringBuffer messageCics, Object model);
}
