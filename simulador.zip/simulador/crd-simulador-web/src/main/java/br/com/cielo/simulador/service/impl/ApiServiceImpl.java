package br.com.cielo.simulador.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.dto.RestApiServiceRequestDTO;
import br.com.cielo.simulador.enums.StatusProcessamento;
import br.com.cielo.simulador.model.Cliente;
import br.com.cielo.simulador.model.DomicilioBancario;
import br.com.cielo.simulador.model.Endereco;
import br.com.cielo.simulador.model.MessageLayoutResponse;
import br.com.cielo.simulador.model.Proprietario;
import br.com.cielo.simulador.model.SolucaoCapturaPlano;
import br.com.cielo.simulador.model.common.ClienteType;
import br.com.cielo.simulador.model.common.DomicilioBancarioType;
import br.com.cielo.simulador.model.common.EnderecoType;
import br.com.cielo.simulador.model.common.ProprietarioType;
import br.com.cielo.simulador.model.common.RamoAtividadeType;
import br.com.cielo.simulador.model.common.SolucaoCapturaType;
import br.com.cielo.simulador.model.common.TelefoneType;
import br.com.cielo.simulador.model.common.TipoType;
import br.com.cielo.simulador.service.IApiService;
import br.com.cielo.simulador.service.IRestApiClientService;
import br.com.cielo.simulador.utils.SimuladorUtils;

/**
 * Classe responsavel pela implementação do serviço de integração com a API de Credenciamento
 * @author janderson@cielo
 */
@Service
public class ApiServiceImpl implements IApiService{
	
	private static final Logger LOG = LogManager.getLogger(ApiServiceImpl.class);

	@Autowired
	private IRestApiClientService restApiClientService;
	
	private final Integer TEL_COMERCIAL = 2;
	private final Integer TEL_CELULAR = 3;

	private final Integer END_COMERCIAL = 2;
	private final Integer END_CORRESPONDENCIA = 3;


	@Override
	public MessageLayoutResponse messageToApiCrd(CredenciamentoDTO infoCredenciamento) {
		try{
			LOG.info("ENVIAR INFORMACOES PARA CREDENCIAMENTO API-GATEWAY");
			RestApiServiceRequestDTO infoCliente = popularInformacoes(infoCredenciamento);
			return (restApiClientService.incluirProposta(infoCliente));
		}catch(Exception ex){
			LOG.error("ERRO ENVIO MENSAGEM PROCESSAMENTO", ex);
			return tratarRuntimeErroSistemico();
		}
	}
	
	/**
	 * Método responsavel por popular as informações de Credenciamento 
	 * @param infoCredenciamento
	 * @return
	 */
	private RestApiServiceRequestDTO popularInformacoes(CredenciamentoDTO infoCredenciamento){
		RestApiServiceRequestDTO infoApiCredenciamento = new RestApiServiceRequestDTO();
		popularSolucaoCaptura(infoApiCredenciamento, infoCredenciamento);
		popularInfoCliente(infoApiCredenciamento, infoCredenciamento);
		popularDomicilioBancario(infoApiCredenciamento, infoCredenciamento);
		popularTelefones(infoApiCredenciamento, infoCredenciamento);
		popularEnderecos(infoApiCredenciamento, infoCredenciamento);
		popularProprietarios(infoApiCredenciamento, infoCredenciamento);
		popularInfoComplementar(infoApiCredenciamento, infoCredenciamento);
		return infoApiCredenciamento;
	}
	
	/**
	 * Método responsavel por popular as informações de Solução de Captura
	 * @param infoApiCredenciamento
	 * @param infoCredenciamento
	 */
	private void popularSolucaoCaptura(RestApiServiceRequestDTO infoApiCredenciamento, CredenciamentoDTO infoCredenciamento){
		List<SolucaoCapturaType> listaSolucaoCaptura = new ArrayList<>();
		SolucaoCapturaType solucaoCaptura = new SolucaoCapturaType();
		tratarInfoSolCaptura(infoCredenciamento.getSolPlano());
		solucaoCaptura.setCodigo(Integer.valueOf(infoCredenciamento.getSolPlano().getTipoSolucaoCaptura()));
		solucaoCaptura.setCodigoPacoteEcommerce(Integer.valueOf(infoCredenciamento.getSolPlano().getCodPacoteEcommerce()));
		solucaoCaptura.setQuantidade(infoCredenciamento.getSolPlano().getQtdadeEquipamento());
		listaSolucaoCaptura.add(solucaoCaptura);
		infoApiCredenciamento.setSolucoesCaptura(listaSolucaoCaptura);
	}
	
	/**
	 * Método responsavel pela retirada de caracteres especiais
	 * @param solCaptura
	 */
	private void tratarInfoSolCaptura(SolucaoCapturaPlano solCaptura){
		solCaptura.setValorFaturamento(null == solCaptura.getValorFaturamento()?SimuladorUtils.STRING_ZERO :
		solCaptura.getValorFaturamento().replaceAll(SimuladorUtils.REGEX_CLEAN_MASK_MONETARIA, SimuladorUtils.STRING_VAZIA));
	}

	/**
	 * Método responsavel por popular as informações do Cliente
	 * @param infoApiCredenciamento
	 * @param infoCredenciamento
	 */
	private void popularInfoCliente(RestApiServiceRequestDTO infoApiCredenciamento, CredenciamentoDTO infoCredenciamento){
		ClienteType cliente = new ClienteType();		
		tratarInfoCliente(infoCredenciamento.getCliente());
		cliente.setNome(infoCredenciamento.getCliente().getNomeFantasia());
		cliente.setRazaoSocial(infoCredenciamento.getCliente().getNomeRazaoSocial());
		cliente.setCpfCnpj(Long.valueOf(infoCredenciamento.getCliente().getCpfCnpj()));
		cliente.setIndicadorMEI(infoCredenciamento.getCliente().getIndicadorMei()!= null ? true : false);
		cliente.setInscricaoEstadual(0l); //INFORMAÇÃO FIXA
		RamoAtividadeType ramoAtividade = new RamoAtividadeType();
		ramoAtividade.setCodigo(Integer.valueOf(infoCredenciamento.getCliente().getRamoAtividade()));
		cliente.setRamoAtividade(ramoAtividade);
		cliente.setTipoPessoa(infoCredenciamento.getCliente().getTipoPessoa());
		String taxaArv = infoCredenciamento.getCliente().getTaxaArv();
		if(taxaArv != null && !taxaArv.equals("")) {
	        cliente.setTaxaArv(new BigDecimal(taxaArv));
		}
		infoApiCredenciamento.setCliente(cliente);
	}
	
	/**
	 * Método responsavel pela retirada de caracteres especiais
	 * @param cliente
	 */
	private void tratarInfoCliente(Cliente cliente){
		cliente.setCpfCnpj(cliente.getCpfCnpj().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));
	}
	
	/**
	 * Método responsavel por popular as informações de Domicilio Bancario
	 * @param infoApiCredenciamento
	 * @param infoCredenciamento
	 */
	private void popularDomicilioBancario(RestApiServiceRequestDTO infoApiCredenciamento, CredenciamentoDTO infoCredenciamento){
		List<DomicilioBancarioType> listaDomicilio = new ArrayList<>();
		DomicilioBancarioType domicilio = new DomicilioBancarioType();
		tratarDomicilioBancario(infoCredenciamento.getDomicilioBancario());
		domicilio.setCodigoBanco(Integer.valueOf(infoCredenciamento.getDomicilioBancario().getCodBanco()));
		domicilio.setAgencia(infoCredenciamento.getDomicilioBancario().getCodAgencia());
		domicilio.setConta(infoCredenciamento.getDomicilioBancario().getNumeroConta());
		domicilio.setTipoConta(infoCredenciamento.getDomicilioBancario().getTipoConta());
		listaDomicilio.add(domicilio);
		infoApiCredenciamento.getCliente().setContasCorrentes(listaDomicilio);
	}
	
	/**
	 * Método responsavel pela retirada de caracteres especiais
	 * @param domBancario
	 */
	private void tratarDomicilioBancario(DomicilioBancario domBancario){
		domBancario.setNumeroConta(domBancario.getNumeroConta().replace("-", ""));
	}
	
	/**
	 * Método responsavel por popular as informações de telefone
	 * @param infoApiCredenciamento
	 * @param infoCredenciamento
	 */
	private void popularTelefones(RestApiServiceRequestDTO infoApiCredenciamento, CredenciamentoDTO infoCredenciamento){
		List<TelefoneType> listaTelefones = new ArrayList<>();
		listaTelefones.add(popularTelefone(tratarDdd(infoCredenciamento.getTelefone().getDddComercial()), tratarTelefone(infoCredenciamento.getTelefone().getNumeroComercial()), TEL_COMERCIAL));
		// VERIFICA SE O CELULAR FOI INFORMADO
		if(isNotEmptyOrNull(infoCredenciamento.getTelefone().getDddCelular()) && isNotEmptyOrNull(infoCredenciamento.getTelefone().getNumeroCelular())){
			listaTelefones.add(popularTelefone(tratarDdd(infoCredenciamento.getTelefone().getDddCelular()), tratarTelefone(infoCredenciamento.getTelefone().getNumeroCelular()), TEL_CELULAR));
		}
		infoApiCredenciamento.getCliente().setTelefones(listaTelefones);
	}
	
	/**
	 * Método responsavel por retornar as informações do ddd sem caracteres especiais
	 * @param ddd
	 * @return
	 */
	private String tratarDdd(String ddd){
		return ddd.replaceAll("[(|)]", "");
	}

	/**
	 * Método responsavel pela retirada de caracteres especiais
	 * @param telefone
	 */
	private String tratarTelefone(String telefone){
		return telefone.replace("-", "");
	}

	/**
	 * Método responsavel por popular o telefone
	 * @param ddd
	 * @param numero
	 * @param codigo
	 * @return
	 */
	private TelefoneType popularTelefone(String ddd, String numero, Integer codigo){
		TelefoneType telefone = new TelefoneType();
		telefone.setDdd(Integer.valueOf(ddd));
		telefone.setNumero(Integer.valueOf(numero));
		TipoType tipo = new TipoType();
		tipo.setCodigo(codigo);
		telefone.setTipo(tipo);
		return telefone;
	}
	
	/**
	 * Método responsavel por popular as informações de endereço
	 * @param infoApiCredenciamento
	 * @param infoCredenciamento
	 */
	private void popularEnderecos(RestApiServiceRequestDTO infoApiCredenciamento, CredenciamentoDTO infoCredenciamento){
		List<EnderecoType> listaEndereco = new ArrayList<>();
		tratarInfoEnderecoCliente(infoCredenciamento.getEndereco());
		listaEndereco.add(popularEndereco(infoCredenciamento.getEndereco(), END_COMERCIAL));		
		//CORRESPONDÊNCIA
		if(isNotEmptyOrNull(infoCredenciamento.getEndereco().getLogradouroC()) && isNotEmptyOrNull(infoCredenciamento.getEndereco().getComplementoC())){
			listaEndereco.add(popularEndereco(infoCredenciamento.getEndereco(), END_CORRESPONDENCIA));
		}
		infoApiCredenciamento.getCliente().setEnderecos(listaEndereco);
	}
	
	/**
	 * Método responsavel pela retirada de caracteres especiais
	 * @param endereco
	 */
	private void tratarInfoEnderecoCliente(Endereco endereco){
		endereco.setCep(endereco.getCep().replace(SimuladorUtils.TRACO, SimuladorUtils.STRING_VAZIA));
		endereco.setEstado(endereco.getEstado().equals("NF")?"":endereco.getEstado());
		//CLIENTE SOLICITOU PARA DUPLICAR O ENDERECO COMERCIAL & cORRESPONDECIA
		if(null != endereco.getDuplicarEndereco()){
			endereco.setLogradouroC(endereco.getLogradouro());
			endereco.setComplementoC(endereco.getComplemento());
			endereco.setCidadeC(endereco.getCidade());
			endereco.setEstadoC(endereco.getEstado());
			endereco.setCepC(endereco.getCep());
		}
		if(endereco.getCepC()!=null){
			endereco.setCepC(endereco.getCepC().replace(SimuladorUtils.TRACO, SimuladorUtils.STRING_VAZIA));
		}
		
	}

	/**
	 * Método responsavel por popular as informações de Endereço
	 * @param infoEndereco
	 * @param codigo
	 * @return
	 */
	private EnderecoType popularEndereco(Endereco infoEndereco, Integer codigo){
		EnderecoType endereco = new EnderecoType();
		endereco.setLogradouro(codigo.equals(END_COMERCIAL)?infoEndereco.getLogradouro():infoEndereco.getLogradouroC());
		endereco.setComplemento(codigo.equals(END_COMERCIAL)?infoEndereco.getComplemento(): infoEndereco.getComplementoC());
		endereco.setBairro("NI");
		endereco.setCep(codigo.equals(END_COMERCIAL)?Integer.valueOf(infoEndereco.getCep()): Integer.valueOf(infoEndereco.getCepC()));
		endereco.setCidade(codigo.equals(END_COMERCIAL)?infoEndereco.getCidade() :infoEndereco.getCidadeC());
		endereco.setNumero(codigo.equals(END_COMERCIAL)?infoEndereco.getNumero(): infoEndereco.getNumeroC());
		endereco.setPais("BRASIL");
		TipoType tipo = new TipoType();
		tipo.setCodigo(codigo);
		endereco.setTipo(tipo);
		endereco.setUf(codigo.equals(END_COMERCIAL)?infoEndereco.getEstado(): infoEndereco.getEstadoC());
		return endereco;
	}
	
	/**
	 * Método responsavel por popular a lista de proprietários
	 * @param infoApiCredenciamento
	 * @param infoCredenciamento
	 */
	private void popularProprietarios(RestApiServiceRequestDTO infoApiCredenciamento, CredenciamentoDTO infoCredenciamento){
		List<ProprietarioType> listaProprietarios = new ArrayList<>();
		tratarInfoProprietarios(infoCredenciamento.getProprietario());
		listaProprietarios.add(popularProprietario(infoCredenciamento.getProprietario().getNome(), 
												   infoCredenciamento.getProprietario().getCpf(),
												   infoCredenciamento.getProprietario().getDataNascimento()));
		// PROPRIETARIO 2
		if(isNotEmptyOrNull(infoCredenciamento.getProprietario().getNome2()) && 
				isNotEmptyOrNull(infoCredenciamento.getProprietario().getCpf2()) && 
				isNotEmptyOrNull(infoCredenciamento.getProprietario().getDataNascimento2())){
			
			listaProprietarios.add(popularProprietario(infoCredenciamento.getProprietario().getNome2(), 
					   infoCredenciamento.getProprietario().getCpf2(),
					   infoCredenciamento.getProprietario().getDataNascimento2()));
		}
		// PROPRIETARIO 3
		if(isNotEmptyOrNull(infoCredenciamento.getProprietario().getNome3()) && 
				isNotEmptyOrNull(infoCredenciamento.getProprietario().getCpf3()) && 
				isNotEmptyOrNull(infoCredenciamento.getProprietario().getDataNascimento3())){
			
			listaProprietarios.add(popularProprietario(infoCredenciamento.getProprietario().getNome3(), 
					   infoCredenciamento.getProprietario().getCpf3(),
					   infoCredenciamento.getProprietario().getDataNascimento3()));
		}

		infoApiCredenciamento.getCliente().setProprietarios(listaProprietarios);
	}
	
	/**
	 * Método responsavel pela retirada de caracteres especiais
	 * @param endereco
	 */
	private void tratarInfoProprietarios(Proprietario proprietario){
		//TRATAR CPF
		proprietario.setCpf(proprietario.getCpf().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));
		proprietario.setCpf2(SimuladorUtils.tratarStringNull(proprietario.getCpf2()));
		proprietario.setCpf3(SimuladorUtils.tratarStringNull(proprietario.getCpf3()));
		if(!proprietario.getCpf2().isEmpty())
			proprietario.setCpf2(proprietario.getCpf2().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));
		if(!proprietario.getCpf3().isEmpty())
			proprietario.setCpf3(proprietario.getCpf3().replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA));

		//TRATAR NOME
		proprietario.setNome2(SimuladorUtils.tratarStringNull(proprietario.getNome2()));
		proprietario.setNome3(SimuladorUtils.tratarStringNull(proprietario.getNome3()));

		//TRATAR Data Nascimento
		proprietario.setDataNascimento(null != proprietario.getDtNascimento() ? SimuladorUtils.dateToStringApi(proprietario.getDtNascimento()):SimuladorUtils.STRING_VAZIA);
		proprietario.setDataNascimento2(null != proprietario.getDtNascimento2() ? SimuladorUtils.dateToStringApi(proprietario.getDtNascimento2()):SimuladorUtils.STRING_VAZIA);
		proprietario.setDataNascimento3(null != proprietario.getDtNascimento3() ? SimuladorUtils.dateToStringApi(proprietario.getDtNascimento3()):SimuladorUtils.STRING_VAZIA);
	}

	/**
	 * Método responsavel por popular as informações de proprietários
	 * @param nome
	 * @param cpf
	 * @param dataNascimento
	 * @return
	 */
	private ProprietarioType popularProprietario(String nome, String cpf, String dataNascimento){
		ProprietarioType proprietario = new ProprietarioType();
		proprietario.setNome(nome);
		proprietario.setCpf(Long.valueOf(cpf));
		proprietario.setDataNascimento(dataNascimento);
		return proprietario;
	}

	/**
	 * Método responsavel por popular as informações complementares da API
	 * @param infoApiCredenciamento
	 * @param infoCredenciamento
	 */
	private void popularInfoComplementar(RestApiServiceRequestDTO infoApiCredenciamento, CredenciamentoDTO infoCredenciamento){
		infoApiCredenciamento.setCodigoFerramenta(infoCredenciamento.getTipoFerramenta());
		infoApiCredenciamento.setIndicadorAgro(infoCredenciamento.getSolPlano().getIndicadorAgro()!=null? true: false);
		infoApiCredenciamento.getCliente().setNomePlaqueta(infoCredenciamento.getCliente().getNomePlaqueta());
		infoApiCredenciamento.getCliente().setNomeContato(infoCredenciamento.getCliente().getPessoaContato());
		infoApiCredenciamento.getCliente().setEmailContato(infoCredenciamento.getCliente().getEmailContato());
		infoApiCredenciamento.getCliente().setCodigoAfiliador(null != infoCredenciamento.getCodigoAfiliador()?infoCredenciamento.getCodigoAfiliador().toString():"0");
		infoApiCredenciamento.getCliente().setFaturamentoMedio(isNotEmptyOrNull(infoCredenciamento.getSolPlano().getValorFaturamento()) ? 
				new BigDecimal(infoCredenciamento.getSolPlano().getValorFaturamento()):new BigDecimal("0"));
		infoApiCredenciamento.getCliente().setCodigoTipoPlanoCielo(Integer.valueOf(infoCredenciamento.getSolPlano().getTipoPlanoCielo()));
		String diasLiquidacao = infoCredenciamento.getSolPlano().getQtdadeDiasLiquidacao();
		infoApiCredenciamento.getCliente().setQuantidadeDiasLiquidacao(null != diasLiquidacao ?Integer.valueOf(infoCredenciamento.getSolPlano().getQtdadeDiasLiquidacao()):0);
	}

	/**
	 * Método responsavel por verificar se a String é diferente de null && empty
	 * @param info
	 * @return
	 */
	private Boolean isNotEmptyOrNull(String info){
		return (null != info && !info.isEmpty());
	}

	/**
	 * Método responsavel por tratar as execeções de Runtime
	 * @return
	 */
	private MessageLayoutResponse tratarRuntimeErroSistemico(){
		MessageLayoutResponse response = new MessageLayoutResponse();
		response.setCodigoProcessamento(StatusProcessamento.PROBLEMA_SISTEMICO);
		response.setMensagemErro("ERRO SISTEMICO");
		return response;
	}

}
