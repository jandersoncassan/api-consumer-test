package br.com.cielo.simulador.service.impl;

import java.lang.reflect.Field;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.annotation.FieldCrd;
import br.com.cielo.simulador.model.DadosFixos;
import br.com.cielo.simulador.service.IDadosFixos;
import br.com.cielo.simulador.service.core.InfoClienteAbstractService;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Service
public class DadosFixosServiceImpl extends InfoClienteAbstractService<DadosFixos> implements IDadosFixos{

	private static final Logger LOG = LoggerFactory.getLogger(ClienteServiceImpl.class);

	@Override
	public StringBuffer tratarInformacoes(StringBuffer messageCics, Object objDadosFixos) {
		return init(messageCics, objDadosFixos);
	}

	/**
	 * Método responsavel pelas informações dos dados fixos
	 * @param messageCics
	 * @param objDadosFixos
	 * @return StringBuffer
	 */
	private StringBuffer init(StringBuffer messageCics, Object objDadosFixos){
		LOG.info("CONSISTIR INFORMACOES DADOS FIXOS");
		DadosFixos dadosFixos = (DadosFixos) objDadosFixos;
		return popularInfoDadosFixos(messageCics, dadosFixos);
	}
	
	/**
	 * Método responsavel por popular as informações dos dados fixos
	 * @param messageCics
	 * @param objDadosFixos
	 * @return StringBuffer
	 */
	private StringBuffer popularInfoDadosFixos(StringBuffer messageCics, DadosFixos dadosFixos) {
		tratarInfoCliente(dadosFixos);
		return tratarConteudoMessage(messageCics, dadosFixos);
	}	
	
	/**
	 * Tratar informações dados fixos
	 * @param objDadosFixos
	 */
	private void tratarInfoCliente(DadosFixos dadosFixos){
		dadosFixos.setCodigoMensagem("045");
		dadosFixos.setNumIdentChamada("CRD#");
		Field[] fields = dadosFixos.getClass().getDeclaredFields();
		try{
			for (Field field : fields) {
				FieldCrd fieldCrd = field.getAnnotation(FieldCrd.class);
				if (null != fieldCrd) {
					field.setAccessible(true);
					if(field.getName().equals("codigoMensagem") ||field.getName().equals("numIdentChamada"))
						continue;
					String tipo = fieldCrd.tipo();
					field.set(dadosFixos, valorField(tipo));
				}
			}
		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO AO TRATAR O CONTEUDO DA MENSAGEM ", ex);
		}
	}
	
	/**
	 * Método responsavel por retornar os valores padrões dos campos fixos
	 * @param tipo
	 * @return String
	 */
	private String valorField(String tipo){
		return (tipo.equals("N")?SimuladorUtils.STRING_ZERO:SimuladorUtils.STRING_ESPACOS);
	}

}
