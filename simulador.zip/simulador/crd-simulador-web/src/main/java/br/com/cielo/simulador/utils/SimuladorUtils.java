package br.com.cielo.simulador.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.Gson;

public class SimuladorUtils {

	public static final String REGEX_CLEAN_CPF_CNPJ = "(\\.|-|\\/)";
	public static final String REGEX_CLEAN_MASK_MONETARIA = "(\\.|\\,)";
	public static final String STRING_VAZIA = "";
	public static final String TRACO = "-";
	
	public static final String STRING_ZERO = "0";
	public static final String STRING_ZERO_SETE = "07";
	public static final String STRING_ESPACOS = " ";
	public static final String STRING_999 = "999";
	
	public static final int NUM_ZERO = 0;
	public static final int NUM_QUATRO = 4;
	public static final int NUM_TRINTA_UM = 31;
	public static final int NUM_TRINTA_DOIS = 32;
	public static final int NUM_TRINTA_SETE = 37;
	public static final int NUM_QUARENTA_SETE = 47;
	public static final int NUM_CEM = 100;
	public static final int NUM_NOVENTA_TRES = 93;
	
	public static final String EC_ZERADO = "0000000000";
	
	public static final String ERRO_SISTEMICO = "erro.sistemico";
	
	public static final String PROPRIETARIO="Proprietário";
	
	/* HEADER*/
	public static final String HEADER_USER = "tns.osb.header.user";
	public static final String HEADER_PASS = "tns.osb.header.pass";
	
	/* ENDPOINTS*/
    public static final String ENDPOINT_LISTA_MCC_STAR = "endpoint.lista.mcc.star";   
    public static final String ENDPOINT_CREDENCIAR_CRD = "endpoint.credenciar.crd";   
    		
    public static final String TOKEN_DASHBOARD = "XYabZSIMULADORWcdKHCRD";
	/**
	 * Método responsavel por tratar String nula
	 * @param valor
	 * @return String
	 */
	public static String tratarStringNull(String valor){
		return (null == valor ? STRING_VAZIA: valor);
	}
	
	/**
	 * Método responsavel por converter o Date para String
	 * @param date
	 * @return String
	 */
	public static String dateToStringCics(Date date){
		String DATE_FORMAT_NOW = "ddMMyy";
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		return sdf.format(date);
	}

	/**
	 * Método responsavel por converter o Date para String
	 * @param date
	 * @return String
	 */
	public static String dateToStringApi(Date date){
		String DATE_FORMAT_NOW = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		return sdf.format(date);
	}

	/**
	 * Método responsavel por transformar Object in Json
	 * @param object
	 * @return
	 */
	public static String objectToJson(Object object){
		Gson gson = new Gson();
		String json = gson.toJson(object);
		return json;
	}
	
	/**
	 * Método responsavel por transformar Json in Object
	 * @param object
	 * @return
	 */
	public static Object jsonToObject(String json, Class<?> clazz){
		Gson gson = new Gson();
		Object Object = gson.fromJson(json, clazz);
		return Object;
	}

}
