package br.com.cielo.simulador.service.core;

import java.lang.reflect.Field;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.simulador.annotation.FieldCrd;

/**
 * Classe abstrata responsavel pelas consistência da mensagem
 * 
 * @author janderson@cielo
 * @since 1.0.0
 */
public abstract class InfoClienteAbstractService<T> {

	private static final Logger LOG = LoggerFactory.getLogger(InfoClienteAbstractService.class);

	private static final String ALFANUMERICO = "A";
	private static final String ESPACOS = " ";
	private static final String ZEROS = "0";

	/**
	 * Método responsavel por tratar as informações de cada objeto e gerar a
	 * String que enviaremos para o CICs
	 * 
	 * @param messageCics
	 * @param objectMessage
	 * @return String
	 */
	public StringBuffer tratarConteudoMessage(StringBuffer messageCics, T objectMessage) {
		Field[] fields = objectMessage.getClass().getDeclaredFields();
		try{
			for (Field field : fields) {
				FieldCrd fieldCrd = field.getAnnotation(FieldCrd.class);
				if (null != fieldCrd) {
					// POPULAR CONTEUDO DA MENSAGEM
					popularConteudoMessage(field, fieldCrd, messageCics, objectMessage);
				}
			}
		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO AO TRATAR O CONTEUDO DA MENSAGEM ", ex);
		}
		return messageCics;
	}

	/**
	 * Método responsavel pelas consistências das informações de credenciamento
	 * 
	 * @param field
	 * @param fieldCrd
	 * @param messageCics
	 * @param objectMessage
	 * @return StringBuffer
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
	private void popularConteudoMessage(Field field, FieldCrd fieldCrd, StringBuffer messageCics, T objectMessage)
			throws IllegalArgumentException, IllegalAccessException {
		
		field.setAccessible(true);
		String info = (String) field.get(objectMessage);
		String tipo = fieldCrd.tipo();
		int tamanho = Integer.valueOf(fieldCrd.tamanho());
		// TRATAMENTO LEFTPAD
		info = tratarDadosString(info, tipo, tamanho);
		// REPLACE NA POSIÇÃO STRING
		int start = Integer.valueOf(fieldCrd.posInicial());
		int end = Integer.valueOf(fieldCrd.posFinal());
		replaceMessageCics(messageCics, info, start, end);
		
	}

	/**
	 * Método responsavel por completar as informaçoes da string de acordo com o
	 * layout do SEC
	 * 
	 * @param tipo
	 * @param tamanho
	 */
	private String tratarDadosString(String info, String tipo, int tamanho) {
		if(tipo.equals(ALFANUMERICO)){
			info = StringUtils.rightPad(info, tamanho, ESPACOS);		
		}else{
			info = StringUtils.leftPad(info, tamanho, ZEROS);	
		}
		return info;
	}

	/**
	 * Método responsavel por efetuar o replace na posição da String
	 * 
	 * @param messageCics
	 * @param info
	 * @param start
	 * @param end
	 */
	private void replaceMessageCics(StringBuffer messageCics, String info, int start, int end) {
		messageCics.replace(start-1, end, info);
	}
}
