package br.com.cielo.simulador.service;

public interface IDadosFixos extends IMessageCore{

}
