package br.com.cielo.simulador.service;

public interface ITelefoneService extends IMessageCore{

}
