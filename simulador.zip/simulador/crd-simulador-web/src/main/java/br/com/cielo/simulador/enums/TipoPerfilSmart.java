package br.com.cielo.simulador.enums;

public enum TipoPerfilSmart {
	
	ISO(1, "ISO"), DDN(2, "DDN"), COMERCIAL(3, "Comercial");
	
	private Integer codigo;
	private String descricao;
	
	private TipoPerfilSmart(Integer codigo, String descricao){
		this.codigo = codigo;
		this.descricao = descricao;
	}

	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

}
