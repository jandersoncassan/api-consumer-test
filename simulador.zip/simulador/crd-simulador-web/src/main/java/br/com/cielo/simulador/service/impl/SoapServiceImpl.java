package br.com.cielo.simulador.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.BancoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CadeiaForcadaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DadosProprietarioType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DomiciliosBancarios;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EnderecoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EstabelecimentoComercialType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.OfertaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucaoCapturaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucoesCaptura;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.TelefoneType;
import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.enums.FerramentaEnum;
import br.com.cielo.simulador.enums.StatusProcessamento;
import br.com.cielo.simulador.model.Endereco;
import br.com.cielo.simulador.model.MessageLayoutResponse;
import br.com.cielo.simulador.model.Proprietario;
import br.com.cielo.simulador.model.Telefone;
import br.com.cielo.simulador.service.ISoapClientService;
import br.com.cielo.simulador.service.ISoapService;
import br.com.cielo.simulador.utils.SimuladorUtils;

/**
 * Classe responsavel pela implementação do serviço de inclusão de proposta via SOAP CRD
 * 
 * @author janderson@cielo
 */
@Service
public class SoapServiceImpl implements ISoapService {

    private static final Logger LOG = LogManager.getLogger(SoapServiceImpl.class);

    @Autowired
    private ISoapClientService soapClientService;

    private final Integer TEL_COMERCIAL = 2;
    private final Integer TEL_CELULAR = 3;

    private final Integer END_COMERCIAL = 2;
    private final Integer END_CORRESPONDENCIA = 3;

    @Override
    public MessageLayoutResponse messageToSoapCrd(CredenciamentoDTO infoCredenciamento) {
        try {
            LOG.info("ENVIAR INFORMACOES PARA CREDENCIAMENTO SOAP-CRD");
            CredenciarClienteRequest clienteRequest = popularInformacoes(infoCredenciamento);
            LOG.info("REQUEST : \n" + SimuladorUtils.objectToJson(clienteRequest));
            return (soapClientService.incluirProposta(clienteRequest));
        } catch (RuntimeException ex) {
            LOG.error("ERRO PROCESSAMENTO SOAP", ex);
            return tratarRuntimeErroSistemico();
        }
    }

    private CredenciarClienteRequest popularInformacoes(CredenciamentoDTO infoCredenciamento) {
        CredenciarClienteRequest request = new CredenciarClienteRequest();
        popularInfoComplementar(request, infoCredenciamento);
        popularEstabelecComercial(request, infoCredenciamento);
        popularSolucoesCaptura(request, infoCredenciamento);
        return request;
    }

    /**
     * Método responsavel por popular as informações complementares
     * 
     * @param request
     * @param infoCredenciamento
     */
    private void popularInfoComplementar(CredenciarClienteRequest request, CredenciamentoDTO infoCredenciamento) {
        request.setCodigoFerramenta(infoCredenciamento.getTipoFerramenta());
        request.setIndicadorAgro(infoCredenciamento.getSolPlano().getIndicadorAgro());
        request.setLoginUsuario(infoCredenciamento.getLoginUsuarioOperador());
        //TRATAMENTO PERFIL SMART
        if(FerramentaEnum.isSmart(infoCredenciamento.getTipoFerramenta())){
        	request.setCodigoTipoPerfilSmart(Integer.valueOf(infoCredenciamento.getCodPerfilSmart()));
        }
        //RL05 SPRINT02 SMART
        request.setNomeExecutivo(infoCredenciamento.getNomeExecutivo());
    }

    /**
     * Método responsavel por popular as informações de estabelecimento comercial
     * 
     * @param request
     * @param infoCredenciamento
     */
    private void popularEstabelecComercial(CredenciarClienteRequest request, CredenciamentoDTO infoCredenciamento) {
        EstabelecimentoComercialType estabelecimento = new EstabelecimentoComercialType();
        popularInfoCliente(estabelecimento, infoCredenciamento);
        popularEnderecos(estabelecimento, infoCredenciamento);
        popularDomicilioBancario(estabelecimento, infoCredenciamento);
        popularProprietarios(estabelecimento, infoCredenciamento);
        popularTelefones(estabelecimento, infoCredenciamento);
        request.setEstabelecimentoComercial(estabelecimento);
    }

    /**
     * Método responsavel por popular as informações do cliente
     * 
     * @param estabelecimento
     * @param infoCredenciamento
     */
    private void popularInfoCliente(EstabelecimentoComercialType estabelecimento,
            CredenciamentoDTO infoCredenciamento) {
        estabelecimento.setCodigoAfiliador(
                null != infoCredenciamento.getCodigoAfiliador() ? infoCredenciamento.getCodigoAfiliador() : 0l);
        estabelecimento.setCodigoRamoAtividade(Integer.valueOf(infoCredenciamento.getCliente().getRamoAtividade()));
        estabelecimento.setCodigoTipoPessoa(infoCredenciamento.getCliente().getTipoPessoa());
        estabelecimento.setCodigoTipoPlanoCielo(Integer.valueOf(infoCredenciamento.getSolPlano().getTipoPlanoCielo()));
        // estabelecimento.setDataAtivacao(dataAtivacao); OPCIONAL
        estabelecimento.setEmailContato(infoCredenciamento.getCliente().getEmailContato());
        // estabelecimento.setIndicadorCadastroDuplicado(indicadorCadastroDuplicado); OPCIONAL
        // estabelecimento.setIndicadorEstabComercialMigrado(indicadorEstabComercialMigrado);OPCIONAL
        estabelecimento.setIndicadorMicroEmpreendedorIndividual(infoCredenciamento.getCliente().getIndicadorMei());
        estabelecimento.setNomeFantasia(infoCredenciamento.getCliente().getNomeFantasia());
        estabelecimento.setNomePessoaContato(infoCredenciamento.getCliente().getPessoaContato());
        estabelecimento.setNomePlaqueta(infoCredenciamento.getCliente().getNomePlaqueta());
        estabelecimento.setNomeRazaoSocial(infoCredenciamento.getCliente().getNomeRazaoSocial());
        estabelecimento.setNumeroCpfCnpj(Long.valueOf(infoCredenciamento.getCliente().getCpfCnpj()
                .replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA)));
        // estabelecimento.setNumeroEc(numeroEc);OPCIONAL
        // estabelecimento.setNumeroInscricaoEstadual(numeroInscricaoEstadual);OPCIONAL
        estabelecimento.setQuantidadeDiasLiquidacao(
                isNotEmptyOrNull(infoCredenciamento.getSolPlano().getQtdadeDiasLiquidacao())
                        ? Integer.valueOf(infoCredenciamento.getSolPlano().getQtdadeDiasLiquidacao())
                        : 0);
        estabelecimento.setValorMedioFaturamento(
                formatarValorFaturamento(infoCredenciamento.getSolPlano().getValorFaturamento()));
        estabelecimento.setTaxaArv(formatarTaxaArv(infoCredenciamento.getCliente().getTaxaArv()));

        OfertaType oferta = new OfertaType();
        String codigoOferta = infoCredenciamento.getCliente().getCodigoOferta();
        if (codigoOferta != null && !codigoOferta.equals("")) {
            oferta.setCodigoOferta(codigoOferta);
        }

        String indicadorAceiteOferta = infoCredenciamento.getCliente().getIndicadorAceiteOferta();
        oferta.setIndicadorAceiteOferta(indicadorAceiteOferta != null && indicadorAceiteOferta.equals("S"));

        String indicadorOfertaAssociada = infoCredenciamento.getCliente().getIndicadorOfertaAssociada();
        oferta.setIndicadorOfertaAssociada(indicadorOfertaAssociada != null && indicadorOfertaAssociada.equals("S"));

        String nivelOferta = infoCredenciamento.getCliente().getNivelOferta();
        if (nivelOferta != null && !nivelOferta.equals("")) {
            oferta.setNivelOferta(nivelOferta);
        }
        Optional<Integer> codigoOfertaCombo = Optional.ofNullable(infoCredenciamento.getCliente().getCodigoOfertaCombo());
        if(codigoOfertaCombo.isPresent()){
        	 oferta.setCodigoOfertaComboAluguel(codigoOfertaCombo.get());
        }
        estabelecimento.setOferta(oferta);
        
        CadeiaForcadaType cadeiaForcada = new CadeiaForcadaType();
        //RL05-SPRINT02 SMART
        cadeiaForcada.setNumeroEc(infoCredenciamento.getCliente().getEcCadeiaForcada());
        cadeiaForcada.setNumeroEcEspelho(infoCredenciamento.getCliente().getEcEspelho());
        Optional<String> indEspelhamentoTaxa = Optional.ofNullable(infoCredenciamento.getCliente().getIndEspelhamentoTaxa());
       
        cadeiaForcada.setIndicadorEspelhamentoTaxa(indEspelhamentoTaxa.isPresent() ? 
        												indEspelhamentoTaxa.get().equals("S")?Boolean.TRUE: Boolean.FALSE
        																			: Boolean.FALSE);
        estabelecimento.setCadeiaForcada(cadeiaForcada);
    }

    private BigDecimal formatarValorFaturamento(String valorFaturamento) {
        return (isNotEmptyOrNull(valorFaturamento)
                ? new BigDecimal(valorFaturamento.replaceAll("\\.", SimuladorUtils.STRING_VAZIA).replace(",", "."))
                : new BigDecimal("0"));
    }

    private BigDecimal formatarTaxaArv(String taxaArv) {
        return (isNotEmptyOrNull(taxaArv)
                ? new BigDecimal(taxaArv.replaceAll("\\.", SimuladorUtils.STRING_VAZIA).replace(",", "."))
                : new BigDecimal("0"));
    }

    /**
     * Método responsavel por popular as informações de Endereço
     * 
     * @param estabelecimento
     * @param infoCredenciamento
     */
    private void popularEnderecos(EstabelecimentoComercialType estabelecimento, CredenciamentoDTO infoCredenciamento) {
        List<EnderecoType> enderecos = new ArrayList<>();
        enderecos.add(popularEnderecoType(infoCredenciamento.getEndereco(), END_COMERCIAL));
        // CORRESPONDÊNCIA
        if (isNotEmptyOrNull(infoCredenciamento.getEndereco().getLogradouroC())
                && isNotEmptyOrNull(infoCredenciamento.getEndereco().getComplementoC())) {
            enderecos.add(popularEnderecoType(infoCredenciamento.getEndereco(), END_CORRESPONDENCIA));
        }
        EnderecoType[] enderecosArray = new EnderecoType[enderecos.size()];
        estabelecimento.setEnderecosEstabelecimento(enderecos.toArray(enderecosArray));
    }

    /**
     * Método responsavel por popular as informações de endereço
     * 
     * @param tipoEndereco
     * @param infoEndereco
     * @param enderecoAtivacao
     * @return EnderecoType
     */
    private EnderecoType popularEnderecoType(Endereco infoEndereco, Integer tipoEndereco) {

        EnderecoType endereco = new EnderecoType();
        endereco.setDescricaoComplementoEndereco(
                tipoEndereco.equals(END_COMERCIAL) ? infoEndereco.getComplemento() : infoEndereco.getComplementoC());
        // endereco.setNomeBairro(nomeBairro);OPCIONAL
        endereco.setNomeCidade(
                tipoEndereco.equals(END_COMERCIAL) ? infoEndereco.getCidade() : infoEndereco.getCidadeC());
        endereco.setNomeLogradouro(
                tipoEndereco.equals(END_COMERCIAL) ? infoEndereco.getLogradouro() : infoEndereco.getLogradouroC());
        endereco.setNumeroCEP(Integer.valueOf(tipoEndereco.equals(END_COMERCIAL)
                ? infoEndereco.getCep().replace(SimuladorUtils.TRACO, SimuladorUtils.STRING_VAZIA)
                : infoEndereco.getCepC().replace(SimuladorUtils.TRACO, SimuladorUtils.STRING_VAZIA)));
        endereco.setNumeroLogradouro(
                tipoEndereco.equals(END_COMERCIAL) ? infoEndereco.getNumero() : infoEndereco.getNumeroC());
        endereco.setSiglaEstado(
                tipoEndereco.equals(END_COMERCIAL) ? infoEndereco.getEstado() : infoEndereco.getEstadoC());
        endereco.setTipoEndereco(tipoEndereco);
        return endereco;
    }

    /**
     * Método responsavel por popular as informações de Domicilios Bancários
     * 
     * @param estabelecimento
     * @param infoCredenciamento
     */
    private void popularDomicilioBancario(EstabelecimentoComercialType estabelecimento,
            CredenciamentoDTO infoCredenciamento) {
        DomiciliosBancarios domicilios = new DomiciliosBancarios();
        BancoType bancoType = new BancoType();
        bancoType.setCodigoBanco(infoCredenciamento.getDomicilioBancario().getCodBanco());
        bancoType.setNumeroAgencia(infoCredenciamento.getDomicilioBancario().getCodAgencia());
        bancoType.setNumeroContaCorrente(infoCredenciamento.getDomicilioBancario().getNumeroConta().replace("-", ""));
        bancoType.setTipoConta(infoCredenciamento.getDomicilioBancario().getTipoConta());
        domicilios.setDomicilioBancario(bancoType);
        estabelecimento.setDomiciliosBancarios(domicilios);
    }

    /**
     * Método responsavel por popular as informações d eproprietarios
     * 
     * @param estabelecimento
     * @param infoCredenciamento
     */
    private void popularProprietarios(EstabelecimentoComercialType estabelecimento,
            CredenciamentoDTO infoCredenciamento) {
        List<DadosProprietarioType> proprietarios = new ArrayList<>();
        proprietarios.add(popularProprietarioType(infoCredenciamento.getProprietario(), 1));
        // PROPRIETARIO 2
        if (isNotEmptyOrNull(infoCredenciamento.getProprietario().getNome2())
                || isNotEmptyOrNull(infoCredenciamento.getProprietario().getCpf2())
                || null != infoCredenciamento.getProprietario().getDtNascimento2()) {
            proprietarios.add(popularProprietarioType(infoCredenciamento.getProprietario(), 2));
        }
        // PROPRIETARIO 3
        if (isNotEmptyOrNull(infoCredenciamento.getProprietario().getNome3())
                || isNotEmptyOrNull(infoCredenciamento.getProprietario().getCpf3())
                || null != infoCredenciamento.getProprietario().getDtNascimento3()) {

            proprietarios.add(popularProprietarioType(infoCredenciamento.getProprietario(), 3));
        }
        DadosProprietarioType[] proprietariosArray = new DadosProprietarioType[proprietarios.size()];
        estabelecimento.setProprietarios(proprietarios.toArray(proprietariosArray));
    }

    /**
     * Método responsavel por popular as informações do proprietário
     * 
     * @param proprietario
     * @param proprietario
     * @return DadosProprietarioType
     */
    private DadosProprietarioType popularProprietarioType(Proprietario proprietario, Integer sequencia) {
        DadosProprietarioType prop = new DadosProprietarioType();

        prop.setDataNascimento(sequencia.equals(1)
                ? getDataNascimento(proprietario.getDtNascimento())
                : sequencia.equals(2)
                        ? getDataNascimento(proprietario.getDtNascimento2())
                        : getDataNascimento(proprietario.getDtNascimento3()));
        prop.setNome(sequencia.equals(1)
                ? proprietario.getNome()
                : sequencia.equals(2) ? proprietario.getNome2() : proprietario.getNome3());
        prop.setNumeroCpf(sequencia.equals(1)
                ? getCpf(proprietario.getCpf())
                : sequencia.equals(2) ? getCpf(proprietario.getCpf2()) : getCpf(proprietario.getCpf3()));
        return prop;
    }

    /**
     * Tratamento da data de nascimento
     * 
     * @param dataNascimento
     * @return
     */
    private String getDataNascimento(Date dataNascimento) {
        return (null != dataNascimento ? SimuladorUtils.dateToStringApi(dataNascimento) : "0001-01-01");
    }

    /**
     * Tratamento do cpf
     * 
     * @param cpf
     * @return
     */
    private String getCpf(String cpf) {
        return cpf.replaceAll(SimuladorUtils.REGEX_CLEAN_CPF_CNPJ, SimuladorUtils.STRING_VAZIA);
    }

    /**
     * Método responsavel por popular as informações de telefones
     * 
     * @param estabelecimento
     * @param infoCredenciamento
     */
    private void popularTelefones(EstabelecimentoComercialType estabelecimento, CredenciamentoDTO infoCredenciamento) {
        List<TelefoneType> telefones = new ArrayList<>();
        telefones.add(popularTelefoneType(infoCredenciamento.getTelefone(), TEL_COMERCIAL));
        // VERIFICA SE O CELULAR FOI INFORMADO
        if (isNotEmptyOrNull(infoCredenciamento.getTelefone().getDddCelular())
                && isNotEmptyOrNull(infoCredenciamento.getTelefone().getNumeroCelular())) {
            telefones.add(popularTelefoneType(infoCredenciamento.getTelefone(), TEL_CELULAR));
        }
        TelefoneType[] telefonesArray = new TelefoneType[telefones.size()];
        estabelecimento.setTelefonesEstabelecimento(telefones.toArray(telefonesArray));
    }

    /**
     * Método responsavel por criar os telefones
     * 
     * @param telefone
     * @param tEL_COMERCIAL2
     * @return
     */
    private TelefoneType popularTelefoneType(Telefone infoTelefone, Integer tipo) {
        TelefoneType telefone = new TelefoneType();
        telefone.setNumeroDDD(tipo.equals(TEL_CELULAR)
                ? Integer.valueOf(tratarDdd(infoTelefone.getDddCelular()))
                : Integer.valueOf(tratarDdd(infoTelefone.getDddComercial())));
        telefone.setNumeroTelefone(tipo.equals(TEL_CELULAR)
                ? tratarTelefone(infoTelefone.getNumeroCelular())
                : tratarTelefone(infoTelefone.getNumeroComercial()));
        telefone.setTipoTelefone(tipo);
        return telefone;
    }

    /**
     * Método responsavel por retornar as informações do ddd sem caracteres especiais
     * 
     * @param ddd
     * @return
     */
    private String tratarDdd(String ddd) {
        return ddd.replaceAll("[(|)]", "");
    }

    /**
     * Método responsavel pela retirada de caracteres especiais
     * 
     * @param telefone
     */
    private String tratarTelefone(String telefone) {
        return telefone.replace("-", "");
    }

    /**
     * Método responsavel por popular as informações de soluções de captura
     * 
     * @param request
     * @param infoCredenciamento
     */
    private void popularSolucoesCaptura(CredenciarClienteRequest request, CredenciamentoDTO infoCredenciamento) {
        SolucoesCaptura solucoes = new SolucoesCaptura();
        SolucaoCapturaType solucao = new SolucaoCapturaType();
        solucao.setCodigoSolucaoCaptura(Integer.valueOf(infoCredenciamento.getSolPlano().getTipoSolucaoCaptura()));
        solucao.setCodigoPacoteEcommerce(infoCredenciamento.getSolPlano().getCodPacoteEcommerce());
        solucao.setQuantidadeEquipamentos(null != infoCredenciamento.getSolPlano().getQtdadeEquipamento()
                ? infoCredenciamento.getSolPlano().getQtdadeEquipamento()
                : 0);

        String indicadorPagamentoPorLink = infoCredenciamento.getSolPlano().getIndicadorPagamentoPorLink();
        if (indicadorPagamentoPorLink != null && indicadorPagamentoPorLink.matches("^(S|s)$")) {
            solucao.setIndicadorPagamentoPorLink(Boolean.TRUE);
        } else {
            solucao.setIndicadorPagamentoPorLink(Boolean.FALSE);
        }
        solucao.setCodigoHorarioFuncionamento(infoCredenciamento.getSolPlano().getCodigoHorarioFuncionamento());
        //RL05 - SPRINT02
        Optional<String> indEntregaMaquinas = Optional.ofNullable(infoCredenciamento.getSolPlano().getIndEntregaMaquinas());
        solucao.setIndicadorEntregaMaquina(indEntregaMaquinas.isPresent() ?
        										indEntregaMaquinas.get().equals("S") ? Boolean.TRUE : Boolean.FALSE
        																  : Boolean.FALSE);
        
        solucoes.setSolucaoCaptura(solucao);

       
        request.setSolucoesCaptura(solucoes);
    }

    /**
     * Método responsavel por verificar se a String é diferente de null && empty
     * 
     * @param info
     * @return
     */
    private Boolean isNotEmptyOrNull(String info) {
        return (null != info && !info.isEmpty());
    }

    /**
     * Método responsavel por tratar as execeções de Runtime
     * 
     * @return
     */
    private MessageLayoutResponse tratarRuntimeErroSistemico() {
        MessageLayoutResponse response = new MessageLayoutResponse();
        response.setCodigoProcessamento(StatusProcessamento.PROBLEMA_SISTEMICO);
        response.setMensagemErro("ERRO SISTEMICO");
        return response;
    }

}
