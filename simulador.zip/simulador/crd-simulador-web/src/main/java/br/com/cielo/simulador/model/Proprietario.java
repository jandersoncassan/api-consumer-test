package br.com.cielo.simulador.model;

import java.util.Date;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import br.com.cielo.simulador.annotation.FieldCrd;

public class Proprietario {
	
	@FieldCrd(tamanho=32, posInicial=504, posFinal=535)
	@NotEmpty(message="{campo.proprietario.nome}")
	private String nome;
	
	@FieldCrd(tipo="N",tamanho=15, posInicial=538, posFinal=552)
	@NotEmpty(message="{campo.proprietario.cpf}")
	private String cpf;

	//@NotNull(message="{campo.proprietario.data.nascimento}")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dtNascimento;
	
	@FieldCrd(tipo="N",tamanho=6, posInicial=555, posFinal=560)
	private String dataNascimento;

	@FieldCrd(tamanho=32, posInicial=563, posFinal=594)
	private String nome2;

	@FieldCrd(tipo="N",tamanho=15, posInicial=597, posFinal=611)
	private String cpf2;
	
	@DateTimeFormat(pattern = "dd/MM/yyyy")	
	private Date dtNascimento2;
	
	@FieldCrd(tipo="N",tamanho=6, posInicial=614, posFinal=619)
	private String dataNascimento2;
	
	@FieldCrd(tamanho=32, posInicial=622, posFinal=653)
	private String nome3;

	@FieldCrd(tipo="N",tamanho=15, posInicial=656, posFinal=670)
	private String cpf3;

	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dtNascimento3;
	
	@FieldCrd(tipo="N",tamanho=6, posInicial=673, posFinal=678)
	private String dataNascimento3;


	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}

	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	/**
	 * @return the dtNascimento
	 */
	public Date getDtNascimento() {
		return dtNascimento;
	}

	/**
	 * @param dtNascimento the dtNascimento to set
	 */
	public void setDtNascimento(Date dtNascimento) {
		this.dtNascimento = dtNascimento;
	}

	/**
	 * @return the nome2
	 */
	public String getNome2() {
		return nome2;
	}

	/**
	 * @param nome2 the nome2 to set
	 */
	public void setNome2(String nome2) {
		this.nome2 = nome2;
	}

	/**
	 * @return the cpf2
	 */
	public String getCpf2() {
		return cpf2;
	}

	/**
	 * @param cpf2 the cpf2 to set
	 */
	public void setCpf2(String cpf2) {
		this.cpf2 = cpf2;
	}

	/**
	 * @return the dtNascimento2
	 */
	public Date getDtNascimento2() {
		return dtNascimento2;
	}

	/**
	 * @param dtNascimento2 the dtNascimento2 to set
	 */
	public void setDtNascimento2(Date dtNascimento2) {
		this.dtNascimento2 = dtNascimento2;
	}

	/**
	 * @return the nome3
	 */
	public String getNome3() {
		return nome3;
	}

	/**
	 * @param nome3 the nome3 to set
	 */
	public void setNome3(String nome3) {
		this.nome3 = nome3;
	}

	/**
	 * @return the cpf3
	 */
	public String getCpf3() {
		return cpf3;
	}

	/**
	 * @param cpf3 the cpf3 to set
	 */
	public void setCpf3(String cpf3) {
		this.cpf3 = cpf3;
	}

	/**
	 * @return the dtNascimento3
	 */
	public Date getDtNascimento3() {
		return dtNascimento3;
	}

	/**
	 * @param dtNascimento3 the dtNascimento3 to set
	 */
	public void setDtNascimento3(Date dtNascimento3) {
		this.dtNascimento3 = dtNascimento3;
	}

	/**
	 * @return the dataNascimento1
	 */
	public String getDataNascimento() {
		return dataNascimento;
	}

	/**
	 * @param dataNascimento1 the dataNascimento1 to set
	 */
	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	/**
	 * @return the dataNascimento2
	 */
	public String getDataNascimento2() {
		return dataNascimento2;
	}

	/**
	 * @param dataNascimento2 the dataNascimento2 to set
	 */
	public void setDataNascimento2(String dataNascimento2) {
		this.dataNascimento2 = dataNascimento2;
	}

	/**
	 * @return the dataNascimento3
	 */
	public String getDataNascimento3() {
		return dataNascimento3;
	}

	/**
	 * @param dataNascimento3 the dataNascimento3 to set
	 */
	public void setDataNascimento3(String dataNascimento3) {
		this.dataNascimento3 = dataNascimento3;
	}
}
