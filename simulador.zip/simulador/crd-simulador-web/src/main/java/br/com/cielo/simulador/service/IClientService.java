package br.com.cielo.simulador.service;

public interface IClientService extends IMessageCore{

}
