package br.com.cielo.simulador.dto;

import java.util.List;

import br.com.cielo.simulador.model.Criticas;
import br.com.cielo.simulador.model.EstabelComercial;
import br.com.cielo.simulador.model.StatusService;

public class RestApiServiceResponseDTO {
	
	private Integer codigo;//NUMERO DA PROPOSTA
	private StatusService status;
	private List<Criticas> criticas;
	private EstabelComercial cliente;
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * 
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	
	/**
	 * @return the status
	 */
	public StatusService getStatus() {
		return status;
	}
	
	/**
	 * @param status the status to set
	 */
	public void setStatus(StatusService status) {
		this.status = status;
	}
	
	/**
	 * @return the criticas
	 */
	public List<Criticas> getCriticas() {
		return criticas;
	}
	
	/**
	 * @param criticas the criticas to set
	 */
	public void setCriticas(List<Criticas> criticas) {
		this.criticas = criticas;
	}
	
	/**
	 * @return the cliente
	 */
	public EstabelComercial getCliente() {
		return cliente;
	}
	
	/**
	 * @param cliente the cliente to set
	 */
	public void setCliente(EstabelComercial cliente) {
		this.cliente = cliente;
	}
	
}
