package br.com.cielo.simulador.service;

import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.model.MessageLayoutResponse;

/**
 * Interface responsável pelo serviço do match de mensagens
 * @author janderson@cielo
 */
public interface IMessageService {

	/**
	 * Método responsavel por efetuar o match das informações para envio para o SEC (CICS_LINK)
	 * @return String
	 */
	MessageLayoutResponse messageToCicsLink(CredenciamentoDTO infoCredenciamento);
}
