package br.com.cielo.simulador.dto;

import java.util.ArrayList;
import java.util.List;

import br.com.cielo.simulador.model.RamoAtividadeMcc;

public class ListaRamoAtividadeMccDTO {

	private List<RamoAtividadeMcc> listaMcc = new ArrayList<>();

	public List<RamoAtividadeMcc> getListaMcc() {
		return listaMcc;
	}

	public void setListaMcc(List<RamoAtividadeMcc> listaMcc) {
		this.listaMcc = listaMcc;
	}
	
	
}
