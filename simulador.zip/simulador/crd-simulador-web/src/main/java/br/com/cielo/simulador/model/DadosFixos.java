package br.com.cielo.simulador.model;

import br.com.cielo.simulador.annotation.FieldCrd;

public class DadosFixos {

	@FieldCrd(tipo="N", tamanho=3, posInicial=1, posFinal=3)
	private String codigoMensagem;

	@FieldCrd(tamanho=8, posInicial=4, posFinal=11)
	private String identifSolicitante;

	@FieldCrd(tamanho=4, posInicial=8, posFinal=11)
	private String numIdentChamada;

	@FieldCrd(tamanho=19, posInicial=12, posFinal=30)
	private String vagoObrigatorio;

	@FieldCrd(tipo="N", tamanho=2, posInicial=31, posFinal=32)
	private String codigoErro;
	
	@FieldCrd(tipo="N", tamanho=15, posInicial=211, posFinal=225)
	private String inscricaoEstadual;

	@FieldCrd(tamanho=32, posInicial=428, posFinal=459)
	private String filler;

	@FieldCrd(tipo="N", tamanho=2, posInicial=460, posFinal=461)
	private String reservaCielo1;

	@FieldCrd(tipo="N", tamanho=10, posInicial=462, posFinal=471)
	private String reservaCielo2;

	@FieldCrd(tamanho=1, posInicial=684, posFinal=684)
	private String centroCompras;

	@FieldCrd(tamanho=1, posInicial=687, posFinal=687)
	private String tipoTerminal;

	@FieldCrd(tamanho=1, posInicial=690, posFinal=690)
	private String complementoMcc;

	@FieldCrd(tamanho=1, posInicial=693, posFinal=693)
	private String indicadorMobile;

	@FieldCrd(tamanho=449, posInicial=731, posFinal=1179)
	private String areaReservada1;
	
	@FieldCrd(tipo="N", tamanho=2, posInicial=737, posFinal=738)
	private String flagPacoteEcommerce;

	@FieldCrd(tipo="N", tamanho=2, posInicial=746, posFinal=747)
	private String flagTipoConta;
	
	@FieldCrd(tipo="N", tamanho=2, posInicial=754, posFinal=755)
	private String flagPlanoCielo;
	
	@FieldCrd(tipo="N", tamanho=2, posInicial=758, posFinal=759)
	private String flagVlFaturamento;
	
	@FieldCrd(tipo="N", tamanho=2, posInicial=773, posFinal=774)
	private String flagDiasLiquidacao;
	
	@FieldCrd(tipo="N", tamanho=2, posInicial=777, posFinal=778)
	private String flagSolucaoCaptura;
	
	@FieldCrd(tipo="N", tamanho=2, posInicial=785, posFinal=786)
	private String flagIndicadorAgro;
	
	@FieldCrd(tamanho=291, posInicial=1180, posFinal=1470)
	private String dadosInformais;

	@FieldCrd(tipo="N", tamanho=8, posInicial=1471, posFinal=1478)
	private String dataAfiliacao;

	@FieldCrd(tipo="N", tamanho=4, posInicial=1481, posFinal=1484)
	private String banco;
	
	@FieldCrd(tipo="N", tamanho=5, posInicial=1487, posFinal=1491)
	private String agencia;

	@FieldCrd(tamanho=14, posInicial=1494, posFinal=1507)
	private String conta;

	@FieldCrd(tamanho=1, posInicial=1510, posFinal=1510)
	private String protocolo;

	@FieldCrd(tamanho=1, posInicial=1513, posFinal=1513)
	private String duplCadastro;

	@FieldCrd(tamanho=1, posInicial=1516, posFinal=1516)
	private String operadoraSaude;

	@FieldCrd(tamanho=17, posInicial=1517, posFinal=1533)
	private String areaReservada2;

	@FieldCrd(tamanho=22, posInicial=1534, posFinal=1555)
	private String areaReservada3;

	@FieldCrd(tamanho=1, posInicial=1558, posFinal=1558)
	private String trocoFacil;

	@FieldCrd(tipo="N", tamanho=5, posInicial=1561, posFinal=1565)
	private String txTrocoFacil;

	@FieldCrd(tipo="N", tamanho=3, posInicial=1568, posFinal=1570)
	private String pzTrocoFacil;

	@FieldCrd(tamanho=1, posInicial=1573, posFinal=1573)
	private String flexCar;

	@FieldCrd(tipo="N", tamanho=5, posInicial=1576, posFinal=1580)
	private String txFlexCar;

	@FieldCrd(tipo="N", tamanho=3, posInicial=1583, posFinal=1585)
	private String pzFlexCar;

	@FieldCrd(tamanho=304, posInicial=1586, posFinal=1889)
	private String areaReservada4;

	@FieldCrd(tamanho=31, posInicial=1890, posFinal=1920)
	private String areaReservada5;

	/**
	 * @return the codigoMensagem
	 */
	public String getCodigoMensagem() {
		return codigoMensagem;
	}

	/**
	 * @param codigoMensagem the codigoMensagem to set
	 */
	public void setCodigoMensagem(String codigoMensagem) {
		this.codigoMensagem = codigoMensagem;
	}

	/**
	 * @return the identifSolicitante
	 */
	public String getIdentifSolicitante() {
		return identifSolicitante;
	}

	/**
	 * @param identifSolicitante the identifSolicitante to set
	 */
	public void setIdentifSolicitante(String identifSolicitante) {
		this.identifSolicitante = identifSolicitante;
	}

	/**
	 * @return the numIdentChamada
	 */
	public String getNumIdentChamada() {
		return numIdentChamada;
	}

	/**
	 * @param numIdentChamada the numIdentChamada to set
	 */
	public void setNumIdentChamada(String numIdentChamada) {
		this.numIdentChamada = numIdentChamada;
	}

	/**
	 * @return the vagoObrigatorio
	 */
	public String getVagoObrigatorio() {
		return vagoObrigatorio;
	}

	/**
	 * @param vagoObrigatorio the vagoObrigatorio to set
	 */
	public void setVagoObrigatorio(String vagoObrigatorio) {
		this.vagoObrigatorio = vagoObrigatorio;
	}

	/**
	 * @return the codigoErro
	 */
	public String getCodigoErro() {
		return codigoErro;
	}

	/**
	 * @param codigoErro the codigoErro to set
	 */
	public void setCodigoErro(String codigoErro) {
		this.codigoErro = codigoErro;
	}

	/**
	 * @return the inscricaoEstadual
	 */
	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	/**
	 * @param inscricaoEstadual the inscricaoEstadual to set
	 */
	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	/**
	 * @return the filler
	 */
	public String getFiller() {
		return filler;
	}

	/**
	 * @param filler the filler to set
	 */
	public void setFiller(String filler) {
		this.filler = filler;
	}

	/**
	 * @return the reservaCielo1
	 */
	public String getReservaCielo1() {
		return reservaCielo1;
	}

	/**
	 * @param reservaCielo1 the reservaCielo1 to set
	 */
	public void setReservaCielo1(String reservaCielo1) {
		this.reservaCielo1 = reservaCielo1;
	}

	/**
	 * @return the reservaCielo2
	 */
	public String getReservaCielo2() {
		return reservaCielo2;
	}

	/**
	 * @param reservaCielo2 the reservaCielo2 to set
	 */
	public void setReservaCielo2(String reservaCielo2) {
		this.reservaCielo2 = reservaCielo2;
	}

	/**
	 * @return the centroCompras
	 */
	public String getCentroCompras() {
		return centroCompras;
	}

	/**
	 * @param centroCompras the centroCompras to set
	 */
	public void setCentroCompras(String centroCompras) {
		this.centroCompras = centroCompras;
	}

	/**
	 * @return the tipoTerminal
	 */
	public String getTipoTerminal() {
		return tipoTerminal;
	}

	/**
	 * @param tipoTerminal the tipoTerminal to set
	 */
	public void setTipoTerminal(String tipoTerminal) {
		this.tipoTerminal = tipoTerminal;
	}

	/**
	 * @return the complementoMcc
	 */
	public String getComplementoMcc() {
		return complementoMcc;
	}

	/**
	 * @param complementoMcc the complementoMcc to set
	 */
	public void setComplementoMcc(String complementoMcc) {
		this.complementoMcc = complementoMcc;
	}

	/**
	 * @return the indicadorMobile
	 */
	public String getIndicadorMobile() {
		return indicadorMobile;
	}

	/**
	 * @param indicadorMobile the indicadorMobile to set
	 */
	public void setIndicadorMobile(String indicadorMobile) {
		this.indicadorMobile = indicadorMobile;
	}

	/**
	 * @return the areaReservada1
	 */
	public String getAreaReservada1() {
		return areaReservada1;
	}

	/**
	 * @param areaReservada1 the areaReservada1 to set
	 */
	public void setAreaReservada1(String areaReservada1) {
		this.areaReservada1 = areaReservada1;
	}

	/**
	 * @return the flagPacoteEcommerce
	 */
	public String getFlagPacoteEcommerce() {
		return flagPacoteEcommerce;
	}

	/**
	 * @param flagPacoteEcommerce the flagPacoteEcommerce to set
	 */
	public void setFlagPacoteEcommerce(String flagPacoteEcommerce) {
		this.flagPacoteEcommerce = flagPacoteEcommerce;
	}

	/**
	 * @return the flagTipoConta
	 */
	public String getFlagTipoConta() {
		return flagTipoConta;
	}

	/**
	 * @param flagTipoConta the flagTipoConta to set
	 */
	public void setFlagTipoConta(String flagTipoConta) {
		this.flagTipoConta = flagTipoConta;
	}

	/**
	 * @return the flagPlanoCielo
	 */
	public String getFlagPlanoCielo() {
		return flagPlanoCielo;
	}

	/**
	 * @param flagPlanoCielo the flagPlanoCielo to set
	 */
	public void setFlagPlanoCielo(String flagPlanoCielo) {
		this.flagPlanoCielo = flagPlanoCielo;
	}

	/**
	 * @return the flagVlFaturamento
	 */
	public String getFlagVlFaturamento() {
		return flagVlFaturamento;
	}

	/**
	 * @param flagVlFaturamento the flagVlFaturamento to set
	 */
	public void setFlagVlFaturamento(String flagVlFaturamento) {
		this.flagVlFaturamento = flagVlFaturamento;
	}

	/**
	 * @return the flagDiasLiquidacao
	 */
	public String getFlagDiasLiquidacao() {
		return flagDiasLiquidacao;
	}

	/**
	 * @param flagDiasLiquidacao the flagDiasLiquidacao to set
	 */
	public void setFlagDiasLiquidacao(String flagDiasLiquidacao) {
		this.flagDiasLiquidacao = flagDiasLiquidacao;
	}

	/**
	 * @return the flagSolucaoCaptura
	 */
	public String getFlagSolucaoCaptura() {
		return flagSolucaoCaptura;
	}

	/**
	 * @param flagSolucaoCaptura the flagSolucaoCaptura to set
	 */
	public void setFlagSolucaoCaptura(String flagSolucaoCaptura) {
		this.flagSolucaoCaptura = flagSolucaoCaptura;
	}

	/**
	 * @return the flagIndicadorAgro
	 */
	public String getFlagIndicadorAgro() {
		return flagIndicadorAgro;
	}

	/**
	 * @param flagIndicadorAgro the flagIndicadorAgro to set
	 */
	public void setFlagIndicadorAgro(String flagIndicadorAgro) {
		this.flagIndicadorAgro = flagIndicadorAgro;
	}

	/**
	 * @return the dadosInformais
	 */
	public String getDadosInformais() {
		return dadosInformais;
	}

	/**
	 * @param dadosInformais the dadosInformais to set
	 */
	public void setDadosInformais(String dadosInformais) {
		this.dadosInformais = dadosInformais;
	}

	/**
	 * @return the dataAfiliacao
	 */
	public String getDataAfiliacao() {
		return dataAfiliacao;
	}

	/**
	 * @param dataAfiliacao the dataAfiliacao to set
	 */
	public void setDataAfiliacao(String dataAfiliacao) {
		this.dataAfiliacao = dataAfiliacao;
	}

	/**
	 * @return the banco
	 */
	public String getBanco() {
		return banco;
	}

	/**
	 * @param banco the banco to set
	 */
	public void setBanco(String banco) {
		this.banco = banco;
	}

	/**
	 * @return the agencia
	 */
	public String getAgencia() {
		return agencia;
	}

	/**
	 * @param agencia the agencia to set
	 */
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	/**
	 * @return the conta
	 */
	public String getConta() {
		return conta;
	}

	/**
	 * @param conta the conta to set
	 */
	public void setConta(String conta) {
		this.conta = conta;
	}

	/**
	 * @return the protocolo
	 */
	public String getProtocolo() {
		return protocolo;
	}

	/**
	 * @param protocolo the protocolo to set
	 */
	public void setProtocolo(String protocolo) {
		this.protocolo = protocolo;
	}

	/**
	 * @return the duplCadastro
	 */
	public String getDuplCadastro() {
		return duplCadastro;
	}

	/**
	 * @param duplCadastro the duplCadastro to set
	 */
	public void setDuplCadastro(String duplCadastro) {
		this.duplCadastro = duplCadastro;
	}

	/**
	 * @return the operadoraSaude
	 */
	public String getOperadoraSaude() {
		return operadoraSaude;
	}

	/**
	 * @param operadoraSaude the operadoraSaude to set
	 */
	public void setOperadoraSaude(String operadoraSaude) {
		this.operadoraSaude = operadoraSaude;
	}

	/**
	 * @return the areaReservada2
	 */
	public String getAreaReservada2() {
		return areaReservada2;
	}

	/**
	 * @param areaReservada2 the areaReservada2 to set
	 */
	public void setAreaReservada2(String areaReservada2) {
		this.areaReservada2 = areaReservada2;
	}

	/**
	 * @return the areaReservada3
	 */
	public String getAreaReservada3() {
		return areaReservada3;
	}

	/**
	 * @param areaReservada3 the areaReservada3 to set
	 */
	public void setAreaReservada3(String areaReservada3) {
		this.areaReservada3 = areaReservada3;
	}

	/**
	 * @return the trocoFacil
	 */
	public String getTrocoFacil() {
		return trocoFacil;
	}

	/**
	 * @param trocoFacil the trocoFacil to set
	 */
	public void setTrocoFacil(String trocoFacil) {
		this.trocoFacil = trocoFacil;
	}

	/**
	 * @return the txTrocoFacil
	 */
	public String getTxTrocoFacil() {
		return txTrocoFacil;
	}

	/**
	 * @param txTrocoFacil the txTrocoFacil to set
	 */
	public void setTxTrocoFacil(String txTrocoFacil) {
		this.txTrocoFacil = txTrocoFacil;
	}

	/**
	 * @return the pzTrocoFacil
	 */
	public String getPzTrocoFacil() {
		return pzTrocoFacil;
	}

	/**
	 * @param pzTrocoFacil the pzTrocoFacil to set
	 */
	public void setPzTrocoFacil(String pzTrocoFacil) {
		this.pzTrocoFacil = pzTrocoFacil;
	}

	/**
	 * @return the flexCar
	 */
	public String getFlexCar() {
		return flexCar;
	}

	/**
	 * @param flexCar the flexCar to set
	 */
	public void setFlexCar(String flexCar) {
		this.flexCar = flexCar;
	}

	/**
	 * @return the txFlexCar
	 */
	public String getTxFlexCar() {
		return txFlexCar;
	}

	/**
	 * @param txFlexCar the txFlexCar to set
	 */
	public void setTxFlexCar(String txFlexCar) {
		this.txFlexCar = txFlexCar;
	}

	/**
	 * @return the pzFlexCar
	 */
	public String getPzFlexCar() {
		return pzFlexCar;
	}

	/**
	 * @param pzFlexCar the pzFlexCar to set
	 */
	public void setPzFlexCar(String pzFlexCar) {
		this.pzFlexCar = pzFlexCar;
	}

	/**
	 * @return the areaReservada4
	 */
	public String getAreaReservada4() {
		return areaReservada4;
	}

	/**
	 * @param areaReservada4 the areaReservada4 to set
	 */
	public void setAreaReservada4(String areaReservada4) {
		this.areaReservada4 = areaReservada4;
	}

	/**
	 * @return the areaReservada5
	 */
	public String getAreaReservada5() {
		return areaReservada5;
	}

	/**
	 * @param areaReservada5 the areaReservada5 to set
	 */
	public void setAreaReservada5(String areaReservada5) {
		this.areaReservada5 = areaReservada5;
	}

		
}
