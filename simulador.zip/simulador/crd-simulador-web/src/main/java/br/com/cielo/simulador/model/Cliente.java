package br.com.cielo.simulador.model;

import org.hibernate.validator.constraints.NotEmpty;

import br.com.cielo.simulador.annotation.FieldCrd;

public class Cliente {

	@FieldCrd(tamanho=1, posInicial=681, posFinal=681)
	@NotEmpty(message="{campo.tipo.pessoa}")
	private String tipoPessoa;

	@FieldCrd(tipo="N", tamanho=15, posInicial=194, posFinal=208)
	@NotEmpty(message="{campo.numero.cpfCnpj}")
	private String cpfCnpj;

	@FieldCrd(tamanho=32, posInicial=50, posFinal=81)
	@NotEmpty(message="{campo.nome.razao}")
	private String nomeRazaoSocial;

	@FieldCrd(tipo="N", tamanho=5, posInicial=474, posFinal=478)
	@NotEmpty(message="{campo.ramo.atividade}")
	private String ramoAtividade;

	@FieldCrd(tamanho=32, posInicial=228, posFinal=259)
	@NotEmpty(message="{campo.nome.fantasia}")
	private String nomeFantasia;

	@FieldCrd(tamanho=32, posInicial=396, posFinal=427)
	@NotEmpty(message="{campo.pessoa.contato}")
	private String pessoaContato;

	@FieldCrd(tamanho=22, posInicial=372, posFinal=393)
	@NotEmpty(message="{campo.nome.plaqueta}")
	private String nomePlaqueta;

	@FieldCrd(tamanho=1, posInicial=730, posFinal=730)
	private String indicadorMei;

	@NotEmpty(message="{campo.email.contato}")
	private String emailContato;
	
	private String taxaArv;	
	private String indicadorOfertaAssociada;
	private String indicadorAceiteOferta;
	private String nivelOferta;
    private String codigoOferta;
    private Integer codigoOfertaCombo;
	//RL05 SPRINT02
    private Long ecCadeiaForcada;
    private Long ecEspelho;
    private String indEspelhamentoTaxa;
    
	/**
	 * @return the tipoPessoa
	 */
	public String getTipoPessoa() {
		return tipoPessoa;
	}

	/**
	 * @param tipoPessoa the tipoPessoa to set
	 */
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}

	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	/**
	 * @return the nomeRazaoSocial
	 */
	public String getNomeRazaoSocial() {
		return nomeRazaoSocial;
	}

	/**
	 * @param nomeRazaoSocial the nomeRazaoSocial to set
	 */
	public void setNomeRazaoSocial(String nomeRazaoSocial) {
		this.nomeRazaoSocial = nomeRazaoSocial;
	}

	/**
	 * @return the ramoAtividade
	 */
	public String getRamoAtividade() {
		return ramoAtividade;
	}

	/**
	 * @param ramoAtividade the ramoAtividade to set
	 */
	public void setRamoAtividade(String ramoAtividade) {
		this.ramoAtividade = ramoAtividade;
	}

	/**
	 * @return the nomeFantasia
	 */
	public String getNomeFantasia() {
		return nomeFantasia;
	}

	/**
	 * @param nomeFantasia the nomeFantasia to set
	 */
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	/**
	 * @return the pessoaContato
	 */
	public String getPessoaContato() {
		return pessoaContato;
	}

	/**
	 * @param pessoaContato the pessoaContato to set
	 */
	public void setPessoaContato(String pessoaContato) {
		this.pessoaContato = pessoaContato;
	}

	/**
	 * @return the nomePlaqueta
	 */
	public String getNomePlaqueta() {
		return nomePlaqueta;
	}

	/**
	 * @param nomePlaqueta the nomePlaqueta to set
	 */
	public void setNomePlaqueta(String nomePlaqueta) {
		this.nomePlaqueta = nomePlaqueta;
	}

	/**
	 * @return the indicadorMei
	 */
	public String getIndicadorMei() {
		return indicadorMei;
	}

	/**
	 * @param indicadorMei the indicadorMei to set
	 */
	public void setIndicadorMei(String indicadorMei) {
		this.indicadorMei = indicadorMei;
	}

	/**
	 * @return the emailContato
	 */
	public String getEmailContato() {
		return emailContato;
	}

	/**
	 * @param emailContato the emailContato to set
	 */
	public void setEmailContato(String emailContato) {
		this.emailContato = emailContato;
	}

    public String getTaxaArv() {
        return taxaArv;
    }

    public void setTaxaArv(String taxaArv) {
        this.taxaArv = taxaArv;
    }

    public String getIndicadorOfertaAssociada() {
        return indicadorOfertaAssociada;
    }

    public void setIndicadorOfertaAssociada(String indicadorOfertaAssociada) {
        this.indicadorOfertaAssociada = indicadorOfertaAssociada;
    }

    public String getIndicadorAceiteOferta() {
        return indicadorAceiteOferta;
    }

    public void setIndicadorAceiteOferta(String indicadorAceiteOferta) {
        this.indicadorAceiteOferta = indicadorAceiteOferta;
    }

    public String getNivelOferta() {
        return nivelOferta;
    }

    public void setNivelOferta(String nivelOferta) {
        this.nivelOferta = nivelOferta;
    }

    public String getCodigoOferta() {
        return codigoOferta;
    }

    public void setCodigoOferta(String codigoOferta) {
        this.codigoOferta = codigoOferta;
    }

	/**
	 * @return the codigoOfertaCombo
	 */
	public Integer getCodigoOfertaCombo() {
		return codigoOfertaCombo;
	}

	/**
	 * @param codigoOfertaCombo the codigoOfertaCombo to set
	 */
	public void setCodigoOfertaCombo(Integer codigoOfertaCombo) {
		this.codigoOfertaCombo = codigoOfertaCombo;
	}

	/**
	 * @return the ecCadeiaForcada
	 */
	public Long getEcCadeiaForcada() {
		return ecCadeiaForcada;
	}

	/**
	 * @param ecCadeiaForcada the ecCadeiaForcada to set
	 */
	public void setEcCadeiaForcada(Long ecCadeiaForcada) {
		this.ecCadeiaForcada = ecCadeiaForcada;
	}

	/**
	 * @return the ecEspelho
	 */
	public Long getEcEspelho() {
		return ecEspelho;
	}

	/**
	 * @param ecEspelho the ecEspelho to set
	 */
	public void setEcEspelho(Long ecEspelho) {
		this.ecEspelho = ecEspelho;
	}

	/**
	 * @return the indEspelhamentoTaxa
	 */
	public String getIndEspelhamentoTaxa() {
		return indEspelhamentoTaxa;
	}

	/**
	 * @param indEspelhamentoTaxa the indEspelhamentoTaxa to set
	 */
	public void setIndEspelhamentoTaxa(String indEspelhamentoTaxa) {
		this.indEspelhamentoTaxa = indEspelhamentoTaxa;
	}
 
	
}
