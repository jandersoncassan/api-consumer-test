package br.com.cielo.simulador.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.model.Telefone;
import br.com.cielo.simulador.service.ITelefoneService;
import br.com.cielo.simulador.service.core.InfoClienteAbstractService;

@Service
public class TelefoneServiceImpl extends InfoClienteAbstractService<Telefone> implements ITelefoneService{

	private static final Logger LOG = LoggerFactory.getLogger(TelefoneServiceImpl.class);

	@Override
	public StringBuffer tratarInformacoes(StringBuffer messageCics, Object objTelefone) {
		return init(messageCics, objTelefone);
	}

	/**
	 * Método responsavel pelas informações do telefone
	 * @param messageCics
	 * @param telefone
	 * @return StringBuffer
	 */
	private StringBuffer init(StringBuffer messageCics, Object objTelefone){
		LOG.info("CONSISTIR INFORMACOES DE TELEFONE");
		Telefone telefone = (Telefone) objTelefone;
		return popularInformacoesTelefone(messageCics, telefone);
	}
	
	/**
	 * Método responsavel por popular as informações de telefone
	 * @param messageCics
	 * @param telefone
	 * @return StringBuffer
	 */
	private StringBuffer popularInformacoesTelefone(StringBuffer messageCics, Telefone telefone) {
		tratarInfoCliente(telefone);
		return tratarConteudoMessage(messageCics, telefone);
	}

	/**
	 * Tratar informações CpfCnpj
	 * @param cliente
	 */
	private void tratarInfoCliente(Telefone telefone){
		telefone.setDddComercial(tratarDdd(telefone.getDddComercial()));
		telefone.setNumeroComercial(tratarTelefone(telefone.getNumeroComercial()));
		telefone.setDddCelular(tratarDdd(telefone.getDddCelular()));
		telefone.setNumeroCelular(tratarTelefone(telefone.getNumeroCelular()));
	}
	
	/**
	 * Método responsavel por retornar as informações do ddd sem caracteres especiais
	 * @param ddd
	 * @return
	 */
	private String tratarDdd(String ddd){
		return ddd.replaceAll("[(|)]", "");
	}
	
	/**
	 * Método responsavel por retornar as informações do telefone sem caracteres especiais
	 * @param telefone
	 * @return
	 */
	private String tratarTelefone(String telefone){
		return telefone.replace("-", "");
	}

}
