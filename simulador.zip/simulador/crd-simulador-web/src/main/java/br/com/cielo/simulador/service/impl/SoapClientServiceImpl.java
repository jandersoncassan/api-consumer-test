package br.com.cielo.simulador.service.impl;

import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CampoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CriticaType;
import br.com.cielo.simulador.enums.StatusProcessamento;
import br.com.cielo.simulador.model.DadosInconsistentes;
import br.com.cielo.simulador.model.MessageLayoutResponse;
import br.com.cielo.simulador.service.ISoapClientService;
import br.com.cielo.simulador.service.osb.IOsbRequestService;
import br.com.cielo.simulador.utils.SimuladorUtils;

/**
 * Classe responsavel pela implementação do serviço de inclusão de proposta via SOAP CRD
 * 
 * @author janderson@cielo
 */
@Service
public class SoapClientServiceImpl implements ISoapClientService {

    private static final Logger LOG = LogManager.getLogger(SoapClientServiceImpl.class);

    @Autowired
    private IOsbRequestService osbRequestService;

    @Override
    public MessageLayoutResponse incluirProposta(CredenciarClienteRequest request) {
        LOG.info("CHAMANDO SERVICO SOAP OSB ...");
        try {
            CredenciarClienteResponse response = osbRequestService.incluirProposta(request);
            return popularMessageResponse(response);

        } catch (MalformedURLException | RemoteException | ServiceException ex) {
            LOG.error("ERRO CHAMADA SERVICE SOAP", ex);
            throw new RuntimeException();
        }
    }

    /**
     * Método responsavel por popular as informações de response
     * 
     * @param response
     * @return
     */
    private MessageLayoutResponse popularMessageResponse(CredenciarClienteResponse infoResponse) {
        MessageLayoutResponse response = new MessageLayoutResponse();
        Integer codigoRetorno = Integer.valueOf(infoResponse.getCodigoStatus());
        response.setCodigoProcessamento(getStatusProcessamento(codigoRetorno));
        popularInfoResponse(response, infoResponse);
        return response;
    }

    /**
     * Método responsavel por popular as informações de acordo com o status do processamento
     * 
     * @param response
     * @param objResponse
     */
    private void popularInfoResponse(MessageLayoutResponse response, CredenciarClienteResponse objResponse) {
        switch (response.getCodigoProcessamento()) {
            case SUCESSO :
                response.setNumeroEc(objResponse.getNumeroEc().toString());
                break;
            case INCONSISTENTE :
                popularStatusInconsistente(response, objResponse);
                break;
            default :// ERRO SISTEMICO
                response.setMensagemErro(objResponse.getDescricaoStatus());
                break;
        }
    }

    /**
     * Método responsavel por popular as informações de processamento 'INCONSISTENTE'
     * 
     * @param response
     * @param objResponse
     */
    private void popularStatusInconsistente(MessageLayoutResponse response, CredenciarClienteResponse objResponse) {

        List<DadosInconsistentes> dadosInconsistencias = new ArrayList<DadosInconsistentes>();

        List<CriticaType> listaCriticas = Arrays.asList(objResponse.getCriticas());
        for (CriticaType critica : listaCriticas) {
            List<CampoType> listaCampos = Arrays.asList(critica.getCampos());
            for (CampoType campoType : listaCampos) {
                DadosInconsistentes dados = new DadosInconsistentes();
                dados.setCodigo(critica.getCodigoCritica());
                dados.setMensagem(critica.getDescricaoCritica());
                // CAMPOS
                dados.setCampo(tratarReferenciaCampo(campoType));
                dadosInconsistencias.add(dados);
            }
        }

        response.setDadosInconsistencias(dadosInconsistencias);
    }

    /**
     * Método responsavel por consisitir a sequencia do campo caso exista.
     * 
     * @param campoType
     * @return String
     */
    private String tratarReferenciaCampo(CampoType campoType) {
        if (campoType.getReferenciaNomeCampo().contains(SimuladorUtils.PROPRIETARIO)) {
            return campoType.getReferenciaNomeCampo().concat(SimuladorUtils.STRING_ESPACOS)
                    .concat(campoType.getReferenciaSequenciaCampo());
        }
        return campoType.getReferenciaNomeCampo();
    }

    /**
     * Método responsavel por efetuar o tratarmento do status de processamento
     * 
     * @param codigoRetorno
     * @return
     */
    private StatusProcessamento getStatusProcessamento(Integer codigoRetorno) {
        switch (codigoRetorno) {
            case 1 : // SUCESSO
                return StatusProcessamento.SUCESSO;
            case 2 : // INCONSISTENTE
                return StatusProcessamento.INCONSISTENTE;
            default : // ERRO SISTEMICO (99)
                return StatusProcessamento.PROBLEMA_SISTEMICO;
        }
    }

}
