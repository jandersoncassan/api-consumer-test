package br.com.cielo.simulador.service.core;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.InetAddress;
import java.net.Socket;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import br.com.cielo.simulador.utils.SimuladorUtils;

public abstract class SocketCicsService {
	
	private static final Logger LOG = LogManager.getLogger(SocketCicsService.class);

	public final String TRANSACAO_CONNECTOR = "SB01";
  //public final String HEADER_PROTOCOLO="00001CRD SIMULADOR CREDENCIAMENTO ONLINEAEOP053C0001920TCN                                0000000000";
    public final String HEADER_PROTOCOLO="00001CRD SIMULADOR CREDENCIAMENTO ONLINEBIOP290D0001920TCN                                0000000000";
	
	public final String SUCESS = "ACK ";
	//SOCKET
	private Socket connection;
	//SEND
    private OutputStream output;
    private OutputStreamWriter writer;
    private BufferedWriter bufferWriter; 
    //GET
    private InputStream input;
    private InputStreamReader reader;
    private BufferedReader bufferReader;

	/**
	 * Método responsavel pelo tramento / envio das informações para o CICS / SEC
	 * @param layoutCliente
	 */
	public abstract String sendMessageCics(String layoutCliente);
	
	/**
	 * Método responsavel por iniciar o socket de comunicação Cics-Link
	 * @param host
	 * @param port
	 * @return Socket
	 */
	public void initConnection(String host, int port){
		try {
			  connection = iniConnectionSocket(host, port);
		      LOG.info("SOCKET DE COMUNICACAO CICS-LINK : SUCESSO");
		      initBufferInpuOutput();
		      LOG.info("BUFFER INICIADO");

		} catch (IOException e) {
			LOG.error("OCORREU UM ERRO AO TENTAR ABRIR O SOCKET DE COMUNICACAO CICS LINK");
			throw new RuntimeException("ERRO COMUNICACAO CICS-LINK", e);
		}
	}
	
	/**
	 * Método responsavel por abrir o socket de comunicação com o CICS
	 * @param host
	 * @param port
	 * @return Socket
	 * @throws IOException
	 */
	private Socket iniConnectionSocket(String host, int port) throws IOException{
		
		LOG.info("INIT - SOCKET DE COMUNICACAO CICS-LINK");		
		InetAddress address = InetAddress.getByName(host);
        Socket socket = new Socket(address, port);
        return socket;

	}

	/**
	 * Método responsavel por iniciar os atributos de buffer input / output
	 * @param socket
	 * @throws IOException 
	 */
	private void initBufferInpuOutput() throws IOException{
		//SEND
         output = connection.getOutputStream();
         writer = new OutputStreamWriter(output);
         bufferWriter = new BufferedWriter(writer); 
        //GET
        input = connection.getInputStream();
        reader = new InputStreamReader(input);
        bufferReader = new BufferedReader(reader);
	}

	/**
	 * Método responsavel pelo envio e recebimento das informações ao SEC 
	 * @param msgInput
	 * @param size
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public String sendMessage(String msgInput, int size) throws IOException, InterruptedException {
		//SEND MESSAGE
		sendMessage(msgInput);
		//GET
		String message = SimuladorUtils.STRING_VAZIA;
		if(size != SimuladorUtils.NUM_ZERO){
			message = getMessage(size);
			while(message.length() < size){
				message = message.concat(getMessage(size));
			}
			LOG.info("RECEBE : "+ message);
		}
		return message;
	}

	/**
	 * Método responsavel pelo envio das informações para o CICS.
	 * @param message
	 * @throws IOException 
	 */
	private void sendMessage(String message) throws IOException {
	       bufferWriter.write(message);
	       bufferWriter.flush();
	       LOG.info("ENVIA  : ".concat(message));		
	}

	/**
	 * Método responsavel por obter as informações retornadas pelo CICS
	 * @param reader2
	 * @param size
	 * @return
	 * @throws IOException 
	 */
	private String getMessage(int size) throws IOException {
        char[] buffer = new char[size];
        int length = bufferReader.read(buffer, 0, size);
        String msgOutput = new String(buffer, 0, length);
        return msgOutput;
	}

	/**
	 * Método responsavel por fechar a conexão do socket
	 */
	public void closeSocketConnection(){
		try {
			if(connection != null)
				connection.close();
		} catch (IOException ex) {
			LOG.error("OCORREU UM ERRO AO FECHAR O SOCKET DE COMUNICACAO CICS-LINK", ex);
			throw new RuntimeException("ERRO AO FECHAR O SOCKET", ex);
		}
	}
}
