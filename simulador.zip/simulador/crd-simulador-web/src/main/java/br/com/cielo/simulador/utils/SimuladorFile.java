package br.com.cielo.simulador.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Classe responsavel ´por fazer o carregamento do arquivo de propriedades da ativação mobile
 * 
 * @author @Cielo
 */
public class SimuladorFile {

    private static final Logger LOG = LoggerFactory.getLogger(SimuladorFile.class);

    private static final String ARQUIVO = "/META-INF/application.properties";

    private Properties external;

    private Properties internal;
    
    private static SimuladorFile instance;
    
    private SimuladorFile(){
    	//CARREGAMOS O ARQUIVO PROPERTIES
    	try{
    		init();
    	}catch(Exception ex){
    		LOG.error("OCORREU UM ERRO AO CRIAR A INSTACIA DO SINGLETON");
    		throw new RuntimeException("OCORREU UM ERRO AO CRIAR A INSTACIA DO SINGLETON", ex);
    	}
    }
    
    private void init() {
        LOG.debug("CARREGAR ARQUIVO PROPRIEDADE - SIMULADOR  []", ARQUIVO);
        internal = new Properties();

        try {
        	internal.load(getClass().getResourceAsStream(ARQUIVO));
        } catch (IOException e) {
            LOG.debug("ERRO : Carregar arquivo properties [][]", ARQUIVO, e);
        }
        // CARREGAMOS O ARQUIVO DE PROPRIEDADES DA ATIVACAO MOBILE
        carregarProperties();
    }

    /**
     * Método responsavel por carregar o arquivo de configurações no diretório do CRD
     */
    private void carregarProperties() {

        Path arquivo = Paths
            .get(String.format("%s%s%s", internal.getProperty("path").trim(), File.separator, internal.get("arquivo")));
        external = new Properties();
        try {
        	external.load(new FileInputStream(arquivo.toFile()));
        } catch (IOException e) {
            LOG.debug("ERRO : Carregar arquivo properties [][]", arquivo.toFile(), e);
        }
    }

    /**
     * Recupera a instância de Simulador File
     * @return
     */
    public static SimuladorFile getInstance(){
    	if(null== instance){
    		instance = new SimuladorFile();
    	}
    	return instance;
    }
    
    /**
     * Método responsavel por obter as propriedades do arquivo interno
     * 
     * @param key
     * @return String
     */
    public String getMessageInternal(String key) {
        return (internal.getProperty(key));
    }

    /**
     * Método responsavel por obter as propriedades do arquivo externo
     * 
     * @param key
     * @return String
     */
    public String getMessageExternal(String key) {
        return (external.getProperty(key));
    }

}
