package br.com.cielo.simulador.service;

import br.com.cielo.simulador.dto.RestApiServiceRequestDTO;
import br.com.cielo.simulador.model.MessageLayoutResponse;

public interface IRestApiClientService {

	/**
	 * Método responsavel pela Inclusão da proposta via API Gateway
	 * @param infoCliente
	 * @return
	 */
	public MessageLayoutResponse incluirProposta(RestApiServiceRequestDTO infoCliente);
}
