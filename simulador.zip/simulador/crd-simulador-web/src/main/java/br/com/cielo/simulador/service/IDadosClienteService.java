package br.com.cielo.simulador.service;

import br.com.cielo.simulador.dto.CredenciamentoDTO;

public interface IDadosClienteService {

	/**
	 * 	
	 * Método responsavel por tratar as informações de credenciamento.
	 * 
	 * @param infoCredenciamento
	 * @param messageToCics
	 */
	void tratarInfoCredenciamento(CredenciamentoDTO infoCredenciamento, StringBuffer messageCics);
	
}
