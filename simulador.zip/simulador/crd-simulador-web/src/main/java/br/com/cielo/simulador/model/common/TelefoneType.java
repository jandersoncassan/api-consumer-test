package br.com.cielo.simulador.model.common;

public class TelefoneType {

	private Integer ddd;
	private Integer numero;
	private TipoType tipo;
	/**
	 * @return the ddd
	 */
	public Integer getDdd() {
		return ddd;
	}
	/**
	 * @param ddd the ddd to set
	 */
	public void setDdd(Integer ddd) {
		this.ddd = ddd;
	}
	/**
	 * @return the numero
	 */
	public Integer getNumero() {
		return numero;
	}
	/**
	 * @param numero the numero to set
	 */
	public void setNumero(Integer numero) {
		this.numero = numero;
	}
	/**
	 * @return the tipo
	 */
	public TipoType getTipo() {
		return tipo;
	}
	/**
	 * @param tipo the tipo to set
	 */
	public void setTipo(TipoType tipo) {
		this.tipo = tipo;
	}
	
  

}
