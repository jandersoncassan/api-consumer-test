package br.com.cielo.simulador.model;

import org.hibernate.validator.constraints.NotEmpty;

import br.com.cielo.simulador.annotation.FieldCrd;

public class Telefone {

	@FieldCrd(tipo="N",tamanho=4, posInicial=696, posFinal=699)
	@NotEmpty(message="{campo.ddd.telefone}")
	private String dddComercial;

	@FieldCrd(tipo="N",tamanho=9, posInicial=702, posFinal=710)
	@NotEmpty(message="{campo.numero.telefone}")
	private String numeroComercial;

	@FieldCrd(tipo="N",tamanho=4, posInicial=713, posFinal=716)
	private String dddCelular;

	@FieldCrd(tipo="N",tamanho=9, posInicial=719, posFinal=727)
	private String numeroCelular;

	/**
	 * @return the dddComercial
	 */
	public String getDddComercial() {
		return dddComercial;
	}

	/**
	 * @param dddComercial the dddComercial to set
	 */
	public void setDddComercial(String dddComercial) {
		this.dddComercial = dddComercial;
	}

	/**
	 * @return the numeroComercial
	 */
	public String getNumeroComercial() {
		return numeroComercial;
	}

	/**
	 * @param numeroComercial the numeroComercial to set
	 */
	public void setNumeroComercial(String numeroComercial) {
		this.numeroComercial = numeroComercial;
	}

	/**
	 * @return the dddCelular
	 */
	public String getDddCelular() {
		return dddCelular;
	}

	/**
	 * @param dddCelular the dddCelular to set
	 */
	public void setDddCelular(String dddCelular) {
		this.dddCelular = dddCelular;
	}

	/**
	 * @return the numeroCelular
	 */
	public String getNumeroCelular() {
		return numeroCelular;
	}

	/**
	 * @param numeroCelular the numeroCelular to set
	 */
	public void setNumeroCelular(String numeroCelular) {
		this.numeroCelular = numeroCelular;
	}

	
}
