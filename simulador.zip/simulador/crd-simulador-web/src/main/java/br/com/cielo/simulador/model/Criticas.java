package br.com.cielo.simulador.model;

import java.util.List;

public class Criticas {

	private String codigo;
	private String descricao;
	private List<Campos> campos;
	
	/**
	 * @return the codigo
	 */
	public String getCodigo() {
		return codigo;
	}
	
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	/**
	 * @return the campos
	 */
	public List<Campos> getCampos() {
		return campos;
	}
	
	/**
	 * @param campos the campos to set
	 */
	public void setCampos(List<Campos> campos) {
		this.campos = campos;
	}
	
	
}
