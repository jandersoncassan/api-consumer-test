package br.com.cielo.simulador.model;

import br.com.cielo.simulador.annotation.FieldCrd;

public class SolucaoCapturaPlano {

	@FieldCrd(tipo="N",tamanho=6, posInicial=779, posFinal=784)
	private String tipoSolucaoCaptura;
	
	private Integer qtdadeEquipamento;

	@FieldCrd(tipo="N",tamanho=2, posInicial=756, posFinal=757)
	private String tipoPlanoCielo;

	@FieldCrd(tipo="N",tamanho=13, posInicial=760, posFinal=772)
	private String valorFaturamento;

	@FieldCrd(tipo="N",tamanho=2, posInicial=775, posFinal=776)
	private String qtdadeDiasLiquidacao;

	@FieldCrd(tamanho=1, posInicial=787, posFinal=787)
	private String indicadorAgro;

	@FieldCrd(tamanho=1, posInicial=739, posFinal=739)
	private String codPacoteEcommerce;

	private String indicadorPagamentoPorLink;
	
	private String codigoHorarioFuncionamento;
	
	private String indEntregaMaquinas;
	
	/**
	 * @return the tipoSolucaoCaptura
	 */
	public String getTipoSolucaoCaptura() {
		return tipoSolucaoCaptura;
	}

	/**
	 * @param tipoSolucaoCaptura the tipoSolucaoCaptura to set
	 */
	public void setTipoSolucaoCaptura(String tipoSolucaoCaptura) {
		this.tipoSolucaoCaptura = tipoSolucaoCaptura;
	}

	/**
	 * @return the qtdadeEquipamento
	 */
	public Integer getQtdadeEquipamento() {
		return qtdadeEquipamento;
	}

	/**
	 * @param qtdadeEquipamento the qtdadeEquipamento to set
	 */
	public void setQtdadeEquipamento(Integer qtdadeEquipamento) {
		this.qtdadeEquipamento = qtdadeEquipamento;
	}

	/**
	 * @return the tipoPlanoCielo
	 */
	public String getTipoPlanoCielo() {
		return tipoPlanoCielo;
	}

	/**
	 * @param tipoPlanoCielo the tipoPlanoCielo to set
	 */
	public void setTipoPlanoCielo(String tipoPlanoCielo) {
		this.tipoPlanoCielo = tipoPlanoCielo;
	}

	/**
	 * @return the valorFaturamento
	 */
	public String getValorFaturamento() {
		return valorFaturamento;
	}

	/**
	 * @param valorFaturamento the valorFaturamento to set
	 */
	public void setValorFaturamento(String valorFaturamento) {
		this.valorFaturamento = valorFaturamento;
	}

	/**
	 * @return the qtdadeDiasLiquidacao
	 */
	public String getQtdadeDiasLiquidacao() {
		return qtdadeDiasLiquidacao;
	}

	/**
	 * @param qtdadeDiasLiquidacao the qtdadeDiasLiquidacao to set
	 */
	public void setQtdadeDiasLiquidacao(String qtdadeDiasLiquidacao) {
		this.qtdadeDiasLiquidacao = qtdadeDiasLiquidacao;
	}

	/**
	 * @return the indicadorAgro
	 */
	public String getIndicadorAgro() {
		return indicadorAgro;
	}

	/**
	 * @param indicadorAgro the indicadorAgro to set
	 */
	public void setIndicadorAgro(String indicadorAgro) {
		this.indicadorAgro = indicadorAgro;
	}

	/**
	 * @return the codPacoteEcommerce
	 */
	public String getCodPacoteEcommerce() {
		return codPacoteEcommerce;
	}

	/**
	 * @param codPacoteEcommerce the codPacoteEcommerce to set
	 */
	public void setCodPacoteEcommerce(String codPacoteEcommerce) {
		this.codPacoteEcommerce = codPacoteEcommerce;
	}

    public String getIndicadorPagamentoPorLink() {
        return indicadorPagamentoPorLink;
    }

    public void setIndicadorPagamentoPorLink(String indicadorPagamentoPorLink) {
        this.indicadorPagamentoPorLink = indicadorPagamentoPorLink;
    }

    public String getCodigoHorarioFuncionamento() {
        return codigoHorarioFuncionamento;
    }

    public void setCodigoHorarioFuncionamento(String codigoHorarioFuncionamento) {
        this.codigoHorarioFuncionamento = codigoHorarioFuncionamento;
    }

	/**
	 * @return the indEntregaMaquinas
	 */
	public String getIndEntregaMaquinas() {
		return indEntregaMaquinas;
	}

	/**
	 * @param indEntregaMaquinas the indEntregaMaquinas to set
	 */
	public void setIndEntregaMaquinas(String indEntregaMaquinas) {
		this.indEntregaMaquinas = indEntregaMaquinas;
	}
	
	
	
}
