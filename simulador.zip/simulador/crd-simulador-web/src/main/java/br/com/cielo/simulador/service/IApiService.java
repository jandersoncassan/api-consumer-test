package br.com.cielo.simulador.service;

import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.model.MessageLayoutResponse;

/**
 * Interface responsável pela chamada da API para credenciamento
 * @author janderson@cielo
 */
public interface IApiService {

	/**
	 * Método responsavel pelas consistências da chamda para a API de Credenciamento
	 * @param infoCredenciamento
	 * @return MessageLayoutResponse
	 */
	MessageLayoutResponse messageToApiCrd(CredenciamentoDTO infoCredenciamento);
}
