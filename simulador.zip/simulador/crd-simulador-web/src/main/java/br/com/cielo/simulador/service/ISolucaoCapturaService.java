package br.com.cielo.simulador.service;

public interface ISolucaoCapturaService extends IMessageCore{

}
