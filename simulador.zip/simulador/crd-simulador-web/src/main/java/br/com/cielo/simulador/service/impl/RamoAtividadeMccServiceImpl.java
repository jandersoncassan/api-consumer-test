package br.com.cielo.simulador.service.impl;

import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.xml.rpc.ServiceException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.ListarRamosAtividadesResponse;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.RamoAtividadeType;
import br.com.cielo.simulador.dto.ListaRamoAtividadeMccDTO;
import br.com.cielo.simulador.model.RamoAtividadeMcc;
import br.com.cielo.simulador.service.IRamoAtividadeMccService;
import br.com.cielo.simulador.service.osb.IOsbRequestService;

@Service
public class RamoAtividadeMccServiceImpl implements IRamoAtividadeMccService {

    private static final Logger LOG = LogManager.getLogger(RamoAtividadeMccServiceImpl.class);

    @Autowired
    private IOsbRequestService osbRequestService;

    @Override
    public ListaRamoAtividadeMccDTO getListaRamoAtividadeMcc() {

        ListaRamoAtividadeMccDTO listaRamoAtividadeMcc = new ListaRamoAtividadeMccDTO();
        List<RamoAtividadeMcc> lista = new ArrayList<>();

        try {
            LOG.info("BUSCANDO A LISTA DE MCCS DO STAR ....");
            ListarRamosAtividadesResponse response = osbRequestService.obterListaMccStar();
            RamoAtividadeType[] listaMcc = response.getRamosAtividades();
            for (RamoAtividadeType mcc : listaMcc) {
                RamoAtividadeMcc ramo = new RamoAtividadeMcc();
                ramo.setCodigo(Integer.valueOf(String.valueOf(mcc.getIdentificador())));
                String descricao = mcc.getDescricao();
                ramo.setDescricao(descricao.trim().length() > 0 ? descricao : "DESCRICAO NAO INFORMADA (STAR)");
                lista.add(ramo);
            }
            ordenarLista(lista);
            listaRamoAtividadeMcc.setListaMcc(lista);
            LOG.info("LISTA OBTIDA COM SUCESSO");
            return listaRamoAtividadeMcc;
        } catch (MalformedURLException | RemoteException | ServiceException e) {
            throw new RuntimeException("OCORREU UM ERRO AO OBTER A LISTA DE MCCS STAR", e);
        }
    }

    /**
     * Método responsavel por orndar a lista
     * 
     * @param lista
     */
    private void ordenarLista(List<RamoAtividadeMcc> lista) {
        Collections.sort(lista, new Comparator<RamoAtividadeMcc>() {
            @Override
            public int compare(RamoAtividadeMcc obj1, RamoAtividadeMcc obj2) {
                return obj1.getCodigo().compareTo(obj2.getCodigo());
            }
        });
    }

}
