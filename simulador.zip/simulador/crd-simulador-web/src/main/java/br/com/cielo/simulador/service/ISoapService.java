package br.com.cielo.simulador.service;

import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.model.MessageLayoutResponse;

public interface ISoapService {

	/**
	 * Método responsavel pelas consistências da chamda para o serviço SOAP de Credenciamento
	 * @param infoCredenciamento
	 * @return MessageLayoutResponse
	 */
	MessageLayoutResponse messageToSoapCrd(CredenciamentoDTO infoCredenciamento);
}
