package br.com.cielo.simulador.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import br.com.cielo.simulador.dto.CredenciamentoDTO;
import br.com.cielo.simulador.dto.ListaRamoAtividadeMccDTO;
import br.com.cielo.simulador.enums.FerramentaEnum;
import br.com.cielo.simulador.model.MessageLayoutResponse;
import br.com.cielo.simulador.model.RamoAtividadeMcc;
import br.com.cielo.simulador.service.IApiService;
import br.com.cielo.simulador.service.IMessageService;
import br.com.cielo.simulador.service.IRamoAtividadeMccService;
import br.com.cielo.simulador.service.ISoapService;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Controller
public class HomeController {

	private static final Logger LOG = LogManager.getLogger(HomeController.class);
	
	@Autowired
	private IMessageService messageService;
	
	@Autowired
	private IApiService apiService;
	
	@Autowired
	private ISoapService soapService;
	
	@Autowired
	private IRamoAtividadeMccService ramoAtividadeMccService;
	
	private static final String PAGE_HOME = "home";
	private static final String PAGE_ERROR = "error";
	
	
    @RequestMapping(value={"/"}, method=RequestMethod.GET)
	public String init() {
		return PAGE_ERROR;
	}
	
	@RequestMapping(value={"/{token}"}, method=RequestMethod.GET)
	public String pageHome(Model model, HttpSession session, @PathVariable String token) {
		model.addAttribute("crd", new CredenciamentoDTO());
		obterListaMcc(model, session);
		if(isTokenValido(token)){
			return PAGE_HOME;
		}
		return PAGE_ERROR;
	}

	@RequestMapping(value={"/cadastrarCliente"}, method=RequestMethod.POST)
	private String cadastrarCliente(@ModelAttribute("crd") @Valid CredenciamentoDTO crd, BindingResult bindingResult,
		HttpSession session, Model model) {		
		
		//TRATAMENTO SOMENTE PARA USUARIO SMART, O PERFIL DEVE SEMPRE SER OBRIGATORIO
		if(FerramentaEnum.isSmart(crd.getTipoFerramenta())){   
			tratarPerfilSmart(crd.getCodPerfilSmart(), bindingResult);			
		}
		
		if(bindingResult.hasErrors()){
        	getListaMcc(model, session);
        	return PAGE_HOME;
        }
        
        if(crd.getTipoFerramenta().equals(FerramentaEnum.BANCOS_ONLINE.getCodigo())){
        	messageToCicsLink(crd, crd.getCliente().getCpfCnpj(), session, model);
        	
        }else{
        	messageToSoapCrd(crd, crd.getCliente().getCpfCnpj(), session, model);
          //messageToApiCrd(crd, crd.getCliente().getCpfCnpj(), session, model);        	
        }
        return PAGE_HOME;
	}

	/**
	 * Ferramenta SMART o perfil torna-se obrigatório
	 * @param tipoFerramenta
	 * @param codPerfilSmart
	 * @param bindingResult
	 */
	private void tratarPerfilSmart(String codPerfilSmart, BindingResult bindingResult) {
		if(null != codPerfilSmart && codPerfilSmart.isEmpty()){
			bindingResult.rejectValue("codPerfilSmart", "perfil.smart.required", "O campo Perfil Smart é obrigatório");      
		}
	}

	/**
	 * Método responsavel pelo processamento Bancos Online 'Simulador'
	 * @param cpfCnpj
	 * @param session
	 * @param model
	 */
	private void messageToCicsLink(CredenciamentoDTO crd, String cpfCnpj, HttpSession session, Model model){
	LOG.info("INIT SIMULADOR CRD x SEC | CPF/CNPJ : "+cpfCnpj);
       MessageLayoutResponse messageResponse = messageService.messageToCicsLink(crd);
       tratarMensagemRetorno(messageResponse, model);
       getListaMcc(model, session);
	}
	
	/**
	 * Método responsavel pelo processamento API Gateway CRD
	 * @param cpfCnpj
	 * @param session
	 * @param model
	 */
	private void messageToApiCrd(CredenciamentoDTO crd, String cpfCnpj, HttpSession session, Model model){
	LOG.info("INIT SIMULADOR CRD x API | CPF/CNPJ : "+cpfCnpj);
       MessageLayoutResponse messageResponse = apiService.messageToApiCrd(crd);
       tratarMensagemRetorno(messageResponse, model);
       getListaMcc(model, session);
	}

	/**
	 * Método responsavel pelo processamento SOAP Service
	 * @param cpfCnpj
	 * @param session
	 * @param model
	 */
	private void messageToSoapCrd(CredenciamentoDTO crd, String cpfCnpj, HttpSession session, Model model){
	LOG.info("INIT SIMULADOR CRD x SOAP | CPF/CNPJ : "+cpfCnpj);
       MessageLayoutResponse messageResponse = soapService.messageToSoapCrd(crd);
       tratarMensagemRetorno(messageResponse, model);
       getListaMcc(model, session);
	}

	/**
	 * Metodo responsavel por retornar o tipo de mensagem no processamento das informações
	 * @param processamento
	 * @return
	 */
	private void tratarMensagemRetorno(MessageLayoutResponse messageResponse, Model model){
		switch (messageResponse.getCodigoProcessamento()) {
		case SUCESSO:
			model.addAttribute("msgSucesso", "MENSAGEM");
			model.addAttribute("response", messageResponse);
			break;
		case INCONSISTENTE:
			model.addAttribute("msgInconsistencia", "MENSAGEM");
			model.addAttribute("response", messageResponse);
			break;
		default: //PROBLEMA_SISTEMICO
			model.addAttribute("msgErro", "MENSAGEM");
		}
	}
	
	/**
	 * Método responsavel por obter a lista de MCC do Star
	 * @return ListaRamoAtividadeMccDTO
	 */
	private void getListaMcc(Model model, HttpSession session){
		ListaRamoAtividadeMccDTO lista = (ListaRamoAtividadeMccDTO) session.getAttribute("lista");
		if(null != lista){
			model.addAttribute("listaMcc", lista);
		}else{
			obterListaMcc(model, session);
		}
	}
	
	/**
	 * Método responsavel por obter a lista de MCC do Star
	 * @return ListaRamoAtividadeMccDTO
	 */
	private void obterListaMcc(Model model, HttpSession session){
		try{
			ListaRamoAtividadeMccDTO listaMcc = ramoAtividadeMccService.getListaRamoAtividadeMcc();
			session.setAttribute("lista", listaMcc);
			model.addAttribute("listaMcc", listaMcc);
		}catch(RuntimeException ex){
			getMccDefault(model);		
		}
	}
	
	/**
	 * Caso ocorra alguma exceção ao buscar lista de mcc do STAR
	 * @return
	 */
	private void getMccDefault(Model model){
		ListaRamoAtividadeMccDTO listaMcc = new ListaRamoAtividadeMccDTO();
		List<RamoAtividadeMcc> listaDefault = new ArrayList<>();
		RamoAtividadeMcc mccDefault = new RamoAtividadeMcc();
		mccDefault.setCodigo(5411);
		mccDefault.setDescricao("MERCEARIAS E SUPERMERCADOS");
		listaDefault.add(mccDefault);
		listaMcc.setListaMcc(listaDefault);
		model.addAttribute("listaMcc", listaMcc);

	}
	
	/**
	 * Método responsavel por validar o token de acesso ao CRD, esse acesso só é permitido se vier do DASH
	 * @param token
	 * @return
	 */
	 private Boolean isTokenValido(String token){
		 return token.equals(SimuladorUtils.TOKEN_DASHBOARD);
	 }
}
