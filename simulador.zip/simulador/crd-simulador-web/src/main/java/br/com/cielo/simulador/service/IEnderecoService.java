package br.com.cielo.simulador.service;

public interface IEnderecoService extends IMessageCore{

}
