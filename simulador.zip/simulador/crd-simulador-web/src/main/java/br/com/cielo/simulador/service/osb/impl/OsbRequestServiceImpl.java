package br.com.cielo.simulador.service.osb.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.springframework.stereotype.Service;

import br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType;
import br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.DadosCliente_ListarRamosAtividadesService;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.DadosCliente_ListarRamosAtividadesServiceLocator;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.DadosCliente_ListarRamosAtividadesServicePortType;
import br.com.cielo.service.cadastro.cliente.dadoscliente.v3.ListarRamosAtividades.ListarRamosAtividadesResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarCliente;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarClienteService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarClienteServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;
import br.com.cielo.simulador.service.osb.IOsbRequestService;
import br.com.cielo.simulador.utils.SimuladorFile;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Service
public class OsbRequestServiceImpl implements IOsbRequestService {

    /**
     * Método responsavel por popular as informações de autenticação do servico SOAP exposto no OSB
     * 
     * @return CieloSoapHeaderType
     */
    private CieloSoapHeaderType buildHeader() {
        UsuarioType user = new UsuarioType();
        user.setId(SimuladorFile.getInstance().getMessageExternal(SimuladorUtils.HEADER_USER));
        user.setSenha(SimuladorFile.getInstance().getMessageExternal(SimuladorUtils.HEADER_PASS));
        CieloSoapHeaderType header = new CieloSoapHeaderType();
        header.setUsuario(user);
        return header;
    }

    /**
     * Serviço responsavel por devovler a lista de MCC
     * 
     * @return
     * @return
     * @throws MalformedURLException
     * @throws ServiceException
     * @throws RemoteException
     */
    public ListarRamosAtividadesResponse obterListaMccStar()
            throws MalformedURLException, ServiceException, RemoteException {
        DadosCliente_ListarRamosAtividadesService ws = new DadosCliente_ListarRamosAtividadesServiceLocator();
        DadosCliente_ListarRamosAtividadesServicePortType service = ws
                .getDadosCliente_ListarRamosAtividadesServiceSOAPPort(new URL(
                        SimuladorFile.getInstance().getMessageExternal(SimuladorUtils.ENDPOINT_LISTA_MCC_STAR)));
        ListarRamosAtividadesResponse listarRamosAtividades = service.listarRamosAtividades(SimuladorUtils.STRING_VAZIA,
                buildHeader());
        return listarRamosAtividades;
    }

    /**
     * Método responsavel pela inclusão da proposta de credenciamento no CRD (RL01)
     * 
     * @return
     * @throws MalformedURLException
     * @throws ServiceException
     * @throws RemoteException
     */
    public CredenciarClienteResponse incluirProposta(CredenciarClienteRequest request)
            throws MalformedURLException, ServiceException, RemoteException {
        Credenciamento_CredenciarClienteService ws = new Credenciamento_CredenciarClienteServiceLocator();
        Credenciamento_CredenciarCliente service = ws.getCredenciamento_CredenciarClienteServiceSoapPort(
                new URL(SimuladorFile.getInstance().getMessageExternal(SimuladorUtils.ENDPOINT_CREDENCIAR_CRD)));
        CredenciarClienteResponse response = service.credenciarCliente(request, buildHeader());
        return response;
    }
}
