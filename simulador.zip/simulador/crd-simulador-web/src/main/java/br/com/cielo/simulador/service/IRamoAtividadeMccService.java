package br.com.cielo.simulador.service;

import br.com.cielo.simulador.dto.ListaRamoAtividadeMccDTO;

public interface IRamoAtividadeMccService {

	/**
	 * Método responsavel por obter a lista de MCC (STAR)
	 * @return
	 */
	ListaRamoAtividadeMccDTO getListaRamoAtividadeMcc();
}
