package br.com.cielo.simulador.service.impl;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.service.core.SocketCicsService;
import br.com.cielo.simulador.utils.SimuladorFile;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Service
public class SocketCicsServiceImpl extends SocketCicsService {

    private static final Logger LOG = LoggerFactory.getLogger(SocketCicsServiceImpl.class);

	private final String HOST = "cicslink.mainframe.host";
	private final String PORT = "cicslink.mainframe.port";

	@Override
	public String sendMessageCics(String layoutCliente) {
		try{

			String host = SimuladorFile.getInstance().getMessageExternal(HOST);
			Integer porta = Integer.valueOf(SimuladorFile.getInstance().getMessageExternal(PORT));
			// INICIA O SOCKET DE COMUNICAÇÃO CICS-LINK
			initConnection(host, porta);
			// TRATAR MENSAGEM CREDENCIAMENTO CLIENTE
			return tratarMensagemComunicacao(layoutCliente);

		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO NO TRATAMENTO DAS MENSAGENS DE COMUNICACAO COM O CICS-LINK");
			throw new RuntimeException("ERRO NO TRATAMENTO DAS MENSAGENS SIMULADOR X CICS-LINK", ex);
			
		} finally {
			closeSocketConnection();
		}
	}

	/**
	 * Método responsavel pelo controle das informações CICS-LINK
	 * 
	 * @return
	 * @throws InterruptedException 
	 * @throws IOException 
	 */
	private String tratarMensagemComunicacao(String layoutCliente) throws IOException, InterruptedException {
		String layoutRetornoCics = null;
			// ENVIA TRANSAÇÃO CONECTOR SB01
			String msgTransConnector = tratarTransConnector();
			if (isSucess(msgTransConnector)) {
				// ENVIA HEADER DO PROTOCOLO (100 BYTES)
				String msgHeaderProtocolo = tratarHeaderProtocolo();
				if (isSucess(msgHeaderProtocolo)) {
					// ENVIA MENSAGEM LAYOUT (<200 KBYTES)
					String msgLayoutCliente = enviarInfoCredenciamento(layoutCliente);
					if (null != msgLayoutCliente) {
						// ENVIA ACK (4 BYTES)
						String msgLayoutRetorno = enviarConfirmacaoSucesso(msgLayoutCliente);
						if (null != msgLayoutRetorno) {
							// ENVIA ACK FINAL
							finalizarOperacao();
						}
						layoutRetornoCics = msgLayoutRetorno;
					}
				}
			}
		return layoutRetornoCics;
	}

	/**
	 * Método responsavel por verificar se a transação connector está ativa
	 * 
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private String tratarTransConnector() throws IOException, InterruptedException {
		return sendMessage(TRANSACAO_CONNECTOR, SimuladorUtils.NUM_QUATRO);
	}

	/**
	 * Método responsavel por enviar o Header do protocolo
	 * 
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private String tratarHeaderProtocolo() throws IOException, InterruptedException {
		return sendMessage(HEADER_PROTOCOLO, SimuladorUtils.NUM_QUATRO);
	}

	/**
	 * Método responsavel por enviar a mensagem de credenciamento
	 * 
	 * @param layoutCliente
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private String enviarInfoCredenciamento(String layoutCliente) throws IOException, InterruptedException {
		return sendMessage(layoutCliente, SimuladorUtils.NUM_CEM);
	}

	/**
	 * Método responsavel por enviar a mensagem de confirmação do tamanho do
	 * retorno
	 * 
	 * @param msgLayoutCliente
	 * @return
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private String enviarConfirmacaoSucesso(String msgLayoutCliente) throws IOException, InterruptedException {
		Integer size = Integer.valueOf(msgLayoutCliente.substring(SimuladorUtils.NUM_NOVENTA_TRES));
		return sendMessage(SUCESS, size);
	}

	/**
	 * Método responsavel por finalizar a operação
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	private void finalizarOperacao() throws IOException, InterruptedException {
		sendMessage(SUCESS, SimuladorUtils.NUM_ZERO);
	}

	/**
	 * Método responsavel por verificar se houve sucesso na comunicação com o
	 * CICS-LINK
	 * 
	 * @param retornoCics
	 * @return
	 */
	private boolean isSucess(String retornoCics) {
		return retornoCics.equals(SUCESS);
	}

}
