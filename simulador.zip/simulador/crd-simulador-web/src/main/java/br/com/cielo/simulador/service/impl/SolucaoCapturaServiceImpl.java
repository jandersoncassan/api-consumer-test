package br.com.cielo.simulador.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import br.com.cielo.simulador.model.SolucaoCapturaPlano;
import br.com.cielo.simulador.service.ISolucaoCapturaService;
import br.com.cielo.simulador.service.core.InfoClienteAbstractService;
import br.com.cielo.simulador.utils.SimuladorUtils;

@Service
public class SolucaoCapturaServiceImpl extends InfoClienteAbstractService<SolucaoCapturaPlano> implements ISolucaoCapturaService{

	private static final Logger LOG = LoggerFactory.getLogger(SolucaoCapturaServiceImpl.class);

	@Override
	public StringBuffer tratarInformacoes(StringBuffer messageCics, Object objSolCaptura) {
		return init(messageCics, objSolCaptura);
	}

	/**
	 * Método responsavel pelas informações do cliente
	 * @param messageCics
	 * @param cliente
	 * @return StringBuffer
	 */
	private StringBuffer init(StringBuffer messageCics, Object objSolCaptura){
		LOG.info("CONSISTIR INFORMACOES DE SOLUCAO DE CAPTURA");
		SolucaoCapturaPlano solCaptura = (SolucaoCapturaPlano) objSolCaptura;
		return popularInfoSolCaptura(messageCics, solCaptura);
	}
	
	/**
	 * Método responsavel por popular as informações de cliente
	 * @param messageCics
	 * @param cliente
	 * @return StringBuffer
	 */
	private StringBuffer popularInfoSolCaptura(StringBuffer messageCics, SolucaoCapturaPlano solCaptura) {
		tratarInfoSolCaptura(solCaptura);
		return tratarConteudoMessage(messageCics, solCaptura);
	}
	
	/**
	 * Tratar informações CpfCnpj
	 * @param cliente
	 */
	private void tratarInfoSolCaptura(SolucaoCapturaPlano solCaptura){
		solCaptura.setValorFaturamento(null == solCaptura.getValorFaturamento()?SimuladorUtils.STRING_ZERO :
		solCaptura.getValorFaturamento().replaceAll(SimuladorUtils.REGEX_CLEAN_MASK_MONETARIA, SimuladorUtils.STRING_VAZIA));
		solCaptura.setIndicadorAgro(null == solCaptura.getIndicadorAgro() ? "N": solCaptura.getIndicadorAgro());
	}

}
