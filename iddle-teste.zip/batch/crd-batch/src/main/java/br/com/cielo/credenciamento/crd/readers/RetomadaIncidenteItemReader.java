package br.com.cielo.credenciamento.crd.readers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;
import br.com.cielo.credenciamento.ejb.remote.IControleIncidenteServiceRemote;
import br.com.cielo.credenciamento.ejb.util.ServiceLocator;

/**
 * Classe READER responsavel pela implementação do processo de retomada de incidente
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class RetomadaIncidenteItemReader implements ItemReader<Incidente> {
	
	private static final Logger LOG = LoggerFactory.getLogger(RetomadaIncidenteItemReader.class);
	 
    private String idIncidente;

	@Override
	public Incidente read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		LOG.info("INIT READER RETOMADA DE INCIDENTE (CODIGO : {})", idIncidente);
		IControleIncidenteServiceRemote incidenteService = ServiceLocator.getInstance().getControleIncidenteServiceRemote();
		Incidente incidente = incidenteService.findIncidente(idIncidente);
		return incidente;
	}

     /**
     * @param idIncidente parametro de entrada do metodo set
     */
    public void setIdIncidente(final String idIncidente) {
        this.idIncidente = idIncidente;
    }




}
