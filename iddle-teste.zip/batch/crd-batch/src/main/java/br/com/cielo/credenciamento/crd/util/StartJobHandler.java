package br.com.cielo.credenciamento.crd.util;

import br.com.cielo.credenciamento.crd.exception.InvalidParameterException;

/**
 * Classe abstrata responsavel pelas consistencias dos parametros para execução do job
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public abstract class StartJobHandler {

    public String[] argumentos;

    /**
     * @param args parametros de entrada para o metodo
     * @return args retornos do metodo 
     * @throws InvalidParameterException lancamento de exception para tratamento de erro
     */
    public final String[] start(final String[] args) throws InvalidParameterException {
        String[] parametros = args;
        this.argumentos = parametros;
        validaQuantidadeDeParametros();
        atrelaValoresComChave();
        return args;

    }

    /**
     * atrelaValoresComChave
     */
    public abstract void atrelaValoresComChave();

    /**
     * @throws InvalidParameterException lancamento de exception para tratamento de erro
     */
    public abstract void validaQuantidadeDeParametros() throws InvalidParameterException;

}
