/**
 * Cielo S.A.
 * Projeto BoB
 * Dir Desenvolvimento de Sistemas Bob-O50013375
 * 
 * Copyright 2014
 */
package br.com.cielo.credenciamento.crd.util;

import br.com.cielo.credenciamento.crd.exception.InvalidParameterException;

/**
 * Classe responsavel por validar a quantidade de parametros para execução do job
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class PrimeiraTransacaoStartHandler extends StartJobHandler {

    private static final int POSICAO_2 = 2;
    private static final int POSICAO_3 = 3;
    private static final String INPUT_FILE_NAME = "input.file.name=";
    private static final String INPUT_DIR_NAME = "input.file.path=";
    private static final int NUMERO_DE_PARAMETROS = 4;

    /**
     * Metodo atrelaValoresComChave
     */
    @Override
    public void atrelaValoresComChave() {
        argumentos[POSICAO_3] = INPUT_DIR_NAME + argumentos[POSICAO_3];
        argumentos[POSICAO_2] = INPUT_FILE_NAME + argumentos[POSICAO_2];

    }

    /**
     * Metodo validaQuantidadeDeParametros
     */
    @Override
    public void validaQuantidadeDeParametros() throws InvalidParameterException {
        if (argumentos.length != NUMERO_DE_PARAMETROS) {
            throw new InvalidParameterException("QUANTIDADE DE PARAMETROS INVALIDOS");
        }
    }

}
