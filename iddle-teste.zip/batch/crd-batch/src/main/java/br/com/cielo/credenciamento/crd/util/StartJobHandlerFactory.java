package br.com.cielo.credenciamento.crd.util;

import org.springframework.batch.core.JobExecutionException;

import br.com.cielo.credenciamento.crd.enums.Jobs;
import br.com.cielo.credenciamento.crd.enums.Layout;

/**
 * Classe responsavel pelas consistencias para execução do job
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class StartJobHandlerFactory {

    /**
     * @param layout parametro de entrada para o metodo
     * @param job parametro de entrada para o metodo
     * @return StartJobHandler
     */
    public static StartJobHandler getHandler(final String layout, final String job) {
        StartJobHandler startJobHandler = null;

        if (ehJobProcessar(layout, job)) {
            startJobHandler = new ProcessarStartHandler();
            
        } else if (ehJobProcessarRetorno(layout, job)) {
            startJobHandler = new ProcessarRetornoSECStartHandler();
            
        } else if (ehJobPrimeiraTransacao(layout, job)) {
            startJobHandler = new PrimeiraTransacaoStartHandler();
            
        } else if (ehRetomadaIncidente(layout, job)) {
            startJobHandler = new ProcessarRetomadaIncidente();
            
        } else if (ehDesbloqueioMobile(layout, job)) {
            startJobHandler = new DesbloqueioMobileStartHandler();
            
        } else {
            new JobExecutionException("HANDLER NAO ENCONTRADO, PARAMETROS INVALIDOS");
        }
        return startJobHandler;
    }


	/**
     * @param layout parametro de entrada para o metodo
     * @param job parametro de entrada para o metodo
     * @return true ou false
     */
    private static boolean ehRetomadaIncidente(final String layout, final String job) {
        return Layout.PROCESSAR_LAYOUT_NOVO_JOB.getValor().equals(layout)
                        && Jobs.PROCESSAR_INCIDENTE.getValor().equals(job);
    }

    /**
     * @param layout parametro de entrada para o metodo
     * @param job parametro de entrada para o metodo
     * @return true or false
     */
    private static boolean ehJobPrimeiraTransacao(final String layout, final String job) {
        return Layout.PROCESSAR_LAYOUT_NOVO_JOB.getValor().equals(layout)
                        && Jobs.PROCESSAR_PRIMEIRA_TRANSACAO_JOB.getValor().equals(job);
    }

    /**
     * @param layout parametro de entrada para o metodo
     * @param job parametro de entrada para o metodo
     * @return true ou false
     */
    private static boolean ehJobProcessarRetorno(final String layout, final String job) {
        return Layout.PROCESSAR_LAYOUT_NOVO_JOB.getValor().equals(layout)
                        && Jobs.PROCESSAR_RETORNO_SEC_JOB.getValor().equals(job);
    }

    /**
     * @param layout parametro de entrada para o metodo
     * @param job parametro de entrada para o metodo
     * @return true ou false
     */
    private static boolean ehJobProcessar(final String layout, final String job) {
        return Layout.PROCESSAR_LAYOUT_NOVO_JOB.getValor().equals(layout)
                        && (Jobs.PROCESSAR_LAYOUT_NOVO_JOB.getValor().equals(job));
    }

    /**
     * @param layout parametro de entrada para o metodo
     * @param job parametro de entrada para o metodo
     * @return true ou false
     */
    private static boolean ehDesbloqueioMobile(String layout, String job) {
        return Layout.PROCESSAR_LAYOUT_NOVO_JOB.getValor().equals(layout)
                && (Jobs.PROCESSAR_DESBLOQUEIO_MOBILE_JOB.getValor().equals(job));
	}

}
