package br.com.cielo.credenciamento.crd.util;

import br.com.cielo.credenciamento.crd.exception.InvalidParameterException;

/**
 * Classe responsavel por verificar a quantidade de parametros para execução da remessa de bancos
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ProcessarStartHandler extends StartJobHandler {

    private static final int POSICAO_4 = 4;
    private static final int POSICAO_3 = 3;
    private static final int POSICAO_2 = 2;
    private static final String INPUT_FILE_NAME = "input.file.name=";
    private static final int NUMERO_DE_PARAMETROS = 5;
    private static final String INPUT_FILE_PATH = "input.file.path=";
    private static final String CODIGO_BANCO = "codigo.banco=";

    /**
     * Metodo atrelaValoresComChave
     */
    @Override
    public void atrelaValoresComChave() {
        argumentos[POSICAO_2] = INPUT_FILE_NAME + argumentos[POSICAO_2];
        argumentos[POSICAO_3] = INPUT_FILE_PATH + argumentos[POSICAO_3];
        argumentos[POSICAO_4] = CODIGO_BANCO + argumentos[POSICAO_4];
    }

    /**
     * Metodo validaQuantidadeDeParametros
     */
    @Override
    public void validaQuantidadeDeParametros() throws InvalidParameterException {
        if (argumentos.length != NUMERO_DE_PARAMETROS) {
            throw new InvalidParameterException("QUANTIDADE DE PARAMETROS INVALIDOS");
        }
    }

}
