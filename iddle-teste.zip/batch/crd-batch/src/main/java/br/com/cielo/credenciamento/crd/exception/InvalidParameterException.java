package br.com.cielo.credenciamento.crd.exception;

/**
 * Classe Exception para tratamento dos parametros na exeucao do batch
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class InvalidParameterException extends Exception {

    private static final long serialVersionUID = 1L;

     public InvalidParameterException(final String msg) {
        super(msg);
    }

}
