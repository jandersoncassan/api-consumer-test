package br.com.cielo.credenciamento.crd.util;

import br.com.cielo.credenciamento.crd.exception.InvalidParameterException;

/**
 * Classe responsavel por verificar a quantidade de parametros para execução do job de retorno de incidente
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ProcessarRetomadaIncidente extends StartJobHandler {

    private static final int POSICAO_2 = 2;
    private static final String IDENTIFICADOR_INCIDENTE = "identificador.incidente=";
    private static final int NUMERO_DE_PARAMETROS = 3;

    /**
     * Metodo atrelaValoresComChave
     */
    @Override
    public void atrelaValoresComChave() {
        argumentos[POSICAO_2] = IDENTIFICADOR_INCIDENTE + argumentos[POSICAO_2];

    }

    /**
     * Metodo validaQuantidadeDeParametros
     */
    @Override
    public void validaQuantidadeDeParametros() throws InvalidParameterException {
        if (argumentos.length != NUMERO_DE_PARAMETROS) {
            throw new InvalidParameterException("QUANTIDADE DE PARAMETROS INVALIDOS");
        }
    }

}
