package br.com.cielo.credenciamento.crd.tasklet;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Classe de monitoração para copis do arquivo de remessas para os diretorios bkp e tmp
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class MonitoraArquivoTasklet implements Tasklet, InitializingBean {

    private static final Logger LOGGER = LoggerFactory.getLogger(MonitoraArquivoTasklet.class);
    
    private String filePath;

    private String fileName;

    /**
     * @return the filePath
     */
    public String getFilePath() {
        return this.filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(final String filePath) {
        this.filePath = filePath;
    }

    /**
     * @return the fileName
     */
    public String getFileName() {
        return this.fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    @Autowired
    public void setFileName(final String fileName) {
        this.fileName = fileName;
    }
    
    /**
     * @throws Exception lancamento de excception para tratamento de erro
     */
    @Override
    public void afterPropertiesSet() throws Exception {
    }
    
    /**
     * Método execute
     * @param contribution parametro de entrada do metodo
     * @param chunkContext parametro de entrada do metodo
     * @return RepeatStatus 
     * @throws Exception lancamento de excception para tratamento de erro
     */
    @Override
    public RepeatStatus execute(final StepContribution contribution, final ChunkContext chunkContext)
        throws Exception {
        
        String arquivoOrigem = String.format("%s/%s", this.filePath, this.fileName);
        String arquivoBKP = String.format("%s/BKP/%s", this.filePath, this.fileName);
        String arquivoTMP = String.format("%s/TMP/%s", this.filePath, this.fileName);

        Path pathArquivoOrigem = FileSystems.getDefault().getPath(arquivoOrigem);
        Path pathArquivoBKP = FileSystems.getDefault().getPath(arquivoBKP);
        Path pathArquivoTMP = FileSystems.getDefault().getPath(arquivoTMP);

        if (!Files.exists(pathArquivoOrigem)) {
            pararJob(chunkContext);
            return RepeatStatus.FINISHED;
        }

        try {
            LOGGER.debug("COPIANDO O ARQUIVO ORIGEM {} ARQUIVO DE DESTINO BKP {} ", arquivoOrigem, arquivoBKP);
            Files.copy(pathArquivoOrigem, pathArquivoBKP, StandardCopyOption.REPLACE_EXISTING);

        } catch (IOException e) {
        	LOGGER.error("ERRO AO RENOMEAR O ARQUIVO {} PARA {}.", arquivoOrigem, arquivoBKP);
            throw new Exception("ERRO AO RENOMEAR ARQUIVO");
        }

        try {
            LOGGER.debug("MOVENDO O ARQUIVO ORIGEM {}  ARQUIVO DE DESTINO TMP {} ", arquivoOrigem, arquivoTMP);
            Files.move(pathArquivoOrigem, pathArquivoTMP, StandardCopyOption.REPLACE_EXISTING);
            
        } catch (IOException e) {
        	LOGGER.error("ERRO AO RENOMEAR O ARQUIVO {} PARA {}", arquivoOrigem, arquivoTMP);
            throw new Exception("ERRO AO RENOMEAR ARQUIVO");
        }

        return RepeatStatus.FINISHED;
    }
    
    /**
     * Método de parar job
     * @param chunkContext parametro de entrada
     */
    private void pararJob(final ChunkContext chunkContext) {
        chunkContext.getStepContext().getStepExecution().getJobExecution().stop();
    }
}
