package br.com.cielo.credenciamento.crd.processor;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.beanio.BeanWriter;
import org.beanio.StreamFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import br.com.cielo.credenciamento.ejb.domain.batch.Arquivo;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.enums.BancosEnum;

/**
 * Classe PROCESSOR para geração do arquivo de retorno de bancos
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ReturnFileProspectItemProcessor implements ItemProcessor<List<Arquivo>, List<String[]>>{

    private static final Logger LOG = LoggerFactory.getLogger(ReturnFileProspectItemProcessor.class);

	public static final String COD_MENSAGEM_RETORNO_SUCESSO = "145";

    private String streamName;

    private StreamFactory streamFactory;

    private String diretorioSaida;

	@Override
	public List<String[]> process(List<Arquivo> listaArquivos) throws Exception {
		LOG.info("INIT PROCESS GERACAO ARQUIVO DE RETORNO, QTDADE {}", listaArquivos.size());
	   	
		List<String[]> listaPathFile = new ArrayList<>();
		try {  
            for (Arquivo arquivo : listaArquivos) {	            	
            	String[] correlationId = getCorrelationId(arquivo.getProspects().get(0));//IDENTIFICAMOS O CORRELATION ATRAVES DO 1º REGISTRO DA REMESSA
            	String nameFile = getFileName(correlationId[0], correlationId[1], correlationId[2]);//BANCO, DATA_MOVIMENTO, REMESSA
            	String pathFile = getPathFileName(nameFile);
            	
            	BeanWriter out = this.streamFactory.createWriter(this.streamName, new File(pathFile));        		
            	for(Prospect proposta : arquivo.getProspects()){
            		proposta.setCodigoMensagem(COD_MENSAGEM_RETORNO_SUCESSO);
            		out.write(proposta);	            		
            	}
            	out.flush();
            	out.close();	
            	//ADICIONAMOS AS INFORMACOES DE PATH
            	listaPathFile.add(new String[]{pathFile, nameFile});
            }	            
            return listaPathFile;
	            
        } catch (final Exception ex) {
            LOG.error("OCORREU UMA EXCECAO NA GERACAO DO ARQUIVO DE RETORNO (process) {} : " + ex);
        }
		return listaPathFile;
	}

    /**
     * Método responsavel por onbter o nome do arquivo de retorno
     * @param proposta
     * @return
     */
    private String[] getCorrelationId(Prospect proposta){
        return (proposta.getCorrelationId().split("\\;"));     
    }
    
    /**
     * Método responsavel por devolver o nome do arquivo de retono
     * @return
     */
    private String getPathFileName(String nameFile){		        		
		return (diretorioSaida.concat("//").concat(nameFile)); 
    }
    
    /**
     * Método responsavel por montar o nome do arquivo de retorno
     * @param banco
     * @param dataMovimento
     * @param remessa
     * @return String
     */
    private String getFileName(String codBanco, String dataMovimento, String remessa){
    	BancosEnum banco = BancosEnum.valueOf("_" + codBanco);
    	return (String.format("IBRCV.AE.RX.CRDBAIXA.PROPRET.%s.%s.%s.txt", banco.getBanco(), dataMovimento, remessa));
    }

	/**
	 * @param streamName the streamName to set
	 */
	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}

	/**
	 * @param streamFactory the streamFactory to set
	 */
	public void setStreamFactory(StreamFactory streamFactory) {
		this.streamFactory = streamFactory;
	}

	/**
	 * @param diretorioSaida the diretorioSaida to set
	 */
	public void setDiretorioSaida(String diretorioSaida) {
		this.diretorioSaida = diretorioSaida;
	}


}
