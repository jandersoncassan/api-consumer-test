package br.com.cielo.credenciamento.crd.processor;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.remote.ICredenciamentoServiceRemote;
import br.com.cielo.credenciamento.ejb.util.ServiceLocator;

/**
 * Classe responsavel por efetuar o processamento dos prospects
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ProspectItemProcessor implements ItemProcessor<Prospect, Prospect>, StepExecutionListener {

	private static final Logger LOG = LoggerFactory.getLogger(ProspectItemProcessor.class);
	
	/* CODIGO DO BANCO REMESSA*/
    private Integer codigoBanco;
    
    /* DSNAME ARQUIVO*/
    private String fileName;
    
    //CONTROLE NUMERO DE REMESSA 
    private static Integer numeroRemessa;
    
    private ICredenciamentoServiceRemote credenciamentoRemote;

    @Override
    public Prospect process(final Prospect prospect) throws Exception {    	
		LOG.info("INTEGRACAO RELEASE 01 - CRD, BANCO {}", codigoBanco); 
		try{
			credenciamentoRemote = getInstanceServiceRemote();
	 		Date dataExecucao = getDataAtual();
			popularNumeroRemessa(dataExecucao, codigoBanco);
			return credenciamentoRemote.invocarServicoCredenciamento(prospect, codigoBanco, numeroRemessa, dataExecucao);

		}catch(Exception ex){
			LOG.error("ERRO NO PROCESSAMENTO DO REGISTRO - BANCO {} CPFCNPJ {}", codigoBanco, prospect.getCpfCnpj()); 
			return prospect;
		}
    }

    /**
     * M�todo set do atributo codigoBanco
     * 
     * @param codigoBanco que ir� atribuir o valor do atributo codigoBanco
     */
    public void setCodigoBanco(final Integer codigoBanco) {
        this.codigoBanco = codigoBanco;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
    	this.fileName = fileName;
    }

     @Override
    public void beforeStep(final StepExecution stepExecution) {
    	 LOG.info("REMESSA BANCO {}", codigoBanco);
    }

    @Override
    public ExitStatus afterStep(final StepExecution stepExecution) {
    	Integer totalRegistros = stepExecution.getReadCount();
        LOG.info("QUANTIDADE DE LINHAS ARQUIVO {}", totalRegistros);
        
        try {
        	LOG.info("ATUALIZANDO TOTAL LOG CARGA BANCO");
        	Date dataExecucao = getDataAtual();
			popularNumeroRemessa(dataExecucao, codigoBanco);
			credenciamentoRemote.cleanAndUpdateInfo(codigoBanco, numeroRemessa, getDataAtual(), totalRegistros);
		} catch (NamingException e) {
			 LOG.error("ERRO ATUALIZANDO TOTAL LOG CARGA BANCO");
		}
        return ExitStatus.EXECUTING;
    }

    /**
     * M�todo responsavel por obter a inst�ncia do servi�o remoto
     * @return ICredenciamentoServiceRemote
     * @throws NamingException
     */
    private ICredenciamentoServiceRemote getInstanceServiceRemote() throws NamingException{
    	if(null == credenciamentoRemote){
    		credenciamentoRemote = ServiceLocator.getInstance().getCredenciamentoServiceRemote();
    	}
    	return credenciamentoRemote;
    }
    
    /**
     * M�todo responsavel pelo controle de remessa
     * @param dataExecucao
     * @param codigoBanco
     * @return
     * @throws NamingException
     */
    private Integer popularNumeroRemessa(final Date dataExecucao, final Integer codigoBanco) throws NamingException {
        if (numeroRemessa == null) {
             numeroRemessa = credenciamentoRemote.getNumeroRemessa(dataExecucao, codigoBanco);
        }
        return numeroRemessa;
    }


	/**
	 * M�todo responsavel por devolver a data atual
	 * @return
	 */
	private Date getDataAtual() {
		if(fileName.contains("G0001V00")){
			String timeStamp = fileName.split("G0001V00")[1];
			timeStamp = timeStamp.replaceAll("(\\.|txt)", "");
			
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddhhmmss");
	        try {
	            return (formatter.parse(timeStamp));
	            
	        } catch (ParseException ex) {
	        	LOG.error("OCORREU UM ERRO AO FORMATAR A DATA DO DSNAME {} ARQUIVO {}", fileName, ex); 
	        	return new Date();
	        }

		}		
		return new Date();
	}
}
