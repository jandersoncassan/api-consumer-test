package br.com.cielo.credenciamento.crd.writers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;

import br.com.cielo.credenciamento.crd.processor.RetomadaIncidenteItemProcessor;

/**
 * Classe WRITER, responsavel por logar o status da execução da retomada de incidente
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class RetomadaIncidenteItemWriter implements ItemWriter<Boolean>, StepExecutionListener {

	private static final Logger LOG = LoggerFactory.getLogger(RetomadaIncidenteItemProcessor.class);

	@Override
	public void write(List<? extends Boolean> statusRetomada) throws Exception {
		LOG.info("FINISHED RETOMADA DE INCIDENTE {}", statusRetomada);		
	}

	@Override
	public void beforeStep(StepExecution stepExecution) {
		// TODO Auto-generated method stub
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		 return ExitStatus.COMPLETED;	
	}
	
      
 }
