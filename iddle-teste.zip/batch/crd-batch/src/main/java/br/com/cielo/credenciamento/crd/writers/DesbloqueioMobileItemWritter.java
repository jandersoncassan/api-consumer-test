package br.com.cielo.credenciamento.crd.writers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import br.com.cielo.credenciamento.ejb.domain.batch.DesbloqueioMobile;

/**
 * Classe WRITER responsavel pelas consisências de desbloqueio mobile
 * 
 * @author @Cielo SA
 * @since Release 03 - Credenciamento
 * @version 1.0.0
 */
public class DesbloqueioMobileItemWritter implements ItemWriter<DesbloqueioMobile>{

	private static final Logger LOG = LoggerFactory.getLogger(DesbloqueioMobileItemWritter.class);

	@Override
	public void write(List<? extends DesbloqueioMobile> items) throws Exception {
	       for (final DesbloqueioMobile desbloqueio : items) {
	        	LOG.info("EC : {}, TERMINAL | DATA  : {}" , 
	        			desbloqueio.getCodigoEstabelecimento(), 
	        			desbloqueio.getCodigoTerminal()+" | "+desbloqueio.getData());
	        }
	}

	/**
	 * Método responsavel por formatar a Data para imprimir no LOG
	 * 
	 * @param data
	 * @return
	 */
	private String dateToString(Date data){
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		return dateFormatter.format(data);
	}

}
