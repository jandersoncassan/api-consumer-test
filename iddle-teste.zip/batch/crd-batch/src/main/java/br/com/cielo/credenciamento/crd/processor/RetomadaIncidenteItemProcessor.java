package br.com.cielo.credenciamento.crd.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemProcessor;

import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;
import br.com.cielo.credenciamento.ejb.enums.StatusEnum;
import br.com.cielo.credenciamento.ejb.remote.ICredenciamentoServiceRemote;
import br.com.cielo.credenciamento.ejb.util.ServiceLocator;

/**
 * Classe PROCESSOR, responsavel por realizar a chamada do serviço de retomada
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class RetomadaIncidenteItemProcessor implements ItemProcessor<Incidente, Boolean> {

	private static final Logger LOG = LoggerFactory.getLogger(RetomadaIncidenteItemProcessor.class);

	@Override
	public Boolean process(Incidente incidente) throws Exception {
		LOG.info("INIT PROCESS RETOMADA DE INCIDENTE");
		//SOMENTE RETOMAMOS O INCIDENTE SE O STATUS DO REGISTRO ESTIVER EM PROCESSAMENTO NA TABELA WRK
		Boolean isIncidenteApto = incidente.getCodStatusProc().equals(StatusEnum.EM_PROCESSAMENTO.getDominio());
		LOG.info("STATUS DO INCIDENTE NA TABELA WRK ESTA EM PROCESSAMENTO : {}", isIncidenteApto);
		
		if(isIncidenteApto){
			LOG.info("RETOMANDO INCIDENTE {}", incidente.getCodigoBanco());
			ICredenciamentoServiceRemote credenciamentoRemote = ServiceLocator.getInstance().getCredenciamentoServiceRemote();
			credenciamentoRemote.retomarIncidente(incidente);
		}		
		return isIncidenteApto;
	}
}
