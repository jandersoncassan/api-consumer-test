package br.com.cielo.credenciamento.crd.enums;

/**
 * Classe ENUM contendo a lista de JOBS para execução
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public enum Jobs {
    PROCESSAR_LAYOUT_NOVO_JOB("processarLayoutAtual"),
    PROCESSAR_PRIMEIRA_TRANSACAO("processarPrimeiraTransacao"),
    PROCESSAR_RETORNO_SEC_JOB("processarRetornoSEC"),
    PROCESSAR_PRIMEIRA_TRANSACAO_JOB("processarPrimeiraTransacao"),
    PROCESSAR_INCIDENTE("processarIncidente"),
    PROCESSAR_DESBLOQUEIO_MOBILE_JOB("processarDesbloqueioMobile");

    private String valor;

    /**
     * @param valor parametro de entrada para atribuicao de valor
     */
    Jobs(final String valor) {
        this.valor = valor;
    }

    /**
     * @return valor
     */
    public String getValor() {
        return this.valor;
    }
}
