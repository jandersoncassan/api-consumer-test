package br.com.cielo.credenciamento.crd.readers;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Locale;

import org.beanio.BeanReader;
import org.beanio.BeanReaderErrorHandler;
import org.beanio.BeanReaderException;
import org.beanio.BeanReaderIOException;
import org.beanio.RecordContext;
import org.beanio.StreamFactory;
import org.beanio.internal.util.IOUtil;
import org.springframework.batch.item.file.FlatFileParseException;
import org.springframework.batch.item.file.ResourceAwareItemReaderItemStream;
import org.springframework.batch.item.support.AbstractItemCountingItemStreamItemReader;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;

import br.com.cielo.credenciamento.ejb.constantes.Constants;

/**
 * Classe responsavel por ler o arquivo de remessa
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class BeanIOFlatFileReader<T> extends AbstractItemCountingItemStreamItemReader<T>
                implements
                ResourceAwareItemReaderItemStream<T>,
                InitializingBean {

    private static final String DEFAULT_CHARSET = Charset.defaultCharset().name();

    private StreamFactory streamFactory;

    private Resource streamMapping;

    private String streamName;

    private Locale locale;

    private boolean strict = true;

    private boolean useSpringExceptions = false;

    private Resource resource;

    private String encoding = DEFAULT_CHARSET;

    private BeanReader reader;

    private BeanReaderErrorHandler errorHandler;

    /**
     * Construtor
     */
    public BeanIOFlatFileReader() {
        setName(ClassUtils.getShortName(BeanIOFlatFileReader.class));
    }

    /**
     * afterPropertiesSet
     * @throws Exception para tratamento de erro
     */
    public void afterPropertiesSet() throws Exception {
        Assert.notNull(this.streamName, "Stream name must be set");
        initializeStreamFactory();
    }

    @Override
    @SuppressWarnings("unchecked")
    protected T doRead() throws Exception {
        if (this.reader == null) {
            return null;
        }

        try {
            return (T) this.reader.read();
        } catch (BeanReaderIOException ex) {
            throw ex.getCause();
        } catch (BeanReaderException ex) {
            if (this.useSpringExceptions) {
                RecordContext ctx = ex.getRecordContext();
                if (ctx != null) {
                    throw new FlatFileParseException(ex.getMessage(), ex, ctx.getRecordText(), ctx.getLineNumber());
                } else {
                    throw new FlatFileParseException(ex.getMessage(), ex, null, 0);
                }
            } else {
                throw ex;
            }
        }
    }

    @Override
    protected void doOpen() throws Exception {
        Assert.notNull(this.resource, "Input resource must be set");

        if (!this.resource.exists()) {
            if (this.strict) {
                throw new IllegalStateException("Input resource must exist: " + this.resource);
            }
            return;
        }

        InputStream bin = this.resource.getInputStream();

        Reader in;
        if (this.encoding == null) {
            in = new InputStreamReader(bin);
        } else {
            in = new InputStreamReader(bin, this.encoding);
        }
        this.reader = this.streamFactory.createReader(this.streamName, in, this.locale);
        if (this.errorHandler != null) {
            this.reader.setErrorHandler(this.errorHandler);
        }
    }

    @Override
    protected void doClose() throws Exception {
        if (this.reader != null) {
            this.reader.close();
            this.reader = null;
        }
        //DELETAR O ARQUIVO DA PASTA TMP
       resource.getFile().deleteOnExit();
    }

    @Override
    protected void jumpToItem(final int itemIndex) throws Exception {
        if (itemIndex <= 0) {
            return;
        }

        int skipped = 0;
        if (this.reader != null) {
            skipped = this.reader.skip(itemIndex);
        }

        if (skipped < itemIndex) {
            throw new IllegalStateException("Failed to skip " + itemIndex + " items, end of stream reached after "
                            + skipped + " items");
        }
    }

    /**
     * Método que inicializa a Stream Factory e tem como tratamento de erro o lançamento de uma exception
     * 
     * @throws Exception para tratamento de erro
     */
    protected void initializeStreamFactory() throws Exception {
        if (this.streamFactory == null) {
            this.streamFactory = StreamFactory.newInstance();
        }

        if (!this.streamFactory.isMapped(this.streamName) && this.streamMapping != null) {
            InputStream in = this.streamMapping.getInputStream();
            try {
                this.streamFactory.load(in);
            } finally {
                IOUtil.closeQuietly(in);
            }
        }

        if (!this.streamFactory.isMapped(this.streamName)) {
            throw new IllegalStateException("No mapping configuration for stream '" + this.streamName + "'");
        }
    }

    /**
     * @return reader
     */
    public String getRecordName() {
        return this.reader != null ? this.reader.getRecordName() : null;
    }

    /**
     * @return reader
     */
    public int getLineNumber() {
        return this.reader != null ? this.reader.getLineNumber() : -1;
    }

    /**
     * @return reader
     */
    public int getRecordCount() {
        return this.reader != null ? this.reader.getRecordCount() : -1;
    }

    /**
     * @param index parametro de entrada do método
     * @return RecordContext retorno do metodo
     */
    public RecordContext getRecordContext(final int index) {
        return this.reader != null ? this.reader.getRecordContext(index) : null;
    }

    /**
     * @return BeanReader
     */
    protected BeanReader getBeanReader() {
        return this.reader;
    }

    /**
     * @param resource parametro de atribuicao de valor para o atributo resource
     */
    public void setResource(final Resource resource) {
        this.resource = resource;
    }

    /**
     * @param strict parametro de atribuicao de valor para o atributo strict
     */
    public void setStrict(final boolean strict) {
        this.strict = strict;
    }

    /**
     * @param streamFactory parametro de atribuicao de valor para o atributo streamFactory
     */
    public void setStreamFactory(final StreamFactory streamFactory) {
        this.streamFactory = streamFactory;
    }

    /**
     * @param streamMapping parametro de atribuicao de valor para o atributo streamMapping
     */
    public void setStreamMapping(final Resource streamMapping) {
        this.streamMapping = streamMapping;
    }

    /**
     * @param streamName parametro de atribuicao de valor para o atributo streamName
     */
    public void setStreamName(final String streamName) {
        this.streamName = streamName;
    }

    /**
     * @param encoding parametro de atribuicao de valor para o atributo encoding
     */
    public void setEncoding(final String encoding) {
        this.encoding = encoding;
    }

    /**
     * @param useSpringExceptions parametro de atribuicao de valor para o atributo useSpringExceptions
     */
    public void setUseSpringExceptions(final boolean useSpringExceptions) {
        this.useSpringExceptions = useSpringExceptions;
    }

    /**
     * @param errorHandler parametro de atribuicao de valor para o atributo errorHandler
     */
    public void setErrorHandler(final BeanReaderErrorHandler errorHandler) {
        this.errorHandler = errorHandler;
    }

    /**
     * @param locale parametro de atribuicao de valor para o atributo locale
     */
    public void setLocale(final String locale) {
        if (locale == null) {
            this.locale = null;
            return;
        }

        String[] s = locale.split("_");
        if (s.length >= Constants.TRES) {
            this.locale = new Locale(s[0], s[1], s[2]);
        } else if (s.length == 2) {
            this.locale = new Locale(s[0], s[1]);
        } else {
            this.locale = new Locale(locale);
        }
    }
}
