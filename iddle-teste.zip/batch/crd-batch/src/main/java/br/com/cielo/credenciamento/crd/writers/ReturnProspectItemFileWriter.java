package br.com.cielo.credenciamento.crd.writers;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;

/**
 * Classe WRITER responsavel pelas consistencias na geração do arquivo de retorno
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ReturnProspectItemFileWriter  implements ItemWriter<List<String[]>>, StepExecutionListener{

    private static final Logger LOG = LoggerFactory.getLogger(ReturnProspectItemFileWriter.class);

    private String diretorioSaida;
    
	@Override
	public void write(List<? extends List<String[]>> listaPaths) throws Exception {
		LOG.info("INIT WRITER GERACAO ARQUIVO DE RETORNO, COPIA BKP {}", listaPaths.get(0).size());
		for (List<String[]> list : listaPaths) {			
			for (String[] paths : list) {
				Files.copy(Paths.get(paths[0]), Paths.get(diretorioSaida.concat("//BKP//").concat(paths[1])), StandardCopyOption.REPLACE_EXISTING);
			}
		}		
	}

	/**
	 * @param diretorioSaida the diretorioSaida to set
	 */
	public void setDiretorioSaida(String diretorioSaida) {
		this.diretorioSaida = diretorioSaida;
	}


	@Override
	public void beforeStep(StepExecution stepExecution) {
		
	}

	@Override
	public ExitStatus afterStep(StepExecution stepExecution) {
		 return ExitStatus.COMPLETED;
	}


}
