/**
 * 
 */
package br.com.cielo.credenciamento.crd.readers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;

import br.com.cielo.credenciamento.ejb.domain.batch.Arquivo;
import br.com.cielo.credenciamento.ejb.remote.IArquivoRetornoServiceRemote;
import br.com.cielo.credenciamento.ejb.util.ServiceLocator;

/**
 * Classe READER responsavel por iniciar o processo de geração do arquivo de retorno
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ReturnFileProspectItemReader implements ItemReader<List<Arquivo>> {

    private static final Logger LOG = LoggerFactory.getLogger(ReturnFileProspectItemReader.class);
    
    private String codigoBanco;

    @Override
    public List<Arquivo> read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
    	LOG.info("INIT READ GERACAO ARQUIVO DE RETORNO, BANCO {}", codigoBanco);
    	IArquivoRetornoServiceRemote arquivoRetornoService = ServiceLocator.getInstance().getArquivoRetornoServiceRemote();
    	List<Arquivo> listaArquivos = arquivoRetornoService.tratarArquivoRetorno(codigoBanco);  
    	LOG.info("QUANTIDADE DE ARQUIVOS BANCO ({}): {}", codigoBanco, listaArquivos.size());
    	return (tratarListaArquivos(listaArquivos)); 
    }
    
    /**
     * Tratamento da lista de remessas de bancos
     * @param listaArquivos
     * @return
     */
    private List<Arquivo> tratarListaArquivos(List<Arquivo> listaArquivos){
    	return (listaArquivos.isEmpty()? null: listaArquivos); //CASO NAO HAJA REGISTROS RETORNAMOS NULL PARA ENCERRAR O PROCESSO
    }

    /**
     * @param codigoBanco parametro de entrada do metodo set
     */
    public void setCodigoBanco(final String codigoBanco) {
        this.codigoBanco = codigoBanco;
    }


}
