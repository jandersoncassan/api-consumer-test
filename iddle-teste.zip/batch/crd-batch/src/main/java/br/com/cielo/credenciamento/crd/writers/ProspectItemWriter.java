package br.com.cielo.credenciamento.crd.writers;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;

/**
 * Classe WRITER responsavel por efetuar as ultimas consistências e concluir o processamento
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ProspectItemWriter implements ItemWriter<Prospect>{

	private static final Logger LOG = LoggerFactory.getLogger(ProspectItemWriter.class);
	
	@Override
	public void write(List<? extends Prospect> listaProspect) throws Exception {
        for (final Prospect prospect : listaProspect) {
        	LOG.info("CORRELATION ID : {}, PROPOSTA | EC  : {}" , 
        			prospect.getCorrelationId(), 
        			prospect.getNumeroProposta()+" | "+prospect.getNumeroEstabelecimento());
        }
	}
}
