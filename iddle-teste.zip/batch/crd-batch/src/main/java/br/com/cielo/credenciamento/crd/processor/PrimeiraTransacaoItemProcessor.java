package br.com.cielo.credenciamento.crd.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import br.com.cielo.credenciamento.ejb.domain.batch.PrimeiraTransacao;
import br.com.cielo.credenciamento.ejb.remote.IPrimeiraTransacaoServiceRemote;
import br.com.cielo.credenciamento.ejb.util.ServiceLocator;

/**
 * Classe PROCESSOR responsável pelas consistências da 1° transação
 * 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class PrimeiraTransacaoItemProcessor implements ItemProcessor<PrimeiraTransacao, PrimeiraTransacao>, StepExecutionListener{

	private static final Logger LOG = LoggerFactory.getLogger(PrimeiraTransacaoItemProcessor.class);
	
    @Override
    public PrimeiraTransacao process(PrimeiraTransacao regPrimTransacao) throws Exception {
    	
    	IPrimeiraTransacaoServiceRemote primTransServiceRemote = ServiceLocator.getInstance().getPrimeiraTransacaoServiceRemote();
    	primTransServiceRemote.atualizarPrimeiraTransacao(regPrimTransacao);
        
    	return regPrimTransacao;
    }

    @Override
   public void beforeStep(final StepExecution stepExecution) {
    	LOG.info("INIT PROCESSAMENTO PRIMEIRA TRANSACAO");
    }

   @Override
   public ExitStatus afterStep(final StepExecution stepExecution) {
       LOG.info("QUANTIDADE DE LINHAS ARQUIVO {}", stepExecution.getReadCount());
       return ExitStatus.EXECUTING;
   }

}