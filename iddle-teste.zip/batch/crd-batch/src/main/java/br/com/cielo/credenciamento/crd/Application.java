package br.com.cielo.credenciamento.crd;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.launch.support.CommandLineJobRunner;

import br.com.cielo.credenciamento.crd.exception.InvalidParameterException;
import br.com.cielo.credenciamento.crd.util.StartJobHandler;
import br.com.cielo.credenciamento.crd.util.StartJobHandlerFactory;
import br.com.cielo.credenciamento.ejb.config.CRDConfig;

/**
 * Classe principal para execução do processo do Spring Batch
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class Application extends CommandLineJobRunner {
   // private static final String BATCH_LOG_ARQUIVO_CAMINHO = "batch.log.arquivo.caminho";
    private static final Logger LOG = LoggerFactory.getLogger(Application.class);

    /**
     * Método main da aplicação
     * @param args parametros de entrada
     */
    public static void main(final String[] args) {     	
    	
    	try {
            CRDConfig.init();
            if (LOG.isInfoEnabled()) {
                LOG.info(String.format("%s%s%s", "Argumentos de entrada: [", args.length, "]"));
                int i = 1;
                for (String string : args) {
                    LOG.info(String
                                    .format("%s%s%s%s%s", "Argumento [", i, "] Valor: [", string, "]"));
                    i++;
                }
            }
            preparaArgumentos(args);
            CommandLineJobRunner.main(args);
        } catch (final Exception exc) {
            LOG.error("Erro na execucao do job: " + exc.getMessage(), exc);
        }
    }

    /**
     * Método que prepara os argumentos do start
     * 
     * @param args parametros de entrada
     * @throws InvalidParameterException exception de tratamento
     */
    private static void preparaArgumentos(String[] args) throws InvalidParameterException {
        final StartJobHandler startJob = StartJobHandlerFactory.getHandler(args[0], args[1]);
        args = startJob.start(args);
    }
 }
