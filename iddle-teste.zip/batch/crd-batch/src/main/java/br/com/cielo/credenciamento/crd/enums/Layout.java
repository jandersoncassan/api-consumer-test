package br.com.cielo.credenciamento.crd.enums;

/**
 * Classe ENUM contendo o bean principal para execução
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public enum Layout {

    PROCESSAR_LAYOUT_NOVO_JOB("spring/layoutAtualJob.xml");

    private String valor;

    /**
     * @param valor parametro de entrada para atribuicao de valor 
     */
    Layout(final String valor) {
        this.valor = valor;
    }

    /**
     * @return valor
     */
    public String getValor() {
        return this.valor;
    }
}
