package br.com.cielo.credenciamento.crd.processor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemProcessor;

import br.com.cielo.credenciamento.ejb.domain.batch.DesbloqueioMobile;
import br.com.cielo.credenciamento.ejb.remote.IDesbloqueioMobileServiceRemote;
import br.com.cielo.credenciamento.ejb.util.ServiceLocator;

/**
 * Classe PROCESSOR responsável pela implementação da chamada ao serviço de desbloqueio de TED
 * 
 * @author @Cielo SA
 * @since Release 03 - Credenciamento
 * @version 1.0.0
 */
public class DesbloqueioMobileItemProcessor implements ItemProcessor<DesbloqueioMobile, DesbloqueioMobile>, StepExecutionListener{

	private static final Logger LOG = LoggerFactory.getLogger(DesbloqueioMobileItemProcessor.class);
	
	@Override
	public DesbloqueioMobile process(DesbloqueioMobile desbloqueioTed) throws Exception {
    	IDesbloqueioMobileServiceRemote desblMobileServiceRemote = ServiceLocator.getInstance().getDesbloqueioMobileServiceRemote();
    	desblMobileServiceRemote.desbloquearMobile(desbloqueioTed);
        
        return desbloqueioTed;
	}

    @Override
   public void beforeStep(final StepExecution stepExecution) {
    	LOG.info("INIT PROCESSAMENTO DESBLOQUEIO MOBILE");
    }

   @Override
   public ExitStatus afterStep(final StepExecution stepExecution) {
       LOG.info("QUANTIDADE DE LINHAS ARQUIVO {}", stepExecution.getReadCount());
       return ExitStatus.EXECUTING;
   }

}
