package br.com.cielo.credenciamento.crd.util;

import br.com.cielo.credenciamento.crd.exception.InvalidParameterException;

/**
 * Classe responsavel por verificar a quantidade de parametros para execução do job de retorno
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class ProcessarRetornoSECStartHandler extends StartJobHandler {

    private static final int POSICAO_3 = 3;
    private static final int POSICAO_2 = 2;
    private static final String OUTPUT_DIR_NAME = "output.dir.name=";
    private static final int NUMERO_DE_PARAMETROS = 4;
    private static final String CODIGO_BANCO = "codigo.banco=";

    /**
     * Metodo atrelaValoresComChave
     */
    @Override
    public void atrelaValoresComChave() {
        argumentos[POSICAO_2] = OUTPUT_DIR_NAME + argumentos[POSICAO_2];
        argumentos[POSICAO_3] = CODIGO_BANCO + argumentos[POSICAO_3];

    }

    /**
     * Metodo validaQuantidadeDeParametros
     */
    @Override
    public void validaQuantidadeDeParametros() throws InvalidParameterException {
        if (argumentos.length != NUMERO_DE_PARAMETROS) {
            throw new InvalidParameterException("QUANTIDADE DE PARAMETROS INVALIDOS");
        }
    }

}
