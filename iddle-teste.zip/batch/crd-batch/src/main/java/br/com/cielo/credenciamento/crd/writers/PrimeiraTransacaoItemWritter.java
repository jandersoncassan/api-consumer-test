package br.com.cielo.credenciamento.crd.writers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.item.ItemWriter;

import br.com.cielo.credenciamento.ejb.domain.batch.PrimeiraTransacao;

/**
 * Classe WRITTER responsavel pelo tratamento da primeira transação 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class PrimeiraTransacaoItemWritter implements ItemWriter<PrimeiraTransacao> {

	private static final Logger LOG = LoggerFactory.getLogger(PrimeiraTransacaoItemWritter.class);

	@Override
	public void write(List<? extends PrimeiraTransacao> listaPrimeiraTransacao) throws Exception {
	       for (final PrimeiraTransacao primTransacao : listaPrimeiraTransacao) {
	        	LOG.info("EC : {}, TERMINAL | DATA  : {}" , 
	        			primTransacao.getCodigoEstabelecimento(), 
	        			primTransacao.getCodigoTerminal()+" | "+dateToString(primTransacao.getData()));
	        }
		}
		
	/**
	 * Método responsavel por formatar a Data para imprimir no LOG
	 * 
	 * @param data
	 * @return
	 */
	private String dateToString(Date data){
		SimpleDateFormat dateFormatter = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		return dateFormatter.format(data);
	}

}
	

