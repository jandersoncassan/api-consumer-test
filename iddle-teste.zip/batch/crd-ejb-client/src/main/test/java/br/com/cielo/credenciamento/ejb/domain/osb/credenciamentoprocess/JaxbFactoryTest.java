package br.com.cielo.credenciamento.ejb.domain.osb.credenciamentoprocess;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPMessage;

import org.junit.Assert;
import org.junit.Test;
import org.w3c.dom.Document;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;


public class JaxbFactoryTest {

    private BancoType createBancoType;

    @Test
    public void deveFazerMarshall() throws JAXBException, Exception{
        ObjectFactory objectFactory = new ObjectFactory();
        this.createBancoType = objectFactory.createBancoType();
        
        this.createBancoType.setCodigoBanco("273");
        
        Document document = DocumentBuilderFactory.newInstance().newDocumentBuilder()
                .newDocument();
        Marshaller marshaller = JAXBContext.newInstance(Prospect.class).createMarshaller();
        Prospect prospect = new Prospect();
        prospect.setBancoType(this.createBancoType);
        marshaller.marshal(prospect, document);

        // cria a mensagem SOAP a partir do Document
        SOAPMessage message = MessageFactory.newInstance().createMessage();
        message.getSOAPBody().addDocument(document);
        
        Assert.assertTrue(true);
        
    }
    
}
