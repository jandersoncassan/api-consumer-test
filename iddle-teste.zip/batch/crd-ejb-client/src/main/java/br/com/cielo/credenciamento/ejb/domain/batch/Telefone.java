package br.com.cielo.credenciamento.ejb.domain.batch;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import br.com.cielo.credenciamento.ejb.annotation.FieldInfoCrd;
import br.com.cielo.credenciamento.ejb.domain.AbstractDTO;

/**
 * DTO Telefone.
 * 
 * @author <a href="mailto:jrmarques1@stefanini.com>José Renato Sena Marques</a>
 * @version $Id$
 */
@XmlRootElement(name = "Telefone")
@XmlAccessorType(XmlAccessType.NONE)
public class Telefone extends AbstractDTO {

    private static final long serialVersionUID = 6832958610216317457L;

    @XmlElement(name = "codigoTipoTelefone")
    private int codigoTipoTelefone;
 
    private String flagDDD;//erroDDD

    @FieldInfoCrd(tipo="N",tamanho=4, posInicial=713, posFinal=716)
    @XmlElement(name = "numeroDDD")
    private String ddd;

    private String flagNumero;//erroNumero

    @FieldInfoCrd(tipo="N",tamanho=9, posInicial=719, posFinal=727)
    @XmlElement(name = "numeroTelefone")
    private String numero;

	/**
	 * @return the flagDDD
	 */
	public String getFlagDDD() {
		return flagDDD;
	}

	/**
	 * @param flagDDD the flagDDD to set
	 */
	public void setFlagDDD(String flagDDD) {
		this.flagDDD = flagDDD;
	}

	/**
	 * @return the codigoTipoTelefone
	 */
	public int getCodigoTipoTelefone() {
		return codigoTipoTelefone;
	}

	/**
	 * @param codigoTipoTelefone the codigoTipoTelefone to set
	 */
	public void setCodigoTipoTelefone(int codigoTipoTelefone) {
		this.codigoTipoTelefone = codigoTipoTelefone;
	}

	/**
	 * @return the ddd
	 */
	public String getDdd() {
		return ddd;
	}

	/**
	 * @param ddd the ddd to set
	 */
	public void setDdd(String ddd) {
		this.ddd = ddd;
	}

	/**
	 * @return the flagNumero
	 */
	public String getFlagNumero() {
		return flagNumero;
	}

	/**
	 * @param flagNumero the flagNumero to set
	 */
	public void setFlagNumero(String flagNumero) {
		this.flagNumero = flagNumero;
	}

	/**
	 * @return the numero
	 */
	public String getNumero() {
		return numero;
	}

	/**
	 * @param numero the numero to set
	 */
	public void setNumero(String numero) {
		this.numero = numero;
	}

}