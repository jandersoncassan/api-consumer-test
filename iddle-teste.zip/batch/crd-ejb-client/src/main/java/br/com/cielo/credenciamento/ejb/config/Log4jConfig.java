package br.com.cielo.credenciamento.ejb.config;

import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.xml.DOMConfigurator;

/**
 * 
 * Classe para configura��o do log4j.
 * 
 * @author <a href="mailto:pedri@prestadorcbmp.com.br>NOME_EXTENSO</a>
 * @version $Id$
 *
 */
public class Log4jConfig {

    private static final String LOG_ARQUIVO_CAMINHO = "log.arquivo.caminho";

    /**
     * 
     * Classe que inicializa a configura��o.
     * @param chave chave
     */
    public static void config(String chave) {
        PropertyConfigurator.configure(CRDConfig.getProperty(chave));
    }

    /**
     * 
     * Classe que inicializa a configura��o.
     */
    public static void config() {
        PropertyConfigurator.configure(CRDConfig.getProperty(LOG_ARQUIVO_CAMINHO));
    }
    
    /**
     * 
     * Classe que inicializa a configura��o baseada em uma chave.
     * @param chave chave
     */
    public static void configXML(final String chave) {
        DOMConfigurator.configure(CRDConfig.getProperty(chave));
    }

}
