package br.com.cielo.credenciamento.ejb.remote;

import javax.ejb.Remote;

import br.com.cielo.credenciamento.ejb.domain.batch.DesbloqueioMobile;

/**
 * Interface remota responsavel pelas consistencias do desbloqueio mobile
 * 
 * @author @Cielo SA
 * @since Release 03 - Credenciamento
 * @version 1.0.0
 */
@Remote
public interface IDesbloqueioMobileServiceRemote {

	/**
	 * Método responsavel por efetuar a chamada do serviço de desbloqueio mobile
	 * @param desbloqueioMobile
	 */
	void desbloquearMobile(DesbloqueioMobile desbloqueioMobile);
}
