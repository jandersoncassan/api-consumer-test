package br.com.cielo.credenciamento.ejb.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * 
 * Classe auxiliar para externaliza��o de configura��o
 * @author <a href="mailto:pedri@prestadorcbmp.com.br>NOME_EXTENSO</a>
 * @version $Id$
 *
 */
public final class CRDConfig {

    private static Properties prop;
    private static Properties config;
    
    /**
     * 
     * Carrega os arquivos externalizados e properties auxliliares.
     */
    public static void init(){
        try {
            config = new Properties();
            config.load(CRDConfig.class.getClassLoader().getResourceAsStream("config.properties"));
            
            carregarProperties();
            
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 
     * Carregar o arquivo de properties
     * @throws IOException exce��o
     * @throws FileNotFoundException exce��o
     */
    public static void carregarProperties() throws IOException, FileNotFoundException {
        Path arquivo = Paths
                .get(String.format("%s%s%s", config.getProperty("diretorio"), File.separator, config.get("arquivo")));
        
        prop = new Properties();
        prop.load(new FileInputStream(arquivo.toFile()));
    }

    /**
     * 
     * Get
     * @param key key
     * @return valor
     */
    public static String getProperty(String key) {
        return prop.getProperty(key);
    }

    /**
     * 
     * Set
     * @param prop chave
     */
    public static void setProp(Properties prop) {
        CRDConfig.prop = prop;
    }

}
