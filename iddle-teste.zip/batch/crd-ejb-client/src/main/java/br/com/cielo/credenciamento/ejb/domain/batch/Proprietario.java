package br.com.cielo.credenciamento.ejb.domain.batch;

import java.util.LinkedList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import br.com.cielo.credenciamento.ejb.annotation.FieldInfoCrd;
import br.com.cielo.credenciamento.ejb.domain.AbstractDTO;

/**
 * DTO Proprietario.
 * 
 * @author <a href="mailto:stefanini@stefanini.com>José Renato Sena Marques</a>
 * @version $Id$
 */
@XmlRootElement(name = "DadosProprietario")
@XmlAccessorType(XmlAccessType.NONE)
public class Proprietario extends AbstractDTO {

    private static final long serialVersionUID = -5010316684220730764L;

    @FieldInfoCrd(tipo="N",tamanho=2, posInicial=502, posFinal=503)
    private String flagNomeProprietario;//erroNomeProprietario

    @FieldInfoCrd(tamanho=32, posInicial=504, posFinal=535)
    @XmlElement(name = "nome")
    private String nomeProprietario;

    @FieldInfoCrd(tipo="N",tamanho=2, posInicial=536, posFinal=537)
    private String flagCpfProprietario;//erroCpfProprietario

    @FieldInfoCrd(tipo="N",tamanho=15, posInicial=538, posFinal=552)
    @XmlElement(name = "numeroCPF")
    private String cpfProprietario;

    @FieldInfoCrd(tipo="N",tamanho=2, posInicial=553, posFinal=554)
    private String flagDataNascimentoProprietario;//erroDataNascimentoProprietario

    @FieldInfoCrd(tipo="N",tamanho=6, posInicial=555, posFinal=560)
    @XmlElement(name = "dataNascimento")
    private String dataNascimentoProprietario;

    @XmlElement(name = "dadosTelefoneProprietario")
    private List<Telefone> telefonesProprietario;

    /**
     * Construtor da classe DTO Proprietario.
     */
    public Proprietario() {
        super();
        this.telefonesProprietario = new LinkedList<Telefone>();
    }

	/**
	 * @return the flagNomeProprietario
	 */
	public String getFlagNomeProprietario() {
		return flagNomeProprietario;
	}

	/**
	 * @param flagNomeProprietario the flagNomeProprietario to set
	 */
	public void setFlagNomeProprietario(String flagNomeProprietario) {
		this.flagNomeProprietario = flagNomeProprietario;
	}

	/**
	 * @return the nomeProprietario
	 */
	public String getNomeProprietario() {
		return nomeProprietario;
	}

	/**
	 * @param nomeProprietario the nomeProprietario to set
	 */
	public void setNomeProprietario(String nomeProprietario) {
		this.nomeProprietario = nomeProprietario;
	}

	/**
	 * @return the flagCpfProprietario
	 */
	public String getFlagCpfProprietario() {
		return flagCpfProprietario;
	}

	/**
	 * @param flagCpfProprietario the flagCpfProprietario to set
	 */
	public void setFlagCpfProprietario(String flagCpfProprietario) {
		this.flagCpfProprietario = flagCpfProprietario;
	}

	/**
	 * @return the cpfProprietario
	 */
	public String getCpfProprietario() {
		return cpfProprietario;
	}

	/**
	 * @param cpfProprietario the cpfProprietario to set
	 */
	public void setCpfProprietario(String cpfProprietario) {
		this.cpfProprietario = cpfProprietario;
	}

	/**
	 * @return the flagDataNascimentoProprietario
	 */
	public String getFlagDataNascimentoProprietario() {
		return flagDataNascimentoProprietario;
	}

	/**
	 * @param flagDataNascimentoProprietario the flagDataNascimentoProprietario to set
	 */
	public void setFlagDataNascimentoProprietario(String flagDataNascimentoProprietario) {
		this.flagDataNascimentoProprietario = flagDataNascimentoProprietario;
	}

	/**
	 * @return the dataNascimentoProprietario
	 */
	public String getDataNascimentoProprietario() {
		return dataNascimentoProprietario;
	}

	/**
	 * @param dataNascimentoProprietario the dataNascimentoProprietario to set
	 */
	public void setDataNascimentoProprietario(String dataNascimentoProprietario) {
		this.dataNascimentoProprietario = dataNascimentoProprietario;
	}

	/**
	 * @return the telefonesProprietario
	 */
	public List<Telefone> getTelefonesProprietario() {
		return telefonesProprietario;
	}

	/**
	 * @param telefonesProprietario the telefonesProprietario to set
	 */
	public void setTelefonesProprietario(List<Telefone> telefonesProprietario) {
		this.telefonesProprietario = telefonesProprietario;
	}



}
