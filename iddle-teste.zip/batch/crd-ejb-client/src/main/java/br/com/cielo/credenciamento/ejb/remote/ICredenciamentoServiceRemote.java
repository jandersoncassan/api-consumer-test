package br.com.cielo.credenciamento.ejb.remote;

import java.util.Date;

import javax.ejb.Remote;
import javax.naming.NamingException;

import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;

/**
 * Interface remote responsavel pelos metodos implementação integração com a Release 01
 *  
 * @author @Cielo 
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Remote
public interface ICredenciamentoServiceRemote {

	/**
	 * Método responsavel por invocar o serviço de credenciamento da release 01
	 * @param infoProposta
	 * @param codigoBanco
	 * @return
	 */
	Prospect invocarServicoCredenciamento(final Prospect infoProposta, final Integer codigoBanco, final Integer numeroRemessa, final Date dataExecucao);
	
	/**
	 * Método responsavel pela retomada de Incidente
	 * @param incidente
	 */
	void retomarIncidente(Incidente incidente);
	
	/**
	 * Método responsavel por "zerar" o count de remessas e a lista de Criticas e atualizar o total de registros na tabela de controle de carga
	 */
	void cleanAndUpdateInfo(final Integer codigoBanco, final Integer numeroRemessa, final Date dataExecucao, final Integer totalRegistros);
	
	/**
	 * Método responsavel por devolver o numero da remessa
	 * @return
	 */
	Integer getNumeroRemessa(final Date dataExecucao, final Integer codigoBanco) throws NamingException;
	
}
