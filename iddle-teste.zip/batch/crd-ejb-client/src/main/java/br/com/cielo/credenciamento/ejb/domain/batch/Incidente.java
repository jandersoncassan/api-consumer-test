package br.com.cielo.credenciamento.ejb.domain.batch;

import java.io.Serializable;
import java.util.Date;

/**
 * Classe model responsavel pela representação do registro de incidente
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class Incidente implements Serializable{

	private static final long serialVersionUID = 1L;

    private Integer codigoBanco;
    
    private Date dataMovimento;
    
    private Integer numeroRemessa;
    
    private Integer numeroLinha;
    
    private String descricaoErro;
    
    private Integer codStatusProc;
    
	/**
	 * @return the codigoBanco
	 */
	public Integer getCodigoBanco() {
		return codigoBanco;
	}

	/**
	 * @param codigoBanco the codigoBanco to set
	 */
	public void setCodigoBanco(Integer codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	/**
	 * @return the dataMovimento
	 */
	public Date getDataMovimento() {
		return dataMovimento;
	}

	/**
	 * @param dataMovimento the dataMovimento to set
	 */
	public void setDataMovimento(Date dataMovimento) {
		this.dataMovimento = dataMovimento;
	}

	/**
	 * @return the numeroRemessa
	 */
	public Integer getNumeroRemessa() {
		return numeroRemessa;
	}

	/**
	 * @param numeroRemessa the numeroRemessa to set
	 */
	public void setNumeroRemessa(Integer numeroRemessa) {
		this.numeroRemessa = numeroRemessa;
	}

	/**
	 * @return the numeroLinha
	 */
	public Integer getNumeroLinha() {
		return numeroLinha;
	}

	/**
	 * @param numeroLinha the numeroLinha to set
	 */
	public void setNumeroLinha(Integer numeroLinha) {
		this.numeroLinha = numeroLinha;
	}

	/**
	 * @return the descricaoErro
	 */
	public String getDescricaoErro() {
		return descricaoErro;
	}

	/**
	 * @param descricaoErro the descricaoErro to set
	 */
	public void setDescricaoErro(String descricaoErro) {
		this.descricaoErro = descricaoErro;
	}

	/**
	 * @return the codStatusProc
	 */
	public Integer getCodStatusProc() {
		return codStatusProc;
	}

	/**
	 * @param codStatusProc the codStatusProc to set
	 */
	public void setCodStatusProc(Integer codStatusProc) {
		this.codStatusProc = codStatusProc;
	}

	    
}
