package br.com.cielo.credenciamento.ejb.enums;

/**
 * Enum responsavel pelo tratarmento do status do processamento do registro da remessa de bancos
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public enum StatusEnum {
    PENDENTE(1),
    EM_PROCESSAMENTO(2),
    COM_ERRO(3),
    ACATADO(4),
    REJEITADO(5),
    PROCESSADO(6),
    PROBLEMA_SISTEMICO(99);
    
    private int dominio;

    /**
     * Construtor da classe enum.
     * @param status parametro de entrada do metodo
     */
    StatusEnum(final int dominio) {
        this.dominio = dominio;
    }

    /**
	 * @return the dominio
	 */
	public int getDominio() {
		return dominio;
	}

	/**
	 * @param dominio the dominio to set
	 */
	public void setDominio(int dominio) {
		this.dominio = dominio;
	}

	/**
     * Método responsavel por obter o Enum coresspondente ao dominio
     * @param dominio situacao
     * @return StatusEnum
     */
    public static StatusEnum getStatus(final int dominio) {
        for (StatusEnum enums : StatusEnum.values()) {
            if (enums.dominio == dominio) {
                return enums;
            }
        }
        return null;
    }
}
