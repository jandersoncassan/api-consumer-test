package br.com.cielo.credenciamento.ejb.domain.batch;

import java.util.LinkedList;
import java.util.List;

import br.com.cielo.credenciamento.ejb.annotation.FieldInfoCrd;
import br.com.cielo.credenciamento.ejb.domain.AbstractDTO;

/**
 * Classe responsavel por representar o prospect do arquivo, consistências do beanio
 * 
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class Prospect extends AbstractDTO {

    private static final long serialVersionUID = 1L;
    
    @FieldInfoCrd(tipo="N", tamanho=3, posInicial=1, posFinal=3)
    private String codigoMensagem;

    @FieldInfoCrd(tamanho=8, posInicial=4, posFinal=11)
    private String solicitante;

    @FieldInfoCrd(tamanho=4, posInicial=4, posFinal=7)
    private String numeroInstituicao;

    @FieldInfoCrd(tamanho=8, posInicial=8, posFinal=11)
    private String numeroIdentificacao;
    
    @FieldInfoCrd(tamanho=19, posInicial=12, posFinal=30)   
    private String areaReservada01;   
    
    @FieldInfoCrd(tipo="N", tamanho=2, posInicial=31, posFinal=32)
    private String codigoErro; 
    
    private String flagBanco; 
 
    @FieldInfoCrd(tipo="N", tamanho=3, posInicial=35, posFinal=37)
    private String banco;
 
    @FieldInfoCrd(tipo="N", tamanho=10, posInicial=38, posFinal=47)
    private String numeroEstabelecimento;
    
    private String flagRazaoSocial;

    @FieldInfoCrd(tipo="A", tamanho=32, posInicial=50, posFinal=81)
    private String razaoSocial;
     
    private Endereco enderecoCorrespondencia;

    private String flagCpfCnpj; 
    
    @FieldInfoCrd(tipo="N", tamanho=15, posInicial=194, posFinal=208)
    private String cpfCnpj;
    
    private String flagInscricaoEstadual; //erroInscricaoEstadual

    @FieldInfoCrd(tipo="N", tamanho=15, posInicial=211, posFinal=225)
    private String inscricaoEstadual;
    
    private String flagNomeFantasia;//erroNomeFantasia
 
    @FieldInfoCrd(tamanho=32, posInicial=228, posFinal=259)
    private String nomeFantasia;
    
    private Endereco enderecoEstabelecimento;

    private String flagNomePlaqueta;//erroNomePlaqueta
 
    @FieldInfoCrd(tamanho=22, posInicial=372, posFinal=393)
    private String nomePlaqueta;

    private String flagPessoaContato; //erroPessoaContato
 
    @FieldInfoCrd(tamanho=32, posInicial=396, posFinal=427)
    private String pessoaContato;
   
    @FieldInfoCrd(tamanho=44, posInicial=427, posFinal=471)
    private String areaReservada02;

    private String flagRamoAtividade; //erroRamoAtividade

    @FieldInfoCrd(tipo="N",tamanho=5, posInicial=474, posFinal=478)
    private String ramoAtividade;

    private Banco dadosBancarios;

    private List<Proprietario> proprietarios;

    private String flagTipoPessoa;//erroTipoPessoa

    @FieldInfoCrd(tamanho=1, posInicial=681, posFinal=681)
    private String tipoPessoa;

    @FieldInfoCrd(tamanho=12, posInicial=682, posFinal=693)
    private String areaReservada03;

    private List<Telefone> telefones;
 
    private String flagMei;//erroMei
 
    @FieldInfoCrd(tamanho=1, posInicial=730, posFinal=730)
    private String mei;

    private String correlationId;

    private String numeroProposta;
     
    private boolean layoutNovo;
    
    private boolean valido;
    
    /* LAYOUT NOVO*/
    @FieldInfoCrd(tipo="A",tamanho=6, posInicial=731, posFinal=736)
    private String areaReservadaCielo04;
    
    private String flagPacoteEcommerce;
    
    @FieldInfoCrd(tamanho=1, posInicial=739, posFinal=739)
    private String codPacoteEcommerce;
    
    @FieldInfoCrd(tamanho=6, posInicial=740, posFinal=745)
    private String areaReservadaCielo05;
    
    private String flagTipoConta;
    
    @FieldInfoCrd(tamanho=1, posInicial=748, posFinal=748)
    private String tipoConta;
    
    @FieldInfoCrd(tamanho=5, posInicial=749, posFinal=753)
    private String areaReservadaCielo06;
    
    private String flagPlanoCielo;
    
    @FieldInfoCrd(tipo="N",tamanho=2, posInicial=756, posFinal=757)
    private String codTipoPlano;
    
    private String flagValorFaturamento;
    
    @FieldInfoCrd(tipo="N",tamanho=13, posInicial=760, posFinal=772)
    private String valorFaturamento;
    
    private String flagQtdadeDiasLiquidacao;
    
    @FieldInfoCrd(tipo="N",tamanho=2, posInicial=775, posFinal=776)
    private String qtdadeDiasLiquidacao;
    
    private String flagSolucaoCaptura;
    
    @FieldInfoCrd(tipo="N",tamanho=6, posInicial=779, posFinal=784)
    private String solucaoCaptura;
    
    private String flagIndicadorAgro;
    
    @FieldInfoCrd(tamanho=1, posInicial=787, posFinal=787)
    private String indicadorAgro;
    
    private String flagNumEnderComercial;

    @FieldInfoCrd(tamanho=5, posInicial=790, posFinal=794)
    private String numEnderComercial;
 
    private String flagNumEnderCorrespondecia;
    
    @FieldInfoCrd(tamanho=5, posInicial=797, posFinal=801)
    private String numEnderCorrespondecia;
    
    private String flagEmail;

    @FieldInfoCrd(tamanho=806, posInicial=804, posFinal=1609)
    private String areaReservadaCielo07;
    
    @FieldInfoCrd(tamanho=60, posInicial=1610, posFinal=1669)
    private String email; 

    @FieldInfoCrd(tamanho=251, posInicial=1670, posFinal=1920)
    private String areaReservadaCielo08;
    /**/
    
    /**
     * Construtor da classe DTO Prospect.
     */
    public Prospect() {
        this.proprietarios = new LinkedList<Proprietario>();
        this.telefones = new LinkedList<Telefone>();
    }

	/**
	 * @return the codigoMensagem
	 */
	public String getCodigoMensagem() {
		return codigoMensagem;
	}

	/**
	 * @param codigoMensagem the codigoMensagem to set
	 */
	public void setCodigoMensagem(String codigoMensagem) {
		this.codigoMensagem = codigoMensagem;
	}

	/**
	 * @return the solicitante
	 */
	public String getSolicitante() {
		return numeroInstituicao.concat(numeroIdentificacao);
	}

	/**
	 * @param solicitante the solicitante to set
	 */
	public void setSolicitante(String solicitante) {
		this.solicitante = solicitante;
	}

	/**
	 * @return the numeroInstituicao
	 */
	public String getNumeroInstituicao() {
		return numeroInstituicao;
	}

	/**
	 * @param numeroInstituicao the numeroInstituicao to set
	 */
	public void setNumeroInstituicao(String numeroInstituicao) {
		this.numeroInstituicao = numeroInstituicao;
	}

	/**
	 * @return the numeroIdentificacao
	 */
	public String getNumeroIdentificacao() {
		return numeroIdentificacao;
	}

	/**
	 * @param numeroIdentificacao the numeroIdentificacao to set
	 */
	public void setNumeroIdentificacao(String numeroIdentificacao) {
		this.numeroIdentificacao = numeroIdentificacao;
	}

	/**
	 * @return the areaReservada01
	 */
	public String getAreaReservada01() {
		return areaReservada01;
	}

	/**
	 * @param areaReservada01 the areaReservada01 to set
	 */
	public void setAreaReservada01(String areaReservada01) {
		this.areaReservada01 = areaReservada01;
	}

	/**
	 * @return the codigoErro
	 */
	public String getCodigoErro() {
		return codigoErro;
	}

	/**
	 * @param codigoErro the codigoErro to set
	 */
	public void setCodigoErro(String codigoErro) {
		this.codigoErro = codigoErro;
	}

	/**
	 * @return the flagBanco
	 */
	public String getFlagBanco() {
		return flagBanco;
	}

	/**
	 * @param flagBanco the flagBanco to set
	 */
	public void setFlagBanco(String flagBanco) {
		this.flagBanco = flagBanco;
	}

	/**
	 * @return the banco
	 */
	public String getBanco() {
		return banco;
	}

	/**
	 * @param banco the banco to set
	 */
	public void setBanco(String banco) {
		this.banco = banco;
	}

	/**
	 * @return the numeroEstabelecimento
	 */
	public String getNumeroEstabelecimento() {
		return numeroEstabelecimento;
	}

	/**
	 * @param numeroEstabelecimento the numeroEstabelecimento to set
	 */
	public void setNumeroEstabelecimento(String numeroEstabelecimento) {
		this.numeroEstabelecimento = numeroEstabelecimento;
	}

	/**
	 * @return the flagRazaoSocial
	 */
	public String getFlagRazaoSocial() {
		return flagRazaoSocial;
	}

	/**
	 * @param flagRazaoSocial the flagRazaoSocial to set
	 */
	public void setFlagRazaoSocial(String flagRazaoSocial) {
		this.flagRazaoSocial = flagRazaoSocial;
	}

	/**
	 * @return the razaoSocial
	 */
	public String getRazaoSocial() {
		return razaoSocial;
	}

	/**
	 * @param razaoSocial the razaoSocial to set
	 */
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	/**
	 * @return the enderecoCorrespondencia
	 */
	public Endereco getEnderecoCorrespondencia() {
		return enderecoCorrespondencia;
	}

	/**
	 * @param enderecoCorrespondencia the enderecoCorrespondencia to set
	 */
	public void setEnderecoCorrespondencia(Endereco enderecoCorrespondencia) {
		this.enderecoCorrespondencia = enderecoCorrespondencia;
	}

	/**
	 * @return the flagCpfCnpj
	 */
	public String getFlagCpfCnpj() {
		return flagCpfCnpj;
	}

	/**
	 * @param flagCpfCnpj the flagCpfCnpj to set
	 */
	public void setFlagCpfCnpj(String flagCpfCnpj) {
		this.flagCpfCnpj = flagCpfCnpj;
	}

	/**
	 * @return the cpfCnpj
	 */
	public String getCpfCnpj() {
		return cpfCnpj;
	}

	/**
	 * @param cpfCnpj the cpfCnpj to set
	 */
	public void setCpfCnpj(String cpfCnpj) {
		this.cpfCnpj = cpfCnpj;
	}

	/**
	 * @return the flagInscricaoEstadual
	 */
	public String getFlagInscricaoEstadual() {
		return flagInscricaoEstadual;
	}

	/**
	 * @param flagInscricaoEstadual the flagInscricaoEstadual to set
	 */
	public void setFlagInscricaoEstadual(String flagInscricaoEstadual) {
		this.flagInscricaoEstadual = flagInscricaoEstadual;
	}

	/**
	 * @return the inscricaoEstadual
	 */
	public String getInscricaoEstadual() {
		return inscricaoEstadual;
	}

	/**
	 * @param inscricaoEstadual the inscricaoEstadual to set
	 */
	public void setInscricaoEstadual(String inscricaoEstadual) {
		this.inscricaoEstadual = inscricaoEstadual;
	}

	/**
	 * @return the flagNomeFantasia
	 */
	public String getFlagNomeFantasia() {
		return flagNomeFantasia;
	}

	/**
	 * @param flagNomeFantasia the flagNomeFantasia to set
	 */
	public void setFlagNomeFantasia(String flagNomeFantasia) {
		this.flagNomeFantasia = flagNomeFantasia;
	}

	/**
	 * @return the nomeFantasia
	 */
	public String getNomeFantasia() {
		return nomeFantasia;
	}

	/**
	 * @param nomeFantasia the nomeFantasia to set
	 */
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	/**
	 * @return the enderecoEstabelecimento
	 */
	public Endereco getEnderecoEstabelecimento() {
		return enderecoEstabelecimento;
	}

	/**
	 * @param enderecoEstabelecimento the enderecoEstabelecimento to set
	 */
	public void setEnderecoEstabelecimento(Endereco enderecoEstabelecimento) {
		this.enderecoEstabelecimento = enderecoEstabelecimento;
	}

	/**
	 * @return the flagNomePlaqueta
	 */
	public String getFlagNomePlaqueta() {
		return flagNomePlaqueta;
	}

	/**
	 * @param flagNomePlaqueta the flagNomePlaqueta to set
	 */
	public void setFlagNomePlaqueta(String flagNomePlaqueta) {
		this.flagNomePlaqueta = flagNomePlaqueta;
	}

	/**
	 * @return the nomePlaqueta
	 */
	public String getNomePlaqueta() {
		return nomePlaqueta;
	}

	/**
	 * @param nomePlaqueta the nomePlaqueta to set
	 */
	public void setNomePlaqueta(String nomePlaqueta) {
		this.nomePlaqueta = nomePlaqueta;
	}

	/**
	 * @return the flagPessoaContato
	 */
	public String getFlagPessoaContato() {
		return flagPessoaContato;
	}

	/**
	 * @param flagPessoaContato the flagPessoaContato to set
	 */
	public void setFlagPessoaContato(String flagPessoaContato) {
		this.flagPessoaContato = flagPessoaContato;
	}

	/**
	 * @return the pessoaContato
	 */
	public String getPessoaContato() {
		return pessoaContato;
	}

	/**
	 * @param pessoaContato the pessoaContato to set
	 */
	public void setPessoaContato(String pessoaContato) {
		this.pessoaContato = pessoaContato;
	}

	/**
	 * @return the areaReservada02
	 */
	public String getAreaReservada02() {
		return areaReservada02;
	}

	/**
	 * @param areaReservada02 the areaReservada02 to set
	 */
	public void setAreaReservada02(String areaReservada02) {
		this.areaReservada02 = areaReservada02;
	}

	/**
	 * @return the flagRamoAtividade
	 */
	public String getFlagRamoAtividade() {
		return flagRamoAtividade;
	}

	/**
	 * @param flagRamoAtividade the flagRamoAtividade to set
	 */
	public void setFlagRamoAtividade(String flagRamoAtividade) {
		this.flagRamoAtividade = flagRamoAtividade;
	}

	/**
	 * @return the ramoAtividade
	 */
	public String getRamoAtividade() {
		return ramoAtividade;
	}

	/**
	 * @param ramoAtividade the ramoAtividade to set
	 */
	public void setRamoAtividade(String ramoAtividade) {
		this.ramoAtividade = ramoAtividade;
	}

	/**
	 * @return the dadosBancarios
	 */
	public Banco getDadosBancarios() {
		return dadosBancarios;
	}

	/**
	 * @param dadosBancarios the dadosBancarios to set
	 */
	public void setDadosBancarios(Banco dadosBancarios) {
		this.dadosBancarios = dadosBancarios;
	}

	/**
	 * @return the proprietarios
	 */
	public List<Proprietario> getProprietarios() {
		return proprietarios;
	}

	/**
	 * @param proprietarios the proprietarios to set
	 */
	public void setProprietarios(List<Proprietario> proprietarios) {
		this.proprietarios = proprietarios;
	}

	/**
	 * @return the flagTipoPessoa
	 */
	public String getFlagTipoPessoa() {
		return flagTipoPessoa;
	}

	/**
	 * @param flagTipoPessoa the flagTipoPessoa to set
	 */
	public void setFlagTipoPessoa(String flagTipoPessoa) {
		this.flagTipoPessoa = flagTipoPessoa;
	}

	/**
	 * @return the tipoPessoa
	 */
	public String getTipoPessoa() {
		return tipoPessoa;
	}

	/**
	 * @param tipoPessoa the tipoPessoa to set
	 */
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	/**
	 * @return the areaReservada03
	 */
	public String getAreaReservada03() {
		return areaReservada03;
	}

	/**
	 * @param areaReservada03 the areaReservada03 to set
	 */
	public void setAreaReservada03(String areaReservada03) {
		this.areaReservada03 = areaReservada03;
	}

	/**
	 * @return the telefones
	 */
	public List<Telefone> getTelefones() {
		return telefones;
	}

	/**
	 * @param telefones the telefones to set
	 */
	public void setTelefones(List<Telefone> telefones) {
		this.telefones = telefones;
	}

	/**
	 * @return the flagMei
	 */
	public String getFlagMei() {
		return flagMei;
	}

	/**
	 * @param flagMei the flagMei to set
	 */
	public void setFlagMei(String flagMei) {
		this.flagMei = flagMei;
	}

	/**
	 * @return the mei
	 */
	public String getMei() {
		return mei;
	}

	/**
	 * @param mei the mei to set
	 */
	public void setMei(String mei) {
		this.mei = mei;
	}

	/**
	 * @return the correlationId
	 */
	public String getCorrelationId() {
		return correlationId;
	}

	/**
	 * @param correlationId the correlationId to set
	 */
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}

	/**
	 * @return the numeroProposta
	 */
	public String getNumeroProposta() {
		return numeroProposta;
	}

	/**
	 * @param numeroProposta the numeroProposta to set
	 */
	public void setNumeroProposta(String numeroProposta) {
		this.numeroProposta = numeroProposta;
	}

	/**
	 * @return the layoutNovo
	 */
	public boolean isLayoutNovo() {
		return layoutNovo;
	}

	/**
	 * @param layoutNovo the layoutNovo to set
	 */
	public void setLayoutNovo(boolean layoutNovo) {
		this.layoutNovo = layoutNovo;
	}

	/**
	 * @return the areaReservadaCielo04
	 */
	public String getAreaReservadaCielo04() {
		return areaReservadaCielo04;
	}

	/**
	 * @param areaReservadaCielo04 the areaReservadaCielo04 to set
	 */
	public void setAreaReservadaCielo04(String areaReservadaCielo04) {
		this.areaReservadaCielo04 = areaReservadaCielo04;
	}

	/**
	 * @return the flagPacoteEcommerce
	 */
	public String getFlagPacoteEcommerce() {
		return flagPacoteEcommerce;
	}

	/**
	 * @param flagPacoteEcommerce the flagPacoteEcommerce to set
	 */
	public void setFlagPacoteEcommerce(String flagPacoteEcommerce) {
		this.flagPacoteEcommerce = flagPacoteEcommerce;
	}

	/**
	 * @return the codPacoteEcommerce
	 */
	public String getCodPacoteEcommerce() {
		return codPacoteEcommerce;
	}

	/**
	 * @param codPacoteEcommerce the codPacoteEcommerce to set
	 */
	public void setCodPacoteEcommerce(String codPacoteEcommerce) {
		this.codPacoteEcommerce = codPacoteEcommerce;
	}

	/**
	 * @return the areaReservadaCielo05
	 */
	public String getAreaReservadaCielo05() {
		return areaReservadaCielo05;
	}

	/**
	 * @param areaReservadaCielo05 the areaReservadaCielo05 to set
	 */
	public void setAreaReservadaCielo05(String areaReservadaCielo05) {
		this.areaReservadaCielo05 = areaReservadaCielo05;
	}

	/**
	 * @return the flagTipoConta
	 */
	public String getFlagTipoConta() {
		return flagTipoConta;
	}

	/**
	 * @param flagTipoConta the flagTipoConta to set
	 */
	public void setFlagTipoConta(String flagTipoConta) {
		this.flagTipoConta = flagTipoConta;
	}

	/**
	 * @return the tipoConta
	 */
	public String getTipoConta() {
		return tipoConta;
	}

	/**
	 * @param tipoConta the tipoConta to set
	 */
	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	/**
	 * @return the areaReservadaCielo06
	 */
	public String getAreaReservadaCielo06() {
		return areaReservadaCielo06;
	}

	/**
	 * @param areaReservadaCielo06 the areaReservadaCielo06 to set
	 */
	public void setAreaReservadaCielo06(String areaReservadaCielo06) {
		this.areaReservadaCielo06 = areaReservadaCielo06;
	}

	/**
	 * @return the flagPlanoCielo
	 */
	public String getFlagPlanoCielo() {
		return flagPlanoCielo;
	}

	/**
	 * @param flagPlanoCielo the flagPlanoCielo to set
	 */
	public void setFlagPlanoCielo(String flagPlanoCielo) {
		this.flagPlanoCielo = flagPlanoCielo;
	}

	/**
	 * @return the codTipoPlano
	 */
	public String getCodTipoPlano() {
		return codTipoPlano;
	}

	/**
	 * @param codTipoPlano the codTipoPlano to set
	 */
	public void setCodTipoPlano(String codTipoPlano) {
		this.codTipoPlano = codTipoPlano;
	}

	/**
	 * @return the flagValorFaturamento
	 */
	public String getFlagValorFaturamento() {
		return flagValorFaturamento;
	}

	/**
	 * @param flagValorFaturamento the flagValorFaturamento to set
	 */
	public void setFlagValorFaturamento(String flagValorFaturamento) {
		this.flagValorFaturamento = flagValorFaturamento;
	}

	/**
	 * @return the valorFaturamento
	 */
	public String getValorFaturamento() {
		return valorFaturamento;
	}

	/**
	 * @param valorFaturamento the valorFaturamento to set
	 */
	public void setValorFaturamento(String valorFaturamento) {
		this.valorFaturamento = valorFaturamento;
	}

	/**
	 * @return the flagQtdadeDiasLiquidacao
	 */
	public String getFlagQtdadeDiasLiquidacao() {
		return flagQtdadeDiasLiquidacao;
	}

	/**
	 * @param flagQtdadeDiasLiquidacao the flagQtdadeDiasLiquidacao to set
	 */
	public void setFlagQtdadeDiasLiquidacao(String flagQtdadeDiasLiquidacao) {
		this.flagQtdadeDiasLiquidacao = flagQtdadeDiasLiquidacao;
	}

	/**
	 * @return the qtdadeDiasLiquidacao
	 */
	public String getQtdadeDiasLiquidacao() {
		return qtdadeDiasLiquidacao;
	}

	/**
	 * @param qtdadeDiasLiquidacao the qtdadeDiasLiquidacao to set
	 */
	public void setQtdadeDiasLiquidacao(String qtdadeDiasLiquidacao) {
		this.qtdadeDiasLiquidacao = qtdadeDiasLiquidacao;
	}

	/**
	 * @return the flagSolucaoCaptura
	 */
	public String getFlagSolucaoCaptura() {
		return flagSolucaoCaptura;
	}

	/**
	 * @param flagSolucaoCaptura the flagSolucaoCaptura to set
	 */
	public void setFlagSolucaoCaptura(String flagSolucaoCaptura) {
		this.flagSolucaoCaptura = flagSolucaoCaptura;
	}

	/**
	 * @return the solucaoCaptura
	 */
	public String getSolucaoCaptura() {
		return solucaoCaptura;
	}

	/**
	 * @param solucaoCaptura the solucaoCaptura to set
	 */
	public void setSolucaoCaptura(String solucaoCaptura) {
		this.solucaoCaptura = solucaoCaptura;
	}

	/**
	 * @return the flagIndicadorAgro
	 */
	public String getFlagIndicadorAgro() {
		return flagIndicadorAgro;
	}

	/**
	 * @param flagIndicadorAgro the flagIndicadorAgro to set
	 */
	public void setFlagIndicadorAgro(String flagIndicadorAgro) {
		this.flagIndicadorAgro = flagIndicadorAgro;
	}

	/**
	 * @return the indicadorAgro
	 */
	public String getIndicadorAgro() {
		return indicadorAgro;
	}

	/**
	 * @param indicadorAgro the indicadorAgro to set
	 */
	public void setIndicadorAgro(String indicadorAgro) {
		this.indicadorAgro = indicadorAgro;
	}

	/**
	 * @return the flagNumEnderComercial
	 */
	public String getFlagNumEnderComercial() {
		return flagNumEnderComercial;
	}

	/**
	 * @param flagNumEnderComercial the flagNumEnderComercial to set
	 */
	public void setFlagNumEnderComercial(String flagNumEnderComercial) {
		this.flagNumEnderComercial = flagNumEnderComercial;
	}

	/**
	 * @return the numEnderComercial
	 */
	public String getNumEnderComercial() {
		return numEnderComercial;
	}

	/**
	 * @param numEnderComercial the numEnderComercial to set
	 */
	public void setNumEnderComercial(String numEnderComercial) {
		this.numEnderComercial = numEnderComercial;
	}

	/**
	 * @return the flagNumEnderCorrespondecia
	 */
	public String getFlagNumEnderCorrespondecia() {
		return flagNumEnderCorrespondecia;
	}

	/**
	 * @param flagNumEnderCorrespondecia the flagNumEnderCorrespondecia to set
	 */
	public void setFlagNumEnderCorrespondecia(String flagNumEnderCorrespondecia) {
		this.flagNumEnderCorrespondecia = flagNumEnderCorrespondecia;
	}

	/**
	 * @return the numEnderCorrespondecia
	 */
	public String getNumEnderCorrespondecia() {
		return numEnderCorrespondecia;
	}

	/**
	 * @param numEnderCorrespondecia the numEnderCorrespondecia to set
	 */
	public void setNumEnderCorrespondecia(String numEnderCorrespondecia) {
		this.numEnderCorrespondecia = numEnderCorrespondecia;
	}

	/**
	 * @return the flagEmail
	 */
	public String getFlagEmail() {
		return flagEmail;
	}

	/**
	 * @param flagEmail the flagEmail to set
	 */
	public void setFlagEmail(String flagEmail) {
		this.flagEmail = flagEmail;
	}

	/**
	 * @return the areaReservadaCielo07
	 */
	public String getAreaReservadaCielo07() {
		return areaReservadaCielo07;
	}

	/**
	 * @param areaReservadaCielo07 the areaReservadaCielo07 to set
	 */
	public void setAreaReservadaCielo07(String areaReservadaCielo07) {
		this.areaReservadaCielo07 = areaReservadaCielo07;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the areaReservadaCielo08
	 */
	public String getAreaReservadaCielo08() {
		return areaReservadaCielo08;
	}

	/**
	 * @param areaReservadaCielo08 the areaReservadaCielo08 to set
	 */
	public void setAreaReservadaCielo08(String areaReservadaCielo08) {
		this.areaReservadaCielo08 = areaReservadaCielo08;
	}

	/**
	 * @return the valido
	 */
	public boolean isValido() {
		return valido;
	}

	/**
	 * @param valido the valido to set
	 */
	public void setValido(boolean valido) {
		this.valido = valido;
	}


}
