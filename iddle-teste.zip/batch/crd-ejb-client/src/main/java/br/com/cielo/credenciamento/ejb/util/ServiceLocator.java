package br.com.cielo.credenciamento.ejb.util;

import java.util.Properties;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import br.com.cielo.credenciamento.ejb.config.CRDConfig;
import br.com.cielo.credenciamento.ejb.remote.IArquivoRetornoServiceRemote;
import br.com.cielo.credenciamento.ejb.remote.IControleIncidenteServiceRemote;
import br.com.cielo.credenciamento.ejb.remote.ICredenciamentoServiceRemote;
import br.com.cielo.credenciamento.ejb.remote.IDesbloqueioMobileServiceRemote;
import br.com.cielo.credenciamento.ejb.remote.IPrimeiraTransacaoServiceRemote;

/**
 * Classe ServiceLocator responsavel pelo lookup dos EJBs remote 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public final class ServiceLocator {

	private static final String BATCH_JAVA_NAMING_PROVIDER_URL = "batch.java.naming.provider.url";
	private static final ServiceLocator INSTANCE = new ServiceLocator();


	/**
	 * @return ServiceLocator
	 */
	public static ServiceLocator getInstance() {
		return INSTANCE;
	}

	/**
	 * @return Context contexto para lookup.
	 * @throws NamingException
	 *             caso ocorra erro ao encontrar o recurso remoto.
	 */
	private Context getContext() throws NamingException {
		Properties properties = new Properties();
		properties.setProperty(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
		properties.put(Context.PROVIDER_URL, CRDConfig.getProperty(BATCH_JAVA_NAMING_PROVIDER_URL));

		Context context = new InitialContext(properties);
		return context;
	}

	/**
	 * @return DataServiceRemote
	 * @throws NamingException
	 *             lancamento de exception para tratamento de erro
	 */
	public IPrimeiraTransacaoServiceRemote getPrimeiraTransacaoServiceRemote() throws NamingException {
		Context context = getContext();
		return (IPrimeiraTransacaoServiceRemote) context
				.lookup("PrimeiraTransacaoService#br.com.cielo.credenciamento.ejb.remote.IPrimeiraTransacaoServiceRemote");
	}

	/**
	 * @return ControleIncidenteServiceRemote
	 * @throws NamingException
	 *             lancamento de exception para tratamento de erro
	 */
	public IControleIncidenteServiceRemote getControleIncidenteServiceRemote() throws NamingException {
		Context context = getContext();
		return (IControleIncidenteServiceRemote) context.lookup(
				"ControleIncidenteService#br.com.cielo.credenciamento.ejb.remote.IControleIncidenteServiceRemote");
	}

	/**
	 * @return CredenciamentoService
	 * @throws NamingException
	 *             lancamento de exception para tratamento de erro
	 */
	public ICredenciamentoServiceRemote getCredenciamentoServiceRemote() throws NamingException {
		return ((ICredenciamentoServiceRemote) getContext()
				.lookup("CredenciamentoService#br.com.cielo.credenciamento.ejb.remote.ICredenciamentoServiceRemote"));
	}

	/**
	 * @return ArquivoRetornoService
	 * @throws NamingException
	 *             lancamento de exception para tratamento de erro
	 */
	public IArquivoRetornoServiceRemote getArquivoRetornoServiceRemote() throws NamingException {
		return ((IArquivoRetornoServiceRemote) getContext()
				.lookup("ArquivoRetornoService#br.com.cielo.credenciamento.ejb.remote.IArquivoRetornoServiceRemote"));
	}

	/**
	 * @return IDesbloqueioMobileServiceRemote
	 * @throws NamingException
	 *             lancamento de exception para tratamento de erro
	 */
	public IDesbloqueioMobileServiceRemote getDesbloqueioMobileServiceRemote() throws NamingException {
		return ((IDesbloqueioMobileServiceRemote) getContext()
				.lookup("DesbloqueioMobileService#br.com.cielo.credenciamento.ejb.remote.IDesbloqueioMobileServiceRemote"));
	}

}
