package br.com.cielo.credenciamento.ejb.domain.batch;

import java.io.Serializable;
import java.util.Date;

public class DesbloqueioMobile implements Serializable{

	private static final long serialVersionUID = 1L;
	
	//TRANSACAO VEM COM MUITA INFORMAÇÃO QUE NÃO UTILIZAMOS
	private String other1;
	private String other2;
	private String other3;
	private String other4;
	
	//DADOS UTEIS
    private Long codigoEstabelecimento;    
    private Integer codigoTerminal;
    private Date data;
	/**
	 * @return the other1
	 */
	public String getOther1() {
		return other1;
	}
	/**
	 * @param other1 the other1 to set
	 */
	public void setOther1(String other1) {
		this.other1 = other1;
	}
	/**
	 * @return the other2
	 */
	public String getOther2() {
		return other2;
	}
	/**
	 * @param other2 the other2 to set
	 */
	public void setOther2(String other2) {
		this.other2 = other2;
	}
	/**
	 * @return the other3
	 */
	public String getOther3() {
		return other3;
	}
	/**
	 * @param other3 the other3 to set
	 */
	public void setOther3(String other3) {
		this.other3 = other3;
	}
	/**
	 * @return the other4
	 */
	public String getOther4() {
		return other4;
	}
	/**
	 * @param other4 the other4 to set
	 */
	public void setOther4(String other4) {
		this.other4 = other4;
	}
	/**
	 * @return the codigoEstabelecimento
	 */
	public Long getCodigoEstabelecimento() {
		return codigoEstabelecimento;
	}
	/**
	 * @param codigoEstabelecimento the codigoEstabelecimento to set
	 */
	public void setCodigoEstabelecimento(Long codigoEstabelecimento) {
		this.codigoEstabelecimento = codigoEstabelecimento;
	}
	/**
	 * @return the codigoTerminal
	 */
	public Integer getCodigoTerminal() {
		return codigoTerminal;
	}
	/**
	 * @param codigoTerminal the codigoTerminal to set
	 */
	public void setCodigoTerminal(Integer codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}
	/**
	 * @return the data
	 */
	public Date getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(Date data) {
		this.data = data;
	}


    
}
