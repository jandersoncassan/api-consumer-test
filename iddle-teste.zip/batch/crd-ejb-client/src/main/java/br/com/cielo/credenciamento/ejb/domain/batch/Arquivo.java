package br.com.cielo.credenciamento.ejb.domain.batch;

import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

/**
 * DTO do arquivo para importação dos registros via BeanIO.
 * 
 * @author cristianobenato
 */
public class Arquivo implements Serializable {

    /** serialVersionUID do Arquivo */
    private static final long serialVersionUID = 9034539454689492436L;

    /** header do layout novo */
    private Header header;

    /** lista de prospects */
    private List<Prospect> prospects;

    /** Trailer do layout novo */
    private Trailer trailer;

    private String sequenciaMovimento;

    /**
     * Construtor da classe DTO do Arquivo.
     */
    public Arquivo() {
        this.prospects = new LinkedList<Prospect>();
    }

    /**
     * getSequenciaMovimento().
     * 
     * @return - String sequenciaMovimento
     */
    public String getSequenciaMovimento() {
        return this.sequenciaMovimento;
    }

    /**
     * setSequenciaMovimento(final String sequenciaMovimento)
     * 
     * @param sequenciaMovimento - String
     */
    public void setSequenciaMovimento(final String sequenciaMovimento) {
        this.sequenciaMovimento = sequenciaMovimento;
    }

    /**
     * @return the header
     */
    public Header getHeader() {
        return this.header;
    }

    /**
     * @param header the header to set
     */
    public void setHeader(final Header header) {
        this.header = header;
    }

    /**
     * @return the prospects
     */
    public List<Prospect> getProspects() {
        return this.prospects;
    }

    /**
     * @param prospects the prospects to set
     */
    public void setProspects(final List<Prospect> prospects) {
        this.prospects = prospects;
    }

    /**
     * @return the trailer
     */
    public Trailer getTrailer() {
        return this.trailer;
    }

    /**
     * @param trailer the trailer to set
     */
    public void setTrailer(final Trailer trailer) {
        this.trailer = trailer;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (this.header == null ? 0 : this.header.hashCode());
        result = prime * result + (this.prospects == null ? 0 : this.prospects.hashCode());
        result = prime * result + (this.trailer == null ? 0 : this.trailer.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Arquivo other = (Arquivo) obj;
        if (this.header == null) {
            if (other.header != null) {
                return false;
            }
        } else if (!this.header.equals(other.header)) {
            return false;
        }
        if (this.prospects == null) {
            if (other.prospects != null) {
                return false;
            }
        } else if (!this.prospects.equals(other.prospects)) {
            return false;
        }
        if (this.trailer == null) {
            if (other.trailer != null) {
                return false;
            }
        } else if (!this.trailer.equals(other.trailer)) {
            return false;
        }
        return true;
    }
}
