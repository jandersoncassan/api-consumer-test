package br.com.cielo.credenciamento.ejb.constantes;

/**
 * Classe de constants para serem utilizadas no projeto
 * 
 * @author <a href="mailto:jrmarques1@stefanini.com>Jose Renato Sena Marques</a>
 * @version $Id$
 */
public interface Constants {

    int ZERO_I = 0;

    long ZERO_L = 0L;

    String ZERO_S = "0";

    int UM = 1;

    int DOIS = 2;
    
    String ZERO_DOIS = "02";

    int TRES = 3;

    long TRES_L = 3;

    int QUATRO = 4;
    
    long QUATRO_L = 4;

    int CINCO = 5;

    int SEIS = 6;

    int SETE = 7;

    int OITO = 8;

    int NOVE = 9;

    int DEZ = 10;

    int ONZE = 11;

    int DOZE = 12;

    String DOZE_S = String.valueOf(DOZE);

    int TREZE = 13;

    String TREZE_S = "13";

    int QUATORZE = 14;

    long QUATORZE_L = 14;

    int QUINZE = 15;

    int DEZESSEIS = 16;

    String DEZESSEIS_S = "16";
    
    int DEZESSETE = 17;

    int DEZOITO = 18;
    
    String DEZOITO_S = "18";

    int DEZENOVE = 19;

    String DEZENOVE_S = "19";

    int VINTE_E_DOIS = 22;

    int VINTE_E_TRES = 23;

    int VINTE_E_CINCO = 25;

    int TRINTA_E_UM = 31;

    int TRINTA_E_DOIS = 32;

    int QUARENTA = 40;

    int QUARENTA_OITO = 48;

    int CINQUENTA = 50;

    int CINQUENTA_E_NOVE = 59;

    int SETENTA = 70;

    int CENTO_E_CINQUENTA = 150;

    int DOIS_DIGITOS = 99;

    int TRES_DIGITOS = 999;

    int QUATRO_DIGITOS = 9999;

    int CINCO_DIGITOS = 99999;

    int SEIS_DIGITOS = 999999;

    int OITO_DIGITOS = 99999999;

    int NOVE_DIGITOS = 999999999;

    long DEZ_DIGITOS = 9999999999L;

    long DOZE_DIGITOS = 999999999999L;

    long QUINZE_DIGITOS = 999999999999999L;

    long QUATORZE_DIGITOS = 99999999999999L;
    
    int TODOS = 0;
    
    int SECULO_VINTE = 1900;
    int SECULO_VINTE_UM = 2000;

    String OK = "OK";

    String NOK = "NOK";
    
    String ASSINCRONO = "A";
    
    String SINCRONO = "S";

    String S = "S";
    
    String A = "A";

    String N = "N";

    String EMPTY_STRING = "";

    String UM_S = "01";
    
    String UM_SEM_ZERO = "1";

    String DOIS_S = "2";

    String TRES_S = "3";

    String QUATRO_S = "4";

    String CINCO_S = "5";

    String SEIS_S = "6";

    String ZERO_SEIS = "06";

    String SETE_S = "07";

    String OITO_S = "8";

    String NOVE_S = "9";

    String DEZ_S = "10";

    String ONZE_S = "11";

    String QUARENTA_QUATRO_S = "44";

    String SESSENTA_SETE_S = "67";

    long NOVENTA_E_NOVE = 99;

    int SETENTA_E_QUATRO = 74;

    String VINTE = "20";

    String USUARIO_CRD = "CRDUSR";

    String ZERO_SETE = "07";

    String ZERO_OITO = "08";

    String ZERO_NOVE = "09";

    String ZERO_CINCO = "05";

    String ZERO_QUATRO = "04";

    String ZERO_TRES = "03";

    String ZERO_ZERO = "00";
    
    String INIT_TAG = "<soap:Header";
    String FINISH_TAG = "</soap:Header>";
	
    String INI_ERROR_TAG = "<descricaoErroProvedor>";
    String FINISH_ERROR_TAG = "</descricaoErroProvedor>";
	
    String ICDT_PROCESSADO = "N";
    String ICDT_RETOMADO = "S";
	
    String ETAPA_WHERE_IN = "5, 7, 9, 11, 12, 14";
    String TIMELINE_WHERE_IN = "5, 6, 7, 9, 11, 12, 14, 15";
    String ETAPA_SUCESSO = "Sucesso";
    String ETAPA_PENDENTE = "Pendente";
    String ETAPA_PARCIAL = "Parcial";
    String ETAPA_VALIDAS_PARCIAL = "6, 7";
    String ETAPA_INSUCESSO = "Insucesso";
	
    int TIMELINE_INSUCESSO = 4;
    int TIMELINE_SUCESSO = 2;
    int TIMELINE_INPROGRESS = 1;
    int TIMELINE_NONE = 0;
	
	/**
	 * See timeline.css
	 */
    String CSS_TIMELINE_SUCESSO = "active-step-conclude";
    String CSS_TIMELINE_INPROGRESS = "active-step-inprogress";
    String CSS_TIMELINE_INSUCESS = "active-step-insucess";
    String CSS_TIMELINE_POINT = "step-num";
    String CSS_TIMELINE_POINT_LAST = "step-last";

    String ZERO_UM = "01";
    String NAO_DISPONIVEL = "N/D";
    String PESSOA_FISICA = "F";
    String ERRO_MEI_IDA = "90";
    String ERRO_MEI_TELA = "157";
    String NOVENTA = "90";
    
    /**
     * Codigos de Erro
     */
    String NAO_HA_ERRO_S = Constants.ZERO_ZERO;
    String ERRO_DEVERIA_NUMERICO_S = Constants.UM_S;
    String ERRO_NAO_PODE_BRANCO_S = Constants.DEZ_S;
    String ERRO_NAO_PODE_ZEROS_S = Constants.ONZE_S;
    
    /**
     * Codigo do campo
     *
     */
    Long AGENCIA = 1L;
    Long BANCO = 2L;
    Long BANCO_VISA_VALE = 3L;
    Long COMPLEMENTO_DO_MCC = 4L;
    Long RAMO_DE_ATIVIDADE = 5L;
    Long TIPO_DE_TERMINAL = 6L;
    Long CENTRO_DE_COMPRAS = 7L;
    Long DATA_DE_NASCIMENTO_DO_PRIMEIRO_PROPRIETARIO = 8L;
    Long DATA_DE_NASCIMENTO_DO_SEGUNDO_PROPRIETARIO = 9L;
    Long DATA_DE_NASCIMENTO_DO_TERCEIRO_PROPRIETARIO = 10L;
    Long PROTOCOLO = 11L;
    Long CADASTRO_DUPLICADO = 12L;
    Long FLEX_CAR = 13L;
    Long MEI = 14L;
    Long OPERADOR_DE_SAUDE = 15L;
    Long TROCO_FACIL = 16L;
    Long INDICADOR_MOBILE = 17L;
    Long RAZAO_SOCIAL = 18L;
    Long AGENCIA_VISA_VALE = 19L;
    Long CEP_ENDERECO_COMERCIAL = 20L;
    Long CEP_ENDERECO_DE_CORRESPONDENCIA = 21L;
    Long CONTA_CORRENTE = 22L;
    Long CONTA_CORRENTE_VISA_VALE = 23L;
    Long CPF_CNPJ = 24L;
    Long CPF_DO_PRIMEIRO_PROPRIETARIO = 25L;
    Long CPF_DO_SEGUNDO_PROPRIETARIO = 26L;
    Long CPF_DO_TERCEIRO_PROPRIETARIO = 27L;
    Long DDD_TELEFONE_DO_ESTABELECIMENTO = 28L;
    Long DDD_FAX = 29L;
    Long INSCRICAO_ESTADUAL = 30L;
    Long FAX = 31L;
    Long TELEFONE_DO_ESTABELECIMENTO = 32L;
    Long CIDADE_DO_ESTABELECIMENTO = 33L;
    Long CIDADE_DE_CORRESPONDENCIA = 34L;
    Long NOME_DO_PRIMEIRO_PROPRIETARIO = 35L;
    Long NOME_DO_SEGUNDA_PROPRIETARIO = 36L;
    Long NOME_DO_TERCEIRO_PROPRIETARIO = 37L;
    Long NOME_FANTASIA = 38L;
    Long LOGRADOURO_DO_ESTABELECIMENTO = 39L;
    Long LOGRADOURO_DE_CORRESPONDENCIA = 40L;
    Long CONTATO = 41L;
    Long PLAQUETA = 42L;
    Long TAXA_FLEX_CAR = 43L;
    Long TAXA_TROCO_FACIL = 44L;
    Long PRAZO_DO_FLEX_CAR = 45L;
    Long PRAZO_DO_TROCO_FACIL = 46L;
    Long TIPO_DE_PESSOA = 47L;
    Long ESTADO_DO_ESTABELECIMENTO = 48L;
    Long ESTADO_DE_CORRESPONDENCIA = 49L;

    int VINTE_I = 20;

    int VINTE_E_QUATRO = 24;

    String SPACE_STRING = " ";
    
}
