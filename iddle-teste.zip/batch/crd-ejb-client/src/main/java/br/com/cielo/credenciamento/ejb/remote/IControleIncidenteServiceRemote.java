package br.com.cielo.credenciamento.ejb.remote;

import javax.ejb.Remote;

import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;

/**
 * Interface remota responsavel pelas consistências de retomada de incidente
 * 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Remote
public interface IControleIncidenteServiceRemote {

	/**
	 * Método responsavel por incluir o registro de incidente na base de dados
	 * @param incidente
	 */
	void incluirIncidente(Incidente incidente);
	
	/**
	 * Método responsavel por buscar o incidente através do id do incidente
	 * @param codigoIncidente
	 * @return
	 */
    Incidente findIncidente(String codigoIncidente);
    
    /**
     * Método responsavel por efetuar a retomada dos incidentes
     * @param incidentes
     */
    void retomarIncidente(Incidente incidente);
 }