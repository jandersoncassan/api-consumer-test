package br.com.cielo.credenciamento.ejb.annotation;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.Retention;
import java.lang.annotation.Target;

/**
 * Annotation para tratamento das informações de tipagem dos campos no layout de bancos
 * @author @Cielo S/A
 * @version 1.0.0
 * @since Release 02 Credenciamento
 */
@Retention(RUNTIME)
@Target({ FIELD, METHOD })
public @interface FieldInfoCrd {
	String tipo() default "A"; //ALFANUMERICO | NUMERICO
	int tamanho();
	int posInicial();
	int posFinal();
}
