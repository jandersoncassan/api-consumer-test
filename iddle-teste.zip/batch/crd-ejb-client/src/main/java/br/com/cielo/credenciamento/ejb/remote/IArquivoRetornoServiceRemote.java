package br.com.cielo.credenciamento.ejb.remote;

import java.util.List;

import javax.ejb.Remote;

import br.com.cielo.credenciamento.ejb.domain.batch.Arquivo;

/**
 * Interface remote responsavel pelos metodos implementação para tratamento e geração do arquivo de retorno 
 * @author @Cielo 
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Remote
public interface IArquivoRetornoServiceRemote {

	/**
	 * Método responsavel por efetuar o tratamento e geração dos dados do arquivo de retorno
	 * @param codigoBanco
	 * @return
	 */
	List<Arquivo> tratarArquivoRetorno(String codigoBanco);
}
