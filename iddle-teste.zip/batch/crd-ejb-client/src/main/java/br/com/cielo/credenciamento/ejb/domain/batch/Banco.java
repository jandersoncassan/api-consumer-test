package br.com.cielo.credenciamento.ejb.domain.batch;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import br.com.cielo.credenciamento.ejb.annotation.FieldInfoCrd;
import br.com.cielo.credenciamento.ejb.domain.AbstractDTO;

/**
 * DTO do banco.
 * 
 * @author <a href="mailto:jrmarques1@stefanini.com>José Renato Sena Marques</a>
 * @version $Id$
 */
@XmlRootElement(name = "dadosBancariosCliente")
@XmlAccessorType(XmlAccessType.NONE)
public class Banco extends AbstractDTO {

    private static final long serialVersionUID = 5824866277656342657L;

    private String erroCodigoBanco;

    @XmlElement
    private String codigoBanco;

    private String flagCodigoAgencia;//erroCodigoAgencia

    @FieldInfoCrd(tipo="N",tamanho=5, posInicial=481, posFinal=485)
    @XmlElement(name = "numeroAgencia")
    private String codigoAgencia;

    private String flagNumeroContaCorrente;//erroNumeroContaCorrente

    @FieldInfoCrd(tipo="N",tamanho=14, posInicial=488, posFinal=501)
    @XmlElement
    private String numeroContaCorrente;

	/**
	 * @return the erroCodigoBanco
	 */
	public String getErroCodigoBanco() {
		return erroCodigoBanco;
	}

	/**
	 * @param erroCodigoBanco the erroCodigoBanco to set
	 */
	public void setErroCodigoBanco(String erroCodigoBanco) {
		this.erroCodigoBanco = erroCodigoBanco;
	}

	/**
	 * @return the codigoBanco
	 */
	public String getCodigoBanco() {
		return codigoBanco;
	}

	/**
	 * @param codigoBanco the codigoBanco to set
	 */
	public void setCodigoBanco(String codigoBanco) {
		this.codigoBanco = codigoBanco;
	}

	/**
	 * @return the flagCodigoAgencia
	 */
	public String getFlagCodigoAgencia() {
		return flagCodigoAgencia;
	}

	/**
	 * @param flagCodigoAgencia the flagCodigoAgencia to set
	 */
	public void setFlagCodigoAgencia(String flagCodigoAgencia) {
		this.flagCodigoAgencia = flagCodigoAgencia;
	}

	/**
	 * @return the codigoAgencia
	 */
	public String getCodigoAgencia() {
		return codigoAgencia;
	}

	/**
	 * @param codigoAgencia the codigoAgencia to set
	 */
	public void setCodigoAgencia(String codigoAgencia) {
		this.codigoAgencia = codigoAgencia;
	}

	/**
	 * @return the flagNumeroContaCorrente
	 */
	public String getFlagNumeroContaCorrente() {
		return flagNumeroContaCorrente;
	}

	/**
	 * @param flagNumeroContaCorrente the flagNumeroContaCorrente to set
	 */
	public void setFlagNumeroContaCorrente(String flagNumeroContaCorrente) {
		this.flagNumeroContaCorrente = flagNumeroContaCorrente;
	}

	/**
	 * @return the numeroContaCorrente
	 */
	public String getNumeroContaCorrente() {
		return numeroContaCorrente;
	}

	/**
	 * @param numeroContaCorrente the numeroContaCorrente to set
	 */
	public void setNumeroContaCorrente(String numeroContaCorrente) {
		this.numeroContaCorrente = numeroContaCorrente;
	}

 
}
