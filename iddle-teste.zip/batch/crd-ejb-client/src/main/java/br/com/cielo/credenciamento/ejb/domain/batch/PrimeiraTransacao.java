package br.com.cielo.credenciamento.ejb.domain.batch;

import java.io.Serializable;
import java.util.Date;


/**
 * Classe responsavel pelas informações de 1° transação
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class PrimeiraTransacao implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long codigoEstabelecimento;
    
    private Integer codigoTerminal;

    private Date data;

	/**
	 * @return the codigoEstabelecimento
	 */
	public Long getCodigoEstabelecimento() {
		return codigoEstabelecimento;
	}

	/**
	 * @param codigoEstabelecimento the codigoEstabelecimento to set
	 */
	public void setCodigoEstabelecimento(Long codigoEstabelecimento) {
		this.codigoEstabelecimento = codigoEstabelecimento;
	}

	/**
	 * @return the codigoTerminal
	 */
	public Integer getCodigoTerminal() {
		return codigoTerminal;
	}

	/**
	 * @param codigoTerminal the codigoTerminal to set
	 */
	public void setCodigoTerminal(Integer codigoTerminal) {
		this.codigoTerminal = codigoTerminal;
	}

	/**
	 * @return the data
	 */
	public Date getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(Date data) {
		this.data = data;
	}
    
 
    
}
