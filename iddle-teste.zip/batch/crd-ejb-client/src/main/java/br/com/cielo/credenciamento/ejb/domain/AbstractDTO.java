package br.com.cielo.credenciamento.ejb.domain;

import java.io.Serializable;

/**
 * Classe DTO Abstrata.
 * 
 * @author <a href="mailto:jrmarques1@stefanini.com>José Renato Sena Marques</a>
 * @version $Id$
 */
public class AbstractDTO implements Serializable {

    private static final long serialVersionUID = 7572970697040175707L;

}
