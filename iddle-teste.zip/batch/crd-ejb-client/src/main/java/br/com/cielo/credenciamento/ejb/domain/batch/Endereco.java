package br.com.cielo.credenciamento.ejb.domain.batch;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import br.com.cielo.credenciamento.ejb.annotation.FieldInfoCrd;
import br.com.cielo.credenciamento.ejb.domain.AbstractDTO;

/**
 * DTO Endereco.
 * 
 * @author <a href="mailto:jrmarques1@stefanini.com>José Renato Sena Marques</a>
 * @version $Id$
 */
@XmlRootElement(name = "Endereco")
@XmlType(propOrder = {"tipoEndereco", "logradouro", "cidade", "estado", "cep",
        "complementoLogradouro"})
@XmlAccessorType(XmlAccessType.NONE)
public class Endereco extends AbstractDTO {

    private static final long serialVersionUID = -607552951214414108L;

    @XmlElement(name = "codigoTipoEndereco")
    private int tipoEndereco;

    private String flagLogradouro;

    @FieldInfoCrd(tamanho=32, posInicial=84, posFinal=115)
    @XmlElement(name = "nomeLogradouro")
    private String logradouro;

    @FieldInfoCrd(tamanho=32, posInicial=116, posFinal=147)
    @XmlElement(name = "descricaoComplementoEndereco")
    private String complementoLogradouro;

    private String flagCidade;

    @FieldInfoCrd(tamanho=28, posInicial=150, posFinal=177)
    @XmlElement(name = "nomeCidade")
    private String cidade;

    private String flagEstado;
    
    @FieldInfoCrd(tamanho=2, posInicial=180, posFinal=181)
    @XmlElement(name = "siglaEstado")
    private String estado;

    private String flagCep;

    @FieldInfoCrd(tipo="N", tamanho=8, posInicial=184, posFinal=191)
    @XmlElement(name = "numeroCEP")
    private String cep;

	/**
	 * @return the tipoEndereco
	 */
	public int getTipoEndereco() {
		return tipoEndereco;
	}

	/**
	 * @param tipoEndereco the tipoEndereco to set
	 */
	public void setTipoEndereco(int tipoEndereco) {
		this.tipoEndereco = tipoEndereco;
	}

	/**
	 * @return the flagLogradouro
	 */
	public String getFlagLogradouro() {
		return flagLogradouro;
	}

	/**
	 * @param flagLogradouro the flagLogradouro to set
	 */
	public void setFlagLogradouro(String flagLogradouro) {
		this.flagLogradouro = flagLogradouro;
	}

	/**
	 * @return the logradouro
	 */
	public String getLogradouro() {
		return logradouro;
	}

	/**
	 * @param logradouro the logradouro to set
	 */
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}

	/**
	 * @return the complementoLogradouro
	 */
	public String getComplementoLogradouro() {
		return complementoLogradouro;
	}

	/**
	 * @param complementoLogradouro the complementoLogradouro to set
	 */
	public void setComplementoLogradouro(String complementoLogradouro) {
		this.complementoLogradouro = complementoLogradouro;
	}

	/**
	 * @return the flagCidade
	 */
	public String getFlagCidade() {
		return flagCidade;
	}

	/**
	 * @param flagCidade the flagCidade to set
	 */
	public void setFlagCidade(String flagCidade) {
		this.flagCidade = flagCidade;
	}

	/**
	 * @return the cidade
	 */
	public String getCidade() {
		return cidade;
	}

	/**
	 * @param cidade the cidade to set
	 */
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	/**
	 * @return the flagEstado
	 */
	public String getFlagEstado() {
		return flagEstado;
	}

	/**
	 * @param flagEstado the flagEstado to set
	 */
	public void setFlagEstado(String flagEstado) {
		this.flagEstado = flagEstado;
	}

	/**
	 * @return the estado
	 */
	public String getEstado() {
		return estado;
	}

	/**
	 * @param estado the estado to set
	 */
	public void setEstado(String estado) {
		this.estado = estado;
	}

	/**
	 * @return the flagCep
	 */
	public String getFlagCep() {
		return flagCep;
	}

	/**
	 * @param flagCep the flagCep to set
	 */
	public void setFlagCep(String flagCep) {
		this.flagCep = flagCep;
	}

	/**
	 * @return the cep
	 */
	public String getCep() {
		return cep;
	}

	/**
	 * @param cep the cep to set
	 */
	public void setCep(String cep) {
		this.cep = cep;
	}


}
