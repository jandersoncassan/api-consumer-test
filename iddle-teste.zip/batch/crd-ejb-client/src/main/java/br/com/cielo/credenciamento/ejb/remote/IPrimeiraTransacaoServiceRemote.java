package br.com.cielo.credenciamento.ejb.remote;

import javax.ejb.Remote;

import br.com.cielo.credenciamento.ejb.domain.batch.PrimeiraTransacao;

/**
 * Interface remota responsavel pelas consistencias da primeira transacao
 * 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Remote
public interface IPrimeiraTransacaoServiceRemote {

    /**
     * Método responsavel por atualizar as informações de 1° transação (**)
     * @param primeiroTransacao
     */
    void atualizarPrimeiraTransacao(PrimeiraTransacao primeiraTransacao);

}
