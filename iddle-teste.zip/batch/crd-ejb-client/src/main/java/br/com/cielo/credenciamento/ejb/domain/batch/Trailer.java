package br.com.cielo.credenciamento.ejb.domain.batch;

import java.io.Serializable;
import java.util.Date;

/**
 * @author cristianobenato
 */
public class Trailer implements Serializable {

    /** serialVersionUID do Trailer */
    private static final long serialVersionUID = -3626152807934975209L;

    private Date dataMovimento;

    private String banco;

    private String quantidadeRegistros;

    /**
     * @return the dataMovimento
     */
    public Date getDataMovimento() {
        return this.dataMovimento;
    }

    /**
     * @param dataMovimento the dataMovimento to set
     */
    public void setDataMovimento(final Date dataMovimento) {
        this.dataMovimento = dataMovimento;
    }

    /**
     * @return the banco
     */
    public String getBanco() {
        return this.banco;
    }

    /**
     * @param banco the banco to set
     */
    public void setBanco(final String banco) {
        this.banco = banco;
    }

    /**
     * @return the quantidadeRegistros
     */
    public String getQuantidadeRegistros() {
        return this.quantidadeRegistros;
    }

    /**
     * @param quantidadeRegistros the quantidadeRegistros to set
     */
    public void setQuantidadeRegistros(final String quantidadeRegistros) {
        this.quantidadeRegistros = quantidadeRegistros;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (this.banco == null ? 0 : this.banco.hashCode());
        result = prime * result + (this.dataMovimento == null ? 0 : this.dataMovimento.hashCode());
        result = prime * result
                        + (this.quantidadeRegistros == null ? 0 : this.quantidadeRegistros.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        Trailer other = (Trailer) obj;
        if (this.banco == null) {
            if (other.banco != null) {
                return false;
            }
        } else if (!this.banco.equals(other.banco)) {
            return false;
        }
        if (this.dataMovimento == null) {
            if (other.dataMovimento != null) {
                return false;
            }
        } else if (!this.dataMovimento.equals(other.dataMovimento)) {
            return false;
        }
        if (this.quantidadeRegistros == null) {
            if (other.quantidadeRegistros != null) {
                return false;
            }
        } else if (!this.quantidadeRegistros.equals(other.quantidadeRegistros)) {
            return false;
        }
        return true;
    }
}
