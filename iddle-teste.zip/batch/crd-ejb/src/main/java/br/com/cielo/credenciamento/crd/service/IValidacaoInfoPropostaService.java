package br.com.cielo.credenciamento.crd.service;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;

/**
 * Interface responsavel pelos metodos de tratamento da validação 'Fisica' e 'TP' antes da chamada do serviço de credenciamernto
 * @author @Cielo
 * @since Release 02 Credenciamento
 * @version 1.0.0
 */
public interface IValidacaoInfoPropostaService{

	/**
	 * Método responsavel por garantir a tipagem 'FISICA' dos campos e regras de TP para credenciamento
	 * @param prospect
	 */
	void tratarTipagemCampos(final Prospect prospect);
	
	/**
	 * Método responsavel por aplicar as regras de TP Layout Atual , caso layout novo assumir informações do layout 
	 * @param prospect
	 */
	void tratarTipoProcessamento(final Prospect prospect);
}
