package br.com.cielo.credenciamento.crd.service.osb;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.credenciamento.ejb.domain.batch.DesbloqueioMobile;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoRequest;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoResponse;
import br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;

/**
 * Interface responsavel pela definição dos metodos de serviços que serão utilizados pelo CRD
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public interface IServicesCredenciamento {

	/**
	 * Método responsavel pela inclusão da proposta de credenciamento no CRD (RL01) via OSB
	 * @param request
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	CredenciarClienteResponse credenciarClienteOSB(CredenciarClienteRequest request) throws MalformedURLException, ServiceException, Fault, RemoteException;
	

	/**
	 *  Método responsavel pela inclusão da proposta de credenciamento no CRD (RL01) via CRD
	 * @param request
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws SOAPException
	 * @throws RemoteException
	 */
	CredenciamentoResponse credenciarClienteCRD(CredenciamentoRequest request)throws MalformedURLException, ServiceException, SOAPException, RemoteException;
	
	/**
	 * Método responsavel por efetuar o desbloqueio mobile
	 * 
	 * @param infoDesbloqueio
	 * @throws ServiceException
	 * @throws RemoteException
	 * @throws MalformedURLException
	 */
	void efetivarDesbloqueioMobile(DesbloqueioMobile infoDesbloqueio) throws ServiceException, RemoteException, MalformedURLException;
}
