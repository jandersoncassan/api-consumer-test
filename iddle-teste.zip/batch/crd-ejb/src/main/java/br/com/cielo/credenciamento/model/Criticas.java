
package br.com.cielo.credenciamento.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "criticas"
})
public class Criticas {

    @JsonProperty("criticas")
    private List<Critica> criticas = null;

    @JsonProperty("criticas")
    public List<Critica> getCriticas() {
        return criticas;
    }

    @JsonProperty("criticas")
    public void setCriticas(List<Critica> criticas) {
        this.criticas = criticas;
    }

}
