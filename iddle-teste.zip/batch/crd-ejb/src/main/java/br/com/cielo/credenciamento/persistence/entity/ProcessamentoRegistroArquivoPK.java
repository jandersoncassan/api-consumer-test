package br.com.cielo.credenciamento.persistence.entity;

import static br.com.cielo.credenciamento.ejb.constantes.Constants.DEZESSETE;
import static br.com.cielo.credenciamento.ejb.constantes.Constants.TRINTA_E_DOIS;
import static br.com.cielo.credenciamento.ejb.constantes.Constants.TRINTA_E_UM;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * PK representando a tabela work, Processamento do Registro 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Embeddable
public class ProcessamentoRegistroArquivoPK implements Serializable {

    // default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name = "CD_BNCO", insertable = false, updatable = false, unique = true, nullable = false, precision = 3)
    private Integer cdBnco;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_MVMN_ARQV_BNCO", insertable = false, updatable = false, unique = true, nullable = false)
    private Date dtMvmnArqvBnco;

    @Column(name = "NU_RMSA_ARQV_BNCO", insertable = false, updatable = false, unique = true, nullable = false, precision = 3)
    private Integer nuRmsaArqvBnco;

    @Column(name = "NU_LNHA_RGST_ARQV_BNCO", insertable = false, updatable = false, unique = true, nullable = false, precision = 4)
    private Integer nuLnhaRgstArqvBnco;

    /**
     * Método get do atributo cdBnco
     * 
     * @return O valor do atributo cdBnco
     */
    public Integer getCdBnco() {
        return this.cdBnco;
    }

    /**
     * Método set do atributo cdBnco
     * 
     * @param cdBnco Valor para setar no atributo cdBnco
     */
    public void setCdBnco(final Integer cdBnco) {
        this.cdBnco = cdBnco;
    }

    /**
     * Método get do atributo dtMvmnArqvBnco
     * 
     * @return O valor do atributo dtMvmnArqvBnco
     */
    public java.util.Date getDtMvmnArqvBnco() {
        return this.dtMvmnArqvBnco;
    }

    /**
     * Método set do atributo dtMvmnArqvBnco
     * 
     * @param dtMvmnArqvBnco Valor para setar no atributo dtMvmnArqvBnco
     */
    public void setDtMvmnArqvBnco(final java.util.Date dtMvmnArqvBnco) {
        this.dtMvmnArqvBnco = dtMvmnArqvBnco;
    }


    /**
	 * @return the nuRmsaArqvBnco
	 */
	public Integer getNuRmsaArqvBnco() {
		return nuRmsaArqvBnco;
	}

	/**
	 * @param nuRmsaArqvBnco the nuRmsaArqvBnco to set
	 */
	public void setNuRmsaArqvBnco(Integer nuRmsaArqvBnco) {
		this.nuRmsaArqvBnco = nuRmsaArqvBnco;
	}

	/**
	 * @return the nuLnhaRgstArqvBnco
	 */
	public Integer getNuLnhaRgstArqvBnco() {
		return nuLnhaRgstArqvBnco;
	}

	/**
	 * @param nuLnhaRgstArqvBnco the nuLnhaRgstArqvBnco to set
	 */
	public void setNuLnhaRgstArqvBnco(Integer nuLnhaRgstArqvBnco) {
		this.nuLnhaRgstArqvBnco = nuLnhaRgstArqvBnco;
	}

	@Override
    public boolean equals(final Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof ProcessamentoRegistroArquivoPK)) {
            return false;
        }
        ProcessamentoRegistroArquivoPK castOther = (ProcessamentoRegistroArquivoPK) other;
        return this.cdBnco == castOther.cdBnco
                        && this.dtMvmnArqvBnco.equals(castOther.dtMvmnArqvBnco)
                        && this.nuRmsaArqvBnco == castOther.nuRmsaArqvBnco
                        && this.nuLnhaRgstArqvBnco == castOther.nuLnhaRgstArqvBnco;
    }

    @Override
    public int hashCode() {
        final int prime = TRINTA_E_UM;
        int hash = DEZESSETE;
        hash = hash * prime + (int) (this.cdBnco ^ this.cdBnco >>> TRINTA_E_DOIS);
        hash = hash * prime + this.dtMvmnArqvBnco.hashCode();
        hash = hash * prime + (int) (this.nuRmsaArqvBnco ^ this.nuRmsaArqvBnco >>> TRINTA_E_DOIS);
        hash = hash * prime + this.nuLnhaRgstArqvBnco.hashCode();

        return hash;
    }
}
