package br.com.cielo.credenciamento.crd.service;

import javax.ejb.Local;

import br.com.cielo.credenciamento.ejb.remote.IPrimeiraTransacaoServiceRemote;

/**
 * Interface Local responsael pela implementacao das consistências envolvendo a 1º transacao
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IPrimeiraTransacaoService extends IPrimeiraTransacaoServiceRemote{

}
