package br.com.cielo.credenciamento.persistence.dao.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.persistence.dao.IControleIncidenteDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.ControleIncidentesProcess;

/**
 * Classe DAO responsavel pelos metodos da entidade de Controle de Incidentes
 * 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class ControleIncidenteDAO extends AbstractJpaDAO<ControleIncidentesProcess> implements IControleIncidenteDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ControleIncidenteDAO.class);

	public ControleIncidenteDAO() {
		super(ControleIncidentesProcess.class);
	}

	@Override
	public ControleIncidentesProcess create(ControleIncidentesProcess entity) {
		LOG.info("INCLUSAO DE INCIDENTE DAO");
		return super.create(entity);
	}

	@Override
	public ControleIncidentesProcess findIncidente(final Long idIncidente) {
		LOG.info("BUSCANDO INCIDENTE COM O ID {}", idIncidente);
		try {
			String strQuery = "FROM " + getEntityClass().getSimpleName() + " c " + "WHERE c.id = :pId AND c.flagControle = 'N'";
			
			TypedQuery<ControleIncidentesProcess> query = getEntityManager().createQuery(strQuery,ControleIncidentesProcess.class);
			query.setParameter("pId", idIncidente);

			return query.getSingleResult();

		} catch (final NoResultException exc) {
			LOG.error("INCIDENTE NAO ENCONTRADO");
			return null;
		}
	}

	@Override
	public List<Long> obterListaIncidentes() {
		LOG.info("BUSCANDO A LISTA DE INCIDENTES");
		StringBuilder sql = new StringBuilder("SELECT i.id FROM " + getEntityClass().getSimpleName() + " i ");
		sql.append("WHERE IN_ICDT_RSVD = 'N'");

		TypedQuery<Long> query = getEntityManager().createQuery(sql.toString(), Long.class);
		return query.getResultList();
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Object[]> getListaCriticasProposta(Long numeroProposta) {
		LOG.info("BUSCANDO A LISTA DE CRITICAS DA PROPOSTA " + numeroProposta);
		try {
			StringBuilder sql = new StringBuilder(
					"SELECT  ETPA.CD_ETPA_CRDN, PRP.CD_CTCI_CRDN, ETPA.CD_STCO_ETPA_PRPS_CRDN, CRI.CD_TIPO_ERRO_VLDC, EC.NU_EC, CMPO.NU_SQNL_CMPO, PRP.IN_RSVA_CTCI_PRPS ");
			sql.append("FROM CRD.TBCRDR_CTCI_PRPS_CRDN PRP ");
			sql.append("INNER JOIN CRD.TBCRDR_CTCI_CMPO_PRPS_CRDN CMPO ");
			sql.append("ON PRP.NU_PRPS_CRDN = CMPO.NU_PRPS_CRDN ");
			sql.append("AND PRP.CD_ETPA_CRDN = CMPO.CD_ETPA_CRDN ");
			sql.append("AND PRP.CD_CTCI_CRDN = CMPO.CD_CTCI_CRDN ");
			sql.append("INNER JOIN CRD.TBCRDR_CTCI_CRDN CRI ");
			sql.append("ON PRP.CD_CTCI_CRDN = CRI.CD_CTCI_CRDN ");
			sql.append("AND PRP.CD_ETPA_CRDN = CRI.CD_ETPA_CRDN ");
			sql.append("INNER JOIN CRD.TBCRDR_ETPA_PRPS_CRDN ETPA ");
			sql.append("ON PRP.NU_PRPS_CRDN = ETPA.NU_PRPS_CRDN ");
			// sql.append("AND PRP.CD_ETPA_CRDN = ETPA.CD_ETPA_CRDN ");
			sql.append("INNER JOIN TBCRDR_EC_PRPS EC ");
			sql.append("ON PRP.NU_PRPS_CRDN = EC.NU_PRPS_CRDN ");
			sql.append("WHERE PRP.NU_PRPS_CRDN = :pNumeroProposta ");
			// sql.append("AND PRP.IN_RSVA_CTCI_PRPS = 'N'");
			sql.append("ORDER BY ETPA.CD_ETPA_CRDN ASC");

			Query query = getEntityManager().createNativeQuery(sql.toString());
			query.setParameter("pNumeroProposta", numeroProposta);

			List<Object[]> listaCriticas = query.getResultList();
			return listaCriticas;

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERO AO BUSCAR A LISTA DE CRITICAS DA PROPOSTA : {} " + numeroProposta);
			return null;
		}
	}

	@Override
	public void expurgoIncidentesProcessados() {
		LOG.info("DAO - EXECUCAO ROTINA DE EXPURGO TABELA INCIDENTES");
		try {
			StringBuilder sql = new StringBuilder("DELETE FROM TBCRDW_CNTR_ICDT_POCS_CRDN ");
						               sql.append("WHERE DT_MVMN_ARQV_BNCO < SYSDATE - 90");
			
			Query query = getEntityManager().createNativeQuery(sql.toString());
			query.executeUpdate();

		} catch (Exception ex) {
			LOG.error("ERROR EXECUCAO ROTINA DE EXPURGO TABELA INCIDENTES {}", ex);
		}
	}

}