package br.com.cielo.credenciamento.persistence.dao;

import java.util.List;

import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.ControleIncidentesProcess;

/**
 * Interface responsavel por tratar consistências envolvendo indicentes da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IControleIncidenteDAO extends IOperations<ControleIncidentesProcess> {

	/**
	 * Método responsavel por obter o registro de incidente atraves do id
	 * @param idIncidente
	 * @return
	 */
	ControleIncidentesProcess findIncidente(Long idIncidente);
     
    /**
     * Método responsavel por obter a lisat de incidentes gerados na comunicação com a RL01
     * @return
     */
    List<Long> obterListaIncidentes();
    
    /**
     * Método responsavel por recuperar a lista de criticas da proposta
     * @param numeroProposta
     * @return
     */
    List<Object[]> getListaCriticasProposta(Long numeroProposta);;
    
    /**
     * Método responsavel por executar o processo de expurgo da tabela de incidentes
     * A regra de expurgo, exclui fisicamente os registros com mais de 90 dias
     */
    void expurgoIncidentesProcessados();
    
}
