package br.com.cielo.credenciamento.persistence.dao;

import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.EtapaProposta;

/**
 * Interface responsavel pela implementacao dos servicos da etapa de credenciamento
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IEtapaCredenciamentoPropostaDAO extends IOperations<EtapaProposta> {

    /**
     * Método responsavel por verificar se existe etapa de ativação criada para a proposta
     * @param numeroProposta
     * @return
     */
    EtapaProposta findEtapaAtivacao(Long numeroProposta);
    
    /**
     * Método responsavel por atualizar a data de fechamento da etapa de ativação
     * @param numeroProposta
     */
    void atualizarEtapaAtivacao(Long numeroProposta);

}
