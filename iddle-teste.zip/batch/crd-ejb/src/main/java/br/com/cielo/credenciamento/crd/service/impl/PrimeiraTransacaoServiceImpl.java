package br.com.cielo.credenciamento.crd.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.service.IPrimeiraTransacaoService;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.PrimeiraTransacao;
import br.com.cielo.credenciamento.ejb.remote.IPrimeiraTransacaoServiceRemote;
import br.com.cielo.credenciamento.persistence.dao.IArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.IEtapaCredenciamentoPropostaDAO;
import br.com.cielo.credenciamento.persistence.dao.IPropostaEcDAO;
import br.com.cielo.credenciamento.persistence.dao.ISolucaoCaputuraDAO;
import br.com.cielo.credenciamento.persistence.entity.EstabelecimentoComercial;
import br.com.cielo.credenciamento.persistence.entity.EtapaProposta;
import br.com.cielo.credenciamento.persistence.entity.EtapaPropostaPK;
import br.com.cielo.credenciamento.persistence.entity.SolucaoCaptura;

/**
 * Classe service responsavel pela implementação das consistências de 1° transação
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless(mappedName = "PrimeiraTransacaoService", name = "PrimeiraTransacaoService")
public class PrimeiraTransacaoServiceImpl implements IPrimeiraTransacaoService, IPrimeiraTransacaoServiceRemote {

	private static final Logger LOG = LoggerFactory.getLogger(PrimeiraTransacaoServiceImpl.class);
	
    @EJB
    private IPropostaEcDAO propostaEcDAO;

    @EJB
    private ISolucaoCaputuraDAO solucaoCapturaDAO;

    @EJB
    private IEtapaCredenciamentoPropostaDAO etapaCredenciamentoPropostaDAO;

    @EJB
    private IArquivoDAO arquivoDAO;
    
 
	@Override
	public void atualizarPrimeiraTransacao(PrimeiraTransacao primeiraTransacao) {
		Long numeroEc = primeiraTransacao.getCodigoEstabelecimento();
		
		LOG.info("ATUALIZANDO A 1 TRANSACAO DO EC {}", numeroEc);
		EstabelecimentoComercial entityEc = propostaEcDAO.findByEc(numeroEc);
		
		if(null != entityEc){
			
			Optional<Date> dataPrimTransacao = Optional.ofNullable(entityEc.getDtAtvcEc());
			LOG.info("DATA DE ATIVACAO DO EC, JA EXISTE ? {}", dataPrimTransacao.isPresent() );
			//SOMENTE ATUALIZAMOS A DATA DE ATIVACAO SE ELA NAO EXISTIR
			if(!dataPrimTransacao.isPresent()){			
				LOG.info("ATUALIZANDO A TABELA DE EC");
				entityEc.setDtAtvcEc(primeiraTransacao.getData());
				entityEc.setDhAltrRgst(new Date());
				
				LOG.info("ATUALIZANDO AS INFORMACOES DA ETAPA");
				createOrUpdateEtapaAtivacao(entityEc.getNuPrpsCrdn());
				
				LOG.info("ATUALIZANDO A SITUACAO DA PROPOSTA");
				propostaEcDAO.atualizarSituacaoProposta(entityEc.getNuPrpsCrdn());
		    }
			
			LOG.info("ATUALIZANDO AS INFORMACOES DA SOLUCAO DE CAPTURA");
			List<SolucaoCaptura> listaEquipamentos = solucaoCapturaDAO.findAll(entityEc.getNuPrpsCrdn());
			LOG.info("QTDADE DE EQUIPAMENTOS {}", listaEquipamentos.size());
			for (SolucaoCaptura solucao : listaEquipamentos) {
				Optional<Integer> numeroLogico = Optional.ofNullable(solucao.getNuLgcoEqpmCptr());
				if(numeroLogico.isPresent()){
					if(numeroLogico.get().equals(primeiraTransacao.getCodigoTerminal())){
						
						Optional<Date> dataAtvEquipamento = Optional.ofNullable(solucao.getDhAtvcEqpmCptr());
						LOG.info("DATA DE ATIVACAO DO EQUIPAMENTO, JA EXISTE ? {}", dataAtvEquipamento.isPresent() );
						//SOMENTE ATUALIZAMOS A DATA DE ATIVACAO DO EQUIPAMENTO, SE ELA NAO EXISTIR
						if(!dataAtvEquipamento.isPresent()){
							solucao.setDhAtvcEqpmCptr(primeiraTransacao.getData());
							solucao.setDhAltrRgst(new Date());
						}
					}
				}
			}
			
			
		}else{
			LOG.info("O EC {} NAO FOI ENCONTRADO NAS TABELAS DO CRD", numeroEc);
		}
	}
	
	/**
	 * Método responsavel por criar | atualizar a etapa de ativação da proposta
	 * @param numeroProposta
	 */
	private void createOrUpdateEtapaAtivacao(Long numeroProposta){		
		if(existeEtapaValidacao(numeroProposta)){
			etapaCredenciamentoPropostaDAO.atualizarEtapaAtivacao(numeroProposta);
			
		}else{			
			etapaCredenciamentoPropostaDAO.create(popularInfoEtapa(numeroProposta));
		}
	}

	/**
	 * Método responsavel por verificar se a etapa de ativação existe
	 * @param numeroProposta
	 * @return
	 */
	private boolean existeEtapaValidacao(Long numeroProposta) {
		EtapaProposta entity = etapaCredenciamentoPropostaDAO.findEtapaAtivacao(numeroProposta);
		return (null != entity? true: false);
	}

	/**
	 * Populamos as informações da etapa da proposta "ATIVACAO"
	 * @param numeroProposta
	 * @return
	 */
	private EtapaProposta popularInfoEtapa(Long numeroProposta) {
        EtapaProposta etapa = new EtapaProposta();
  
        EtapaPropostaPK id = new EtapaPropostaPK();
        id.setNuPrpsCrdn(numeroProposta);
        id.setCdEtpaCrdn(CrdUtils.ETAPA_ATIVACAO);
        etapa.setId(id);
 
        Date dataCriacao = new Date();
        etapa.setCodSituacaoEtapa(CrdUtils.STATUS_ETAPA_SUCESSO);
        etapa.setDhAbrtEtpaPrpsCrdn(dataCriacao);        
        etapa.setCdUsroInclRgst("CRDUSR");
        etapa.setDhInclRgst(dataCriacao);
        etapa.setCdUsroAltrRgst("CRDUSR");
        etapa.setDhAltrRgst(dataCriacao);        
        etapa.setDhEnceEtpaPrpsCrdn(dataCriacao);
       
        return etapa;
	}
}
