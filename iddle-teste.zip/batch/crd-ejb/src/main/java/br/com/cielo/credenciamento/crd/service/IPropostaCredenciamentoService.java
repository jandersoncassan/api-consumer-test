package br.com.cielo.credenciamento.crd.service;

import java.util.Date;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;

/**
 * Interface responsavel por definir as consistências de Prospect
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public interface IPropostaCredenciamentoService {

	/**
	 * Método responsavel pela persistência das informações de prospect
	 * 
	 * @param prospect
	 * @param dataExecucao
	 * @param codigoBanco
	 * @param numRemessa
	 * @param numLinha
	 * @return
	 */
	void incluirProspect(Prospect prospect, Date dataExecucao, Integer codigoBanco, Integer numRemessa, Integer numLinha);
	
	/**
	 * Método responsavel por atualizar o numero total de remessas
	 * 
	 * @param dataExecucao
	 * @param codigoBanco
	 * @param numRemess
	 */
	void atualizarTotalLinhaRemessa( Date dataExecucao, Integer codigoBanco, Integer numeroRemessa, Integer totalRegistros);

}
