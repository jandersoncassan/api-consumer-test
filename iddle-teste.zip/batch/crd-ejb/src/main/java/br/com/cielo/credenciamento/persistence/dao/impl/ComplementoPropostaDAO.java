package br.com.cielo.credenciamento.persistence.dao.impl;

import java.util.Calendar;
import java.util.Date;

import javax.ejb.Stateless;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.constantes.Constants;
import br.com.cielo.credenciamento.persistence.dao.IComplementoPropostaDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.ComplementoProposta;

/**
 * Classe DAO responsavel pelas consistencias da tabela de complemento da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class ComplementoPropostaDAO extends AbstractJpaDAO<ComplementoProposta> implements IComplementoPropostaDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ComplementoPropostaDAO.class);

	public ComplementoPropostaDAO() {
		super(ComplementoProposta.class);
	}

	@Override
	public ComplementoProposta findById(Long numeroProposta) {
		LOG.info("FIND REGISTRO COMPLEMENTO BY ID {}", numeroProposta );
		return super.findOne(numeroProposta);
	}

	@Override
	public ComplementoProposta fyndByCorrelation(Integer codigoBanco, Date dataRemessa, Integer numeroRemessa,	Integer numeroLinha) {
		LOG.info("FIND REGISTRO COMPLEMENTO BY CORRELATION ID");

	       Calendar cal = Calendar.getInstance();
	       cal.setTime(dataRemessa);
	       cal.set(Calendar.HOUR_OF_DAY, 0);
	       cal.set(Calendar.MINUTE, 0);
	       cal.set(Calendar.SECOND, 0);
	       Date dataInicio = cal.getTime();
	        
	       cal.add(Calendar.HOUR_OF_DAY, Constants.VINTE_E_TRES);
	       cal.add(Calendar.MINUTE, Constants.CINQUENTA_E_NOVE);
	       cal.add(Calendar.SECOND, Constants.CINQUENTA_E_NOVE);
	       Date dataFim = cal.getTime();
    		
		try{
			StringBuilder sql = new StringBuilder("FROM "+getEntityClass().getSimpleName()+" C ");
			sql.append("WHERE ");
			sql.append("C.cdBnco = :pCdBnco ");
			sql.append("AND C.dtMvmnArqvBnco >= :dtMvmnArqvBncoIni ");
			sql.append("AND C.dtMvmnArqvBnco <= :dtMvmnArqvBncoFim ");
			sql.append("AND C.nuRmsaArqvBnco = :pNuRmsaArqvBnco ");
			sql.append("AND C.nuLnhaRgstArqvBnco = :pNuLnhaRgstArqvBnco");
	
			TypedQuery<ComplementoProposta> query = getEntityManager().createQuery(sql.toString(), ComplementoProposta.class);
			query.setParameter("pCdBnco", codigoBanco);
			query.setParameter("dtMvmnArqvBncoIni", dataInicio);
			query.setParameter("dtMvmnArqvBncoFim", dataFim);
			query.setParameter("pNuRmsaArqvBnco", numeroRemessa);
			query.setParameter("pNuLnhaRgstArqvBnco", numeroLinha);
			
			ComplementoProposta entity = query.getSingleResult();
			
			return entity;
			
		}catch(NoResultException ex){
			LOG.info("NAO HA REGISTRO CADASTRADO COM O CORRELATION ID {}", CrdUtils.popularCorrelationId(codigoBanco, dataRemessa, numeroRemessa, numeroLinha));
			return null;
		}
	}
}
