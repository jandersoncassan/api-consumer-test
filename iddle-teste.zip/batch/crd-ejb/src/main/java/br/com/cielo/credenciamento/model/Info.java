
package br.com.cielo.credenciamento.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "codigoSec",
    "cpLayout",
    "cpEntidade",
    "colEntidade"
})
public class Info implements Serializable{

	private static final long serialVersionUID = 1L;

	@JsonProperty("codigoSec")
    private String codigoSec;
    
    @JsonProperty("cpLayout")
    private String cpLayout;
    
    @JsonProperty("cpEntidade")
    private String cpEntidade;
    
    @JsonProperty("colEntidade")
    private String colEntidade;

    @JsonProperty("codigoSec")
    public String getCodigoSec() {
        return codigoSec;
    }

    @JsonProperty("codigoSec")
    public void setCodigoSec(String codigoSec) {
        this.codigoSec = codigoSec;
    }

    @JsonProperty("cpLayout")
    public String getCpLayout() {
        return cpLayout;
    }

    @JsonProperty("cpLayout")
    public void setCpLayout(String cpLayout) {
        this.cpLayout = cpLayout;
    }

    @JsonProperty("cpEntidade")
    public String getCpEntidade() {
        return cpEntidade;
    }

    @JsonProperty("cpEntidade")
    public void setCpEntidade(String cpEntidade) {
        this.cpEntidade = cpEntidade;
    }

    @JsonProperty("colEntidade")
    public String getColEntidade() {
        return colEntidade;
    }

    @JsonProperty("colEntidade")
    public void setColEntidade(String colEntidade) {
        this.colEntidade = colEntidade;
    }

}
