package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * PK representando a tabela Controlde de Carga Bancos 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Embeddable
public class LogControleCargaBancoPK implements Serializable {

    // default serial version id, required for serializable classes.
    private static final long serialVersionUID = 1L;

    @Column(name = "CD_BNCO", unique = true, nullable = false, precision = 3)
    private Integer cdBnco;

    @Temporal(TemporalType.DATE)
    @Column(name = "DT_MVMN_ARQV_BNCO", unique = true, nullable = false)
    private java.util.Date dtMvmnArqvBnco;

    @Column(name = "NU_RMSA_ARQV_BNCO", unique = true, nullable = false, precision = 3)
    private Integer nuRmsaArqvBnco;

	/**
	 * @return the cdBnco
	 */
	public Integer getCdBnco() {
		return cdBnco;
	}

	/**
	 * @param cdBnco the cdBnco to set
	 */
	public void setCdBnco(Integer cdBnco) {
		this.cdBnco = cdBnco;
	}

	/**
	 * @return the dtMvmnArqvBnco
	 */
	public java.util.Date getDtMvmnArqvBnco() {
		return dtMvmnArqvBnco;
	}

	/**
	 * @param dtMvmnArqvBnco the dtMvmnArqvBnco to set
	 */
	public void setDtMvmnArqvBnco(java.util.Date dtMvmnArqvBnco) {
		this.dtMvmnArqvBnco = dtMvmnArqvBnco;
	}

	/**
	 * @return the nuRmsaArqvBnco
	 */
	public Integer getNuRmsaArqvBnco() {
		return nuRmsaArqvBnco;
	}

	/**
	 * @param nuRmsaArqvBnco the nuRmsaArqvBnco to set
	 */
	public void setNuRmsaArqvBnco(Integer nuRmsaArqvBnco) {
		this.nuRmsaArqvBnco = nuRmsaArqvBnco;
	}

    
}
