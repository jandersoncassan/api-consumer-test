package br.com.cielo.credenciamento.crd.service.osb.impl;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.inject.Inject;
import javax.inject.Named;
import javax.xml.rpc.ServiceException;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType;
import br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType;
import br.com.cielo.credenciamento.crd.service.osb.IServicesCredenciamento;
import br.com.cielo.credenciamento.crd.util.CrdFileUtil;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.DesbloqueioMobile;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoCliente;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoRequest;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoResponse;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteService;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteServiceLocator;
import br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException;
import br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobile;
import br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobileService;
import br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobileServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarCliente;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarClienteService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarClienteServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;

/**
 * Classe responsavel pela implementação dos serviços envolvendo o OSB
 * 
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Named
public class ServicesCredenciamentoImpl implements IServicesCredenciamento {

	@Inject
	private CrdFileUtil crdFileUtil;

	/**
	 * Método responsavel por popular as informações de autenticação do servico
	 * SOAP exposto no OSB
	 * 
	 * @return CieloSoapHeaderType
	 */
	private CieloSoapHeaderType buildHeader() {
		UsuarioType user = new UsuarioType();
		user.setId(crdFileUtil.getMessage(CrdUtils.HEADER_USER));
		user.setSenha(crdFileUtil.getMessage(CrdUtils.HEADER_PASS));

		CieloSoapHeaderType header = new CieloSoapHeaderType();
		header.setUsuario(user);
		return header;
	}

	/**
	 * Método responsavel pela inclusão da proposta de credenciamento no CRD
	 * (RL01) via OSB
	 * 
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws RemoteException
	 */
	@Override
	public CredenciarClienteResponse credenciarClienteOSB(CredenciarClienteRequest request)
			throws MalformedURLException, ServiceException, Fault, RemoteException {

		Credenciamento_CredenciarClienteService ws = new Credenciamento_CredenciarClienteServiceLocator();
		Credenciamento_CredenciarCliente service = ws.getCredenciamento_CredenciarClienteServiceSoapPort(
				new URL(crdFileUtil.getMessage(CrdUtils.ENDPOINT_CREDENCIAR_CLIENTE_OSB)));
		CrdUtils.deflate("CREDENCIAMENTO VIA OSB", request);
		CredenciarClienteResponse response = service.credenciarCliente(request, buildHeader());

		return response;
	}

	/**
	 * Método responsavel pela inclusão da proposta de credenciamento no CRD
	 * (RL01) via CRD
	 * 
	 * @return
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws SOAPException
	 * @throws RemoteException
	 */
	@Override
	public CredenciamentoResponse credenciarClienteCRD(CredenciamentoRequest request)
			throws MalformedURLException, ServiceException, SOAPException, RemoteException {

		CredenciarClienteService ws = new CredenciarClienteServiceLocator();
		CredenciamentoCliente service = ws
				.getCredenciarCliente(new URL(crdFileUtil.getMessage(CrdUtils.ENDPOINT_CREDENCIAR_CLIENTE_CRD)));
		CrdUtils.deflate("CREDENCIAMENTO VIA CRD", request);
		CredenciamentoResponse response = service.credenciarCliente(request);

		return response;
	}

	/**
	 * Método responsavel por efetivar o desbloqueio mobile
	 * 
	 * @throws ServiceException
	 * @throws RemoteException
	 * @throws MalformedURLException
	 */
	@Override
	public void efetivarDesbloqueioMobile(DesbloqueioMobile infoDesbloqueio)
			throws ServiceException, RemoteException, MalformedURLException {
		
		CadastrarDesbloqueioMobileService ws = new CadastrarDesbloqueioMobileServiceLocator();
		CadastrarDesbloqueioMobile service = ws.getCadastrarDesbloqueioMobilePort(
				new URL(crdFileUtil.getMessage(CrdUtils.ENDPOINT_DESBLOQUEIO_MOBILE)));
		
		service.cadastrarDesbloqueioMobile(infoDesbloqueio.getCodigoEstabelecimento(),
				infoDesbloqueio.getCodigoTerminal(), CrdUtils.dateToString(infoDesbloqueio.getData()));
	}

}
