package br.com.cielo.credenciamento.crd.service.impl;

import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.exception.CredenciarClienteException;
import br.com.cielo.credenciamento.crd.service.IValidacaoInfoPropostaService;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.annotation.FieldInfoCrd;
import br.com.cielo.credenciamento.ejb.domain.batch.Banco;
import br.com.cielo.credenciamento.ejb.domain.batch.Endereco;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;

/**
 * Classe responsavel pela implementação do tratamento de tipagem dos campos e
 * regras de TP
 * 
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class ValidacaoInfoPropostaServiceImpl implements IValidacaoInfoPropostaService {

	private static final Logger LOG = LoggerFactory.getLogger(ValidacaoInfoPropostaServiceImpl.class);

    private static final String REGEX_TP = "(TP)((0[1-9]{1})|[1-9]{1}|(LZ)|(LW)|(L2)|(WF)|(ZX)|(ZY))";    										
    
    private static final String TP_DEFAULT = "TP1";

	@Override
	public void tratarTipagemCampos(final Prospect prospect) {		
		LOG.info("INIT - TRATAMENTO TIPAGEM DOS CAMPOS");
		try {
			initTratarTipagem(prospect);
			
		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO TRATAR A TIPAGEM DOS CAMPOS DO PROSPECT {}", ex);
			throw new CredenciarClienteException("Erro tratamento de tipagem", ex);
		}
	}

	/**
	 * 
	 * @param prospect
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private void initTratarTipagem(final Prospect prospect) throws IllegalArgumentException, IllegalAccessException {
		Field[] fields = prospect.getClass().getDeclaredFields();
		for (Field field : fields) {
			Type type = field.getGenericType();
			
			if(isAssignableFrom(field.getType())){//TRATAR  ENDERECO && BANCO
				field.setAccessible(true);
				Object obj = field.get(prospect);
				tratarField(obj);

			}else if(isParameterizedType(type)){//LISTA PROPRIETARIOS && LISTA TELEFONES
					 field.setAccessible(true);
					 List<Object> listObject = (java.util.List) field.get(prospect);
				     for(Object obj : listObject){
				    	 tratarField(obj);
				     }
			}else{//TRATAR TIPAGEM CAMPOS
					tratarTipagemField(field, prospect);
			}
		}		
	}

	/**
	 * Método responsavel pela tipagem dos campos
	 * @param obj
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void tratarField(final Object obj) throws IllegalArgumentException, IllegalAccessException {
		Field[] typeFields = obj.getClass().getDeclaredFields();
		 for (Field typeField : typeFields) {	
			 tratarTipagemField(typeField, obj);
		}
	}

	/**
	 * Tratar objeto Endereco e Banco
	 * @param clazz
	 * @return
	 */
	private static boolean isAssignableFrom(final Class<?> clazz){
		return (clazz.isAssignableFrom(Endereco.class) || clazz.isAssignableFrom(Banco.class));
	}

	/**
	 * Tratar objeto List
	 * @param type
	 * @return
	 */
	private static boolean isParameterizedType(final Type type){
		return (type instanceof ParameterizedType);
	}

	/**
	 * Método responsavel por consistir a tipagem dos campos
	 * 
	 * @param field
	 * @param fieldCrd
	 * @param prospect
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 */
	private void tratarTipagemField(final Field field, final Object prospect) throws IllegalArgumentException, IllegalAccessException {

		field.setAccessible(true);
		FieldInfoCrd fieldCrd = field.getAnnotation(FieldInfoCrd.class);
		if (null != fieldCrd) {
			String info = (String) field.get(prospect);
			String tipo = fieldCrd.tipo();
			info = info != null ? info.trim() : info;
			tratarTipagem(tipo, info, field, prospect);
		}
	}

	/**
	 * Método responsavel por tratar o tipo de informação de prospect
	 * @param tipo
	 * @param info
	 * @param field
	 * @param prospect
	 * @throws IllegalArgumentException
	 * @throws IllegalAccessException
	 */
	private void tratarTipagem(final String tipo, final String info, final Field field, final Object prospect)
			throws IllegalArgumentException, IllegalAccessException {
		if (tipo.equals(CrdUtils.NUMERICO)) {
			if (!CrdUtils.isNumber(info)) {
				field.set(prospect, String.valueOf(CrdUtils.VALOR_NUMERICO_ZERO));
			}
		}
	}

	@Override
	public void tratarTipoProcessamento(final Prospect prospect) {
		LOG.info("INIT - TRATAMENTO TIPO DE PROCESSAMENTO (TP)");
		try{
			initTratarTipoProcessamento(prospect);

		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO AO TRATAR O TIPO DE PROCESSAMENTO (TP) {}", ex);
			throw new CredenciarClienteException("Erro no tratamento de TP", ex);
		}
	}

	/**
	 * Método responsavel por efetuar as consistencias do tipo de processamento
	 * @param prospect
	 */
	private void initTratarTipoProcessamento(final Prospect prospect) {
		prospect.setLayoutNovo(CrdUtils.isLayoutNovo(prospect.getCodTipoPlano(), prospect.getSolucaoCaptura()));
		
		if(prospect.isLayoutNovo()){
			LOG.info("LAYOUT NOVO - UTILIZAMOS OS CAMPOS DO PROPRIO LAYOUT");
		}else{
			LOG.info("LAYOUT ATUAL - NECESSARIO EFETUAR O TRATAMENTO DE TP");
			List<String> listaTP = tratarTipoTP(prospect);
			tratarCodigoTP(listaTP, prospect);
		}		
	}

	/**
	 * Tratamos o 1º TP válido e limpamos todos os TPs 'validos' da String Pessoa Contato
	 * @param listaTP
	 */
	private void tratarCodigoTP(final List<String> listaTP, final Prospect prospect) {		
		String tpValido = listaTP.isEmpty() ? TP_DEFAULT : listaTP.get(0);
		//EFETUA AS CONSISTÊNCIAS E POPULA OS CAMPOS NO PROSPECT
		tratarCamposTp(getValoresCamposTP(tpValido), prospect);
		//RETIRA AS INFORMAÇÕES DE TP DO CAMPO CONTATO
		limparInfoTpContato(listaTP, prospect);
	}

	/**
	 * Método responsavel por retirar as informações de TP do campo contato
	 * @param listaTP
	 * @param prospect
	 */
	private void limparInfoTpContato(final List<String> listaTP, final Prospect prospect) {
		for (String infoTp : listaTP) {
			prospect.setPessoaContato(prospect.getPessoaContato().replace(infoTp, ""));
		}		
	}

	/**
	 * Método responsavel por popular os campos do layout atual de acordo com o TP
	 * @param valoresCamposTP
	 * @param prospect
	 */
	private void tratarCamposTp(final String[] valoresCamposTP, final Prospect prospect) {
		prospect.setCodTipoPlano(valoresCamposTP[0]);
		prospect.setValorFaturamento(valoresCamposTP[1]);
		prospect.setQtdadeDiasLiquidacao(valoresCamposTP[2]);
		prospect.setIndicadorAgro(valoresCamposTP[3]);
		prospect.setSolucaoCaptura(valoresCamposTP[4]);
	}

	/**
	 * Método responsavel pelo tratamento de TP
	 * @param prospect
	 */
	private List<String> tratarTipoTP(final Prospect prospect) {
		Pattern pattern = Pattern.compile(REGEX_TP);
		Matcher matcher = pattern.matcher(prospect.getPessoaContato());
		List<String> listaTP = new ArrayList<String>();
		while(matcher.find()){
			listaTP.add(matcher.group());
		}
		return listaTP;
	}

	/**
	 * Método auxiliar para popular os campos de acordo com o tipo de TP
	 * @param codigoTp
	 * @return String[], valores fixos a serem populados no prospect
	 */
	private String[] getValoresCamposTP(final String codigoTp){
		LOG.info("TP VALIDO {}", codigoTp);
		Map <String, String[]> valoresCampos = new HashMap<>();
		//CÓDIGO DO PLANO CIELO,VALOR DE FATURAMENTO (0.00),QTDE DE DIAS LIQUIDAÇÃO,IND. AGRO,CÓDIGO DA SOLUÇÃO DE CAPTURA,DESCRIÇÃO SOLUÇÃO
		valoresCampos.put("TP01",new String[]{"1","0","0","N","1","POS MOVEL"});
		valoresCampos.put("TP02",new String[]{"1","0","0","N","2","POS MOVEL"});
		valoresCampos.put("TP03",new String[]{"1","0","0","N","18","MOBILE"});
		valoresCampos.put("TP04",new String[]{"1","0","0","S","1","POS MOVEL"});
		valoresCampos.put("TP05",new String[]{"1","0","0","N","21","LIO Basic"});
		valoresCampos.put("TP06",new String[]{"2","1000","30","N","1","POS Móvel"});
		valoresCampos.put("TP07",new String[]{"2","1000","2","N","1","POS Móvel"});
		valoresCampos.put("TP08",new String[]{"2","2000","30","N","1","POS Móvel"});
		valoresCampos.put("TP09",new String[]{"2","1000","2","N","1","POS Móvel"});
		valoresCampos.put("TP1",new String[]{"1","0","0","N","1","POS MOVEL"});
		valoresCampos.put("TP2",new String[]{"1","0","0","N","2","POS MOVEL"});
		valoresCampos.put("TP3",new String[]{"1","0","0","N","18","MOBILE"});
		valoresCampos.put("TP4",new String[]{"1","0","0","S","1","POS MOVEL"});
		valoresCampos.put("TP5",new String[]{"1","0","0","N","21","LIO Basic"});
		valoresCampos.put("TP6",new String[]{"2","1000","30","N","1","POS Móvel"});
		//valoresCampos.put("TP7",new String[]{"2","1000","2","N","1","POS Móvel"});
		valoresCampos.put("TP7",new String[]{"2","1000","2","N","26","Cielo ZIP"});//TRATAMENTO CIELO ZIP EVENTO FORCA VENDA MARKETING
		valoresCampos.put("TP8",new String[]{"2","2000","30","N","1","POS Móvel"});
		//valoresCampos.put("TP9",new String[]{"2","1000","2","N","1","POS Móvel"});
		valoresCampos.put("TP9",new String[]{"2","2000","2","N","26","Cielo ZIP"});//TRATAMENTO CIELO ZIP EVENTO FORCA VENDA MARKETING
		valoresCampos.put("TPLZ",new String[]{"1","0","0","N","22","LIO Plus"});
		valoresCampos.put("TPLW",new String[]{"1","0","0","N","23","LIO Basic V2"});
		valoresCampos.put("TPL2",new String[]{"1","0","0","N","24","LIO Plus V2"});
		valoresCampos.put("TPWF",new String[]{"1","0","0","N","25","POS Wi Fi"});
		valoresCampos.put("TPZX",new String[]{"2","500","30","N","1","POS Móvel"});
		//valoresCampos.put("TPZY",new String[]{"2","500","2","N","1","POS Móvel"});
		valoresCampos.put("TPZY",new String[]{"2","500","2","N","26","Cielo ZIP"});//TRATAMENTO CIELO ZIP EVENTO FORCA VENDA MARKETING
		
		return valoresCampos.get(codigoTp);
	}
}
