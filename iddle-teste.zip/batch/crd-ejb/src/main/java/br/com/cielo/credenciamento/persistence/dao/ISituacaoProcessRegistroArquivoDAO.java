package br.com.cielo.credenciamento.persistence.dao;

import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.SituacaoProcessRegistroArquivo;

/**
 * Interface responsavel pelas consistencias envolvendo a situação de processamento do registro
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface ISituacaoProcessRegistroArquivoDAO extends IOperations<SituacaoProcessRegistroArquivo> {

}
