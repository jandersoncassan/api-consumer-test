package br.com.cielo.credenciamento.crd.service.impl;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.enun.SitProcRegistroArquivoEnum;
import br.com.cielo.credenciamento.crd.enun.StatusCredenciamento;
import br.com.cielo.credenciamento.crd.exception.CredenciarClienteException;
import br.com.cielo.credenciamento.crd.service.IConsistenciasInfoCrdService;
import br.com.cielo.credenciamento.crd.service.osb.IServicesCredenciamento;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.Proprietario;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.domain.batch.Telefone;
import br.com.cielo.credenciamento.model.Critica;
import br.com.cielo.credenciamento.model.Criticas;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CampoCriticaType;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoRequest;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoResponse;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CriticaPropostaType;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DadosProprietarioType;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DomicilioBancarioType;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EnderecoType;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType;
import br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.TelefoneType;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.ISituacaoProcessRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivoPK;

/**
 * Classe responsavel por popular as informações da request na chamado do serviço OSB
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class ConsistenciasInfoCrdServiceImpl implements IConsistenciasInfoCrdService{

	private static final Logger LOG = LoggerFactory.getLogger(ConsistenciasInfoCrdServiceImpl.class);

	@Inject
	private IServicesCredenciamento servicesCredenciamento;
	
	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroArquivoDAO;
	
    @Inject
    private ISituacaoProcessRegistroArquivoDAO sitProcRegArquivoDAO;

    private Criticas criticas;
    
	//DOMINIOS 
	private final Integer FERRAMENTA_BANCOS = 2;	
	private final Integer TELEFONE_COMERCIAL = 2;
	private final Integer TELEFONE_CELULAR = 3;	
	private final Integer ENDERECO_COMERCIAL = 2;
	private final Integer ENDERECO_CORRESPONDECIA = 3;

	@Override
	public void efetivarCredenciamentoCRD(Prospect proposta, Criticas criticas) {
		LOG.info("INIT - CREDENCIAMENTO VIA SERVICO CRD - Contingencia (RL01)");
		try{
			CredenciamentoRequest request = popularRequest(proposta);
			CredenciamentoResponse response = efetivarCredenciamento(request);
			//LISTA DE CRITICAS "DE/PARA" SEC LAYOUT DE BANCOS
			this.criticas = criticas;
			tratarCredenciamentoResponse(proposta, response);
			
		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO AO CREDENCIAR VIA SERVICO CRD - Contingencia (RL01) {}", ex);
			throw new CredenciarClienteException("ERRO CREDENCIAER CLIENTE", ex);
		}
	}

	/**
	 * Método responsavel pela efetivação do credenciamento
	 * @param request
	 * @return 
	 */
	private CredenciamentoResponse efetivarCredenciamento(CredenciamentoRequest request) {
		try {
			return servicesCredenciamento.credenciarClienteCRD(request);
			
		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO TRATAR A TIPAGEM DOS CAMPOS DO PROSPECT {}", ex);
			throw new RuntimeException("ERRO CHAMADA SERVICO CREDENCIAMENTO", ex);
		}		
	}

	/**
	 * Método responsavel por popular as informações de request para chamada do serviço
	 * @param proposta
	 * @return 
	 */
	private CredenciamentoRequest popularRequest(final Prospect proposta) {
		CredenciamentoRequest request = new CredenciamentoRequest();
		request.setCodigoFerramenta(FERRAMENTA_BANCOS); 
		request.setCorraletionID(proposta.getCorrelationId());
		request.setIndicadorAgro(proposta.getIndicadorAgro());
		//POPULAR AS INFORMACOES DE ESTABELECIMENTO COMERCIAL
		popularEstabelecimentoComercial(request, proposta);
		//POPULAR AS INFORMACOES DE SOLUCAO DE CAPTURA
		popularSolucoesCaptura(request, proposta);		
		return request;		
	}
	
	/**
	 * Método responsavel por pouplar as informações de estabelecimento comercial
	 * @param request
	 * @param proposta
	 */
	private void popularEstabelecimentoComercial(CredenciamentoRequest request, Prospect proposta) {
		EstabelecimentoComercialType estabelecimento = new EstabelecimentoComercialType();
		
		estabelecimento.setNumeroCpfCnpj(Long.valueOf(proposta.getCpfCnpj()));
		estabelecimento.setTipoPessoa(proposta.getTipoPessoa());
		estabelecimento.setNumeroEc(Long.valueOf(proposta.getNumeroEstabelecimento()));//OPCIONAL
		estabelecimento.setNomeRazaoSocial(proposta.getRazaoSocial());
		estabelecimento.setIndicadorMei(proposta.getMei());
		estabelecimento.setNumeroInscricaoEstadual(Long.valueOf(proposta.getInscricaoEstadual()));
		estabelecimento.setNomeFantasia(proposta.getNomeFantasia());
		estabelecimento.setNomePlaqueta(proposta.getNomePlaqueta());
		estabelecimento.setNomePessoaContato(proposta.getPessoaContato());
		estabelecimento.setEmail(proposta.getEmail());
		estabelecimento.setCodigoRamoAtividade(Integer.valueOf(proposta.getRamoAtividade()));
		estabelecimento.setValorFatMedioMensal(BigDecimal.valueOf(Long.valueOf(proposta.getValorFaturamento())));
		estabelecimento.setCodigoAfiliador(0l);//OPCIONAL
		estabelecimento.setIndEstabComercialMigrado("N");//OPCIONAL
		estabelecimento.setIndCadastroDuplicado("N");//OPCIONAL
		estabelecimento.setDataAtivacaoEstabComercial(null);//OPCIONAL
		estabelecimento.setCodigoTipoPlanoCielo(Integer.valueOf(proposta.getCodTipoPlano()));
		estabelecimento.setQuantidadeDiasLiquidacao(Integer.valueOf(proposta.getQtdadeDiasLiquidacao()));
		//POPULAR DOMICILIO BANCARIO
		popularDomicilioBancario(estabelecimento, proposta);
		//POPULAR TELEFONES
		popularTelefones(estabelecimento, proposta);
		//POPULAR ENDERECOS
		popularEnderecos(estabelecimento, proposta);
		//POPULAR INFORMACOES DE PROPRIETARIOS
		popularProprietarios(estabelecimento, proposta);		
		request.setEstabelecimentoComercial(estabelecimento);
		
	}

	/**
	 * Método responsavel por popular as informações de Domicilio Bancario
	 * @param estabelecimento
	 * @param proposta
	 */
	private void popularDomicilioBancario(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		List<DomicilioBancarioType> listaDomicilio = new ArrayList<DomicilioBancarioType>();		

		DomicilioBancarioType domicilio = new DomicilioBancarioType();
		domicilio.setCodigoBanco(proposta.getBanco());
		domicilio.setNumeroAgencia(Integer.valueOf(proposta.getDadosBancarios().getCodigoAgencia()).toString());
		domicilio.setNumeroConta(proposta.getDadosBancarios().getNumeroContaCorrente());
		domicilio.setTipoConta(proposta.getTipoConta());
		listaDomicilio.add(domicilio);
		
		DomicilioBancarioType[] domiciliosArray = new DomicilioBancarioType[listaDomicilio.size()];
		estabelecimento.setDomiciliosBancarios(listaDomicilio.toArray(domiciliosArray));
	}
	
	/**
	 * Método responsavel por popular as informações de telefones
	 * @param estabelecimento
	 * @param proposta
	 */
	private void popularTelefones(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		List<TelefoneType> listaTelefones = new ArrayList<TelefoneType>();
		Integer tipoTelefone = TELEFONE_COMERCIAL;
		for (Telefone telefone : proposta.getTelefones()) {
			//TELEFONE COMERCIAL AND CELULAR
			TelefoneType telefoneType = new TelefoneType();
			telefoneType.setCodigoTipoTelefone(tipoTelefone); //COMERCIAL
			telefoneType.setNumeroDdd(Integer.valueOf(telefone.getDdd()));
			telefoneType.setNumeroTelefone(telefone.getNumero());
			listaTelefones.add(telefoneType);
			tipoTelefone = TELEFONE_CELULAR;			
		}
		
		TelefoneType[] telefonesArray = new TelefoneType[listaTelefones.size()];
		estabelecimento.setTelefones(listaTelefones.toArray(telefonesArray));
	}

	/**
	 * Método responsavel por popular as informações de Endereço
	 * @param estabelecimento
	 * @param proposta
	 */
	private void popularEnderecos(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		List<EnderecoType> listaEnderecos = new ArrayList<EnderecoType>();
		//ENDERECO COMERCIAL
		EnderecoType enderecoComercial = new EnderecoType();		
		enderecoComercial.setCodigoTipoEndereco(ENDERECO_COMERCIAL);
		enderecoComercial.setLogradouro(proposta.getEnderecoEstabelecimento().getLogradouro());
		enderecoComercial.setComplemento(proposta.getEnderecoEstabelecimento().getComplementoLogradouro());
		enderecoComercial.setNumeroLogradouro(proposta.getNumEnderComercial());
		enderecoComercial.setCidade(proposta.getEnderecoEstabelecimento().getCidade());
		enderecoComercial.setBairro("");//OPCIONAL NAO EXISTE NO LAYOUT DE BANCOS
		enderecoComercial.setSiglaEstado(proposta.getEnderecoEstabelecimento().getEstado());
		enderecoComercial.setNumeroCep(Integer.valueOf(proposta.getEnderecoEstabelecimento().getCep()));
		listaEnderecos.add(enderecoComercial);
		//ENDERECO CORRESPONDENCIA
		EnderecoType enderecoCorrespondecia = new EnderecoType();		
		enderecoCorrespondecia.setCodigoTipoEndereco(ENDERECO_CORRESPONDECIA);
		enderecoCorrespondecia.setLogradouro(proposta.getEnderecoCorrespondencia().getLogradouro());
		enderecoCorrespondecia.setComplemento(proposta.getEnderecoCorrespondencia().getComplementoLogradouro());
		enderecoCorrespondecia.setNumeroLogradouro(proposta.getNumEnderCorrespondecia());
		enderecoCorrespondecia.setCidade(proposta.getEnderecoCorrespondencia().getCidade());
		enderecoCorrespondecia.setBairro("");//OPCIONAL NAO EXISTE NO LAYOUT DE BANCOS
		enderecoCorrespondecia.setSiglaEstado(proposta.getEnderecoCorrespondencia().getEstado());
		enderecoCorrespondecia.setNumeroCep(Integer.valueOf(proposta.getEnderecoCorrespondencia().getCep()));
		listaEnderecos.add(enderecoCorrespondecia);
	
		EnderecoType[] enderecosArray = new EnderecoType[listaEnderecos.size()];
		estabelecimento.setEnderecos(listaEnderecos.toArray(enderecosArray));
	}
	
	/**
	 * Método responsavel por popular as informações de proprietários
	 * @param estabelecimento
	 * @param proposta
	 */
	private void popularProprietarios(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		List<DadosProprietarioType> listaProprietarios = new ArrayList<DadosProprietarioType>();
		for (Proprietario proprietario : proposta.getProprietarios()) {
			DadosProprietarioType proprietarioType = new DadosProprietarioType();
			proprietarioType.setNome(proprietario.getNomeProprietario());
			proprietarioType.setNumeroCpf(proprietario.getCpfProprietario());
			proprietarioType.setDataNascimento(tratarDataNascimento(proprietario.getDataNascimentoProprietario()));
			listaProprietarios.add(proprietarioType);
		}
		
		DadosProprietarioType[] proprietariosArray = new DadosProprietarioType[listaProprietarios.size()];
		estabelecimento.setProprietarios(listaProprietarios.toArray(proprietariosArray));
	}

	
	/**
	 * Método responsavel por popular as informações de solução de captura
	 * @param request
	 * @param proposta
	 */
	private void popularSolucoesCaptura(CredenciamentoRequest request, Prospect proposta) {
		List<SolucaoCapturaType> listaSolucoes = new ArrayList<SolucaoCapturaType>();		
		SolucaoCapturaType solucao = new SolucaoCapturaType();
		solucao.setCodigoSolucaoCaptura(Integer.valueOf(proposta.getSolucaoCaptura()));
		solucao.setQuantidadeEquipamentos(1);
		solucao.setCodigoPacoteEcommerce(proposta.getCodPacoteEcommerce());
		listaSolucoes.add(solucao);
		
		SolucaoCapturaType[] solucoesArray = new SolucaoCapturaType[listaSolucoes.size()];
		request.setSolucoes(listaSolucoes.toArray(solucoesArray));
	}

	/**
	 * Método responsavel por tratar a data de nascimento
	 * @param dataNascimento
	 * @return
	 */
	private Calendar tratarDataNascimento(String dataNascimento){		
		if(!CrdUtils.isNumberAndNotZeros(dataNascimento)){
			dataNascimento =  "010101";
		}
		try {
			Calendar calendar = Calendar.getInstance();
			SimpleDateFormat dateFormat = new SimpleDateFormat("ddMMyy");
			calendar.setTime(dateFormat.parse(dataNascimento));
			return calendar;
		} catch (ParseException e) {
			return null;
		}
	}
	
	/**
	 * Método responsavel por tratar o retorno da chamada do serviço de credenciamento RL01
	 * @param proposta 
	 * @param response
	 */
	private void tratarCredenciamentoResponse(Prospect proposta, CredenciamentoResponse response) {

		String codigoStatus = response.getCodigoStatus();
		proposta.setNumeroProposta(response.getNumeroProposta().toString());
		
		if(codigoStatus.equals(StatusCredenciamento.SUCESSO.getCodigo())){
			String numeroEc = response.getNumeroEc().toString();
			proposta.setNumeroEstabelecimento(response.getNumeroEc().toString());
			atualizarPropostaSucesso(proposta.getCorrelationId(), numeroEc);
		
		}else if(codigoStatus.equals(StatusCredenciamento.REJEITADA.getCodigo())){
			atualizarPropostaRejeitada(proposta.getCorrelationId(), response.getListaCriticas());
			
		}else if(codigoStatus.equals(StatusCredenciamento.REJEITADA_FALHA_SISTEMICA.getCodigo())){
			atualizarPropostaError(proposta.getCorrelationId());
		}
	}
	

	/**
	 * Método responsavel por atualizar o status da proposta na tabela wrk (2-Em processamento --> 4-Acatado)
	 * @param correlation
	 */
	private void atualizarPropostaSucesso(String correlationId, String numeroEc){
		ProcessamentoRegistroArquivo entity = getProspect(correlationId);
		entity.setNuEc(numeroEc);		
		entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.ACATADO.getCodigoSituacaoProposta()));
	}
	
	/**
	 * Método responsavel por atualizar as informações de criticas no prospect
	 * @param correlationId
	 * @param criticasType
	 * @param criticas
	 */
	private void atualizarPropostaRejeitada(String correlationId, CriticaPropostaType[] criticasType){
		ProcessamentoRegistroArquivo entity = getProspect(correlationId);
		entity.setCdErroVldcArqv(CrdUtils.PROPOSTA_REJEITADA);
		entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.REJEITADO.getCodigoSituacaoProposta()));

		List<Critica> listaCriticas = new ArrayList<>();
		for (CriticaPropostaType critica : Arrays.asList(criticasType)) {			
			for(CampoCriticaType campo : critica.getListaCampos()){
				listaCriticas.add(CrdUtils.getCriticasSec(criticas, critica.getCodigoCritica(), Integer.valueOf(campo.getReferenciaSequenciaCampo())));
			}
		}

		CrdUtils.popularCriticas(entity, listaCriticas);		
	}
	
	/**
	 * Método responsavel por atualizar as porpostas que foram rejeitadas por falha sistemica
	 * @param correlationId
	 */
	private void atualizarPropostaError(String correlationId) {
		ProcessamentoRegistroArquivo entity = getProspect(correlationId);
		entity.setCdErroVldcArqv(CrdUtils.PROPOSTA_FALHA_SISTEMICA);
		entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.FALHA_SISTEMICA.getCodigoSituacaoProposta()));
	}
	

	
	/**
	 * Método responsavel por obter a entidade de prospect
	 * @param correlationId
	 * @return
	 */
	private ProcessamentoRegistroArquivo getProspect(String correlationId){
		String[] infoCorrelation = getInfoCorrelation(correlationId);
		ProcessamentoRegistroArquivoPK pk = popularInfoProspectPk(infoCorrelation);
		return (procRegistroArquivoDAO.findById(pk));
	}

	/**
	 * Método responsavel pelo parse do correlation ID
	 * @param correlationId
	 * @return
	 */
	private String[] getInfoCorrelation(String correlationId){
		return correlationId.split(";");
	}
	
	/**
	 * Método responsavel por popular as informações na entidade de complemento proposta
	 * @param infoProposta
	 * @param numeroProposta 
	 * @return 
	 */
	private ProcessamentoRegistroArquivoPK popularInfoProspectPk(String[] correlationId) {
		ProcessamentoRegistroArquivoPK pk = new ProcessamentoRegistroArquivoPK();
		pk.setCdBnco(Integer.valueOf(correlationId[CrdUtils.INDEX_BANCO]));
		pk.setDtMvmnArqvBnco(CrdUtils.getDataMovimento(correlationId[CrdUtils.INDEX_DATA_MOVIMENTO]));
		pk.setNuRmsaArqvBnco(Integer.valueOf(correlationId[CrdUtils.INDEX_REMESSA]));
		pk.setNuLnhaRgstArqvBnco(Integer.valueOf(correlationId[CrdUtils.INDEX_LINHA]));		
		return pk;
	}

}
