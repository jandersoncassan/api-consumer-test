package br.com.cielo.credenciamento.crd.exception;

import javax.ejb.ApplicationException;

/**
 * Classe Exception para tratamento de exceções ocorreido no processamento do arquivo
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@ApplicationException(rollback=false)
public class CredenciarClienteException extends RuntimeException{

	private static final long serialVersionUID = 1L;
	
	public CredenciarClienteException(Throwable cause){
		super(cause);
	}
	
	public CredenciarClienteException(String message){
		super(message);
	}
	
	public CredenciarClienteException( String message, Throwable cause){
		super(message, cause);
	}
}
