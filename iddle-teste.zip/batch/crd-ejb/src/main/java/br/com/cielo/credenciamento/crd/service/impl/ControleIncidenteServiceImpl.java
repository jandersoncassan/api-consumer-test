package br.com.cielo.credenciamento.crd.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.enun.SitProcRegistroArquivoEnum;
import br.com.cielo.credenciamento.crd.exception.CredenciarClienteException;
import br.com.cielo.credenciamento.crd.service.IControleIncidenteService;
import br.com.cielo.credenciamento.crd.service.ICredenciamentoService;
import br.com.cielo.credenciamento.crd.service.ICredenciarClienteService;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.remote.IControleIncidenteServiceRemote;
import br.com.cielo.credenciamento.model.Critica;
import br.com.cielo.credenciamento.model.IncidenteProposta;
import br.com.cielo.credenciamento.persistence.dao.IComplementoPropostaDAO;
import br.com.cielo.credenciamento.persistence.dao.IControleIncidenteDAO;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.ISituacaoProcessRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.entity.ComplementoProposta;
import br.com.cielo.credenciamento.persistence.entity.ControleIncidentesProcess;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivoPK;

/**
 * @author Autor
 */
@Stateless(name = "ControleIncidenteService", mappedName = "ControleIncidenteService")
public class ControleIncidenteServiceImpl implements IControleIncidenteService, IControleIncidenteServiceRemote {

	private static final Logger LOG = LoggerFactory.getLogger(ControleIncidenteServiceImpl.class);

	@Inject
	private IControleIncidenteDAO controleIncidenteDAO;

	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroArquivoDAO;

	@Inject
	private IComplementoPropostaDAO complementoPropostaDAO;
	
	@Inject
	private ICredenciamentoService credenciamentoService;

	@Inject
	private ICredenciarClienteService credenciarClienteService;
	
    @Inject
    private ISituacaoProcessRegistroArquivoDAO sitProcRegArquivoDAO;


	@Override
	public void incluirIncidente(Incidente incidente) {
		LOG.info("INIT INCLUIR INCIDENTE, CODIGO ");
		try {
			initIncluirIncidente(incidente);

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO NO PROCESSO INCLUSAO DE INCIDENTE {}", ex);
			throw new CredenciarClienteException("ERRO INCLUSAO INCIDENTE", ex);
		}
	}

	/**
	 * Método responsavel pela inclusão de incidente na base de dados
	 * 
	 * @param incidente
	 * @param correlationId
	 */
	private void initIncluirIncidente(Incidente incidente) {
		ControleIncidentesProcess entity = popularInfoIncidente(incidente);
		controleIncidenteDAO.create(entity);
	}

	/**
	 * Método responsavel por popular as informações do Incidente
	 * 
	 * @param incidente
	 */
	private ControleIncidentesProcess popularInfoIncidente(Incidente incidente) {

		ProcessamentoRegistroArquivoPK pk = popularPkProspect(incidente);
		ProcessamentoRegistroArquivo entityRgst = getEntityRegistro(pk);

		ControleIncidentesProcess entity = new ControleIncidentesProcess();
		entity.setTbcrdwPcsmRgstCdstAtul(entityRgst);
		entity.setCauseException(incidente.getDescricaoErro());
		entity.setCdUsroInclRgst("CRDUSR");
		entity.setDhInclRgst(new Date());
		entity.setFlagControle("N"); // FIXO 'N' AO CRIAR

		return entity;
	}

	/**
	 * Método responsavel por persistir registro de incidente na base de dados
	 * 
	 * @param correlationId
	 * @return
	 */
	private ProcessamentoRegistroArquivoPK popularPkProspect(Incidente incidente) {
		ProcessamentoRegistroArquivoPK pk = new ProcessamentoRegistroArquivoPK();
		pk.setCdBnco(incidente.getCodigoBanco());
		pk.setDtMvmnArqvBnco(incidente.getDataMovimento());
		pk.setNuRmsaArqvBnco(incidente.getNumeroRemessa());
		pk.setNuLnhaRgstArqvBnco(incidente.getNumeroLinha());
		return pk;
	}


	@Override
	public List<Incidente> obterListaIncidente() {
		List<Incidente> listaIncidentes = new ArrayList<>();

		List<Long> listaEntidade = controleIncidenteDAO.obterListaIncidentes();
		for (Long codigoIncidente : listaEntidade) {
			listaIncidentes.add(getIncidente(codigoIncidente));
		}
		return listaIncidentes;
	}
	
	@Override
	public Incidente findIncidente(String codigoIncidente) {
		return getIncidente(Long.valueOf(codigoIncidente));
	}

	/**
	 * Método responsavel por popular o objeto incidente
	 * @param codigoIncidente
	 * @return
	 */
	private Incidente getIncidente(Long codigoIncidente){
		ControleIncidentesProcess entity = controleIncidenteDAO.findIncidente(codigoIncidente);
		return (null != entity ? popularIncidente(entity) : null);		
	}
	
	/**
	 * Método responsavel por popular as informações de incidente
	 * 
	 * @param entity
	 * @return
	 */
	private Incidente popularIncidente(ControleIncidentesProcess entity) {
		entity.setFlagControle("S"); // FIXO 'S' AO RETOMAR
		Incidente incidente = new Incidente();
		incidente.setCodigoBanco(entity.getTbcrdwPcsmRgstCdstAtul().getId().getCdBnco());
		incidente.setDataMovimento(entity.getTbcrdwPcsmRgstCdstAtul().getId().getDtMvmnArqvBnco());
		incidente.setNumeroRemessa(entity.getTbcrdwPcsmRgstCdstAtul().getId().getNuRmsaArqvBnco());
		incidente.setNumeroLinha(entity.getTbcrdwPcsmRgstCdstAtul().getId().getNuLnhaRgstArqvBnco());
		incidente.setDescricaoErro(entity.getCauseException());
		incidente.setCodStatusProc(entity.getTbcrdwPcsmRgstCdstAtul().getSituacaoRegistro().getCodSituacao());
		return incidente;
	}

	@Override
	public void retomarIncidente(Incidente incidente) {
		LOG.info("INIT RETOMAR INCIDENTE {} ", incidente);
		try {
			initRetomarIncidente(incidente);

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO NO PROCESSO DE RETOMADA DE {}", ex);
			throw new CredenciarClienteException("ERRO RETOMADA INCIDENTE", ex);
		}

	}

	/**
	 * Método responsavel por iniciar a retomada dos incidentes
	 * @param incidentes
	 */
	private void initRetomarIncidente(Incidente incidente) {

			ComplementoProposta entityComplemento = complementoPropostaDAO.fyndByCorrelation(incidente.getCodigoBanco(), incidente.getDataMovimento(),
													 incidente.getNumeroRemessa(), incidente.getNumeroLinha());
			
			//BUSCAMOS AS INFORMAÇÕES DA PROPOSTA NA TABELA WRK
			ProcessamentoRegistroArquivoPK pkEntity = popularPkProspect(incidente);
			ProcessamentoRegistroArquivo entity = getEntityRegistro(pkEntity);

			if(null != entityComplemento){
				//EXISTE PROPOSTA
				
				List<Object[]> listaCriticas = controleIncidenteDAO.getListaCriticasProposta(entityComplemento.getNuPrpsCrdn());
				List<IncidenteProposta> listaCriticasProposta = popularCriticasProposta(listaCriticas);
				//SUCESSO
				if(isSucesso(listaCriticasProposta)){
					entity.setNuEc(StringUtils.leftPad(listaCriticasProposta.get(CrdUtils.NUM_ZERO).getNumeroEc(),CrdUtils.NUM_DEZ,CrdUtils.NUM_ZERO_S));
					entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.ACATADO.getCodigoSituacaoProposta()));
				//FALHA SISTEMICA
				}else if(isFalhaSistemica(listaCriticasProposta)){
					entity.setCdErroVldcArqv(CrdUtils.PROPOSTA_FALHA_SISTEMICA);
					entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.FALHA_SISTEMICA.getCodigoSituacaoProposta()));
				//REJEITADA
				}else{
					entity.setCdErroVldcArqv(CrdUtils.PROPOSTA_REJEITADA);
					entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.REJEITADO.getCodigoSituacaoProposta()));
					//TRATAMOS A LISTA DE CRITICAS DA PROPOSTA
					tratarCriticaProposta(entity, listaCriticasProposta);
				}
					
			}else{
				
				try{
					//NAO EXISTE PROPOSTA, PRECISAMOS MONTAR O PROSPECT E RETOMAR
					Prospect proposta = CrdUtils.popularEntityToProposta(entity);
					//EFETUAMOS O TRATAMENTO DE TIPAGEM E TP
					credenciamentoService.tratarProspectRetomada(proposta);
					//EFETIVAMOS O CREDENCIAMENTO 
					credenciarClienteService.credenciarCliente(proposta);

				}catch(Exception ex){
					//CASO OCORRA ERRO NA RETOMADA GERAMOS UM NOVO INCIDENTE
					initIncluirIncidente(incidente);
				}
			}
		}
	

	private void tratarCriticaProposta(ProcessamentoRegistroArquivo entity, List<IncidenteProposta> listaCriticasProposta) {
		List<Critica> listaCriticas = new ArrayList<>();
		for (IncidenteProposta incidenteProposta : listaCriticasProposta) {	
			if(incidenteProposta.getFlagRessalva().equals(CrdUtils.SEM_RESSALVA))
				listaCriticas.add(CrdUtils.getCriticasSec(credenciarClienteService.getListaCriticas(), incidenteProposta.getCodigoCritica().toString(), incidenteProposta.getSequenciaCampo()));
		}
		
		CrdUtils.popularCriticas(entity, listaCriticas);
	}
	


	/**
	 * Método responsavel por verificar se houve sucesso no credenciamento 
	 * ETAPA PRECADASTRO (18) COM STATUS SUCESSO (3)
	 * @param listaCriticasProposta
	 * @return
	 */
	private boolean isSucesso(List<IncidenteProposta> listaCriticasProposta) {
		for (IncidenteProposta incidenteProposta : listaCriticasProposta) {
			System.out.println(incidenteProposta.getCodigoEtapa());
			if(incidenteProposta.getCodigoEtapa().equals(CrdUtils.ETAPA_PRE_CADASTRO)){
				if(incidenteProposta.getCodSitEtapa().equals(CrdUtils.STATUS_SUCESSO)){
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Método responsavel por verificar se houve Falha Sistemica no processamento do arquivo
	 * CODIGO SITUACAO DA ETAPA (7) FALHA SISTEMICA
	 * @param listaCriticasProposta
	 * @return
	 */
	private boolean isFalhaSistemica(List<IncidenteProposta> listaCriticasProposta) {
		for (IncidenteProposta incidenteProposta : listaCriticasProposta) {
			if(incidenteProposta.getCodSitEtapa().equals(CrdUtils.STATUS_FALHA_SISTEMICA)){
					return true;
			}
		}
		return false;
	}

	/**
	 * Método responsavel por popular as informações das criticas
	 * @param listaCriticas
	 * @return
	 */
	private List<IncidenteProposta> popularCriticasProposta(List<Object[]> listaCriticas) {
		List<IncidenteProposta> listaCriticaProposta = new ArrayList<>();
		for (Object[] critica : listaCriticas) {
			IncidenteProposta incidenteProposta = new IncidenteProposta();
			incidenteProposta.setCodigoEtapa(Integer.valueOf(String.valueOf(critica[CrdUtils.COD_ETAPA])));
			incidenteProposta.setCodigoCritica(Integer.valueOf(String.valueOf(critica[CrdUtils.COD_CRITICA])));	 
			incidenteProposta.setCodSitEtapa(Integer.valueOf(String.valueOf(critica[CrdUtils.COD_SIT_ETAPA])));	 
			incidenteProposta.setCodTipoErroValidacao(Integer.valueOf(String.valueOf(critica[CrdUtils.COD_TIPO_ERRO])));	 
			incidenteProposta.setNumeroEc(String.valueOf(critica[CrdUtils.NUMERO_EC]));
			incidenteProposta.setSequenciaCampo(Integer.valueOf(String.valueOf(critica[CrdUtils.SEQ_CAMPO])));
			incidenteProposta.setFlagRessalva(critica[CrdUtils.FLAG_RESSALVA].toString());
			listaCriticaProposta.add(incidenteProposta);
		}
		return listaCriticaProposta;
	}
	
	/**
	 * Metodo responsavel por retornar a entity do registro na tabela wrk
	 * @param pk
	 * @return
	 */
	private ProcessamentoRegistroArquivo getEntityRegistro(ProcessamentoRegistroArquivoPK pk){
		return procRegistroArquivoDAO.findById(pk);
	}

}