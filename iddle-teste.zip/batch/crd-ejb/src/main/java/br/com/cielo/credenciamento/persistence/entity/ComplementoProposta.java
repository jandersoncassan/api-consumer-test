package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entidade representando a tabela de complemento da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDR_CMPM_PRPS_CRDN_BNCO", schema = "CRD")
public class ComplementoProposta implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "NU_PRPS_CRDN", unique = true, nullable = false)
    private Long nuPrpsCrdn;

    @Column(name = "CD_BNCO", nullable = false, precision = 3)
    private Integer cdBnco;

    @Temporal(TemporalType.DATE)
    @Column(name = "DT_MVMN_ARQV_BNCO", nullable = false)
    private Date dtMvmnArqvBnco;

    @Column(name = "NU_RMSA_ARQV_BNCO", nullable = false, precision = 3)
    private Integer nuRmsaArqvBnco;

    @Column(name = "NU_LNHA_RGST_ARQV_BNCO", nullable = false, precision = 4)
    private Integer nuLnhaRgstArqvBnco;

    @Column(name = "CD_USRO_ALTR_RGST", length = 20)
    private String cdUsroAltrRgst;

    @Column(name = "CD_USRO_INCL_RGST", nullable = false, length = 20)
    private String cdUsroInclRgst;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DH_ALTR_RGST")
    private Date dhAltrRgst;

    @Temporal(TemporalType.DATE)
    @Column(name = "DH_INCL_RGST", nullable = false)
    private Date dhInclRgst;

    @Column(name = "NU_SQNL_PRPS_BNCO", nullable = false, precision = 6)
    private Integer nuSqnlPrpsBnco;

	/**
	 * @return the nuPrpsCrdn
	 */
	public Long getNuPrpsCrdn() {
		return nuPrpsCrdn;
	}

	/**
	 * @param nuPrpsCrdn the nuPrpsCrdn to set
	 */
	public void setNuPrpsCrdn(Long nuPrpsCrdn) {
		this.nuPrpsCrdn = nuPrpsCrdn;
	}

	/**
	 * @return the cdBnco
	 */
	public Integer getCdBnco() {
		return cdBnco;
	}

	/**
	 * @param cdBnco the cdBnco to set
	 */
	public void setCdBnco(Integer cdBnco) {
		this.cdBnco = cdBnco;
	}

	/**
	 * @return the dtMvmnArqvBnco
	 */
	public Date getDtMvmnArqvBnco() {
		return dtMvmnArqvBnco;
	}

	/**
	 * @param dtMvmnArqvBnco the dtMvmnArqvBnco to set
	 */
	public void setDtMvmnArqvBnco(Date dtMvmnArqvBnco) {
		this.dtMvmnArqvBnco = dtMvmnArqvBnco;
	}

	/**
	 * @return the nuRmsaArqvBnco
	 */
	public Integer getNuRmsaArqvBnco() {
		return nuRmsaArqvBnco;
	}

	/**
	 * @param nuRmsaArqvBnco the nuRmsaArqvBnco to set
	 */
	public void setNuRmsaArqvBnco(Integer nuRmsaArqvBnco) {
		this.nuRmsaArqvBnco = nuRmsaArqvBnco;
	}

	/**
	 * @return the nuLnhaRgstArqvBnco
	 */
	public Integer getNuLnhaRgstArqvBnco() {
		return nuLnhaRgstArqvBnco;
	}

	/**
	 * @param nuLnhaRgstArqvBnco the nuLnhaRgstArqvBnco to set
	 */
	public void setNuLnhaRgstArqvBnco(Integer nuLnhaRgstArqvBnco) {
		this.nuLnhaRgstArqvBnco = nuLnhaRgstArqvBnco;
	}

	/**
	 * @return the cdUsroAltrRgst
	 */
	public String getCdUsroAltrRgst() {
		return cdUsroAltrRgst;
	}

	/**
	 * @param cdUsroAltrRgst the cdUsroAltrRgst to set
	 */
	public void setCdUsroAltrRgst(String cdUsroAltrRgst) {
		this.cdUsroAltrRgst = cdUsroAltrRgst;
	}

	/**
	 * @return the cdUsroInclRgst
	 */
	public String getCdUsroInclRgst() {
		return cdUsroInclRgst;
	}

	/**
	 * @param cdUsroInclRgst the cdUsroInclRgst to set
	 */
	public void setCdUsroInclRgst(String cdUsroInclRgst) {
		this.cdUsroInclRgst = cdUsroInclRgst;
	}

	/**
	 * @return the dhAltrRgst
	 */
	public Date getDhAltrRgst() {
		return dhAltrRgst;
	}

	/**
	 * @param dhAltrRgst the dhAltrRgst to set
	 */
	public void setDhAltrRgst(Date dhAltrRgst) {
		this.dhAltrRgst = dhAltrRgst;
	}

	/**
	 * @return the dhInclRgst
	 */
	public Date getDhInclRgst() {
		return dhInclRgst;
	}

	/**
	 * @param dhInclRgst the dhInclRgst to set
	 */
	public void setDhInclRgst(Date dhInclRgst) {
		this.dhInclRgst = dhInclRgst;
	}

	/**
	 * @return the nuSqnlPrpsBnco
	 */
	public Integer getNuSqnlPrpsBnco() {
		return nuSqnlPrpsBnco;
	}

	/**
	 * @param nuSqnlPrpsBnco the nuSqnlPrpsBnco to set
	 */
	public void setNuSqnlPrpsBnco(Integer nuSqnlPrpsBnco) {
		this.nuSqnlPrpsBnco = nuSqnlPrpsBnco;
	}

    
}
