package br.com.cielo.credenciamento.crd.service;

import javax.ejb.Local;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.remote.ICredenciamentoServiceRemote;

/**
 * Interface Local responsael pela implementacao da integracao com a Release 01
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface ICredenciamentoService extends ICredenciamentoServiceRemote{

	/**
	 * Método responsavel pelas consistências do prospect na retomada
	 * @param proposta
	 */
	void tratarProspectRetomada(Prospect proposta);
}
