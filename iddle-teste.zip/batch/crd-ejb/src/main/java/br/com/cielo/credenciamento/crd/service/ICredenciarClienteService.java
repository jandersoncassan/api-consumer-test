package br.com.cielo.credenciamento.crd.service;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.model.Criticas;

/**
 * Interface responsavel pelos métodos para credenciamento de cliente, utilizando o serviço da RL01 - CRD
 * @author Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public interface ICredenciarClienteService {

	/**
	 * Método responsavel pelo credenciamento de cliente via serviço CRD (RL01)
	 * @param proposta
	 */
	void credenciarCliente(final Prospect proposta);
	
	/**
	 * Método responsavel por devolver a lista de criticas de para CRD --> SEC
	 * @return
	 */
	Criticas getListaCriticas();
	
	/**
	 * Método responsavel por "limpar" a lista de criticas da memória.
	 * A cada remessa efetuamos essa operação.
	 */
	void limparListaCriticas();
}
