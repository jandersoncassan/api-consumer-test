package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * Entidade representando a atabela de Controle de Carga Bancos
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDR_LOG_CNTR_CRGA_BNCO")
public class LogControleCargaBanco implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotFound(action = NotFoundAction.IGNORE)
    @EmbeddedId
    private LogControleCargaBancoPK id;

    @Column(name = "CD_USRO_ALTR_RGST", length = 20)
    private String cdUsroAltrRgst;

    @Column(name = "CD_USRO_INCL_RGST", nullable = false, length = 20)
    private String cdUsroInclRgst;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DH_ALTR_RGST")
    private Date dhAltrRgst;

    @Temporal(TemporalType.TIMESTAMP)
    @DateTimeFormat(pattern = "dd/MM/yyyy hh:mm:ss")
    @Column(name = "DH_INCL_RGST", nullable = false)
    private Date dhInclRgst;

    @Column(name = "IN_ARQV_ACTD", nullable = false, columnDefinition="char(1)")
    private String inArqvActd;

    @Column(name = "QT_RGST_ACTD", nullable = false, precision = 5)
    private Integer qtRgstActd;

    @Column(name = "QT_RGST_RJTD", nullable = false, precision = 5)
    private Integer qtRgstRjtd;

    @Column(name = "QT_TOTL_RGST", precision = 5)
    private Integer qtTotlRgst;

    @Column(name = "CD_ERRO_ARQV_BNCO")
    private Integer codErroArquivoBanco;

    @Column(name = "CD_TIPO_ARQV_BNCO", nullable = false)
    private Integer codTipoArquivoBanco;

    @OneToMany(mappedBy = "controleCargaBanco", fetch = FetchType.LAZY, cascade = {CascadeType.MERGE})
    @Fetch(FetchMode.SELECT)
    private List<ProcessamentoRegistroArquivo> listaRegistroArquivo;

    
    /**
	 * @return the id
	 */
	public LogControleCargaBancoPK getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(LogControleCargaBancoPK id) {
		this.id = id;
	}


	/**
	 * @return the cdUsroAltrRgst
	 */
	public String getCdUsroAltrRgst() {
		return cdUsroAltrRgst;
	}


	/**
	 * @param cdUsroAltrRgst the cdUsroAltrRgst to set
	 */
	public void setCdUsroAltrRgst(String cdUsroAltrRgst) {
		this.cdUsroAltrRgst = cdUsroAltrRgst;
	}


	/**
	 * @return the cdUsroInclRgst
	 */
	public String getCdUsroInclRgst() {
		return cdUsroInclRgst;
	}


	/**
	 * @param cdUsroInclRgst the cdUsroInclRgst to set
	 */
	public void setCdUsroInclRgst(String cdUsroInclRgst) {
		this.cdUsroInclRgst = cdUsroInclRgst;
	}


	/**
	 * @return the dhAltrRgst
	 */
	public Date getDhAltrRgst() {
		return dhAltrRgst;
	}


	/**
	 * @param dhAltrRgst the dhAltrRgst to set
	 */
	public void setDhAltrRgst(Date dhAltrRgst) {
		this.dhAltrRgst = dhAltrRgst;
	}


	/**
	 * @return the dhInclRgst
	 */
	public Date getDhInclRgst() {
		return dhInclRgst;
	}


	/**
	 * @param dhInclRgst the dhInclRgst to set
	 */
	public void setDhInclRgst(Date dhInclRgst) {
		this.dhInclRgst = dhInclRgst;
	}


	/**
	 * @return the inArqvActd
	 */
	public String getInArqvActd() {
		return inArqvActd;
	}


	/**
	 * @param inArqvActd the inArqvActd to set
	 */
	public void setInArqvActd(String inArqvActd) {
		this.inArqvActd = inArqvActd;
	}


	/**
	 * @return the qtRgstActd
	 */
	public Integer getQtRgstActd() {
		return qtRgstActd;
	}


	/**
	 * @param qtRgstActd the qtRgstActd to set
	 */
	public void setQtRgstActd(Integer qtRgstActd) {
		this.qtRgstActd = qtRgstActd;
	}


	/**
	 * @return the qtRgstRjtd
	 */
	public Integer getQtRgstRjtd() {
		return qtRgstRjtd;
	}


	/**
	 * @param qtRgstRjtd the qtRgstRjtd to set
	 */
	public void setQtRgstRjtd(Integer qtRgstRjtd) {
		this.qtRgstRjtd = qtRgstRjtd;
	}


	/**
	 * @return the qtTotlRgst
	 */
	public Integer getQtTotlRgst() {
		return qtTotlRgst;
	}


	/**
	 * @param qtTotlRgst the qtTotlRgst to set
	 */
	public void setQtTotlRgst(Integer qtTotlRgst) {
		this.qtTotlRgst = qtTotlRgst;
	}


	/**
	 * @return the codErroArquivoBanco
	 */
	public Integer getCodErroArquivoBanco() {
		return codErroArquivoBanco;
	}


	/**
	 * @param codErroArquivoBanco the codErroArquivoBanco to set
	 */
	public void setCodErroArquivoBanco(Integer codErroArquivoBanco) {
		this.codErroArquivoBanco = codErroArquivoBanco;
	}


	/**
	 * @return the codTipoArquivoBanco
	 */
	public Integer getCodTipoArquivoBanco() {
		return codTipoArquivoBanco;
	}


	/**
	 * @param codTipoArquivoBanco the codTipoArquivoBanco to set
	 */
	public void setCodTipoArquivoBanco(Integer codTipoArquivoBanco) {
		this.codTipoArquivoBanco = codTipoArquivoBanco;
	}


	/**
	 * @return the listaRegistroArquivo
	 */
	public List<ProcessamentoRegistroArquivo> getListaRegistroArquivo() {
		return listaRegistroArquivo;
	}


	/**
	 * @param listaRegistroArquivo the listaRegistroArquivo to set
	 */
	public void setListaRegistroArquivo(List<ProcessamentoRegistroArquivo> listaRegistroArquivo) {
		this.listaRegistroArquivo = listaRegistroArquivo;
	}

	
}
