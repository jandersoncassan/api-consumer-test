package br.com.cielo.credenciamento.persistence.dao.impl;

import java.util.Date;

import javax.ejb.Stateless;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.persistence.dao.IEtapaCredenciamentoPropostaDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.EtapaProposta;

/**
 * Classe DAO responsavel pela implementacao dos servicos da etapa de credenciamento
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class EtapaCredenciamentoPropostaDAO extends AbstractJpaDAO<EtapaProposta> implements  IEtapaCredenciamentoPropostaDAO {

	private static final Logger LOG = LoggerFactory.getLogger(EtapaCredenciamentoPropostaDAO.class);

	public EtapaCredenciamentoPropostaDAO() {
        super(EtapaProposta.class);
    }

    @Override
    public EtapaProposta findEtapaAtivacao(final Long numeroProposta) {
       try{
	    	StringBuilder sql = new StringBuilder("FROM EtapaProposta e ");
	        			  sql.append("WHERE e.id.nuPrpsCrdn = :pNuPrpsCrdn ");
	        			  sql.append("AND e.id.cdEtpaCrdn = 14");
	
	        TypedQuery<EtapaProposta> query = getEntityManager().createQuery(sql.toString(), EtapaProposta.class);
	        query.setParameter("pNuPrpsCrdn", numeroProposta);
	 
	        EtapaProposta result = query.getSingleResult();
	
	        return result;
        
       }catch(NoResultException ex){
    	   LOG.error("NAO HA ETAPA DE ATIVACAO CRIADA PARA A PROPOSTA {}", numeroProposta);
    	   return null;
       }
    }

	@Override
	public void atualizarEtapaAtivacao(Long numeroProposta) {
		StringBuilder sql = new StringBuilder("UPDATE TBCRDR_ETPA_PRPS_CRDN ETPA ");
		              sql.append("SET ETPA.DH_ENCE_ETPA_PRPS_CRDN = :pDataEncerramento , ");
		              sql.append("ETPA.CD_STCO_ETPA_PRPS_CRDN = 3 ,");
		              sql.append("ETPA.DH_ALTR_RGST = :pDataEncerramento ");
		              sql.append("WHERE ETPA.NU_PRPS_CRDN = :pNumeroProposta ");
		              sql.append("AND ETPA.CD_ETPA_CRDN = 14");
		              
		 Query query = getEntityManager().createNativeQuery(sql.toString());
		 query.setParameter("pDataEncerramento", new Date());
		 query.setParameter("pNumeroProposta", numeroProposta);
		 
		 query.executeUpdate();		
	}
}
