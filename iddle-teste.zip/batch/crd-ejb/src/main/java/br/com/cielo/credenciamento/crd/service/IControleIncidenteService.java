package br.com.cielo.credenciamento.crd.service;

import java.util.List;

import javax.ejb.Local;

import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;
import br.com.cielo.credenciamento.ejb.remote.IControleIncidenteServiceRemote;

/**
 * Interface Local responsael pela implementacao do tratamento / controle de incidente
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IControleIncidenteService extends IControleIncidenteServiceRemote {
	
    /**
     * Método responsavel por obter a lista de incidentes na base dedados
     * @return
     */
    List<Incidente> obterListaIncidente();

}