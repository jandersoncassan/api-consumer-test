package br.com.cielo.credenciamento.crd.service.impl;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.service.IRotinaExpurgoService;
import br.com.cielo.credenciamento.persistence.dao.IControleIncidenteDAO;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;

@Stateless
public class RotinaExpurgoServiceImpl implements IRotinaExpurgoService{

	private static final Logger LOG = LoggerFactory.getLogger(RotinaExpurgoServiceImpl.class);

	@Inject
	private IControleIncidenteDAO controleIncidenteDAO;
	
	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroDAO;
	
	@Override
	public void executarExpurgo() {
		LOG.info("SERVICE - EXECUCAO ROTINA DE EXPURGO");
		expurgoIncidProcessados();
		expurgoRegProcessados();
	}
	
	/**
	 * Método responsavel por efetuar o expurgo da tabela de incidentes
	 */
	private void expurgoIncidProcessados(){
		LOG.info("EXPURGO TABELA DE INCIDENTES");
		controleIncidenteDAO.expurgoIncidentesProcessados();
	}

	/**
	 * Método responsavel por efetuar o expurgo da tabela work
	 */
	private void expurgoRegProcessados(){
		LOG.info("EXPURGO TABELA WORK");
		procRegistroDAO.expurgoRegistrosProcessados();		
	}

}
