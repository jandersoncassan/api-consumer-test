package br.com.cielo.credenciamento.crd.util;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.SerializationUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import br.com.cielo.credenciamento.ejb.domain.batch.Banco;
import br.com.cielo.credenciamento.ejb.domain.batch.Endereco;
import br.com.cielo.credenciamento.ejb.domain.batch.Proprietario;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.domain.batch.Telefone;
import br.com.cielo.credenciamento.model.Critica;
import br.com.cielo.credenciamento.model.Criticas;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivoPK;

/**
 * Classe Utils CRD
 * 
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class CrdUtils {

	private static final Logger LOG = LoggerFactory.getLogger(CrdUtils.class);
	
    private static final ObjectMapper objectMapper = new ObjectMapper();

	
	// INFORMAÇÕES HEADER SERVIÇOS SOAP
	public static final String HEADER_USER = "soap.header.id";
	public static final String HEADER_PASS = "soap.header.senha";

	// ENDPOINT VALIDACAO
	public static final String ENDPOINT_CREDENCIAR_CLIENTE_OSB = "endpoint.credenciar.cliente.osb";
	public static final String ENDPOINT_CREDENCIAR_CLIENTE_CRD = "endpoint.credenciar.cliente.crd";
	public static final String ENDPOINT_DESBLOQUEIO_MOBILE = "endpoint.desbloqueio.mobile";

	public static final String NUMERICO = "N";
	public static final Integer VALOR_NUMERICO_ZERO = 0;

	public static final String CODIGO_MENSAGEM = "045";
	public static final String CODIGO_REJEICAO_MENSAGEM = "98";
	public static final String CODIGO_REJEICAO_BANCO = "07";

	// CHAVE PARA IDENTIFICAR SE DEVEMOS IR PELO SERVIÇO DO OSB OU CHAMAR DIRETO O CRD
	public static final String PROCESS_SERVICE = "process.service";

	// PATH ARQUIVO JSON CRITICAS
	public static final String PATH_FILE_JSON_CITICAS = "path.file.criticas.json";
	
	//DOMICILIO BANCARIO
	public static final Integer ERRO_DOMICILIO_CRD= 9;
	public static final String ERRO_DOMICILIO_SEC= "20";
	
	//CORRELATIONID
	public static final Integer INDEX_BANCO = 0;
	public static final Integer INDEX_DATA_MOVIMENTO = 1;
	public static final Integer INDEX_REMESSA = 2;
	public static final Integer INDEX_LINHA = 3;

	// SITUACAO VALIDACAO ARQUIVO
	public static final String PROPOSTA_REJEITADA = "01";
	public static final String PROPOSTA_FALHA_SISTEMICA = "99";
	
	//ETAPA ATIVACAO
	public static final Integer ETAPA_ATIVACAO = 14;
	public static final Integer STATUS_ETAPA_SUCESSO = 3;
	
    //TRATAMENTO DE INCIDENTES
	public static final Integer COD_ETAPA = 0;
	public static final Integer COD_CRITICA = 1;
	public static final Integer COD_SIT_ETAPA = 2;
	public static final Integer COD_TIPO_ERRO = 3;
	public static final Integer NUMERO_EC = 4;
	public static final Integer SEQ_CAMPO = 5;
	public static final Integer FLAG_RESSALVA = 6;
	
	public static final Integer ETAPA_PRE_CADASTRO = 18;
	public static final Integer STATUS_SUCESSO = 3;
	public static final Integer STATUS_FALHA_SISTEMICA = 7;
	
	public static final String SEM_RESSALVA = "N";
	public static final Integer NUM_ZERO = 0;
	public static final String NUM_ZERO_S = "0";
	public static final Integer NUM_DEZ = 10;
	/**
	 * Método responsavel por verificar se o banco está utilizando o layout novo
	 * ou o atual Codigo Plano OR Solução de Captura is Numerico && <> zero.
	 * 
	 * @param codTipoPlano
	 * @param solucaoCaptura
	 */
	public static boolean isLayoutNovo(String codTipoPlano, String solucaoCaptura) {
		return (isNumberAndNotZeros(codTipoPlano) || isNumberAndNotZeros(solucaoCaptura));
	}

	/**
	 * Método responsavel por verificar se a informação é numerica
	 * 
	 * @param info
	 * @return boolean
	 */
	public static boolean isNumber(String info) {
		return info.matches("\\d+");
	}

	/**
	 * Método responsavel por verificar se a informação é numerica
	 * 
	 * @param info
	 * @return boolean
	 */
	public static boolean isNumberAndNotZeros(String info) {
		return (isNumber(info) && !info.matches("[^1-9]+"));
	}

	/**
	 * Metodo responsavel por carregar o arquivo de propriedades "Criticas"
	 * 
	 * @param t
	 * @return
	 * @throws IOException
	 * @throws JsonMappingException
	 * @throws JsonParseException
	 */
	public static Criticas loadFileCriticas(Class<Criticas> clazz, String path)
			throws JsonParseException, JsonMappingException, IOException {
		
		ObjectMapper mapper = new ObjectMapper();
		return (mapper.readValue(new File(path), clazz));
	}
	
	/**
	 * Método responsavel por recuperar a data de movimento
	 * @param data
	 * @return
	 */
	public static Date getDataMovimento(String data){
		SimpleDateFormat dateFormatter = new SimpleDateFormat("ddMMyy");
		Date formatada = null;
		try {
			formatada= dateFormatter.parse(data);
		} catch (ParseException ex) {
			LOG.error("OCORREU UM ERRO NA FORMATACAO DA DATA DE MOVIMENTO CORRELATIONID {}", ex);
		}
		return formatada;
	}
	
 	/**
	 * Método responsavel por "montar" o correlationID
	 * 
	 * @param codigoBanco
	 * @param dataExecucao
	 * @param numRemessa
	 * @param numLinha
	 * @return
	 */
	public static String popularCorrelationId(final Integer codigoBanco, final Date dataExecucao, final Integer numRemessa, final Integer numLinha){
		SimpleDateFormat dateFormatter = new SimpleDateFormat("ddMMyy");
        StringBuilder corrId = new StringBuilder();
        corrId.append(StringUtils.leftPad(codigoBanco.toString(), 3, "0")).append(";")
        	  .append(dateFormatter.format(dataExecucao)).append(";")
        	  .append(numRemessa).append(";")
        	  .append(numLinha);
        return corrId.toString();
	}


	/**
	 * Método responsavel por popular as informações da proposta
	 * @param entityProposta
	 * @return
	 */
	public static Prospect popularEntityToProposta(ProcessamentoRegistroArquivo entityProposta) {
		Prospect proposta = new Prospect();
		popularInformacoes(proposta, entityProposta);
		return proposta;
	}

	/**
	 * Método responsavel por popular as informações da proposta
	 * @param proposta
	 */
	private static void popularInformacoes(Prospect proposta, ProcessamentoRegistroArquivo entityProposta) {		
 		proposta.setCodigoMensagem(entityProposta.getCdFnldArqv());
		proposta.setSolicitante(entityProposta.getCdBncoSlcePrpsCrdn());
		proposta.setNumeroInstituicao(entityProposta.getNuSpbBncoSlcePrpsCrdn());
		proposta.setNumeroIdentificacao(entityProposta.getNuIdtfOrgmSlctAflc());
	    proposta.setAreaReservada01(entityProposta.getTxPrimEpcoRsrdCilo());  
	    proposta.setCodigoErro(entityProposta.getCdErroVldcArqv()); 
	    proposta.setFlagBanco(entityProposta.getCdErroCdgoBncoPrpsCrdn()); 
	    proposta.setBanco(entityProposta.getCdBncoPrpsCrdn());
	    proposta.setNumeroEstabelecimento(entityProposta.getNuEc());
	    proposta.setFlagRazaoSocial(entityProposta.getCdErroNmRazoSocl());
	    proposta.setRazaoSocial(entityProposta.getNmRazoSocl());
	    //POPULAR ENDERECO CORRESPONDENCIA
	    popularEnderecoCorrespondecia(proposta, entityProposta);
	    proposta.setFlagCpfCnpj(entityProposta.getCdErroNmroCpfCnpj()); 
	    proposta.setCpfCnpj(entityProposta.getNuCpfCnpj());
	    proposta.setFlagInscricaoEstadual(entityProposta.getCdErroNmroIe()); 
	    proposta.setInscricaoEstadual(entityProposta.getNuIe());
	    proposta.setFlagNomeFantasia(entityProposta.getCdErroNomeFnts());
	    proposta.setNomeFantasia(entityProposta.getNmFnts());
	    //POPULAR ENDERECO COMERCIAL	
	    popularEnderecoComercial(proposta, entityProposta);
	    proposta.setFlagNomePlaqueta(entityProposta.getCdErroNomePlqtEc());
	    proposta.setNomePlaqueta(entityProposta.getNmPlqtEc());
	    proposta.setFlagPessoaContato(entityProposta.getCdErroNomePesaCnto()); 
	    proposta.setPessoaContato(entityProposta.getNmPesaCnto());
	    proposta.setAreaReservada02(entityProposta.getTxEpcoRsrdArqv());
	    proposta.setFlagRamoAtividade(entityProposta.getCdErroCdgoMcc()); 
	    proposta.setRamoAtividade(entityProposta.getCdMcc());
	    //POPULAR DOMICILIO BANCARIO	
	    popularDomicilioBancario(proposta, entityProposta);
	    //POPULAR PROPRIETARIOS
	    popularProprietarios(proposta, entityProposta);
	    proposta.setFlagTipoPessoa(entityProposta.getCdErroSgTipoPesa());
	    proposta.setTipoPessoa(entityProposta.getSgTipoPesa());
	    proposta.setAreaReservada03(entityProposta.getTxNonoEpcoRsrdCilo());
	    //POPULAR TELEFONES
	    popularTelefones(proposta, entityProposta);
	    proposta.setFlagMei(entityProposta.getCdErroIdcrMei());
	    proposta.setMei(entityProposta.getInMei());
	    proposta.setAreaReservadaCielo04(entityProposta.getTxQrtoEpcoRsrdCilo());
	    proposta.setFlagPacoteEcommerce(entityProposta.getCdErroPcteCmel());
	    proposta.setCodPacoteEcommerce(entityProposta.getCdPcteCmel());
	    proposta.setAreaReservadaCielo05(entityProposta.getTxQuntEpcoRsrdCilo());
	    proposta.setFlagTipoConta(entityProposta.getCdErroTipoConta());
	    proposta.setTipoConta(entityProposta.getCdTipoConta());
	    proposta.setAreaReservadaCielo06(entityProposta.getTxDcmoEpcoRsrdCilo());
	    proposta.setFlagPlanoCielo(entityProposta.getCdErroPlnoCilo());
	    proposta.setCodTipoPlano(entityProposta.getCdPlnoCilo());
	    proposta.setFlagValorFaturamento(entityProposta.getCdErroValrFtrm());
	    proposta.setValorFaturamento(entityProposta.getValrFtrm());
	    proposta.setFlagQtdadeDiasLiquidacao(entityProposta.getCdErroQntdDiaLqdc());
	    proposta.setQtdadeDiasLiquidacao(entityProposta.getQntdDiaLqdc());
	    proposta.setFlagSolucaoCaptura(entityProposta.getCdErroSlcp());
	    proposta.setSolucaoCaptura(entityProposta.getCdSlcp());
	    proposta.setFlagIndicadorAgro(entityProposta.getCdErroIdcrAgro());
	    proposta.setIndicadorAgro(entityProposta.getCdIdcrAgro());
	    proposta.setFlagEmail(entityProposta.getCdErroDercEmal());;
	    proposta.setAreaReservadaCielo07(entityProposta.getTxSxtoEpcoRsrdCilo());
	    proposta.setEmail(entityProposta.getDescEmail());; 
	    proposta.setAreaReservadaCielo08(entityProposta.getTxStmoEpcoRsrdCilo());;
	    
	    proposta.setCorrelationId(getCorrelationId(entityProposta.getId()));
	}

	/**
	 * Método responsavel por popular a lista de telefones
	 * @param proposta
	 * @param entityProposta
	 */
	private static void popularTelefones(Prospect proposta, ProcessamentoRegistroArquivo entityProposta) {
		List<Telefone> telefones = new ArrayList<>();
	    Telefone telefoneCelular = new Telefone();
	    telefoneCelular.setFlagDDD(entityProposta.getCdErroNmroDddSlcoMvel());
	    telefoneCelular.setDdd(entityProposta.getNuDddTlfnSlcoMvel());
	    telefoneCelular.setFlagNumero(entityProposta.getCdErroNmroTlfnSlcoMvel());
	    telefoneCelular.setNumero(entityProposta.getNuTlfnSlcoMvel());
	    telefones.add(telefoneCelular);
	   
	    Telefone telefoneComercial = new Telefone();
	    telefoneComercial.setFlagDDD(entityProposta.getCdErroNmroDddTlfnFax());
	    telefoneComercial.setDdd(entityProposta.getNuDddTlfnFax());
	    telefoneComercial.setFlagNumero(entityProposta.getCdErroNmroTlfnFax());
	    telefoneComercial.setNumero(entityProposta.getNuTlfnFax());
	    telefones.add(telefoneComercial);
	    
	    proposta.setTelefones(telefones);
	}

	/**
	 * Método responsavel por popular as informações de proprietários
	 * @param proposta
	 * @param entityProposta
	 */
	private static void popularProprietarios(Prospect proposta, ProcessamentoRegistroArquivo entityProposta) {
		List<Proprietario> listaProprietarios = new ArrayList<>();
		Proprietario proprietario01 = new Proprietario();
	    proprietario01.setFlagNomeProprietario(entityProposta.getCdErroNomeCmplPrimPrpt());	    
	    proprietario01.setNomeProprietario(entityProposta.getNmCmplPrimPrpt());	    
	    proprietario01.setFlagCpfProprietario(entityProposta.getCdErroNmroCpfPrimPrpt());	    
	    proprietario01.setCpfProprietario(entityProposta.getNuCpfPrimPrpt());
	    proprietario01.setFlagDataNascimentoProprietario(entityProposta.getCdErroDataNscmPrimPrpt());
	    proprietario01.setDataNascimentoProprietario(entityProposta.getDtNscmPrimPrpt());
	    listaProprietarios.add(proprietario01);
	    Proprietario proprietario02 = new Proprietario();
	    proprietario02.setFlagNomeProprietario(entityProposta.getCdErroNomeCmplSgndPrpt());	    
	    proprietario02.setNomeProprietario(entityProposta.getNmCmplSgndPrpt());	    
	    proprietario02.setFlagCpfProprietario(entityProposta.getCdErroNmroCpfSgndPrpt());	    
	    proprietario02.setCpfProprietario(entityProposta.getNuCpfSgndPrpt());
	    proprietario02.setFlagDataNascimentoProprietario(entityProposta.getCdErroDataNscmSgndPrpt());
	    proprietario02.setDataNascimentoProprietario(entityProposta.getDtNscmSgndPrpt());
	    listaProprietarios.add(proprietario02);
	    Proprietario proprietario03 = new Proprietario();
	    proprietario03.setFlagNomeProprietario(entityProposta.getCdErroNomeCmplTerePrpt());	    
	    proprietario03.setNomeProprietario(entityProposta.getNmCmplTerePrpt());	    
	    proprietario03.setFlagCpfProprietario(entityProposta.getCdErroNmroCpfTerePrpt());	    
	    proprietario03.setCpfProprietario(entityProposta.getNuCpfTerePrpt());
	    proprietario03.setFlagDataNascimentoProprietario(entityProposta.getCdErroDataNscmTerePrpt());
	    proprietario03.setDataNascimentoProprietario(entityProposta.getDtNscmTerePrpt());
	    listaProprietarios.add(proprietario03);
	    proposta.setProprietarios(listaProprietarios);
	}

	/**
	 * Método responsvel por popular as informações de Domicilio bancário
	 * @param proposta
	 * @param entityProposta
	 */
	private static void popularDomicilioBancario(Prospect proposta, ProcessamentoRegistroArquivo entityProposta) {
	       Banco banco = new Banco();	       
	       banco.setFlagCodigoAgencia(entityProposta.getCdErroCdgoAgnc());
	       banco.setCodigoAgencia(entityProposta.getCdAgnc());
	       banco.setFlagNumeroContaCorrente(entityProposta.getCdErroNmroCncr());
	       banco.setNumeroContaCorrente(entityProposta.getNuCncr());
	       proposta.setDadosBancarios(banco);
	}

	/**
	 * Método responsavel por popular as informações de endereço comercial
	 * @param proposta
	 * @param entityProposta
	 */
	private static void popularEnderecoComercial(Prospect proposta, ProcessamentoRegistroArquivo entityProposta) {
        Endereco enderecoComercial = new Endereco();
        enderecoComercial.setFlagLogradouro(entityProposta.getCdErroNomeLgrdEndrCmrl());
        enderecoComercial.setLogradouro(entityProposta.getNmLgrdEndrCmrl());
        enderecoComercial.setComplementoLogradouro(entityProposta.getDcCmpmLgrdEndrCmrl());
        enderecoComercial.setFlagCidade(entityProposta.getCdErroNomeCideEndrCmrl());
        enderecoComercial.setCidade(entityProposta.getNmCideEndrCmrl());
        enderecoComercial.setFlagEstado(entityProposta.getCdErroSglaEstdEndrCmrl());
        enderecoComercial.setEstado(entityProposta.getSgEstdEndrCmrl());
        enderecoComercial.setFlagCep(entityProposta.getCdErroNmroCepEndrCmrl());
        enderecoComercial.setCep(entityProposta.getNuCepEndrCmrl());
        proposta.setFlagNumEnderComercial(entityProposta.getCdErroNmroEndrCmrl());
        proposta.setNumEnderComercial(entityProposta.getNmroEndrCmrl());        
        proposta.setEnderecoEstabelecimento(enderecoComercial);
	}

	/**
	 * Método responsavel por popular o Endereço Correspondência
	 * @param proposta
	 * @param entityProposta
	 */
	private static void popularEnderecoCorrespondecia(Prospect proposta, ProcessamentoRegistroArquivo entityProposta) {
		Endereco enderecoCorrespondencia = new Endereco();
        enderecoCorrespondencia.setFlagLogradouro(entityProposta.getCdErroNomeLgrdEndrCrsp());
        enderecoCorrespondencia.setLogradouro(entityProposta.getNmLgrdEndrCrsp());
        enderecoCorrespondencia.setComplementoLogradouro(entityProposta.getDcCmpmLgrdEndrCrsp());
        enderecoCorrespondencia.setFlagCidade(entityProposta.getCdErroNomeCideEndrCrsp());
        enderecoCorrespondencia.setCidade(entityProposta.getNmCideEndrCrsp());
        enderecoCorrespondencia.setFlagEstado(entityProposta.getCdErroSglaEstdEndrCrsp());
        enderecoCorrespondencia.setEstado(entityProposta.getSgEstdEndrCrsp());
        enderecoCorrespondencia.setFlagCep(entityProposta.getCdErroNmroCepEndrCrsp());
        enderecoCorrespondencia.setCep(entityProposta.getNuCepEndrCrsp());
        proposta.setFlagNumEnderCorrespondecia(entityProposta.getCdErroNmroEndrCrsa());
        proposta.setNumEnderCorrespondecia(entityProposta.getNmroEndrCrsa());        
		proposta.setEnderecoCorrespondencia(enderecoCorrespondencia);
	}

	/**
	 * Método responsavel por popular o correlation Id
	 * @param id
	 * @return
	 */
	private static String getCorrelationId(ProcessamentoRegistroArquivoPK id){
		return popularCorrelationId(id.getCdBnco(), id.getDtMvmnArqvBnco(), id.getNuRmsaArqvBnco(), id.getNuLnhaRgstArqvBnco());
	}

	
	//CRITICAS
	/**
	 * Método responsavel por popular as criticas com o "De|Para" para o SEC
	 * @param criticasType
	 * @param criticas
	 * @return
	 */
	public static void popularCriticas(ProcessamentoRegistroArquivo entity, List<Critica> listaCriticas){
		Field[] fields = entity.getClass().getDeclaredFields();
		for(Critica critica : listaCriticas){
			
			if(critica.getCodigoCrd().equals(CrdUtils.ERRO_DOMICILIO_CRD)){
				String[] campos = critica.getInfo().getCpEntidade().split("\\|");
				popularInfoDomicilio(campos, entity );
				continue;
			}
			
			for (Field field : fields){
				if(critica.getInfo().getCpEntidade().equals(field.getName())){
					updateValorCampo(entity, field, critica.getInfo().getCodigoSec());
				}
			}
		}		
	}
	
	/**
	 * Método responsavel por popular as informações das flags do domicilio bancario
	 * 
	 * @param campos
	 * @param entity
	 */
	private static void popularInfoDomicilio(String [] campos, ProcessamentoRegistroArquivo entity){		
		for(String campo : campos){
			try {
				Field field = entity.getClass().getDeclaredField(campo);
				updateValorCampo(entity, field, CrdUtils.ERRO_DOMICILIO_SEC);
			} catch (Exception e){
				LOG.error("ERRO NO MOMENTO DE ATUALIZACAO DO PROSPECT REJEITADO DOMICILIO BANCARIO (20){}", e);
			}
		}
	}
	
	/**
	 * Efetua o update das informações de prospect
	 * @param entity
	 * @param field
	 * @param valor
	 */
	private static void updateValorCampo(ProcessamentoRegistroArquivo entity, Field field, String valor){
		field.setAccessible(true);
	    try {
			field.set(entity, valor);
		} catch (IllegalArgumentException | IllegalAccessException e) {
			LOG.error("ERRO NO MOMENTO DE ATUALIZACAO DO PROSPECT REJEITADO {}", e);
		}

	}
	
	/**
	 * Método responsavel por popular os códigos Match com o layout de bancos SEC
	 * @param codCriticaCrd
	 * @return Map<String, String>
	 */
	public static Critica getCriticasSec(Criticas listaCriticas ,String criticaCrd, Integer sequencia){
		Critica critica = null;
		//POPULAMOS AS CRITICAS DE | PARA SEC
			for (Critica criticaSec : listaCriticas.getCriticas()) {				
				if(criticaCrd.equals(criticaSec.getCodigoCrd().toString())){					
					critica = SerializationUtils.clone(criticaSec);
					if(critica.getInfo().getCpEntidade().contains("|")){
						String[] campos = critica.getInfo().getCpEntidade().split("\\|");
						critica.getInfo().setCpEntidade(campos[sequencia-1]);
					}
					break;
				}
			}
		return critica;
	}

	   /**
     * Método responsavel por gerar o json
     * 
     * @param object
     * @return byte[]
     * @throws IllegalArgumentException
     */
    public static void deflate(String operacao, Object object) throws IllegalArgumentException {

        try {
            String json = objectMapper.writeValueAsString(object);
            byte[] bytes = json.getBytes();
            printLog(operacao, new String(bytes));
 
        } catch (JsonProcessingException e) {
        	 LOG.error("ERRO AO LOGAR AS INFORMACOES DA OPERACAO {}", operacao);
        }
    }

    /**
     * Print das informações de log
     * 
     * @param operacao
     * @param mensagem
     */
    private static void printLog(String operacao, String mensagem) {

        LOG.info("=>".concat(operacao).concat(" PAYLOAD : {}"), mensagem);
    }

	/**
	 * Método responsavel por formatar a Data para imprimir no LOG
	 * 
	 * @param data
	 * @return
	 */
	public static String dateToString(Date data){
		SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
		return dateFormatter.format(data);
	}

}
