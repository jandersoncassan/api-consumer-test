package br.com.cielo.credenciamento.persistence.dao.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.ejb.constantes.Constants;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.LogControleCargaBanco;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivoPK;

/**
 * Classe DAO responsavel pelas consistências envolvendo o arquivo de remessa de bancos
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class ProcessamentoRegistroArquivoDAO extends AbstractJpaDAO<ProcessamentoRegistroArquivo> implements  IProcessamentoRegistroArquivoDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ProcessamentoRegistroArquivoDAO.class);

     public ProcessamentoRegistroArquivoDAO() {
        super(ProcessamentoRegistroArquivo.class);
    }

    @Override
    public void atualizarContadoresRemessa(String codigoBanco) {
    	LOG.info("ATUALIZAR CONTADORES DAS REMESSAS");
        try {
            getEntityManager().flush();
            Query query = getEntityManager().createNativeQuery("update TBCRDR_LOG_CNTR_CRGA_BNCO logc set "
                            + "logc.QT_RGST_ACTD = " + "(select count(*) from TBCRDW_PCSM_RGST_CDST_ATUL cad "
                            + "where to_date(cad.DT_MVMN_ARQV_BNCO, 'dd/mm/yyyy') = to_date(logc.DT_MVMN_ARQV_BNCO, 'dd/mm/yyyy') "
                            + " and cad.NU_RMSA_ARQV_BNCO = logc.NU_RMSA_ARQV_BNCO and cad.CD_BNCO = logc.CD_BNCO and "
                            + "cad.CD_STCO_PCSM_RGST_ARQV in (4,6)), " + "logc.QT_RGST_RJTD = "
                            + "(select count(*) from TBCRDW_PCSM_RGST_CDST_ATUL cad "
                            + "where to_date(cad.DT_MVMN_ARQV_BNCO, 'dd/mm/yyyy') = to_date(logc.DT_MVMN_ARQV_BNCO, 'dd/mm/yyyy') "
                            + "and cad.NU_RMSA_ARQV_BNCO = logc.NU_RMSA_ARQV_BNCO and cad.CD_BNCO = logc.CD_BNCO and "
                            + "cad.CD_STCO_PCSM_RGST_ARQV in (3,5,99)) " + "where "
                            + "logc.QT_TOTL_RGST > (logc.QT_RGST_ACTD + logc.QT_RGST_RJTD) and logc.IN_ARQV_ACTD = 'N' "
                            + " AND logc.DH_INCL_RGST >=(SYSDATE - 5) "
                            + " AND logc.CD_BNCO = :pCdBnco").setParameter("pCdBnco", Integer.valueOf(codigoBanco));
            
            query.executeUpdate();
            
        } catch (Exception e) {
            LOG.error("OCORREU UM ERRO AO ATUALIZAR OS CONTADORES DAS REMESSAS");
        }
    }

    @Override
    public List<ProcessamentoRegistroArquivo> obterListaRegistrosConcluidos(String codigoBanco) {
    	LOG.info("BUSCANDO A LISTA DE REGISTROS CONCLUIDOS");
    	StringBuilder sql = new StringBuilder("SELECT * FROM TBCRDW_PCSM_RGST_CDST_ATUL ");
                      sql.append("WHERE CD_STCO_PCSM_RGST_ARQV = '4' ");
                      sql.append("AND NU_EC IS NOT NULL ");
                      sql.append("AND CD_BNCO ="+ Integer.valueOf(codigoBanco));

        Query query = getEntityManager().createNativeQuery(sql.toString(), ProcessamentoRegistroArquivo.class);

        @SuppressWarnings("unchecked")
        List<ProcessamentoRegistroArquivo> arquivos = (List<ProcessamentoRegistroArquivo>) query.getResultList();

        return arquivos;
    }

    @Override
    public List<LogControleCargaBanco> obterListaRemessasArquivos(final String codigoBanco) {
    	LOG.info("BUSCANDO A LISTA DE REMESSAS DE ARQUIVOS");
    	StringBuilder sql = new StringBuilder("FROM LogControleCargaBanco L ");
        sql.append("WHERE L.inArqvActd = 'N' ");
        sql.append("AND L.qtTotlRgst=( ");
        sql.append("SELECT COUNT(*) ");
        sql.append("FROM ProcessamentoRegistroArquivo P ");
        sql.append("WHERE ");
        sql.append("(P.situacaoRegistro.codSituacao = 5 "); //REJEITADO
        sql.append("OR P.situacaoRegistro.codSituacao = 3 "); //COM ERRO
        sql.append("OR P.situacaoRegistro.codSituacao = 99 "); //PROBLEMA SISTEMICO
        sql.append("OR P.situacaoRegistro.codSituacao = 6 "); //PROCESSADO
        sql.append(") AND P.id.cdBnco = L.id.cdBnco ");
        sql.append("AND P.id.cdBnco = :pcdBnco");
        sql.append(" AND to_date(P.id.dtMvmnArqvBnco,'dd/mm/yyyy') = to_date(L.id.dtMvmnArqvBnco,'dd/mm/yyyy') ");
        sql.append("AND P.id.nuRmsaArqvBnco=L.id.nuRmsaArqvBnco )");

        TypedQuery<LogControleCargaBanco> query = getEntityManager()
                .createQuery(sql.toString(), LogControleCargaBanco.class).setParameter("pcdBnco", Integer.valueOf(codigoBanco));
        return query.getResultList();
    }


    @Override
    public Integer getNextLinha(final Integer codigoBanco, final Date dataMovimento, final Integer numeroRemessa) {
    	LOG.info("BUSCANDO A PROXIMA LINHA DA REMESSA");
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        String sql = "SELECT MAX(bean.NU_LNHA_RGST_ARQV_BNCO) FROM TBCRDW_PCSM_RGST_CDST_ATUL bean "
                        + "WHERE bean.CD_BNCO = :codigoBanco AND trunc(bean.DT_MVMN_ARQV_BNCO) = to_date(:dataMovimento, 'dd/mm/yyyy') "
                        + "AND bean.NU_RMSA_ARQV_BNCO = :numeroRemessa";

        Query query = getEntityManager().createNativeQuery(sql);
        query.setParameter("codigoBanco", codigoBanco);
        query.setParameter("dataMovimento", sdf.format(dataMovimento));
        query.setParameter("numeroRemessa", numeroRemessa);

        BigDecimal remessaAtual = (BigDecimal) query.getSingleResult();
        int proximaRemessa = 1;
        if (remessaAtual != null) {
            proximaRemessa = remessaAtual.intValue() + Constants.UM;
        }
        return proximaRemessa;
    }

	@Override
	public ProcessamentoRegistroArquivo findById(final ProcessamentoRegistroArquivoPK id) {
		LOG.info("BUSCANDO AS INFORMACOES DE PROSPECT ");
		try{
		
	        Calendar cal = Calendar.getInstance();
	        cal.setTime(id.getDtMvmnArqvBnco());
	        cal.set(Calendar.HOUR_OF_DAY, 0);
	        cal.set(Calendar.MINUTE, 0);
	        cal.set(Calendar.SECOND, 0);
	        Date dataInicio = cal.getTime();
	        
	        cal.add(Calendar.HOUR_OF_DAY, Constants.VINTE_E_TRES);
	        cal.add(Calendar.MINUTE, Constants.CINQUENTA_E_NOVE);
	        cal.add(Calendar.SECOND, Constants.CINQUENTA_E_NOVE);
	        Date dataFim = cal.getTime();
	
	        String strQuery = "SELECT p FROM " + getEntityClass().getSimpleName() + " p "
	                + "WHERE p.id.cdBnco =:cdBnco "
	        		+ "AND p.id.dtMvmnArqvBnco >= :dtMvmnArqvBncoIni  "
	        		+ "AND p.id.dtMvmnArqvBnco <= :dtMvmnArqvBncoFim "
	                + "AND p.id.nuRmsaArqvBnco= :nuRmsaArqvBnco "
	        		+ "AND p.id.nuLnhaRgstArqvBnco= :nuLnhaRgstArqvBnco";
	        
	        TypedQuery<ProcessamentoRegistroArquivo> query = getEntityManager().createQuery(strQuery, ProcessamentoRegistroArquivo.class);
	        query.setParameter("cdBnco", id.getCdBnco());
	        query.setParameter("dtMvmnArqvBncoIni", dataInicio);
	        query.setParameter("dtMvmnArqvBncoFim", dataFim);
	        query.setParameter("nuRmsaArqvBnco", id.getNuRmsaArqvBnco());
	        query.setParameter("nuLnhaRgstArqvBnco", id.getNuLnhaRgstArqvBnco());
        
    	    ProcessamentoRegistroArquivo entity = query.getSingleResult();
    	    
    	  return entity;
    	  
      }catch(Exception e){
    	  LOG.error("NAO HA PROSPECT CADASTRADO");
    	  return null;
      }
	}

	@Override
	public void expurgoRegistrosProcessados() {
		LOG.info("DAO - EXECUCAO ROTINA DE EXPURGO TABELA WORK");
		try{
			StringBuilder sql = new StringBuilder("DELETE FROM TBCRDW_PCSM_RGST_CDST_ATUL ");
									   sql.append("WHERE DT_MVMN_ARQV_BNCO < SYSDATE - 90");	
			Query query = getEntityManager().createNativeQuery(sql.toString());
			query.executeUpdate();			
			
		}catch(Exception ex){
			LOG.error("ERROR EXECUCAO ROTINA DE EXPURGO TABELA WORK {}", ex);
		}
	}


}
