package br.com.cielo.credenciamento.crd.service.impl;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.enun.SitProcRegistroArquivoEnum;
import br.com.cielo.credenciamento.crd.enun.StatusCredenciamento;
import br.com.cielo.credenciamento.crd.exception.CredenciarClienteException;
import br.com.cielo.credenciamento.crd.service.IConsistenciasInfoOsbService;
import br.com.cielo.credenciamento.crd.service.osb.IServicesCredenciamento;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.Proprietario;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.domain.batch.Telefone;
import br.com.cielo.credenciamento.model.Critica;
import br.com.cielo.credenciamento.model.Criticas;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.ISituacaoProcessRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivoPK;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.BancoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CampoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CriticaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DadosProprietarioType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DomiciliosBancarios;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EnderecoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EstabelecimentoComercialType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucaoCapturaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucoesCaptura;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.TelefoneType;

/**
 * Classe responsavel por popular as informações da request na chamado do serviço OSB
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class ConsistenciasInfoOsbServiceImpl implements IConsistenciasInfoOsbService{

	private static final Logger LOG = LoggerFactory.getLogger(ConsistenciasInfoOsbServiceImpl.class);

	@Inject
	private IServicesCredenciamento servicesCredenciamento;

	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroArquivoDAO;
    
    @Inject
    private ISituacaoProcessRegistroArquivoDAO sitProcRegArquivoDAO;

    private Criticas criticas;

	//DOMINIOS 
	private final Integer FERRAMENTA_BANCOS = 2;	
	private final Integer TELEFONE_COMERCIAL = 2;
	private final Integer TELEFONE_CELULAR = 3;	
	private final Integer ENDERECO_COMERCIAL = 2;
	private final Integer ENDERECO_CORRESPONDECIA = 3;

	@Override
	public void efetivarCredenciamentoOSB(Prospect proposta, Criticas criticas) {
		LOG.info("INIT - CREDENCIAMENTO VIA SERVICO OSB (RL01)");
		try{
			 CredenciarClienteRequest request = popularInfo(proposta);
			 CredenciarClienteResponse response = efetivarCredenciamentoOSB(request);
			 //LISTA DE CRITICAS "DE/PARA" SEC LAYOUT DE BANCOS
			 this.criticas = criticas;
			 tratarCredenciamentoResponse(proposta, response);

		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO AO CREDENCIAR VIA SERVICO OSB {}", ex);
			throw new CredenciarClienteException("ERRO CREDENCIAR CLIENTE", ex);
		}
	}

	/**
	 * Método responsavel pela efetivação do credenciamento
	 * @param request
	 * @return 
	 */
	private CredenciarClienteResponse efetivarCredenciamentoOSB(CredenciarClienteRequest request) {
		try {
			return servicesCredenciamento.credenciarClienteOSB(request);
			
		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO EFETIVAR O CREDENCIAMENTO {}", ex);
			throw new RuntimeException("ERRO CHAMADA SERVICO CREDENCIAMENTO", ex);
		}		
	}

	/**
	 * Método responsavel por popular as informações de Request
	 * @param request
	 * @param proposta
	 */
	private CredenciarClienteRequest popularInfo(Prospect proposta) {
		CredenciarClienteRequest request = new CredenciarClienteRequest();
		request.setCodigoFerramenta(FERRAMENTA_BANCOS);
		request.setIndicadorAgro(proposta.getIndicadorAgro());
		request.setCorrelationID(proposta.getCorrelationId());		
		//POPULAR AS INFORMACOES DE ESTABELECIMENTO COMERCIAL
		popularEstabelecimentoComercial(request, proposta);
		//POPULAR AS INFORMACOES DE SOLUCAO DE CAPTURA
		popularSolucoesCaptura(request, proposta);
		
		return request;
	}
	
	
	/**
	 * Método responsavel por popular as informações de estabelecimento comercial
	 * @param request
	 * @param infoCredenciamento
	 */
	private void popularEstabelecimentoComercial(CredenciarClienteRequest request, Prospect proposta) {
		EstabelecimentoComercialType estabelecimento = new EstabelecimentoComercialType();
		popularInfoCliente(estabelecimento, proposta);
		popularEnderecos(estabelecimento, proposta);
		popularDomicilioBancario(estabelecimento, proposta);
		popularProprietarios(estabelecimento, proposta);
		popularTelefones(estabelecimento, proposta);
		request.setEstabelecimentoComercial(estabelecimento);
	}
	

	/**
	 * Método responsavel por popular as informações do cliente
	 * @param estabelecimento
	 * @param infoCredenciamento
	 */
	private void popularInfoCliente(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		estabelecimento.setCodigoAfiliador(0l);
		estabelecimento.setCodigoRamoAtividade(Integer.valueOf(proposta.getRamoAtividade()));
		estabelecimento.setCodigoTipoPessoa(proposta.getTipoPessoa());
		estabelecimento.setCodigoTipoPlanoCielo(Integer.valueOf(proposta.getCodTipoPlano()));
		//estabelecimento.setDataAtivacao(dataAtivacao); OPCIONAL
		estabelecimento.setEmailContato(proposta.getEmail());		
		//estabelecimento.setIndicadorCadastroDuplicado(indicadorCadastroDuplicado); OPCIONAL
		//estabelecimento.setIndicadorEstabComercialMigrado(indicadorEstabComercialMigrado);OPCIONAL
		estabelecimento.setIndicadorMicroEmpreendedorIndividual(proposta.getMei());
		estabelecimento.setNomeFantasia(proposta.getNomeFantasia());
		estabelecimento.setNomePessoaContato(proposta.getPessoaContato());
		estabelecimento.setNomePlaqueta(proposta.getNomePlaqueta());
		estabelecimento.setNomeRazaoSocial(proposta.getRazaoSocial());
		estabelecimento.setNumeroCpfCnpj(Long.valueOf(proposta.getCpfCnpj()));
		//estabelecimento.setNumeroEc(numeroEc);OPCIONAL
		//estabelecimento.setNumeroInscricaoEstadual(numeroInscricaoEstadual);OPCIONAL
		estabelecimento.setQuantidadeDiasLiquidacao(Integer.valueOf(proposta.getQtdadeDiasLiquidacao()));
		estabelecimento.setValorMedioFaturamento(BigDecimal.valueOf(Long.valueOf(proposta.getValorFaturamento())));
	}

	/**
	 * Método responsavel por popular as informações de Endereço
	 * @param estabelecimento
	 * @param infoCredenciamento
	 */
	private void popularEnderecos(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		List<EnderecoType> listaEnderecos = new ArrayList<>();
		listaEnderecos.add(popularEnderecoComercial(proposta));
		listaEnderecos.add(popularEnderecoCorrespondecia(proposta));

		EnderecoType[] enderecosArray = new EnderecoType[listaEnderecos.size()];
		estabelecimento.setEnderecosEstabelecimento(listaEnderecos.toArray(enderecosArray));
	}

	/**
	 * Método responsavel por popular as informações de Endereco Comercial
	 * @param proposta
	 * @return EnderecoType
	 */
	private EnderecoType popularEnderecoComercial(Prospect proposta) {
		EnderecoType enderecoComercial = new EnderecoType();		
		enderecoComercial.setTipoEndereco(ENDERECO_COMERCIAL);
		enderecoComercial.setNomeLogradouro(proposta.getEnderecoEstabelecimento().getLogradouro());
		enderecoComercial.setDescricaoComplementoEndereco(proposta.getEnderecoEstabelecimento().getComplementoLogradouro());
		enderecoComercial.setNumeroLogradouro(proposta.getNumEnderComercial());
		enderecoComercial.setNomeCidade(proposta.getEnderecoEstabelecimento().getCidade());
		enderecoComercial.setNomeBairro("");//OPCIONAL NAO EXISTE NO LAYOUT DE BANCOS
		enderecoComercial.setSiglaEstado(proposta.getEnderecoEstabelecimento().getEstado());
		enderecoComercial.setNumeroCEP(Integer.valueOf(proposta.getEnderecoEstabelecimento().getCep()));
		return enderecoComercial;
	}

	/**
	 * Método responsavel por popular as informações de Endereco Correspondencia
	 * @param proposta
	 * @return EnderecoType
	 */
	private EnderecoType popularEnderecoCorrespondecia(Prospect proposta) {
		EnderecoType enderecoCorrespondecia = new EnderecoType();		
		enderecoCorrespondecia.setTipoEndereco(ENDERECO_CORRESPONDECIA);
		enderecoCorrespondecia.setNomeLogradouro(proposta.getEnderecoCorrespondencia().getLogradouro());
		enderecoCorrespondecia.setDescricaoComplementoEndereco(proposta.getEnderecoCorrespondencia().getComplementoLogradouro());
		enderecoCorrespondecia.setNumeroLogradouro(proposta.getNumEnderCorrespondecia());
		enderecoCorrespondecia.setNomeCidade(proposta.getEnderecoCorrespondencia().getCidade());
		enderecoCorrespondecia.setNomeBairro("");//OPCIONAL NAO EXISTE NO LAYOUT DE BANCOS
		enderecoCorrespondecia.setSiglaEstado(proposta.getEnderecoCorrespondencia().getEstado());
		enderecoCorrespondecia.setNumeroCEP(Integer.valueOf(proposta.getEnderecoCorrespondencia().getCep()));
		return enderecoCorrespondecia;
	}

	/**
	 * Método responsavel por popular as informações de Domicilios Bancários
	 * @param estabelecimento
	 * @param infoCredenciamento
	 */
	private void popularDomicilioBancario(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		DomiciliosBancarios domicilios = new DomiciliosBancarios();
		BancoType bancoType = new BancoType();
		bancoType.setCodigoBanco(proposta.getBanco());
		bancoType.setNumeroAgencia(proposta.getDadosBancarios().getCodigoAgencia());
		bancoType.setNumeroContaCorrente(proposta.getDadosBancarios().getNumeroContaCorrente());
		bancoType.setTipoConta(proposta.getTipoConta());
		domicilios.setDomicilioBancario(bancoType);
		estabelecimento.setDomiciliosBancarios(domicilios);
	}

	/**
	 * Método responsavel por popular as informações d eproprietarios
	 * @param estabelecimento
	 * @param infoCredenciamento
	 */
	private void popularProprietarios(EstabelecimentoComercialType estabelecimento,	Prospect proposta) {
		List<DadosProprietarioType> listaProprietarios = new ArrayList<DadosProprietarioType>();
		for (Proprietario proprietario : proposta.getProprietarios()) {
			DadosProprietarioType proprietarioType = new DadosProprietarioType();
			proprietarioType.setNome(proprietario.getNomeProprietario());
			proprietarioType.setNumeroCpf(proprietario.getCpfProprietario());
			proprietarioType.setDataNascimento(tratarDataNascimento(proprietario.getDataNascimentoProprietario()));
			listaProprietarios.add(proprietarioType);
		}

		DadosProprietarioType[] proprietariosArray = new DadosProprietarioType[listaProprietarios.size()];
		estabelecimento.setProprietarios(listaProprietarios.toArray(proprietariosArray));
	}
	
	/**
	 * Método responsavel por tratar a data de nascimento
	 * @param dataNascimento
	 * @return
	 */
	private String tratarDataNascimento(String dataNascimento){		
		if(!CrdUtils.isNumberAndNotZeros(dataNascimento)){
			return dataNascimento =  "0001-01-01";
		
		}else{
        
			DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	        String dataFormatada = null;
	        try {
	            dataFormatada = sdf.format(new SimpleDateFormat("ddMMyy").parse(dataNascimento));
	        } catch (Exception ex) {
	            LOG.error(" ERRO FORMATANDO A DATA DE NASCIMENTO DO(S) PROPRIETARIO(S) {}" + ex);
	        }
	        return dataFormatada;
		}
	}

	/**
	 * Método responsavel por popular as informações de telefones
	 * @param estabelecimento
	 * @param infoCredenciamento
	 */
	private void popularTelefones(EstabelecimentoComercialType estabelecimento, Prospect proposta) {
		
		
		List<TelefoneType> listaTelefones = new ArrayList<TelefoneType>();
		Integer tipoTelefone = TELEFONE_COMERCIAL;
		for (Telefone telefone : proposta.getTelefones()) {
			//TELEFONE COMERCIAL AND CELULAR
			TelefoneType telefoneType = new TelefoneType();
			telefoneType.setTipoTelefone(tipoTelefone); //COMERCIAL
			telefoneType.setNumeroDDD(Integer.valueOf(telefone.getDdd()));
			telefoneType.setNumeroTelefone(telefone.getNumero());
			listaTelefones.add(telefoneType);
			tipoTelefone = TELEFONE_CELULAR;			
		}
		
		TelefoneType[] telefonesArray = new TelefoneType[listaTelefones.size()];
		estabelecimento.setTelefonesEstabelecimento(listaTelefones.toArray(telefonesArray));
	}

	
	
	/**
	 * Método responsavel por popular as informações de soluções de captura
	 * @param request
	 * @param infoCredenciamento
	 */
	private void popularSolucoesCaptura(CredenciarClienteRequest request, Prospect proposta) {
		SolucoesCaptura solucoes = new SolucoesCaptura();
		SolucaoCapturaType solucao = new SolucaoCapturaType();
		solucao.setCodigoSolucaoCaptura(Integer.valueOf(proposta.getSolucaoCaptura()));
		solucao.setCodigoPacoteEcommerce(proposta.getCodPacoteEcommerce());
		solucao.setQuantidadeEquipamentos(1);
		solucoes.setSolucaoCaptura(solucao);
		request.setSolucoesCaptura(solucoes);
	}

	/**
	 * Método responsavel por tratar o retorno da chamada do serviço de credenciamento RL01
	 * @param proposta 
	 * @param response
	 */
	private void tratarCredenciamentoResponse(Prospect proposta, CredenciarClienteResponse response) {
		String codigoStatus = response.getCodigoStatus();
		proposta.setNumeroProposta(response.getNumeroProposta().toString());

		if(codigoStatus.equals(StatusCredenciamento.SUCESSO.getCodigo())){
			String numeroEc = response.getNumeroEc().toString();
			proposta.setNumeroEstabelecimento(response.getNumeroEc().toString());
			atualizarPropostaSucesso(proposta.getCorrelationId(), numeroEc);
		
		}else if(codigoStatus.equals(StatusCredenciamento.REJEITADA.getCodigo())){
			atualizarPropostaRejeitada(proposta.getCorrelationId(), response.getCriticas());
			
		}else if(codigoStatus.equals(StatusCredenciamento.REJEITADA_FALHA_SISTEMICA.getCodigo())){
			atualizarPropostaError(proposta.getCorrelationId());
		}
	}
	
	
	/**
	 * Método responsavel por atualizar o status da proposta na tabela wrk (2-Em processamento --> 4-Acatado)
	 * @param correlation
	 */
	private void atualizarPropostaSucesso(String correlationId, String numeroEc){
		ProcessamentoRegistroArquivo entity = getProspect(correlationId);
		entity.setNuEc(numeroEc);
		entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.ACATADO.getCodigoSituacaoProposta()));
	}
	
	/**
	 * Método responsavel por atualizar as informações de criticas no prospect
	 * @param correlationId
	 * @param criticaTypes
	 * @param criticas
	 */
	private void atualizarPropostaRejeitada(String correlationId, CriticaType[] criticaTypes){
		ProcessamentoRegistroArquivo entity = getProspect(correlationId);
		entity.setCdErroVldcArqv(CrdUtils.PROPOSTA_REJEITADA);
		entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.REJEITADO.getCodigoSituacaoProposta()));

		List<Critica> listaCriticas = new ArrayList<>();
		for (CriticaType critica : Arrays.asList(criticaTypes)) {			
			for(CampoType campo : critica.getCampos()){
				listaCriticas.add(CrdUtils.getCriticasSec(criticas, critica.getCodigoCritica(), Integer.valueOf(campo.getReferenciaSequenciaCampo())));
			}
		}
		CrdUtils.popularCriticas(entity, listaCriticas);		
	}
	
	/**
	 * Método responsavel por atualizar as porpostas que foram rejeitadas por falha sistemica
	 * @param correlationId
	 */
	private void atualizarPropostaError(String correlationId) {
		ProcessamentoRegistroArquivo entity = getProspect(correlationId);
		entity.setCdErroVldcArqv(CrdUtils.PROPOSTA_FALHA_SISTEMICA);
		entity.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.FALHA_SISTEMICA.getCodigoSituacaoProposta()));
	}
	
	
	
	/**
	 * Método responsavel por obter a entidade de prospect
	 * @param correlationId
	 * @return
	 */
	private ProcessamentoRegistroArquivo getProspect(String correlationId){
		String[] infoCorrelation = getInfoCorrelation(correlationId);
		ProcessamentoRegistroArquivoPK pk = popularInfoProspectPk(infoCorrelation);
		return (procRegistroArquivoDAO.findById(pk));
	}

	/**
	 * Método responsavel pelo parse do correlation ID
	 * @param correlationId
	 * @return
	 */
	private String[] getInfoCorrelation(String correlationId){
		return correlationId.split(";");
	}
	
	/**
	 * Método responsavel por popular as informações na entidade de complemento proposta
	 * @param infoProposta
	 * @param numeroProposta 
	 * @return 
	 */
	private ProcessamentoRegistroArquivoPK popularInfoProspectPk(String[] correlation) {
		ProcessamentoRegistroArquivoPK pk = new ProcessamentoRegistroArquivoPK();
		pk.setCdBnco(Integer.valueOf(correlation[CrdUtils.INDEX_BANCO]));
		pk.setDtMvmnArqvBnco(CrdUtils.getDataMovimento(correlation[CrdUtils.INDEX_DATA_MOVIMENTO]));
		pk.setNuRmsaArqvBnco(Integer.valueOf(correlation[CrdUtils.INDEX_REMESSA]));
		pk.setNuLnhaRgstArqvBnco(Integer.valueOf(correlation[CrdUtils.INDEX_LINHA]));		
		return pk;
	}
	

}
