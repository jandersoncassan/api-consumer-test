package br.com.cielo.credenciamento.crd.service;

import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.model.Criticas;

/**
 * Interface responsavel por consistir as informações de request na chamada do serviço do CRD *direto* contingencia
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public interface IConsistenciasInfoCrdService {

	/**
	 * Método responsavel por popular as informações de proposta e efetuar as consistências de efetivação / tratamento de crtiticas.
	 * @param proposta
	 * @param criticas
	 */
	void efetivarCredenciamentoCRD(Prospect proposta, Criticas criticas);
}
