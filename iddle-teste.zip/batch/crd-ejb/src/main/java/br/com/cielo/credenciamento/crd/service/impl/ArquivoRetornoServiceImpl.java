package br.com.cielo.credenciamento.crd.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.enun.SitProcRegistroArquivoEnum;
import br.com.cielo.credenciamento.crd.service.IArquivoRetornoService;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.Arquivo;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.remote.IArquivoRetornoServiceRemote;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.ISituacaoProcessRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.entity.LogControleCargaBanco;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;

/**
 * Classe responsavel pela implementação dos serviços de tratamento / geração do arquivo de retorno
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless(name = "ArquivoRetornoService", mappedName = "ArquivoRetornoService")
public class ArquivoRetornoServiceImpl implements IArquivoRetornoService, IArquivoRetornoServiceRemote{

	private static final Logger LOG = LoggerFactory.getLogger(ArquivoRetornoServiceImpl.class);

	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroDAO;
	
	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroArquivoDAO;
	
    @Inject
    private ISituacaoProcessRegistroArquivoDAO sitProcRegArquivoDAO;
	
	@Override
	public List<Arquivo> tratarArquivoRetorno(String codigoBanco) {
 		LOG.info("INIT - GERACAO ARQUIVO RETORNO - BANCO {}", codigoBanco); 
 		try{
 			return initArquivoRetorno(codigoBanco);
 			
 		}catch(Exception ex){
 			LOG.error("OCORREU UM ERRO NO PROCESSO DE GERACAO DO ARQUIVO DE RETORNO {}", ex);
 			return null;
 		}
	}

	/**
	 * Método responsavel por iniciar o tratamento e consistências para geração do arquivo de retorno
	 * @param codigoBanco
	 * @return
	 */
	private List<Arquivo> initArquivoRetorno(String codigoBanco) {
		//ATUALIZA OS CONTADORES DA REMESSA DE BANCOS
		atualizarContadoresRemessa(codigoBanco);
		//EFETUA A ATUALIZACAO DO STATUS DO REGISTRO CONCLUIDO
		concluirArquivos(codigoBanco);
		//BUSCA A LISTA DE ARQUIVOS/REMESSAS QUE PRECISAM SER DEVOLVIDOS PARA OS BANCOS
		return obterListaRemessasArquivos(codigoBanco);
	}


	/**
	 * Método responsavel por efetuar a atualização dos contadores (Acatados e Rejeitados) tbl controle de carga
	 * @param codigoBanco 
	 */
	private void atualizarContadoresRemessa(String codigoBanco){
		procRegistroDAO.atualizarContadoresRemessa(codigoBanco);
	}
	
	/**
	 * Método responsavel por efetivar a conclusão e fechamento dos registros (4-Acatado --> 6-Processado)
	 * @param codigoBanco 
	 * @param codigoBanco
	 * @return
	 */
	private void concluirArquivos(String codigoBanco){
		List<ProcessamentoRegistroArquivo> listaArquivosConcluidos = getListaArquivosConcluidos(codigoBanco);
		for (ProcessamentoRegistroArquivo registro : listaArquivosConcluidos) {
			registro.setSituacaoRegistro(sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.PROCESSADO.getCodigoSituacaoProposta()));
		}
	}
	
	/**
	 * Método responsavel por obter a lista de arquivos / remessas para serem devolvidas para os bancos
	 * @param codigoBanco
	 * @return
	 */
	private List<Arquivo> obterListaRemessasArquivos(String codigoBanco) {
		List<Arquivo> listaArquivos = new ArrayList<>();
		List<LogControleCargaBanco> listaRemessas = getListaRemessasArquivos(codigoBanco);
		for (LogControleCargaBanco remessa : listaRemessas) {	
			
			Arquivo arquivo = new Arquivo();
			for (ProcessamentoRegistroArquivo entityProposta : remessa.getListaRegistroArquivo()) {
				arquivo.getProspects().add(popularProposta(entityProposta));				
			}
			listaArquivos.add(arquivo);
			
			remessa.setInArqvActd("S");
			remessa.setDhAltrRgst(new Date());
			remessa.setCdUsroAltrRgst("CRDUSR");
		}
		return listaArquivos;
	}

	/**
	 * Método responsavel por popular as informações da proposta
	 * @param entityProposta
	 * @return
	 */
	private Prospect popularProposta(ProcessamentoRegistroArquivo entityProposta) {
		return (CrdUtils.popularEntityToProposta(entityProposta));
	}

	
	/**
	 * Método responsavel por obetr a lista de registros concluidos
	 * @param codigoBanco 
	 * @return 
	 */
	private List<ProcessamentoRegistroArquivo> getListaArquivosConcluidos(String codigoBanco){
		return procRegistroArquivoDAO.obterListaRegistrosConcluidos(codigoBanco);
	}
	
	
	/**
	 * Método responsavel por obter a lista de remessas para serem devolvidas para os bancos
	 * @param codigoBanco
	 * @return
	 */
	private List<LogControleCargaBanco> getListaRemessasArquivos(String codigoBanco){
		return procRegistroArquivoDAO.obterListaRemessasArquivos(codigoBanco);
	}
}
