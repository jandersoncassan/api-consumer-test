package br.com.cielo.credenciamento.crd.service.impl;

import java.util.Date;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.service.IControleIncidenteService;
import br.com.cielo.credenciamento.crd.service.ICredenciamentoService;
import br.com.cielo.credenciamento.crd.service.ICredenciarClienteService;
import br.com.cielo.credenciamento.crd.service.IPropostaCredenciamentoService;
import br.com.cielo.credenciamento.crd.service.IValidacaoInfoPropostaService;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.remote.ICredenciamentoServiceRemote;
import br.com.cielo.credenciamento.persistence.dao.IArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;

/**
 * Classe responsavel pela implementação dos serviços de integração com a release 01
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless(name = "CredenciamentoService", mappedName = "CredenciamentoService")
public class CredenciamentoServiceImpl implements ICredenciamentoService, ICredenciamentoServiceRemote {

	private static final Logger LOG = LoggerFactory.getLogger(CredenciamentoServiceImpl.class);
	
	@Inject
	private IValidacaoInfoPropostaService validacaoService;
	
	@Inject
	private IPropostaCredenciamentoService propostaCredenciamentoService;	
	
	@Inject
	private ICredenciarClienteService credenciarClienteService;

    @Inject
    private IArquivoDAO arquivoDAO;
    
	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroArquivoDAO;

    @Inject
    private IControleIncidenteService controleIncidenteService;
    
 	@Override
	public Prospect invocarServicoCredenciamento(final Prospect prospect, final Integer codigoBanco, final Integer numeroRemessa, final Date dataExecucao) {
 		LOG.info("INIT - INVOKE SERVICE RL01"); 
 		try{
 			initCredenciamento(prospect, codigoBanco, numeroRemessa, dataExecucao);
 			
 		}catch(Exception ex){
 			LOG.error("OCORREU UM ERRO NO PROCESSO DE CREDENCIAMENTO {} ", ex);
 			//AO OCORRER UMA EXCECAO PRECISAMOS ABRIR UM INCIDENTE PARA TRATAMENTO
 			controleIncidenteService.incluirIncidente(getInfoIncidente(prospect, ex.toString()));
 		}
		return prospect;
	}
 	
 	/**
 	 * Método responsavel por executar o fluxo de credenciamento
 	 * @param infoProspect
 	 * @throws NamingException 
 	 */
 	private void initCredenciamento(final Prospect prospect, final Integer codigoBanco, final Integer numeroRemessa, final Date dataExecucao) throws NamingException{ 		
 		//TIPO DE LAYOUT (ATUAL | NOVO) 
 		tratarTipoLayout(prospect); 		
 		//TRATAMENTO COD MENSAGEM E CODIGO BANCO
 		tratarCodMensagemCodBanco(prospect);
 		//INFORMACOES REMESSA / ARQUIVOS
 		Integer numLinha = getNumeroLinha(codigoBanco, dataExecucao, numeroRemessa);	
 		//GERAMOS O CORRELATIONID PARA RASTREABILIDADE DA PROPOSTA
 		popularCorrelationId(codigoBanco, dataExecucao, numeroRemessa, numLinha, prospect);
 		//PERSISTENCIA DAS INFORMACOES NA TABELA WORK E CONTROLE DE CARGA BANCOS
 		persistirProspect(prospect, dataExecucao, codigoBanco, numeroRemessa, numLinha); 	
 		//SEGUIMOS PARA PROCESSAMENTO SOMENTE SE NAO HAVER PROBLEMAS NO LAYOUT
 		if(prospect.isValido()){
	 		//TRATAMENTO VALIDAÇÃO FISICA
	 		tratarProspect(prospect);	
	 		//INCLUSÃO DA PROPOSTA VIA SERVIÇO CRD RELEASE 01
	 		efetivarCredenciamento(prospect); 	
 		}
 	}

 	/**
 	 * Tratamento para validação da mensagem do layout "045" e codigo do banco <> "zeros"
 	 * @param infoProspect
 	 */
	private void tratarCodMensagemCodBanco(final Prospect prospect) {		
		if(!prospect.getCodigoMensagem().equals(CrdUtils.CODIGO_MENSAGEM)){
			//REJEITAMOS O REGISTRO NA TABELA WRK COD 98
			prospect.setCodigoErro(CrdUtils.CODIGO_REJEICAO_MENSAGEM);
			prospect.setValido(Boolean.FALSE);

		}else if(!CrdUtils.isNumberAndNotZeros(prospect.getBanco())){
			//REJEITAMOS O REGISTRO NA TABELA WRK COD 07
			prospect.setCodigoErro(CrdUtils.CODIGO_REJEICAO_BANCO);
			prospect.setValido(Boolean.FALSE);

		}else{
			prospect.setValido(Boolean.TRUE);
		}
	}

	/**
	 * Método responsavel pela inclusão do prospect nas tabelas de Carga Banco e Tabela Work
	 * 
	 * @param infoProspect
	 * @param codigoBanco
	 * @param numRemessa
	 * @param numLinha
	 * @return 
	 */
	private void persistirProspect(final Prospect prospect, final Date dataExecucao, final Integer codigoBanco, final Integer numRemessa, final Integer numLinha){
		LOG.info("INIT - INCLUIR PROSPECT");		
		propostaCredenciamentoService.incluirProspect(prospect, dataExecucao, codigoBanco, numRemessa, numLinha);
	}

	/**
 	 * Método responsavel por tratar as informações de prospect
 	 * @param infoProspect
 	 */
	private void tratarProspect(final Prospect prospect) {
 		LOG.info("INIT - TRATAR PROSPECT");
		executarTratamentoTipagemCampos(prospect);
		tratarTipoProcessamento(prospect);
	}

	/**
	 * Método responsavel por garantir a tipagem dos campos antes de chamar o serviço da release 01 'validação fisica'
	 * @param infoProspect
	 */
	private void executarTratamentoTipagemCampos(final Prospect prospect){
		validacaoService.tratarTipagemCampos(prospect);
	}
	
	/**
	 * Método responsavel
	 * @param infoProspect
	 */
	private void tratarTipoProcessamento(final Prospect prospect){
		validacaoService.tratarTipoProcessamento(prospect);
	}


	/**
	 * Método responsavel pelo invoke do serviço de credenciamento
	 * @param infoProspect
	 */
 	private void efetivarCredenciamento(final Prospect prospect){		
 		credenciarClienteService.credenciarCliente(prospect);
	}
 	
 	/**
	 * Método responsavel por "montar" o correlationID
	 * 
	 * @param codigoBanco
	 * @param dataExecucao
	 * @param numRemessa
	 * @param numLinha
	 * @return
	 */
	private void popularCorrelationId(final Integer codigoBanco, final Date dataExecucao, final Integer numRemessa, final Integer numLinha, final Prospect prospect){
        prospect.setCorrelationId(CrdUtils.popularCorrelationId(codigoBanco, dataExecucao, numRemessa, numLinha));
	}


	/**
	 * Método responsavel por obter o numero da remessa de processamento
	 * @param dataExecucao
	 * @param codigoBanco
	 * @return
	 * @throws NamingException
	 */
	@Override
    public Integer getNumeroRemessa(final Date dataExecucao, final Integer codigoBanco) throws NamingException {
         return (arquivoDAO.findNextNumRemessa(dataExecucao, codigoBanco));
     }

    /**
     * Método responsavel por obter o numero da linha da remessa
     * @param codigoBanco
     * @param dataExecucao
     * @param numeroRemessa2
     * @return
     */
	private Integer getNumeroLinha(final Integer codigoBanco, final Date dataExecucao, Integer numeroRemessa) {
		return (procRegistroArquivoDAO.getNextLinha(codigoBanco, dataExecucao, numeroRemessa));
	}
	
	/**
	 * Método responsavel por popular o tipo de layout da remessa
	 * @param prospect
	 */
	private void tratarTipoLayout(final Prospect prospect){
		 boolean isLayoutNovo = CrdUtils.isLayoutNovo(prospect.getCodTipoPlano(), prospect.getSolucaoCaptura());
		 LOG.info("LAYOUT NOVO ? {}", isLayoutNovo);
		 prospect.setLayoutNovo(isLayoutNovo);
	}

	/**
	 * Método responsavel por popular as informações para abertura de incidente
	 * @param proposta
	 * @return Incidente
	 */
	private Incidente getInfoIncidente(Prospect proposta, String cause){
		Incidente incidente = new Incidente();		
		String [] correlation = proposta.getCorrelationId().split("\\;");
		incidente.setCodigoBanco(Integer.valueOf(correlation[CrdUtils.INDEX_BANCO]));
		incidente.setDataMovimento(CrdUtils.getDataMovimento(correlation[CrdUtils.INDEX_DATA_MOVIMENTO]));
		incidente.setNumeroRemessa(Integer.valueOf(correlation[CrdUtils.INDEX_REMESSA]));
		incidente.setNumeroLinha(Integer.valueOf(correlation[CrdUtils.INDEX_LINHA]));
		incidente.setDescricaoErro(cause);
		
		return incidente;		
	}
	
	@Override
	public void retomarIncidente(Incidente incidente) {
		controleIncidenteService.retomarIncidente(incidente);
	}
	
	@Override
	public void tratarProspectRetomada(Prospect proposta) {
		LOG.info("INIT TRATAMENTO RETOMADA PROPOSTA");
		tratarProspect(proposta);
	}
	
	@Override
	public void cleanAndUpdateInfo(final Integer codigoBanco, final Integer numeroRemessa, final Date dataExecucao, final Integer totalRegistros){
		propostaCredenciamentoService.atualizarTotalLinhaRemessa(dataExecucao, codigoBanco, numeroRemessa, totalRegistros);		
		credenciarClienteService.limparListaCriticas();		
	}
	
}
