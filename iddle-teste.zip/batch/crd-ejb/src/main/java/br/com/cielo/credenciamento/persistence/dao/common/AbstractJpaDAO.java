package br.com.cielo.credenciamento.persistence.dao.common;

import java.io.Serializable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.beans.factory.annotation.Value;

/**
 * Classe JPA abstract Generics DAO
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public abstract class AbstractJpaDAO<T extends Serializable> {

    private final Class<T> clazz;

   
    /**
     * Gerador de identificador JDBC para processamento de lote.
     */
    @Value("${hibernate.jdbc.batch_size}")
    private int batchSize;
    
    
    /**
     * Instancia da classe EntityManager para comunicacao com a base de dados.
     */
    @PersistenceContext(unitName = "CredenciamentoPU")
    protected EntityManager entityManager;

    /**
     * Construtor da Classe AbstractJpaDAO.
     * 
     * @param clazz para classe generica
     */
    public AbstractJpaDAO(final Class<T> clazz) {
        this.clazz = clazz;
    }

    /**
     * Método de busca por id.
     * 
     * @param id para busca na base de dados
     * @return uma classe entidade.
     */
    public T findOne(final long id) {
        return this.entityManager.find(this.clazz, id);
    }

    /**
     * Método de busca por id.
     * 
     * @param id para busca na base de dados
     * @return uma classe entidade.
     */
    public T findOne(final Serializable id) {
        return this.entityManager.find(this.clazz, id);
    }

    /**
     * Método de busca de uma lista.
     * 
     * @return uma lista de uma classe entidade
     */
    @SuppressWarnings("unchecked")
    public List<T> findAll() {
        return this.entityManager.createQuery("from " + this.clazz.getName()).getResultList();
    }

    /**
     * Busca uma lista da entidade com base no filtro passado.
     * 
     * @param params parâmetros para serem usados no filtro.
     * @return uma lista de uma classe entidade.
     */
    @SuppressWarnings("unchecked")
    public List<T> findAllBy(final Map<String, Object> params) {
        StringBuilder builder = new StringBuilder();

        builder.append("from ").append(this.clazz.getName()).append(" where ");

        int contadorDeFiltros = 0;

        Iterator<String> nomesDosCampos = params.keySet().iterator();

        while (nomesDosCampos.hasNext()) {
            String nomeDoCampo = nomesDosCampos.next();

            Object valorDoCampo = params.get(nomeDoCampo);

            if (contadorDeFiltros++ == 0) {
                builder.append(nomeDoCampo).append(" = ").append(valorDoCampo);
            } else {
                builder.append("and ").append(nomeDoCampo).append(" = ").append(valorDoCampo);
            }
        }

        Query query = this.entityManager.createQuery(builder.toString());

        return query.getResultList();
    }

    /**
     * Método para inserir na base de dados.
     * 
     * @param entity classe entidade
     * @return uma classe entidade
     */
    public T create(final T entity) {
        this.entityManager.persist(entity);
        this.entityManager.flush();
        return entity;
    }

    /**
     * Método para inserir uma lista de dados.
     * 
     * @param entities lista de entidades
     * @return uma lista de entidades
     */
    public List<T> createAll(final List<T> entities) {
        int i = 0;

        for (T t : entities) {
            this.entityManager.persist(t);

            if (++i % this.batchSize == 0) {
                this.entityManager.flush();
                this.entityManager.clear();
            }
        }

        return entities;
    }

    /**
     * Método que atualiza a base de dados.
     * 
     * @param entity classe entidade
     * @return uma entidade
     */
    public T update(final T entity) {
    	final T entidade = this.entityManager.merge(entity);
        this.entityManager.flush();
        return entidade;
    }

    /**
     * Método que deleta dados na base.
     * 
     * @param entity classe entidade
     */
    public void delete(final T entity) {
        this.entityManager.remove(entity);
        this.entityManager.flush();
    }

    /**
     * Método que deleta dados a partir de uma id.
     * 
     * @param entityId id da classe entidade
     */
    public void deleteById(final long entityId) {
        T entity = findOne(entityId);
        delete(entity);
    }

    /**
     * Método get do atributo entityManager
     * 
     * @return O valor do atributo entityManager
     */
    public EntityManager getEntityManager() {
        return this.entityManager;
    }

    /**
     * Método set do atributo entityManager
     * 
     * @param entityManager Valor para setar no atributo entityManager
     */
    public void setEntityManager(final EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    
    /**
     * Método que retorna o .class da Classe
     * @return Class .class
     */
    @SuppressWarnings("rawtypes")
    public Class getEntityClass() {
        return this.clazz;
    }

}
