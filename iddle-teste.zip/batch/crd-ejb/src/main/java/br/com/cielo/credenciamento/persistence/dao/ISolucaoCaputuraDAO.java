package br.com.cielo.credenciamento.persistence.dao;

import java.util.List;

import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.SolucaoCaptura;

/**
 * Interface responsavel pela implementação das consistências de atualização das informações de equipamentos
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface ISolucaoCaputuraDAO extends IOperations<SolucaoCaptura> {


	/**
	 * Método responsavel por recuperar as informações dos equipamentos através do numero da proposta
	 * @param numeroProposta
	 * @return
	 */
	List<SolucaoCaptura> findAll(Long numeroProposta);

  

}
