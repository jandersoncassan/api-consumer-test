package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entidade representando a tabela de Solucao Captura 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDR_EQPMN_CPTR_PRPS_CRDN")
public class SolucaoCaptura implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private SolucaoCapturaPK id;

    @Column(name = "NU_SQCL_EQPM_CPTR", insertable = false, updatable = false)
    private Integer nuSqclEqpmCptr;

    @Column(name = "CD_MLHR_PRDO_INST_EQPM_CPTR", precision = 2, nullable = true)
    private BigDecimal cdMlhrPrdoInstEqpmCptr;

    @Column(name = "CD_MTVO_CNCL_INST_EQPM_CPTR", length = 3, nullable = true)
    private String cdMtvoCnclInstEqpmCptr;

    @Column(name = "CD_TIPO_TRMN_INSL", length = 2, nullable = true)
    private String cdTipoTrmnInsl;

    @Column(name = "CD_USRO_ALTR_RGST", length = 20, nullable = true)
    private String cdUsroAltrRgst;

    @Column(name = "CD_USRO_INCL_RGST", nullable = false, length = 20)
    private String cdUsroInclRgst;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DH_ALTR_RGST", nullable = true)
    private Date dhAltrRgst;

    @Temporal(TemporalType.DATE)
    @Column(name = "DH_INCL_RGST", nullable = false)
    private Date dhInclRgst;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DH_ATVC_EQPM_CPTR", nullable = true)
    private Date dhAtvcEqpmCptr;

    @Temporal(TemporalType.DATE)
    @Column(name = "DT_CNCL_INST_EQPM_CPTR", nullable = true)
    private Date dtCnclInstEqpmCptr;

    @Temporal(TemporalType.DATE)
    @Column(name = "DT_INST_EQPM_CPTR", nullable = true)
    private Date dtInstEqpmCptr;

    @Column(name = "NU_CHMD_INST_EQPM_CPTR", nullable = true, precision = 6)
    private Long nuChmdInstEqpmCptr;

    @Column(name = "NU_LGCO_EQPM_CPTR", nullable = true, precision = 8)
    private Integer nuLgcoEqpmCptr;

    @Column(name = "CD_STCO_CHMD_INST", length = 20)
    private Integer codSitChamadoInstalacao;

    @Column(name = "DH_PRVS_INST_EQPM_CPTR", nullable = true)
    @Temporal(javax.persistence.TemporalType.TIMESTAMP)
    private Date dtPrevInstalEquipamento;

    @Column(name = "BCMC001C_ATEND_REFER", nullable = true, length = 11)
    private Long codigoReferenciaEvento;

	/**
	 * @return the id
	 */
	public SolucaoCapturaPK getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(SolucaoCapturaPK id) {
		this.id = id;
	}

	/**
	 * @return the nuSqclEqpmCptr
	 */
	public Integer getNuSqclEqpmCptr() {
		return nuSqclEqpmCptr;
	}

	/**
	 * @param nuSqclEqpmCptr the nuSqclEqpmCptr to set
	 */
	public void setNuSqclEqpmCptr(Integer nuSqclEqpmCptr) {
		this.nuSqclEqpmCptr = nuSqclEqpmCptr;
	}

	/**
	 * @return the cdMtvoCnclInstEqpmCptr
	 */
	public String getCdMtvoCnclInstEqpmCptr() {
		return cdMtvoCnclInstEqpmCptr;
	}

	/**
	 * @param cdMtvoCnclInstEqpmCptr the cdMtvoCnclInstEqpmCptr to set
	 */
	public void setCdMtvoCnclInstEqpmCptr(String cdMtvoCnclInstEqpmCptr) {
		this.cdMtvoCnclInstEqpmCptr = cdMtvoCnclInstEqpmCptr;
	}

	/**
	 * @return the cdTipoTrmnInsl
	 */
	public String getCdTipoTrmnInsl() {
		return cdTipoTrmnInsl;
	}

	/**
	 * @param cdTipoTrmnInsl the cdTipoTrmnInsl to set
	 */
	public void setCdTipoTrmnInsl(String cdTipoTrmnInsl) {
		this.cdTipoTrmnInsl = cdTipoTrmnInsl;
	}

	/**
	 * @return the cdUsroAltrRgst
	 */
	public String getCdUsroAltrRgst() {
		return cdUsroAltrRgst;
	}

	/**
	 * @param cdUsroAltrRgst the cdUsroAltrRgst to set
	 */
	public void setCdUsroAltrRgst(String cdUsroAltrRgst) {
		this.cdUsroAltrRgst = cdUsroAltrRgst;
	}

	/**
	 * @return the cdUsroInclRgst
	 */
	public String getCdUsroInclRgst() {
		return cdUsroInclRgst;
	}

	/**
	 * @param cdUsroInclRgst the cdUsroInclRgst to set
	 */
	public void setCdUsroInclRgst(String cdUsroInclRgst) {
		this.cdUsroInclRgst = cdUsroInclRgst;
	}

	/**
	 * @return the dhAltrRgst
	 */
	public Date getDhAltrRgst() {
		return dhAltrRgst;
	}

	/**
	 * @param dhAltrRgst the dhAltrRgst to set
	 */
	public void setDhAltrRgst(Date dhAltrRgst) {
		this.dhAltrRgst = dhAltrRgst;
	}

	/**
	 * @return the dhInclRgst
	 */
	public Date getDhInclRgst() {
		return dhInclRgst;
	}

	/**
	 * @param dhInclRgst the dhInclRgst to set
	 */
	public void setDhInclRgst(Date dhInclRgst) {
		this.dhInclRgst = dhInclRgst;
	}

	/**
	 * @return the dhAtvcEqpmCptr
	 */
	public Date getDhAtvcEqpmCptr() {
		return dhAtvcEqpmCptr;
	}

	/**
	 * @param dhAtvcEqpmCptr the dhAtvcEqpmCptr to set
	 */
	public void setDhAtvcEqpmCptr(Date dhAtvcEqpmCptr) {
		this.dhAtvcEqpmCptr = dhAtvcEqpmCptr;
	}

	/**
	 * @return the dtCnclInstEqpmCptr
	 */
	public Date getDtCnclInstEqpmCptr() {
		return dtCnclInstEqpmCptr;
	}

	/**
	 * @param dtCnclInstEqpmCptr the dtCnclInstEqpmCptr to set
	 */
	public void setDtCnclInstEqpmCptr(Date dtCnclInstEqpmCptr) {
		this.dtCnclInstEqpmCptr = dtCnclInstEqpmCptr;
	}

	/**
	 * @return the dtInstEqpmCptr
	 */
	public Date getDtInstEqpmCptr() {
		return dtInstEqpmCptr;
	}

	/**
	 * @param dtInstEqpmCptr the dtInstEqpmCptr to set
	 */
	public void setDtInstEqpmCptr(Date dtInstEqpmCptr) {
		this.dtInstEqpmCptr = dtInstEqpmCptr;
	}

	/**
	 * @return the nuChmdInstEqpmCptr
	 */
	public Long getNuChmdInstEqpmCptr() {
		return nuChmdInstEqpmCptr;
	}

	/**
	 * @param nuChmdInstEqpmCptr the nuChmdInstEqpmCptr to set
	 */
	public void setNuChmdInstEqpmCptr(Long nuChmdInstEqpmCptr) {
		this.nuChmdInstEqpmCptr = nuChmdInstEqpmCptr;
	}

	/**
	 * @return the nuLgcoEqpmCptr
	 */
	public Integer getNuLgcoEqpmCptr() {
		return nuLgcoEqpmCptr;
	}

	/**
	 * @param nuLgcoEqpmCptr the nuLgcoEqpmCptr to set
	 */
	public void setNuLgcoEqpmCptr(Integer nuLgcoEqpmCptr) {
		this.nuLgcoEqpmCptr = nuLgcoEqpmCptr;
	}

	/**
	 * @return the codSitChamadoInstalacao
	 */
	public Integer getCodSitChamadoInstalacao() {
		return codSitChamadoInstalacao;
	}

	/**
	 * @param codSitChamadoInstalacao the codSitChamadoInstalacao to set
	 */
	public void setCodSitChamadoInstalacao(Integer codSitChamadoInstalacao) {
		this.codSitChamadoInstalacao = codSitChamadoInstalacao;
	}

	/**
	 * @return the dtPrevInstalEquipamento
	 */
	public Date getDtPrevInstalEquipamento() {
		return dtPrevInstalEquipamento;
	}

	/**
	 * @param dtPrevInstalEquipamento the dtPrevInstalEquipamento to set
	 */
	public void setDtPrevInstalEquipamento(Date dtPrevInstalEquipamento) {
		this.dtPrevInstalEquipamento = dtPrevInstalEquipamento;
	}

	/**
	 * @return the codigoReferenciaEvento
	 */
	public Long getCodigoReferenciaEvento() {
		return codigoReferenciaEvento;
	}

	/**
	 * @param codigoReferenciaEvento the codigoReferenciaEvento to set
	 */
	public void setCodigoReferenciaEvento(Long codigoReferenciaEvento) {
		this.codigoReferenciaEvento = codigoReferenciaEvento;
	}

    
}
