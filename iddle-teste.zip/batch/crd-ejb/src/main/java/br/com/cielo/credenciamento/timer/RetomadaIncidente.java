/**
 * 
 */
package br.com.cielo.credenciamento.timer;

import java.util.List;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.service.IControleIncidenteService;
import br.com.cielo.credenciamento.ejb.domain.batch.Incidente;
import br.com.cielo.credenciamento.ejb.enums.StatusEnum;

/**
 * Classe responsavel pelas retomadas de incidentes no processamento das propostas de credenciamento
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */

@Singleton
public class RetomadaIncidente {

	private static final Logger LOG = LoggerFactory.getLogger(RetomadaIncidente.class);

	@Inject
	private IControleIncidenteService controleIncidenteService;

	private final String NAME_CLUSTER = "weblogic.Name";
	private final String CLUSTER_NO1 = "credServer1";

	@Schedule(dayOfWeek = "Mon,Tue,Wed,Thu,Fri", hour = "20", minute = "45", info = "RETOMADA DE INCIDENTES", persistent = false)
	public void initRetomada() {

		String nameServer = System.getProperty(NAME_CLUSTER);
		LOG.info("RETOMADA INCIDENTE | NOME SERVIDOR : " + nameServer);
		if (nameServer.equals(CLUSTER_NO1)) {
			List<Incidente> listaIncidentes = getListaIncidente();
			
			if (null != listaIncidentes && !listaIncidentes.isEmpty()) {
				LOG.info("QTDADE DE REGISTROS RETOMADA : {}", listaIncidentes.size());
				//SOMENTE RETOMAMOS O INCIDENTE SE O STATUS DO REGISTRO ESTIVER EM PROCESSAMENTO NA TABELA WRK
				for (Incidente incidente : listaIncidentes) {
					Boolean isIncidenteApto = incidente.getCodStatusProc().equals(StatusEnum.EM_PROCESSAMENTO.getDominio());
					LOG.info("STATUS DO INCIDENTE NA TABELA WRK ESTA EM PROCESSAMENTO : {}", isIncidenteApto);

					if(isIncidenteApto){
						LOG.info("RETOMANDO INCIDENTE");
						controleIncidenteService.retomarIncidente(incidente);
					}
				}

			} else {
				LOG.info("LISTA INCIDENTES VAZIA");
			}
		}
	}

	/**
	 * Método responsavel por obter a lista de incidentes
	 * 
	 * @return List<String>
	 */
	private List<Incidente> getListaIncidente() {
		LOG.info("BUSCANDO LISTA INCIDENTES");
		return (controleIncidenteService.obterListaIncidente());
	}

}
