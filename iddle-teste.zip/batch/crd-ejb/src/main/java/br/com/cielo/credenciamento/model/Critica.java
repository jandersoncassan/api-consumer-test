
package br.com.cielo.credenciamento.model;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "codigoCrd",
    "info"
})
public class Critica implements Serializable{

	private static final long serialVersionUID = 1L;

	@JsonProperty("codigoCrd")
    private Integer codigoCrd;
    @JsonProperty("info")
    private Info info;

    @JsonProperty("codigoCrd")
    public Integer getCodigoCrd() {
        return codigoCrd;
    }

    @JsonProperty("codigoCrd")
    public void setCodigoCrd(Integer codigoCrd) {
        this.codigoCrd = codigoCrd;
    }

    @JsonProperty("info")
    public Info getInfo() {
        return info;
    }

    @JsonProperty("info")
    public void setInfo(Info info) {
        this.info = info;
    }
}
