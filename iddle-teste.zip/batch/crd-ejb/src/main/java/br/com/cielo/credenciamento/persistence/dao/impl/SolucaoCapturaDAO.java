package br.com.cielo.credenciamento.persistence.dao.impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.persistence.dao.ISolucaoCaputuraDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.SolucaoCaptura;

/**
 * Classe DAO responsavel pelas consistências envolvendo a tabela de equipamentos da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class SolucaoCapturaDAO extends AbstractJpaDAO<SolucaoCaptura> implements ISolucaoCaputuraDAO {

	private static final Logger LOG = LoggerFactory.getLogger(SolucaoCapturaDAO.class);

	public SolucaoCapturaDAO() {
        super(SolucaoCaptura.class);
    }

    @Override
    public List<SolucaoCaptura> findAll(final Long numeroProposta) {
    	LOG.info("BUSNCADO A LISTA DE SOLUCOES DE CAPTURA PARA A PROPOSTA {}", numeroProposta);
        StringBuilder sql = new StringBuilder("FROM "+getEntityClass().getSimpleName()+ " s ");
        	          sql.append("WHERE s.id.nuPrpsCrdn = :pNuPrpsCrdn");        
        
        TypedQuery<SolucaoCaptura> query = getEntityManager().createQuery(sql.toString(), SolucaoCaptura.class);
        query.setParameter("pNuPrpsCrdn", numeroProposta);
        return query.getResultList();
    }    

}
