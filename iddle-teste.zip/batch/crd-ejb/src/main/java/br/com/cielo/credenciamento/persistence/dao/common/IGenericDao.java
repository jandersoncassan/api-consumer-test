package br.com.cielo.credenciamento.persistence.dao.common;

import java.io.Serializable;

/**
 * Interface JPA abstract Generics DAO
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public interface IGenericDao<T extends Serializable> extends IOperations<T> {

}
