package br.com.cielo.credenciamento.crd.enun;

/**
 * Classe Enum responsavel pela classificação do status de processamento do registro
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public enum SitProcRegistroArquivoEnum {

    PENDENTE(1),
    EM_PROCESSAMENTO(2),
    COM_ERRO(3),
    ACATADO(4),
    REJEITADO(5),
    PROCESSADO(6),
    FALHA_SISTEMICA(99);

    private Integer codigoSituacao;

    SitProcRegistroArquivoEnum(final Integer codigo) {
        this.codigoSituacao = codigo;
    }

    /**
     * Método get do atributo codigoSituacao
     * 
     * @return O valor do atributo codigoSituacao
     */
    public Integer getCodigoSituacaoProposta() {
        return this.codigoSituacao;
    }

}
