package br.com.cielo.credenciamento.crd.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.ejb.Schedule;
import javax.ejb.Singleton;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Classe singleton responsavel por efetuar a leitura dos arquivos properties
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Singleton
public class CrdFileUtil {

	private static final Logger LOG = LoggerFactory.getLogger(CrdFileUtil.class);

	private static final String ARQUIVO = "config.properties";

	private Properties properties;

	private Properties config;

	@PostConstruct
	public void init() {
		LOG.debug("CARREGAR ARQUIVO PROPRIEDADE - CRD BATCH {}", ARQUIVO);
		loadProperties();
	}

	@Schedule(hour = "*", minute = "45", persistent = false)
	private void loadProperties(){
		config = new Properties();
		InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(ARQUIVO);

		try {
			this.config.load(inputStream);
		} catch (IOException e) {
			LOG.debug("ERRO : Carregar arquivo properties {}{}", ARQUIVO, e);
		}
		// CARREGAMOS O ARQUIVO DE PROPRIEDADES CRD BATCH
		carregarProperties();
	}
	
	/**
	 * Método responsavel por carregar o arquivo de configurações no diretório
	 * do CRD
	 */
	private void carregarProperties() {

		Path arquivo = Paths.get(String.format("%s%s%s", config.getProperty("diretorio"), File.separator, config.get("arquivo")));
		properties = new Properties();
		try {
			properties.load(new FileInputStream(arquivo.toFile()));
		} catch (IOException e) {
			LOG.debug("ERRO : Carregar arquivo properties {}{}", arquivo.toFile(), e);
		}
	}

	/**
	 * Método responsavel por obter as propriedades do arquivo
	 * 
	 * @param key
	 * @return String
	 */
	public String getMessage(String key) {
		return (properties.getProperty(key));
	}
}
