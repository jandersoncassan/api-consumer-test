package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entidade representando a tabela de incidentes da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDW_CNTR_ICDT_POCS_CRDN")
public class ControleIncidentesProcess implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @SequenceGenerator(name = "SQR_CNTR_ICDT_POCS_CRDN", sequenceName = "SQR_CNTR_ICDT_POCS_CRDN", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQR_CNTR_ICDT_POCS_CRDN")
    @Column(name = "NU_SQNL_IDTF_ICDT", nullable = false)
    private Long id;

    @ManyToOne
    @JoinColumns({
    	@JoinColumn(name = "CD_BNCO", referencedColumnName = "CD_BNCO"),
    	@JoinColumn(name = "DT_MVMN_ARQV_BNCO", referencedColumnName = "DT_MVMN_ARQV_BNCO"),
    	@JoinColumn(name = "NU_RMSA_ARQV_BNCO", referencedColumnName = "NU_RMSA_ARQV_BNCO"),
    	@JoinColumn(name = "NU_LNHA_RGST_ARQV_BNCO", referencedColumnName = "NU_LNHA_RGST_ARQV_BNCO")
    })
    private ProcessamentoRegistroArquivo tbcrdwPcsmRgstCdstAtul;
 
    @Column(name = "DC_ERRO_STMA_PVDO", nullable = false)
    private String causeException;

    @Column(name = "CD_USRO_INCL_RGST", nullable = false)
    private String cdUsroInclRgst;
    
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DH_INCL_RGST", nullable = false)
    private Date dhInclRgst;

    @Column(name = "CD_USRO_ALTR_RGST")
    private String cdUsroAltrRgst;

    @Column(name = "DH_ALTR_RGST")
    private Date dhAltrRgst;
    
    @Column(name = "IN_ICDT_RSVD", nullable = false)
    private String flagControle;

	/**
	 * @return the id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return the tbcrdwPcsmRgstCdstAtul
	 */
	public ProcessamentoRegistroArquivo getTbcrdwPcsmRgstCdstAtul() {
		return tbcrdwPcsmRgstCdstAtul;
	}

	/**
	 * @param tbcrdwPcsmRgstCdstAtul the tbcrdwPcsmRgstCdstAtul to set
	 */
	public void setTbcrdwPcsmRgstCdstAtul(ProcessamentoRegistroArquivo tbcrdwPcsmRgstCdstAtul) {
		this.tbcrdwPcsmRgstCdstAtul = tbcrdwPcsmRgstCdstAtul;
	}

	/**
	 * @return the causeException
	 */
	public String getCauseException() {
		return causeException;
	}

	/**
	 * @param causeException the causeException to set
	 */
	public void setCauseException(String causeException) {
		this.causeException = causeException;
	}

	/**
	 * @return the cdUsroInclRgst
	 */
	public String getCdUsroInclRgst() {
		return cdUsroInclRgst;
	}

	/**
	 * @param cdUsroInclRgst the cdUsroInclRgst to set
	 */
	public void setCdUsroInclRgst(String cdUsroInclRgst) {
		this.cdUsroInclRgst = cdUsroInclRgst;
	}

	/**
	 * @return the dhInclRgst
	 */
	public Date getDhInclRgst() {
		return dhInclRgst;
	}

	/**
	 * @param dhInclRgst the dhInclRgst to set
	 */
	public void setDhInclRgst(Date dhInclRgst) {
		this.dhInclRgst = dhInclRgst;
	}

	/**
	 * @return the cdUsroAltrRgst
	 */
	public String getCdUsroAltrRgst() {
		return cdUsroAltrRgst;
	}

	/**
	 * @param cdUsroAltrRgst the cdUsroAltrRgst to set
	 */
	public void setCdUsroAltrRgst(String cdUsroAltrRgst) {
		this.cdUsroAltrRgst = cdUsroAltrRgst;
	}

	/**
	 * @return the dhAltrRgst
	 */
	public Date getDhAltrRgst() {
		return dhAltrRgst;
	}

	/**
	 * @param dhAltrRgst the dhAltrRgst to set
	 */
	public void setDhAltrRgst(Date dhAltrRgst) {
		this.dhAltrRgst = dhAltrRgst;
	}

	/**
	 * @return the flagControle
	 */
	public String getFlagControle() {
		return flagControle;
	}

	/**
	 * @param flagControle the flagControle to set
	 */
	public void setFlagControle(String flagControle) {
		this.flagControle = flagControle;
	}
    
    
}