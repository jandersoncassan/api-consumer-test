package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * PK representando a tabela de Solucao Captura 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Embeddable
public class SolucaoCapturaPK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "NU_PRPS_CRDN", insertable = false, updatable = false, unique = true, nullable = false)
    private long nuPrpsCrdn;

    @Column(name = "CD_TECHNOLOGY", insertable = false, updatable = false, unique = true, nullable = false)
    private Integer codigoSolucaoCaptura;

    @Column(name = "NU_SQCL_EQPM_CPTR", unique = true, nullable = false, precision = 2)
    private long nuSqclEqpmCptr;

    @Column(name = "CD_TIPO_TRMN")
    private String cdTipoTrmn;

	/**
	 * @return the nuPrpsCrdn
	 */
	public long getNuPrpsCrdn() {
		return nuPrpsCrdn;
	}

	/**
	 * @param nuPrpsCrdn the nuPrpsCrdn to set
	 */
	public void setNuPrpsCrdn(long nuPrpsCrdn) {
		this.nuPrpsCrdn = nuPrpsCrdn;
	}

	/**
	 * @return the codigoSolucaoCaptura
	 */
	public Integer getCodigoSolucaoCaptura() {
		return codigoSolucaoCaptura;
	}

	/**
	 * @param codigoSolucaoCaptura the codigoSolucaoCaptura to set
	 */
	public void setCodigoSolucaoCaptura(Integer codigoSolucaoCaptura) {
		this.codigoSolucaoCaptura = codigoSolucaoCaptura;
	}

	/**
	 * @return the nuSqclEqpmCptr
	 */
	public long getNuSqclEqpmCptr() {
		return nuSqclEqpmCptr;
	}

	/**
	 * @param nuSqclEqpmCptr the nuSqclEqpmCptr to set
	 */
	public void setNuSqclEqpmCptr(long nuSqclEqpmCptr) {
		this.nuSqclEqpmCptr = nuSqclEqpmCptr;
	}

	/**
	 * @return the cdTipoTrmn
	 */
	public String getCdTipoTrmn() {
		return cdTipoTrmn;
	}

	/**
	 * @param cdTipoTrmn the cdTipoTrmn to set
	 */
	public void setCdTipoTrmn(String cdTipoTrmn) {
		this.cdTipoTrmn = cdTipoTrmn;
	}

    
 }
