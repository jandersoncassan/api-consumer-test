package br.com.cielo.credenciamento.persistence.dao;

import java.util.Date;

import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.ComplementoProposta;

/**
 * Interface responsavel pelo tratamento de arquivos complemento da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IComplementoPropostaDAO extends IOperations<ComplementoProposta> {


	/**
	 * Método responsavel por obter o registro de complemento através do numero da proposta
	 * @param numeroProposta
	 * @return
	 */
	ComplementoProposta findById(final Long numeroProposta);
	
	/**
	 * Método responsavel por obter o registro de complemento através do correlationId
	 * @param codigoBanco
	 * @param dataRemessa
	 * @param numeroRemessa
	 * @param numeroLinha
	 * @return
	 */
	ComplementoProposta fyndByCorrelation(final Integer codigoBanco, final Date dataRemessa, final Integer numeroRemessa, final Integer numeroLinha);

}
