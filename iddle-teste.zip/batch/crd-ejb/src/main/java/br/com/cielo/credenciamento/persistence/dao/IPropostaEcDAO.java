package br.com.cielo.credenciamento.persistence.dao;

import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.EstabelecimentoComercial;

/**
 * Interface responsavel pelos metodos de consistências do numero de estabelecimento da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IPropostaEcDAO extends IOperations<EstabelecimentoComercial> {

	/**
	 * Método responsavel por obter o numero da proposta do numero do estabelecimento comercial
	 * @param numeroEc
	 * @return numeroProposta
	 */
	EstabelecimentoComercial findByEc(final Long numeroEc);
	
	/**
	 * Método responsavel por atualizar a situação da proposta
	 * @param numeroProposta
	 */
	void atualizarSituacaoProposta(final Long numeroProposta);

}
