package br.com.cielo.credenciamento.persistence.dao.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.ejb.constantes.Constants;
import br.com.cielo.credenciamento.persistence.dao.IArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.LogControleCargaBanco;

/**
 * Classe DAO responsavel pelas consistencias da tabela de controle de carga banco
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
@TransactionAttribute(TransactionAttributeType.REQUIRES_NEW)
public class ArquivoDAO extends AbstractJpaDAO<LogControleCargaBanco> implements IArquivoDAO {

	private static final Logger LOG = LoggerFactory.getLogger(ArquivoDAO.class);

    public ArquivoDAO() {
        super(LogControleCargaBanco.class);
    }

    @Override
    public LogControleCargaBanco create(LogControleCargaBanco entity) {
    	 LogControleCargaBanco log = super.create(entity);
    	 return log;
    }
    
    @Override
    public LogControleCargaBanco update(LogControleCargaBanco entity) {
    	LogControleCargaBanco log = super.update(entity);
    	return log;
    }
    
	@Override
    public LogControleCargaBanco findEntity(final Integer banco, final Date dataExecucao, final Integer numeroRemessa) {
		LOG.info("BUSCANDO A ENTIDADE LOG CARGA BANCO");
       try{
			DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	
	        String sql = "SELECT * FROM TBCRDR_LOG_CNTR_CRGA_BNCO WHERE CD_BNCO = :banco "
	                + "AND trunc(DT_MVMN_ARQV_BNCO) = to_date(:dataExecucao, 'dd/mm/yyyy') "
	                + "AND NU_RMSA_ARQV_BNCO = :numeroRemessa";
	
	        Query query = getEntityManager().createNativeQuery(sql, LogControleCargaBanco.class);
	
	        query.setParameter("banco", banco);
	        query.setParameter("dataExecucao", sdf.format(dataExecucao));
	        query.setParameter("numeroRemessa", numeroRemessa);
	
	        LogControleCargaBanco entity = (LogControleCargaBanco) query.getSingleResult();
	
	        return entity;
 
       }catch(NoResultException ex){
    	   LOG.info("NAO HA REMESSA CADASTRADA PARA ESSE REGISTRO");
    	   return null;
       }
    }

    @Override
    public Integer findNextNumRemessa(final Date dataInsercao, final Integer banco) {
    	LOG.info("BUSCANDO PROXIMO NUMERO DE REMESSA ..");
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String sql = "SELECT MAX(bean.NU_RMSA_ARQV_BNCO) as val FROM TBCRDR_LOG_CNTR_CRGA_BNCO bean "
                + "WHERE bean.CD_BNCO = :banco AND trunc(bean.DT_MVMN_ARQV_BNCO) = to_date(:dataInsercao, 'dd/mm/yyyy')";

        Query query = getEntityManager().createNativeQuery(sql);
        query.setParameter("banco", Integer.valueOf(banco).longValue());
        query.setParameter("dataInsercao", sdf.format(dataInsercao));

        BigDecimal remessaAtual = (BigDecimal) query.getSingleResult();
        int proximaRemessa = Constants.UM;
        if (remessaAtual != null) {
            proximaRemessa = remessaAtual.intValue() + 1;
        }
        return proximaRemessa;
    }
        
}