package br.com.cielo.credenciamento.persistence.dao.common;

import java.io.Serializable;
import java.util.List;

/**
 * Interface JPA abstract Generics DAO
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public interface IOperations<T extends Serializable> {

    /**
     * Método de busca por id da entidade.
     * 
     * @param id do objeto entidade
     * @return T
     */
    T findOne(final long id);

    /**
     * Método de busca por id da entidade.
     * 
     * @param id do objeto entidade
     * @return T
     */
    T findOne(final Serializable id);

    /**
     * Método de busca lista de entidades.
     * 
     * @return T
     */
    List<T> findAll();

    /**
     * Método criar dados do objeto entidade na base de dados.
     * 
     * @param entity objeto entidade
     * @return T
     */
    T create(final T entity);

    /**
     * Método criar lista de objeto entidade na base de dados.
     * 
     * @param entities lista de objeto entidade
     * @return List<T>
     */
    List<T> createAll(final List<T> entities);

    /**
     * Método atualiza dados do objeto entidade na base de dados.
     * 
     * @param entity objeto entidade
     * @return T
     */
    T update(final T entity);

    /**
     * Método deleta dados do objeto entidade da base de dados.
     * 
     * @param entity objeto entidade
     */
    void delete(final T entity);

    /**
     * Método deleta objeto entidade por id da base de dados.
     * 
     * @param entityId id do objeto entidade
     */
    void deleteById(final long entityId);

}
