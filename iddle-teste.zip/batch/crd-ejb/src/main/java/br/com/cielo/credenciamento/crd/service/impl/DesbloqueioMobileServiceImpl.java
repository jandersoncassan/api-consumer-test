package br.com.cielo.credenciamento.crd.service.impl;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.service.IDesbloqueioMobileService;
import br.com.cielo.credenciamento.crd.service.osb.IServicesCredenciamento;
import br.com.cielo.credenciamento.ejb.domain.batch.DesbloqueioMobile;
import br.com.cielo.credenciamento.ejb.remote.IDesbloqueioMobileServiceRemote;

@Stateless(name = "DesbloqueioMobileService", mappedName = "DesbloqueioMobileService")
public class DesbloqueioMobileServiceImpl implements IDesbloqueioMobileService, IDesbloqueioMobileServiceRemote{

	private static final Logger LOG = LoggerFactory.getLogger(DesbloqueioMobileServiceImpl.class);
	
	@Inject
	private IServicesCredenciamento servicesCredenciamento;
	
	@Override
	public void desbloquearMobile(DesbloqueioMobile desbloqueioMobile) {
		LOG.info("EFETIVANDO DESBLOQUEIO MOBILE {}", desbloqueioMobile.getCodigoEstabelecimento());
		efetivarDesbloqueio(desbloqueioMobile);
	}
	
	/**
	 * Método responsavel por efetivar o desbloqueio mobile
	 * @param desbloqueioMobile
	 */
	private void efetivarDesbloqueio(DesbloqueioMobile desbloqueioMobile){		
		try {
			servicesCredenciamento.efetivarDesbloqueioMobile(desbloqueioMobile);
			
		} catch (RemoteException | ServiceException | MalformedURLException ex) {
			LOG.error("OCORREU UM ERRO AO EFETIVAR O DESBLOQUEIO MOBILE {}", ex);
		}
	}

}
