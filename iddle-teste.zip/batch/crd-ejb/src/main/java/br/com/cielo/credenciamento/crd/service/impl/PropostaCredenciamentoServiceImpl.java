package br.com.cielo.credenciamento.crd.service.impl;

import java.util.Date;

import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.enun.SitProcRegistroArquivoEnum;
import br.com.cielo.credenciamento.crd.exception.CredenciarClienteException;
import br.com.cielo.credenciamento.crd.service.IPropostaCredenciamentoService;
import br.com.cielo.credenciamento.ejb.constantes.Constants;
import br.com.cielo.credenciamento.ejb.domain.batch.Proprietario;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.ejb.domain.batch.Telefone;
import br.com.cielo.credenciamento.persistence.dao.IArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.IProcessamentoRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.ISituacaoProcessRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.entity.LogControleCargaBanco;
import br.com.cielo.credenciamento.persistence.entity.LogControleCargaBancoPK;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivoPK;
import br.com.cielo.credenciamento.persistence.entity.SituacaoProcessRegistroArquivo;

/**
 * Classe responsavel pela implementação das regras de inclusão de prospect
 * 
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class PropostaCredenciamentoServiceImpl implements IPropostaCredenciamentoService {

	private static final Logger LOG = LoggerFactory.getLogger(PropostaCredenciamentoServiceImpl.class);

	@Inject
	private IProcessamentoRegistroArquivoDAO procRegistroArquivoDAO;
    
    @Inject
    private IArquivoDAO arquivoDAO;
    
    @Inject
    private ISituacaoProcessRegistroArquivoDAO sitProcRegArquivoDAO;

	@Override
	public void incluirProspect(Prospect prospect, Date dataExecucao, Integer codigoBanco, Integer numRemessa, Integer numLinha) {
		LOG.info("INIT - PERSITENCIA TBL LOG E WRK");
		try {
			initPersistencia(prospect, dataExecucao, codigoBanco, numRemessa, numLinha);

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO NO PROCESSO DE PERSISTENCIA {}", ex);
			throw new CredenciarClienteException("ERRO PERSISTENCIA PROSPECT", ex);
		}
	}

	/**
	 * Método responsavel por efetivar a persistência das informações de prospect
	 * 
	 * @param prospect
	 * @param dataExecucao
	 * @param codigoBanco
	 * @param numRemessa
	 * @param numLinha
	 * @return 
	 * @throws NamingException 
	 */
	private void initPersistencia(Prospect prospect, Date dataExecucao, Integer codigoBanco, Integer numRemessa, Integer numLinha) throws NamingException {
		incluir(prospect, dataExecucao, numRemessa, codigoBanco, numLinha);
	}

    /**
     * Método responsavel pela persistencia do prospect
     * @param prospect
     * @param dataExecucao
     * @param numeroRemessa
     * @param codigoBanco
     * @param numeroLinha
     * @return 
     */
    public void incluir(Prospect prospect, Date dataExecucao, Integer numeroRemessa, Integer codigoBanco, Integer numeroLinha) {
    	LogControleCargaBanco logCargaBanco = persistirControleCarga(codigoBanco, dataExecucao, numeroRemessa, prospect.isLayoutNovo());
    	persistirProspect(prospect, logCargaBanco, codigoBanco, numeroLinha);
    }


	/**
     * Método responsavel pela inclusão das informações na tabela de carga
     * @param isLayoutNovo 
     * @return TbcrdrLogCntrCrgaBnco
     */
	private LogControleCargaBanco persistirControleCarga(Integer codigoBanco, Date dataExecucao, Integer numeroRemessa, boolean isLayoutNovo) {
		return (popularLogControleCargaBanco(codigoBanco, dataExecucao, numeroRemessa, isLayoutNovo));
	}

	/**
	 * Método responsavel pela inclusão das informações na tabela de controle de carga banco
	 * @param codigoBanco
	 * @param dataExecucao
	 * @param numeroRemessa
	 * @param hasError
	 * @param isLayoutNovo 
	 * @return TbcrdrLogCntrCrgaBnco
	 */
	private LogControleCargaBanco popularLogControleCargaBanco(Integer codigoBanco, Date dataExecucao, Integer numeroRemessa, boolean isLayoutNovo) {
        LogControleCargaBanco tbcrdrLogCntrCrgaBnco = getEntityControleCargaBanco(codigoBanco, dataExecucao, numeroRemessa);

        if (tbcrdrLogCntrCrgaBnco == null) {
            tbcrdrLogCntrCrgaBnco = new LogControleCargaBanco();
            LogControleCargaBancoPK  id = new LogControleCargaBancoPK ();

            id.setCdBnco(codigoBanco);
            id.setDtMvmnArqvBnco(dataExecucao);
            id.setNuRmsaArqvBnco(numeroRemessa);

            tbcrdrLogCntrCrgaBnco.setId(id);
            tbcrdrLogCntrCrgaBnco.setCdUsroInclRgst("CRDUSR");
            tbcrdrLogCntrCrgaBnco.setDhInclRgst(new Date());
            tbcrdrLogCntrCrgaBnco.setInArqvActd("N");
            tbcrdrLogCntrCrgaBnco.setQtRgstRjtd(Constants.ZERO_I);
            tbcrdrLogCntrCrgaBnco.setQtRgstActd(Constants.ZERO_I);
            tbcrdrLogCntrCrgaBnco.setQtTotlRgst(99999);//TRATAMENTO PARA GERAÇAO DO ARQUIVO DE RETORNO, ATENDENDO AO PROCESSAMENTO SINCRONO
            tbcrdrLogCntrCrgaBnco.setCodTipoArquivoBanco(isLayoutNovo? Constants.DOIS: Constants.UM);
            tbcrdrLogCntrCrgaBnco = this.arquivoDAO.create(tbcrdrLogCntrCrgaBnco);
        } 
        return tbcrdrLogCntrCrgaBnco;
	}
	

	/**
	 * Método responsavel por retornar o numero total de remessas
	 * 
	 * @param codigoBanco
	 * @param dataExecucao
	 * @param numeroRemessa
	 * @return
	 */
    private LogControleCargaBanco getEntityControleCargaBanco(Integer codigoBanco, Date dataExecucao, Integer numeroRemessa){
    	return this.arquivoDAO.findEntity(codigoBanco, dataExecucao, numeroRemessa);
    }
    
	/**
	 * Método responsavel pela inclusão das informações de prospect
	 * @param prospect
	 * @param logCargaBanco
	 * @param codigoBanco
	 * @param numeroLinha
	 * @return 
	 * @return TbcrdwPcsmRgstCdstAtul
	 */
	private ProcessamentoRegistroArquivo persistirProspect(Prospect prospect, LogControleCargaBanco logCargaBanco, Integer codigoBanco, Integer numeroLinha) {
		return popularProspect(prospect, logCargaBanco, codigoBanco, numeroLinha);
	}

	 /**
     * Metodo que prepara o prospect 
     * 
     * @param prospect parametro de entrada do metodo
     * @param tbcrdrLogCntrCrgaBnco parametro de entrada do metodo
     * @param situacaoProcessamentoRegistro parametro de entrada do metodo
     * @param codigoBanco parametro de entrada do metodo
     * @param numeroLinha parametro de entrada do metodo
     * @return TbcrdwPcsmRgstCdstAtul
     */
    private ProcessamentoRegistroArquivo popularProspect(Prospect prospect, LogControleCargaBanco logCntrCrgaBnco, Integer codigoBanco, Integer numeroLinha) {
       
    	ProcessamentoRegistroArquivo pcsmRgstCdstAtul = new ProcessamentoRegistroArquivo();
    	//POPULAR ID
    	ProcessamentoRegistroArquivoPK idRgstAtul = new ProcessamentoRegistroArquivoPK();
    	idRgstAtul.setCdBnco(codigoBanco);
    	idRgstAtul.setDtMvmnArqvBnco(logCntrCrgaBnco.getId().getDtMvmnArqvBnco());
    	idRgstAtul.setNuLnhaRgstArqvBnco(numeroLinha);
    	idRgstAtul.setNuRmsaArqvBnco(logCntrCrgaBnco.getId().getNuRmsaArqvBnco()); 
    	pcsmRgstCdstAtul.setId(idRgstAtul); 
    	//SITUACAO DO REGISTRO
        pcsmRgstCdstAtul.setSituacaoRegistro(getSituacaoProcessamento(prospect.isValido()));        
        pcsmRgstCdstAtul.setCdFnldArqv(prospect.getCodigoMensagem());        
        pcsmRgstCdstAtul.setCdBncoSlcePrpsCrdn(prospect.getSolicitante());        
        pcsmRgstCdstAtul.setNuSpbBncoSlcePrpsCrdn(prospect.getNumeroInstituicao());        
        pcsmRgstCdstAtul.setNuIdtfOrgmSlctAflc(prospect.getNumeroIdentificacao());        
        pcsmRgstCdstAtul.setTxPrimEpcoRsrdCilo(prospect.getAreaReservada01());        
        pcsmRgstCdstAtul.setCdErroVldcArqv(prospect.getCodigoErro());        
        pcsmRgstCdstAtul.setCdErroCdgoBncoPrpsCrdn(prospect.getFlagBanco());        
        pcsmRgstCdstAtul.setCdBncoPrpsCrdn(prospect.getBanco());
        pcsmRgstCdstAtul.setNuEc(prospect.getNumeroEstabelecimento());        
        pcsmRgstCdstAtul.setCdErroNmRazoSocl(prospect.getFlagRazaoSocial());        
        pcsmRgstCdstAtul.setNmRazoSocl(prospect.getRazaoSocial());;
        //ENDERECO CORRESPONDENCIA
        popularEnderecoCorrespondencia(pcsmRgstCdstAtul, prospect);        
        pcsmRgstCdstAtul.setCdErroNmroCpfCnpj(prospect.getFlagCpfCnpj());        
        pcsmRgstCdstAtul.setNuCpfCnpj(prospect.getCpfCnpj());        
        pcsmRgstCdstAtul.setCdErroNmroIe(prospect.getFlagInscricaoEstadual());        
        pcsmRgstCdstAtul.setNuIe(prospect.getInscricaoEstadual());        
        pcsmRgstCdstAtul.setCdErroNomeFnts(prospect.getFlagNomeFantasia());        
        pcsmRgstCdstAtul.setNmFnts(prospect.getNomeFantasia());
        //ENDERECO COMERCIAL
        popularEnderecoComercial(pcsmRgstCdstAtul, prospect);  
        pcsmRgstCdstAtul.setCdErroNomePlqtEc(prospect.getFlagNomePlaqueta());        
        pcsmRgstCdstAtul.setNmPlqtEc(prospect.getNomePlaqueta());        
        pcsmRgstCdstAtul.setCdErroNomePesaCnto(prospect.getFlagPessoaContato());        
        pcsmRgstCdstAtul.setNmPesaCnto(prospect.getPessoaContato());        
        pcsmRgstCdstAtul.setTxEpcoRsrdArqv(prospect.getAreaReservada02());        
        pcsmRgstCdstAtul.setCdErroCdgoMcc(prospect.getFlagRamoAtividade());        
        pcsmRgstCdstAtul.setCdMcc(prospect.getRamoAtividade());
        //DOMICILIO BANCARIO
        popularDomicilioBancario(pcsmRgstCdstAtul, prospect);
        //PROPRIETARIOS
        popularProprietarios(pcsmRgstCdstAtul, prospect);        
        pcsmRgstCdstAtul.setCdErroSgTipoPesa(prospect.getFlagTipoPessoa());        
        pcsmRgstCdstAtul.setSgTipoPesa(prospect.getTipoPessoa());        
        pcsmRgstCdstAtul.setTxNonoEpcoRsrdCilo(prospect.getAreaReservada03());
        popularTelefones(pcsmRgstCdstAtul, prospect);
        pcsmRgstCdstAtul.setCdErroIdcrMei(prospect.getFlagMei());        
        pcsmRgstCdstAtul.setInMei(prospect.getMei());        
        pcsmRgstCdstAtul.setTxQrtoEpcoRsrdCilo(prospect.getAreaReservadaCielo04());
        pcsmRgstCdstAtul.setCdErroPcteCmel(prospect.getFlagPacoteEcommerce());
        pcsmRgstCdstAtul.setCdPcteCmel(prospect.getCodPacoteEcommerce());
        pcsmRgstCdstAtul.setTxQuntEpcoRsrdCilo(prospect.getAreaReservadaCielo05());     
        pcsmRgstCdstAtul.setCdErroTipoConta(prospect.getFlagTipoConta());
        pcsmRgstCdstAtul.setCdTipoConta(prospect.getTipoConta());
        pcsmRgstCdstAtul.setTxDcmoEpcoRsrdCilo(prospect.getAreaReservadaCielo06());     
        pcsmRgstCdstAtul.setCdErroPlnoCilo(prospect.getFlagPlanoCielo());
        pcsmRgstCdstAtul.setCdPlnoCilo(prospect.getCodTipoPlano());       
        pcsmRgstCdstAtul.setCdErroValrFtrm(prospect.getFlagValorFaturamento());
        pcsmRgstCdstAtul.setValrFtrm(prospect.getValorFaturamento());
        pcsmRgstCdstAtul.setCdErroQntdDiaLqdc(prospect.getFlagQtdadeDiasLiquidacao());
        pcsmRgstCdstAtul.setQntdDiaLqdc(prospect.getQtdadeDiasLiquidacao());     
        pcsmRgstCdstAtul.setCdErroSlcp(prospect.getFlagSolucaoCaptura());
        pcsmRgstCdstAtul.setCdSlcp(prospect.getSolucaoCaptura());      
        pcsmRgstCdstAtul.setCdErroIdcrAgro(prospect.getFlagIndicadorAgro());
        pcsmRgstCdstAtul.setCdIdcrAgro(prospect.getIndicadorAgro());  
        pcsmRgstCdstAtul.setCdErroDercEmal(prospect.getFlagEmail());        
        pcsmRgstCdstAtul.setTxSxtoEpcoRsrdCilo(prospect.getAreaReservadaCielo07());
        pcsmRgstCdstAtul.setDescEmail(prospect.getEmail());        
        pcsmRgstCdstAtul.setTxStmoEpcoRsrdCilo(prospect.getAreaReservadaCielo08());

        return (procRegistroArquivoDAO.create(pcsmRgstCdstAtul));
    }

	/**
     * Método responsavel por popular as informações de endereço de correspondecia
     * @param pcsmRgstCdstAtul
     * @param prospect
     */
    private void popularEnderecoCorrespondencia(ProcessamentoRegistroArquivo pcsmRgstCdstAtul, Prospect prospect) {
    	prospect.getEnderecoCorrespondencia().setTipoEndereco(Constants.TRES);//CORRESPONDENCIA
        pcsmRgstCdstAtul.setCdErroNomeLgrdEndrCrsp(prospect.getEnderecoCorrespondencia().getFlagLogradouro());
        pcsmRgstCdstAtul.setNmLgrdEndrCrsp(prospect.getEnderecoCorrespondencia().getLogradouro());
        pcsmRgstCdstAtul.setDcCmpmLgrdEndrCrsp(prospect.getEnderecoCorrespondencia().getComplementoLogradouro());
        pcsmRgstCdstAtul.setCdErroNomeCideEndrCrsp(prospect.getEnderecoCorrespondencia().getFlagCidade());
        pcsmRgstCdstAtul.setNmCideEndrCrsp(prospect.getEnderecoCorrespondencia().getCidade());
        pcsmRgstCdstAtul.setCdErroSglaEstdEndrCrsp(prospect.getEnderecoCorrespondencia().getFlagEstado());
        pcsmRgstCdstAtul.setSgEstdEndrCrsp(prospect.getEnderecoCorrespondencia().getEstado());
        pcsmRgstCdstAtul.setCdErroNmroCepEndrCrsp(prospect.getEnderecoCorrespondencia().getFlagCep());
        pcsmRgstCdstAtul.setNuCepEndrCrsp(prospect.getEnderecoCorrespondencia().getCep());      
        pcsmRgstCdstAtul.setCdErroNmroEndrCrsa(prospect.getFlagNumEnderCorrespondecia());
        pcsmRgstCdstAtul.setNmroEndrCrsa(prospect.getNumEnderCorrespondecia());
	}

	/**
     * Método responsavel por popular as informações de endereço de comercial
     * @param pcsmRgstCdstAtul
     * @param prospect
     */
    private void popularEnderecoComercial(ProcessamentoRegistroArquivo pcsmRgstCdstAtul, Prospect prospect) {
    	prospect.getEnderecoEstabelecimento().setTipoEndereco(Constants.DOIS);//COMERCIAL
        pcsmRgstCdstAtul.setCdErroNomeLgrdEndrCmrl(prospect.getEnderecoEstabelecimento().getFlagLogradouro());        
        pcsmRgstCdstAtul.setDcCmpmLgrdEndrCmrl(prospect.getEnderecoEstabelecimento().getComplementoLogradouro());        
        pcsmRgstCdstAtul.setNmLgrdEndrCmrl(prospect.getEnderecoEstabelecimento().getLogradouro());        
        pcsmRgstCdstAtul.setCdErroNomeCideEndrCmrl(prospect.getEnderecoEstabelecimento().getFlagCidade());        
        pcsmRgstCdstAtul.setNmCideEndrCmrl(prospect.getEnderecoEstabelecimento().getCidade());        
        pcsmRgstCdstAtul.setCdErroSglaEstdEndrCmrl(prospect.getEnderecoEstabelecimento().getFlagEstado());        
        pcsmRgstCdstAtul.setSgEstdEndrCmrl(prospect.getEnderecoEstabelecimento().getEstado());        
        pcsmRgstCdstAtul.setCdErroNmroCepEndrCmrl(prospect.getEnderecoEstabelecimento().getFlagCep());        
        pcsmRgstCdstAtul.setNuCepEndrCmrl(prospect.getEnderecoEstabelecimento().getCep());  		
        pcsmRgstCdstAtul.setCdErroNmroEndrCmrl(prospect.getFlagNumEnderComercial());
        pcsmRgstCdstAtul.setNmroEndrCmrl(prospect.getNumEnderComercial());
	}

    /**
     * Método responsavel por popular as informações de domicilio bancário
     * @param pcsmRgstCdstAtul
     * @param prospect
     */
	private void popularDomicilioBancario(ProcessamentoRegistroArquivo pcsmRgstCdstAtul, Prospect prospect) {
       pcsmRgstCdstAtul.setCdErroCdgoAgnc(prospect.getDadosBancarios().getFlagCodigoAgencia());;	        
       pcsmRgstCdstAtul.setCdAgnc(prospect.getDadosBancarios().getCodigoAgencia());;	        
       pcsmRgstCdstAtul.setCdErroNmroCncr(prospect.getDadosBancarios().getFlagNumeroContaCorrente());;	        
       pcsmRgstCdstAtul.setNuCncr(prospect.getDadosBancarios().getNumeroContaCorrente());;
	}

	/**
	 * Método responsavel por popular as informações de Proprietarios
	 * @param pcsmRgstCdstAtul
	 * @param prospect
	 */
	private void popularProprietarios(ProcessamentoRegistroArquivo pcsmRgstCdstAtul, Prospect prospect) {
		//PROPRIETARIO 01
		Proprietario proprietario01 = prospect.getProprietarios().get(0);
	    pcsmRgstCdstAtul.setCdErroNomeCmplPrimPrpt(proprietario01.getFlagNomeProprietario());	    
	    pcsmRgstCdstAtul.setNmCmplPrimPrpt(proprietario01.getNomeProprietario());	    
	    pcsmRgstCdstAtul.setCdErroNmroCpfPrimPrpt(proprietario01.getFlagCpfProprietario());	    
	    pcsmRgstCdstAtul.setNuCpfPrimPrpt(proprietario01.getCpfProprietario());
	    pcsmRgstCdstAtul.setCdErroDataNscmPrimPrpt(proprietario01.getFlagDataNascimentoProprietario());
	    pcsmRgstCdstAtul.setDtNscmPrimPrpt(proprietario01.getDataNascimentoProprietario());
		//PROPRIETARIO 02
		Proprietario proprietario02 = prospect.getProprietarios().get(1);
	    pcsmRgstCdstAtul.setCdErroNomeCmplSgndPrpt(proprietario02.getFlagNomeProprietario());	    
	    pcsmRgstCdstAtul.setNmCmplSgndPrpt(proprietario02.getNomeProprietario());	    
	    pcsmRgstCdstAtul.setCdErroNmroCpfSgndPrpt(proprietario02.getFlagCpfProprietario());	    
	    pcsmRgstCdstAtul.setNuCpfSgndPrpt(proprietario02.getCpfProprietario());
	    pcsmRgstCdstAtul.setCdErroDataNscmSgndPrpt(proprietario02.getFlagDataNascimentoProprietario());
	    pcsmRgstCdstAtul.setDtNscmSgndPrpt(proprietario02.getDataNascimentoProprietario());
		//PROPRIETARIO 03
		Proprietario proprietario03 = prospect.getProprietarios().get(2);
	    pcsmRgstCdstAtul.setCdErroNomeCmplTerePrpt(proprietario03.getFlagNomeProprietario());	    
	    pcsmRgstCdstAtul.setNmCmplTerePrpt(proprietario03.getNomeProprietario());	    
	    pcsmRgstCdstAtul.setCdErroNmroCpfTerePrpt(proprietario03.getFlagCpfProprietario());	    
	    pcsmRgstCdstAtul.setNuCpfTerePrpt(proprietario03.getCpfProprietario());
	    pcsmRgstCdstAtul.setCdErroDataNscmTerePrpt(proprietario03.getFlagDataNascimentoProprietario());
	    pcsmRgstCdstAtul.setDtNscmTerePrpt(proprietario03.getDataNascimentoProprietario());		
	}

	/**
	 * Método responsavel por popular as informações de telefones
	 * @param pcsmRgstCdstAtul
	 * @param prospect
	 */
	private void popularTelefones(ProcessamentoRegistroArquivo pcsmRgstCdstAtul, Prospect prospect) {
		prospect.getTelefones().get(0).setCodigoTipoTelefone(Constants.TRES);//CELULAR
		Telefone telCelular = prospect.getTelefones().get(0);
	    pcsmRgstCdstAtul.setCdErroNmroDddSlcoMvel(telCelular.getFlagDDD());
	    pcsmRgstCdstAtul.setNuDddTlfnSlcoMvel(telCelular.getDdd());
	    pcsmRgstCdstAtul.setCdErroNmroTlfnSlcoMvel(telCelular.getFlagNumero());
	    pcsmRgstCdstAtul.setNuTlfnSlcoMvel(telCelular.getNumero());
	    
		prospect.getTelefones().get(1).setCodigoTipoTelefone(Constants.DOIS);//COMERCIAL
		Telefone telComercial = prospect.getTelefones().get(1);
	    pcsmRgstCdstAtul.setCdErroNmroDddTlfnFax(telComercial.getFlagDDD());
	    pcsmRgstCdstAtul.setNuDddTlfnFax(telComercial.getDdd());
	    pcsmRgstCdstAtul.setCdErroNmroTlfnFax(telComercial.getFlagNumero());
	    pcsmRgstCdstAtul.setNuTlfnFax(telComercial.getNumero());
	}

	/**
     * Método responsavel por obter o registro da situação Em Processamento
	 * @param isProspectValido 
     * @return
     */
    private SituacaoProcessRegistroArquivo getSituacaoProcessamento(boolean isProspectValido){
    	return (isProspectValido 
    			? sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.EM_PROCESSAMENTO.getCodigoSituacaoProposta())
    			: sitProcRegArquivoDAO.findOne(SitProcRegistroArquivoEnum.COM_ERRO.getCodigoSituacaoProposta()));
    }

	@Override
	public void atualizarTotalLinhaRemessa(Date dataExecucao, Integer codigoBanco, Integer numeroRemessa, Integer totalRegistros) {
		LogControleCargaBanco entity = getEntityControleCargaBanco(codigoBanco, dataExecucao, numeroRemessa);
		atualizarTotalLogCargaBanco(entity, totalRegistros);
	}
    
    /**
     * Metodo que atualiza a quantidade dos registros no log da carga do banco
     * 
     * @param quantidadeRegistros
     *            parametro de entrada do metodo
     * @param tbcrdrLogCntrCrgaBnco
     *            parametro de entrada do metodo
     * @param recusado
     *            parametro de entrada do metodo
     * @return tabela log controle carga banco
     */
    private void atualizarTotalLogCargaBanco(LogControleCargaBanco entity, Integer totalRegistros) {
    	entity.setQtTotlRgst(totalRegistros); 
    	this.arquivoDAO.update(entity);
    }

}
