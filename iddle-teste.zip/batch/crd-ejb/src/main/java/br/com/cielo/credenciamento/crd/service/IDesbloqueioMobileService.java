package br.com.cielo.credenciamento.crd.service;

import javax.ejb.Local;

import br.com.cielo.credenciamento.ejb.remote.IDesbloqueioMobileServiceRemote;

/**
 * Interface local, responsavel pelo tratamento do desbloqueio mobile
 * @author @Cielo S/A
 * @since Release 03 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IDesbloqueioMobileService extends IDesbloqueioMobileServiceRemote{

}
