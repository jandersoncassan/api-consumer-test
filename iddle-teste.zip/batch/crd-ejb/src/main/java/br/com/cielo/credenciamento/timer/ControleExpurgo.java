package br.com.cielo.credenciamento.timer;

import javax.ejb.Schedule;
import javax.ejb.Singleton;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.service.IRotinaExpurgoService;

@Singleton
public class ControleExpurgo {
	
	private static final Logger LOG = LoggerFactory.getLogger(ControleExpurgo.class);
	
	private final String NAME_CLUSTER = "weblogic.Name";
	private final String CLUSTER_NO1 = "credServer1";

	@Inject
	private IRotinaExpurgoService rotinaExpurgoService;
	
	@Schedule(dayOfWeek = "Sat", hour = "18", minute = "30", info = "EXPURGO TABELA WORK OCORRE DE SABADO E EXCLUI REGISTROS COM MAIS DE 90 DIAS", persistent = false )
	public void initExpurgo() {
		
		String nameServer = System.getProperty(NAME_CLUSTER);
		LOG.info("INIT EXECUCAO ROTINA DE EXPURGO | NOME SERVIDOR : {} ", nameServer);

		if (nameServer.equals(CLUSTER_NO1)) {
			rotinaExpurgoService.executarExpurgo();
			LOG.info("FINISHED EXECUCAO ROTINA DE EXPURGO");
		}
	}

}
