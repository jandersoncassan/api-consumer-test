package br.com.cielo.credenciamento.persistence.dao;

import java.util.Date;
import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.LogControleCargaBanco;

/**
 * Interface responsavel pelo tratamento de arquivos tabela work e controle de carga
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IArquivoDAO extends IOperations<LogControleCargaBanco> {


	/**
	 * Método responsavel por obter o registro de controle de carga
	 * @param banco
	 * @param dataExecucao
	 * @param numeroRemessa
	 * @return
	 */
	LogControleCargaBanco findEntity(Integer banco, Date dataExecucao, Integer numeroRemessa);

    /**
     * Método responsavel por buscar o proximo numero de remessas
     * @param dataInsercao
     * @param banco
     * @return
     */
    Integer findNextNumRemessa(Date dataInsercao, Integer banco);
    
}
