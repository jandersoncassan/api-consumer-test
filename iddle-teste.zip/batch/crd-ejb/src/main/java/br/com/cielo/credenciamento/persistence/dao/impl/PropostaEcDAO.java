package br.com.cielo.credenciamento.persistence.dao.impl;

import javax.ejb.Stateless;
import javax.persistence.NoResultException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.persistence.dao.IPropostaEcDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.EstabelecimentoComercial;

/**
 * Classe DAO responsavel pelas consistências envolvendo o estabelecimento da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class PropostaEcDAO extends AbstractJpaDAO<EstabelecimentoComercial> implements IPropostaEcDAO {

	private static final Logger LOG = LoggerFactory.getLogger(PropostaEcDAO.class);
	
    public PropostaEcDAO() {
        super(EstabelecimentoComercial.class);
    }

	@Override
	public EstabelecimentoComercial findByEc(Long numeroEc) {
		LOG.info("BUSCANDO O EC COM ID {}", numeroEc);
		try{
			StringBuilder sql = new StringBuilder("FROM "+getEntityClass().getSimpleName());
			              sql.append(" WHERE nuEc = :pNUmeroEc");		              
			              
			TypedQuery<EstabelecimentoComercial> query = getEntityManager().createQuery(sql.toString(),	EstabelecimentoComercial.class);
			query.setParameter("pNUmeroEc", numeroEc);
	
			return query.getSingleResult();
		
		}catch(NoResultException ex){
			LOG.error("O EC {} NAO FOI CADASTRADO VIA CRD", numeroEc);
			return null;
		}
	}
	
	@Override
	public void atualizarSituacaoProposta(Long numeroProposta) {
		LOG.info("DAO - ATUALIZAR SITUACAO DA PROPOSTA");
		try {
			StringBuilder sql = new StringBuilder("UPDATE TBCRDR_PRPS_CRDN ");
						               sql.append("SET CD_STCO_PRPS_CRDN = 2 ");
						               sql.append("WHERE NU_PRPS_CRDN = :numProposta ");
						               
			Query query = getEntityManager().createNativeQuery(sql.toString());
			query.setParameter("numProposta",numeroProposta);
			query.executeUpdate();

		} catch (Exception ex) {
			LOG.error("ERROR ATUALIZAR SITUACAO DA PROPOSTA {}", ex);
		}
	}

	
    
}
