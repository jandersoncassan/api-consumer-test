package br.com.cielo.credenciamento.persistence.dao.impl;

import javax.ejb.Stateless;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.persistence.dao.ISituacaoProcessRegistroArquivoDAO;
import br.com.cielo.credenciamento.persistence.dao.common.AbstractJpaDAO;
import br.com.cielo.credenciamento.persistence.entity.SituacaoProcessRegistroArquivo;

/**
 * Classe DAO responsavel pelas consistencias envolvendo a situação de processamento do registro
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class SituacaoProcessRegistroArquivoDAO extends AbstractJpaDAO<SituacaoProcessRegistroArquivo> implements ISituacaoProcessRegistroArquivoDAO {

	private static final Logger LOG = LoggerFactory.getLogger(SituacaoProcessRegistroArquivoDAO.class);

    public SituacaoProcessRegistroArquivoDAO() {
        super(SituacaoProcessRegistroArquivo.class);
    }
    
    @Override
    public SituacaoProcessRegistroArquivo findOne(long id) {
    	LOG.info("BUSCANDO A SITUACAO DO PROCESSAMENTO COM ID {}", id);
    	return super.findOne(id);
    }
}
