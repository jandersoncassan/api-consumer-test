package br.com.cielo.credenciamento.crd.service.impl;

import java.io.IOException;

import javax.ejb.Stateless;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import br.com.cielo.credenciamento.crd.exception.CredenciarClienteException;
import br.com.cielo.credenciamento.crd.service.IConsistenciasInfoCrdService;
import br.com.cielo.credenciamento.crd.service.IConsistenciasInfoOsbService;
import br.com.cielo.credenciamento.crd.service.ICredenciarClienteService;
import br.com.cielo.credenciamento.crd.util.CrdFileUtil;
import br.com.cielo.credenciamento.crd.util.CrdUtils;
import br.com.cielo.credenciamento.ejb.domain.batch.Prospect;
import br.com.cielo.credenciamento.model.Criticas;

/**
 * Classe responsavel pela implementação dos serviços de credenciamento via CRD (RL01)
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Stateless
public class CredenciarClienteServiceImpl implements ICredenciarClienteService{

	private static final Logger LOG = LoggerFactory.getLogger(CredenciarClienteServiceImpl.class);

	@Inject
	private IConsistenciasInfoOsbService infoOsbService;

	@Inject
	private IConsistenciasInfoCrdService infoCrdService;

	@Inject
	private CrdFileUtil crdFileUtil;	
	
	// CHAMADA SERVIÇO
	private final String OSB_SERVICE = "OSB";
	
	private Criticas criticas;
	
	
	@Override
	public void credenciarCliente(final Prospect proposta) {
		LOG.info("INIT - CREDENCIAR CLIENTE CRD RL01");
		try{
			initCredenciarCliente(proposta);

		}catch(Exception ex){
			LOG.error("OCORREU UM ERRO AO EFETIVAR O CREDENCIAMENTO DO CLIENTE {}", ex);
			throw new CredenciarClienteException("Erro credenciamento cliente via RL01", ex);
		}
	}

	/**
	 * Método responsavel por iniciar o credenciamento via OSB
	 * @param proposta
	 */
	private void initCredenciarCliente(Prospect proposta) {		
		String tipoProcessamento = getTipoProcessamento();
		if(tipoProcessamento.equals(OSB_SERVICE)){
			initServiceOSB(proposta);
		}else{
			//CONTINGÊNCIA SERVIÇO CRD
			initServiceCRD(proposta);
		}		
	}

	/**
	 * Método responsavel por efetivar o credenciamento via serviço OSB
	 * @param proposta
	 */
	private void initServiceOSB(Prospect proposta){
		infoOsbService.efetivarCredenciamentoOSB(proposta, getListaCriticas());		
	}
	
	/**
	 * Método responsavel por efetivar o credenciamento via serviço CRD
	 * @param proposta
	 */
	private void initServiceCRD(Prospect proposta){
		infoCrdService.efetivarCredenciamentoCRD(proposta, getListaCriticas());
	}
	
	@Override
	public Criticas getListaCriticas() {
		if(null == criticas){
			loadListaCriticas();
		}
		return criticas;
	}

	/**
	 * Recupera o tipo de processamento que deve ser efetivado
	 * quando contingencia o servico chamado será o do crd direto
	 * @return
	 */
	private String getTipoProcessamento(){
		return (crdFileUtil.getMessage(CrdUtils.PROCESS_SERVICE));
	}

	
	/**
	 * Método responsavel por carregar a lista de Criticas CRD
	 */
	private void loadListaCriticas() {
		String pathJson = crdFileUtil.getMessage(CrdUtils.PATH_FILE_JSON_CITICAS);
		try {
			criticas = CrdUtils.loadFileCriticas(Criticas.class, pathJson);
		} catch (IOException ex) {
			LOG.error("OCORREU UM ERRO AO CARREGAR O ARQUIVO DE PROPRIEDADES CRITICAS  {}", ex);
		}
	}

	@Override
	public void limparListaCriticas() {
		criticas = null;		
	}


	
}
