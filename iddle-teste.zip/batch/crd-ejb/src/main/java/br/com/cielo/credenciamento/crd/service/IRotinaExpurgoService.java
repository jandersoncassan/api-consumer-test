package br.com.cielo.credenciamento.crd.service;

public interface IRotinaExpurgoService {

	/**
	 * Método responsavel pela execução da rotina de expurgo da tabela work
	 * Esse expurgo ocorre de sabado e exclui fisicamente todos os registro com mais de 90 dias
	 */
	void executarExpurgo();
}
