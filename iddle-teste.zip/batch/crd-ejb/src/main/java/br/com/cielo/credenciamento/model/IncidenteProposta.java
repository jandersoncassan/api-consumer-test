package br.com.cielo.credenciamento.model;

/**
 * Classe Model utilizada no tratamento de retomada de incidentes da proposta.
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
public class IncidenteProposta {	
	 
	 private Integer codigoEtapa;
	 
	 private Integer codigoCritica;	 
	 
	 private Integer codSitEtapa;	 
	 
	 private Integer codTipoErroValidacao;	 
	 
	 private String numeroEc;
	 
	 private Integer sequenciaCampo;
	 
	 private String flagRessalva;

	/**
	 * @return the codigoEtapa
	 */
	public Integer getCodigoEtapa() {
		return codigoEtapa;
	}

	/**
	 * @param codigoEtapa the codigoEtapa to set
	 */
	public void setCodigoEtapa(Integer codigoEtapa) {
		this.codigoEtapa = codigoEtapa;
	}

	/**
	 * @return the codigoCritica
	 */
	public Integer getCodigoCritica() {
		return codigoCritica;
	}

	/**
	 * @param codigoCritica the codigoCritica to set
	 */
	public void setCodigoCritica(Integer codigoCritica) {
		this.codigoCritica = codigoCritica;
	}

	/**
	 * @return the codSitEtapa
	 */
	public Integer getCodSitEtapa() {
		return codSitEtapa;
	}

	/**
	 * @param codSitEtapa the codSitEtapa to set
	 */
	public void setCodSitEtapa(Integer codSitEtapa) {
		this.codSitEtapa = codSitEtapa;
	}

	/**
	 * @return the codTipoErroValidacao
	 */
	public Integer getCodTipoErroValidacao() {
		return codTipoErroValidacao;
	}

	/**
	 * @param codTipoErroValidacao the codTipoErroValidacao to set
	 */
	public void setCodTipoErroValidacao(Integer codTipoErroValidacao) {
		this.codTipoErroValidacao = codTipoErroValidacao;
	}

	/**
	 * @return the numeroEc
	 */
	public String getNumeroEc() {
		return numeroEc;
	}

	/**
	 * @param numeroEc the numeroEc to set
	 */
	public void setNumeroEc(String numeroEc) {
		this.numeroEc = numeroEc;
	}

	/**
	 * @return the sequenciaCampo
	 */
	public Integer getSequenciaCampo() {
		return sequenciaCampo;
	}

	/**
	 * @param sequenciaCampo the sequenciaCampo to set
	 */
	public void setSequenciaCampo(Integer sequenciaCampo) {
		this.sequenciaCampo = sequenciaCampo;
	}

	/**
	 * @return the flagRessalva
	 */
	public String getFlagRessalva() {
		return flagRessalva;
	}

	/**
	 * @param flagRessalva the flagRessalva to set
	 */
	public void setFlagRessalva(String flagRessalva) {
		this.flagRessalva = flagRessalva;
	}
	 
}
