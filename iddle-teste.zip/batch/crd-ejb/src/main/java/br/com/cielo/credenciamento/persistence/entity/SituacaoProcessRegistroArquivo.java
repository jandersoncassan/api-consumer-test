package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entidade representando a tabela de Situacao do Processamento Registro 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDW_STCO_PCSM_RGST_ARQV")
public class SituacaoProcessRegistroArquivo implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "CD_STCO_PCSM_RGST_ARQV", unique = true, nullable = false, precision = 2)
    private Integer codSituacao;

    @Column(name = "DC_STCO_PCSM_RGST_ARQV", nullable = false, length = 50)
    private String descSituacao;

    @Column(name = "CD_USRO_INCL_RGST", nullable = false, length = 20)
    private String cdUsroInclRgst;

    @Column(name = "DH_INCL_RGST", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date dhInclRgst;

    @Column(name = "CD_USRO_ALTR_RGST", length = 20)
    private String cdUsroAltrRgst;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DH_ALTR_RGST")
    private Date dhAltrRgst;

	/**
	 * @return the codSituacao
	 */
	public Integer getCodSituacao() {
		return codSituacao;
	}

	/**
	 * @param codSituacao the codSituacao to set
	 */
	public void setCodSituacao(Integer codSituacao) {
		this.codSituacao = codSituacao;
	}

	/**
	 * @return the descSituacao
	 */
	public String getDescSituacao() {
		return descSituacao;
	}

	/**
	 * @param descSituacao the descSituacao to set
	 */
	public void setDescSituacao(String descSituacao) {
		this.descSituacao = descSituacao;
	}

	/**
	 * @return the cdUsroInclRgst
	 */
	public String getCdUsroInclRgst() {
		return cdUsroInclRgst;
	}

	/**
	 * @param cdUsroInclRgst the cdUsroInclRgst to set
	 */
	public void setCdUsroInclRgst(String cdUsroInclRgst) {
		this.cdUsroInclRgst = cdUsroInclRgst;
	}

	/**
	 * @return the dhInclRgst
	 */
	public Date getDhInclRgst() {
		return dhInclRgst;
	}

	/**
	 * @param dhInclRgst the dhInclRgst to set
	 */
	public void setDhInclRgst(Date dhInclRgst) {
		this.dhInclRgst = dhInclRgst;
	}

	/**
	 * @return the cdUsroAltrRgst
	 */
	public String getCdUsroAltrRgst() {
		return cdUsroAltrRgst;
	}

	/**
	 * @param cdUsroAltrRgst the cdUsroAltrRgst to set
	 */
	public void setCdUsroAltrRgst(String cdUsroAltrRgst) {
		this.cdUsroAltrRgst = cdUsroAltrRgst;
	}

	/**
	 * @return the dhAltrRgst
	 */
	public Date getDhAltrRgst() {
		return dhAltrRgst;
	}

	/**
	 * @param dhAltrRgst the dhAltrRgst to set
	 */
	public void setDhAltrRgst(Date dhAltrRgst) {
		this.dhAltrRgst = dhAltrRgst;
	}

    
 
}
