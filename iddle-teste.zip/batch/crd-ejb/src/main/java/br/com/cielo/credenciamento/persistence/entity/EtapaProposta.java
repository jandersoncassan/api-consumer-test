package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entidade responsavel por representar a tabela de etapas da proposta
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDR_ETPA_PRPS_CRDN")
public class EtapaProposta implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    private EtapaPropostaPK id;

    @Column(name="CD_STCO_ETPA_PRPS_CRDN", length=3)
    private Integer codSituacaoEtapa;
    
    @Temporal(TemporalType.DATE)
    @Column(name = "DH_ABRT_ETPA_PRPS_CRDN", nullable = false)
    private Date dhAbrtEtpaPrpsCrdn;

    @Column(name = "CD_USRO_INCL_RGST", nullable = false, length = 20)
    private String cdUsroInclRgst;

    @Temporal(TemporalType.DATE)
    @Column(name = "DH_INCL_RGST", nullable = false)
    private Date dhInclRgst;
  
    @Column(name = "CD_USRO_ALTR_RGST", length = 20)
    private String cdUsroAltrRgst;

    @Temporal(TemporalType.DATE)
    @Column(name = "DH_ALTR_RGST")
    private Date dhAltrRgst;

    @Temporal(TemporalType.DATE)
    @Column(name = "DH_ENCE_ETPA_PRPS_CRDN", nullable = true)
    private Date dhEnceEtpaPrpsCrdn;

	/**
	 * @return the id
	 */
	public EtapaPropostaPK getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(EtapaPropostaPK id) {
		this.id = id;
	}

	/**
	 * @return the codSituacaoEtapa
	 */
	public Integer getCodSituacaoEtapa() {
		return codSituacaoEtapa;
	}

	/**
	 * @param codSituacaoEtapa the codSituacaoEtapa to set
	 */
	public void setCodSituacaoEtapa(Integer codSituacaoEtapa) {
		this.codSituacaoEtapa = codSituacaoEtapa;
	}

	/**
	 * @return the cdUsroAltrRgst
	 */
	public String getCdUsroAltrRgst() {
		return cdUsroAltrRgst;
	}

	/**
	 * @param cdUsroAltrRgst the cdUsroAltrRgst to set
	 */
	public void setCdUsroAltrRgst(String cdUsroAltrRgst) {
		this.cdUsroAltrRgst = cdUsroAltrRgst;
	}

	/**
	 * @return the cdUsroInclRgst
	 */
	public String getCdUsroInclRgst() {
		return cdUsroInclRgst;
	}

	/**
	 * @param cdUsroInclRgst the cdUsroInclRgst to set
	 */
	public void setCdUsroInclRgst(String cdUsroInclRgst) {
		this.cdUsroInclRgst = cdUsroInclRgst;
	}

	/**
	 * @return the dhAbrtEtpaPrpsCrdn
	 */
	public Date getDhAbrtEtpaPrpsCrdn() {
		return dhAbrtEtpaPrpsCrdn;
	}

	/**
	 * @param dhAbrtEtpaPrpsCrdn the dhAbrtEtpaPrpsCrdn to set
	 */
	public void setDhAbrtEtpaPrpsCrdn(Date dhAbrtEtpaPrpsCrdn) {
		this.dhAbrtEtpaPrpsCrdn = dhAbrtEtpaPrpsCrdn;
	}

	/**
	 * @return the dhAltrRgst
	 */
	public Date getDhAltrRgst() {
		return dhAltrRgst;
	}

	/**
	 * @param dhAltrRgst the dhAltrRgst to set
	 */
	public void setDhAltrRgst(Date dhAltrRgst) {
		this.dhAltrRgst = dhAltrRgst;
	}

	/**
	 * @return the dhInclRgst
	 */
	public Date getDhInclRgst() {
		return dhInclRgst;
	}

	/**
	 * @param dhInclRgst the dhInclRgst to set
	 */
	public void setDhInclRgst(Date dhInclRgst) {
		this.dhInclRgst = dhInclRgst;
	}

	/**
	 * @return the dhEnceEtpaPrpsCrdn
	 */
	public Date getDhEnceEtpaPrpsCrdn() {
		return dhEnceEtpaPrpsCrdn;
	}

	/**
	 * @param dhEnceEtpaPrpsCrdn the dhEnceEtpaPrpsCrdn to set
	 */
	public void setDhEnceEtpaPrpsCrdn(Date dhEnceEtpaPrpsCrdn) {
		this.dhEnceEtpaPrpsCrdn = dhEnceEtpaPrpsCrdn;
	}
    
}
