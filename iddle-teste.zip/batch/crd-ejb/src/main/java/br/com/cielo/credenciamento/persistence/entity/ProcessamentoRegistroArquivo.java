package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * Entidade representando a tabela work, Processamento do Registro 
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDW_PCSM_RGST_CDST_ATUL")
public class ProcessamentoRegistroArquivo implements Serializable {
    
      private static final long serialVersionUID = 1L;

    @EmbeddedId
    private ProcessamentoRegistroArquivoPK id;

    // bi-directional many-to-one association to TbcrdwStcoPcsmRgstArqv
    @ManyToOne
    @JoinColumn(name = "CD_STCO_PCSM_RGST_ARQV", nullable = false)
    private SituacaoProcessRegistroArquivo situacaoRegistro;

    @Column(name = "CD_FNLD_ARQV", length = 3)
    private String cdFnldArqv;
    
    @Column(name = "CD_BNCO_SLCE_PRPS_CRDN", length = 8)
    private String cdBncoSlcePrpsCrdn;
    
    @Column(name = "NU_SPB_BNCO_SLCE_PRPS_CRDN", length = 4)
    private String nuSpbBncoSlcePrpsCrdn;
    
    @Column(name = "NU_IDTF_ORGM_SLCT_AFLC", length = 4)
    private String nuIdtfOrgmSlctAflc;
    
    @Column(name = "TX_PRIM_EPCO_RSRD_CILO", length = 19)
    private String txPrimEpcoRsrdCilo;
    
    @Column(name = "CD_ERRO_VLDC_ARQV", length = 2)
    private String cdErroVldcArqv;
    
    @Column(name = "CD_ERRO_CDGO_BNCO_PRPS_CRDN", length = 2)
    private String cdErroCdgoBncoPrpsCrdn;
    
    @Column(name = "CD_BNCO_PRPS_CRDN", length = 3)
    private String cdBncoPrpsCrdn;
    
    @Column(name = "NU_EC", length = 10)
    private String nuEc;
    
    @Column(name = "CD_ERRO_NM_RAZO_SOCL", length = 2)
    private String cdErroNmRazoSocl;
    
    @Column(name = "NM_RAZO_SOCL", length = 32)
    private String nmRazoSocl;
    
    @Column(name = "CD_ERRO_NOME_LGRD_ENDR_CRSP", length = 2)
    private String cdErroNomeLgrdEndrCrsp;
    
    @Column(name = "NM_LGRD_ENDR_CRSP", length = 32)
    private String nmLgrdEndrCrsp;
    
    @Column(name = "DC_CMPM_LGRD_ENDR_CRSP", length = 32)
    private String dcCmpmLgrdEndrCrsp;
    
    @Column(name = "CD_ERRO_NOME_CIDE_ENDR_CRSP", length = 2)
    private String cdErroNomeCideEndrCrsp;
    
    @Column(name = "NM_CIDE_ENDR_CRSP", length = 28)
    private String nmCideEndrCrsp;
    
    @Column(name = "CD_ERRO_SGLA_ESTD_ENDR_CRSP", length = 2)
    private String cdErroSglaEstdEndrCrsp;
    
    @Column(name = "SG_ESTD_ENDR_CRSP", length = 2)
    private String sgEstdEndrCrsp;
    
    @Column(name = "CD_ERRO_NMRO_CEP_ENDR_CRSP", length = 2)
    private String cdErroNmroCepEndrCrsp;
    
    @Column(name = "NU_CEP_ENDR_CRSP", length = 8)
    private String nuCepEndrCrsp;
    
    @Column(name = "CD_ERRO_NMRO_CPF_CNPJ", length = 2)
    private String cdErroNmroCpfCnpj;
    
    @Column(name = "NU_CPF_CNPJ", length = 15)
    private String nuCpfCnpj;
    
    @Column(name = "CD_ERRO_NMRO_IE", length = 2)
    private String cdErroNmroIe;
    
    @Column(name = "NU_IE", length = 15)
    private String nuIe;
    
    @Column(name = "CD_ERRO_NOME_FNTS", length = 2)
    private String cdErroNomeFnts;
    
    @Column(name = "NM_FNTS", length = 32)
    private String nmFnts;
    
    @Column(name = "CD_ERRO_NOME_LGRD_ENDR_CMRL", length = 2)
    private String cdErroNomeLgrdEndrCmrl;
    
    @Column(name = "DC_CMPM_LGRD_ENDR_CMRL", length = 32)
    private String dcCmpmLgrdEndrCmrl;
    
    @Column(name = "NM_LGRD_ENDR_CMRL", length = 32)
    private String nmLgrdEndrCmrl;
    
    @Column(name = "CD_ERRO_NOME_CIDE_ENDR_CMRL", length = 2)
    private String cdErroNomeCideEndrCmrl;
    
    @Column(name = "NM_CIDE_ENDR_CMRL", length = 28)
    private String nmCideEndrCmrl;
    
    @Column(name = "CD_ERRO_SGLA_ESTD_ENDR_CMRL", length = 2)
    private String cdErroSglaEstdEndrCmrl;
    
    @Column(name = "SG_ESTD_ENDR_CMRL", length = 2)
    private String sgEstdEndrCmrl;
    
    @Column(name = "CD_ERRO_NMRO_CEP_ENDR_CMRL", length = 2)
    private String cdErroNmroCepEndrCmrl;
    
    @Column(name = "NU_CEP_ENDR_CMRL", length = 8)
    private String nuCepEndrCmrl;
    
    @Column(name = "CD_ERRO_NOME_PLQT_EC", length = 2)
    private String cdErroNomePlqtEc;
    
    @Column(name = "NM_PLQT_EC", length = 22)
    private String nmPlqtEc;
    
    @Column(name = "CD_ERRO_NOME_PESA_CNTO", length = 2)
    private String cdErroNomePesaCnto;
    
    @Column(name = "NM_PESA_CNTO", length = 32)
    private String nmPesaCnto;
    
    @Column(name = "TX_EPCO_RSRD_ARQV", length = 44)
    private String txEpcoRsrdArqv;
    
    @Column(name = "CD_ERRO_CDGO_MCC", length = 2)
    private String cdErroCdgoMcc;
    
    @Column(name = "CD_MCC", length = 5)
    private String cdMcc;
    
    @Column(name = "CD_ERRO_CDGO_AGNC", length = 2)
    private String cdErroCdgoAgnc;
    
    @Column(name = "CD_AGNC", length = 5)
    private String cdAgnc;
    
    @Column(name = "CD_ERRO_NMRO_CNCR", length = 2)
    private String cdErroNmroCncr;
    
    @Column(name = "NU_CNCR", length = 14)
    private String nuCncr;
    
    @Column(name = "CD_ERRO_NOME_CMPL_PRIM_PRPT", length = 2)
    private String cdErroNomeCmplPrimPrpt;
    
    @Column(name = "NM_CMPL_PRIM_PRPT", length = 32)
    private String nmCmplPrimPrpt;
    
    @Column(name = "CD_ERRO_NMRO_CPF_PRIM_PRPT", length = 2)
    private String cdErroNmroCpfPrimPrpt;
    
    @Column(name = "NU_CPF_PRIM_PRPT", length = 15)
    private String nuCpfPrimPrpt;

    @Column(name = "CD_ERRO_DATA_NSCM_PRIM_PRPT", length = 2)
    private String cdErroDataNscmPrimPrpt;

    @Column(name = "DT_NSCM_PRIM_PRPT", length = 6)
    private String dtNscmPrimPrpt;

    @Column(name = "CD_ERRO_NOME_CMPL_SGND_PRPT", length = 2)
    private String cdErroNomeCmplSgndPrpt;

    @Column(name = "NM_CMPL_SGND_PRPT", length = 32)
    private String nmCmplSgndPrpt;

    @Column(name = "CD_ERRO_NMRO_CPF_SGND_PRPT", length = 2)
    private String cdErroNmroCpfSgndPrpt;
    
    @Column(name = "NU_CPF_SGND_PRPT", length = 15)
    private String nuCpfSgndPrpt;
    
    @Column(name = "CD_ERRO_DATA_NSCM_SGND_PRPT", length = 2)
    private String cdErroDataNscmSgndPrpt;
    
    @Column(name = "DT_NSCM_SGND_PRPT", length = 6)
    private String dtNscmSgndPrpt;
    
    @Column(name = "CD_ERRO_NOME_CMPL_TERE_PRPT", length = 2)
    private String cdErroNomeCmplTerePrpt;
    
    @Column(name = "NM_CMPL_TERE_PRPT", length = 32)
    private String nmCmplTerePrpt;
    
    @Column(name = "CD_ERRO_NMRO_CPF_TERE_PRPT", length = 2)
    private String cdErroNmroCpfTerePrpt;
    
    @Column(name = "NU_CPF_TERE_PRPT", length = 15)
    private String nuCpfTerePrpt;
    
    @Column(name = "CD_ERRO_DATA_NSCM_TERE_PRPT", length = 2)
    private String cdErroDataNscmTerePrpt;
    
    @Column(name = "DT_NSCM_TERE_PRPT", length = 6)
    private String dtNscmTerePrpt;
    
    @Column(name = "CD_ERRO_SG_TIPO_PESA", length = 2)
    private String cdErroSgTipoPesa;
    
    @Column(name = "SG_TIPO_PESA", length = 1)
    private String sgTipoPesa;
    
    @Column(name = "TX_NONO_EPCO_RSRD_CILO", length = 12)
    private String txNonoEpcoRsrdCilo;
    
    @Column(name = "CD_ERRO_NMRO_DDD_SLCO_MVEL", length = 2)
    private String cdErroNmroDddSlcoMvel;
    
    @Column(name = "NU_DDD_TLFN_SLCO_MVEL", length = 4)
    private String nuDddTlfnSlcoMvel;
    
    @Column(name = "CD_ERRO_NMRO_TLFN_SLCO_MVEL", length = 2)
    private String cdErroNmroTlfnSlcoMvel;
    
    @Column(name = "NU_TLFN_SLCO_MVEL", length = 9)
    private String nuTlfnSlcoMvel;

    @Column(name = "CD_ERRO_NMRO_DDD_TLFN_FAX", length = 2)
    private String cdErroNmroDddTlfnFax;

    @Column(name = "NU_DDD_TLFN_FAX", length = 4)
    private String nuDddTlfnFax;

    @Column(name = "CD_ERRO_NMRO_TLFN_FAX", length = 2)
    private String cdErroNmroTlfnFax;
    
    @Column(name = "NU_TLFN_FAX", length = 9)
    private String nuTlfnFax;
    
    @Column(name = "CD_ERRO_IDCR_MEI", length = 2)
    private String cdErroIdcrMei;
    
    @Column(name = "IN_MEI", length = 1)
    private String inMei;
    
    @Column(name = "TX_QRTO_EPCO_RSRD_CILO", length = 6)
    private String txQrtoEpcoRsrdCilo;

    @Column(name = "CD_ERRO_PCTE_CMEL", length = 2)
    private String cdErroPcteCmel;

    @Column(name = "CD_PCTE_CMEL", length = 1)
    private String cdPcteCmel;

    @Column(name = "TX_QUNT_EPCO_RSRD_CILO", length = 6)
    private String txQuntEpcoRsrdCilo;
 
    @Column(name = "CD_ERRO_TIPO_CNTA", length = 2)
    private String cdErroTipoConta;

    @Column(name = "CD_TIPO_CNTA", length = 1)
    private String cdTipoConta;

    @Column(name = "TX_DCMO_EPCO_RSRD_CILO", length = 5)
    private String txDcmoEpcoRsrdCilo;
 
    @Column(name = "CD_ERRO_PLNO_CILO", length = 2)
    private String cdErroPlnoCilo;

    @Column(name = "CD_PLNO_CILO", length = 2)
    private String cdPlnoCilo;
   
    @Column(name = "CD_ERRO_VALR_FTRM", length = 2)
    private String cdErroValrFtrm;

    @Column(name = "VL_FTRM", length = 13)
    private String ValrFtrm;

    @Column(name = "CD_ERRO_QNTD_DIA_LQDC", length = 2)
    private String cdErroQntdDiaLqdc;

    @Column(name = "QT_DIA_LQDC", length = 2)
    private String QntdDiaLqdc;
 
    @Column(name = "CD_ERRO_SLCP", length = 2)
    private String cdErroSlcp;

    @Column(name = "CD_SLCP", length = 6)
    private String cdSlcp;
  
    @Column(name = "CD_ERRO_IDCR_AGRO", length = 2)
    private String cdErroIdcrAgro;

    @Column(name = "IN_AGRO", length = 1)
    private String cdIdcrAgro;
  
    @Column(name = "CD_ERRO_NMRO_ENDR_CMRL", length = 2)
    private String cdErroNmroEndrCmrl;

    @Column(name = "NU_ENDR_CMRL", length = 5)
    private String nmroEndrCmrl;
   
    @Column(name = "CD_ERRO_NMRO_ENDR_CRSA", length = 2)
    private String cdErroNmroEndrCrsa;

    @Column(name = "NU_ENDR_CRSA", length = 5)
    private String nmroEndrCrsa;
    
    @Column(name = "CD_ERRO_DERC_EMAL", length = 2)
    private String cdErroDercEmal;
    
    @Column(name = "TX_SXTO_EPCO_RSRD_CILO", length = 806)
    private String txSxtoEpcoRsrdCilo;

    @Column(name = "DC_EMAL", length = 60)
    private String descEmail;

    @Column(name = "TX_STMO_EPCO_RSRD_CILO", length = 251)
    private String txStmoEpcoRsrdCilo;
    

    // bi-directional one-to-one association to TbcrdrLogCntrCrgaBnco
    @ManyToOne(cascade = {CascadeType.PERSIST})
    @JoinColumns({
        @JoinColumn(name = "CD_BNCO", referencedColumnName = "CD_BNCO", nullable = false, insertable = false, updatable = false),
        @JoinColumn(name = "DT_MVMN_ARQV_BNCO", referencedColumnName = "DT_MVMN_ARQV_BNCO", nullable = false, insertable = false, updatable = false),
        @JoinColumn(name = "NU_RMSA_ARQV_BNCO", referencedColumnName = "NU_RMSA_ARQV_BNCO", nullable = false, insertable = false, updatable = false)})
    private LogControleCargaBanco controleCargaBanco;


	/**
	 * @return the id
	 */
	public ProcessamentoRegistroArquivoPK getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 */
	public void setId(ProcessamentoRegistroArquivoPK id) {
		this.id = id;
	}


	/**
	 * @return the situacaoRegistro
	 */
	public SituacaoProcessRegistroArquivo getSituacaoRegistro() {
		return situacaoRegistro;
	}


	/**
	 * @param situacaoRegistro the situacaoRegistro to set
	 */
	public void setSituacaoRegistro(SituacaoProcessRegistroArquivo situacaoRegistro) {
		this.situacaoRegistro = situacaoRegistro;
	}


	/**
	 * @return the cdFnldArqv
	 */
	public String getCdFnldArqv() {
		return cdFnldArqv;
	}


	/**
	 * @param cdFnldArqv the cdFnldArqv to set
	 */
	public void setCdFnldArqv(String cdFnldArqv) {
		this.cdFnldArqv = cdFnldArqv;
	}


	/**
	 * @return the cdBncoSlcePrpsCrdn
	 */
	public String getCdBncoSlcePrpsCrdn() {
		return cdBncoSlcePrpsCrdn;
	}


	/**
	 * @param cdBncoSlcePrpsCrdn the cdBncoSlcePrpsCrdn to set
	 */
	public void setCdBncoSlcePrpsCrdn(String cdBncoSlcePrpsCrdn) {
		this.cdBncoSlcePrpsCrdn = cdBncoSlcePrpsCrdn;
	}


	/**
	 * @return the nuSpbBncoSlcePrpsCrdn
	 */
	public String getNuSpbBncoSlcePrpsCrdn() {
		return nuSpbBncoSlcePrpsCrdn;
	}


	/**
	 * @param nuSpbBncoSlcePrpsCrdn the nuSpbBncoSlcePrpsCrdn to set
	 */
	public void setNuSpbBncoSlcePrpsCrdn(String nuSpbBncoSlcePrpsCrdn) {
		this.nuSpbBncoSlcePrpsCrdn = nuSpbBncoSlcePrpsCrdn;
	}


	/**
	 * @return the nuIdtfOrgmSlctAflc
	 */
	public String getNuIdtfOrgmSlctAflc() {
		return nuIdtfOrgmSlctAflc;
	}


	/**
	 * @param nuIdtfOrgmSlctAflc the nuIdtfOrgmSlctAflc to set
	 */
	public void setNuIdtfOrgmSlctAflc(String nuIdtfOrgmSlctAflc) {
		this.nuIdtfOrgmSlctAflc = nuIdtfOrgmSlctAflc;
	}


	/**
	 * @return the txPrimEpcoRsrdCilo
	 */
	public String getTxPrimEpcoRsrdCilo() {
		return txPrimEpcoRsrdCilo;
	}


	/**
	 * @param txPrimEpcoRsrdCilo the txPrimEpcoRsrdCilo to set
	 */
	public void setTxPrimEpcoRsrdCilo(String txPrimEpcoRsrdCilo) {
		this.txPrimEpcoRsrdCilo = txPrimEpcoRsrdCilo;
	}


	/**
	 * @return the cdErroVldcArqv
	 */
	public String getCdErroVldcArqv() {
		return cdErroVldcArqv;
	}


	/**
	 * @param cdErroVldcArqv the cdErroVldcArqv to set
	 */
	public void setCdErroVldcArqv(String cdErroVldcArqv) {
		this.cdErroVldcArqv = cdErroVldcArqv;
	}


	/**
	 * @return the cdErroCdgoBncoPrpsCrdn
	 */
	public String getCdErroCdgoBncoPrpsCrdn() {
		return cdErroCdgoBncoPrpsCrdn;
	}


	/**
	 * @param cdErroCdgoBncoPrpsCrdn the cdErroCdgoBncoPrpsCrdn to set
	 */
	public void setCdErroCdgoBncoPrpsCrdn(String cdErroCdgoBncoPrpsCrdn) {
		this.cdErroCdgoBncoPrpsCrdn = cdErroCdgoBncoPrpsCrdn;
	}


	/**
	 * @return the cdBncoPrpsCrdn
	 */
	public String getCdBncoPrpsCrdn() {
		return cdBncoPrpsCrdn;
	}


	/**
	 * @param cdBncoPrpsCrdn the cdBncoPrpsCrdn to set
	 */
	public void setCdBncoPrpsCrdn(String cdBncoPrpsCrdn) {
		this.cdBncoPrpsCrdn = cdBncoPrpsCrdn;
	}


	/**
	 * @return the nuEc
	 */
	public String getNuEc() {
		return nuEc;
	}


	/**
	 * @param nuEc the nuEc to set
	 */
	public void setNuEc(String nuEc) {
		this.nuEc = nuEc;
	}


	/**
	 * @return the cdErroNmRazoSocl
	 */
	public String getCdErroNmRazoSocl() {
		return cdErroNmRazoSocl;
	}


	/**
	 * @param cdErroNmRazoSocl the cdErroNmRazoSocl to set
	 */
	public void setCdErroNmRazoSocl(String cdErroNmRazoSocl) {
		this.cdErroNmRazoSocl = cdErroNmRazoSocl;
	}


	/**
	 * @return the nmRazoSocl
	 */
	public String getNmRazoSocl() {
		return nmRazoSocl;
	}


	/**
	 * @param nmRazoSocl the nmRazoSocl to set
	 */
	public void setNmRazoSocl(String nmRazoSocl) {
		this.nmRazoSocl = nmRazoSocl;
	}


	/**
	 * @return the cdErroNomeLgrdEndrCrsp
	 */
	public String getCdErroNomeLgrdEndrCrsp() {
		return cdErroNomeLgrdEndrCrsp;
	}


	/**
	 * @param cdErroNomeLgrdEndrCrsp the cdErroNomeLgrdEndrCrsp to set
	 */
	public void setCdErroNomeLgrdEndrCrsp(String cdErroNomeLgrdEndrCrsp) {
		this.cdErroNomeLgrdEndrCrsp = cdErroNomeLgrdEndrCrsp;
	}


	/**
	 * @return the nmLgrdEndrCrsp
	 */
	public String getNmLgrdEndrCrsp() {
		return nmLgrdEndrCrsp;
	}


	/**
	 * @param nmLgrdEndrCrsp the nmLgrdEndrCrsp to set
	 */
	public void setNmLgrdEndrCrsp(String nmLgrdEndrCrsp) {
		this.nmLgrdEndrCrsp = nmLgrdEndrCrsp;
	}


	/**
	 * @return the dcCmpmLgrdEndrCrsp
	 */
	public String getDcCmpmLgrdEndrCrsp() {
		return dcCmpmLgrdEndrCrsp;
	}


	/**
	 * @param dcCmpmLgrdEndrCrsp the dcCmpmLgrdEndrCrsp to set
	 */
	public void setDcCmpmLgrdEndrCrsp(String dcCmpmLgrdEndrCrsp) {
		this.dcCmpmLgrdEndrCrsp = dcCmpmLgrdEndrCrsp;
	}


	/**
	 * @return the cdErroNomeCideEndrCrsp
	 */
	public String getCdErroNomeCideEndrCrsp() {
		return cdErroNomeCideEndrCrsp;
	}


	/**
	 * @param cdErroNomeCideEndrCrsp the cdErroNomeCideEndrCrsp to set
	 */
	public void setCdErroNomeCideEndrCrsp(String cdErroNomeCideEndrCrsp) {
		this.cdErroNomeCideEndrCrsp = cdErroNomeCideEndrCrsp;
	}


	/**
	 * @return the nmCideEndrCrsp
	 */
	public String getNmCideEndrCrsp() {
		return nmCideEndrCrsp;
	}


	/**
	 * @param nmCideEndrCrsp the nmCideEndrCrsp to set
	 */
	public void setNmCideEndrCrsp(String nmCideEndrCrsp) {
		this.nmCideEndrCrsp = nmCideEndrCrsp;
	}


	/**
	 * @return the cdErroSglaEstdEndrCrsp
	 */
	public String getCdErroSglaEstdEndrCrsp() {
		return cdErroSglaEstdEndrCrsp;
	}


	/**
	 * @param cdErroSglaEstdEndrCrsp the cdErroSglaEstdEndrCrsp to set
	 */
	public void setCdErroSglaEstdEndrCrsp(String cdErroSglaEstdEndrCrsp) {
		this.cdErroSglaEstdEndrCrsp = cdErroSglaEstdEndrCrsp;
	}


	/**
	 * @return the sgEstdEndrCrsp
	 */
	public String getSgEstdEndrCrsp() {
		return sgEstdEndrCrsp;
	}


	/**
	 * @param sgEstdEndrCrsp the sgEstdEndrCrsp to set
	 */
	public void setSgEstdEndrCrsp(String sgEstdEndrCrsp) {
		this.sgEstdEndrCrsp = sgEstdEndrCrsp;
	}


	/**
	 * @return the cdErroNmroCepEndrCrsp
	 */
	public String getCdErroNmroCepEndrCrsp() {
		return cdErroNmroCepEndrCrsp;
	}


	/**
	 * @param cdErroNmroCepEndrCrsp the cdErroNmroCepEndrCrsp to set
	 */
	public void setCdErroNmroCepEndrCrsp(String cdErroNmroCepEndrCrsp) {
		this.cdErroNmroCepEndrCrsp = cdErroNmroCepEndrCrsp;
	}


	/**
	 * @return the nuCepEndrCrsp
	 */
	public String getNuCepEndrCrsp() {
		return nuCepEndrCrsp;
	}


	/**
	 * @param nuCepEndrCrsp the nuCepEndrCrsp to set
	 */
	public void setNuCepEndrCrsp(String nuCepEndrCrsp) {
		this.nuCepEndrCrsp = nuCepEndrCrsp;
	}


	/**
	 * @return the cdErroNmroCpfCnpj
	 */
	public String getCdErroNmroCpfCnpj() {
		return cdErroNmroCpfCnpj;
	}


	/**
	 * @param cdErroNmroCpfCnpj the cdErroNmroCpfCnpj to set
	 */
	public void setCdErroNmroCpfCnpj(String cdErroNmroCpfCnpj) {
		this.cdErroNmroCpfCnpj = cdErroNmroCpfCnpj;
	}


	/**
	 * @return the nuCpfCnpj
	 */
	public String getNuCpfCnpj() {
		return nuCpfCnpj;
	}


	/**
	 * @param nuCpfCnpj the nuCpfCnpj to set
	 */
	public void setNuCpfCnpj(String nuCpfCnpj) {
		this.nuCpfCnpj = nuCpfCnpj;
	}


	/**
	 * @return the cdErroNmroIe
	 */
	public String getCdErroNmroIe() {
		return cdErroNmroIe;
	}


	/**
	 * @param cdErroNmroIe the cdErroNmroIe to set
	 */
	public void setCdErroNmroIe(String cdErroNmroIe) {
		this.cdErroNmroIe = cdErroNmroIe;
	}


	/**
	 * @return the nuIe
	 */
	public String getNuIe() {
		return nuIe;
	}


	/**
	 * @param nuIe the nuIe to set
	 */
	public void setNuIe(String nuIe) {
		this.nuIe = nuIe;
	}


	/**
	 * @return the cdErroNomeFnts
	 */
	public String getCdErroNomeFnts() {
		return cdErroNomeFnts;
	}


	/**
	 * @param cdErroNomeFnts the cdErroNomeFnts to set
	 */
	public void setCdErroNomeFnts(String cdErroNomeFnts) {
		this.cdErroNomeFnts = cdErroNomeFnts;
	}


	/**
	 * @return the nmFnts
	 */
	public String getNmFnts() {
		return nmFnts;
	}


	/**
	 * @param nmFnts the nmFnts to set
	 */
	public void setNmFnts(String nmFnts) {
		this.nmFnts = nmFnts;
	}


	/**
	 * @return the cdErroNomeLgrdEndrCmrl
	 */
	public String getCdErroNomeLgrdEndrCmrl() {
		return cdErroNomeLgrdEndrCmrl;
	}


	/**
	 * @param cdErroNomeLgrdEndrCmrl the cdErroNomeLgrdEndrCmrl to set
	 */
	public void setCdErroNomeLgrdEndrCmrl(String cdErroNomeLgrdEndrCmrl) {
		this.cdErroNomeLgrdEndrCmrl = cdErroNomeLgrdEndrCmrl;
	}


	/**
	 * @return the dcCmpmLgrdEndrCmrl
	 */
	public String getDcCmpmLgrdEndrCmrl() {
		return dcCmpmLgrdEndrCmrl;
	}


	/**
	 * @param dcCmpmLgrdEndrCmrl the dcCmpmLgrdEndrCmrl to set
	 */
	public void setDcCmpmLgrdEndrCmrl(String dcCmpmLgrdEndrCmrl) {
		this.dcCmpmLgrdEndrCmrl = dcCmpmLgrdEndrCmrl;
	}


	/**
	 * @return the nmLgrdEndrCmrl
	 */
	public String getNmLgrdEndrCmrl() {
		return nmLgrdEndrCmrl;
	}


	/**
	 * @param nmLgrdEndrCmrl the nmLgrdEndrCmrl to set
	 */
	public void setNmLgrdEndrCmrl(String nmLgrdEndrCmrl) {
		this.nmLgrdEndrCmrl = nmLgrdEndrCmrl;
	}


	/**
	 * @return the cdErroNomeCideEndrCmrl
	 */
	public String getCdErroNomeCideEndrCmrl() {
		return cdErroNomeCideEndrCmrl;
	}


	/**
	 * @param cdErroNomeCideEndrCmrl the cdErroNomeCideEndrCmrl to set
	 */
	public void setCdErroNomeCideEndrCmrl(String cdErroNomeCideEndrCmrl) {
		this.cdErroNomeCideEndrCmrl = cdErroNomeCideEndrCmrl;
	}


	/**
	 * @return the nmCideEndrCmrl
	 */
	public String getNmCideEndrCmrl() {
		return nmCideEndrCmrl;
	}


	/**
	 * @param nmCideEndrCmrl the nmCideEndrCmrl to set
	 */
	public void setNmCideEndrCmrl(String nmCideEndrCmrl) {
		this.nmCideEndrCmrl = nmCideEndrCmrl;
	}


	/**
	 * @return the cdErroSglaEstdEndrCmrl
	 */
	public String getCdErroSglaEstdEndrCmrl() {
		return cdErroSglaEstdEndrCmrl;
	}


	/**
	 * @param cdErroSglaEstdEndrCmrl the cdErroSglaEstdEndrCmrl to set
	 */
	public void setCdErroSglaEstdEndrCmrl(String cdErroSglaEstdEndrCmrl) {
		this.cdErroSglaEstdEndrCmrl = cdErroSglaEstdEndrCmrl;
	}


	/**
	 * @return the sgEstdEndrCmrl
	 */
	public String getSgEstdEndrCmrl() {
		return sgEstdEndrCmrl;
	}


	/**
	 * @param sgEstdEndrCmrl the sgEstdEndrCmrl to set
	 */
	public void setSgEstdEndrCmrl(String sgEstdEndrCmrl) {
		this.sgEstdEndrCmrl = sgEstdEndrCmrl;
	}


	/**
	 * @return the cdErroNmroCepEndrCmrl
	 */
	public String getCdErroNmroCepEndrCmrl() {
		return cdErroNmroCepEndrCmrl;
	}


	/**
	 * @param cdErroNmroCepEndrCmrl the cdErroNmroCepEndrCmrl to set
	 */
	public void setCdErroNmroCepEndrCmrl(String cdErroNmroCepEndrCmrl) {
		this.cdErroNmroCepEndrCmrl = cdErroNmroCepEndrCmrl;
	}


	/**
	 * @return the nuCepEndrCmrl
	 */
	public String getNuCepEndrCmrl() {
		return nuCepEndrCmrl;
	}


	/**
	 * @param nuCepEndrCmrl the nuCepEndrCmrl to set
	 */
	public void setNuCepEndrCmrl(String nuCepEndrCmrl) {
		this.nuCepEndrCmrl = nuCepEndrCmrl;
	}


	/**
	 * @return the cdErroNomePlqtEc
	 */
	public String getCdErroNomePlqtEc() {
		return cdErroNomePlqtEc;
	}


	/**
	 * @param cdErroNomePlqtEc the cdErroNomePlqtEc to set
	 */
	public void setCdErroNomePlqtEc(String cdErroNomePlqtEc) {
		this.cdErroNomePlqtEc = cdErroNomePlqtEc;
	}


	/**
	 * @return the nmPlqtEc
	 */
	public String getNmPlqtEc() {
		return nmPlqtEc;
	}


	/**
	 * @param nmPlqtEc the nmPlqtEc to set
	 */
	public void setNmPlqtEc(String nmPlqtEc) {
		this.nmPlqtEc = nmPlqtEc;
	}


	/**
	 * @return the cdErroNomePesaCnto
	 */
	public String getCdErroNomePesaCnto() {
		return cdErroNomePesaCnto;
	}


	/**
	 * @param cdErroNomePesaCnto the cdErroNomePesaCnto to set
	 */
	public void setCdErroNomePesaCnto(String cdErroNomePesaCnto) {
		this.cdErroNomePesaCnto = cdErroNomePesaCnto;
	}


	/**
	 * @return the nmPesaCnto
	 */
	public String getNmPesaCnto() {
		return nmPesaCnto;
	}


	/**
	 * @param nmPesaCnto the nmPesaCnto to set
	 */
	public void setNmPesaCnto(String nmPesaCnto) {
		this.nmPesaCnto = nmPesaCnto;
	}


	/**
	 * @return the txEpcoRsrdArqv
	 */
	public String getTxEpcoRsrdArqv() {
		return txEpcoRsrdArqv;
	}


	/**
	 * @param txEpcoRsrdArqv the txEpcoRsrdArqv to set
	 */
	public void setTxEpcoRsrdArqv(String txEpcoRsrdArqv) {
		this.txEpcoRsrdArqv = txEpcoRsrdArqv;
	}


	/**
	 * @return the cdErroCdgoMcc
	 */
	public String getCdErroCdgoMcc() {
		return cdErroCdgoMcc;
	}


	/**
	 * @param cdErroCdgoMcc the cdErroCdgoMcc to set
	 */
	public void setCdErroCdgoMcc(String cdErroCdgoMcc) {
		this.cdErroCdgoMcc = cdErroCdgoMcc;
	}


	/**
	 * @return the cdMcc
	 */
	public String getCdMcc() {
		return cdMcc;
	}


	/**
	 * @param cdMcc the cdMcc to set
	 */
	public void setCdMcc(String cdMcc) {
		this.cdMcc = cdMcc;
	}


	/**
	 * @return the cdErroCdgoAgnc
	 */
	public String getCdErroCdgoAgnc() {
		return cdErroCdgoAgnc;
	}


	/**
	 * @param cdErroCdgoAgnc the cdErroCdgoAgnc to set
	 */
	public void setCdErroCdgoAgnc(String cdErroCdgoAgnc) {
		this.cdErroCdgoAgnc = cdErroCdgoAgnc;
	}


	/**
	 * @return the cdAgnc
	 */
	public String getCdAgnc() {
		return cdAgnc;
	}


	/**
	 * @param cdAgnc the cdAgnc to set
	 */
	public void setCdAgnc(String cdAgnc) {
		this.cdAgnc = cdAgnc;
	}


	/**
	 * @return the cdErroNmroCncr
	 */
	public String getCdErroNmroCncr() {
		return cdErroNmroCncr;
	}


	/**
	 * @param cdErroNmroCncr the cdErroNmroCncr to set
	 */
	public void setCdErroNmroCncr(String cdErroNmroCncr) {
		this.cdErroNmroCncr = cdErroNmroCncr;
	}


	/**
	 * @return the nuCncr
	 */
	public String getNuCncr() {
		return nuCncr;
	}


	/**
	 * @param nuCncr the nuCncr to set
	 */
	public void setNuCncr(String nuCncr) {
		this.nuCncr = nuCncr;
	}


	/**
	 * @return the cdErroNomeCmplPrimPrpt
	 */
	public String getCdErroNomeCmplPrimPrpt() {
		return cdErroNomeCmplPrimPrpt;
	}


	/**
	 * @param cdErroNomeCmplPrimPrpt the cdErroNomeCmplPrimPrpt to set
	 */
	public void setCdErroNomeCmplPrimPrpt(String cdErroNomeCmplPrimPrpt) {
		this.cdErroNomeCmplPrimPrpt = cdErroNomeCmplPrimPrpt;
	}


	/**
	 * @return the nmCmplPrimPrpt
	 */
	public String getNmCmplPrimPrpt() {
		return nmCmplPrimPrpt;
	}


	/**
	 * @param nmCmplPrimPrpt the nmCmplPrimPrpt to set
	 */
	public void setNmCmplPrimPrpt(String nmCmplPrimPrpt) {
		this.nmCmplPrimPrpt = nmCmplPrimPrpt;
	}


	/**
	 * @return the cdErroNmroCpfPrimPrpt
	 */
	public String getCdErroNmroCpfPrimPrpt() {
		return cdErroNmroCpfPrimPrpt;
	}


	/**
	 * @param cdErroNmroCpfPrimPrpt the cdErroNmroCpfPrimPrpt to set
	 */
	public void setCdErroNmroCpfPrimPrpt(String cdErroNmroCpfPrimPrpt) {
		this.cdErroNmroCpfPrimPrpt = cdErroNmroCpfPrimPrpt;
	}


	/**
	 * @return the nuCpfPrimPrpt
	 */
	public String getNuCpfPrimPrpt() {
		return nuCpfPrimPrpt;
	}


	/**
	 * @param nuCpfPrimPrpt the nuCpfPrimPrpt to set
	 */
	public void setNuCpfPrimPrpt(String nuCpfPrimPrpt) {
		this.nuCpfPrimPrpt = nuCpfPrimPrpt;
	}


	/**
	 * @return the cdErroDataNscmPrimPrpt
	 */
	public String getCdErroDataNscmPrimPrpt() {
		return cdErroDataNscmPrimPrpt;
	}


	/**
	 * @param cdErroDataNscmPrimPrpt the cdErroDataNscmPrimPrpt to set
	 */
	public void setCdErroDataNscmPrimPrpt(String cdErroDataNscmPrimPrpt) {
		this.cdErroDataNscmPrimPrpt = cdErroDataNscmPrimPrpt;
	}


	/**
	 * @return the dtNscmPrimPrpt
	 */
	public String getDtNscmPrimPrpt() {
		return dtNscmPrimPrpt;
	}


	/**
	 * @param dtNscmPrimPrpt the dtNscmPrimPrpt to set
	 */
	public void setDtNscmPrimPrpt(String dtNscmPrimPrpt) {
		this.dtNscmPrimPrpt = dtNscmPrimPrpt;
	}


	/**
	 * @return the cdErroNomeCmplSgndPrpt
	 */
	public String getCdErroNomeCmplSgndPrpt() {
		return cdErroNomeCmplSgndPrpt;
	}


	/**
	 * @param cdErroNomeCmplSgndPrpt the cdErroNomeCmplSgndPrpt to set
	 */
	public void setCdErroNomeCmplSgndPrpt(String cdErroNomeCmplSgndPrpt) {
		this.cdErroNomeCmplSgndPrpt = cdErroNomeCmplSgndPrpt;
	}


	/**
	 * @return the nmCmplSgndPrpt
	 */
	public String getNmCmplSgndPrpt() {
		return nmCmplSgndPrpt;
	}


	/**
	 * @param nmCmplSgndPrpt the nmCmplSgndPrpt to set
	 */
	public void setNmCmplSgndPrpt(String nmCmplSgndPrpt) {
		this.nmCmplSgndPrpt = nmCmplSgndPrpt;
	}


	/**
	 * @return the cdErroNmroCpfSgndPrpt
	 */
	public String getCdErroNmroCpfSgndPrpt() {
		return cdErroNmroCpfSgndPrpt;
	}


	/**
	 * @param cdErroNmroCpfSgndPrpt the cdErroNmroCpfSgndPrpt to set
	 */
	public void setCdErroNmroCpfSgndPrpt(String cdErroNmroCpfSgndPrpt) {
		this.cdErroNmroCpfSgndPrpt = cdErroNmroCpfSgndPrpt;
	}


	/**
	 * @return the nuCpfSgndPrpt
	 */
	public String getNuCpfSgndPrpt() {
		return nuCpfSgndPrpt;
	}


	/**
	 * @param nuCpfSgndPrpt the nuCpfSgndPrpt to set
	 */
	public void setNuCpfSgndPrpt(String nuCpfSgndPrpt) {
		this.nuCpfSgndPrpt = nuCpfSgndPrpt;
	}


	/**
	 * @return the cdErroDataNscmSgndPrpt
	 */
	public String getCdErroDataNscmSgndPrpt() {
		return cdErroDataNscmSgndPrpt;
	}


	/**
	 * @param cdErroDataNscmSgndPrpt the cdErroDataNscmSgndPrpt to set
	 */
	public void setCdErroDataNscmSgndPrpt(String cdErroDataNscmSgndPrpt) {
		this.cdErroDataNscmSgndPrpt = cdErroDataNscmSgndPrpt;
	}


	/**
	 * @return the dtNscmSgndPrpt
	 */
	public String getDtNscmSgndPrpt() {
		return dtNscmSgndPrpt;
	}


	/**
	 * @param dtNscmSgndPrpt the dtNscmSgndPrpt to set
	 */
	public void setDtNscmSgndPrpt(String dtNscmSgndPrpt) {
		this.dtNscmSgndPrpt = dtNscmSgndPrpt;
	}


	/**
	 * @return the cdErroNomeCmplTerePrpt
	 */
	public String getCdErroNomeCmplTerePrpt() {
		return cdErroNomeCmplTerePrpt;
	}


	/**
	 * @param cdErroNomeCmplTerePrpt the cdErroNomeCmplTerePrpt to set
	 */
	public void setCdErroNomeCmplTerePrpt(String cdErroNomeCmplTerePrpt) {
		this.cdErroNomeCmplTerePrpt = cdErroNomeCmplTerePrpt;
	}


	/**
	 * @return the nmCmplTerePrpt
	 */
	public String getNmCmplTerePrpt() {
		return nmCmplTerePrpt;
	}


	/**
	 * @param nmCmplTerePrpt the nmCmplTerePrpt to set
	 */
	public void setNmCmplTerePrpt(String nmCmplTerePrpt) {
		this.nmCmplTerePrpt = nmCmplTerePrpt;
	}


	/**
	 * @return the cdErroNmroCpfTerePrpt
	 */
	public String getCdErroNmroCpfTerePrpt() {
		return cdErroNmroCpfTerePrpt;
	}


	/**
	 * @param cdErroNmroCpfTerePrpt the cdErroNmroCpfTerePrpt to set
	 */
	public void setCdErroNmroCpfTerePrpt(String cdErroNmroCpfTerePrpt) {
		this.cdErroNmroCpfTerePrpt = cdErroNmroCpfTerePrpt;
	}


	/**
	 * @return the nuCpfTerePrpt
	 */
	public String getNuCpfTerePrpt() {
		return nuCpfTerePrpt;
	}


	/**
	 * @param nuCpfTerePrpt the nuCpfTerePrpt to set
	 */
	public void setNuCpfTerePrpt(String nuCpfTerePrpt) {
		this.nuCpfTerePrpt = nuCpfTerePrpt;
	}


	/**
	 * @return the cdErroDataNscmTerePrpt
	 */
	public String getCdErroDataNscmTerePrpt() {
		return cdErroDataNscmTerePrpt;
	}


	/**
	 * @param cdErroDataNscmTerePrpt the cdErroDataNscmTerePrpt to set
	 */
	public void setCdErroDataNscmTerePrpt(String cdErroDataNscmTerePrpt) {
		this.cdErroDataNscmTerePrpt = cdErroDataNscmTerePrpt;
	}


	/**
	 * @return the dtNscmTerePrpt
	 */
	public String getDtNscmTerePrpt() {
		return dtNscmTerePrpt;
	}


	/**
	 * @param dtNscmTerePrpt the dtNscmTerePrpt to set
	 */
	public void setDtNscmTerePrpt(String dtNscmTerePrpt) {
		this.dtNscmTerePrpt = dtNscmTerePrpt;
	}


	/**
	 * @return the cdErroSgTipoPesa
	 */
	public String getCdErroSgTipoPesa() {
		return cdErroSgTipoPesa;
	}


	/**
	 * @param cdErroSgTipoPesa the cdErroSgTipoPesa to set
	 */
	public void setCdErroSgTipoPesa(String cdErroSgTipoPesa) {
		this.cdErroSgTipoPesa = cdErroSgTipoPesa;
	}


	/**
	 * @return the sgTipoPesa
	 */
	public String getSgTipoPesa() {
		return sgTipoPesa;
	}


	/**
	 * @param sgTipoPesa the sgTipoPesa to set
	 */
	public void setSgTipoPesa(String sgTipoPesa) {
		this.sgTipoPesa = sgTipoPesa;
	}


	/**
	 * @return the txNonoEpcoRsrdCilo
	 */
	public String getTxNonoEpcoRsrdCilo() {
		return txNonoEpcoRsrdCilo;
	}


	/**
	 * @param txNonoEpcoRsrdCilo the txNonoEpcoRsrdCilo to set
	 */
	public void setTxNonoEpcoRsrdCilo(String txNonoEpcoRsrdCilo) {
		this.txNonoEpcoRsrdCilo = txNonoEpcoRsrdCilo;
	}


	/**
	 * @return the cdErroNmroDddSlcoMvel
	 */
	public String getCdErroNmroDddSlcoMvel() {
		return cdErroNmroDddSlcoMvel;
	}


	/**
	 * @param cdErroNmroDddSlcoMvel the cdErroNmroDddSlcoMvel to set
	 */
	public void setCdErroNmroDddSlcoMvel(String cdErroNmroDddSlcoMvel) {
		this.cdErroNmroDddSlcoMvel = cdErroNmroDddSlcoMvel;
	}


	/**
	 * @return the nuDddTlfnSlcoMvel
	 */
	public String getNuDddTlfnSlcoMvel() {
		return nuDddTlfnSlcoMvel;
	}


	/**
	 * @param nuDddTlfnSlcoMvel the nuDddTlfnSlcoMvel to set
	 */
	public void setNuDddTlfnSlcoMvel(String nuDddTlfnSlcoMvel) {
		this.nuDddTlfnSlcoMvel = nuDddTlfnSlcoMvel;
	}


	/**
	 * @return the cdErroNmroTlfnSlcoMvel
	 */
	public String getCdErroNmroTlfnSlcoMvel() {
		return cdErroNmroTlfnSlcoMvel;
	}


	/**
	 * @param cdErroNmroTlfnSlcoMvel the cdErroNmroTlfnSlcoMvel to set
	 */
	public void setCdErroNmroTlfnSlcoMvel(String cdErroNmroTlfnSlcoMvel) {
		this.cdErroNmroTlfnSlcoMvel = cdErroNmroTlfnSlcoMvel;
	}


	/**
	 * @return the nuTlfnSlcoMvel
	 */
	public String getNuTlfnSlcoMvel() {
		return nuTlfnSlcoMvel;
	}


	/**
	 * @param nuTlfnSlcoMvel the nuTlfnSlcoMvel to set
	 */
	public void setNuTlfnSlcoMvel(String nuTlfnSlcoMvel) {
		this.nuTlfnSlcoMvel = nuTlfnSlcoMvel;
	}


	/**
	 * @return the cdErroNmroDddTlfnFax
	 */
	public String getCdErroNmroDddTlfnFax() {
		return cdErroNmroDddTlfnFax;
	}


	/**
	 * @param cdErroNmroDddTlfnFax the cdErroNmroDddTlfnFax to set
	 */
	public void setCdErroNmroDddTlfnFax(String cdErroNmroDddTlfnFax) {
		this.cdErroNmroDddTlfnFax = cdErroNmroDddTlfnFax;
	}


	/**
	 * @return the nuDddTlfnFax
	 */
	public String getNuDddTlfnFax() {
		return nuDddTlfnFax;
	}


	/**
	 * @param nuDddTlfnFax the nuDddTlfnFax to set
	 */
	public void setNuDddTlfnFax(String nuDddTlfnFax) {
		this.nuDddTlfnFax = nuDddTlfnFax;
	}


	/**
	 * @return the cdErroNmroTlfnFax
	 */
	public String getCdErroNmroTlfnFax() {
		return cdErroNmroTlfnFax;
	}


	/**
	 * @param cdErroNmroTlfnFax the cdErroNmroTlfnFax to set
	 */
	public void setCdErroNmroTlfnFax(String cdErroNmroTlfnFax) {
		this.cdErroNmroTlfnFax = cdErroNmroTlfnFax;
	}


	/**
	 * @return the nuTlfnFax
	 */
	public String getNuTlfnFax() {
		return nuTlfnFax;
	}


	/**
	 * @param nuTlfnFax the nuTlfnFax to set
	 */
	public void setNuTlfnFax(String nuTlfnFax) {
		this.nuTlfnFax = nuTlfnFax;
	}


	/**
	 * @return the cdErroIdcrMei
	 */
	public String getCdErroIdcrMei() {
		return cdErroIdcrMei;
	}


	/**
	 * @param cdErroIdcrMei the cdErroIdcrMei to set
	 */
	public void setCdErroIdcrMei(String cdErroIdcrMei) {
		this.cdErroIdcrMei = cdErroIdcrMei;
	}


	/**
	 * @return the inMei
	 */
	public String getInMei() {
		return inMei;
	}


	/**
	 * @param inMei the inMei to set
	 */
	public void setInMei(String inMei) {
		this.inMei = inMei;
	}


	/**
	 * @return the txQrtoEpcoRsrdCilo
	 */
	public String getTxQrtoEpcoRsrdCilo() {
		return txQrtoEpcoRsrdCilo;
	}


	/**
	 * @param txQrtoEpcoRsrdCilo the txQrtoEpcoRsrdCilo to set
	 */
	public void setTxQrtoEpcoRsrdCilo(String txQrtoEpcoRsrdCilo) {
		this.txQrtoEpcoRsrdCilo = txQrtoEpcoRsrdCilo;
	}


	/**
	 * @return the cdErroPcteCmel
	 */
	public String getCdErroPcteCmel() {
		return cdErroPcteCmel;
	}


	/**
	 * @param cdErroPcteCmel the cdErroPcteCmel to set
	 */
	public void setCdErroPcteCmel(String cdErroPcteCmel) {
		this.cdErroPcteCmel = cdErroPcteCmel;
	}


	/**
	 * @return the cdPcteCmel
	 */
	public String getCdPcteCmel() {
		return cdPcteCmel;
	}


	/**
	 * @param cdPcteCmel the cdPcteCmel to set
	 */
	public void setCdPcteCmel(String cdPcteCmel) {
		this.cdPcteCmel = cdPcteCmel;
	}


	/**
	 * @return the txQuntEpcoRsrdCilo
	 */
	public String getTxQuntEpcoRsrdCilo() {
		return txQuntEpcoRsrdCilo;
	}


	/**
	 * @param txQuntEpcoRsrdCilo the txQuntEpcoRsrdCilo to set
	 */
	public void setTxQuntEpcoRsrdCilo(String txQuntEpcoRsrdCilo) {
		this.txQuntEpcoRsrdCilo = txQuntEpcoRsrdCilo;
	}


	/**
	 * @return the cdErroTipoConta
	 */
	public String getCdErroTipoConta() {
		return cdErroTipoConta;
	}


	/**
	 * @param cdErroTipoConta the cdErroTipoConta to set
	 */
	public void setCdErroTipoConta(String cdErroTipoConta) {
		this.cdErroTipoConta = cdErroTipoConta;
	}


	/**
	 * @return the cdTipoConta
	 */
	public String getCdTipoConta() {
		return cdTipoConta;
	}


	/**
	 * @param cdTipoConta the cdTipoConta to set
	 */
	public void setCdTipoConta(String cdTipoConta) {
		this.cdTipoConta = cdTipoConta;
	}


	/**
	 * @return the txDcmoEpcoRsrdCilo
	 */
	public String getTxDcmoEpcoRsrdCilo() {
		return txDcmoEpcoRsrdCilo;
	}


	/**
	 * @param txDcmoEpcoRsrdCilo the txDcmoEpcoRsrdCilo to set
	 */
	public void setTxDcmoEpcoRsrdCilo(String txDcmoEpcoRsrdCilo) {
		this.txDcmoEpcoRsrdCilo = txDcmoEpcoRsrdCilo;
	}


	/**
	 * @return the cdErroPlnoCilo
	 */
	public String getCdErroPlnoCilo() {
		return cdErroPlnoCilo;
	}


	/**
	 * @param cdErroPlnoCilo the cdErroPlnoCilo to set
	 */
	public void setCdErroPlnoCilo(String cdErroPlnoCilo) {
		this.cdErroPlnoCilo = cdErroPlnoCilo;
	}


	/**
	 * @return the cdPlnoCilo
	 */
	public String getCdPlnoCilo() {
		return cdPlnoCilo;
	}


	/**
	 * @param cdPlnoCilo the cdPlnoCilo to set
	 */
	public void setCdPlnoCilo(String cdPlnoCilo) {
		this.cdPlnoCilo = cdPlnoCilo;
	}


	/**
	 * @return the cdErroValrFtrm
	 */
	public String getCdErroValrFtrm() {
		return cdErroValrFtrm;
	}


	/**
	 * @param cdErroValrFtrm the cdErroValrFtrm to set
	 */
	public void setCdErroValrFtrm(String cdErroValrFtrm) {
		this.cdErroValrFtrm = cdErroValrFtrm;
	}


	/**
	 * @return the valrFtrm
	 */
	public String getValrFtrm() {
		return ValrFtrm;
	}


	/**
	 * @param valrFtrm the valrFtrm to set
	 */
	public void setValrFtrm(String valrFtrm) {
		ValrFtrm = valrFtrm;
	}


	/**
	 * @return the cdErroQntdDiaLqdc
	 */
	public String getCdErroQntdDiaLqdc() {
		return cdErroQntdDiaLqdc;
	}


	/**
	 * @param cdErroQntdDiaLqdc the cdErroQntdDiaLqdc to set
	 */
	public void setCdErroQntdDiaLqdc(String cdErroQntdDiaLqdc) {
		this.cdErroQntdDiaLqdc = cdErroQntdDiaLqdc;
	}


	/**
	 * @return the qntdDiaLqdc
	 */
	public String getQntdDiaLqdc() {
		return QntdDiaLqdc;
	}


	/**
	 * @param qntdDiaLqdc the qntdDiaLqdc to set
	 */
	public void setQntdDiaLqdc(String qntdDiaLqdc) {
		QntdDiaLqdc = qntdDiaLqdc;
	}


	/**
	 * @return the cdErroSlcp
	 */
	public String getCdErroSlcp() {
		return cdErroSlcp;
	}


	/**
	 * @param cdErroSlcp the cdErroSlcp to set
	 */
	public void setCdErroSlcp(String cdErroSlcp) {
		this.cdErroSlcp = cdErroSlcp;
	}


	/**
	 * @return the cdSlcp
	 */
	public String getCdSlcp() {
		return cdSlcp;
	}


	/**
	 * @param cdSlcp the cdSlcp to set
	 */
	public void setCdSlcp(String cdSlcp) {
		this.cdSlcp = cdSlcp;
	}


	/**
	 * @return the cdErroIdcrAgro
	 */
	public String getCdErroIdcrAgro() {
		return cdErroIdcrAgro;
	}


	/**
	 * @param cdErroIdcrAgro the cdErroIdcrAgro to set
	 */
	public void setCdErroIdcrAgro(String cdErroIdcrAgro) {
		this.cdErroIdcrAgro = cdErroIdcrAgro;
	}


	/**
	 * @return the cdIdcrAgro
	 */
	public String getCdIdcrAgro() {
		return cdIdcrAgro;
	}


	/**
	 * @param cdIdcrAgro the cdIdcrAgro to set
	 */
	public void setCdIdcrAgro(String cdIdcrAgro) {
		this.cdIdcrAgro = cdIdcrAgro;
	}


	/**
	 * @return the cdErroNmroEndrCmrl
	 */
	public String getCdErroNmroEndrCmrl() {
		return cdErroNmroEndrCmrl;
	}


	/**
	 * @param cdErroNmroEndrCmrl the cdErroNmroEndrCmrl to set
	 */
	public void setCdErroNmroEndrCmrl(String cdErroNmroEndrCmrl) {
		this.cdErroNmroEndrCmrl = cdErroNmroEndrCmrl;
	}


	/**
	 * @return the nmroEndrCmrl
	 */
	public String getNmroEndrCmrl() {
		return nmroEndrCmrl;
	}


	/**
	 * @param nmroEndrCmrl the nmroEndrCmrl to set
	 */
	public void setNmroEndrCmrl(String nmroEndrCmrl) {
		this.nmroEndrCmrl = nmroEndrCmrl;
	}


	/**
	 * @return the cdErroNmroEndrCrsa
	 */
	public String getCdErroNmroEndrCrsa() {
		return cdErroNmroEndrCrsa;
	}


	/**
	 * @param cdErroNmroEndrCrsa the cdErroNmroEndrCrsa to set
	 */
	public void setCdErroNmroEndrCrsa(String cdErroNmroEndrCrsa) {
		this.cdErroNmroEndrCrsa = cdErroNmroEndrCrsa;
	}


	/**
	 * @return the nmroEndrCrsa
	 */
	public String getNmroEndrCrsa() {
		return nmroEndrCrsa;
	}


	/**
	 * @param nmroEndrCrsa the nmroEndrCrsa to set
	 */
	public void setNmroEndrCrsa(String nmroEndrCrsa) {
		this.nmroEndrCrsa = nmroEndrCrsa;
	}


	/**
	 * @return the cdErroDercEmal
	 */
	public String getCdErroDercEmal() {
		return cdErroDercEmal;
	}


	/**
	 * @param cdErroDercEmal the cdErroDercEmal to set
	 */
	public void setCdErroDercEmal(String cdErroDercEmal) {
		this.cdErroDercEmal = cdErroDercEmal;
	}


	/**
	 * @return the txSxtoEpcoRsrdCilo
	 */
	public String getTxSxtoEpcoRsrdCilo() {
		return txSxtoEpcoRsrdCilo;
	}


	/**
	 * @param txSxtoEpcoRsrdCilo the txSxtoEpcoRsrdCilo to set
	 */
	public void setTxSxtoEpcoRsrdCilo(String txSxtoEpcoRsrdCilo) {
		this.txSxtoEpcoRsrdCilo = txSxtoEpcoRsrdCilo;
	}


	/**
	 * @return the descEmail
	 */
	public String getDescEmail() {
		return descEmail;
	}


	/**
	 * @param descEmail the descEmail to set
	 */
	public void setDescEmail(String descEmail) {
		this.descEmail = descEmail;
	}


	/**
	 * @return the txStmoEpcoRsrdCilo
	 */
	public String getTxStmoEpcoRsrdCilo() {
		return txStmoEpcoRsrdCilo;
	}


	/**
	 * @param txStmoEpcoRsrdCilo the txStmoEpcoRsrdCilo to set
	 */
	public void setTxStmoEpcoRsrdCilo(String txStmoEpcoRsrdCilo) {
		this.txStmoEpcoRsrdCilo = txStmoEpcoRsrdCilo;
	}


	/**
	 * @return the controleCargaBanco
	 */
	public LogControleCargaBanco getControleCargaBanco() {
		return controleCargaBanco;
	}


	/**
	 * @param controleCargaBanco the controleCargaBanco to set
	 */
	public void setControleCargaBanco(LogControleCargaBanco controleCargaBanco) {
		this.controleCargaBanco = controleCargaBanco;
	}
	
	
}
