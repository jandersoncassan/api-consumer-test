package br.com.cielo.credenciamento.crd.enun;

public enum StatusCredenciamento {

	SUCESSO("1"), REJEITADA("2"), REJEITADA_FALHA_SISTEMICA("99");
	
	private String codigoStatus;
	
	private StatusCredenciamento(String codigoStatus){
		this.codigoStatus = codigoStatus;
	}
	
	public String getCodigo(){
		return codigoStatus;
	}
	
}
