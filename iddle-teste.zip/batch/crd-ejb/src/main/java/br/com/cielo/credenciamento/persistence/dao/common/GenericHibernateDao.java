package br.com.cielo.credenciamento.persistence.dao.common;

import java.io.Serializable;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

/**
 * Classe JPA abstract Generics DAO
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Repository
@Scope(BeanDefinition.SCOPE_PROTOTYPE)
public class GenericHibernateDao<T extends Serializable> extends AbstractJpaDAO<T> implements
                IGenericDao<T> {

    /**
     * GenericHibernateDao
     * 
     * @param t - Class<T>
     */
    public GenericHibernateDao(final Class<T> t) {
        super(t);
    }
}
