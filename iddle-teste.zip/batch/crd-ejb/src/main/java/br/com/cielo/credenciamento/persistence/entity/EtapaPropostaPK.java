package br.com.cielo.credenciamento.persistence.entity;


import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * PK responsavel pela chave da tabela de etapas
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Embeddable
public class EtapaPropostaPK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Column(name = "NU_PRPS_CRDN", insertable = false, updatable = false, nullable = false)
    private Long nuPrpsCrdn;

    @Column(name = "CD_ETPA_CRDN", insertable = false, updatable = false, nullable = false, precision = 3)
    private Integer cdEtpaCrdn;

	/**
	 * @return the nuPrpsCrdn
	 */
	public Long getNuPrpsCrdn() {
		return nuPrpsCrdn;
	}

	/**
	 * @param nuPrpsCrdn the nuPrpsCrdn to set
	 */
	public void setNuPrpsCrdn(Long nuPrpsCrdn) {
		this.nuPrpsCrdn = nuPrpsCrdn;
	}

	/**
	 * @return the cdEtpaCrdn
	 */
	public Integer getCdEtpaCrdn() {
		return cdEtpaCrdn;
	}

	/**
	 * @param cdEtpaCrdn the cdEtpaCrdn to set
	 */
	public void setCdEtpaCrdn(Integer cdEtpaCrdn) {
		this.cdEtpaCrdn = cdEtpaCrdn;
	}

	
 
}
