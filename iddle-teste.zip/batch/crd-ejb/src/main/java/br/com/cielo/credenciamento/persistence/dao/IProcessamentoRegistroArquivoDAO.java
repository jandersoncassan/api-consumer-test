package br.com.cielo.credenciamento.persistence.dao;

import java.util.Date;
import java.util.List;

import javax.ejb.Local;

import br.com.cielo.credenciamento.persistence.dao.common.IOperations;
import br.com.cielo.credenciamento.persistence.entity.LogControleCargaBanco;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivo;
import br.com.cielo.credenciamento.persistence.entity.ProcessamentoRegistroArquivoPK;

/**
 * Interface responsavel pelas consistências envolvendo o arquivo de remessa de bancos
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IProcessamentoRegistroArquivoDAO extends IOperations<ProcessamentoRegistroArquivo> {

    /**
     * Método responsavel por atualizar os contadores de Acatados e Rejeitados tabela de controle de carga 
     * 
     * @param codigoBanco
     */
    void atualizarContadoresRemessa(String codigoBanco);


    /**
     * Método responsavel por obter a lista de arquivos concluidos
	 *
     * @param codigoBanco
     * @return
     */
    List<ProcessamentoRegistroArquivo> obterListaRegistrosConcluidos(String codigoBanco);

    /**
     * Método responsavel por obter a próxima linha do arquivo | remessa   
     * @param codigoBanco
     * @param dataMovimento
     * @param numeroRemessa
     * @return
     */
    Integer getNextLinha(Integer codigoBanco, Date dataMovimento, Integer numeroRemessa);
    
    /**
     * Método responsavel por obter o prospect na tabela WRK
     * @param atulPK
     * @return
     */
    ProcessamentoRegistroArquivo findById(ProcessamentoRegistroArquivoPK atulPK);
    
    /**
     * Método responsavel por executar o processo de expurgo da tabela work
     * A regra de expurgo, exclui fisicamente os registros com mais de 90 dias
     */
    void expurgoRegistrosProcessados();


    /**
     * Método responsavel por obter a lista de Remessas concluidas
     * @param codigoBanco
     * @return
     */
	List<LogControleCargaBanco> obterListaRemessasArquivos(String codigoBanco);

}
