package br.com.cielo.credenciamento.persistence.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Entidade representando a tabela de estabelecimento comercial EC
 * @author @Cielo SA
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Entity
@Table(name = "TBCRDR_EC_PRPS")
public class EstabelecimentoComercial implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "NU_PRPS_CRDN", unique = true, nullable = false)
    private Long nuPrpsCrdn;

    @Column(name = "CD_MCC", precision = 5)
    private BigDecimal cdMcc;

    @Column(name = "CD_USRO_ALTR_RGST", length = 20)
    private String cdUsroAltrRgst;

    @Column(name = "CD_USRO_INCL_RGST", nullable = false, length = 20)
    private String cdUsroInclRgst;

    @Column(name = "DC_EMAIL_CNTO_EC", length = 70)
    private String dcEmailCntoEc;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DH_ALTR_RGST")
    private Date dhAltrRgst;

    @Temporal(TemporalType.DATE)
    @Column(name = "DH_INCL_RGST", nullable = false)
    private Date dhInclRgst;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "DT_ATVC_EC")
    private Date dtAtvcEc;

    @Column(name = "IN_MEI", nullable = false, columnDefinition="char(1)")
    private String inMei;

    @Column(name = "NM_FNTS", length = 70)
    private String nmFnts;

    @Column(name = "NM_PESA_CNTO", length = 40)
    private String nmPesaCnto;

    @Column(name = "NM_PLQT_EC", length = 22)
    private String nmPlqtEc;

    @Column(name = "NM_RAZO_SOCL", length = 70)
    private String nmRazoSocl;

    @Column(name = "NU_EC", precision = 10)
    private Long nuEc;

    @Column(name = "NU_IE", precision = 15)
    private BigDecimal nuIe;
    
    @Column(name = "CD_TIPO_PLNO_CILO", length=2)
    private Integer codTipoPlanoCielo;

 	/**
	 * @return the nuPrpsCrdn
	 */
	public Long getNuPrpsCrdn() {
		return nuPrpsCrdn;
	}

	/**
	 * @param nuPrpsCrdn the nuPrpsCrdn to set
	 */
	public void setNuPrpsCrdn(Long nuPrpsCrdn) {
		this.nuPrpsCrdn = nuPrpsCrdn;
	}

	/**
	 * @return the cdMcc
	 */
	public BigDecimal getCdMcc() {
		return cdMcc;
	}

	/**
	 * @param cdMcc the cdMcc to set
	 */
	public void setCdMcc(BigDecimal cdMcc) {
		this.cdMcc = cdMcc;
	}

	/**
	 * @return the cdUsroAltrRgst
	 */
	public String getCdUsroAltrRgst() {
		return cdUsroAltrRgst;
	}

	/**
	 * @param cdUsroAltrRgst the cdUsroAltrRgst to set
	 */
	public void setCdUsroAltrRgst(String cdUsroAltrRgst) {
		this.cdUsroAltrRgst = cdUsroAltrRgst;
	}

	/**
	 * @return the cdUsroInclRgst
	 */
	public String getCdUsroInclRgst() {
		return cdUsroInclRgst;
	}

	/**
	 * @param cdUsroInclRgst the cdUsroInclRgst to set
	 */
	public void setCdUsroInclRgst(String cdUsroInclRgst) {
		this.cdUsroInclRgst = cdUsroInclRgst;
	}

	/**
	 * @return the dcEmailCntoEc
	 */
	public String getDcEmailCntoEc() {
		return dcEmailCntoEc;
	}

	/**
	 * @param dcEmailCntoEc the dcEmailCntoEc to set
	 */
	public void setDcEmailCntoEc(String dcEmailCntoEc) {
		this.dcEmailCntoEc = dcEmailCntoEc;
	}

	/**
	 * @return the dhAltrRgst
	 */
	public Date getDhAltrRgst() {
		return dhAltrRgst;
	}

	/**
	 * @param dhAltrRgst the dhAltrRgst to set
	 */
	public void setDhAltrRgst(Date dhAltrRgst) {
		this.dhAltrRgst = dhAltrRgst;
	}

	/**
	 * @return the dhInclRgst
	 */
	public Date getDhInclRgst() {
		return dhInclRgst;
	}

	/**
	 * @param dhInclRgst the dhInclRgst to set
	 */
	public void setDhInclRgst(Date dhInclRgst) {
		this.dhInclRgst = dhInclRgst;
	}

	/**
	 * @return the dtAtvcEc
	 */
	public Date getDtAtvcEc() {
		return dtAtvcEc;
	}

	/**
	 * @param dtAtvcEc the dtAtvcEc to set
	 */
	public void setDtAtvcEc(Date dtAtvcEc) {
		this.dtAtvcEc = dtAtvcEc;
	}

	/**
	 * @return the inMei
	 */
	public String getInMei() {
		return inMei;
	}

	/**
	 * @param inMei the inMei to set
	 */
	public void setInMei(String inMei) {
		this.inMei = inMei;
	}

	/**
	 * @return the nmFnts
	 */
	public String getNmFnts() {
		return nmFnts;
	}

	/**
	 * @param nmFnts the nmFnts to set
	 */
	public void setNmFnts(String nmFnts) {
		this.nmFnts = nmFnts;
	}

	/**
	 * @return the nmPesaCnto
	 */
	public String getNmPesaCnto() {
		return nmPesaCnto;
	}

	/**
	 * @param nmPesaCnto the nmPesaCnto to set
	 */
	public void setNmPesaCnto(String nmPesaCnto) {
		this.nmPesaCnto = nmPesaCnto;
	}

	/**
	 * @return the nmPlqtEc
	 */
	public String getNmPlqtEc() {
		return nmPlqtEc;
	}

	/**
	 * @param nmPlqtEc the nmPlqtEc to set
	 */
	public void setNmPlqtEc(String nmPlqtEc) {
		this.nmPlqtEc = nmPlqtEc;
	}

	/**
	 * @return the nmRazoSocl
	 */
	public String getNmRazoSocl() {
		return nmRazoSocl;
	}

	/**
	 * @param nmRazoSocl the nmRazoSocl to set
	 */
	public void setNmRazoSocl(String nmRazoSocl) {
		this.nmRazoSocl = nmRazoSocl;
	}

	/**
	 * @return the nuEc
	 */
	public Long getNuEc() {
		return nuEc;
	}

	/**
	 * @param nuEc the nuEc to set
	 */
	public void setNuEc(Long nuEc) {
		this.nuEc = nuEc;
	}

	/**
	 * @return the nuIe
	 */
	public BigDecimal getNuIe() {
		return nuIe;
	}

	/**
	 * @param nuIe the nuIe to set
	 */
	public void setNuIe(BigDecimal nuIe) {
		this.nuIe = nuIe;
	}

	/**
	 * @return the codTipoPlanoCielo
	 */
	public Integer getCodTipoPlanoCielo() {
		return codTipoPlanoCielo;
	}

	/**
	 * @param codTipoPlanoCielo the codTipoPlanoCielo to set
	 */
	public void setCodTipoPlanoCielo(Integer codTipoPlanoCielo) {
		this.codTipoPlanoCielo = codTipoPlanoCielo;
	}

}
