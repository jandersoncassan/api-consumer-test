package br.com.cielo.credenciamento.crd.service;

import javax.ejb.Local;

import br.com.cielo.credenciamento.ejb.remote.IArquivoRetornoServiceRemote;

/**
 * Interface Local responsael pela implementacao do tratamento / geração do arquivo de retorno
 * @author @Cielo
 * @since Release 02 - Credenciamento
 * @version 1.0.0
 */
@Local
public interface IArquivoRetornoService extends IArquivoRetornoServiceRemote{

}
