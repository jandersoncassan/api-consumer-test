package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrStcoEtpaCrdn_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.604-0300")
@StaticMetamodel(TbcrdrStcoEtpaCrdn.class)
public class TbcrdrStcoEtpaCrdn_ {
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, TbcrdrStcoEtpaCrdnPK> id;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, String> dcStcoEtpaPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, TbcrdrEtpaCrdn> tbcrdrEtpaCrdn;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdn, TbcrdrStcoEtpaPrp> tbcrdrStcoEtpaPrp;
}
