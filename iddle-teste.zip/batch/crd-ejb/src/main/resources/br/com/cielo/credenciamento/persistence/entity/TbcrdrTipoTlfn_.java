package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrTipoTlfn_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.729-0300")
@StaticMetamodel(TbcrdrTipoTlfn.class)
public class TbcrdrTipoTlfn_ {
    public static volatile SingularAttribute<TbcrdrTipoTlfn, Long> cdTipoTlfn;
    public static volatile SingularAttribute<TbcrdrTipoTlfn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoTlfn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrTipoTlfn, String> dcTipoTlfn;
    public static volatile SingularAttribute<TbcrdrTipoTlfn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoTlfn, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrTipoTlfn, TbcrdrTlfnEcPrp> tbcrdrTlfnEcPrps;
    public static volatile ListAttribute<TbcrdrTipoTlfn, TbcrdrTlfnPrptEcPrp> tbcrdrTlfnPrptEcPrps;
}
