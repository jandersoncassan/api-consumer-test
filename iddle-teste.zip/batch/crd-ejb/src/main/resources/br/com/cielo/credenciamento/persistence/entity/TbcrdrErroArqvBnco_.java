package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrErroArqvBnco
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.369-0300")
@StaticMetamodel(TbcrdrErroArqvBnco.class)
public class TbcrdrErroArqvBnco_ {
    public static volatile SingularAttribute<TbcrdrErroArqvBnco, Long> cdErroArqvBnco;
    public static volatile SingularAttribute<TbcrdrErroArqvBnco, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrErroArqvBnco, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrErroArqvBnco, String> dcErroArqvBnco;
    public static volatile SingularAttribute<TbcrdrErroArqvBnco, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrErroArqvBnco, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrErroArqvBnco, TbcrdrLogCntrCrgaBnco> tbcrdrLogCntrCrgaBncos;
}
