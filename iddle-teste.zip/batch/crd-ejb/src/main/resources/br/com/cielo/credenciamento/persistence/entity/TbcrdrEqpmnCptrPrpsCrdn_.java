package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrEqpmnCptrPrpsCrdn
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.338-0300")
@StaticMetamodel(TbcrdrEqpmnCptrPrpsCrdn.class)
public class TbcrdrEqpmnCptrPrpsCrdn_ {
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, TbcrdrEqpmnCptrPrpsCrdnPK> id;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, BigDecimal> cdMlhrDiaInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, BigDecimal> cdMlhrPrdoInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, String> cdMtvoCnclInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, BigDecimal> cdNmncMrkt;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, BigDecimal> cdSlcoCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, String> cdTipoTrmnInsl;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, Date> dhAtvcEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, Date> dtCnclInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, Date> dtInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, BigDecimal> nuChmdInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, BigDecimal> nuLgcoEqpmCptr;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdn, TbcrdrPrpsCrdn> tbcrdrPrpsCrdn;
}
