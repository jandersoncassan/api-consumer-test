package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrPrptEcPrp
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.557-0300")
@StaticMetamodel(TbcrdrPrptEcPrp.class)
public class TbcrdrPrptEcPrp_ {
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, TbcrdrPrptEcPrpPK> id;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, Date> dtNscmPrpt;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, String> nmCmplPrpt;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, BigDecimal> nuCpfPrpt;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, BigDecimal> nuDvCpfPrpt;
    public static volatile SingularAttribute<TbcrdrPrptEcPrp, TbcrdrEcPrp> tbcrdrEcPrp;
    public static volatile ListAttribute<TbcrdrPrptEcPrp, TbcrdrTlfnPrptEcPrp> tbcrdrTlfnPrptEcPrps;
}
