package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrLogPrpsBncoRjtdPK_
 * @author lumartins 
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.494-0300")
@StaticMetamodel(TbcrdrLogPrpsBncoRjtdPK.class)
public class TbcrdrLogPrpsBncoRjtdPK_ {
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Long> cdBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Date> dtMvmnArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Long> nuLnhaRgstArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Long> nuRmsaArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Long> nuPrpsBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Long> cdTipoRgstArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Long> cdCmpoArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtdPK, Long> cdTipoArqvBnco;
}
