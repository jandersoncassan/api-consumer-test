package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdwPcsmRgstCdstNovoPK
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.869-0300")
@StaticMetamodel(TbcrdwPcsmRgstCdstNovoPK.class)
public class TbcrdwPcsmRgstCdstNovoPK_ {
    public static volatile SingularAttribute<TbcrdwPcsmRgstCdstNovoPK, Long> cdBnco;
    public static volatile SingularAttribute<TbcrdwPcsmRgstCdstNovoPK, Date> dtMvmnArqvBnco;
    public static volatile SingularAttribute<TbcrdwPcsmRgstCdstNovoPK, Long> nuRmsaArqvBnco;
}
