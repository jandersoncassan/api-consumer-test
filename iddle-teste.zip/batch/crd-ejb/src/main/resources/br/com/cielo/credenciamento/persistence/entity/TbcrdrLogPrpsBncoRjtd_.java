package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrLogPrpsBncoRjtd_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.479-0300")
@StaticMetamodel(TbcrdrLogPrpsBncoRjtd.class)
public class TbcrdrLogPrpsBncoRjtd_ {
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtd, TbcrdrLogPrpsBncoRjtdPK> id;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtd, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtd, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtd, String> txCntdCmpoArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtd, TbcrdrCmpoArqvBnco> tbcrdrCmpoArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogPrpsBncoRjtd, TbcrdrErroCmpoArqvBnco> tbcrdrErroCmpoArqvBnco;
}
