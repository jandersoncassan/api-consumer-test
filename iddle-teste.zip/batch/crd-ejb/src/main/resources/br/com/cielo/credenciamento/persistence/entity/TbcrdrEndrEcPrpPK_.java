package br.com.cielo.credenciamento.persistence.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Clase de referencia TbcrdrEndrEcPrpPK
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.323-0300")
@StaticMetamodel(TbcrdrEndrEcPrpPK.class)
public class TbcrdrEndrEcPrpPK_ {
    public static volatile SingularAttribute<TbcrdrEndrEcPrpPK, Long> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrEndrEcPrpPK, Long> cdTipoEndrEcPrps;
    public static volatile SingularAttribute<TbcrdrEndrEcPrpPK, Long> nuSqnlEndrEcPrps;
}
