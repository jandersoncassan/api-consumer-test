package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrEndrEcPrp
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.307-0300")
@StaticMetamodel(TbcrdrEndrEcPrp.class)
public class TbcrdrEndrEcPrp_ {
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, TbcrdrEndrEcPrpPK> id;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, String> dcCmpmLgrd;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, String> nmCide;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, String> nmLgrd;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, BigDecimal> nuCep;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, String> nuLgrd;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, String> sgEstd;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, TbcrdrEcPrp> tbcrdrEcPrp;
    public static volatile SingularAttribute<TbcrdrEndrEcPrp, TbcrdrTipoEndrEcPrp> tbcrdrTipoEndrEcPrp;
}
