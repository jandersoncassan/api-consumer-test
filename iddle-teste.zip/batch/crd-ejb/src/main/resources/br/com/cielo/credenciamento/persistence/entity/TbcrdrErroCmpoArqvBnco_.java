package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrErroCmpoArqvBnco
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.369-0300")
@StaticMetamodel(TbcrdrErroCmpoArqvBnco.class)
public class TbcrdrErroCmpoArqvBnco_ {
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBnco, TbcrdrErroCmpoArqvBncoPk> id;
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBnco, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBnco, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBnco, String> dcErroCmpoArqvBnco;
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBnco, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBnco, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrErroCmpoArqvBnco, TbcrdrLogPrpsBncoRjtd> tbcrdrLogPrpsBncoRjtds;
}
