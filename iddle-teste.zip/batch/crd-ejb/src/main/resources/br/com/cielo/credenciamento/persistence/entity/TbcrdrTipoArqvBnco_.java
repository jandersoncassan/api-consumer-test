package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrTipoArqvBnco_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.682-0300")
@StaticMetamodel(TbcrdrTipoArqvBnco.class)
public class TbcrdrTipoArqvBnco_ {
    public static volatile SingularAttribute<TbcrdrTipoArqvBnco, Long> cdTipoArqvBnco;
    public static volatile SingularAttribute<TbcrdrTipoArqvBnco, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoArqvBnco, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrTipoArqvBnco, String> dcTipoArqvBnco;
    public static volatile SingularAttribute<TbcrdrTipoArqvBnco, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoArqvBnco, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrTipoArqvBnco, TbcrdrCmpoArqvBnco> tbcrdrCmpoArqvBncos;
    public static volatile ListAttribute<TbcrdrTipoArqvBnco, TbcrdrLogCntrCrgaBnco> tbcrdrLogCntrCrgaBncos;
}
