package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrStcoPrpsCrdn_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.682-0300")
@StaticMetamodel(TbcrdrStcoPrpsCrdn.class)
public class TbcrdrStcoPrpsCrdn_ {
    public static volatile SingularAttribute<TbcrdrStcoPrpsCrdn, Long> cdStcoPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrStcoPrpsCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrStcoPrpsCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrStcoPrpsCrdn, String> dcStcoPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrStcoPrpsCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrStcoPrpsCrdn, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrStcoPrpsCrdn, TbcrdrPrpsCrdn> tbcrdrPrpsCrdns;
}
