package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdwPcsmSlcpNovoPK
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.885-0300")
@StaticMetamodel(TbcrdwPcsmSlcpNovoPK.class)
public class TbcrdwPcsmSlcpNovoPK_ {
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovoPK, Long> cdBnco;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovoPK, Date> dtMvmnArqvBnco;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovoPK, Long> nuRmsaArqvBnco;
}
