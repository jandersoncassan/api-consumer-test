package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdwPcsmSlcpNovo
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.885-0300")
@StaticMetamodel(TbcrdwPcsmSlcpNovo.class)
public class TbcrdwPcsmSlcpNovo_ {
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, TbcrdwPcsmSlcpNovoPK> id;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroCdgoGrpoSlcp;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroDddTlfnSlcp;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroInPrimLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroInQrtoLtr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroInQuntLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroInSgndLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroInTereLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroMlhrDiaInstEqpm;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroMlhrPrdoParaInst;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroDddPrmoCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroDddQrtoCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroDddQuntCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroDddSgndCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroDddTereCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroPrimTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroQrtoTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroQuntTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroTereTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNmroTlfnSlcp;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroNrCpfCnpj;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroQntdPnpd;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroQntdPos;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroSglaTipoPesa;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroSgndTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdErroVldcArqv;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdGrpoSlcp;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdMlhrDiaInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdMlhrPrdoInstEqpmCptr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> cdTipoRgstArqvBnco;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> dcEndrUrlSiteEc;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> inPrimoLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> inQrtoLtr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> inQuntLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> inSgndLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> inTereLtor;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nmSrvdSiteEc;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuCpfCnpj;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuDddPrimTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuDddQrtoTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuDddQuntTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuDddSgndTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuDddTereTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuDddTlfnSlcp;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuEc;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, BigDecimal> nuLnhaRgstArqvBnco;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuPrimNuLgcoEqpmCptr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuPrimTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuQrtoNuLgcoEqpmCptr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuQrtoTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuQuntNuLgcoEqpmCptr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuQuntTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuSgndNuLgcoEqpmCptr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuSgndTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuSqnlPrpsBnco;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuSqnlRgst;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuTereNuLgcoEqpmCptr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuTereTlfnCelr;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> nuTlfnSlcp;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> qtPnpd;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> qtPos;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> sgTipoPesa;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> txPrimEpcoRsrdCielo;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> txQrtoEpcoRsrdCielo;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> txSgndEpcoRsrdCielo;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, String> txTereEpcoRsrdCielo;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, TbcrdrLogCntrCrgaBnco> tbcrdrLogCntrCrgaBnco;
    public static volatile SingularAttribute<TbcrdwPcsmSlcpNovo, TbcrdwStcoPcsmRgstArqv> tbcrdwStcoPcsmRgstArqv;
}
