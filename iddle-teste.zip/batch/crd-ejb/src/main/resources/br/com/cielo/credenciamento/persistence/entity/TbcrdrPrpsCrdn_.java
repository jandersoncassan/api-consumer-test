package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrPrpsCrdn_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.526-0300")
@StaticMetamodel(TbcrdrPrpsCrdn.class)
public class TbcrdrPrpsCrdn_ {
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, Long> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, BigDecimal> nuPrdePrps;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, BigDecimal> cdFerramentaCrdn;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, String> cdUsroFerramentaCrdn;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, Date> dhAbrtPrps;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, String> inTipoPesa;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, BigDecimal> nuCpfPrps;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, BigDecimal> nuDvCnpjPrps;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, BigDecimal> nuDvCpfPrps;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, BigDecimal> nuFiliCnpjPrps;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, BigDecimal> nuRaizCnpjPrps;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, TbcrdrCmpmPrpsCrdnBnco> tbcrdrCmpmPrpsCrdnBnco;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, TbcrdrEcPrp> tbcrdrEcPrp;
    public static volatile ListAttribute<TbcrdrPrpsCrdn, TbcrdrEqpmnCptrPrpsCrdn> tbcrdrEqpmnCptrPrpsCrdns;
    public static volatile ListAttribute<TbcrdrPrpsCrdn, TbcrdrEtpaPrpsCrdn> tbcrdrEtpaPrpsCrdns;
    public static volatile ListAttribute<TbcrdrPrpsCrdn, TbcrdrPrdtPrpsCrdn> tbcrdrPrdtPrpsCrdns;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, TbcrdrCtgrCrdn> tbcrdrCtgrCrdn;
    public static volatile SingularAttribute<TbcrdrPrpsCrdn, TbcrdrStcoPrpsCrdn> tbcrdrStcoPrpsCrdn;
    public static volatile ListAttribute<TbcrdrPrpsCrdn, TbcrdrSrvcPrpsCrdn> tbcrdrSrvcPrpsCrdns;
}
