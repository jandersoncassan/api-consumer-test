package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrTipoRgstArqvBnco_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.713-0300")
@StaticMetamodel(TbcrdrTipoRgstArqvBnco.class)
public class TbcrdrTipoRgstArqvBnco_ {
    public static volatile SingularAttribute<TbcrdrTipoRgstArqvBnco, Long> cdTipoRgstArqvBnco;
    public static volatile SingularAttribute<TbcrdrTipoRgstArqvBnco, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoRgstArqvBnco, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrTipoRgstArqvBnco, String> dcTipoRgstArqvBnco;
    public static volatile SingularAttribute<TbcrdrTipoRgstArqvBnco, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoRgstArqvBnco, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrTipoRgstArqvBnco, TbcrdrCmpoArqvBnco> tbcrdrCmpoArqvBncos;
}
