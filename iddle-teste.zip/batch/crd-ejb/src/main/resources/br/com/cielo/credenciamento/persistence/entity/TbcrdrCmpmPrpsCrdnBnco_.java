package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia a tabela TbcrdrCmpmPrpsCrdnBnco
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:05.776-0300")
@StaticMetamodel(TbcrdrCmpmPrpsCrdnBnco.class)
public class TbcrdrCmpmPrpsCrdnBnco_ {
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, Long> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, BigDecimal> cdBnco;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, Date> dtMvmnArqvBnco;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, BigDecimal> nuRmsaArqvBnco;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, BigDecimal> nuSqnlPrpsBnco;
    public static volatile SingularAttribute<TbcrdrCmpmPrpsCrdnBnco, TbcrdrPrpsCrdn> tbcrdrPrpsCrdn;
}
