package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdwStcoPcsmRgstArqv
 * @author lumartins 
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.901-0300")
@StaticMetamodel(TbcrdwStcoPcsmRgstArqv.class)
public class TbcrdwStcoPcsmRgstArqv_ {
    public static volatile SingularAttribute<TbcrdwStcoPcsmRgstArqv, Long> cdStcoPcsmRgstArqv;
    public static volatile SingularAttribute<TbcrdwStcoPcsmRgstArqv, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdwStcoPcsmRgstArqv, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdwStcoPcsmRgstArqv, String> dcStcoPcsmRgstArqv;
    public static volatile SingularAttribute<TbcrdwStcoPcsmRgstArqv, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdwStcoPcsmRgstArqv, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdwStcoPcsmRgstArqv, TbcrdwPcsmRgstCdstAtul> tbcrdwPcsmRgstCdstAtuls;
    public static volatile ListAttribute<TbcrdwStcoPcsmRgstArqv, TbcrdwPcsmRgstCdstNovo> tbcrdwPcsmRgstCdstNovos;
    public static volatile ListAttribute<TbcrdwStcoPcsmRgstArqv, TbcrdwPcsmSlcpNovo> tbcrdwPcsmSlcpNovos;
}
