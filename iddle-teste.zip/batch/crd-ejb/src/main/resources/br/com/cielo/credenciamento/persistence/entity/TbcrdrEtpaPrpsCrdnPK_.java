package br.com.cielo.credenciamento.persistence.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

/**
 * Classe de referencia TbcrdrEtpaPrpsCrdnPK
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.416-0300")
@StaticMetamodel(TbcrdrEtpaPrpsCrdnPK.class)
public class TbcrdrEtpaPrpsCrdnPK_ {
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdnPK, Long> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdnPK, Long> cdEtpaCrdn;
}
