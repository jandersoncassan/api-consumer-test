package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrEtpaCrdn
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.401-0300")
@StaticMetamodel(TbcrdrEtpaCrdn.class)
public class TbcrdrEtpaCrdn_ {
    public static volatile SingularAttribute<TbcrdrEtpaCrdn, Long> cdEtpaCrdn;
    public static volatile SingularAttribute<TbcrdrEtpaCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrEtpaCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrEtpaCrdn, String> dcEtpaCrdn;
    public static volatile SingularAttribute<TbcrdrEtpaCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrEtpaCrdn, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrEtpaCrdn, TbcrdrEtpaPrpsCrdn> tbcrdrEtpaPrpsCrdns;
    public static volatile ListAttribute<TbcrdrEtpaCrdn, TbcrdrStcoEtpaCrdn> tbcrdrStcoEtpaCrdns;
}
