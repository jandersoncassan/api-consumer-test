package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/** 
 * Classe de referencia TbcrdrLogCntrCrgaBncoPK_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.463-0300")
@StaticMetamodel(TbcrdrLogCntrCrgaBncoPK.class)
public class TbcrdrLogCntrCrgaBncoPK_ {
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBncoPK, Long> cdBnco;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBncoPK, Date> dtMvmnArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBncoPK, Long> nuRmsaArqvBnco;
}
