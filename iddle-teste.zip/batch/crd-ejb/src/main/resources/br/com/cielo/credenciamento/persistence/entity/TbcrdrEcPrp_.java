package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrEcPrp
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.260-0300")
@StaticMetamodel(TbcrdrEcPrp.class)
public class TbcrdrEcPrp_ {
    public static volatile SingularAttribute<TbcrdrEcPrp, Long> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrEcPrp, BigDecimal> cdMcc;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> dcEmailCntoEc;
    public static volatile SingularAttribute<TbcrdrEcPrp, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrEcPrp, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrEcPrp, Date> dtAtvcEc;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> inCdstDplc;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> inEcMgrd;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> inMei;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> nmFnts;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> nmPesaCnto;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> nmPlqtEc;
    public static volatile SingularAttribute<TbcrdrEcPrp, String> nmRazoSocl;
    public static volatile SingularAttribute<TbcrdrEcPrp, BigDecimal> nuEc;
    public static volatile SingularAttribute<TbcrdrEcPrp, BigDecimal> nuIe;
    public static volatile SingularAttribute<TbcrdrEcPrp, TbcrdrPrpsCrdn> tbcrdrPrpsCrdn;
    public static volatile ListAttribute<TbcrdrEcPrp, TbcrdrEndrEcPrp> tbcrdrEndrEcPrps;
    public static volatile ListAttribute<TbcrdrEcPrp, TbcrdrPrptEcPrp> tbcrdrPrptEcPrps;
    public static volatile ListAttribute<TbcrdrEcPrp, TbcrdrTlfnEcPrp> tbcrdrTlfnEcPrps;
}
