package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrTlfnPrptEcPrp_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.760-0300")
@StaticMetamodel(TbcrdrTlfnPrptEcPrp.class)
public class TbcrdrTlfnPrptEcPrp_ {
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, TbcrdrTlfnPrptEcPrpPK> id;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, BigDecimal> nuDddTlfnPrpt;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, String> nuTlfnPrpt;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, TbcrdrPrptEcPrp> tbcrdrPrptEcPrp;
    public static volatile SingularAttribute<TbcrdrTlfnPrptEcPrp, TbcrdrTipoTlfn> tbcrdrTipoTlfn;
}
