package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrCmpoArqvBnco_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.198-0300")
@StaticMetamodel(TbcrdrCmpoArqvBnco.class)
public class TbcrdrCmpoArqvBnco_ {
    public static volatile SingularAttribute<TbcrdrCmpoArqvBnco, TbcrdrCmpoArqvBncoPK> id;
    public static volatile SingularAttribute<TbcrdrCmpoArqvBnco, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrCmpoArqvBnco, String> dcCmpoArqvBnco;
    public static volatile SingularAttribute<TbcrdrCmpoArqvBnco, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrCmpoArqvBnco, BigDecimal> nuSqncCmpoArqvBnco;
    public static volatile SingularAttribute<TbcrdrCmpoArqvBnco, TbcrdrTipoArqvBnco> tbcrdrTipoArqvBnco;
    public static volatile SingularAttribute<TbcrdrCmpoArqvBnco, TbcrdrTipoRgstArqvBnco> tbcrdrTipoRgstArqvBnco;
    public static volatile ListAttribute<TbcrdrCmpoArqvBnco, TbcrdrLogPrpsBncoRjtd> tbcrdrLogPrpsBncoRjtds;
}
