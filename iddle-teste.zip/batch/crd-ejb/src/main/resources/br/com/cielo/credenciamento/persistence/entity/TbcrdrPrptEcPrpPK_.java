package br.com.cielo.credenciamento.persistence.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia  TbcrdrPrptEcPrpPK
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.573-0300")
@StaticMetamodel(TbcrdrPrptEcPrpPK.class)
public class TbcrdrPrptEcPrpPK_ {
    public static volatile SingularAttribute<TbcrdrPrptEcPrpPK, Long> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrPrptEcPrpPK, Long> nuSqnlPrpt;
}
