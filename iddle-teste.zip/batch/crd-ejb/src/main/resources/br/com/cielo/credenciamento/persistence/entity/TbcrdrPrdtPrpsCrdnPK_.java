package br.com.cielo.credenciamento.persistence.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrPrdtPrpsCrdnPK
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.510-0300")
@StaticMetamodel(TbcrdrPrdtPrpsCrdnPK.class)
public class TbcrdrPrdtPrpsCrdnPK_ {
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdnPK, Long> cdPrdt;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdnPK, Long> nuPrpsCrdn;
}
