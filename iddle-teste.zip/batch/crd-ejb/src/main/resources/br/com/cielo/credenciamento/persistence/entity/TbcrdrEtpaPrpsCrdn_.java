package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrEtpaPrpsCrdn
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.416-0300")
@StaticMetamodel(TbcrdrEtpaPrpsCrdn.class)
public class TbcrdrEtpaPrpsCrdn_ {
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, TbcrdrEtpaPrpsCrdnPK> id;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, Date> dhAbrtEtpaPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, TbcrdrEtpaCrdn> tbcrdrEtpaCrdn;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, TbcrdrPrpsCrdn> tbcrdrPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrEtpaPrpsCrdn, TbcrdrStcoEtpaPrp> tbcrdrStcoEtpaPrp;
}
