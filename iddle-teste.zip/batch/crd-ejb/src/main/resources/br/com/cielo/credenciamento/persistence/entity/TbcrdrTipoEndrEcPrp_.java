package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrTipoEndrEcPrp_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.698-0300")
@StaticMetamodel(TbcrdrTipoEndrEcPrp.class)
public class TbcrdrTipoEndrEcPrp_ {
    public static volatile SingularAttribute<TbcrdrTipoEndrEcPrp, Long> cdTipoEndrEcPrps;
    public static volatile SingularAttribute<TbcrdrTipoEndrEcPrp, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoEndrEcPrp, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrTipoEndrEcPrp, String> dcTipoEndrEcPrps;
    public static volatile SingularAttribute<TbcrdrTipoEndrEcPrp, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrTipoEndrEcPrp, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrTipoEndrEcPrp, TbcrdrEndrEcPrp> tbcrdrEndrEcPrps;
}
