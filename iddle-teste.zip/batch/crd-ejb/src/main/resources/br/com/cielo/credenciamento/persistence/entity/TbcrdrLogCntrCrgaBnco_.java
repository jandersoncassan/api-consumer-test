package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrLogCntrCrgaBnco_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.448-0300")
@StaticMetamodel(TbcrdrLogCntrCrgaBnco.class)
public class TbcrdrLogCntrCrgaBnco_ {
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, TbcrdrLogCntrCrgaBncoPK> id;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, String> inArqvActd;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, BigDecimal> qtRgstActd;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, BigDecimal> qtRgstRjtd;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, BigDecimal> qtTotlRgst;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, TbcrdrErroArqvBnco> tbcrdrErroArqvBnco;
    public static volatile SingularAttribute<TbcrdrLogCntrCrgaBnco, TbcrdrTipoArqvBnco> tbcrdrTipoArqvBnco;
    public static volatile ListAttribute<TbcrdrLogCntrCrgaBnco, TbcrdwPcsmRgstCdstAtul> tbcrdwPcsmRgstCdstAtul;
}
