package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrTlfnEcPrp_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.744-0300")
@StaticMetamodel(TbcrdrTlfnEcPrp.class)
public class TbcrdrTlfnEcPrp_ {
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, TbcrdrTlfnEcPrpPK> id;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, BigDecimal> nuDddTlfnEcPrps;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, String> nuTlfnEcPrps;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, TbcrdrEcPrp> tbcrdrEcPrp;
    public static volatile SingularAttribute<TbcrdrTlfnEcPrp, TbcrdrTipoTlfn> tbcrdrTipoTlfn;
}
