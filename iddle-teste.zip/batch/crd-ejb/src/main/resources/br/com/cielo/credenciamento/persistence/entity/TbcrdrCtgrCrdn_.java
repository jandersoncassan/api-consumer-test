package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrCtgrCrdn_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.229-0300")
@StaticMetamodel(TbcrdrCtgrCrdn.class)
public class TbcrdrCtgrCrdn_ {
    public static volatile SingularAttribute<TbcrdrCtgrCrdn, Long> cdCtgrCrdn;
    public static volatile SingularAttribute<TbcrdrCtgrCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrCtgrCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrCtgrCrdn, String> dcCtgrCrdn;
    public static volatile SingularAttribute<TbcrdrCtgrCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrCtgrCrdn, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrCtgrCrdn, TbcrdrPrpsCrdn> tbcrdrPrpsCrdns;
}
