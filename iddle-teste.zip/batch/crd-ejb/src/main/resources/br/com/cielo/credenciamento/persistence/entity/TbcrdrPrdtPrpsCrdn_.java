package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referenciaTbcrdrPrdtPrpsCrdn
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.494-0300")
@StaticMetamodel(TbcrdrPrdtPrpsCrdn.class)
public class TbcrdrPrdtPrpsCrdn_ {
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, TbcrdrPrdtPrpsCrdnPK> id;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, BigDecimal> cdAgnc;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, BigDecimal> cdBnco;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, BigDecimal> cdCncr;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, BigDecimal> cdErroHblcPrdt;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, Date> dhInclRgst;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, String> inPrdtHblt;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, String> nuDvAgnc;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, String> nuDvCncr;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, BigDecimal> pcTaxaMdr;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, BigDecimal> qtDiaLqdc;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, BigDecimal> qtPrclPrdt;
    public static volatile SingularAttribute<TbcrdrPrdtPrpsCrdn, TbcrdrPrpsCrdn> tbcrdrPrpsCrdn;
}
