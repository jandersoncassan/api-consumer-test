package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdwPcsmRgstCdstAtulPK_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.807-0300")
@StaticMetamodel(TbcrdwPcsmRgstCdstAtulPK.class)
public class TbcrdwPcsmRgstCdstAtulPK_ {
    public static volatile SingularAttribute<TbcrdwPcsmRgstCdstAtulPK, Long> cdBnco;
    public static volatile SingularAttribute<TbcrdwPcsmRgstCdstAtulPK, Date> dtMvmnArqvBnco;
    public static volatile SingularAttribute<TbcrdwPcsmRgstCdstAtulPK, Long> nuRmsaArqvBnco;
    public static volatile SingularAttribute<TbcrdwPcsmRgstCdstAtulPK, BigDecimal> nuLnhaRgstArqvBnco;
}
