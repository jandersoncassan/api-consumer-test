package br.com.cielo.credenciamento.persistence.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrEqpmnCptrPrpsCrdnPK
 * @author lumartins
 *
 */ 
@Generated(value = "Dali", date = "2016-03-31T22:18:06.354-0300")
@StaticMetamodel(TbcrdrEqpmnCptrPrpsCrdnPK.class)
public class TbcrdrEqpmnCptrPrpsCrdnPK_ {
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdnPK, Long> nuPrpsCrdn;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdnPK, String> cdTipoTrmn;
    public static volatile SingularAttribute<TbcrdrEqpmnCptrPrpsCrdnPK, Long> nuSqclEqpmCptr;
}
