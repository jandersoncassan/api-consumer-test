package br.com.cielo.credenciamento.persistence.entity;

import java.math.BigDecimal;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrErroCmpoArqvBncoPk_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.401-0300")
@StaticMetamodel(TbcrdrErroCmpoArqvBncoPk.class)
public class TbcrdrErroCmpoArqvBncoPk_ {
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBncoPk, Long> cdErroCmpoArqvBnco;
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBncoPk, BigDecimal> cdTipoArqvBnco;
    public static volatile SingularAttribute<TbcrdrErroCmpoArqvBncoPk, BigDecimal> cdTipoRgstArqvBnco;
}
