package br.com.cielo.credenciamento.persistence.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrStcoEtpaCrdnPK_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.635-0300")
@StaticMetamodel(TbcrdrStcoEtpaCrdnPK.class)
public class TbcrdrStcoEtpaCrdnPK_ {
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdnPK, Long> cdEtpaCrdn;
    public static volatile SingularAttribute<TbcrdrStcoEtpaCrdnPK, Long> cdStcoEtpaPrps;
}
