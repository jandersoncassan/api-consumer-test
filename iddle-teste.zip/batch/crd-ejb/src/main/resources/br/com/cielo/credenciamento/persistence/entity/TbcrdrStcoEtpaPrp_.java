package br.com.cielo.credenciamento.persistence.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
/**
 * Classe de referencia TbcrdrStcoEtpaPrp_
 * @author lumartins
 *
 */
@Generated(value = "Dali", date = "2016-03-31T22:18:06.651-0300")
@StaticMetamodel(TbcrdrStcoEtpaPrp.class)
public class TbcrdrStcoEtpaPrp_ {
    public static volatile SingularAttribute<TbcrdrStcoEtpaPrp, Long> cdStcoEtpaPrps;
    public static volatile SingularAttribute<TbcrdrStcoEtpaPrp, String> cdUsroAltrRgst;
    public static volatile SingularAttribute<TbcrdrStcoEtpaPrp, String> cdUsroInclRgst;
    public static volatile SingularAttribute<TbcrdrStcoEtpaPrp, String> dcStcoEtpaPrps;
    public static volatile SingularAttribute<TbcrdrStcoEtpaPrp, Date> dhAltrRgst;
    public static volatile SingularAttribute<TbcrdrStcoEtpaPrp, Date> dhInclRgst;
    public static volatile ListAttribute<TbcrdrStcoEtpaPrp, TbcrdrEtpaPrpsCrdn> tbcrdrEtpaPrpsCrdns;
    public static volatile ListAttribute<TbcrdrStcoEtpaPrp, TbcrdrStcoEtpaCrdn> tbcrdrStcoEtpaCrdns;
}
