package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class CredenciamentoClienteProxy implements br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoCliente {
  private String _endpoint = null;
  private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoCliente credenciamentoCliente = null;
  
  public CredenciamentoClienteProxy() {
    _initCredenciamentoClienteProxy();
  }
  
  public CredenciamentoClienteProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamentoClienteProxy();
  }
  
  private void _initCredenciamentoClienteProxy() {
    try {
      credenciamentoCliente = (new br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteServiceLocator()).getCredenciarCliente();
      if (credenciamentoCliente != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamentoCliente)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamentoCliente)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamentoCliente != null)
      ((javax.xml.rpc.Stub)credenciamentoCliente)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoCliente getCredenciamentoCliente() {
    if (credenciamentoCliente == null)
      _initCredenciamentoClienteProxy();
    return credenciamentoCliente;
  }
  
  public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialResponse consultarClienteExistente(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ConsultarClienteRequest dadosConsultarCliente) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException{
    if (credenciamentoCliente == null)
      _initCredenciamentoClienteProxy();
    return credenciamentoCliente.consultarClienteExistente(dadosConsultarCliente);
  }
  
  public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoResponse credenciarCliente(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoRequest dadosCredenciamento) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException{
    if (credenciamentoCliente == null)
      _initCredenciamentoClienteProxy();
    return credenciamentoCliente.credenciarCliente(dadosCredenciamento);
  }
  
  public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ProspectResponse consultarPropostaRascunho(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ConsultarProspectRequest dadosConsultarProspect) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException{
    if (credenciamentoCliente == null)
      _initCredenciamentoClienteProxy();
    return credenciamentoCliente.consultarPropostaRascunho(dadosConsultarProspect);
  }
  
  public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ProspectResponse atualizarPropostaRascunho(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.AtualizarProspectRequest dadosAtualizarProspect) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException{
    if (credenciamentoCliente == null)
      _initCredenciamentoClienteProxy();
    return credenciamentoCliente.atualizarPropostaRascunho(dadosAtualizarProspect);
  }
  
  
}