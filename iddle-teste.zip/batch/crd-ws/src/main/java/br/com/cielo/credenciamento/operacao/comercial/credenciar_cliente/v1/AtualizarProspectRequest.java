/**
 * AtualizarProspectRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class AtualizarProspectRequest  implements java.io.Serializable {
    private long numeroProposta;

    private int codigoFerramenta;

    private java.lang.String indicadorAgro;

    private java.lang.String loginUsuario;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoesCaptura;

    public AtualizarProspectRequest() {
    }

    public AtualizarProspectRequest(
           long numeroProposta,
           int codigoFerramenta,
           java.lang.String indicadorAgro,
           java.lang.String loginUsuario,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoesCaptura) {
           this.numeroProposta = numeroProposta;
           this.codigoFerramenta = codigoFerramenta;
           this.indicadorAgro = indicadorAgro;
           this.loginUsuario = loginUsuario;
           this.estabelecimentoComercial = estabelecimentoComercial;
           this.solucoesCaptura = solucoesCaptura;
    }


    /**
     * Gets the numeroProposta value for this AtualizarProspectRequest.
     * 
     * @return numeroProposta
     */
    public long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this AtualizarProspectRequest.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the codigoFerramenta value for this AtualizarProspectRequest.
     * 
     * @return codigoFerramenta
     */
    public int getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this AtualizarProspectRequest.
     * 
     * @param codigoFerramenta
     */
    public void setCodigoFerramenta(int codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the indicadorAgro value for this AtualizarProspectRequest.
     * 
     * @return indicadorAgro
     */
    public java.lang.String getIndicadorAgro() {
        return indicadorAgro;
    }


    /**
     * Sets the indicadorAgro value for this AtualizarProspectRequest.
     * 
     * @param indicadorAgro
     */
    public void setIndicadorAgro(java.lang.String indicadorAgro) {
        this.indicadorAgro = indicadorAgro;
    }


    /**
     * Gets the loginUsuario value for this AtualizarProspectRequest.
     * 
     * @return loginUsuario
     */
    public java.lang.String getLoginUsuario() {
        return loginUsuario;
    }


    /**
     * Sets the loginUsuario value for this AtualizarProspectRequest.
     * 
     * @param loginUsuario
     */
    public void setLoginUsuario(java.lang.String loginUsuario) {
        this.loginUsuario = loginUsuario;
    }


    /**
     * Gets the estabelecimentoComercial value for this AtualizarProspectRequest.
     * 
     * @return estabelecimentoComercial
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType getEstabelecimentoComercial() {
        return estabelecimentoComercial;
    }


    /**
     * Sets the estabelecimentoComercial value for this AtualizarProspectRequest.
     * 
     * @param estabelecimentoComercial
     */
    public void setEstabelecimentoComercial(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial) {
        this.estabelecimentoComercial = estabelecimentoComercial;
    }


    /**
     * Gets the solucoesCaptura value for this AtualizarProspectRequest.
     * 
     * @return solucoesCaptura
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] getSolucoesCaptura() {
        return solucoesCaptura;
    }


    /**
     * Sets the solucoesCaptura value for this AtualizarProspectRequest.
     * 
     * @param solucoesCaptura
     */
    public void setSolucoesCaptura(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoesCaptura) {
        this.solucoesCaptura = solucoesCaptura;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AtualizarProspectRequest)) return false;
        AtualizarProspectRequest other = (AtualizarProspectRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.numeroProposta == other.getNumeroProposta() &&
            this.codigoFerramenta == other.getCodigoFerramenta() &&
            ((this.indicadorAgro==null && other.getIndicadorAgro()==null) || 
             (this.indicadorAgro!=null &&
              this.indicadorAgro.equals(other.getIndicadorAgro()))) &&
            ((this.loginUsuario==null && other.getLoginUsuario()==null) || 
             (this.loginUsuario!=null &&
              this.loginUsuario.equals(other.getLoginUsuario()))) &&
            ((this.estabelecimentoComercial==null && other.getEstabelecimentoComercial()==null) || 
             (this.estabelecimentoComercial!=null &&
              this.estabelecimentoComercial.equals(other.getEstabelecimentoComercial()))) &&
            ((this.solucoesCaptura==null && other.getSolucoesCaptura()==null) || 
             (this.solucoesCaptura!=null &&
              java.util.Arrays.equals(this.solucoesCaptura, other.getSolucoesCaptura())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getNumeroProposta()).hashCode();
        _hashCode += getCodigoFerramenta();
        if (getIndicadorAgro() != null) {
            _hashCode += getIndicadorAgro().hashCode();
        }
        if (getLoginUsuario() != null) {
            _hashCode += getLoginUsuario().hashCode();
        }
        if (getEstabelecimentoComercial() != null) {
            _hashCode += getEstabelecimentoComercial().hashCode();
        }
        if (getSolucoesCaptura() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSolucoesCaptura());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSolucoesCaptura(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AtualizarProspectRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "atualizarProspectRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAgro");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indicadorAgro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loginUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "loginUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "estabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "estabelecimentoComercialType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucoesCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("", "solucoesCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "solucaoCapturaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "solucao"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
