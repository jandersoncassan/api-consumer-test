/**
 * CampoCriticaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class CampoCriticaType  implements java.io.Serializable {
    private java.lang.String codigoCampo;

    private java.lang.String descricaoCampo;

    private java.lang.String referenciaNomeCampo;

    private java.lang.String referenciaSequenciaCampo;

    public CampoCriticaType() {
    }

    public CampoCriticaType(
           java.lang.String codigoCampo,
           java.lang.String descricaoCampo,
           java.lang.String referenciaNomeCampo,
           java.lang.String referenciaSequenciaCampo) {
           this.codigoCampo = codigoCampo;
           this.descricaoCampo = descricaoCampo;
           this.referenciaNomeCampo = referenciaNomeCampo;
           this.referenciaSequenciaCampo = referenciaSequenciaCampo;
    }


    /**
     * Gets the codigoCampo value for this CampoCriticaType.
     * 
     * @return codigoCampo
     */
    public java.lang.String getCodigoCampo() {
        return codigoCampo;
    }


    /**
     * Sets the codigoCampo value for this CampoCriticaType.
     * 
     * @param codigoCampo
     */
    public void setCodigoCampo(java.lang.String codigoCampo) {
        this.codigoCampo = codigoCampo;
    }


    /**
     * Gets the descricaoCampo value for this CampoCriticaType.
     * 
     * @return descricaoCampo
     */
    public java.lang.String getDescricaoCampo() {
        return descricaoCampo;
    }


    /**
     * Sets the descricaoCampo value for this CampoCriticaType.
     * 
     * @param descricaoCampo
     */
    public void setDescricaoCampo(java.lang.String descricaoCampo) {
        this.descricaoCampo = descricaoCampo;
    }


    /**
     * Gets the referenciaNomeCampo value for this CampoCriticaType.
     * 
     * @return referenciaNomeCampo
     */
    public java.lang.String getReferenciaNomeCampo() {
        return referenciaNomeCampo;
    }


    /**
     * Sets the referenciaNomeCampo value for this CampoCriticaType.
     * 
     * @param referenciaNomeCampo
     */
    public void setReferenciaNomeCampo(java.lang.String referenciaNomeCampo) {
        this.referenciaNomeCampo = referenciaNomeCampo;
    }


    /**
     * Gets the referenciaSequenciaCampo value for this CampoCriticaType.
     * 
     * @return referenciaSequenciaCampo
     */
    public java.lang.String getReferenciaSequenciaCampo() {
        return referenciaSequenciaCampo;
    }


    /**
     * Sets the referenciaSequenciaCampo value for this CampoCriticaType.
     * 
     * @param referenciaSequenciaCampo
     */
    public void setReferenciaSequenciaCampo(java.lang.String referenciaSequenciaCampo) {
        this.referenciaSequenciaCampo = referenciaSequenciaCampo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CampoCriticaType)) return false;
        CampoCriticaType other = (CampoCriticaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCampo==null && other.getCodigoCampo()==null) || 
             (this.codigoCampo!=null &&
              this.codigoCampo.equals(other.getCodigoCampo()))) &&
            ((this.descricaoCampo==null && other.getDescricaoCampo()==null) || 
             (this.descricaoCampo!=null &&
              this.descricaoCampo.equals(other.getDescricaoCampo()))) &&
            ((this.referenciaNomeCampo==null && other.getReferenciaNomeCampo()==null) || 
             (this.referenciaNomeCampo!=null &&
              this.referenciaNomeCampo.equals(other.getReferenciaNomeCampo()))) &&
            ((this.referenciaSequenciaCampo==null && other.getReferenciaSequenciaCampo()==null) || 
             (this.referenciaSequenciaCampo!=null &&
              this.referenciaSequenciaCampo.equals(other.getReferenciaSequenciaCampo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCampo() != null) {
            _hashCode += getCodigoCampo().hashCode();
        }
        if (getDescricaoCampo() != null) {
            _hashCode += getDescricaoCampo().hashCode();
        }
        if (getReferenciaNomeCampo() != null) {
            _hashCode += getReferenciaNomeCampo().hashCode();
        }
        if (getReferenciaSequenciaCampo() != null) {
            _hashCode += getReferenciaSequenciaCampo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CampoCriticaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "campoCriticaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCampo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoCampo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoCampo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descricaoCampo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referenciaNomeCampo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "referenciaNomeCampo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referenciaSequenciaCampo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "referenciaSequenciaCampo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
