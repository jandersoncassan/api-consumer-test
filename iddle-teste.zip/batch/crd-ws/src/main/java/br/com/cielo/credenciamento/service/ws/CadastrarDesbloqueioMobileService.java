/**
 * CadastrarDesbloqueioMobileService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.service.ws;

public interface CadastrarDesbloqueioMobileService extends javax.xml.rpc.Service {
    public java.lang.String getCadastrarDesbloqueioMobilePortAddress();

    public br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobile getCadastrarDesbloqueioMobilePort() throws javax.xml.rpc.ServiceException;

    public br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobile getCadastrarDesbloqueioMobilePort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
