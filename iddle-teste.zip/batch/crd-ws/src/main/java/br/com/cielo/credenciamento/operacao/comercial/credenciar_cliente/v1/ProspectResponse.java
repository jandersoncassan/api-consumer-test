/**
 * ProspectResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class ProspectResponse  implements java.io.Serializable {
    private java.lang.String codigoStatus;

    private java.lang.String descricaoStatus;

    private java.lang.Long numeroProposta;

    private java.lang.Integer codigoFerramenta;

    private java.lang.String indicadorAgro;

    private java.lang.String loginUsuario;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoes;

    public ProspectResponse() {
    }

    public ProspectResponse(
           java.lang.String codigoStatus,
           java.lang.String descricaoStatus,
           java.lang.Long numeroProposta,
           java.lang.Integer codigoFerramenta,
           java.lang.String indicadorAgro,
           java.lang.String loginUsuario,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoes) {
           this.codigoStatus = codigoStatus;
           this.descricaoStatus = descricaoStatus;
           this.numeroProposta = numeroProposta;
           this.codigoFerramenta = codigoFerramenta;
           this.indicadorAgro = indicadorAgro;
           this.loginUsuario = loginUsuario;
           this.estabelecimentoComercial = estabelecimentoComercial;
           this.solucoes = solucoes;
    }


    /**
     * Gets the codigoStatus value for this ProspectResponse.
     * 
     * @return codigoStatus
     */
    public java.lang.String getCodigoStatus() {
        return codigoStatus;
    }


    /**
     * Sets the codigoStatus value for this ProspectResponse.
     * 
     * @param codigoStatus
     */
    public void setCodigoStatus(java.lang.String codigoStatus) {
        this.codigoStatus = codigoStatus;
    }


    /**
     * Gets the descricaoStatus value for this ProspectResponse.
     * 
     * @return descricaoStatus
     */
    public java.lang.String getDescricaoStatus() {
        return descricaoStatus;
    }


    /**
     * Sets the descricaoStatus value for this ProspectResponse.
     * 
     * @param descricaoStatus
     */
    public void setDescricaoStatus(java.lang.String descricaoStatus) {
        this.descricaoStatus = descricaoStatus;
    }


    /**
     * Gets the numeroProposta value for this ProspectResponse.
     * 
     * @return numeroProposta
     */
    public java.lang.Long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this ProspectResponse.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(java.lang.Long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the codigoFerramenta value for this ProspectResponse.
     * 
     * @return codigoFerramenta
     */
    public java.lang.Integer getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this ProspectResponse.
     * 
     * @param codigoFerramenta
     */
    public void setCodigoFerramenta(java.lang.Integer codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the indicadorAgro value for this ProspectResponse.
     * 
     * @return indicadorAgro
     */
    public java.lang.String getIndicadorAgro() {
        return indicadorAgro;
    }


    /**
     * Sets the indicadorAgro value for this ProspectResponse.
     * 
     * @param indicadorAgro
     */
    public void setIndicadorAgro(java.lang.String indicadorAgro) {
        this.indicadorAgro = indicadorAgro;
    }


    /**
     * Gets the loginUsuario value for this ProspectResponse.
     * 
     * @return loginUsuario
     */
    public java.lang.String getLoginUsuario() {
        return loginUsuario;
    }


    /**
     * Sets the loginUsuario value for this ProspectResponse.
     * 
     * @param loginUsuario
     */
    public void setLoginUsuario(java.lang.String loginUsuario) {
        this.loginUsuario = loginUsuario;
    }


    /**
     * Gets the estabelecimentoComercial value for this ProspectResponse.
     * 
     * @return estabelecimentoComercial
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType getEstabelecimentoComercial() {
        return estabelecimentoComercial;
    }


    /**
     * Sets the estabelecimentoComercial value for this ProspectResponse.
     * 
     * @param estabelecimentoComercial
     */
    public void setEstabelecimentoComercial(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial) {
        this.estabelecimentoComercial = estabelecimentoComercial;
    }


    /**
     * Gets the solucoes value for this ProspectResponse.
     * 
     * @return solucoes
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] getSolucoes() {
        return solucoes;
    }


    /**
     * Sets the solucoes value for this ProspectResponse.
     * 
     * @param solucoes
     */
    public void setSolucoes(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoes) {
        this.solucoes = solucoes;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProspectResponse)) return false;
        ProspectResponse other = (ProspectResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoStatus==null && other.getCodigoStatus()==null) || 
             (this.codigoStatus!=null &&
              this.codigoStatus.equals(other.getCodigoStatus()))) &&
            ((this.descricaoStatus==null && other.getDescricaoStatus()==null) || 
             (this.descricaoStatus!=null &&
              this.descricaoStatus.equals(other.getDescricaoStatus()))) &&
            ((this.numeroProposta==null && other.getNumeroProposta()==null) || 
             (this.numeroProposta!=null &&
              this.numeroProposta.equals(other.getNumeroProposta()))) &&
            ((this.codigoFerramenta==null && other.getCodigoFerramenta()==null) || 
             (this.codigoFerramenta!=null &&
              this.codigoFerramenta.equals(other.getCodigoFerramenta()))) &&
            ((this.indicadorAgro==null && other.getIndicadorAgro()==null) || 
             (this.indicadorAgro!=null &&
              this.indicadorAgro.equals(other.getIndicadorAgro()))) &&
            ((this.loginUsuario==null && other.getLoginUsuario()==null) || 
             (this.loginUsuario!=null &&
              this.loginUsuario.equals(other.getLoginUsuario()))) &&
            ((this.estabelecimentoComercial==null && other.getEstabelecimentoComercial()==null) || 
             (this.estabelecimentoComercial!=null &&
              this.estabelecimentoComercial.equals(other.getEstabelecimentoComercial()))) &&
            ((this.solucoes==null && other.getSolucoes()==null) || 
             (this.solucoes!=null &&
              java.util.Arrays.equals(this.solucoes, other.getSolucoes())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoStatus() != null) {
            _hashCode += getCodigoStatus().hashCode();
        }
        if (getDescricaoStatus() != null) {
            _hashCode += getDescricaoStatus().hashCode();
        }
        if (getNumeroProposta() != null) {
            _hashCode += getNumeroProposta().hashCode();
        }
        if (getCodigoFerramenta() != null) {
            _hashCode += getCodigoFerramenta().hashCode();
        }
        if (getIndicadorAgro() != null) {
            _hashCode += getIndicadorAgro().hashCode();
        }
        if (getLoginUsuario() != null) {
            _hashCode += getLoginUsuario().hashCode();
        }
        if (getEstabelecimentoComercial() != null) {
            _hashCode += getEstabelecimentoComercial().hashCode();
        }
        if (getSolucoes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSolucoes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSolucoes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProspectResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "prospectResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descricaoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAgro");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indicadorAgro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loginUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "loginUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "estabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "estabelecimentoComercialType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucoes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "solucoes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "solucaoCapturaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "solucao"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
