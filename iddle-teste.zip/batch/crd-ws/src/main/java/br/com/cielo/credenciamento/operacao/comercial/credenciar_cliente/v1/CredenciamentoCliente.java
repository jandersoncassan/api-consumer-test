/**
 * CredenciamentoCliente.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public interface CredenciamentoCliente extends java.rmi.Remote {
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialResponse consultarClienteExistente(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ConsultarClienteRequest dadosConsultarCliente) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException;
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoResponse credenciarCliente(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoRequest dadosCredenciamento) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException;
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ProspectResponse consultarPropostaRascunho(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ConsultarProspectRequest dadosConsultarProspect) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException;
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.ProspectResponse atualizarPropostaRascunho(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.AtualizarProspectRequest dadosAtualizarProspect) throws java.rmi.RemoteException, br.com.cielo.credenciamento.operacao.comercial.service_lista_bancos.v1.SOAPException;
}
