/**
 * SolucoesCaptura.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente;

public class SolucoesCaptura  implements java.io.Serializable {
    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucaoCapturaType solucaoCaptura;

    public SolucoesCaptura() {
    }

    public SolucoesCaptura(
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucaoCapturaType solucaoCaptura) {
           this.solucaoCaptura = solucaoCaptura;
    }


    /**
     * Gets the solucaoCaptura value for this SolucoesCaptura.
     * 
     * @return solucaoCaptura
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucaoCapturaType getSolucaoCaptura() {
        return solucaoCaptura;
    }


    /**
     * Sets the solucaoCaptura value for this SolucoesCaptura.
     * 
     * @param solucaoCaptura
     */
    public void setSolucaoCaptura(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucaoCapturaType solucaoCaptura) {
        this.solucaoCaptura = solucaoCaptura;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SolucoesCaptura)) return false;
        SolucoesCaptura other = (SolucoesCaptura) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.solucaoCaptura==null && other.getSolucaoCaptura()==null) || 
             (this.solucaoCaptura!=null &&
              this.solucaoCaptura.equals(other.getSolucaoCaptura())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getSolucaoCaptura() != null) {
            _hashCode += getSolucaoCaptura().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SolucoesCaptura.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "solucoesCaptura"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "solucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "solucaoCapturaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
