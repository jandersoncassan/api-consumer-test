/**
 * CredenciarClienteServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class CredenciarClienteServiceLocator extends org.apache.axis.client.Service implements br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteService {

    public CredenciarClienteServiceLocator() {
    }


    public CredenciarClienteServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public CredenciarClienteServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for CredenciarCliente
    private java.lang.String CredenciarCliente_address = "http://10.80.30.78:8802/CredenciamentoCliente/CredenciarClienteService";

    public java.lang.String getCredenciarClienteAddress() {
        return CredenciarCliente_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String CredenciarClienteWSDDServiceName = "CredenciarCliente";

    public java.lang.String getCredenciarClienteWSDDServiceName() {
        return CredenciarClienteWSDDServiceName;
    }

    public void setCredenciarClienteWSDDServiceName(java.lang.String name) {
        CredenciarClienteWSDDServiceName = name;
    }

    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoCliente getCredenciarCliente() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(CredenciarCliente_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCredenciarCliente(endpoint);
    }

    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoCliente getCredenciarCliente(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteBindingStub _stub = new br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteBindingStub(portAddress, this);
            _stub.setPortName(getCredenciarClienteWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCredenciarClienteEndpointAddress(java.lang.String address) {
        CredenciarCliente_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciamentoCliente.class.isAssignableFrom(serviceEndpointInterface)) {
                br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteBindingStub _stub = new br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.CredenciarClienteBindingStub(new java.net.URL(CredenciarCliente_address), this);
                _stub.setPortName(getCredenciarClienteWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("CredenciarCliente".equals(inputPortName)) {
            return getCredenciarCliente();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "CredenciarClienteService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "CredenciarCliente"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("CredenciarCliente".equals(portName)) {
            setCredenciarClienteEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
