/**
 * EstabelecimentoComercialResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class EstabelecimentoComercialResponse  implements java.io.Serializable {
    private java.lang.String codigoStatus;

    private java.lang.String descricaoStatus;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial;

    public EstabelecimentoComercialResponse() {
    }

    public EstabelecimentoComercialResponse(
           java.lang.String codigoStatus,
           java.lang.String descricaoStatus,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial) {
           this.codigoStatus = codigoStatus;
           this.descricaoStatus = descricaoStatus;
           this.estabelecimentoComercial = estabelecimentoComercial;
    }


    /**
     * Gets the codigoStatus value for this EstabelecimentoComercialResponse.
     * 
     * @return codigoStatus
     */
    public java.lang.String getCodigoStatus() {
        return codigoStatus;
    }


    /**
     * Sets the codigoStatus value for this EstabelecimentoComercialResponse.
     * 
     * @param codigoStatus
     */
    public void setCodigoStatus(java.lang.String codigoStatus) {
        this.codigoStatus = codigoStatus;
    }


    /**
     * Gets the descricaoStatus value for this EstabelecimentoComercialResponse.
     * 
     * @return descricaoStatus
     */
    public java.lang.String getDescricaoStatus() {
        return descricaoStatus;
    }


    /**
     * Sets the descricaoStatus value for this EstabelecimentoComercialResponse.
     * 
     * @param descricaoStatus
     */
    public void setDescricaoStatus(java.lang.String descricaoStatus) {
        this.descricaoStatus = descricaoStatus;
    }


    /**
     * Gets the estabelecimentoComercial value for this EstabelecimentoComercialResponse.
     * 
     * @return estabelecimentoComercial
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType getEstabelecimentoComercial() {
        return estabelecimentoComercial;
    }


    /**
     * Sets the estabelecimentoComercial value for this EstabelecimentoComercialResponse.
     * 
     * @param estabelecimentoComercial
     */
    public void setEstabelecimentoComercial(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial) {
        this.estabelecimentoComercial = estabelecimentoComercial;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EstabelecimentoComercialResponse)) return false;
        EstabelecimentoComercialResponse other = (EstabelecimentoComercialResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoStatus==null && other.getCodigoStatus()==null) || 
             (this.codigoStatus!=null &&
              this.codigoStatus.equals(other.getCodigoStatus()))) &&
            ((this.descricaoStatus==null && other.getDescricaoStatus()==null) || 
             (this.descricaoStatus!=null &&
              this.descricaoStatus.equals(other.getDescricaoStatus()))) &&
            ((this.estabelecimentoComercial==null && other.getEstabelecimentoComercial()==null) || 
             (this.estabelecimentoComercial!=null &&
              this.estabelecimentoComercial.equals(other.getEstabelecimentoComercial())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoStatus() != null) {
            _hashCode += getCodigoStatus().hashCode();
        }
        if (getDescricaoStatus() != null) {
            _hashCode += getDescricaoStatus().hashCode();
        }
        if (getEstabelecimentoComercial() != null) {
            _hashCode += getEstabelecimentoComercial().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EstabelecimentoComercialResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "estabelecimentoComercialResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descricaoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "estabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "estabelecimentoComercialType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
