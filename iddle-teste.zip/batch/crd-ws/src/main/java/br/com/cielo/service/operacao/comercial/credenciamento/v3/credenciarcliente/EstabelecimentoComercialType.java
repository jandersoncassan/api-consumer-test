/**
 * EstabelecimentoComercialType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente;

public class EstabelecimentoComercialType  implements java.io.Serializable {
    private java.lang.Long numeroCpfCnpj;

    private java.lang.Long numeroEc;

    /* Tipo que representa Código do Tipo da
     * 						Pessoa. F -
     * 						Física J - Jurídica */
    private java.lang.String codigoTipoPessoa;

    private java.lang.String nomeRazaoSocial;

    private java.lang.String indicadorMicroEmpreendedorIndividual;

    private java.lang.Long numeroInscricaoEstadual;

    private java.lang.String nomeFantasia;

    private java.lang.String nomePlaqueta;

    private java.lang.String nomePessoaContato;

    private java.lang.String emailContato;

    private java.lang.Integer codigoRamoAtividade;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DomiciliosBancarios domiciliosBancarios;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.TelefoneType[] telefonesEstabelecimento;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EnderecoType[] enderecosEstabelecimento;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DadosProprietarioType[] proprietarios;

    private java.lang.Long codigoAfiliador;

    private java.math.BigDecimal valorMedioFaturamento;

    private java.lang.String indicadorEstabComercialMigrado;

    private java.lang.String indicadorCadastroDuplicado;

    private java.util.Calendar dataAtivacao;

    private java.lang.Integer codigoTipoPlanoCielo;

    private java.lang.Integer quantidadeDiasLiquidacao;

    /* 1 - A VISTA | 2 - A VISTA E PARCELADO */
    private java.lang.Integer codigoTipoModalidadePagamento;

    private java.math.BigDecimal taxaArv;

    public EstabelecimentoComercialType() {
    }

    public EstabelecimentoComercialType(
           java.lang.Long numeroCpfCnpj,
           java.lang.Long numeroEc,
           java.lang.String codigoTipoPessoa,
           java.lang.String nomeRazaoSocial,
           java.lang.String indicadorMicroEmpreendedorIndividual,
           java.lang.Long numeroInscricaoEstadual,
           java.lang.String nomeFantasia,
           java.lang.String nomePlaqueta,
           java.lang.String nomePessoaContato,
           java.lang.String emailContato,
           java.lang.Integer codigoRamoAtividade,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DomiciliosBancarios domiciliosBancarios,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.TelefoneType[] telefonesEstabelecimento,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EnderecoType[] enderecosEstabelecimento,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DadosProprietarioType[] proprietarios,
           java.lang.Long codigoAfiliador,
           java.math.BigDecimal valorMedioFaturamento,
           java.lang.String indicadorEstabComercialMigrado,
           java.lang.String indicadorCadastroDuplicado,
           java.util.Calendar dataAtivacao,
           java.lang.Integer codigoTipoPlanoCielo,
           java.lang.Integer quantidadeDiasLiquidacao,
           java.lang.Integer codigoTipoModalidadePagamento,
           java.math.BigDecimal taxaArv) {
           this.numeroCpfCnpj = numeroCpfCnpj;
           this.numeroEc = numeroEc;
           this.codigoTipoPessoa = codigoTipoPessoa;
           this.nomeRazaoSocial = nomeRazaoSocial;
           this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
           this.numeroInscricaoEstadual = numeroInscricaoEstadual;
           this.nomeFantasia = nomeFantasia;
           this.nomePlaqueta = nomePlaqueta;
           this.nomePessoaContato = nomePessoaContato;
           this.emailContato = emailContato;
           this.codigoRamoAtividade = codigoRamoAtividade;
           this.domiciliosBancarios = domiciliosBancarios;
           this.telefonesEstabelecimento = telefonesEstabelecimento;
           this.enderecosEstabelecimento = enderecosEstabelecimento;
           this.proprietarios = proprietarios;
           this.codigoAfiliador = codigoAfiliador;
           this.valorMedioFaturamento = valorMedioFaturamento;
           this.indicadorEstabComercialMigrado = indicadorEstabComercialMigrado;
           this.indicadorCadastroDuplicado = indicadorCadastroDuplicado;
           this.dataAtivacao = dataAtivacao;
           this.codigoTipoPlanoCielo = codigoTipoPlanoCielo;
           this.quantidadeDiasLiquidacao = quantidadeDiasLiquidacao;
           this.codigoTipoModalidadePagamento = codigoTipoModalidadePagamento;
           this.taxaArv = taxaArv;
    }


    /**
     * Gets the numeroCpfCnpj value for this EstabelecimentoComercialType.
     * 
     * @return numeroCpfCnpj
     */
    public java.lang.Long getNumeroCpfCnpj() {
        return numeroCpfCnpj;
    }


    /**
     * Sets the numeroCpfCnpj value for this EstabelecimentoComercialType.
     * 
     * @param numeroCpfCnpj
     */
    public void setNumeroCpfCnpj(java.lang.Long numeroCpfCnpj) {
        this.numeroCpfCnpj = numeroCpfCnpj;
    }


    /**
     * Gets the numeroEc value for this EstabelecimentoComercialType.
     * 
     * @return numeroEc
     */
    public java.lang.Long getNumeroEc() {
        return numeroEc;
    }


    /**
     * Sets the numeroEc value for this EstabelecimentoComercialType.
     * 
     * @param numeroEc
     */
    public void setNumeroEc(java.lang.Long numeroEc) {
        this.numeroEc = numeroEc;
    }


    /**
     * Gets the codigoTipoPessoa value for this EstabelecimentoComercialType.
     * 
     * @return codigoTipoPessoa   * Tipo que representa Código do Tipo da
     * 						Pessoa. F -
     * 						Física J - Jurídica
     */
    public java.lang.String getCodigoTipoPessoa() {
        return codigoTipoPessoa;
    }


    /**
     * Sets the codigoTipoPessoa value for this EstabelecimentoComercialType.
     * 
     * @param codigoTipoPessoa   * Tipo que representa Código do Tipo da
     * 						Pessoa. F -
     * 						Física J - Jurídica
     */
    public void setCodigoTipoPessoa(java.lang.String codigoTipoPessoa) {
        this.codigoTipoPessoa = codigoTipoPessoa;
    }


    /**
     * Gets the nomeRazaoSocial value for this EstabelecimentoComercialType.
     * 
     * @return nomeRazaoSocial
     */
    public java.lang.String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }


    /**
     * Sets the nomeRazaoSocial value for this EstabelecimentoComercialType.
     * 
     * @param nomeRazaoSocial
     */
    public void setNomeRazaoSocial(java.lang.String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }


    /**
     * Gets the indicadorMicroEmpreendedorIndividual value for this EstabelecimentoComercialType.
     * 
     * @return indicadorMicroEmpreendedorIndividual
     */
    public java.lang.String getIndicadorMicroEmpreendedorIndividual() {
        return indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Sets the indicadorMicroEmpreendedorIndividual value for this EstabelecimentoComercialType.
     * 
     * @param indicadorMicroEmpreendedorIndividual
     */
    public void setIndicadorMicroEmpreendedorIndividual(java.lang.String indicadorMicroEmpreendedorIndividual) {
        this.indicadorMicroEmpreendedorIndividual = indicadorMicroEmpreendedorIndividual;
    }


    /**
     * Gets the numeroInscricaoEstadual value for this EstabelecimentoComercialType.
     * 
     * @return numeroInscricaoEstadual
     */
    public java.lang.Long getNumeroInscricaoEstadual() {
        return numeroInscricaoEstadual;
    }


    /**
     * Sets the numeroInscricaoEstadual value for this EstabelecimentoComercialType.
     * 
     * @param numeroInscricaoEstadual
     */
    public void setNumeroInscricaoEstadual(java.lang.Long numeroInscricaoEstadual) {
        this.numeroInscricaoEstadual = numeroInscricaoEstadual;
    }


    /**
     * Gets the nomeFantasia value for this EstabelecimentoComercialType.
     * 
     * @return nomeFantasia
     */
    public java.lang.String getNomeFantasia() {
        return nomeFantasia;
    }


    /**
     * Sets the nomeFantasia value for this EstabelecimentoComercialType.
     * 
     * @param nomeFantasia
     */
    public void setNomeFantasia(java.lang.String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }


    /**
     * Gets the nomePlaqueta value for this EstabelecimentoComercialType.
     * 
     * @return nomePlaqueta
     */
    public java.lang.String getNomePlaqueta() {
        return nomePlaqueta;
    }


    /**
     * Sets the nomePlaqueta value for this EstabelecimentoComercialType.
     * 
     * @param nomePlaqueta
     */
    public void setNomePlaqueta(java.lang.String nomePlaqueta) {
        this.nomePlaqueta = nomePlaqueta;
    }


    /**
     * Gets the nomePessoaContato value for this EstabelecimentoComercialType.
     * 
     * @return nomePessoaContato
     */
    public java.lang.String getNomePessoaContato() {
        return nomePessoaContato;
    }


    /**
     * Sets the nomePessoaContato value for this EstabelecimentoComercialType.
     * 
     * @param nomePessoaContato
     */
    public void setNomePessoaContato(java.lang.String nomePessoaContato) {
        this.nomePessoaContato = nomePessoaContato;
    }


    /**
     * Gets the emailContato value for this EstabelecimentoComercialType.
     * 
     * @return emailContato
     */
    public java.lang.String getEmailContato() {
        return emailContato;
    }


    /**
     * Sets the emailContato value for this EstabelecimentoComercialType.
     * 
     * @param emailContato
     */
    public void setEmailContato(java.lang.String emailContato) {
        this.emailContato = emailContato;
    }


    /**
     * Gets the codigoRamoAtividade value for this EstabelecimentoComercialType.
     * 
     * @return codigoRamoAtividade
     */
    public java.lang.Integer getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this EstabelecimentoComercialType.
     * 
     * @param codigoRamoAtividade
     */
    public void setCodigoRamoAtividade(java.lang.Integer codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the domiciliosBancarios value for this EstabelecimentoComercialType.
     * 
     * @return domiciliosBancarios
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DomiciliosBancarios getDomiciliosBancarios() {
        return domiciliosBancarios;
    }


    /**
     * Sets the domiciliosBancarios value for this EstabelecimentoComercialType.
     * 
     * @param domiciliosBancarios
     */
    public void setDomiciliosBancarios(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DomiciliosBancarios domiciliosBancarios) {
        this.domiciliosBancarios = domiciliosBancarios;
    }


    /**
     * Gets the telefonesEstabelecimento value for this EstabelecimentoComercialType.
     * 
     * @return telefonesEstabelecimento
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.TelefoneType[] getTelefonesEstabelecimento() {
        return telefonesEstabelecimento;
    }


    /**
     * Sets the telefonesEstabelecimento value for this EstabelecimentoComercialType.
     * 
     * @param telefonesEstabelecimento
     */
    public void setTelefonesEstabelecimento(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.TelefoneType[] telefonesEstabelecimento) {
        this.telefonesEstabelecimento = telefonesEstabelecimento;
    }


    /**
     * Gets the enderecosEstabelecimento value for this EstabelecimentoComercialType.
     * 
     * @return enderecosEstabelecimento
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EnderecoType[] getEnderecosEstabelecimento() {
        return enderecosEstabelecimento;
    }


    /**
     * Sets the enderecosEstabelecimento value for this EstabelecimentoComercialType.
     * 
     * @param enderecosEstabelecimento
     */
    public void setEnderecosEstabelecimento(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EnderecoType[] enderecosEstabelecimento) {
        this.enderecosEstabelecimento = enderecosEstabelecimento;
    }


    /**
     * Gets the proprietarios value for this EstabelecimentoComercialType.
     * 
     * @return proprietarios
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DadosProprietarioType[] getProprietarios() {
        return proprietarios;
    }


    /**
     * Sets the proprietarios value for this EstabelecimentoComercialType.
     * 
     * @param proprietarios
     */
    public void setProprietarios(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DadosProprietarioType[] proprietarios) {
        this.proprietarios = proprietarios;
    }


    /**
     * Gets the codigoAfiliador value for this EstabelecimentoComercialType.
     * 
     * @return codigoAfiliador
     */
    public java.lang.Long getCodigoAfiliador() {
        return codigoAfiliador;
    }


    /**
     * Sets the codigoAfiliador value for this EstabelecimentoComercialType.
     * 
     * @param codigoAfiliador
     */
    public void setCodigoAfiliador(java.lang.Long codigoAfiliador) {
        this.codigoAfiliador = codigoAfiliador;
    }


    /**
     * Gets the valorMedioFaturamento value for this EstabelecimentoComercialType.
     * 
     * @return valorMedioFaturamento
     */
    public java.math.BigDecimal getValorMedioFaturamento() {
        return valorMedioFaturamento;
    }


    /**
     * Sets the valorMedioFaturamento value for this EstabelecimentoComercialType.
     * 
     * @param valorMedioFaturamento
     */
    public void setValorMedioFaturamento(java.math.BigDecimal valorMedioFaturamento) {
        this.valorMedioFaturamento = valorMedioFaturamento;
    }


    /**
     * Gets the indicadorEstabComercialMigrado value for this EstabelecimentoComercialType.
     * 
     * @return indicadorEstabComercialMigrado
     */
    public java.lang.String getIndicadorEstabComercialMigrado() {
        return indicadorEstabComercialMigrado;
    }


    /**
     * Sets the indicadorEstabComercialMigrado value for this EstabelecimentoComercialType.
     * 
     * @param indicadorEstabComercialMigrado
     */
    public void setIndicadorEstabComercialMigrado(java.lang.String indicadorEstabComercialMigrado) {
        this.indicadorEstabComercialMigrado = indicadorEstabComercialMigrado;
    }


    /**
     * Gets the indicadorCadastroDuplicado value for this EstabelecimentoComercialType.
     * 
     * @return indicadorCadastroDuplicado
     */
    public java.lang.String getIndicadorCadastroDuplicado() {
        return indicadorCadastroDuplicado;
    }


    /**
     * Sets the indicadorCadastroDuplicado value for this EstabelecimentoComercialType.
     * 
     * @param indicadorCadastroDuplicado
     */
    public void setIndicadorCadastroDuplicado(java.lang.String indicadorCadastroDuplicado) {
        this.indicadorCadastroDuplicado = indicadorCadastroDuplicado;
    }


    /**
     * Gets the dataAtivacao value for this EstabelecimentoComercialType.
     * 
     * @return dataAtivacao
     */
    public java.util.Calendar getDataAtivacao() {
        return dataAtivacao;
    }


    /**
     * Sets the dataAtivacao value for this EstabelecimentoComercialType.
     * 
     * @param dataAtivacao
     */
    public void setDataAtivacao(java.util.Calendar dataAtivacao) {
        this.dataAtivacao = dataAtivacao;
    }


    /**
     * Gets the codigoTipoPlanoCielo value for this EstabelecimentoComercialType.
     * 
     * @return codigoTipoPlanoCielo
     */
    public java.lang.Integer getCodigoTipoPlanoCielo() {
        return codigoTipoPlanoCielo;
    }


    /**
     * Sets the codigoTipoPlanoCielo value for this EstabelecimentoComercialType.
     * 
     * @param codigoTipoPlanoCielo
     */
    public void setCodigoTipoPlanoCielo(java.lang.Integer codigoTipoPlanoCielo) {
        this.codigoTipoPlanoCielo = codigoTipoPlanoCielo;
    }


    /**
     * Gets the quantidadeDiasLiquidacao value for this EstabelecimentoComercialType.
     * 
     * @return quantidadeDiasLiquidacao
     */
    public java.lang.Integer getQuantidadeDiasLiquidacao() {
        return quantidadeDiasLiquidacao;
    }


    /**
     * Sets the quantidadeDiasLiquidacao value for this EstabelecimentoComercialType.
     * 
     * @param quantidadeDiasLiquidacao
     */
    public void setQuantidadeDiasLiquidacao(java.lang.Integer quantidadeDiasLiquidacao) {
        this.quantidadeDiasLiquidacao = quantidadeDiasLiquidacao;
    }


    /**
     * Gets the codigoTipoModalidadePagamento value for this EstabelecimentoComercialType.
     * 
     * @return codigoTipoModalidadePagamento   * 1 - A VISTA | 2 - A VISTA E PARCELADO
     */
    public java.lang.Integer getCodigoTipoModalidadePagamento() {
        return codigoTipoModalidadePagamento;
    }


    /**
     * Sets the codigoTipoModalidadePagamento value for this EstabelecimentoComercialType.
     * 
     * @param codigoTipoModalidadePagamento   * 1 - A VISTA | 2 - A VISTA E PARCELADO
     */
    public void setCodigoTipoModalidadePagamento(java.lang.Integer codigoTipoModalidadePagamento) {
        this.codigoTipoModalidadePagamento = codigoTipoModalidadePagamento;
    }


    /**
     * Gets the taxaArv value for this EstabelecimentoComercialType.
     * 
     * @return taxaArv
     */
    public java.math.BigDecimal getTaxaArv() {
        return taxaArv;
    }


    /**
     * Sets the taxaArv value for this EstabelecimentoComercialType.
     * 
     * @param taxaArv
     */
    public void setTaxaArv(java.math.BigDecimal taxaArv) {
        this.taxaArv = taxaArv;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EstabelecimentoComercialType)) return false;
        EstabelecimentoComercialType other = (EstabelecimentoComercialType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroCpfCnpj==null && other.getNumeroCpfCnpj()==null) || 
             (this.numeroCpfCnpj!=null &&
              this.numeroCpfCnpj.equals(other.getNumeroCpfCnpj()))) &&
            ((this.numeroEc==null && other.getNumeroEc()==null) || 
             (this.numeroEc!=null &&
              this.numeroEc.equals(other.getNumeroEc()))) &&
            ((this.codigoTipoPessoa==null && other.getCodigoTipoPessoa()==null) || 
             (this.codigoTipoPessoa!=null &&
              this.codigoTipoPessoa.equals(other.getCodigoTipoPessoa()))) &&
            ((this.nomeRazaoSocial==null && other.getNomeRazaoSocial()==null) || 
             (this.nomeRazaoSocial!=null &&
              this.nomeRazaoSocial.equals(other.getNomeRazaoSocial()))) &&
            ((this.indicadorMicroEmpreendedorIndividual==null && other.getIndicadorMicroEmpreendedorIndividual()==null) || 
             (this.indicadorMicroEmpreendedorIndividual!=null &&
              this.indicadorMicroEmpreendedorIndividual.equals(other.getIndicadorMicroEmpreendedorIndividual()))) &&
            ((this.numeroInscricaoEstadual==null && other.getNumeroInscricaoEstadual()==null) || 
             (this.numeroInscricaoEstadual!=null &&
              this.numeroInscricaoEstadual.equals(other.getNumeroInscricaoEstadual()))) &&
            ((this.nomeFantasia==null && other.getNomeFantasia()==null) || 
             (this.nomeFantasia!=null &&
              this.nomeFantasia.equals(other.getNomeFantasia()))) &&
            ((this.nomePlaqueta==null && other.getNomePlaqueta()==null) || 
             (this.nomePlaqueta!=null &&
              this.nomePlaqueta.equals(other.getNomePlaqueta()))) &&
            ((this.nomePessoaContato==null && other.getNomePessoaContato()==null) || 
             (this.nomePessoaContato!=null &&
              this.nomePessoaContato.equals(other.getNomePessoaContato()))) &&
            ((this.emailContato==null && other.getEmailContato()==null) || 
             (this.emailContato!=null &&
              this.emailContato.equals(other.getEmailContato()))) &&
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade()))) &&
            ((this.domiciliosBancarios==null && other.getDomiciliosBancarios()==null) || 
             (this.domiciliosBancarios!=null &&
              this.domiciliosBancarios.equals(other.getDomiciliosBancarios()))) &&
            ((this.telefonesEstabelecimento==null && other.getTelefonesEstabelecimento()==null) || 
             (this.telefonesEstabelecimento!=null &&
              java.util.Arrays.equals(this.telefonesEstabelecimento, other.getTelefonesEstabelecimento()))) &&
            ((this.enderecosEstabelecimento==null && other.getEnderecosEstabelecimento()==null) || 
             (this.enderecosEstabelecimento!=null &&
              java.util.Arrays.equals(this.enderecosEstabelecimento, other.getEnderecosEstabelecimento()))) &&
            ((this.proprietarios==null && other.getProprietarios()==null) || 
             (this.proprietarios!=null &&
              java.util.Arrays.equals(this.proprietarios, other.getProprietarios()))) &&
            ((this.codigoAfiliador==null && other.getCodigoAfiliador()==null) || 
             (this.codigoAfiliador!=null &&
              this.codigoAfiliador.equals(other.getCodigoAfiliador()))) &&
            ((this.valorMedioFaturamento==null && other.getValorMedioFaturamento()==null) || 
             (this.valorMedioFaturamento!=null &&
              this.valorMedioFaturamento.equals(other.getValorMedioFaturamento()))) &&
            ((this.indicadorEstabComercialMigrado==null && other.getIndicadorEstabComercialMigrado()==null) || 
             (this.indicadorEstabComercialMigrado!=null &&
              this.indicadorEstabComercialMigrado.equals(other.getIndicadorEstabComercialMigrado()))) &&
            ((this.indicadorCadastroDuplicado==null && other.getIndicadorCadastroDuplicado()==null) || 
             (this.indicadorCadastroDuplicado!=null &&
              this.indicadorCadastroDuplicado.equals(other.getIndicadorCadastroDuplicado()))) &&
            ((this.dataAtivacao==null && other.getDataAtivacao()==null) || 
             (this.dataAtivacao!=null &&
              this.dataAtivacao.equals(other.getDataAtivacao()))) &&
            ((this.codigoTipoPlanoCielo==null && other.getCodigoTipoPlanoCielo()==null) || 
             (this.codigoTipoPlanoCielo!=null &&
              this.codigoTipoPlanoCielo.equals(other.getCodigoTipoPlanoCielo()))) &&
            ((this.quantidadeDiasLiquidacao==null && other.getQuantidadeDiasLiquidacao()==null) || 
             (this.quantidadeDiasLiquidacao!=null &&
              this.quantidadeDiasLiquidacao.equals(other.getQuantidadeDiasLiquidacao()))) &&
            ((this.codigoTipoModalidadePagamento==null && other.getCodigoTipoModalidadePagamento()==null) || 
             (this.codigoTipoModalidadePagamento!=null &&
              this.codigoTipoModalidadePagamento.equals(other.getCodigoTipoModalidadePagamento()))) &&
            ((this.taxaArv==null && other.getTaxaArv()==null) || 
             (this.taxaArv!=null &&
              this.taxaArv.equals(other.getTaxaArv())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroCpfCnpj() != null) {
            _hashCode += getNumeroCpfCnpj().hashCode();
        }
        if (getNumeroEc() != null) {
            _hashCode += getNumeroEc().hashCode();
        }
        if (getCodigoTipoPessoa() != null) {
            _hashCode += getCodigoTipoPessoa().hashCode();
        }
        if (getNomeRazaoSocial() != null) {
            _hashCode += getNomeRazaoSocial().hashCode();
        }
        if (getIndicadorMicroEmpreendedorIndividual() != null) {
            _hashCode += getIndicadorMicroEmpreendedorIndividual().hashCode();
        }
        if (getNumeroInscricaoEstadual() != null) {
            _hashCode += getNumeroInscricaoEstadual().hashCode();
        }
        if (getNomeFantasia() != null) {
            _hashCode += getNomeFantasia().hashCode();
        }
        if (getNomePlaqueta() != null) {
            _hashCode += getNomePlaqueta().hashCode();
        }
        if (getNomePessoaContato() != null) {
            _hashCode += getNomePessoaContato().hashCode();
        }
        if (getEmailContato() != null) {
            _hashCode += getEmailContato().hashCode();
        }
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        if (getDomiciliosBancarios() != null) {
            _hashCode += getDomiciliosBancarios().hashCode();
        }
        if (getTelefonesEstabelecimento() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTelefonesEstabelecimento());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTelefonesEstabelecimento(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEnderecosEstabelecimento() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEnderecosEstabelecimento());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEnderecosEstabelecimento(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProprietarios() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProprietarios());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProprietarios(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodigoAfiliador() != null) {
            _hashCode += getCodigoAfiliador().hashCode();
        }
        if (getValorMedioFaturamento() != null) {
            _hashCode += getValorMedioFaturamento().hashCode();
        }
        if (getIndicadorEstabComercialMigrado() != null) {
            _hashCode += getIndicadorEstabComercialMigrado().hashCode();
        }
        if (getIndicadorCadastroDuplicado() != null) {
            _hashCode += getIndicadorCadastroDuplicado().hashCode();
        }
        if (getDataAtivacao() != null) {
            _hashCode += getDataAtivacao().hashCode();
        }
        if (getCodigoTipoPlanoCielo() != null) {
            _hashCode += getCodigoTipoPlanoCielo().hashCode();
        }
        if (getQuantidadeDiasLiquidacao() != null) {
            _hashCode += getQuantidadeDiasLiquidacao().hashCode();
        }
        if (getCodigoTipoModalidadePagamento() != null) {
            _hashCode += getCodigoTipoModalidadePagamento().hashCode();
        }
        if (getTaxaArv() != null) {
            _hashCode += getTaxaArv().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EstabelecimentoComercialType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "estabelecimentoComercialType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCpfCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "numeroCpfCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "numeroEc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoTipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeRazaoSocial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomeRazaoSocial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMicroEmpreendedorIndividual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "indicadorMicroEmpreendedorIndividual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroInscricaoEstadual");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "numeroInscricaoEstadual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFantasia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomeFantasia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePlaqueta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomePlaqueta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePessoaContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomePessoaContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("emailContato");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "emailContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domiciliosBancarios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "domiciliosBancarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "domiciliosBancarios"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telefonesEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "telefonesEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "telefoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "telefone"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enderecosEstabelecimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "enderecosEstabelecimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "enderecoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "endereco"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("proprietarios");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "proprietarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "dadosProprietarioType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "proprietario"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoAfiliador");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoAfiliador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorMedioFaturamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "valorMedioFaturamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorEstabComercialMigrado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "indicadorEstabComercialMigrado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorCadastroDuplicado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "indicadorCadastroDuplicado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataAtivacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "dataAtivacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPlanoCielo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoTipoPlanoCielo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeDiasLiquidacao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "quantidadeDiasLiquidacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoModalidadePagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoTipoModalidadePagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaArv");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "taxaArv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
