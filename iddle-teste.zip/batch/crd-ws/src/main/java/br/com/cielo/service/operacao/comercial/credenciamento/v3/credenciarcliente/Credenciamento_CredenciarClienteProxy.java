package br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente;

public class Credenciamento_CredenciarClienteProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarCliente {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarCliente credenciamento_CredenciarCliente = null;
  
  public Credenciamento_CredenciarClienteProxy() {
    _initCredenciamento_CredenciarClienteProxy();
  }
  
  public Credenciamento_CredenciarClienteProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamento_CredenciarClienteProxy();
  }
  
  private void _initCredenciamento_CredenciarClienteProxy() {
    try {
      credenciamento_CredenciarCliente = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarClienteServiceLocator()).getCredenciamento_CredenciarClienteServiceSoapPort();
      if (credenciamento_CredenciarCliente != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamento_CredenciarCliente)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamento_CredenciarCliente)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamento_CredenciarCliente != null)
      ((javax.xml.rpc.Stub)credenciamento_CredenciarCliente)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarCliente getCredenciamento_CredenciarCliente() {
    if (credenciamento_CredenciarCliente == null)
      _initCredenciamento_CredenciarClienteProxy();
    return credenciamento_CredenciarCliente;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse credenciarCliente(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamento_CredenciarCliente == null)
      _initCredenciamento_CredenciarClienteProxy();
    return credenciamento_CredenciarCliente.credenciarCliente(parameters, header);
  }
  
  
}