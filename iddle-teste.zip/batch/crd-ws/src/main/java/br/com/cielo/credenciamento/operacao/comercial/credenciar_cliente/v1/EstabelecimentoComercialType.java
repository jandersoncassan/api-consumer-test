/**
 * EstabelecimentoComercialType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class EstabelecimentoComercialType  implements java.io.Serializable {
    private java.lang.Long numeroCpfCnpj;

    private java.lang.String tipoPessoa;

    private java.lang.Long numeroEc;

    private java.lang.String nomeRazaoSocial;

    private java.lang.String indicadorMei;

    private java.lang.Long numeroInscricaoEstadual;

    private java.lang.String nomeFantasia;

    private java.lang.String nomePlaqueta;

    private java.lang.String nomePessoaContato;

    private java.lang.String email;

    private java.lang.Integer codigoRamoAtividade;

    private java.math.BigDecimal valorFatMedioMensal;

    private java.lang.Long codigoAfiliador;

    private java.lang.String indEstabComercialMigrado;

    private java.lang.String indCadastroDuplicado;

    private java.util.Calendar dataAtivacaoEstabComercial;

    private java.lang.Integer codigoTipoPlanoCielo;

    private java.lang.Integer quantidadeDiasLiquidacao;

    private java.lang.Integer codigoTipoModalidadePagamento;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DomicilioBancarioType[] domiciliosBancarios;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.TelefoneType[] telefones;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EnderecoType[] enderecos;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DadosProprietarioType[] proprietarios;

    private java.math.BigDecimal taxaArv;

    private java.lang.String indicadorOfertaAssociada;

    private java.lang.String indicadorAceiteOferta;

    private java.lang.String nivelOferta;

    private java.lang.String codigoOferta;

    public EstabelecimentoComercialType() {
    }

    public EstabelecimentoComercialType(
           java.lang.Long numeroCpfCnpj,
           java.lang.String tipoPessoa,
           java.lang.Long numeroEc,
           java.lang.String nomeRazaoSocial,
           java.lang.String indicadorMei,
           java.lang.Long numeroInscricaoEstadual,
           java.lang.String nomeFantasia,
           java.lang.String nomePlaqueta,
           java.lang.String nomePessoaContato,
           java.lang.String email,
           java.lang.Integer codigoRamoAtividade,
           java.math.BigDecimal valorFatMedioMensal,
           java.lang.Long codigoAfiliador,
           java.lang.String indEstabComercialMigrado,
           java.lang.String indCadastroDuplicado,
           java.util.Calendar dataAtivacaoEstabComercial,
           java.lang.Integer codigoTipoPlanoCielo,
           java.lang.Integer quantidadeDiasLiquidacao,
           java.lang.Integer codigoTipoModalidadePagamento,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DomicilioBancarioType[] domiciliosBancarios,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.TelefoneType[] telefones,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EnderecoType[] enderecos,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DadosProprietarioType[] proprietarios,
           java.math.BigDecimal taxaArv,
           java.lang.String indicadorOfertaAssociada,
           java.lang.String indicadorAceiteOferta,
           java.lang.String nivelOferta,
           java.lang.String codigoOferta) {
           this.numeroCpfCnpj = numeroCpfCnpj;
           this.tipoPessoa = tipoPessoa;
           this.numeroEc = numeroEc;
           this.nomeRazaoSocial = nomeRazaoSocial;
           this.indicadorMei = indicadorMei;
           this.numeroInscricaoEstadual = numeroInscricaoEstadual;
           this.nomeFantasia = nomeFantasia;
           this.nomePlaqueta = nomePlaqueta;
           this.nomePessoaContato = nomePessoaContato;
           this.email = email;
           this.codigoRamoAtividade = codigoRamoAtividade;
           this.valorFatMedioMensal = valorFatMedioMensal;
           this.codigoAfiliador = codigoAfiliador;
           this.indEstabComercialMigrado = indEstabComercialMigrado;
           this.indCadastroDuplicado = indCadastroDuplicado;
           this.dataAtivacaoEstabComercial = dataAtivacaoEstabComercial;
           this.codigoTipoPlanoCielo = codigoTipoPlanoCielo;
           this.quantidadeDiasLiquidacao = quantidadeDiasLiquidacao;
           this.codigoTipoModalidadePagamento = codigoTipoModalidadePagamento;
           this.domiciliosBancarios = domiciliosBancarios;
           this.telefones = telefones;
           this.enderecos = enderecos;
           this.proprietarios = proprietarios;
           this.taxaArv = taxaArv;
           this.indicadorOfertaAssociada = indicadorOfertaAssociada;
           this.indicadorAceiteOferta = indicadorAceiteOferta;
           this.nivelOferta = nivelOferta;
           this.codigoOferta = codigoOferta;
    }


    /**
     * Gets the numeroCpfCnpj value for this EstabelecimentoComercialType.
     * 
     * @return numeroCpfCnpj
     */
    public java.lang.Long getNumeroCpfCnpj() {
        return numeroCpfCnpj;
    }


    /**
     * Sets the numeroCpfCnpj value for this EstabelecimentoComercialType.
     * 
     * @param numeroCpfCnpj
     */
    public void setNumeroCpfCnpj(java.lang.Long numeroCpfCnpj) {
        this.numeroCpfCnpj = numeroCpfCnpj;
    }


    /**
     * Gets the tipoPessoa value for this EstabelecimentoComercialType.
     * 
     * @return tipoPessoa
     */
    public java.lang.String getTipoPessoa() {
        return tipoPessoa;
    }


    /**
     * Sets the tipoPessoa value for this EstabelecimentoComercialType.
     * 
     * @param tipoPessoa
     */
    public void setTipoPessoa(java.lang.String tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }


    /**
     * Gets the numeroEc value for this EstabelecimentoComercialType.
     * 
     * @return numeroEc
     */
    public java.lang.Long getNumeroEc() {
        return numeroEc;
    }


    /**
     * Sets the numeroEc value for this EstabelecimentoComercialType.
     * 
     * @param numeroEc
     */
    public void setNumeroEc(java.lang.Long numeroEc) {
        this.numeroEc = numeroEc;
    }


    /**
     * Gets the nomeRazaoSocial value for this EstabelecimentoComercialType.
     * 
     * @return nomeRazaoSocial
     */
    public java.lang.String getNomeRazaoSocial() {
        return nomeRazaoSocial;
    }


    /**
     * Sets the nomeRazaoSocial value for this EstabelecimentoComercialType.
     * 
     * @param nomeRazaoSocial
     */
    public void setNomeRazaoSocial(java.lang.String nomeRazaoSocial) {
        this.nomeRazaoSocial = nomeRazaoSocial;
    }


    /**
     * Gets the indicadorMei value for this EstabelecimentoComercialType.
     * 
     * @return indicadorMei
     */
    public java.lang.String getIndicadorMei() {
        return indicadorMei;
    }


    /**
     * Sets the indicadorMei value for this EstabelecimentoComercialType.
     * 
     * @param indicadorMei
     */
    public void setIndicadorMei(java.lang.String indicadorMei) {
        this.indicadorMei = indicadorMei;
    }


    /**
     * Gets the numeroInscricaoEstadual value for this EstabelecimentoComercialType.
     * 
     * @return numeroInscricaoEstadual
     */
    public java.lang.Long getNumeroInscricaoEstadual() {
        return numeroInscricaoEstadual;
    }


    /**
     * Sets the numeroInscricaoEstadual value for this EstabelecimentoComercialType.
     * 
     * @param numeroInscricaoEstadual
     */
    public void setNumeroInscricaoEstadual(java.lang.Long numeroInscricaoEstadual) {
        this.numeroInscricaoEstadual = numeroInscricaoEstadual;
    }


    /**
     * Gets the nomeFantasia value for this EstabelecimentoComercialType.
     * 
     * @return nomeFantasia
     */
    public java.lang.String getNomeFantasia() {
        return nomeFantasia;
    }


    /**
     * Sets the nomeFantasia value for this EstabelecimentoComercialType.
     * 
     * @param nomeFantasia
     */
    public void setNomeFantasia(java.lang.String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }


    /**
     * Gets the nomePlaqueta value for this EstabelecimentoComercialType.
     * 
     * @return nomePlaqueta
     */
    public java.lang.String getNomePlaqueta() {
        return nomePlaqueta;
    }


    /**
     * Sets the nomePlaqueta value for this EstabelecimentoComercialType.
     * 
     * @param nomePlaqueta
     */
    public void setNomePlaqueta(java.lang.String nomePlaqueta) {
        this.nomePlaqueta = nomePlaqueta;
    }


    /**
     * Gets the nomePessoaContato value for this EstabelecimentoComercialType.
     * 
     * @return nomePessoaContato
     */
    public java.lang.String getNomePessoaContato() {
        return nomePessoaContato;
    }


    /**
     * Sets the nomePessoaContato value for this EstabelecimentoComercialType.
     * 
     * @param nomePessoaContato
     */
    public void setNomePessoaContato(java.lang.String nomePessoaContato) {
        this.nomePessoaContato = nomePessoaContato;
    }


    /**
     * Gets the email value for this EstabelecimentoComercialType.
     * 
     * @return email
     */
    public java.lang.String getEmail() {
        return email;
    }


    /**
     * Sets the email value for this EstabelecimentoComercialType.
     * 
     * @param email
     */
    public void setEmail(java.lang.String email) {
        this.email = email;
    }


    /**
     * Gets the codigoRamoAtividade value for this EstabelecimentoComercialType.
     * 
     * @return codigoRamoAtividade
     */
    public java.lang.Integer getCodigoRamoAtividade() {
        return codigoRamoAtividade;
    }


    /**
     * Sets the codigoRamoAtividade value for this EstabelecimentoComercialType.
     * 
     * @param codigoRamoAtividade
     */
    public void setCodigoRamoAtividade(java.lang.Integer codigoRamoAtividade) {
        this.codigoRamoAtividade = codigoRamoAtividade;
    }


    /**
     * Gets the valorFatMedioMensal value for this EstabelecimentoComercialType.
     * 
     * @return valorFatMedioMensal
     */
    public java.math.BigDecimal getValorFatMedioMensal() {
        return valorFatMedioMensal;
    }


    /**
     * Sets the valorFatMedioMensal value for this EstabelecimentoComercialType.
     * 
     * @param valorFatMedioMensal
     */
    public void setValorFatMedioMensal(java.math.BigDecimal valorFatMedioMensal) {
        this.valorFatMedioMensal = valorFatMedioMensal;
    }


    /**
     * Gets the codigoAfiliador value for this EstabelecimentoComercialType.
     * 
     * @return codigoAfiliador
     */
    public java.lang.Long getCodigoAfiliador() {
        return codigoAfiliador;
    }


    /**
     * Sets the codigoAfiliador value for this EstabelecimentoComercialType.
     * 
     * @param codigoAfiliador
     */
    public void setCodigoAfiliador(java.lang.Long codigoAfiliador) {
        this.codigoAfiliador = codigoAfiliador;
    }


    /**
     * Gets the indEstabComercialMigrado value for this EstabelecimentoComercialType.
     * 
     * @return indEstabComercialMigrado
     */
    public java.lang.String getIndEstabComercialMigrado() {
        return indEstabComercialMigrado;
    }


    /**
     * Sets the indEstabComercialMigrado value for this EstabelecimentoComercialType.
     * 
     * @param indEstabComercialMigrado
     */
    public void setIndEstabComercialMigrado(java.lang.String indEstabComercialMigrado) {
        this.indEstabComercialMigrado = indEstabComercialMigrado;
    }


    /**
     * Gets the indCadastroDuplicado value for this EstabelecimentoComercialType.
     * 
     * @return indCadastroDuplicado
     */
    public java.lang.String getIndCadastroDuplicado() {
        return indCadastroDuplicado;
    }


    /**
     * Sets the indCadastroDuplicado value for this EstabelecimentoComercialType.
     * 
     * @param indCadastroDuplicado
     */
    public void setIndCadastroDuplicado(java.lang.String indCadastroDuplicado) {
        this.indCadastroDuplicado = indCadastroDuplicado;
    }


    /**
     * Gets the dataAtivacaoEstabComercial value for this EstabelecimentoComercialType.
     * 
     * @return dataAtivacaoEstabComercial
     */
    public java.util.Calendar getDataAtivacaoEstabComercial() {
        return dataAtivacaoEstabComercial;
    }


    /**
     * Sets the dataAtivacaoEstabComercial value for this EstabelecimentoComercialType.
     * 
     * @param dataAtivacaoEstabComercial
     */
    public void setDataAtivacaoEstabComercial(java.util.Calendar dataAtivacaoEstabComercial) {
        this.dataAtivacaoEstabComercial = dataAtivacaoEstabComercial;
    }


    /**
     * Gets the codigoTipoPlanoCielo value for this EstabelecimentoComercialType.
     * 
     * @return codigoTipoPlanoCielo
     */
    public java.lang.Integer getCodigoTipoPlanoCielo() {
        return codigoTipoPlanoCielo;
    }


    /**
     * Sets the codigoTipoPlanoCielo value for this EstabelecimentoComercialType.
     * 
     * @param codigoTipoPlanoCielo
     */
    public void setCodigoTipoPlanoCielo(java.lang.Integer codigoTipoPlanoCielo) {
        this.codigoTipoPlanoCielo = codigoTipoPlanoCielo;
    }


    /**
     * Gets the quantidadeDiasLiquidacao value for this EstabelecimentoComercialType.
     * 
     * @return quantidadeDiasLiquidacao
     */
    public java.lang.Integer getQuantidadeDiasLiquidacao() {
        return quantidadeDiasLiquidacao;
    }


    /**
     * Sets the quantidadeDiasLiquidacao value for this EstabelecimentoComercialType.
     * 
     * @param quantidadeDiasLiquidacao
     */
    public void setQuantidadeDiasLiquidacao(java.lang.Integer quantidadeDiasLiquidacao) {
        this.quantidadeDiasLiquidacao = quantidadeDiasLiquidacao;
    }


    /**
     * Gets the codigoTipoModalidadePagamento value for this EstabelecimentoComercialType.
     * 
     * @return codigoTipoModalidadePagamento
     */
    public java.lang.Integer getCodigoTipoModalidadePagamento() {
        return codigoTipoModalidadePagamento;
    }


    /**
     * Sets the codigoTipoModalidadePagamento value for this EstabelecimentoComercialType.
     * 
     * @param codigoTipoModalidadePagamento
     */
    public void setCodigoTipoModalidadePagamento(java.lang.Integer codigoTipoModalidadePagamento) {
        this.codigoTipoModalidadePagamento = codigoTipoModalidadePagamento;
    }


    /**
     * Gets the domiciliosBancarios value for this EstabelecimentoComercialType.
     * 
     * @return domiciliosBancarios
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DomicilioBancarioType[] getDomiciliosBancarios() {
        return domiciliosBancarios;
    }


    /**
     * Sets the domiciliosBancarios value for this EstabelecimentoComercialType.
     * 
     * @param domiciliosBancarios
     */
    public void setDomiciliosBancarios(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DomicilioBancarioType[] domiciliosBancarios) {
        this.domiciliosBancarios = domiciliosBancarios;
    }


    /**
     * Gets the telefones value for this EstabelecimentoComercialType.
     * 
     * @return telefones
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.TelefoneType[] getTelefones() {
        return telefones;
    }


    /**
     * Sets the telefones value for this EstabelecimentoComercialType.
     * 
     * @param telefones
     */
    public void setTelefones(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.TelefoneType[] telefones) {
        this.telefones = telefones;
    }


    /**
     * Gets the enderecos value for this EstabelecimentoComercialType.
     * 
     * @return enderecos
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EnderecoType[] getEnderecos() {
        return enderecos;
    }


    /**
     * Sets the enderecos value for this EstabelecimentoComercialType.
     * 
     * @param enderecos
     */
    public void setEnderecos(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EnderecoType[] enderecos) {
        this.enderecos = enderecos;
    }


    /**
     * Gets the proprietarios value for this EstabelecimentoComercialType.
     * 
     * @return proprietarios
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DadosProprietarioType[] getProprietarios() {
        return proprietarios;
    }


    /**
     * Sets the proprietarios value for this EstabelecimentoComercialType.
     * 
     * @param proprietarios
     */
    public void setProprietarios(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.DadosProprietarioType[] proprietarios) {
        this.proprietarios = proprietarios;
    }


    /**
     * Gets the taxaArv value for this EstabelecimentoComercialType.
     * 
     * @return taxaArv
     */
    public java.math.BigDecimal getTaxaArv() {
        return taxaArv;
    }


    /**
     * Sets the taxaArv value for this EstabelecimentoComercialType.
     * 
     * @param taxaArv
     */
    public void setTaxaArv(java.math.BigDecimal taxaArv) {
        this.taxaArv = taxaArv;
    }


    /**
     * Gets the indicadorOfertaAssociada value for this EstabelecimentoComercialType.
     * 
     * @return indicadorOfertaAssociada
     */
    public java.lang.String getIndicadorOfertaAssociada() {
        return indicadorOfertaAssociada;
    }


    /**
     * Sets the indicadorOfertaAssociada value for this EstabelecimentoComercialType.
     * 
     * @param indicadorOfertaAssociada
     */
    public void setIndicadorOfertaAssociada(java.lang.String indicadorOfertaAssociada) {
        this.indicadorOfertaAssociada = indicadorOfertaAssociada;
    }


    /**
     * Gets the indicadorAceiteOferta value for this EstabelecimentoComercialType.
     * 
     * @return indicadorAceiteOferta
     */
    public java.lang.String getIndicadorAceiteOferta() {
        return indicadorAceiteOferta;
    }


    /**
     * Sets the indicadorAceiteOferta value for this EstabelecimentoComercialType.
     * 
     * @param indicadorAceiteOferta
     */
    public void setIndicadorAceiteOferta(java.lang.String indicadorAceiteOferta) {
        this.indicadorAceiteOferta = indicadorAceiteOferta;
    }


    /**
     * Gets the nivelOferta value for this EstabelecimentoComercialType.
     * 
     * @return nivelOferta
     */
    public java.lang.String getNivelOferta() {
        return nivelOferta;
    }


    /**
     * Sets the nivelOferta value for this EstabelecimentoComercialType.
     * 
     * @param nivelOferta
     */
    public void setNivelOferta(java.lang.String nivelOferta) {
        this.nivelOferta = nivelOferta;
    }


    /**
     * Gets the codigoOferta value for this EstabelecimentoComercialType.
     * 
     * @return codigoOferta
     */
    public java.lang.String getCodigoOferta() {
        return codigoOferta;
    }


    /**
     * Sets the codigoOferta value for this EstabelecimentoComercialType.
     * 
     * @param codigoOferta
     */
    public void setCodigoOferta(java.lang.String codigoOferta) {
        this.codigoOferta = codigoOferta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EstabelecimentoComercialType)) return false;
        EstabelecimentoComercialType other = (EstabelecimentoComercialType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroCpfCnpj==null && other.getNumeroCpfCnpj()==null) || 
             (this.numeroCpfCnpj!=null &&
              this.numeroCpfCnpj.equals(other.getNumeroCpfCnpj()))) &&
            ((this.tipoPessoa==null && other.getTipoPessoa()==null) || 
             (this.tipoPessoa!=null &&
              this.tipoPessoa.equals(other.getTipoPessoa()))) &&
            ((this.numeroEc==null && other.getNumeroEc()==null) || 
             (this.numeroEc!=null &&
              this.numeroEc.equals(other.getNumeroEc()))) &&
            ((this.nomeRazaoSocial==null && other.getNomeRazaoSocial()==null) || 
             (this.nomeRazaoSocial!=null &&
              this.nomeRazaoSocial.equals(other.getNomeRazaoSocial()))) &&
            ((this.indicadorMei==null && other.getIndicadorMei()==null) || 
             (this.indicadorMei!=null &&
              this.indicadorMei.equals(other.getIndicadorMei()))) &&
            ((this.numeroInscricaoEstadual==null && other.getNumeroInscricaoEstadual()==null) || 
             (this.numeroInscricaoEstadual!=null &&
              this.numeroInscricaoEstadual.equals(other.getNumeroInscricaoEstadual()))) &&
            ((this.nomeFantasia==null && other.getNomeFantasia()==null) || 
             (this.nomeFantasia!=null &&
              this.nomeFantasia.equals(other.getNomeFantasia()))) &&
            ((this.nomePlaqueta==null && other.getNomePlaqueta()==null) || 
             (this.nomePlaqueta!=null &&
              this.nomePlaqueta.equals(other.getNomePlaqueta()))) &&
            ((this.nomePessoaContato==null && other.getNomePessoaContato()==null) || 
             (this.nomePessoaContato!=null &&
              this.nomePessoaContato.equals(other.getNomePessoaContato()))) &&
            ((this.email==null && other.getEmail()==null) || 
             (this.email!=null &&
              this.email.equals(other.getEmail()))) &&
            ((this.codigoRamoAtividade==null && other.getCodigoRamoAtividade()==null) || 
             (this.codigoRamoAtividade!=null &&
              this.codigoRamoAtividade.equals(other.getCodigoRamoAtividade()))) &&
            ((this.valorFatMedioMensal==null && other.getValorFatMedioMensal()==null) || 
             (this.valorFatMedioMensal!=null &&
              this.valorFatMedioMensal.equals(other.getValorFatMedioMensal()))) &&
            ((this.codigoAfiliador==null && other.getCodigoAfiliador()==null) || 
             (this.codigoAfiliador!=null &&
              this.codigoAfiliador.equals(other.getCodigoAfiliador()))) &&
            ((this.indEstabComercialMigrado==null && other.getIndEstabComercialMigrado()==null) || 
             (this.indEstabComercialMigrado!=null &&
              this.indEstabComercialMigrado.equals(other.getIndEstabComercialMigrado()))) &&
            ((this.indCadastroDuplicado==null && other.getIndCadastroDuplicado()==null) || 
             (this.indCadastroDuplicado!=null &&
              this.indCadastroDuplicado.equals(other.getIndCadastroDuplicado()))) &&
            ((this.dataAtivacaoEstabComercial==null && other.getDataAtivacaoEstabComercial()==null) || 
             (this.dataAtivacaoEstabComercial!=null &&
              this.dataAtivacaoEstabComercial.equals(other.getDataAtivacaoEstabComercial()))) &&
            ((this.codigoTipoPlanoCielo==null && other.getCodigoTipoPlanoCielo()==null) || 
             (this.codigoTipoPlanoCielo!=null &&
              this.codigoTipoPlanoCielo.equals(other.getCodigoTipoPlanoCielo()))) &&
            ((this.quantidadeDiasLiquidacao==null && other.getQuantidadeDiasLiquidacao()==null) || 
             (this.quantidadeDiasLiquidacao!=null &&
              this.quantidadeDiasLiquidacao.equals(other.getQuantidadeDiasLiquidacao()))) &&
            ((this.codigoTipoModalidadePagamento==null && other.getCodigoTipoModalidadePagamento()==null) || 
             (this.codigoTipoModalidadePagamento!=null &&
              this.codigoTipoModalidadePagamento.equals(other.getCodigoTipoModalidadePagamento()))) &&
            ((this.domiciliosBancarios==null && other.getDomiciliosBancarios()==null) || 
             (this.domiciliosBancarios!=null &&
              java.util.Arrays.equals(this.domiciliosBancarios, other.getDomiciliosBancarios()))) &&
            ((this.telefones==null && other.getTelefones()==null) || 
             (this.telefones!=null &&
              java.util.Arrays.equals(this.telefones, other.getTelefones()))) &&
            ((this.enderecos==null && other.getEnderecos()==null) || 
             (this.enderecos!=null &&
              java.util.Arrays.equals(this.enderecos, other.getEnderecos()))) &&
            ((this.proprietarios==null && other.getProprietarios()==null) || 
             (this.proprietarios!=null &&
              java.util.Arrays.equals(this.proprietarios, other.getProprietarios()))) &&
            ((this.taxaArv==null && other.getTaxaArv()==null) || 
             (this.taxaArv!=null &&
              this.taxaArv.equals(other.getTaxaArv()))) &&
            ((this.indicadorOfertaAssociada==null && other.getIndicadorOfertaAssociada()==null) || 
             (this.indicadorOfertaAssociada!=null &&
              this.indicadorOfertaAssociada.equals(other.getIndicadorOfertaAssociada()))) &&
            ((this.indicadorAceiteOferta==null && other.getIndicadorAceiteOferta()==null) || 
             (this.indicadorAceiteOferta!=null &&
              this.indicadorAceiteOferta.equals(other.getIndicadorAceiteOferta()))) &&
            ((this.nivelOferta==null && other.getNivelOferta()==null) || 
             (this.nivelOferta!=null &&
              this.nivelOferta.equals(other.getNivelOferta()))) &&
            ((this.codigoOferta==null && other.getCodigoOferta()==null) || 
             (this.codigoOferta!=null &&
              this.codigoOferta.equals(other.getCodigoOferta())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroCpfCnpj() != null) {
            _hashCode += getNumeroCpfCnpj().hashCode();
        }
        if (getTipoPessoa() != null) {
            _hashCode += getTipoPessoa().hashCode();
        }
        if (getNumeroEc() != null) {
            _hashCode += getNumeroEc().hashCode();
        }
        if (getNomeRazaoSocial() != null) {
            _hashCode += getNomeRazaoSocial().hashCode();
        }
        if (getIndicadorMei() != null) {
            _hashCode += getIndicadorMei().hashCode();
        }
        if (getNumeroInscricaoEstadual() != null) {
            _hashCode += getNumeroInscricaoEstadual().hashCode();
        }
        if (getNomeFantasia() != null) {
            _hashCode += getNomeFantasia().hashCode();
        }
        if (getNomePlaqueta() != null) {
            _hashCode += getNomePlaqueta().hashCode();
        }
        if (getNomePessoaContato() != null) {
            _hashCode += getNomePessoaContato().hashCode();
        }
        if (getEmail() != null) {
            _hashCode += getEmail().hashCode();
        }
        if (getCodigoRamoAtividade() != null) {
            _hashCode += getCodigoRamoAtividade().hashCode();
        }
        if (getValorFatMedioMensal() != null) {
            _hashCode += getValorFatMedioMensal().hashCode();
        }
        if (getCodigoAfiliador() != null) {
            _hashCode += getCodigoAfiliador().hashCode();
        }
        if (getIndEstabComercialMigrado() != null) {
            _hashCode += getIndEstabComercialMigrado().hashCode();
        }
        if (getIndCadastroDuplicado() != null) {
            _hashCode += getIndCadastroDuplicado().hashCode();
        }
        if (getDataAtivacaoEstabComercial() != null) {
            _hashCode += getDataAtivacaoEstabComercial().hashCode();
        }
        if (getCodigoTipoPlanoCielo() != null) {
            _hashCode += getCodigoTipoPlanoCielo().hashCode();
        }
        if (getQuantidadeDiasLiquidacao() != null) {
            _hashCode += getQuantidadeDiasLiquidacao().hashCode();
        }
        if (getCodigoTipoModalidadePagamento() != null) {
            _hashCode += getCodigoTipoModalidadePagamento().hashCode();
        }
        if (getDomiciliosBancarios() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getDomiciliosBancarios());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getDomiciliosBancarios(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTelefones() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTelefones());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTelefones(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getEnderecos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEnderecos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEnderecos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getProprietarios() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getProprietarios());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getProprietarios(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getTaxaArv() != null) {
            _hashCode += getTaxaArv().hashCode();
        }
        if (getIndicadorOfertaAssociada() != null) {
            _hashCode += getIndicadorOfertaAssociada().hashCode();
        }
        if (getIndicadorAceiteOferta() != null) {
            _hashCode += getIndicadorAceiteOferta().hashCode();
        }
        if (getNivelOferta() != null) {
            _hashCode += getNivelOferta().hashCode();
        }
        if (getCodigoOferta() != null) {
            _hashCode += getCodigoOferta().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EstabelecimentoComercialType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "estabelecimentoComercialType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCpfCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroCpfCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "tipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEc");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroEc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeRazaoSocial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomeRazaoSocial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorMei");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indicadorMei"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroInscricaoEstadual");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroInscricaoEstadual"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeFantasia");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomeFantasia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePlaqueta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomePlaqueta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomePessoaContato");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomePessoaContato"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("email");
        elemField.setXmlName(new javax.xml.namespace.QName("", "email"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoRamoAtividade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoRamoAtividade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("valorFatMedioMensal");
        elemField.setXmlName(new javax.xml.namespace.QName("", "valorFatMedioMensal"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoAfiliador");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoAfiliador"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indEstabComercialMigrado");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indEstabComercialMigrado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indCadastroDuplicado");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indCadastroDuplicado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataAtivacaoEstabComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dataAtivacaoEstabComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "dateTime"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPlanoCielo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoTipoPlanoCielo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeDiasLiquidacao");
        elemField.setXmlName(new javax.xml.namespace.QName("", "quantidadeDiasLiquidacao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoModalidadePagamento");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoTipoModalidadePagamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("domiciliosBancarios");
        elemField.setXmlName(new javax.xml.namespace.QName("", "domiciliosBancarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "domicilioBancarioType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "domicilio"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telefones");
        elemField.setXmlName(new javax.xml.namespace.QName("", "telefones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "telefoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "telefone"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enderecos");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enderecos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "enderecoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "endereco"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("proprietarios");
        elemField.setXmlName(new javax.xml.namespace.QName("", "proprietarios"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "dadosProprietarioType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "proprietario"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaArv");
        elemField.setXmlName(new javax.xml.namespace.QName("", "taxaArv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorOfertaAssociada");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indicadorOfertaAssociada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAceiteOferta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indicadorAceiteOferta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nivelOferta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nivelOferta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoOferta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoOferta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
