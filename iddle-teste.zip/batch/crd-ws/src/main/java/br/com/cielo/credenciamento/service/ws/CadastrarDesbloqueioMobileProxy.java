package br.com.cielo.credenciamento.service.ws;

public class CadastrarDesbloqueioMobileProxy implements br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobile {
  private String _endpoint = null;
  private br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobile cadastrarDesbloqueioMobile = null;
  
  public CadastrarDesbloqueioMobileProxy() {
    _initCadastrarDesbloqueioMobileProxy();
  }
  
  public CadastrarDesbloqueioMobileProxy(String endpoint) {
    _endpoint = endpoint;
    _initCadastrarDesbloqueioMobileProxy();
  }
  
  private void _initCadastrarDesbloqueioMobileProxy() {
    try {
      cadastrarDesbloqueioMobile = (new br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobileServiceLocator()).getCadastrarDesbloqueioMobilePort();
      if (cadastrarDesbloqueioMobile != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)cadastrarDesbloqueioMobile)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)cadastrarDesbloqueioMobile)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (cadastrarDesbloqueioMobile != null)
      ((javax.xml.rpc.Stub)cadastrarDesbloqueioMobile)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.credenciamento.service.ws.CadastrarDesbloqueioMobile getCadastrarDesbloqueioMobile() {
    if (cadastrarDesbloqueioMobile == null)
      _initCadastrarDesbloqueioMobileProxy();
    return cadastrarDesbloqueioMobile;
  }
  
  public java.lang.Integer cadastrarDesbloqueioMobile(long numeroEstabelecimentoComercial, long numeroLogico, java.lang.String dataDesbloqueioMobile) throws java.rmi.RemoteException{
    if (cadastrarDesbloqueioMobile == null)
      _initCadastrarDesbloqueioMobileProxy();
    return cadastrarDesbloqueioMobile.cadastrarDesbloqueioMobile(numeroEstabelecimentoComercial, numeroLogico, dataDesbloqueioMobile);
  }
  
  
}