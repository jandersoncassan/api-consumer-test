/**
 * EnderecoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class EnderecoType  implements java.io.Serializable {
    private java.lang.Integer codigoTipoEndereco;

    private java.lang.String logradouro;

    private java.lang.String complemento;

    private java.lang.String numeroLogradouro;

    private java.lang.String cidade;

    private java.lang.String bairro;

    private java.lang.String siglaEstado;

    private java.lang.Integer numeroCep;

    public EnderecoType() {
    }

    public EnderecoType(
           java.lang.Integer codigoTipoEndereco,
           java.lang.String logradouro,
           java.lang.String complemento,
           java.lang.String numeroLogradouro,
           java.lang.String cidade,
           java.lang.String bairro,
           java.lang.String siglaEstado,
           java.lang.Integer numeroCep) {
           this.codigoTipoEndereco = codigoTipoEndereco;
           this.logradouro = logradouro;
           this.complemento = complemento;
           this.numeroLogradouro = numeroLogradouro;
           this.cidade = cidade;
           this.bairro = bairro;
           this.siglaEstado = siglaEstado;
           this.numeroCep = numeroCep;
    }


    /**
     * Gets the codigoTipoEndereco value for this EnderecoType.
     * 
     * @return codigoTipoEndereco
     */
    public java.lang.Integer getCodigoTipoEndereco() {
        return codigoTipoEndereco;
    }


    /**
     * Sets the codigoTipoEndereco value for this EnderecoType.
     * 
     * @param codigoTipoEndereco
     */
    public void setCodigoTipoEndereco(java.lang.Integer codigoTipoEndereco) {
        this.codigoTipoEndereco = codigoTipoEndereco;
    }


    /**
     * Gets the logradouro value for this EnderecoType.
     * 
     * @return logradouro
     */
    public java.lang.String getLogradouro() {
        return logradouro;
    }


    /**
     * Sets the logradouro value for this EnderecoType.
     * 
     * @param logradouro
     */
    public void setLogradouro(java.lang.String logradouro) {
        this.logradouro = logradouro;
    }


    /**
     * Gets the complemento value for this EnderecoType.
     * 
     * @return complemento
     */
    public java.lang.String getComplemento() {
        return complemento;
    }


    /**
     * Sets the complemento value for this EnderecoType.
     * 
     * @param complemento
     */
    public void setComplemento(java.lang.String complemento) {
        this.complemento = complemento;
    }


    /**
     * Gets the numeroLogradouro value for this EnderecoType.
     * 
     * @return numeroLogradouro
     */
    public java.lang.String getNumeroLogradouro() {
        return numeroLogradouro;
    }


    /**
     * Sets the numeroLogradouro value for this EnderecoType.
     * 
     * @param numeroLogradouro
     */
    public void setNumeroLogradouro(java.lang.String numeroLogradouro) {
        this.numeroLogradouro = numeroLogradouro;
    }


    /**
     * Gets the cidade value for this EnderecoType.
     * 
     * @return cidade
     */
    public java.lang.String getCidade() {
        return cidade;
    }


    /**
     * Sets the cidade value for this EnderecoType.
     * 
     * @param cidade
     */
    public void setCidade(java.lang.String cidade) {
        this.cidade = cidade;
    }


    /**
     * Gets the bairro value for this EnderecoType.
     * 
     * @return bairro
     */
    public java.lang.String getBairro() {
        return bairro;
    }


    /**
     * Sets the bairro value for this EnderecoType.
     * 
     * @param bairro
     */
    public void setBairro(java.lang.String bairro) {
        this.bairro = bairro;
    }


    /**
     * Gets the siglaEstado value for this EnderecoType.
     * 
     * @return siglaEstado
     */
    public java.lang.String getSiglaEstado() {
        return siglaEstado;
    }


    /**
     * Sets the siglaEstado value for this EnderecoType.
     * 
     * @param siglaEstado
     */
    public void setSiglaEstado(java.lang.String siglaEstado) {
        this.siglaEstado = siglaEstado;
    }


    /**
     * Gets the numeroCep value for this EnderecoType.
     * 
     * @return numeroCep
     */
    public java.lang.Integer getNumeroCep() {
        return numeroCep;
    }


    /**
     * Sets the numeroCep value for this EnderecoType.
     * 
     * @param numeroCep
     */
    public void setNumeroCep(java.lang.Integer numeroCep) {
        this.numeroCep = numeroCep;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EnderecoType)) return false;
        EnderecoType other = (EnderecoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTipoEndereco==null && other.getCodigoTipoEndereco()==null) || 
             (this.codigoTipoEndereco!=null &&
              this.codigoTipoEndereco.equals(other.getCodigoTipoEndereco()))) &&
            ((this.logradouro==null && other.getLogradouro()==null) || 
             (this.logradouro!=null &&
              this.logradouro.equals(other.getLogradouro()))) &&
            ((this.complemento==null && other.getComplemento()==null) || 
             (this.complemento!=null &&
              this.complemento.equals(other.getComplemento()))) &&
            ((this.numeroLogradouro==null && other.getNumeroLogradouro()==null) || 
             (this.numeroLogradouro!=null &&
              this.numeroLogradouro.equals(other.getNumeroLogradouro()))) &&
            ((this.cidade==null && other.getCidade()==null) || 
             (this.cidade!=null &&
              this.cidade.equals(other.getCidade()))) &&
            ((this.bairro==null && other.getBairro()==null) || 
             (this.bairro!=null &&
              this.bairro.equals(other.getBairro()))) &&
            ((this.siglaEstado==null && other.getSiglaEstado()==null) || 
             (this.siglaEstado!=null &&
              this.siglaEstado.equals(other.getSiglaEstado()))) &&
            ((this.numeroCep==null && other.getNumeroCep()==null) || 
             (this.numeroCep!=null &&
              this.numeroCep.equals(other.getNumeroCep())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTipoEndereco() != null) {
            _hashCode += getCodigoTipoEndereco().hashCode();
        }
        if (getLogradouro() != null) {
            _hashCode += getLogradouro().hashCode();
        }
        if (getComplemento() != null) {
            _hashCode += getComplemento().hashCode();
        }
        if (getNumeroLogradouro() != null) {
            _hashCode += getNumeroLogradouro().hashCode();
        }
        if (getCidade() != null) {
            _hashCode += getCidade().hashCode();
        }
        if (getBairro() != null) {
            _hashCode += getBairro().hashCode();
        }
        if (getSiglaEstado() != null) {
            _hashCode += getSiglaEstado().hashCode();
        }
        if (getNumeroCep() != null) {
            _hashCode += getNumeroCep().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EnderecoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "enderecoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoTipoEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("logradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("", "logradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("complemento");
        elemField.setXmlName(new javax.xml.namespace.QName("", "complemento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroLogradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cidade");
        elemField.setXmlName(new javax.xml.namespace.QName("", "cidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("bairro");
        elemField.setXmlName(new javax.xml.namespace.QName("", "bairro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("siglaEstado");
        elemField.setXmlName(new javax.xml.namespace.QName("", "siglaEstado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCep");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroCep"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
