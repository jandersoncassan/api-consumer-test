/**
 * TelefoneType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class TelefoneType  implements java.io.Serializable {
    private java.lang.Integer codigoTipoTelefone;

    private java.lang.Integer numeroDdd;

    private java.lang.String numeroTelefone;

    public TelefoneType() {
    }

    public TelefoneType(
           java.lang.Integer codigoTipoTelefone,
           java.lang.Integer numeroDdd,
           java.lang.String numeroTelefone) {
           this.codigoTipoTelefone = codigoTipoTelefone;
           this.numeroDdd = numeroDdd;
           this.numeroTelefone = numeroTelefone;
    }


    /**
     * Gets the codigoTipoTelefone value for this TelefoneType.
     * 
     * @return codigoTipoTelefone
     */
    public java.lang.Integer getCodigoTipoTelefone() {
        return codigoTipoTelefone;
    }


    /**
     * Sets the codigoTipoTelefone value for this TelefoneType.
     * 
     * @param codigoTipoTelefone
     */
    public void setCodigoTipoTelefone(java.lang.Integer codigoTipoTelefone) {
        this.codigoTipoTelefone = codigoTipoTelefone;
    }


    /**
     * Gets the numeroDdd value for this TelefoneType.
     * 
     * @return numeroDdd
     */
    public java.lang.Integer getNumeroDdd() {
        return numeroDdd;
    }


    /**
     * Sets the numeroDdd value for this TelefoneType.
     * 
     * @param numeroDdd
     */
    public void setNumeroDdd(java.lang.Integer numeroDdd) {
        this.numeroDdd = numeroDdd;
    }


    /**
     * Gets the numeroTelefone value for this TelefoneType.
     * 
     * @return numeroTelefone
     */
    public java.lang.String getNumeroTelefone() {
        return numeroTelefone;
    }


    /**
     * Sets the numeroTelefone value for this TelefoneType.
     * 
     * @param numeroTelefone
     */
    public void setNumeroTelefone(java.lang.String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TelefoneType)) return false;
        TelefoneType other = (TelefoneType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTipoTelefone==null && other.getCodigoTipoTelefone()==null) || 
             (this.codigoTipoTelefone!=null &&
              this.codigoTipoTelefone.equals(other.getCodigoTipoTelefone()))) &&
            ((this.numeroDdd==null && other.getNumeroDdd()==null) || 
             (this.numeroDdd!=null &&
              this.numeroDdd.equals(other.getNumeroDdd()))) &&
            ((this.numeroTelefone==null && other.getNumeroTelefone()==null) || 
             (this.numeroTelefone!=null &&
              this.numeroTelefone.equals(other.getNumeroTelefone())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTipoTelefone() != null) {
            _hashCode += getCodigoTipoTelefone().hashCode();
        }
        if (getNumeroDdd() != null) {
            _hashCode += getNumeroDdd().hashCode();
        }
        if (getNumeroTelefone() != null) {
            _hashCode += getNumeroTelefone().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TelefoneType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "telefoneType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoTipoTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDdd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroDdd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numeroTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
