/**
 * CadastrarDesbloqueioMobile.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.service.ws;

public interface CadastrarDesbloqueioMobile extends java.rmi.Remote {
    public java.lang.Integer cadastrarDesbloqueioMobile(long numeroEstabelecimentoComercial, long numeroLogico, java.lang.String dataDesbloqueioMobile) throws java.rmi.RemoteException;
}
