/**
 * CredenciamentoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1;

public class CredenciamentoRequest  implements java.io.Serializable {
    private java.lang.Integer codigoFerramenta;

    private java.lang.String indicadorAgro;

    private java.lang.String corraletionID;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial;

    private br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoes;

    private java.lang.String loginUsuario;

    public CredenciamentoRequest() {
    }

    public CredenciamentoRequest(
           java.lang.Integer codigoFerramenta,
           java.lang.String indicadorAgro,
           java.lang.String corraletionID,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial,
           br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoes,
           java.lang.String loginUsuario) {
           this.codigoFerramenta = codigoFerramenta;
           this.indicadorAgro = indicadorAgro;
           this.corraletionID = corraletionID;
           this.estabelecimentoComercial = estabelecimentoComercial;
           this.solucoes = solucoes;
           this.loginUsuario = loginUsuario;
    }


    /**
     * Gets the codigoFerramenta value for this CredenciamentoRequest.
     * 
     * @return codigoFerramenta
     */
    public java.lang.Integer getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this CredenciamentoRequest.
     * 
     * @param codigoFerramenta
     */
    public void setCodigoFerramenta(java.lang.Integer codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the indicadorAgro value for this CredenciamentoRequest.
     * 
     * @return indicadorAgro
     */
    public java.lang.String getIndicadorAgro() {
        return indicadorAgro;
    }


    /**
     * Sets the indicadorAgro value for this CredenciamentoRequest.
     * 
     * @param indicadorAgro
     */
    public void setIndicadorAgro(java.lang.String indicadorAgro) {
        this.indicadorAgro = indicadorAgro;
    }


    /**
     * Gets the corraletionID value for this CredenciamentoRequest.
     * 
     * @return corraletionID
     */
    public java.lang.String getCorraletionID() {
        return corraletionID;
    }


    /**
     * Sets the corraletionID value for this CredenciamentoRequest.
     * 
     * @param corraletionID
     */
    public void setCorraletionID(java.lang.String corraletionID) {
        this.corraletionID = corraletionID;
    }


    /**
     * Gets the estabelecimentoComercial value for this CredenciamentoRequest.
     * 
     * @return estabelecimentoComercial
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType getEstabelecimentoComercial() {
        return estabelecimentoComercial;
    }


    /**
     * Sets the estabelecimentoComercial value for this CredenciamentoRequest.
     * 
     * @param estabelecimentoComercial
     */
    public void setEstabelecimentoComercial(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.EstabelecimentoComercialType estabelecimentoComercial) {
        this.estabelecimentoComercial = estabelecimentoComercial;
    }


    /**
     * Gets the solucoes value for this CredenciamentoRequest.
     * 
     * @return solucoes
     */
    public br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] getSolucoes() {
        return solucoes;
    }


    /**
     * Sets the solucoes value for this CredenciamentoRequest.
     * 
     * @param solucoes
     */
    public void setSolucoes(br.com.cielo.credenciamento.operacao.comercial.credenciar_cliente.v1.SolucaoCapturaType[] solucoes) {
        this.solucoes = solucoes;
    }


    /**
     * Gets the loginUsuario value for this CredenciamentoRequest.
     * 
     * @return loginUsuario
     */
    public java.lang.String getLoginUsuario() {
        return loginUsuario;
    }


    /**
     * Sets the loginUsuario value for this CredenciamentoRequest.
     * 
     * @param loginUsuario
     */
    public void setLoginUsuario(java.lang.String loginUsuario) {
        this.loginUsuario = loginUsuario;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CredenciamentoRequest)) return false;
        CredenciamentoRequest other = (CredenciamentoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoFerramenta==null && other.getCodigoFerramenta()==null) || 
             (this.codigoFerramenta!=null &&
              this.codigoFerramenta.equals(other.getCodigoFerramenta()))) &&
            ((this.indicadorAgro==null && other.getIndicadorAgro()==null) || 
             (this.indicadorAgro!=null &&
              this.indicadorAgro.equals(other.getIndicadorAgro()))) &&
            ((this.corraletionID==null && other.getCorraletionID()==null) || 
             (this.corraletionID!=null &&
              this.corraletionID.equals(other.getCorraletionID()))) &&
            ((this.estabelecimentoComercial==null && other.getEstabelecimentoComercial()==null) || 
             (this.estabelecimentoComercial!=null &&
              this.estabelecimentoComercial.equals(other.getEstabelecimentoComercial()))) &&
            ((this.solucoes==null && other.getSolucoes()==null) || 
             (this.solucoes!=null &&
              java.util.Arrays.equals(this.solucoes, other.getSolucoes()))) &&
            ((this.loginUsuario==null && other.getLoginUsuario()==null) || 
             (this.loginUsuario!=null &&
              this.loginUsuario.equals(other.getLoginUsuario())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoFerramenta() != null) {
            _hashCode += getCodigoFerramenta().hashCode();
        }
        if (getIndicadorAgro() != null) {
            _hashCode += getIndicadorAgro().hashCode();
        }
        if (getCorraletionID() != null) {
            _hashCode += getCorraletionID().hashCode();
        }
        if (getEstabelecimentoComercial() != null) {
            _hashCode += getEstabelecimentoComercial().hashCode();
        }
        if (getSolucoes() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSolucoes());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSolucoes(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getLoginUsuario() != null) {
            _hashCode += getLoginUsuario().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CredenciamentoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "credenciamentoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAgro");
        elemField.setXmlName(new javax.xml.namespace.QName("", "indicadorAgro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("corraletionID");
        elemField.setXmlName(new javax.xml.namespace.QName("", "corraletionID"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "estabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "estabelecimentoComercialType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucoes");
        elemField.setXmlName(new javax.xml.namespace.QName("", "solucoes"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://credenciamento.cielo.com.br/operacao/comercial/credenciar_cliente/v1", "solucaoCapturaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("", "solucao"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loginUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "loginUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
