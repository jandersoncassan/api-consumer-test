package br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta;

public class Cliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy implements br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServicePortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServicePortType cliente_consultarMccPorTipoPessoaFerramentaServicePortType = null;
  
  public Cliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy() {
    _initCliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy();
  }
  
  public Cliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initCliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy();
  }
  
  private void _initCliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy() {
    try {
      cliente_consultarMccPorTipoPessoaFerramentaServicePortType = (new br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServiceLocator()).getCliente_consultarMccPorTipoPessoaFerramentaServiceSOAPPort();
      if (cliente_consultarMccPorTipoPessoaFerramentaServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)cliente_consultarMccPorTipoPessoaFerramentaServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)cliente_consultarMccPorTipoPessoaFerramentaServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (cliente_consultarMccPorTipoPessoaFerramentaServicePortType != null)
      ((javax.xml.rpc.Stub)cliente_consultarMccPorTipoPessoaFerramentaServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServicePortType getCliente_consultarMccPorTipoPessoaFerramentaServicePortType() {
    if (cliente_consultarMccPorTipoPessoaFerramentaServicePortType == null)
      _initCliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy();
    return cliente_consultarMccPorTipoPessoaFerramentaServicePortType;
  }
  
  public br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaResponseType consultarMccPorTipoPessoaFerramenta(br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaRequestType parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (cliente_consultarMccPorTipoPessoaFerramentaServicePortType == null)
      _initCliente_consultarMccPorTipoPessoaFerramentaServicePortTypeProxy();
    return cliente_consultarMccPorTipoPessoaFerramentaServicePortType.consultarMccPorTipoPessoaFerramenta(parameters, header);
  }
  
  
}