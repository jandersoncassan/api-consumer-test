package br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico;

public class ConsultarNumeroLogicoProxy implements br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogico {
  private String _endpoint = null;
  private br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogico consultarNumeroLogico = null;
  
  public ConsultarNumeroLogicoProxy() {
    _initConsultarNumeroLogicoProxy();
  }
  
  public ConsultarNumeroLogicoProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarNumeroLogicoProxy();
  }
  
  private void _initConsultarNumeroLogicoProxy() {
    try {
      consultarNumeroLogico = (new br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoSOAPQSServiceLocator()).getConsultarNumeroLogicoSOAPQSPort();
      if (consultarNumeroLogico != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarNumeroLogico)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarNumeroLogico)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarNumeroLogico != null)
      ((javax.xml.rpc.Stub)consultarNumeroLogico)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogico getConsultarNumeroLogico() {
    if (consultarNumeroLogico == null)
      _initConsultarNumeroLogicoProxy();
    return consultarNumeroLogico;
  }
  
  public br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoResponseType consultarNumeroLogico(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoRequestType parameters) throws java.rmi.RemoteException{
    if (consultarNumeroLogico == null)
      _initConsultarNumeroLogicoProxy();
    return consultarNumeroLogico.consultarNumeroLogico(header, parameters);
  }
  
  
}