/**
 * DadosProprietarioType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho;

public class DadosProprietarioType  implements java.io.Serializable {
    private java.lang.String nome;

    private java.lang.String numeroCpf;

    private java.util.Date dataNascimento;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType[] telefonesProprietario;

    public DadosProprietarioType() {
    }

    public DadosProprietarioType(
           java.lang.String nome,
           java.lang.String numeroCpf,
           java.util.Date dataNascimento,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType[] telefonesProprietario) {
           this.nome = nome;
           this.numeroCpf = numeroCpf;
           this.dataNascimento = dataNascimento;
           this.telefonesProprietario = telefonesProprietario;
    }


    /**
     * Gets the nome value for this DadosProprietarioType.
     * 
     * @return nome
     */
    public java.lang.String getNome() {
        return nome;
    }


    /**
     * Sets the nome value for this DadosProprietarioType.
     * 
     * @param nome
     */
    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }


    /**
     * Gets the numeroCpf value for this DadosProprietarioType.
     * 
     * @return numeroCpf
     */
    public java.lang.String getNumeroCpf() {
        return numeroCpf;
    }


    /**
     * Sets the numeroCpf value for this DadosProprietarioType.
     * 
     * @param numeroCpf
     */
    public void setNumeroCpf(java.lang.String numeroCpf) {
        this.numeroCpf = numeroCpf;
    }


    /**
     * Gets the dataNascimento value for this DadosProprietarioType.
     * 
     * @return dataNascimento
     */
    public java.util.Date getDataNascimento() {
        return dataNascimento;
    }


    /**
     * Sets the dataNascimento value for this DadosProprietarioType.
     * 
     * @param dataNascimento
     */
    public void setDataNascimento(java.util.Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }


    /**
     * Gets the telefonesProprietario value for this DadosProprietarioType.
     * 
     * @return telefonesProprietario
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType[] getTelefonesProprietario() {
        return telefonesProprietario;
    }


    /**
     * Sets the telefonesProprietario value for this DadosProprietarioType.
     * 
     * @param telefonesProprietario
     */
    public void setTelefonesProprietario(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType[] telefonesProprietario) {
        this.telefonesProprietario = telefonesProprietario;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof DadosProprietarioType)) return false;
        DadosProprietarioType other = (DadosProprietarioType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.nome==null && other.getNome()==null) || 
             (this.nome!=null &&
              this.nome.equals(other.getNome()))) &&
            ((this.numeroCpf==null && other.getNumeroCpf()==null) || 
             (this.numeroCpf!=null &&
              this.numeroCpf.equals(other.getNumeroCpf()))) &&
            ((this.dataNascimento==null && other.getDataNascimento()==null) || 
             (this.dataNascimento!=null &&
              this.dataNascimento.equals(other.getDataNascimento()))) &&
            ((this.telefonesProprietario==null && other.getTelefonesProprietario()==null) || 
             (this.telefonesProprietario!=null &&
              java.util.Arrays.equals(this.telefonesProprietario, other.getTelefonesProprietario())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNome() != null) {
            _hashCode += getNome().hashCode();
        }
        if (getNumeroCpf() != null) {
            _hashCode += getNumeroCpf().hashCode();
        }
        if (getDataNascimento() != null) {
            _hashCode += getDataNascimento().hashCode();
        }
        if (getTelefonesProprietario() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getTelefonesProprietario());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getTelefonesProprietario(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(DadosProprietarioType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "dadosProprietarioType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "nome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCpf");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "numeroCpf"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dataNascimento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "dataNascimento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "date"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telefonesProprietario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "telefonesProprietario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "telefoneType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "telefone"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
