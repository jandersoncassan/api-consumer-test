/**
 * Credenciamento_ConsultarListaParametrosSolucaoCaptura.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura;

public interface Credenciamento_ConsultarListaParametrosSolucaoCaptura extends java.rmi.Remote {
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaResponse consultarListaParametrosSolucaoCaptura(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
