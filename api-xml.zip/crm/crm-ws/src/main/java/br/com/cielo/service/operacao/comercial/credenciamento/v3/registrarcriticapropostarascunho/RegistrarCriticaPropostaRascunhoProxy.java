package br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho;

public class RegistrarCriticaPropostaRascunhoProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunho_PortType {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunho_PortType registrarCriticaPropostaRascunho_PortType = null;
  
  public RegistrarCriticaPropostaRascunhoProxy() {
    _initRegistrarCriticaPropostaRascunhoProxy();
  }
  
  public RegistrarCriticaPropostaRascunhoProxy(String endpoint) {
    _endpoint = endpoint;
    _initRegistrarCriticaPropostaRascunhoProxy();
  }
  
  private void _initRegistrarCriticaPropostaRascunhoProxy() {
    try {
      registrarCriticaPropostaRascunho_PortType = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunho_ServiceLocator()).getRegistrarCriticaPropostaRascunhoSoapPort();
      if (registrarCriticaPropostaRascunho_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)registrarCriticaPropostaRascunho_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)registrarCriticaPropostaRascunho_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (registrarCriticaPropostaRascunho_PortType != null)
      ((javax.xml.rpc.Stub)registrarCriticaPropostaRascunho_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunho_PortType getRegistrarCriticaPropostaRascunho_PortType() {
    if (registrarCriticaPropostaRascunho_PortType == null)
      _initRegistrarCriticaPropostaRascunhoProxy();
    return registrarCriticaPropostaRascunho_PortType;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoResponseType registrarCriticaPropostaRascunho(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoRequestType parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (registrarCriticaPropostaRascunho_PortType == null)
      _initRegistrarCriticaPropostaRascunhoProxy();
    return registrarCriticaPropostaRascunho_PortType.registrarCriticaPropostaRascunho(header, parameters);
  }
  
  
}