/**
 * ConsultarPropostaRascunhoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho;

public class ConsultarPropostaRascunhoRequest  implements java.io.Serializable {
    /* Tipo que representa Código do Tipo da Pessoa. 
     * 						F - Física
     * 						J - Jurídica */
    private br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequestCodigoTipoPessoa codigoTipoPessoa;

    /* Tipo que representa o Código da Ferramenta
     * 						1	BANCOS BATCH
     * 						2	BANCOS ON-LINE
     * 						3	SITE */
    private int codigoFerramenta;

    private long numeroCpfCnpj;

    public ConsultarPropostaRascunhoRequest() {
    }

    public ConsultarPropostaRascunhoRequest(
           br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequestCodigoTipoPessoa codigoTipoPessoa,
           int codigoFerramenta,
           long numeroCpfCnpj) {
           this.codigoTipoPessoa = codigoTipoPessoa;
           this.codigoFerramenta = codigoFerramenta;
           this.numeroCpfCnpj = numeroCpfCnpj;
    }


    /**
     * Gets the codigoTipoPessoa value for this ConsultarPropostaRascunhoRequest.
     * 
     * @return codigoTipoPessoa   * Tipo que representa Código do Tipo da Pessoa. 
     * 						F - Física
     * 						J - Jurídica
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequestCodigoTipoPessoa getCodigoTipoPessoa() {
        return codigoTipoPessoa;
    }


    /**
     * Sets the codigoTipoPessoa value for this ConsultarPropostaRascunhoRequest.
     * 
     * @param codigoTipoPessoa   * Tipo que representa Código do Tipo da Pessoa. 
     * 						F - Física
     * 						J - Jurídica
     */
    public void setCodigoTipoPessoa(br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequestCodigoTipoPessoa codigoTipoPessoa) {
        this.codigoTipoPessoa = codigoTipoPessoa;
    }


    /**
     * Gets the codigoFerramenta value for this ConsultarPropostaRascunhoRequest.
     * 
     * @return codigoFerramenta   * Tipo que representa o Código da Ferramenta
     * 						1	BANCOS BATCH
     * 						2	BANCOS ON-LINE
     * 						3	SITE
     */
    public int getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this ConsultarPropostaRascunhoRequest.
     * 
     * @param codigoFerramenta   * Tipo que representa o Código da Ferramenta
     * 						1	BANCOS BATCH
     * 						2	BANCOS ON-LINE
     * 						3	SITE
     */
    public void setCodigoFerramenta(int codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the numeroCpfCnpj value for this ConsultarPropostaRascunhoRequest.
     * 
     * @return numeroCpfCnpj
     */
    public long getNumeroCpfCnpj() {
        return numeroCpfCnpj;
    }


    /**
     * Sets the numeroCpfCnpj value for this ConsultarPropostaRascunhoRequest.
     * 
     * @param numeroCpfCnpj
     */
    public void setNumeroCpfCnpj(long numeroCpfCnpj) {
        this.numeroCpfCnpj = numeroCpfCnpj;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarPropostaRascunhoRequest)) return false;
        ConsultarPropostaRascunhoRequest other = (ConsultarPropostaRascunhoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTipoPessoa==null && other.getCodigoTipoPessoa()==null) || 
             (this.codigoTipoPessoa!=null &&
              this.codigoTipoPessoa.equals(other.getCodigoTipoPessoa()))) &&
            this.codigoFerramenta == other.getCodigoFerramenta() &&
            this.numeroCpfCnpj == other.getNumeroCpfCnpj();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTipoPessoa() != null) {
            _hashCode += getCodigoTipoPessoa().hashCode();
        }
        _hashCode += getCodigoFerramenta();
        _hashCode += new Long(getNumeroCpfCnpj()).hashCode();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarPropostaRascunhoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", ">consultarPropostaRascunhoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "codigoTipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", ">>consultarPropostaRascunhoRequest>codigoTipoPessoa"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCpfCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "numeroCpfCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
