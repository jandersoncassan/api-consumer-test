package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta;

public class Credenciamento_ConsultarSolucaoCapturaPorFerramentaProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType = null;
  
  public Credenciamento_ConsultarSolucaoCapturaPorFerramentaProxy() {
    _initCredenciamento_ConsultarSolucaoCapturaPorFerramentaProxy();
  }
  
  public Credenciamento_ConsultarSolucaoCapturaPorFerramentaProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamento_ConsultarSolucaoCapturaPorFerramentaProxy();
  }
  
  private void _initCredenciamento_ConsultarSolucaoCapturaPorFerramentaProxy() {
    try {
      credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator()).getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort();
      if (credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType != null)
      ((javax.xml.rpc.Stub)credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType getCredenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType() {
    if (credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType == null)
      _initCredenciamento_ConsultarSolucaoCapturaPorFerramentaProxy();
    return credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.ConsultarSolucaoCapturaPorFerramentaResponse consultarSolucaoCapturaPorFerramenta(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.ConsultarSolucaoCapturaPorFerramentaRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType == null)
      _initCredenciamento_ConsultarSolucaoCapturaPorFerramentaProxy();
    return credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType.consultarSolucaoCapturaPorFerramenta(header, parameters);
  }
  
  
}