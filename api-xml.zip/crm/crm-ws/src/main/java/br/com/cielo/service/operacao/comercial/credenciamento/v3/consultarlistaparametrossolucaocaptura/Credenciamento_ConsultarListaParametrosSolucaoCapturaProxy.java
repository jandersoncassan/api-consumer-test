package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura;

public class Credenciamento_ConsultarListaParametrosSolucaoCapturaProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.Credenciamento_ConsultarListaParametrosSolucaoCaptura {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.Credenciamento_ConsultarListaParametrosSolucaoCaptura credenciamento_ConsultarListaParametrosSolucaoCaptura = null;
  
  public Credenciamento_ConsultarListaParametrosSolucaoCapturaProxy() {
    _initCredenciamento_ConsultarListaParametrosSolucaoCapturaProxy();
  }
  
  public Credenciamento_ConsultarListaParametrosSolucaoCapturaProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamento_ConsultarListaParametrosSolucaoCapturaProxy();
  }
  
  private void _initCredenciamento_ConsultarListaParametrosSolucaoCapturaProxy() {
    try {
      credenciamento_ConsultarListaParametrosSolucaoCaptura = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.Credenciamento_ConsultarListaParametrosSolucaoCapturaServiceLocator()).getCredenciamento_ConsultarListaParametrosSolucaoCapturaServiceSoapPort();
      if (credenciamento_ConsultarListaParametrosSolucaoCaptura != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamento_ConsultarListaParametrosSolucaoCaptura)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamento_ConsultarListaParametrosSolucaoCaptura)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamento_ConsultarListaParametrosSolucaoCaptura != null)
      ((javax.xml.rpc.Stub)credenciamento_ConsultarListaParametrosSolucaoCaptura)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.Credenciamento_ConsultarListaParametrosSolucaoCaptura getCredenciamento_ConsultarListaParametrosSolucaoCaptura() {
    if (credenciamento_ConsultarListaParametrosSolucaoCaptura == null)
      _initCredenciamento_ConsultarListaParametrosSolucaoCapturaProxy();
    return credenciamento_ConsultarListaParametrosSolucaoCaptura;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaResponse consultarListaParametrosSolucaoCaptura(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaRequest parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamento_ConsultarListaParametrosSolucaoCaptura == null)
      _initCredenciamento_ConsultarListaParametrosSolucaoCapturaProxy();
    return credenciamento_ConsultarListaParametrosSolucaoCaptura.consultarListaParametrosSolucaoCaptura(header, parameters);
  }
  
  
}