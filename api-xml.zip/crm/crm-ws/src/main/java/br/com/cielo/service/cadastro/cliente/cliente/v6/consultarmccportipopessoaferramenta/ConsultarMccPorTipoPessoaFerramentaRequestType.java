/**
 * ConsultarMccPorTipoPessoaFerramentaRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta;

public class ConsultarMccPorTipoPessoaFerramentaRequestType  implements java.io.Serializable {
    /* Identificador do tipo de pessoa, exemplo: F(Fisica) e J(Juridica). */
    private java.lang.String codigoTipoPessoa;

    /* Identificador da ferramenta solicitande da consulta(Canal atendimento
     * -
     * 						código cadastrado na tabela Ferramentas. Dominios: 1 - Bancos
     * batch ||
     * 						2 - Bancos on-line || 3 – Site */
    private java.math.BigInteger codigoFerramenta;

    public ConsultarMccPorTipoPessoaFerramentaRequestType() {
    }

    public ConsultarMccPorTipoPessoaFerramentaRequestType(
           java.lang.String codigoTipoPessoa,
           java.math.BigInteger codigoFerramenta) {
           this.codigoTipoPessoa = codigoTipoPessoa;
           this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the codigoTipoPessoa value for this ConsultarMccPorTipoPessoaFerramentaRequestType.
     * 
     * @return codigoTipoPessoa   * Identificador do tipo de pessoa, exemplo: F(Fisica) e J(Juridica).
     */
    public java.lang.String getCodigoTipoPessoa() {
        return codigoTipoPessoa;
    }


    /**
     * Sets the codigoTipoPessoa value for this ConsultarMccPorTipoPessoaFerramentaRequestType.
     * 
     * @param codigoTipoPessoa   * Identificador do tipo de pessoa, exemplo: F(Fisica) e J(Juridica).
     */
    public void setCodigoTipoPessoa(java.lang.String codigoTipoPessoa) {
        this.codigoTipoPessoa = codigoTipoPessoa;
    }


    /**
     * Gets the codigoFerramenta value for this ConsultarMccPorTipoPessoaFerramentaRequestType.
     * 
     * @return codigoFerramenta   * Identificador da ferramenta solicitande da consulta(Canal atendimento
     * -
     * 						código cadastrado na tabela Ferramentas. Dominios: 1 - Bancos
     * batch ||
     * 						2 - Bancos on-line || 3 – Site
     */
    public java.math.BigInteger getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this ConsultarMccPorTipoPessoaFerramentaRequestType.
     * 
     * @param codigoFerramenta   * Identificador da ferramenta solicitande da consulta(Canal atendimento
     * -
     * 						código cadastrado na tabela Ferramentas. Dominios: 1 - Bancos
     * batch ||
     * 						2 - Bancos on-line || 3 – Site
     */
    public void setCodigoFerramenta(java.math.BigInteger codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarMccPorTipoPessoaFerramentaRequestType)) return false;
        ConsultarMccPorTipoPessoaFerramentaRequestType other = (ConsultarMccPorTipoPessoaFerramentaRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoTipoPessoa==null && other.getCodigoTipoPessoa()==null) || 
             (this.codigoTipoPessoa!=null &&
              this.codigoTipoPessoa.equals(other.getCodigoTipoPessoa()))) &&
            ((this.codigoFerramenta==null && other.getCodigoFerramenta()==null) || 
             (this.codigoFerramenta!=null &&
              this.codigoFerramenta.equals(other.getCodigoFerramenta())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoTipoPessoa() != null) {
            _hashCode += getCodigoTipoPessoa().hashCode();
        }
        if (getCodigoFerramenta() != null) {
            _hashCode += getCodigoFerramenta().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarMccPorTipoPessoaFerramentaRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v6/consultarmccportipopessoaferramenta", "consultarMccPorTipoPessoaFerramentaRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v6/consultarmccportipopessoaferramenta", "codigoTipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/cliente/cliente/v6/consultarmccportipopessoaferramenta", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
