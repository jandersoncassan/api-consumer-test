package br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos;

public class Banco_ListarBancosServicePortTypeProxy implements br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.Banco_ListarBancosServicePortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.Banco_ListarBancosServicePortType banco_ListarBancosServicePortType = null;
  
  public Banco_ListarBancosServicePortTypeProxy() {
    _initBanco_ListarBancosServicePortTypeProxy();
  }
  
  public Banco_ListarBancosServicePortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initBanco_ListarBancosServicePortTypeProxy();
  }
  
  private void _initBanco_ListarBancosServicePortTypeProxy() {
    try {
      banco_ListarBancosServicePortType = (new br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.Banco_ListarBancosServiceLocator()).getBanco_ListarBancosServiceSOAPPort();
      if (banco_ListarBancosServicePortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)banco_ListarBancosServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)banco_ListarBancosServicePortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (banco_ListarBancosServicePortType != null)
      ((javax.xml.rpc.Stub)banco_ListarBancosServicePortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.Banco_ListarBancosServicePortType getBanco_ListarBancosServicePortType() {
    if (banco_ListarBancosServicePortType == null)
      _initBanco_ListarBancosServicePortTypeProxy();
    return banco_ListarBancosServicePortType;
  }
  
  public br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.ListarBancosResponse listarBancos(java.lang.Object parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (banco_ListarBancosServicePortType == null)
      _initBanco_ListarBancosServicePortTypeProxy();
    return banco_ListarBancosServicePortType.listarBancos(parameters, header);
  }
  
  
}