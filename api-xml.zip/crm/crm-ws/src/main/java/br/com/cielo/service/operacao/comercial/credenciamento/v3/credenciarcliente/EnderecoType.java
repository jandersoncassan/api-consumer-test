/**
 * EnderecoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente;

public class EnderecoType  implements java.io.Serializable {
    /* Tipo que indica o codigo do tipo de endereço
     * 						1-Residencial
     * 						2-Comercial
     * 						3-Correspondencia
     * 						4-Suprimento */
    private java.lang.Integer tipoEndereco;

    private java.lang.String nomeLogradouro;

    private java.lang.String descricaoComplementoEndereco;

    private java.lang.String numeroLogradouro;

    private java.lang.String nomeBairro;

    private java.lang.String nomeCidade;

    private java.lang.String siglaEstado;

    private java.lang.Integer numeroCEP;

    public EnderecoType() {
    }

    public EnderecoType(
           java.lang.Integer tipoEndereco,
           java.lang.String nomeLogradouro,
           java.lang.String descricaoComplementoEndereco,
           java.lang.String numeroLogradouro,
           java.lang.String nomeBairro,
           java.lang.String nomeCidade,
           java.lang.String siglaEstado,
           java.lang.Integer numeroCEP) {
           this.tipoEndereco = tipoEndereco;
           this.nomeLogradouro = nomeLogradouro;
           this.descricaoComplementoEndereco = descricaoComplementoEndereco;
           this.numeroLogradouro = numeroLogradouro;
           this.nomeBairro = nomeBairro;
           this.nomeCidade = nomeCidade;
           this.siglaEstado = siglaEstado;
           this.numeroCEP = numeroCEP;
    }


    /**
     * Gets the tipoEndereco value for this EnderecoType.
     * 
     * @return tipoEndereco   * Tipo que indica o codigo do tipo de endereço
     * 						1-Residencial
     * 						2-Comercial
     * 						3-Correspondencia
     * 						4-Suprimento
     */
    public java.lang.Integer getTipoEndereco() {
        return tipoEndereco;
    }


    /**
     * Sets the tipoEndereco value for this EnderecoType.
     * 
     * @param tipoEndereco   * Tipo que indica o codigo do tipo de endereço
     * 						1-Residencial
     * 						2-Comercial
     * 						3-Correspondencia
     * 						4-Suprimento
     */
    public void setTipoEndereco(java.lang.Integer tipoEndereco) {
        this.tipoEndereco = tipoEndereco;
    }


    /**
     * Gets the nomeLogradouro value for this EnderecoType.
     * 
     * @return nomeLogradouro
     */
    public java.lang.String getNomeLogradouro() {
        return nomeLogradouro;
    }


    /**
     * Sets the nomeLogradouro value for this EnderecoType.
     * 
     * @param nomeLogradouro
     */
    public void setNomeLogradouro(java.lang.String nomeLogradouro) {
        this.nomeLogradouro = nomeLogradouro;
    }


    /**
     * Gets the descricaoComplementoEndereco value for this EnderecoType.
     * 
     * @return descricaoComplementoEndereco
     */
    public java.lang.String getDescricaoComplementoEndereco() {
        return descricaoComplementoEndereco;
    }


    /**
     * Sets the descricaoComplementoEndereco value for this EnderecoType.
     * 
     * @param descricaoComplementoEndereco
     */
    public void setDescricaoComplementoEndereco(java.lang.String descricaoComplementoEndereco) {
        this.descricaoComplementoEndereco = descricaoComplementoEndereco;
    }


    /**
     * Gets the numeroLogradouro value for this EnderecoType.
     * 
     * @return numeroLogradouro
     */
    public java.lang.String getNumeroLogradouro() {
        return numeroLogradouro;
    }


    /**
     * Sets the numeroLogradouro value for this EnderecoType.
     * 
     * @param numeroLogradouro
     */
    public void setNumeroLogradouro(java.lang.String numeroLogradouro) {
        this.numeroLogradouro = numeroLogradouro;
    }


    /**
     * Gets the nomeBairro value for this EnderecoType.
     * 
     * @return nomeBairro
     */
    public java.lang.String getNomeBairro() {
        return nomeBairro;
    }


    /**
     * Sets the nomeBairro value for this EnderecoType.
     * 
     * @param nomeBairro
     */
    public void setNomeBairro(java.lang.String nomeBairro) {
        this.nomeBairro = nomeBairro;
    }


    /**
     * Gets the nomeCidade value for this EnderecoType.
     * 
     * @return nomeCidade
     */
    public java.lang.String getNomeCidade() {
        return nomeCidade;
    }


    /**
     * Sets the nomeCidade value for this EnderecoType.
     * 
     * @param nomeCidade
     */
    public void setNomeCidade(java.lang.String nomeCidade) {
        this.nomeCidade = nomeCidade;
    }


    /**
     * Gets the siglaEstado value for this EnderecoType.
     * 
     * @return siglaEstado
     */
    public java.lang.String getSiglaEstado() {
        return siglaEstado;
    }


    /**
     * Sets the siglaEstado value for this EnderecoType.
     * 
     * @param siglaEstado
     */
    public void setSiglaEstado(java.lang.String siglaEstado) {
        this.siglaEstado = siglaEstado;
    }


    /**
     * Gets the numeroCEP value for this EnderecoType.
     * 
     * @return numeroCEP
     */
    public java.lang.Integer getNumeroCEP() {
        return numeroCEP;
    }


    /**
     * Sets the numeroCEP value for this EnderecoType.
     * 
     * @param numeroCEP
     */
    public void setNumeroCEP(java.lang.Integer numeroCEP) {
        this.numeroCEP = numeroCEP;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof EnderecoType)) return false;
        EnderecoType other = (EnderecoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.tipoEndereco==null && other.getTipoEndereco()==null) || 
             (this.tipoEndereco!=null &&
              this.tipoEndereco.equals(other.getTipoEndereco()))) &&
            ((this.nomeLogradouro==null && other.getNomeLogradouro()==null) || 
             (this.nomeLogradouro!=null &&
              this.nomeLogradouro.equals(other.getNomeLogradouro()))) &&
            ((this.descricaoComplementoEndereco==null && other.getDescricaoComplementoEndereco()==null) || 
             (this.descricaoComplementoEndereco!=null &&
              this.descricaoComplementoEndereco.equals(other.getDescricaoComplementoEndereco()))) &&
            ((this.numeroLogradouro==null && other.getNumeroLogradouro()==null) || 
             (this.numeroLogradouro!=null &&
              this.numeroLogradouro.equals(other.getNumeroLogradouro()))) &&
            ((this.nomeBairro==null && other.getNomeBairro()==null) || 
             (this.nomeBairro!=null &&
              this.nomeBairro.equals(other.getNomeBairro()))) &&
            ((this.nomeCidade==null && other.getNomeCidade()==null) || 
             (this.nomeCidade!=null &&
              this.nomeCidade.equals(other.getNomeCidade()))) &&
            ((this.siglaEstado==null && other.getSiglaEstado()==null) || 
             (this.siglaEstado!=null &&
              this.siglaEstado.equals(other.getSiglaEstado()))) &&
            ((this.numeroCEP==null && other.getNumeroCEP()==null) || 
             (this.numeroCEP!=null &&
              this.numeroCEP.equals(other.getNumeroCEP())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTipoEndereco() != null) {
            _hashCode += getTipoEndereco().hashCode();
        }
        if (getNomeLogradouro() != null) {
            _hashCode += getNomeLogradouro().hashCode();
        }
        if (getDescricaoComplementoEndereco() != null) {
            _hashCode += getDescricaoComplementoEndereco().hashCode();
        }
        if (getNumeroLogradouro() != null) {
            _hashCode += getNumeroLogradouro().hashCode();
        }
        if (getNomeBairro() != null) {
            _hashCode += getNomeBairro().hashCode();
        }
        if (getNomeCidade() != null) {
            _hashCode += getNomeCidade().hashCode();
        }
        if (getSiglaEstado() != null) {
            _hashCode += getSiglaEstado().hashCode();
        }
        if (getNumeroCEP() != null) {
            _hashCode += getNumeroCEP().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(EnderecoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "enderecoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "tipoEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeLogradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomeLogradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoComplementoEndereco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "descricaoComplementoEndereco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroLogradouro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "numeroLogradouro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBairro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomeBairro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeCidade");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "nomeCidade"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("siglaEstado");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "siglaEstado"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroCEP");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "numeroCEP"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
