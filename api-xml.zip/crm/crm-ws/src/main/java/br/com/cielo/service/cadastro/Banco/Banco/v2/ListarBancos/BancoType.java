/**
 * BancoType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos;

public class BancoType  implements java.io.Serializable {
    private java.lang.String codigo;

    private java.lang.String nomeResumido;

    private java.lang.String nomeBacen;

    private java.lang.String indicadorAtivo;

    private java.lang.String indicadorPermiteContaPoupanca;

    public BancoType() {
    }

    public BancoType(
           java.lang.String codigo,
           java.lang.String nomeResumido,
           java.lang.String nomeBacen,
           java.lang.String indicadorAtivo,
           java.lang.String indicadorPermiteContaPoupanca) {
           this.codigo = codigo;
           this.nomeResumido = nomeResumido;
           this.nomeBacen = nomeBacen;
           this.indicadorAtivo = indicadorAtivo;
           this.indicadorPermiteContaPoupanca = indicadorPermiteContaPoupanca;
    }


    /**
     * Gets the codigo value for this BancoType.
     * 
     * @return codigo
     */
    public java.lang.String getCodigo() {
        return codigo;
    }


    /**
     * Sets the codigo value for this BancoType.
     * 
     * @param codigo
     */
    public void setCodigo(java.lang.String codigo) {
        this.codigo = codigo;
    }


    /**
     * Gets the nomeResumido value for this BancoType.
     * 
     * @return nomeResumido
     */
    public java.lang.String getNomeResumido() {
        return nomeResumido;
    }


    /**
     * Sets the nomeResumido value for this BancoType.
     * 
     * @param nomeResumido
     */
    public void setNomeResumido(java.lang.String nomeResumido) {
        this.nomeResumido = nomeResumido;
    }


    /**
     * Gets the nomeBacen value for this BancoType.
     * 
     * @return nomeBacen
     */
    public java.lang.String getNomeBacen() {
        return nomeBacen;
    }


    /**
     * Sets the nomeBacen value for this BancoType.
     * 
     * @param nomeBacen
     */
    public void setNomeBacen(java.lang.String nomeBacen) {
        this.nomeBacen = nomeBacen;
    }


    /**
     * Gets the indicadorAtivo value for this BancoType.
     * 
     * @return indicadorAtivo
     */
    public java.lang.String getIndicadorAtivo() {
        return indicadorAtivo;
    }


    /**
     * Sets the indicadorAtivo value for this BancoType.
     * 
     * @param indicadorAtivo
     */
    public void setIndicadorAtivo(java.lang.String indicadorAtivo) {
        this.indicadorAtivo = indicadorAtivo;
    }


    /**
     * Gets the indicadorPermiteContaPoupanca value for this BancoType.
     * 
     * @return indicadorPermiteContaPoupanca
     */
    public java.lang.String getIndicadorPermiteContaPoupanca() {
        return indicadorPermiteContaPoupanca;
    }


    /**
     * Sets the indicadorPermiteContaPoupanca value for this BancoType.
     * 
     * @param indicadorPermiteContaPoupanca
     */
    public void setIndicadorPermiteContaPoupanca(java.lang.String indicadorPermiteContaPoupanca) {
        this.indicadorPermiteContaPoupanca = indicadorPermiteContaPoupanca;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof BancoType)) return false;
        BancoType other = (BancoType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigo==null && other.getCodigo()==null) || 
             (this.codigo!=null &&
              this.codigo.equals(other.getCodigo()))) &&
            ((this.nomeResumido==null && other.getNomeResumido()==null) || 
             (this.nomeResumido!=null &&
              this.nomeResumido.equals(other.getNomeResumido()))) &&
            ((this.nomeBacen==null && other.getNomeBacen()==null) || 
             (this.nomeBacen!=null &&
              this.nomeBacen.equals(other.getNomeBacen()))) &&
            ((this.indicadorAtivo==null && other.getIndicadorAtivo()==null) || 
             (this.indicadorAtivo!=null &&
              this.indicadorAtivo.equals(other.getIndicadorAtivo()))) &&
            ((this.indicadorPermiteContaPoupanca==null && other.getIndicadorPermiteContaPoupanca()==null) || 
             (this.indicadorPermiteContaPoupanca!=null &&
              this.indicadorPermiteContaPoupanca.equals(other.getIndicadorPermiteContaPoupanca())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigo() != null) {
            _hashCode += getCodigo().hashCode();
        }
        if (getNomeResumido() != null) {
            _hashCode += getNomeResumido().hashCode();
        }
        if (getNomeBacen() != null) {
            _hashCode += getNomeBacen().hashCode();
        }
        if (getIndicadorAtivo() != null) {
            _hashCode += getIndicadorAtivo().hashCode();
        }
        if (getIndicadorPermiteContaPoupanca() != null) {
            _hashCode += getIndicadorPermiteContaPoupanca().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(BancoType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/Cadastro/Banco/Banco/v2/ListarBancos", "BancoType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/Cadastro/Banco/Banco/v2/ListarBancos", "codigo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeResumido");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/Cadastro/Banco/Banco/v2/ListarBancos", "nomeResumido"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeBacen");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/Cadastro/Banco/Banco/v2/ListarBancos", "nomeBacen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAtivo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/Cadastro/Banco/Banco/v2/ListarBancos", "indicadorAtivo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorPermiteContaPoupanca");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/Cadastro/Banco/Banco/v2/ListarBancos", "indicadorPermiteContaPoupanca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
