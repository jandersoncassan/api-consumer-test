package br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep;

public class ConsultarCEPProxy implements br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEP {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEP consultarCEP = null;
  
  public ConsultarCEPProxy() {
    _initConsultarCEPProxy();
  }
  
  public ConsultarCEPProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarCEPProxy();
  }
  
  private void _initConsultarCEPProxy() {
    try {
      consultarCEP = (new br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPContractSOAPQSServiceLocator()).getConsultarCEPContractSOAPQSPort();
      if (consultarCEP != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarCEP)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarCEP)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarCEP != null)
      ((javax.xml.rpc.Stub)consultarCEP)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEP getConsultarCEP() {
    if (consultarCEP == null)
      _initConsultarCEPProxy();
    return consultarCEP;
  }
  
  public br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPResponse consultarCEP(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPRequest parameters) throws java.rmi.RemoteException{
    if (consultarCEP == null)
      _initConsultarCEPProxy();
    return consultarCEP.consultarCEP(header, parameters);
  }
  
  
}