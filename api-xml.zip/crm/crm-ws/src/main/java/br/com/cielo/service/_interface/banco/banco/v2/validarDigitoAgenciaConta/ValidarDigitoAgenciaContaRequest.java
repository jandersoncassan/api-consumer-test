/**
 * ValidarDigitoAgenciaContaRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta;

public class ValidarDigitoAgenciaContaRequest  implements java.io.Serializable {
    private java.math.BigInteger codigoBanco;

    private java.math.BigInteger numeroAgencia;

    private java.lang.String numeroConta;

    /* Codigo do tipo de conta domicilio
     * 								' ' = C/C banco liquidante cielo (PAGFOR) 
     * 								0 = C/C banco liquidante cielo (PAGFOR) 
     * 								1 = C/C banco nao liquidante cielo (TED) 
     * 								2 = poupanca (TED)
     * 								3 = cartao pre-pago (NAO CONSTRUIDO) */
    private java.lang.String tipoConta;

    public ValidarDigitoAgenciaContaRequest() {
    }

    public ValidarDigitoAgenciaContaRequest(
           java.math.BigInteger codigoBanco,
           java.math.BigInteger numeroAgencia,
           java.lang.String numeroConta,
           java.lang.String tipoConta) {
           this.codigoBanco = codigoBanco;
           this.numeroAgencia = numeroAgencia;
           this.numeroConta = numeroConta;
           this.tipoConta = tipoConta;
    }


    /**
     * Gets the codigoBanco value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @return codigoBanco
     */
    public java.math.BigInteger getCodigoBanco() {
        return codigoBanco;
    }


    /**
     * Sets the codigoBanco value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @param codigoBanco
     */
    public void setCodigoBanco(java.math.BigInteger codigoBanco) {
        this.codigoBanco = codigoBanco;
    }


    /**
     * Gets the numeroAgencia value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @return numeroAgencia
     */
    public java.math.BigInteger getNumeroAgencia() {
        return numeroAgencia;
    }


    /**
     * Sets the numeroAgencia value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @param numeroAgencia
     */
    public void setNumeroAgencia(java.math.BigInteger numeroAgencia) {
        this.numeroAgencia = numeroAgencia;
    }


    /**
     * Gets the numeroConta value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @return numeroConta
     */
    public java.lang.String getNumeroConta() {
        return numeroConta;
    }


    /**
     * Sets the numeroConta value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @param numeroConta
     */
    public void setNumeroConta(java.lang.String numeroConta) {
        this.numeroConta = numeroConta;
    }


    /**
     * Gets the tipoConta value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @return tipoConta   * Codigo do tipo de conta domicilio
     * 								' ' = C/C banco liquidante cielo (PAGFOR) 
     * 								0 = C/C banco liquidante cielo (PAGFOR) 
     * 								1 = C/C banco nao liquidante cielo (TED) 
     * 								2 = poupanca (TED)
     * 								3 = cartao pre-pago (NAO CONSTRUIDO)
     */
    public java.lang.String getTipoConta() {
        return tipoConta;
    }


    /**
     * Sets the tipoConta value for this ValidarDigitoAgenciaContaRequest.
     * 
     * @param tipoConta   * Codigo do tipo de conta domicilio
     * 								' ' = C/C banco liquidante cielo (PAGFOR) 
     * 								0 = C/C banco liquidante cielo (PAGFOR) 
     * 								1 = C/C banco nao liquidante cielo (TED) 
     * 								2 = poupanca (TED)
     * 								3 = cartao pre-pago (NAO CONSTRUIDO)
     */
    public void setTipoConta(java.lang.String tipoConta) {
        this.tipoConta = tipoConta;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ValidarDigitoAgenciaContaRequest)) return false;
        ValidarDigitoAgenciaContaRequest other = (ValidarDigitoAgenciaContaRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoBanco==null && other.getCodigoBanco()==null) || 
             (this.codigoBanco!=null &&
              this.codigoBanco.equals(other.getCodigoBanco()))) &&
            ((this.numeroAgencia==null && other.getNumeroAgencia()==null) || 
             (this.numeroAgencia!=null &&
              this.numeroAgencia.equals(other.getNumeroAgencia()))) &&
            ((this.numeroConta==null && other.getNumeroConta()==null) || 
             (this.numeroConta!=null &&
              this.numeroConta.equals(other.getNumeroConta()))) &&
            ((this.tipoConta==null && other.getTipoConta()==null) || 
             (this.tipoConta!=null &&
              this.tipoConta.equals(other.getTipoConta())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoBanco() != null) {
            _hashCode += getCodigoBanco().hashCode();
        }
        if (getNumeroAgencia() != null) {
            _hashCode += getNumeroAgencia().hashCode();
        }
        if (getNumeroConta() != null) {
            _hashCode += getNumeroConta().hashCode();
        }
        if (getTipoConta() != null) {
            _hashCode += getTipoConta().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ValidarDigitoAgenciaContaRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v2/validarDigitoAgenciaConta", ">validarDigitoAgenciaContaRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoBanco");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v2/validarDigitoAgenciaConta", "codigoBanco"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroAgencia");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v2/validarDigitoAgenciaConta", "numeroAgencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "integer"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v2/validarDigitoAgenciaConta", "numeroConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoConta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/interface/banco/banco/v2/validarDigitoAgenciaConta", "tipoConta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
