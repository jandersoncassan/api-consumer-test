/**
 * RegistrarCriticaPropostaRascunhoRequestType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho;

public class RegistrarCriticaPropostaRascunhoRequestType  implements java.io.Serializable {
    private java.lang.String tipoPessoa;

    private long cpfCnpj;

    private long numeroProposta;

    private int codigoCritica;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.CampoType[] camposCriticados;

    public RegistrarCriticaPropostaRascunhoRequestType() {
    }

    public RegistrarCriticaPropostaRascunhoRequestType(
           java.lang.String tipoPessoa,
           long cpfCnpj,
           long numeroProposta,
           int codigoCritica,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.CampoType[] camposCriticados) {
           this.tipoPessoa = tipoPessoa;
           this.cpfCnpj = cpfCnpj;
           this.numeroProposta = numeroProposta;
           this.codigoCritica = codigoCritica;
           this.camposCriticados = camposCriticados;
    }


    /**
     * Gets the tipoPessoa value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @return tipoPessoa
     */
    public java.lang.String getTipoPessoa() {
        return tipoPessoa;
    }


    /**
     * Sets the tipoPessoa value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @param tipoPessoa
     */
    public void setTipoPessoa(java.lang.String tipoPessoa) {
        this.tipoPessoa = tipoPessoa;
    }


    /**
     * Gets the cpfCnpj value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @return cpfCnpj
     */
    public long getCpfCnpj() {
        return cpfCnpj;
    }


    /**
     * Sets the cpfCnpj value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @param cpfCnpj
     */
    public void setCpfCnpj(long cpfCnpj) {
        this.cpfCnpj = cpfCnpj;
    }


    /**
     * Gets the numeroProposta value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @return numeroProposta
     */
    public long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the codigoCritica value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @return codigoCritica
     */
    public int getCodigoCritica() {
        return codigoCritica;
    }


    /**
     * Sets the codigoCritica value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @param codigoCritica
     */
    public void setCodigoCritica(int codigoCritica) {
        this.codigoCritica = codigoCritica;
    }


    /**
     * Gets the camposCriticados value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @return camposCriticados
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.CampoType[] getCamposCriticados() {
        return camposCriticados;
    }


    /**
     * Sets the camposCriticados value for this RegistrarCriticaPropostaRascunhoRequestType.
     * 
     * @param camposCriticados
     */
    public void setCamposCriticados(br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.CampoType[] camposCriticados) {
        this.camposCriticados = camposCriticados;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof RegistrarCriticaPropostaRascunhoRequestType)) return false;
        RegistrarCriticaPropostaRascunhoRequestType other = (RegistrarCriticaPropostaRascunhoRequestType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.tipoPessoa==null && other.getTipoPessoa()==null) || 
             (this.tipoPessoa!=null &&
              this.tipoPessoa.equals(other.getTipoPessoa()))) &&
            this.cpfCnpj == other.getCpfCnpj() &&
            this.numeroProposta == other.getNumeroProposta() &&
            this.codigoCritica == other.getCodigoCritica() &&
            ((this.camposCriticados==null && other.getCamposCriticados()==null) || 
             (this.camposCriticados!=null &&
              java.util.Arrays.equals(this.camposCriticados, other.getCamposCriticados())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTipoPessoa() != null) {
            _hashCode += getTipoPessoa().hashCode();
        }
        _hashCode += new Long(getCpfCnpj()).hashCode();
        _hashCode += new Long(getNumeroProposta()).hashCode();
        _hashCode += getCodigoCritica();
        if (getCamposCriticados() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCamposCriticados());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCamposCriticados(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(RegistrarCriticaPropostaRascunhoRequestType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "RegistrarCriticaPropostaRascunhoRequestType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoPessoa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "tipoPessoa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("cpfCnpj");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "cpfCnpj"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCritica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "codigoCritica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("camposCriticados");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "camposCriticados"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "CampoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/registrarcriticapropostarascunho", "camposCriticados"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
