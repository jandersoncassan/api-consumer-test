/**
 * SolucaoCapturaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta;

public class SolucaoCapturaType  implements java.io.Serializable {
    private java.lang.Integer codigoSolucaoCaptura;

    private java.lang.String nome;

    private java.lang.String descricao;

    private java.lang.Boolean indicadorEntregaMaquina;

    public SolucaoCapturaType() {
    }

    public SolucaoCapturaType(
           java.lang.Integer codigoSolucaoCaptura,
           java.lang.String nome,
           java.lang.String descricao,
           java.lang.Boolean indicadorEntregaMaquina) {
           this.codigoSolucaoCaptura = codigoSolucaoCaptura;
           this.nome = nome;
           this.descricao = descricao;
           this.indicadorEntregaMaquina = indicadorEntregaMaquina;
    }


    /**
     * Gets the codigoSolucaoCaptura value for this SolucaoCapturaType.
     * 
     * @return codigoSolucaoCaptura
     */
    public java.lang.Integer getCodigoSolucaoCaptura() {
        return codigoSolucaoCaptura;
    }


    /**
     * Sets the codigoSolucaoCaptura value for this SolucaoCapturaType.
     * 
     * @param codigoSolucaoCaptura
     */
    public void setCodigoSolucaoCaptura(java.lang.Integer codigoSolucaoCaptura) {
        this.codigoSolucaoCaptura = codigoSolucaoCaptura;
    }


    /**
     * Gets the nome value for this SolucaoCapturaType.
     * 
     * @return nome
     */
    public java.lang.String getNome() {
        return nome;
    }


    /**
     * Sets the nome value for this SolucaoCapturaType.
     * 
     * @param nome
     */
    public void setNome(java.lang.String nome) {
        this.nome = nome;
    }


    /**
     * Gets the descricao value for this SolucaoCapturaType.
     * 
     * @return descricao
     */
    public java.lang.String getDescricao() {
        return descricao;
    }


    /**
     * Sets the descricao value for this SolucaoCapturaType.
     * 
     * @param descricao
     */
    public void setDescricao(java.lang.String descricao) {
        this.descricao = descricao;
    }


    /**
     * Gets the indicadorEntregaMaquina value for this SolucaoCapturaType.
     * 
     * @return indicadorEntregaMaquina
     */
    public java.lang.Boolean getIndicadorEntregaMaquina() {
        return indicadorEntregaMaquina;
    }


    /**
     * Sets the indicadorEntregaMaquina value for this SolucaoCapturaType.
     * 
     * @param indicadorEntregaMaquina
     */
    public void setIndicadorEntregaMaquina(java.lang.Boolean indicadorEntregaMaquina) {
        this.indicadorEntregaMaquina = indicadorEntregaMaquina;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SolucaoCapturaType)) return false;
        SolucaoCapturaType other = (SolucaoCapturaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoSolucaoCaptura==null && other.getCodigoSolucaoCaptura()==null) || 
             (this.codigoSolucaoCaptura!=null &&
              this.codigoSolucaoCaptura.equals(other.getCodigoSolucaoCaptura()))) &&
            ((this.nome==null && other.getNome()==null) || 
             (this.nome!=null &&
              this.nome.equals(other.getNome()))) &&
            ((this.descricao==null && other.getDescricao()==null) || 
             (this.descricao!=null &&
              this.descricao.equals(other.getDescricao()))) &&
            ((this.indicadorEntregaMaquina==null && other.getIndicadorEntregaMaquina()==null) || 
             (this.indicadorEntregaMaquina!=null &&
              this.indicadorEntregaMaquina.equals(other.getIndicadorEntregaMaquina())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoSolucaoCaptura() != null) {
            _hashCode += getCodigoSolucaoCaptura().hashCode();
        }
        if (getNome() != null) {
            _hashCode += getNome().hashCode();
        }
        if (getDescricao() != null) {
            _hashCode += getDescricao().hashCode();
        }
        if (getIndicadorEntregaMaquina() != null) {
            _hashCode += getIndicadorEntregaMaquina().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SolucaoCapturaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarsolucaocapturaporferramenta", "SolucaoCapturaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarsolucaocapturaporferramenta", "codigoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nome");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarsolucaocapturaporferramenta", "nome"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricao");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarsolucaocapturaporferramenta", "descricao"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorEntregaMaquina");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarsolucaocapturaporferramenta", "indicadorEntregaMaquina"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
