package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento;

public class ConsultarListaFaturamentoServiceProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoService {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoService consultarListaFaturamentoService = null;
  
  public ConsultarListaFaturamentoServiceProxy() {
    _initConsultarListaFaturamentoServiceProxy();
  }
  
  public ConsultarListaFaturamentoServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarListaFaturamentoServiceProxy();
  }
  
  private void _initConsultarListaFaturamentoServiceProxy() {
    try {
      consultarListaFaturamentoService = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoServiceSoapBindingQSServiceLocator()).getConsultarListaFaturamentoServiceSoapBindingQSPort();
      if (consultarListaFaturamentoService != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarListaFaturamentoService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarListaFaturamentoService)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarListaFaturamentoService != null)
      ((javax.xml.rpc.Stub)consultarListaFaturamentoService)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoService getConsultarListaFaturamentoService() {
    if (consultarListaFaturamentoService == null)
      _initConsultarListaFaturamentoServiceProxy();
    return consultarListaFaturamentoService;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoResponseType consultarListaFaturamentoService(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoRequestType parameters) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (consultarListaFaturamentoService == null)
      _initConsultarListaFaturamentoServiceProxy();
    return consultarListaFaturamentoService.consultarListaFaturamentoService(header, parameters);
  }
  
  
}