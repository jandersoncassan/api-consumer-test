/**
 * TelefoneType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho;

public class TelefoneType  implements java.io.Serializable {
    /* Tipo que ndica o codigo do tipo do telefone
     * 					1-Residencial
     * 					2-Comercial
     * 					3-Celular
     * 					4-Recado
     * 					5-Fax */
    private java.lang.Integer tipoTelefone;

    private java.lang.Integer numeroDDD;

    private java.lang.String numeroTelefone;

    public TelefoneType() {
    }

    public TelefoneType(
           java.lang.Integer tipoTelefone,
           java.lang.Integer numeroDDD,
           java.lang.String numeroTelefone) {
           this.tipoTelefone = tipoTelefone;
           this.numeroDDD = numeroDDD;
           this.numeroTelefone = numeroTelefone;
    }


    /**
     * Gets the tipoTelefone value for this TelefoneType.
     * 
     * @return tipoTelefone   * Tipo que ndica o codigo do tipo do telefone
     * 					1-Residencial
     * 					2-Comercial
     * 					3-Celular
     * 					4-Recado
     * 					5-Fax
     */
    public java.lang.Integer getTipoTelefone() {
        return tipoTelefone;
    }


    /**
     * Sets the tipoTelefone value for this TelefoneType.
     * 
     * @param tipoTelefone   * Tipo que ndica o codigo do tipo do telefone
     * 					1-Residencial
     * 					2-Comercial
     * 					3-Celular
     * 					4-Recado
     * 					5-Fax
     */
    public void setTipoTelefone(java.lang.Integer tipoTelefone) {
        this.tipoTelefone = tipoTelefone;
    }


    /**
     * Gets the numeroDDD value for this TelefoneType.
     * 
     * @return numeroDDD
     */
    public java.lang.Integer getNumeroDDD() {
        return numeroDDD;
    }


    /**
     * Sets the numeroDDD value for this TelefoneType.
     * 
     * @param numeroDDD
     */
    public void setNumeroDDD(java.lang.Integer numeroDDD) {
        this.numeroDDD = numeroDDD;
    }


    /**
     * Gets the numeroTelefone value for this TelefoneType.
     * 
     * @return numeroTelefone
     */
    public java.lang.String getNumeroTelefone() {
        return numeroTelefone;
    }


    /**
     * Sets the numeroTelefone value for this TelefoneType.
     * 
     * @param numeroTelefone
     */
    public void setNumeroTelefone(java.lang.String numeroTelefone) {
        this.numeroTelefone = numeroTelefone;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof TelefoneType)) return false;
        TelefoneType other = (TelefoneType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.tipoTelefone==null && other.getTipoTelefone()==null) || 
             (this.tipoTelefone!=null &&
              this.tipoTelefone.equals(other.getTipoTelefone()))) &&
            ((this.numeroDDD==null && other.getNumeroDDD()==null) || 
             (this.numeroDDD!=null &&
              this.numeroDDD.equals(other.getNumeroDDD()))) &&
            ((this.numeroTelefone==null && other.getNumeroTelefone()==null) || 
             (this.numeroTelefone!=null &&
              this.numeroTelefone.equals(other.getNumeroTelefone())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTipoTelefone() != null) {
            _hashCode += getTipoTelefone().hashCode();
        }
        if (getNumeroDDD() != null) {
            _hashCode += getNumeroDDD().hashCode();
        }
        if (getNumeroTelefone() != null) {
            _hashCode += getNumeroTelefone().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(TelefoneType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "telefoneType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("tipoTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "tipoTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroDDD");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "numeroDDD"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroTelefone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "numeroTelefone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
