/**
 * CriticaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente;

public class CriticaType  implements java.io.Serializable {
    private java.lang.String codigoCritica;

    private java.lang.String descricaoCritica;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CampoType[] campos;

    public CriticaType() {
    }

    public CriticaType(
           java.lang.String codigoCritica,
           java.lang.String descricaoCritica,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CampoType[] campos) {
           this.codigoCritica = codigoCritica;
           this.descricaoCritica = descricaoCritica;
           this.campos = campos;
    }


    /**
     * Gets the codigoCritica value for this CriticaType.
     * 
     * @return codigoCritica
     */
    public java.lang.String getCodigoCritica() {
        return codigoCritica;
    }


    /**
     * Sets the codigoCritica value for this CriticaType.
     * 
     * @param codigoCritica
     */
    public void setCodigoCritica(java.lang.String codigoCritica) {
        this.codigoCritica = codigoCritica;
    }


    /**
     * Gets the descricaoCritica value for this CriticaType.
     * 
     * @return descricaoCritica
     */
    public java.lang.String getDescricaoCritica() {
        return descricaoCritica;
    }


    /**
     * Sets the descricaoCritica value for this CriticaType.
     * 
     * @param descricaoCritica
     */
    public void setDescricaoCritica(java.lang.String descricaoCritica) {
        this.descricaoCritica = descricaoCritica;
    }


    /**
     * Gets the campos value for this CriticaType.
     * 
     * @return campos
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CampoType[] getCampos() {
        return campos;
    }


    /**
     * Sets the campos value for this CriticaType.
     * 
     * @param campos
     */
    public void setCampos(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CampoType[] campos) {
        this.campos = campos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CriticaType)) return false;
        CriticaType other = (CriticaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoCritica==null && other.getCodigoCritica()==null) || 
             (this.codigoCritica!=null &&
              this.codigoCritica.equals(other.getCodigoCritica()))) &&
            ((this.descricaoCritica==null && other.getDescricaoCritica()==null) || 
             (this.descricaoCritica!=null &&
              this.descricaoCritica.equals(other.getDescricaoCritica()))) &&
            ((this.campos==null && other.getCampos()==null) || 
             (this.campos!=null &&
              java.util.Arrays.equals(this.campos, other.getCampos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoCritica() != null) {
            _hashCode += getCodigoCritica().hashCode();
        }
        if (getDescricaoCritica() != null) {
            _hashCode += getDescricaoCritica().hashCode();
        }
        if (getCampos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCampos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCampos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CriticaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "criticaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoCritica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoCritica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoCritica");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "descricaoCritica"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("campos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "campos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "campoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "campo"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
