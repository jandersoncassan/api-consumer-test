/**
 * AtualizarDadosParciaisPropostaRascunhoResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho;

public class AtualizarDadosParciaisPropostaRascunhoResponse  implements java.io.Serializable {
    private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimentoComercial;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] solucoesCaptura;

    /* 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE */
    private java.lang.Integer codigoFerramenta;

    private java.lang.String codigoStatus;

    private java.lang.String descricaoStatus;

    /* Indicador Agro S - Sim N - Não */
    private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoResponseIndicadorAgro indicadorAgro;

    private java.lang.Long numeroProposta;

    private java.lang.String loginUsuario;

    private java.lang.Integer codigoTipoPerfilSmart;

    private java.lang.String nomeExecutivo;

    public AtualizarDadosParciaisPropostaRascunhoResponse() {
    }

    public AtualizarDadosParciaisPropostaRascunhoResponse(
           br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimentoComercial,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] solucoesCaptura,
           java.lang.Integer codigoFerramenta,
           java.lang.String codigoStatus,
           java.lang.String descricaoStatus,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoResponseIndicadorAgro indicadorAgro,
           java.lang.Long numeroProposta,
           java.lang.String loginUsuario,
           java.lang.Integer codigoTipoPerfilSmart,
           java.lang.String nomeExecutivo) {
           this.estabelecimentoComercial = estabelecimentoComercial;
           this.solucoesCaptura = solucoesCaptura;
           this.codigoFerramenta = codigoFerramenta;
           this.codigoStatus = codigoStatus;
           this.descricaoStatus = descricaoStatus;
           this.indicadorAgro = indicadorAgro;
           this.numeroProposta = numeroProposta;
           this.loginUsuario = loginUsuario;
           this.codigoTipoPerfilSmart = codigoTipoPerfilSmart;
           this.nomeExecutivo = nomeExecutivo;
    }


    /**
     * Gets the estabelecimentoComercial value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return estabelecimentoComercial
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType getEstabelecimentoComercial() {
        return estabelecimentoComercial;
    }


    /**
     * Sets the estabelecimentoComercial value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param estabelecimentoComercial
     */
    public void setEstabelecimentoComercial(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimentoComercial) {
        this.estabelecimentoComercial = estabelecimentoComercial;
    }


    /**
     * Gets the solucoesCaptura value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return solucoesCaptura
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] getSolucoesCaptura() {
        return solucoesCaptura;
    }


    /**
     * Sets the solucoesCaptura value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param solucoesCaptura
     */
    public void setSolucoesCaptura(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] solucoesCaptura) {
        this.solucoesCaptura = solucoesCaptura;
    }


    /**
     * Gets the codigoFerramenta value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return codigoFerramenta   * 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE
     */
    public java.lang.Integer getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param codigoFerramenta   * 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE
     */
    public void setCodigoFerramenta(java.lang.Integer codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the codigoStatus value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return codigoStatus
     */
    public java.lang.String getCodigoStatus() {
        return codigoStatus;
    }


    /**
     * Sets the codigoStatus value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param codigoStatus
     */
    public void setCodigoStatus(java.lang.String codigoStatus) {
        this.codigoStatus = codigoStatus;
    }


    /**
     * Gets the descricaoStatus value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return descricaoStatus
     */
    public java.lang.String getDescricaoStatus() {
        return descricaoStatus;
    }


    /**
     * Sets the descricaoStatus value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param descricaoStatus
     */
    public void setDescricaoStatus(java.lang.String descricaoStatus) {
        this.descricaoStatus = descricaoStatus;
    }


    /**
     * Gets the indicadorAgro value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return indicadorAgro   * Indicador Agro S - Sim N - Não
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoResponseIndicadorAgro getIndicadorAgro() {
        return indicadorAgro;
    }


    /**
     * Sets the indicadorAgro value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param indicadorAgro   * Indicador Agro S - Sim N - Não
     */
    public void setIndicadorAgro(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoResponseIndicadorAgro indicadorAgro) {
        this.indicadorAgro = indicadorAgro;
    }


    /**
     * Gets the numeroProposta value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return numeroProposta
     */
    public java.lang.Long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(java.lang.Long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the loginUsuario value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return loginUsuario
     */
    public java.lang.String getLoginUsuario() {
        return loginUsuario;
    }


    /**
     * Sets the loginUsuario value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param loginUsuario
     */
    public void setLoginUsuario(java.lang.String loginUsuario) {
        this.loginUsuario = loginUsuario;
    }


    /**
     * Gets the codigoTipoPerfilSmart value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return codigoTipoPerfilSmart
     */
    public java.lang.Integer getCodigoTipoPerfilSmart() {
        return codigoTipoPerfilSmart;
    }


    /**
     * Sets the codigoTipoPerfilSmart value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param codigoTipoPerfilSmart
     */
    public void setCodigoTipoPerfilSmart(java.lang.Integer codigoTipoPerfilSmart) {
        this.codigoTipoPerfilSmart = codigoTipoPerfilSmart;
    }


    /**
     * Gets the nomeExecutivo value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @return nomeExecutivo
     */
    public java.lang.String getNomeExecutivo() {
        return nomeExecutivo;
    }


    /**
     * Sets the nomeExecutivo value for this AtualizarDadosParciaisPropostaRascunhoResponse.
     * 
     * @param nomeExecutivo
     */
    public void setNomeExecutivo(java.lang.String nomeExecutivo) {
        this.nomeExecutivo = nomeExecutivo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AtualizarDadosParciaisPropostaRascunhoResponse)) return false;
        AtualizarDadosParciaisPropostaRascunhoResponse other = (AtualizarDadosParciaisPropostaRascunhoResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.estabelecimentoComercial==null && other.getEstabelecimentoComercial()==null) || 
             (this.estabelecimentoComercial!=null &&
              this.estabelecimentoComercial.equals(other.getEstabelecimentoComercial()))) &&
            ((this.solucoesCaptura==null && other.getSolucoesCaptura()==null) || 
             (this.solucoesCaptura!=null &&
              java.util.Arrays.equals(this.solucoesCaptura, other.getSolucoesCaptura()))) &&
            ((this.codigoFerramenta==null && other.getCodigoFerramenta()==null) || 
             (this.codigoFerramenta!=null &&
              this.codigoFerramenta.equals(other.getCodigoFerramenta()))) &&
            ((this.codigoStatus==null && other.getCodigoStatus()==null) || 
             (this.codigoStatus!=null &&
              this.codigoStatus.equals(other.getCodigoStatus()))) &&
            ((this.descricaoStatus==null && other.getDescricaoStatus()==null) || 
             (this.descricaoStatus!=null &&
              this.descricaoStatus.equals(other.getDescricaoStatus()))) &&
            ((this.indicadorAgro==null && other.getIndicadorAgro()==null) || 
             (this.indicadorAgro!=null &&
              this.indicadorAgro.equals(other.getIndicadorAgro()))) &&
            ((this.numeroProposta==null && other.getNumeroProposta()==null) || 
             (this.numeroProposta!=null &&
              this.numeroProposta.equals(other.getNumeroProposta()))) &&
            ((this.loginUsuario==null && other.getLoginUsuario()==null) || 
             (this.loginUsuario!=null &&
              this.loginUsuario.equals(other.getLoginUsuario()))) &&
            ((this.codigoTipoPerfilSmart==null && other.getCodigoTipoPerfilSmart()==null) || 
             (this.codigoTipoPerfilSmart!=null &&
              this.codigoTipoPerfilSmart.equals(other.getCodigoTipoPerfilSmart()))) &&
            ((this.nomeExecutivo==null && other.getNomeExecutivo()==null) || 
             (this.nomeExecutivo!=null &&
              this.nomeExecutivo.equals(other.getNomeExecutivo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEstabelecimentoComercial() != null) {
            _hashCode += getEstabelecimentoComercial().hashCode();
        }
        if (getSolucoesCaptura() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSolucoesCaptura());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSolucoesCaptura(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodigoFerramenta() != null) {
            _hashCode += getCodigoFerramenta().hashCode();
        }
        if (getCodigoStatus() != null) {
            _hashCode += getCodigoStatus().hashCode();
        }
        if (getDescricaoStatus() != null) {
            _hashCode += getDescricaoStatus().hashCode();
        }
        if (getIndicadorAgro() != null) {
            _hashCode += getIndicadorAgro().hashCode();
        }
        if (getNumeroProposta() != null) {
            _hashCode += getNumeroProposta().hashCode();
        }
        if (getLoginUsuario() != null) {
            _hashCode += getLoginUsuario().hashCode();
        }
        if (getCodigoTipoPerfilSmart() != null) {
            _hashCode += getCodigoTipoPerfilSmart().hashCode();
        }
        if (getNomeExecutivo() != null) {
            _hashCode += getNomeExecutivo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AtualizarDadosParciaisPropostaRascunhoResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", ">atualizarDadosParciaisPropostaRascunhoResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "estabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "estabelecimentoComercialType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucoesCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "solucoesCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "solucaoCapturaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "solucaoCaptura"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "codigoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "descricaoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAgro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "indicadorAgro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", ">>atualizarDadosParciaisPropostaRascunhoResponse>indicadorAgro"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loginUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "loginUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPerfilSmart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "codigoTipoPerfilSmart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeExecutivo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "nomeExecutivo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
