/**
 * ConsultarListaFaturamentoResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento;

public class ConsultarListaFaturamentoResponseType  implements java.io.Serializable {
    private br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.FaturamentoType[] faturamentos;

    public ConsultarListaFaturamentoResponseType() {
    }

    public ConsultarListaFaturamentoResponseType(
           br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.FaturamentoType[] faturamentos) {
           this.faturamentos = faturamentos;
    }


    /**
     * Gets the faturamentos value for this ConsultarListaFaturamentoResponseType.
     * 
     * @return faturamentos
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.FaturamentoType[] getFaturamentos() {
        return faturamentos;
    }


    /**
     * Sets the faturamentos value for this ConsultarListaFaturamentoResponseType.
     * 
     * @param faturamentos
     */
    public void setFaturamentos(br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.FaturamentoType[] faturamentos) {
        this.faturamentos = faturamentos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarListaFaturamentoResponseType)) return false;
        ConsultarListaFaturamentoResponseType other = (ConsultarListaFaturamentoResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.faturamentos==null && other.getFaturamentos()==null) || 
             (this.faturamentos!=null &&
              java.util.Arrays.equals(this.faturamentos, other.getFaturamentos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFaturamentos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getFaturamentos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getFaturamentos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarListaFaturamentoResponseType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarlistafaturamento", "ConsultarListaFaturamentoResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("faturamentos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarlistafaturamento", "faturamentos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarlistafaturamento", "FaturamentoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarlistafaturamento", "faturamentos"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
