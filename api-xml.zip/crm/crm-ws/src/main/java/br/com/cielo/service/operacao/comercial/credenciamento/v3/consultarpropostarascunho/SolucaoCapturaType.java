/**
 * SolucaoCapturaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho;

public class SolucaoCapturaType  implements java.io.Serializable {
    private java.lang.Integer codigoSolucaoCaptura;

    private java.lang.Integer quantidadeEquipamentos;

    private java.lang.String codigoPacoteEcommerce;

    private java.lang.Boolean indicadorPagamentoPorLink;

    private int[] operadoras;

    private java.lang.String codigoHorarioFuncionamento;

    private java.lang.Boolean indicadorAutoServico;

    private java.lang.Boolean indicadorEntregaMaquina;

    public SolucaoCapturaType() {
    }

    public SolucaoCapturaType(
           java.lang.Integer codigoSolucaoCaptura,
           java.lang.Integer quantidadeEquipamentos,
           java.lang.String codigoPacoteEcommerce,
           java.lang.Boolean indicadorPagamentoPorLink,
           int[] operadoras,
           java.lang.String codigoHorarioFuncionamento,
           java.lang.Boolean indicadorAutoServico,
           java.lang.Boolean indicadorEntregaMaquina) {
           this.codigoSolucaoCaptura = codigoSolucaoCaptura;
           this.quantidadeEquipamentos = quantidadeEquipamentos;
           this.codigoPacoteEcommerce = codigoPacoteEcommerce;
           this.indicadorPagamentoPorLink = indicadorPagamentoPorLink;
           this.operadoras = operadoras;
           this.codigoHorarioFuncionamento = codigoHorarioFuncionamento;
           this.indicadorAutoServico = indicadorAutoServico;
           this.indicadorEntregaMaquina = indicadorEntregaMaquina;
    }


    /**
     * Gets the codigoSolucaoCaptura value for this SolucaoCapturaType.
     * 
     * @return codigoSolucaoCaptura
     */
    public java.lang.Integer getCodigoSolucaoCaptura() {
        return codigoSolucaoCaptura;
    }


    /**
     * Sets the codigoSolucaoCaptura value for this SolucaoCapturaType.
     * 
     * @param codigoSolucaoCaptura
     */
    public void setCodigoSolucaoCaptura(java.lang.Integer codigoSolucaoCaptura) {
        this.codigoSolucaoCaptura = codigoSolucaoCaptura;
    }


    /**
     * Gets the quantidadeEquipamentos value for this SolucaoCapturaType.
     * 
     * @return quantidadeEquipamentos
     */
    public java.lang.Integer getQuantidadeEquipamentos() {
        return quantidadeEquipamentos;
    }


    /**
     * Sets the quantidadeEquipamentos value for this SolucaoCapturaType.
     * 
     * @param quantidadeEquipamentos
     */
    public void setQuantidadeEquipamentos(java.lang.Integer quantidadeEquipamentos) {
        this.quantidadeEquipamentos = quantidadeEquipamentos;
    }


    /**
     * Gets the codigoPacoteEcommerce value for this SolucaoCapturaType.
     * 
     * @return codigoPacoteEcommerce
     */
    public java.lang.String getCodigoPacoteEcommerce() {
        return codigoPacoteEcommerce;
    }


    /**
     * Sets the codigoPacoteEcommerce value for this SolucaoCapturaType.
     * 
     * @param codigoPacoteEcommerce
     */
    public void setCodigoPacoteEcommerce(java.lang.String codigoPacoteEcommerce) {
        this.codigoPacoteEcommerce = codigoPacoteEcommerce;
    }


    /**
     * Gets the indicadorPagamentoPorLink value for this SolucaoCapturaType.
     * 
     * @return indicadorPagamentoPorLink
     */
    public java.lang.Boolean getIndicadorPagamentoPorLink() {
        return indicadorPagamentoPorLink;
    }


    /**
     * Sets the indicadorPagamentoPorLink value for this SolucaoCapturaType.
     * 
     * @param indicadorPagamentoPorLink
     */
    public void setIndicadorPagamentoPorLink(java.lang.Boolean indicadorPagamentoPorLink) {
        this.indicadorPagamentoPorLink = indicadorPagamentoPorLink;
    }


    /**
     * Gets the operadoras value for this SolucaoCapturaType.
     * 
     * @return operadoras
     */
    public int[] getOperadoras() {
        return operadoras;
    }


    /**
     * Sets the operadoras value for this SolucaoCapturaType.
     * 
     * @param operadoras
     */
    public void setOperadoras(int[] operadoras) {
        this.operadoras = operadoras;
    }


    /**
     * Gets the codigoHorarioFuncionamento value for this SolucaoCapturaType.
     * 
     * @return codigoHorarioFuncionamento
     */
    public java.lang.String getCodigoHorarioFuncionamento() {
        return codigoHorarioFuncionamento;
    }


    /**
     * Sets the codigoHorarioFuncionamento value for this SolucaoCapturaType.
     * 
     * @param codigoHorarioFuncionamento
     */
    public void setCodigoHorarioFuncionamento(java.lang.String codigoHorarioFuncionamento) {
        this.codigoHorarioFuncionamento = codigoHorarioFuncionamento;
    }


    /**
     * Gets the indicadorAutoServico value for this SolucaoCapturaType.
     * 
     * @return indicadorAutoServico
     */
    public java.lang.Boolean getIndicadorAutoServico() {
        return indicadorAutoServico;
    }


    /**
     * Sets the indicadorAutoServico value for this SolucaoCapturaType.
     * 
     * @param indicadorAutoServico
     */
    public void setIndicadorAutoServico(java.lang.Boolean indicadorAutoServico) {
        this.indicadorAutoServico = indicadorAutoServico;
    }


    /**
     * Gets the indicadorEntregaMaquina value for this SolucaoCapturaType.
     * 
     * @return indicadorEntregaMaquina
     */
    public java.lang.Boolean getIndicadorEntregaMaquina() {
        return indicadorEntregaMaquina;
    }


    /**
     * Sets the indicadorEntregaMaquina value for this SolucaoCapturaType.
     * 
     * @param indicadorEntregaMaquina
     */
    public void setIndicadorEntregaMaquina(java.lang.Boolean indicadorEntregaMaquina) {
        this.indicadorEntregaMaquina = indicadorEntregaMaquina;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof SolucaoCapturaType)) return false;
        SolucaoCapturaType other = (SolucaoCapturaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoSolucaoCaptura==null && other.getCodigoSolucaoCaptura()==null) || 
             (this.codigoSolucaoCaptura!=null &&
              this.codigoSolucaoCaptura.equals(other.getCodigoSolucaoCaptura()))) &&
            ((this.quantidadeEquipamentos==null && other.getQuantidadeEquipamentos()==null) || 
             (this.quantidadeEquipamentos!=null &&
              this.quantidadeEquipamentos.equals(other.getQuantidadeEquipamentos()))) &&
            ((this.codigoPacoteEcommerce==null && other.getCodigoPacoteEcommerce()==null) || 
             (this.codigoPacoteEcommerce!=null &&
              this.codigoPacoteEcommerce.equals(other.getCodigoPacoteEcommerce()))) &&
            ((this.indicadorPagamentoPorLink==null && other.getIndicadorPagamentoPorLink()==null) || 
             (this.indicadorPagamentoPorLink!=null &&
              this.indicadorPagamentoPorLink.equals(other.getIndicadorPagamentoPorLink()))) &&
            ((this.operadoras==null && other.getOperadoras()==null) || 
             (this.operadoras!=null &&
              java.util.Arrays.equals(this.operadoras, other.getOperadoras()))) &&
            ((this.codigoHorarioFuncionamento==null && other.getCodigoHorarioFuncionamento()==null) || 
             (this.codigoHorarioFuncionamento!=null &&
              this.codigoHorarioFuncionamento.equals(other.getCodigoHorarioFuncionamento()))) &&
            ((this.indicadorAutoServico==null && other.getIndicadorAutoServico()==null) || 
             (this.indicadorAutoServico!=null &&
              this.indicadorAutoServico.equals(other.getIndicadorAutoServico()))) &&
            ((this.indicadorEntregaMaquina==null && other.getIndicadorEntregaMaquina()==null) || 
             (this.indicadorEntregaMaquina!=null &&
              this.indicadorEntregaMaquina.equals(other.getIndicadorEntregaMaquina())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoSolucaoCaptura() != null) {
            _hashCode += getCodigoSolucaoCaptura().hashCode();
        }
        if (getQuantidadeEquipamentos() != null) {
            _hashCode += getQuantidadeEquipamentos().hashCode();
        }
        if (getCodigoPacoteEcommerce() != null) {
            _hashCode += getCodigoPacoteEcommerce().hashCode();
        }
        if (getIndicadorPagamentoPorLink() != null) {
            _hashCode += getIndicadorPagamentoPorLink().hashCode();
        }
        if (getOperadoras() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getOperadoras());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getOperadoras(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getCodigoHorarioFuncionamento() != null) {
            _hashCode += getCodigoHorarioFuncionamento().hashCode();
        }
        if (getIndicadorAutoServico() != null) {
            _hashCode += getIndicadorAutoServico().hashCode();
        }
        if (getIndicadorEntregaMaquina() != null) {
            _hashCode += getIndicadorEntregaMaquina().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(SolucaoCapturaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "solucaoCapturaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoSolucaoCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "codigoSolucaoCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("quantidadeEquipamentos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "quantidadeEquipamentos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoPacoteEcommerce");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "codigoPacoteEcommerce"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorPagamentoPorLink");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "indicadorPagamentoPorLink"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("operadoras");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "operadoras"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "codigoOperadora"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoHorarioFuncionamento");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "codigoHorarioFuncionamento"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAutoServico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "indicadorAutoServico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorEntregaMaquina");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "indicadorEntregaMaquina"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
