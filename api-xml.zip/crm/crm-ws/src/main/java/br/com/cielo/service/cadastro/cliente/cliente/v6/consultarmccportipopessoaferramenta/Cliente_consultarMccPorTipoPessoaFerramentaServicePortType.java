/**
 * Cliente_consultarMccPorTipoPessoaFerramentaServicePortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta;

public interface Cliente_consultarMccPorTipoPessoaFerramentaServicePortType extends java.rmi.Remote {

    /**
     * Operacao responsavel por consultar MCC por tipo de pessoa e
     * ferramenta(Canal de atendimento)
     */
    public br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaResponseType consultarMccPorTipoPessoaFerramenta(br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaRequestType parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
