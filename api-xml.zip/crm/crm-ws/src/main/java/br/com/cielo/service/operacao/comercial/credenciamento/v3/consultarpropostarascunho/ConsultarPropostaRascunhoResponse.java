/**
 * ConsultarPropostaRascunhoResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho;

public class ConsultarPropostaRascunhoResponse  implements java.io.Serializable {
    private br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.PropostaRascunhoType propostaRascunho;

    public ConsultarPropostaRascunhoResponse() {
    }

    public ConsultarPropostaRascunhoResponse(
           br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.PropostaRascunhoType propostaRascunho) {
           this.propostaRascunho = propostaRascunho;
    }


    /**
     * Gets the propostaRascunho value for this ConsultarPropostaRascunhoResponse.
     * 
     * @return propostaRascunho
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.PropostaRascunhoType getPropostaRascunho() {
        return propostaRascunho;
    }


    /**
     * Sets the propostaRascunho value for this ConsultarPropostaRascunhoResponse.
     * 
     * @param propostaRascunho
     */
    public void setPropostaRascunho(br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.PropostaRascunhoType propostaRascunho) {
        this.propostaRascunho = propostaRascunho;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarPropostaRascunhoResponse)) return false;
        ConsultarPropostaRascunhoResponse other = (ConsultarPropostaRascunhoResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.propostaRascunho==null && other.getPropostaRascunho()==null) || 
             (this.propostaRascunho!=null &&
              this.propostaRascunho.equals(other.getPropostaRascunho())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getPropostaRascunho() != null) {
            _hashCode += getPropostaRascunho().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarPropostaRascunhoResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", ">consultarPropostaRascunhoResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("propostaRascunho");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "propostaRascunho"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "propostaRascunhoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
