/**
 * Banco_ValidarDigitoAgenciaContaService_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta;

public interface Banco_ValidarDigitoAgenciaContaService_Service extends javax.xml.rpc.Service {
    public java.lang.String getBancoSOAPAddress();

    public br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_PortType getBancoSOAP() throws javax.xml.rpc.ServiceException;

    public br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_PortType getBancoSOAP(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
