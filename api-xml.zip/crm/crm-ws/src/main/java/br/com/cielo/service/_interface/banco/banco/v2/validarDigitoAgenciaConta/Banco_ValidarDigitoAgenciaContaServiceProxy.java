package br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta;

public class Banco_ValidarDigitoAgenciaContaServiceProxy implements br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_PortType {
  private String _endpoint = null;
  private br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_PortType banco_ValidarDigitoAgenciaContaService_PortType = null;
  
  public Banco_ValidarDigitoAgenciaContaServiceProxy() {
    _initBanco_ValidarDigitoAgenciaContaServiceProxy();
  }
  
  public Banco_ValidarDigitoAgenciaContaServiceProxy(String endpoint) {
    _endpoint = endpoint;
    _initBanco_ValidarDigitoAgenciaContaServiceProxy();
  }
  
  private void _initBanco_ValidarDigitoAgenciaContaServiceProxy() {
    try {
      banco_ValidarDigitoAgenciaContaService_PortType = (new br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_ServiceLocator()).getBancoSOAP();
      if (banco_ValidarDigitoAgenciaContaService_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)banco_ValidarDigitoAgenciaContaService_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)banco_ValidarDigitoAgenciaContaService_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (banco_ValidarDigitoAgenciaContaService_PortType != null)
      ((javax.xml.rpc.Stub)banco_ValidarDigitoAgenciaContaService_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_PortType getBanco_ValidarDigitoAgenciaContaService_PortType() {
    if (banco_ValidarDigitoAgenciaContaService_PortType == null)
      _initBanco_ValidarDigitoAgenciaContaServiceProxy();
    return banco_ValidarDigitoAgenciaContaService_PortType;
  }
  
  public br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaResponse validarDigitoAgenciaConta(br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (banco_ValidarDigitoAgenciaContaService_PortType == null)
      _initBanco_ValidarDigitoAgenciaContaServiceProxy();
    return banco_ValidarDigitoAgenciaContaService_PortType.validarDigitoAgenciaConta(parameters, header);
  }
  
  
}