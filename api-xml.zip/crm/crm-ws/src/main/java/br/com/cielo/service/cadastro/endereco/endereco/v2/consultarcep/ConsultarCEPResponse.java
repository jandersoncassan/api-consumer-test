/**
 * ConsultarCEPResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep;

public class ConsultarCEPResponse  implements java.io.Serializable {
    private br.com.cielo.canonico.cadastro.v1.Endereco[] enderecos;

    public ConsultarCEPResponse() {
    }

    public ConsultarCEPResponse(
           br.com.cielo.canonico.cadastro.v1.Endereco[] enderecos) {
           this.enderecos = enderecos;
    }


    /**
     * Gets the enderecos value for this ConsultarCEPResponse.
     * 
     * @return enderecos
     */
    public br.com.cielo.canonico.cadastro.v1.Endereco[] getEnderecos() {
        return enderecos;
    }


    /**
     * Sets the enderecos value for this ConsultarCEPResponse.
     * 
     * @param enderecos
     */
    public void setEnderecos(br.com.cielo.canonico.cadastro.v1.Endereco[] enderecos) {
        this.enderecos = enderecos;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarCEPResponse)) return false;
        ConsultarCEPResponse other = (ConsultarCEPResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.enderecos==null && other.getEnderecos()==null) || 
             (this.enderecos!=null &&
              java.util.Arrays.equals(this.enderecos, other.getEnderecos())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getEnderecos() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getEnderecos());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getEnderecos(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarCEPResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/endereco/endereco/v2/consultarcep", ">consultarCEPResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enderecos");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/endereco/endereco/v2/consultarcep", "enderecos"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "Endereco"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://canonico.cielo.com.br/cadastro/v1", "enderecos"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
