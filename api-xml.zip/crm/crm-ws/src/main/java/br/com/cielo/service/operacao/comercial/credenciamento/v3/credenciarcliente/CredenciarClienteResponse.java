/**
 * CredenciarClienteResponse.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente;

public class CredenciarClienteResponse  implements java.io.Serializable {
    /* Tipo que indica o Status
     * 
     * 							OK-Sucesso NOK-InSucesso */
    private java.lang.String codigoStatus;

    private java.lang.String descricaoStatus;

    private java.lang.Long numeroProposta;

    private java.lang.Long numeroEc;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CriticaType[] criticas;

    public CredenciarClienteResponse() {
    }

    public CredenciarClienteResponse(
           java.lang.String codigoStatus,
           java.lang.String descricaoStatus,
           java.lang.Long numeroProposta,
           java.lang.Long numeroEc,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CriticaType[] criticas) {
           this.codigoStatus = codigoStatus;
           this.descricaoStatus = descricaoStatus;
           this.numeroProposta = numeroProposta;
           this.numeroEc = numeroEc;
           this.criticas = criticas;
    }


    /**
     * Gets the codigoStatus value for this CredenciarClienteResponse.
     * 
     * @return codigoStatus   * Tipo que indica o Status
     * 
     * 							OK-Sucesso NOK-InSucesso
     */
    public java.lang.String getCodigoStatus() {
        return codigoStatus;
    }


    /**
     * Sets the codigoStatus value for this CredenciarClienteResponse.
     * 
     * @param codigoStatus   * Tipo que indica o Status
     * 
     * 							OK-Sucesso NOK-InSucesso
     */
    public void setCodigoStatus(java.lang.String codigoStatus) {
        this.codigoStatus = codigoStatus;
    }


    /**
     * Gets the descricaoStatus value for this CredenciarClienteResponse.
     * 
     * @return descricaoStatus
     */
    public java.lang.String getDescricaoStatus() {
        return descricaoStatus;
    }


    /**
     * Sets the descricaoStatus value for this CredenciarClienteResponse.
     * 
     * @param descricaoStatus
     */
    public void setDescricaoStatus(java.lang.String descricaoStatus) {
        this.descricaoStatus = descricaoStatus;
    }


    /**
     * Gets the numeroProposta value for this CredenciarClienteResponse.
     * 
     * @return numeroProposta
     */
    public java.lang.Long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this CredenciarClienteResponse.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(java.lang.Long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the numeroEc value for this CredenciarClienteResponse.
     * 
     * @return numeroEc
     */
    public java.lang.Long getNumeroEc() {
        return numeroEc;
    }


    /**
     * Sets the numeroEc value for this CredenciarClienteResponse.
     * 
     * @param numeroEc
     */
    public void setNumeroEc(java.lang.Long numeroEc) {
        this.numeroEc = numeroEc;
    }


    /**
     * Gets the criticas value for this CredenciarClienteResponse.
     * 
     * @return criticas
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CriticaType[] getCriticas() {
        return criticas;
    }


    /**
     * Sets the criticas value for this CredenciarClienteResponse.
     * 
     * @param criticas
     */
    public void setCriticas(br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CriticaType[] criticas) {
        this.criticas = criticas;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CredenciarClienteResponse)) return false;
        CredenciarClienteResponse other = (CredenciarClienteResponse) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codigoStatus==null && other.getCodigoStatus()==null) || 
             (this.codigoStatus!=null &&
              this.codigoStatus.equals(other.getCodigoStatus()))) &&
            ((this.descricaoStatus==null && other.getDescricaoStatus()==null) || 
             (this.descricaoStatus!=null &&
              this.descricaoStatus.equals(other.getDescricaoStatus()))) &&
            ((this.numeroProposta==null && other.getNumeroProposta()==null) || 
             (this.numeroProposta!=null &&
              this.numeroProposta.equals(other.getNumeroProposta()))) &&
            ((this.numeroEc==null && other.getNumeroEc()==null) || 
             (this.numeroEc!=null &&
              this.numeroEc.equals(other.getNumeroEc()))) &&
            ((this.criticas==null && other.getCriticas()==null) || 
             (this.criticas!=null &&
              java.util.Arrays.equals(this.criticas, other.getCriticas())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodigoStatus() != null) {
            _hashCode += getCodigoStatus().hashCode();
        }
        if (getDescricaoStatus() != null) {
            _hashCode += getDescricaoStatus().hashCode();
        }
        if (getNumeroProposta() != null) {
            _hashCode += getNumeroProposta().hashCode();
        }
        if (getNumeroEc() != null) {
            _hashCode += getNumeroEc().hashCode();
        }
        if (getCriticas() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getCriticas());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getCriticas(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CredenciarClienteResponse.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", ">credenciarClienteResponse"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "codigoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "descricaoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "numeroEc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("criticas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "criticas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "criticaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/credenciarcliente", "critica"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
