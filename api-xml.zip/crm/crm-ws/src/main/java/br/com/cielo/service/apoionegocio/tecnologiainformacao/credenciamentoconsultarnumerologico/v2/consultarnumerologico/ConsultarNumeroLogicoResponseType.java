/**
 * ConsultarNumeroLogicoResponseType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico;

public class ConsultarNumeroLogicoResponseType  implements java.io.Serializable {
    private java.lang.Integer status;

    private java.lang.String descricaoStatus;

    /* Lista com os numeros Logico  */
    private br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.NumeroLogicoType[] numerosLogico;

    public ConsultarNumeroLogicoResponseType() {
    }

    public ConsultarNumeroLogicoResponseType(
           java.lang.Integer status,
           java.lang.String descricaoStatus,
           br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.NumeroLogicoType[] numerosLogico) {
           this.status = status;
           this.descricaoStatus = descricaoStatus;
           this.numerosLogico = numerosLogico;
    }


    /**
     * Gets the status value for this ConsultarNumeroLogicoResponseType.
     * 
     * @return status
     */
    public java.lang.Integer getStatus() {
        return status;
    }


    /**
     * Sets the status value for this ConsultarNumeroLogicoResponseType.
     * 
     * @param status
     */
    public void setStatus(java.lang.Integer status) {
        this.status = status;
    }


    /**
     * Gets the descricaoStatus value for this ConsultarNumeroLogicoResponseType.
     * 
     * @return descricaoStatus
     */
    public java.lang.String getDescricaoStatus() {
        return descricaoStatus;
    }


    /**
     * Sets the descricaoStatus value for this ConsultarNumeroLogicoResponseType.
     * 
     * @param descricaoStatus
     */
    public void setDescricaoStatus(java.lang.String descricaoStatus) {
        this.descricaoStatus = descricaoStatus;
    }


    /**
     * Gets the numerosLogico value for this ConsultarNumeroLogicoResponseType.
     * 
     * @return numerosLogico   * Lista com os numeros Logico 
     */
    public br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.NumeroLogicoType[] getNumerosLogico() {
        return numerosLogico;
    }


    /**
     * Sets the numerosLogico value for this ConsultarNumeroLogicoResponseType.
     * 
     * @param numerosLogico   * Lista com os numeros Logico 
     */
    public void setNumerosLogico(br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.NumeroLogicoType[] numerosLogico) {
        this.numerosLogico = numerosLogico;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ConsultarNumeroLogicoResponseType)) return false;
        ConsultarNumeroLogicoResponseType other = (ConsultarNumeroLogicoResponseType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.status==null && other.getStatus()==null) || 
             (this.status!=null &&
              this.status.equals(other.getStatus()))) &&
            ((this.descricaoStatus==null && other.getDescricaoStatus()==null) || 
             (this.descricaoStatus!=null &&
              this.descricaoStatus.equals(other.getDescricaoStatus()))) &&
            ((this.numerosLogico==null && other.getNumerosLogico()==null) || 
             (this.numerosLogico!=null &&
              java.util.Arrays.equals(this.numerosLogico, other.getNumerosLogico())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getStatus() != null) {
            _hashCode += getStatus().hashCode();
        }
        if (getDescricaoStatus() != null) {
            _hashCode += getDescricaoStatus().hashCode();
        }
        if (getNumerosLogico() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getNumerosLogico());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getNumerosLogico(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ConsultarNumeroLogicoResponseType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/apoionegocio/tecnologiainformacao/credenciamentoconsultarnumerologico/v2/consultarnumerologico", "consultarNumeroLogicoResponseType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("status");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/apoionegocio/tecnologiainformacao/credenciamentoconsultarnumerologico/v2/consultarnumerologico", "status"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descricaoStatus");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/apoionegocio/tecnologiainformacao/credenciamentoconsultarnumerologico/v2/consultarnumerologico", "descricaoStatus"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numerosLogico");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/apoionegocio/tecnologiainformacao/credenciamentoconsultarnumerologico/v2/consultarnumerologico", "numerosLogico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/apoionegocio/tecnologiainformacao/credenciamentoconsultarnumerologico/v2/consultarnumerologico", "NumeroLogicoType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/apoionegocio/tecnologiainformacao/credenciamentoconsultarnumerologico/v2/consultarnumerologico", "numeroLogico"));
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
