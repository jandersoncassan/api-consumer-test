/**
 * CieloSoapHeaderType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.canonico.governancasoa.comum.v1;

public class CieloSoapHeaderType  implements java.io.Serializable {
    private br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType usuario;

    private java.lang.String token;

    private java.lang.String recurso;

    private java.lang.String realm;

    private br.com.cielo.canonico.governancasoa.comum.v1.IdentificacaoRequestType identificacaoRequest;

    public CieloSoapHeaderType() {
    }

    public CieloSoapHeaderType(
           br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType usuario,
           java.lang.String token,
           java.lang.String recurso,
           java.lang.String realm,
           br.com.cielo.canonico.governancasoa.comum.v1.IdentificacaoRequestType identificacaoRequest) {
           this.usuario = usuario;
           this.token = token;
           this.recurso = recurso;
           this.realm = realm;
           this.identificacaoRequest = identificacaoRequest;
    }


    /**
     * Gets the usuario value for this CieloSoapHeaderType.
     * 
     * @return usuario
     */
    public br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType getUsuario() {
        return usuario;
    }


    /**
     * Sets the usuario value for this CieloSoapHeaderType.
     * 
     * @param usuario
     */
    public void setUsuario(br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType usuario) {
        this.usuario = usuario;
    }


    /**
     * Gets the token value for this CieloSoapHeaderType.
     * 
     * @return token
     */
    public java.lang.String getToken() {
        return token;
    }


    /**
     * Sets the token value for this CieloSoapHeaderType.
     * 
     * @param token
     */
    public void setToken(java.lang.String token) {
        this.token = token;
    }


    /**
     * Gets the recurso value for this CieloSoapHeaderType.
     * 
     * @return recurso
     */
    public java.lang.String getRecurso() {
        return recurso;
    }


    /**
     * Sets the recurso value for this CieloSoapHeaderType.
     * 
     * @param recurso
     */
    public void setRecurso(java.lang.String recurso) {
        this.recurso = recurso;
    }


    /**
     * Gets the realm value for this CieloSoapHeaderType.
     * 
     * @return realm
     */
    public java.lang.String getRealm() {
        return realm;
    }


    /**
     * Sets the realm value for this CieloSoapHeaderType.
     * 
     * @param realm
     */
    public void setRealm(java.lang.String realm) {
        this.realm = realm;
    }


    /**
     * Gets the identificacaoRequest value for this CieloSoapHeaderType.
     * 
     * @return identificacaoRequest
     */
    public br.com.cielo.canonico.governancasoa.comum.v1.IdentificacaoRequestType getIdentificacaoRequest() {
        return identificacaoRequest;
    }


    /**
     * Sets the identificacaoRequest value for this CieloSoapHeaderType.
     * 
     * @param identificacaoRequest
     */
    public void setIdentificacaoRequest(br.com.cielo.canonico.governancasoa.comum.v1.IdentificacaoRequestType identificacaoRequest) {
        this.identificacaoRequest = identificacaoRequest;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CieloSoapHeaderType)) return false;
        CieloSoapHeaderType other = (CieloSoapHeaderType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.usuario==null && other.getUsuario()==null) || 
             (this.usuario!=null &&
              this.usuario.equals(other.getUsuario()))) &&
            ((this.token==null && other.getToken()==null) || 
             (this.token!=null &&
              this.token.equals(other.getToken()))) &&
            ((this.recurso==null && other.getRecurso()==null) || 
             (this.recurso!=null &&
              this.recurso.equals(other.getRecurso()))) &&
            ((this.realm==null && other.getRealm()==null) || 
             (this.realm!=null &&
              this.realm.equals(other.getRealm()))) &&
            ((this.identificacaoRequest==null && other.getIdentificacaoRequest()==null) || 
             (this.identificacaoRequest!=null &&
              this.identificacaoRequest.equals(other.getIdentificacaoRequest())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getUsuario() != null) {
            _hashCode += getUsuario().hashCode();
        }
        if (getToken() != null) {
            _hashCode += getToken().hashCode();
        }
        if (getRecurso() != null) {
            _hashCode += getRecurso().hashCode();
        }
        if (getRealm() != null) {
            _hashCode += getRealm().hashCode();
        }
        if (getIdentificacaoRequest() != null) {
            _hashCode += getIdentificacaoRequest().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CieloSoapHeaderType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "CieloSoapHeaderType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("usuario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "usuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "UsuarioType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("token");
        elemField.setXmlName(new javax.xml.namespace.QName("", "token"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("recurso");
        elemField.setXmlName(new javax.xml.namespace.QName("", "recurso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("realm");
        elemField.setXmlName(new javax.xml.namespace.QName("", "realm"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("identificacaoRequest");
        elemField.setXmlName(new javax.xml.namespace.QName("", "identificacaoRequest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://canonico.cielo.com.br/governancasoa/comum/v1", "IdentificacaoRequestType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
