/**
 * CadeiaForcadaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho;

public class CadeiaForcadaType  implements java.io.Serializable {
    private java.lang.Long numeroEc;

    private java.lang.Long numeroEcEspelho;

    private java.lang.Boolean indicadorEspelhamentoTaxa;

    public CadeiaForcadaType() {
    }

    public CadeiaForcadaType(
           java.lang.Long numeroEc,
           java.lang.Long numeroEcEspelho,
           java.lang.Boolean indicadorEspelhamentoTaxa) {
           this.numeroEc = numeroEc;
           this.numeroEcEspelho = numeroEcEspelho;
           this.indicadorEspelhamentoTaxa = indicadorEspelhamentoTaxa;
    }


    /**
     * Gets the numeroEc value for this CadeiaForcadaType.
     * 
     * @return numeroEc
     */
    public java.lang.Long getNumeroEc() {
        return numeroEc;
    }


    /**
     * Sets the numeroEc value for this CadeiaForcadaType.
     * 
     * @param numeroEc
     */
    public void setNumeroEc(java.lang.Long numeroEc) {
        this.numeroEc = numeroEc;
    }


    /**
     * Gets the numeroEcEspelho value for this CadeiaForcadaType.
     * 
     * @return numeroEcEspelho
     */
    public java.lang.Long getNumeroEcEspelho() {
        return numeroEcEspelho;
    }


    /**
     * Sets the numeroEcEspelho value for this CadeiaForcadaType.
     * 
     * @param numeroEcEspelho
     */
    public void setNumeroEcEspelho(java.lang.Long numeroEcEspelho) {
        this.numeroEcEspelho = numeroEcEspelho;
    }


    /**
     * Gets the indicadorEspelhamentoTaxa value for this CadeiaForcadaType.
     * 
     * @return indicadorEspelhamentoTaxa
     */
    public java.lang.Boolean getIndicadorEspelhamentoTaxa() {
        return indicadorEspelhamentoTaxa;
    }


    /**
     * Sets the indicadorEspelhamentoTaxa value for this CadeiaForcadaType.
     * 
     * @param indicadorEspelhamentoTaxa
     */
    public void setIndicadorEspelhamentoTaxa(java.lang.Boolean indicadorEspelhamentoTaxa) {
        this.indicadorEspelhamentoTaxa = indicadorEspelhamentoTaxa;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof CadeiaForcadaType)) return false;
        CadeiaForcadaType other = (CadeiaForcadaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.numeroEc==null && other.getNumeroEc()==null) || 
             (this.numeroEc!=null &&
              this.numeroEc.equals(other.getNumeroEc()))) &&
            ((this.numeroEcEspelho==null && other.getNumeroEcEspelho()==null) || 
             (this.numeroEcEspelho!=null &&
              this.numeroEcEspelho.equals(other.getNumeroEcEspelho()))) &&
            ((this.indicadorEspelhamentoTaxa==null && other.getIndicadorEspelhamentoTaxa()==null) || 
             (this.indicadorEspelhamentoTaxa!=null &&
              this.indicadorEspelhamentoTaxa.equals(other.getIndicadorEspelhamentoTaxa())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getNumeroEc() != null) {
            _hashCode += getNumeroEc().hashCode();
        }
        if (getNumeroEcEspelho() != null) {
            _hashCode += getNumeroEcEspelho().hashCode();
        }
        if (getIndicadorEspelhamentoTaxa() != null) {
            _hashCode += getIndicadorEspelhamentoTaxa().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(CadeiaForcadaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "CadeiaForcadaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "numeroEc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroEcEspelho");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "numeroEcEspelho"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorEspelhamentoTaxa");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarpropostarascunho", "indicadorEspelhamentoTaxa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
