/**
 * OfertaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho;

public class OfertaType  implements java.io.Serializable {
    private java.lang.Boolean indicadorOfertaAssociada;

    private java.lang.Boolean indicadorAceiteOferta;

    private java.lang.String nivelOferta;

    private java.lang.String codigoOferta;

    private java.lang.Integer codigoOfertaComboAluguel;

    public OfertaType() {
    }

    public OfertaType(
           java.lang.Boolean indicadorOfertaAssociada,
           java.lang.Boolean indicadorAceiteOferta,
           java.lang.String nivelOferta,
           java.lang.String codigoOferta,
           java.lang.Integer codigoOfertaComboAluguel) {
           this.indicadorOfertaAssociada = indicadorOfertaAssociada;
           this.indicadorAceiteOferta = indicadorAceiteOferta;
           this.nivelOferta = nivelOferta;
           this.codigoOferta = codigoOferta;
           this.codigoOfertaComboAluguel = codigoOfertaComboAluguel;
    }


    /**
     * Gets the indicadorOfertaAssociada value for this OfertaType.
     * 
     * @return indicadorOfertaAssociada
     */
    public java.lang.Boolean getIndicadorOfertaAssociada() {
        return indicadorOfertaAssociada;
    }


    /**
     * Sets the indicadorOfertaAssociada value for this OfertaType.
     * 
     * @param indicadorOfertaAssociada
     */
    public void setIndicadorOfertaAssociada(java.lang.Boolean indicadorOfertaAssociada) {
        this.indicadorOfertaAssociada = indicadorOfertaAssociada;
    }


    /**
     * Gets the indicadorAceiteOferta value for this OfertaType.
     * 
     * @return indicadorAceiteOferta
     */
    public java.lang.Boolean getIndicadorAceiteOferta() {
        return indicadorAceiteOferta;
    }


    /**
     * Sets the indicadorAceiteOferta value for this OfertaType.
     * 
     * @param indicadorAceiteOferta
     */
    public void setIndicadorAceiteOferta(java.lang.Boolean indicadorAceiteOferta) {
        this.indicadorAceiteOferta = indicadorAceiteOferta;
    }


    /**
     * Gets the nivelOferta value for this OfertaType.
     * 
     * @return nivelOferta
     */
    public java.lang.String getNivelOferta() {
        return nivelOferta;
    }


    /**
     * Sets the nivelOferta value for this OfertaType.
     * 
     * @param nivelOferta
     */
    public void setNivelOferta(java.lang.String nivelOferta) {
        this.nivelOferta = nivelOferta;
    }


    /**
     * Gets the codigoOferta value for this OfertaType.
     * 
     * @return codigoOferta
     */
    public java.lang.String getCodigoOferta() {
        return codigoOferta;
    }


    /**
     * Sets the codigoOferta value for this OfertaType.
     * 
     * @param codigoOferta
     */
    public void setCodigoOferta(java.lang.String codigoOferta) {
        this.codigoOferta = codigoOferta;
    }


    /**
     * Gets the codigoOfertaComboAluguel value for this OfertaType.
     * 
     * @return codigoOfertaComboAluguel
     */
    public java.lang.Integer getCodigoOfertaComboAluguel() {
        return codigoOfertaComboAluguel;
    }


    /**
     * Sets the codigoOfertaComboAluguel value for this OfertaType.
     * 
     * @param codigoOfertaComboAluguel
     */
    public void setCodigoOfertaComboAluguel(java.lang.Integer codigoOfertaComboAluguel) {
        this.codigoOfertaComboAluguel = codigoOfertaComboAluguel;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof OfertaType)) return false;
        OfertaType other = (OfertaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.indicadorOfertaAssociada==null && other.getIndicadorOfertaAssociada()==null) || 
             (this.indicadorOfertaAssociada!=null &&
              this.indicadorOfertaAssociada.equals(other.getIndicadorOfertaAssociada()))) &&
            ((this.indicadorAceiteOferta==null && other.getIndicadorAceiteOferta()==null) || 
             (this.indicadorAceiteOferta!=null &&
              this.indicadorAceiteOferta.equals(other.getIndicadorAceiteOferta()))) &&
            ((this.nivelOferta==null && other.getNivelOferta()==null) || 
             (this.nivelOferta!=null &&
              this.nivelOferta.equals(other.getNivelOferta()))) &&
            ((this.codigoOferta==null && other.getCodigoOferta()==null) || 
             (this.codigoOferta!=null &&
              this.codigoOferta.equals(other.getCodigoOferta()))) &&
            ((this.codigoOfertaComboAluguel==null && other.getCodigoOfertaComboAluguel()==null) || 
             (this.codigoOfertaComboAluguel!=null &&
              this.codigoOfertaComboAluguel.equals(other.getCodigoOfertaComboAluguel())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIndicadorOfertaAssociada() != null) {
            _hashCode += getIndicadorOfertaAssociada().hashCode();
        }
        if (getIndicadorAceiteOferta() != null) {
            _hashCode += getIndicadorAceiteOferta().hashCode();
        }
        if (getNivelOferta() != null) {
            _hashCode += getNivelOferta().hashCode();
        }
        if (getCodigoOferta() != null) {
            _hashCode += getCodigoOferta().hashCode();
        }
        if (getCodigoOfertaComboAluguel() != null) {
            _hashCode += getCodigoOfertaComboAluguel().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(OfertaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "OfertaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorOfertaAssociada");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "indicadorOfertaAssociada"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAceiteOferta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "indicadorAceiteOferta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "boolean"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nivelOferta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "nivelOferta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoOferta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "codigoOferta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoOfertaComboAluguel");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "codigoOfertaComboAluguel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
