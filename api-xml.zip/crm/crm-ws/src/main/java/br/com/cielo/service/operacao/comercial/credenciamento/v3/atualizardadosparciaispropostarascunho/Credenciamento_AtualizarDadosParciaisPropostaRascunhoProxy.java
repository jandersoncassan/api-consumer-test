package br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho;

public class Credenciamento_AtualizarDadosParciaisPropostaRascunhoProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.Credenciamento_AtualizarDadosParciaisPropostaRascunho {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.Credenciamento_AtualizarDadosParciaisPropostaRascunho credenciamento_AtualizarDadosParciaisPropostaRascunho = null;
  
  public Credenciamento_AtualizarDadosParciaisPropostaRascunhoProxy() {
    _initCredenciamento_AtualizarDadosParciaisPropostaRascunhoProxy();
  }
  
  public Credenciamento_AtualizarDadosParciaisPropostaRascunhoProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamento_AtualizarDadosParciaisPropostaRascunhoProxy();
  }
  
  private void _initCredenciamento_AtualizarDadosParciaisPropostaRascunhoProxy() {
    try {
      credenciamento_AtualizarDadosParciaisPropostaRascunho = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.Credenciamento_AtualizarDadosParciaisPropostaRascunhoServiceLocator()).getCredenciamento_AtualizarDadosParciaisPropostaRascunhoServiceSoapPort();
      if (credenciamento_AtualizarDadosParciaisPropostaRascunho != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamento_AtualizarDadosParciaisPropostaRascunho)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamento_AtualizarDadosParciaisPropostaRascunho)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamento_AtualizarDadosParciaisPropostaRascunho != null)
      ((javax.xml.rpc.Stub)credenciamento_AtualizarDadosParciaisPropostaRascunho)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.Credenciamento_AtualizarDadosParciaisPropostaRascunho getCredenciamento_AtualizarDadosParciaisPropostaRascunho() {
    if (credenciamento_AtualizarDadosParciaisPropostaRascunho == null)
      _initCredenciamento_AtualizarDadosParciaisPropostaRascunhoProxy();
    return credenciamento_AtualizarDadosParciaisPropostaRascunho;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoResponse atualizarDadosParciaisPropostaRascunho(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamento_AtualizarDadosParciaisPropostaRascunho == null)
      _initCredenciamento_AtualizarDadosParciaisPropostaRascunhoProxy();
    return credenciamento_AtualizarDadosParciaisPropostaRascunho.atualizarDadosParciaisPropostaRascunho(parameters, header);
  }
  
  
}