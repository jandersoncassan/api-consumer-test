package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho;

public class Credenciamento_ConsultarPropostaRascunhoProxy implements br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.Credenciamento_ConsultarPropostaRascunho {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.Credenciamento_ConsultarPropostaRascunho credenciamento_ConsultarPropostaRascunho = null;
  
  public Credenciamento_ConsultarPropostaRascunhoProxy() {
    _initCredenciamento_ConsultarPropostaRascunhoProxy();
  }
  
  public Credenciamento_ConsultarPropostaRascunhoProxy(String endpoint) {
    _endpoint = endpoint;
    _initCredenciamento_ConsultarPropostaRascunhoProxy();
  }
  
  private void _initCredenciamento_ConsultarPropostaRascunhoProxy() {
    try {
      credenciamento_ConsultarPropostaRascunho = (new br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.Credenciamento_ConsultarPropostaRascunhoServiceLocator()).getCredenciamento_ConsultarPropostaRascunhoServiceSoapPort();
      if (credenciamento_ConsultarPropostaRascunho != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)credenciamento_ConsultarPropostaRascunho)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)credenciamento_ConsultarPropostaRascunho)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (credenciamento_ConsultarPropostaRascunho != null)
      ((javax.xml.rpc.Stub)credenciamento_ConsultarPropostaRascunho)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.Credenciamento_ConsultarPropostaRascunho getCredenciamento_ConsultarPropostaRascunho() {
    if (credenciamento_ConsultarPropostaRascunho == null)
      _initCredenciamento_ConsultarPropostaRascunhoProxy();
    return credenciamento_ConsultarPropostaRascunho;
  }
  
  public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoResponse consultarPropostaRascunho(br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault{
    if (credenciamento_ConsultarPropostaRascunho == null)
      _initCredenciamento_ConsultarPropostaRascunhoProxy();
    return credenciamento_ConsultarPropostaRascunho.consultarPropostaRascunho(parameters, header);
  }
  
  
}