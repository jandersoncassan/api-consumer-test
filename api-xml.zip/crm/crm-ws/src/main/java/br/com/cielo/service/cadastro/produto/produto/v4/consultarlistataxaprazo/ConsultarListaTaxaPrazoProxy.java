package br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo;

public class ConsultarListaTaxaPrazoProxy implements br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazo_PortType {
  private String _endpoint = null;
  private br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazo_PortType consultarListaTaxaPrazo_PortType = null;
  
  public ConsultarListaTaxaPrazoProxy() {
    _initConsultarListaTaxaPrazoProxy();
  }
  
  public ConsultarListaTaxaPrazoProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarListaTaxaPrazoProxy();
  }
  
  private void _initConsultarListaTaxaPrazoProxy() {
    try {
      consultarListaTaxaPrazo_PortType = (new br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazo_ServiceLocator()).getConsultarListaTaxaPrazoSOAP();
      if (consultarListaTaxaPrazo_PortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarListaTaxaPrazo_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarListaTaxaPrazo_PortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarListaTaxaPrazo_PortType != null)
      ((javax.xml.rpc.Stub)consultarListaTaxaPrazo_PortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazo_PortType getConsultarListaTaxaPrazo_PortType() {
    if (consultarListaTaxaPrazo_PortType == null)
      _initConsultarListaTaxaPrazoProxy();
    return consultarListaTaxaPrazo_PortType;
  }
  
  public br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazoResponseType consultarListaTaxaPrazo(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazoRequestType parameters) throws java.rmi.RemoteException{
    if (consultarListaTaxaPrazo_PortType == null)
      _initConsultarListaTaxaPrazoProxy();
    return consultarListaTaxaPrazo_PortType.consultarListaTaxaPrazo(header, parameters);
  }
  
  
}