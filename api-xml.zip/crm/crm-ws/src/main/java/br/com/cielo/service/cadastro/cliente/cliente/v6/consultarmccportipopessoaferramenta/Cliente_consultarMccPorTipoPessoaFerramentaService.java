/**
 * Cliente_consultarMccPorTipoPessoaFerramentaService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta;

public interface Cliente_consultarMccPorTipoPessoaFerramentaService extends javax.xml.rpc.Service {
    public java.lang.String getCliente_consultarMccPorTipoPessoaFerramentaServiceSOAPPortAddress();

    public br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServicePortType getCliente_consultarMccPorTipoPessoaFerramentaServiceSOAPPort() throws javax.xml.rpc.ServiceException;

    public br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServicePortType getCliente_consultarMccPorTipoPessoaFerramentaServiceSOAPPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
