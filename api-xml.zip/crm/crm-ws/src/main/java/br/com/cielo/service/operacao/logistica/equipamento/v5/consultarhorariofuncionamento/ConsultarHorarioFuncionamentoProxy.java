package br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento;

public class ConsultarHorarioFuncionamentoProxy implements br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamento {
  private String _endpoint = null;
  private br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamento consultarHorarioFuncionamento = null;
  
  public ConsultarHorarioFuncionamentoProxy() {
    _initConsultarHorarioFuncionamentoProxy();
  }
  
  public ConsultarHorarioFuncionamentoProxy(String endpoint) {
    _endpoint = endpoint;
    _initConsultarHorarioFuncionamentoProxy();
  }
  
  private void _initConsultarHorarioFuncionamentoProxy() {
    try {
      consultarHorarioFuncionamento = (new br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoSOAPQSServiceLocator()).getConsultarHorarioFuncionamentoSOAPQSPort();
      if (consultarHorarioFuncionamento != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)consultarHorarioFuncionamento)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)consultarHorarioFuncionamento)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (consultarHorarioFuncionamento != null)
      ((javax.xml.rpc.Stub)consultarHorarioFuncionamento)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamento getConsultarHorarioFuncionamento() {
    if (consultarHorarioFuncionamento == null)
      _initConsultarHorarioFuncionamentoProxy();
    return consultarHorarioFuncionamento;
  }
  
  public br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoResponseType consultarHorarioFuncionamento(br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header, br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoRequestType parameters) throws java.rmi.RemoteException{
    if (consultarHorarioFuncionamento == null)
      _initConsultarHorarioFuncionamentoProxy();
    return consultarHorarioFuncionamento.consultarHorarioFuncionamento(header, parameters);
  }
  
  
}