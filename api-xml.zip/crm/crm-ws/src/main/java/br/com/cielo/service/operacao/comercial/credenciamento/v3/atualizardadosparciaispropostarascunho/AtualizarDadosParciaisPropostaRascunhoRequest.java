/**
 * AtualizarDadosParciaisPropostaRascunhoRequest.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho;

public class AtualizarDadosParciaisPropostaRascunhoRequest  implements java.io.Serializable {
    private long numeroProposta;

    /* 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE */
    private int codigoFerramenta;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimentoComercial;

    private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] solucoesCaptura;

    /* Indicador Agro S - Sim N - Não */
    private br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequestIndicadorAgro indicadorAgro;

    private java.lang.String loginUsuario;

    private java.lang.Integer codigoTipoPerfilSmart;

    private java.lang.String nomeExecutivo;

    public AtualizarDadosParciaisPropostaRascunhoRequest() {
    }

    public AtualizarDadosParciaisPropostaRascunhoRequest(
           long numeroProposta,
           int codigoFerramenta,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimentoComercial,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] solucoesCaptura,
           br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequestIndicadorAgro indicadorAgro,
           java.lang.String loginUsuario,
           java.lang.Integer codigoTipoPerfilSmart,
           java.lang.String nomeExecutivo) {
           this.numeroProposta = numeroProposta;
           this.codigoFerramenta = codigoFerramenta;
           this.estabelecimentoComercial = estabelecimentoComercial;
           this.solucoesCaptura = solucoesCaptura;
           this.indicadorAgro = indicadorAgro;
           this.loginUsuario = loginUsuario;
           this.codigoTipoPerfilSmart = codigoTipoPerfilSmart;
           this.nomeExecutivo = nomeExecutivo;
    }


    /**
     * Gets the numeroProposta value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return numeroProposta
     */
    public long getNumeroProposta() {
        return numeroProposta;
    }


    /**
     * Sets the numeroProposta value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param numeroProposta
     */
    public void setNumeroProposta(long numeroProposta) {
        this.numeroProposta = numeroProposta;
    }


    /**
     * Gets the codigoFerramenta value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return codigoFerramenta   * 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE
     */
    public int getCodigoFerramenta() {
        return codigoFerramenta;
    }


    /**
     * Sets the codigoFerramenta value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param codigoFerramenta   * 1 BANCOS BATCH 2 BANCOS ON-LINE 3 SITE
     */
    public void setCodigoFerramenta(int codigoFerramenta) {
        this.codigoFerramenta = codigoFerramenta;
    }


    /**
     * Gets the estabelecimentoComercial value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return estabelecimentoComercial
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType getEstabelecimentoComercial() {
        return estabelecimentoComercial;
    }


    /**
     * Sets the estabelecimentoComercial value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param estabelecimentoComercial
     */
    public void setEstabelecimentoComercial(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimentoComercial) {
        this.estabelecimentoComercial = estabelecimentoComercial;
    }


    /**
     * Gets the solucoesCaptura value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return solucoesCaptura
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] getSolucoesCaptura() {
        return solucoesCaptura;
    }


    /**
     * Sets the solucoesCaptura value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param solucoesCaptura
     */
    public void setSolucoesCaptura(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType[] solucoesCaptura) {
        this.solucoesCaptura = solucoesCaptura;
    }


    /**
     * Gets the indicadorAgro value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return indicadorAgro   * Indicador Agro S - Sim N - Não
     */
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequestIndicadorAgro getIndicadorAgro() {
        return indicadorAgro;
    }


    /**
     * Sets the indicadorAgro value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param indicadorAgro   * Indicador Agro S - Sim N - Não
     */
    public void setIndicadorAgro(br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequestIndicadorAgro indicadorAgro) {
        this.indicadorAgro = indicadorAgro;
    }


    /**
     * Gets the loginUsuario value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return loginUsuario
     */
    public java.lang.String getLoginUsuario() {
        return loginUsuario;
    }


    /**
     * Sets the loginUsuario value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param loginUsuario
     */
    public void setLoginUsuario(java.lang.String loginUsuario) {
        this.loginUsuario = loginUsuario;
    }


    /**
     * Gets the codigoTipoPerfilSmart value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return codigoTipoPerfilSmart
     */
    public java.lang.Integer getCodigoTipoPerfilSmart() {
        return codigoTipoPerfilSmart;
    }


    /**
     * Sets the codigoTipoPerfilSmart value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param codigoTipoPerfilSmart
     */
    public void setCodigoTipoPerfilSmart(java.lang.Integer codigoTipoPerfilSmart) {
        this.codigoTipoPerfilSmart = codigoTipoPerfilSmart;
    }


    /**
     * Gets the nomeExecutivo value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @return nomeExecutivo
     */
    public java.lang.String getNomeExecutivo() {
        return nomeExecutivo;
    }


    /**
     * Sets the nomeExecutivo value for this AtualizarDadosParciaisPropostaRascunhoRequest.
     * 
     * @param nomeExecutivo
     */
    public void setNomeExecutivo(java.lang.String nomeExecutivo) {
        this.nomeExecutivo = nomeExecutivo;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof AtualizarDadosParciaisPropostaRascunhoRequest)) return false;
        AtualizarDadosParciaisPropostaRascunhoRequest other = (AtualizarDadosParciaisPropostaRascunhoRequest) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            this.numeroProposta == other.getNumeroProposta() &&
            this.codigoFerramenta == other.getCodigoFerramenta() &&
            ((this.estabelecimentoComercial==null && other.getEstabelecimentoComercial()==null) || 
             (this.estabelecimentoComercial!=null &&
              this.estabelecimentoComercial.equals(other.getEstabelecimentoComercial()))) &&
            ((this.solucoesCaptura==null && other.getSolucoesCaptura()==null) || 
             (this.solucoesCaptura!=null &&
              java.util.Arrays.equals(this.solucoesCaptura, other.getSolucoesCaptura()))) &&
            ((this.indicadorAgro==null && other.getIndicadorAgro()==null) || 
             (this.indicadorAgro!=null &&
              this.indicadorAgro.equals(other.getIndicadorAgro()))) &&
            ((this.loginUsuario==null && other.getLoginUsuario()==null) || 
             (this.loginUsuario!=null &&
              this.loginUsuario.equals(other.getLoginUsuario()))) &&
            ((this.codigoTipoPerfilSmart==null && other.getCodigoTipoPerfilSmart()==null) || 
             (this.codigoTipoPerfilSmart!=null &&
              this.codigoTipoPerfilSmart.equals(other.getCodigoTipoPerfilSmart()))) &&
            ((this.nomeExecutivo==null && other.getNomeExecutivo()==null) || 
             (this.nomeExecutivo!=null &&
              this.nomeExecutivo.equals(other.getNomeExecutivo())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        _hashCode += new Long(getNumeroProposta()).hashCode();
        _hashCode += getCodigoFerramenta();
        if (getEstabelecimentoComercial() != null) {
            _hashCode += getEstabelecimentoComercial().hashCode();
        }
        if (getSolucoesCaptura() != null) {
            for (int i=0;
                 i<java.lang.reflect.Array.getLength(getSolucoesCaptura());
                 i++) {
                java.lang.Object obj = java.lang.reflect.Array.get(getSolucoesCaptura(), i);
                if (obj != null &&
                    !obj.getClass().isArray()) {
                    _hashCode += obj.hashCode();
                }
            }
        }
        if (getIndicadorAgro() != null) {
            _hashCode += getIndicadorAgro().hashCode();
        }
        if (getLoginUsuario() != null) {
            _hashCode += getLoginUsuario().hashCode();
        }
        if (getCodigoTipoPerfilSmart() != null) {
            _hashCode += getCodigoTipoPerfilSmart().hashCode();
        }
        if (getNomeExecutivo() != null) {
            _hashCode += getNomeExecutivo().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(AtualizarDadosParciaisPropostaRascunhoRequest.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", ">atualizarDadosParciaisPropostaRascunhoRequest"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numeroProposta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "numeroProposta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "long"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoFerramenta");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "codigoFerramenta"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("estabelecimentoComercial");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "estabelecimentoComercial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "estabelecimentoComercialType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("solucoesCaptura");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "solucoesCaptura"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "solucaoCapturaType"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        elemField.setItemQName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "solucaoCaptura"));
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("indicadorAgro");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "indicadorAgro"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", ">>atualizarDadosParciaisPropostaRascunhoRequest>indicadorAgro"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("loginUsuario");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "loginUsuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codigoTipoPerfilSmart");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "codigoTipoPerfilSmart"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomeExecutivo");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/atualizardadosparciaispropostarascunho", "nomeExecutivo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
