/**
 * ProdutosTaxaType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo;

public class ProdutosTaxaType  implements java.io.Serializable {
    private java.lang.Integer mcc;

    private java.math.BigDecimal taxaProduto40;

    private java.math.BigDecimal taxaProduto41;

    private java.math.BigDecimal taxaProduto43;

    private java.math.BigDecimal taxaSegmentada3Parcelas;

    private java.math.BigDecimal taxaSegmentada6Parcelas;

    private java.math.BigDecimal taxaSegmentada12Parcelas;

    public ProdutosTaxaType() {
    }

    public ProdutosTaxaType(
           java.lang.Integer mcc,
           java.math.BigDecimal taxaProduto40,
           java.math.BigDecimal taxaProduto41,
           java.math.BigDecimal taxaProduto43,
           java.math.BigDecimal taxaSegmentada3Parcelas,
           java.math.BigDecimal taxaSegmentada6Parcelas,
           java.math.BigDecimal taxaSegmentada12Parcelas) {
           this.mcc = mcc;
           this.taxaProduto40 = taxaProduto40;
           this.taxaProduto41 = taxaProduto41;
           this.taxaProduto43 = taxaProduto43;
           this.taxaSegmentada3Parcelas = taxaSegmentada3Parcelas;
           this.taxaSegmentada6Parcelas = taxaSegmentada6Parcelas;
           this.taxaSegmentada12Parcelas = taxaSegmentada12Parcelas;
    }


    /**
     * Gets the mcc value for this ProdutosTaxaType.
     * 
     * @return mcc
     */
    public java.lang.Integer getMcc() {
        return mcc;
    }


    /**
     * Sets the mcc value for this ProdutosTaxaType.
     * 
     * @param mcc
     */
    public void setMcc(java.lang.Integer mcc) {
        this.mcc = mcc;
    }


    /**
     * Gets the taxaProduto40 value for this ProdutosTaxaType.
     * 
     * @return taxaProduto40
     */
    public java.math.BigDecimal getTaxaProduto40() {
        return taxaProduto40;
    }


    /**
     * Sets the taxaProduto40 value for this ProdutosTaxaType.
     * 
     * @param taxaProduto40
     */
    public void setTaxaProduto40(java.math.BigDecimal taxaProduto40) {
        this.taxaProduto40 = taxaProduto40;
    }


    /**
     * Gets the taxaProduto41 value for this ProdutosTaxaType.
     * 
     * @return taxaProduto41
     */
    public java.math.BigDecimal getTaxaProduto41() {
        return taxaProduto41;
    }


    /**
     * Sets the taxaProduto41 value for this ProdutosTaxaType.
     * 
     * @param taxaProduto41
     */
    public void setTaxaProduto41(java.math.BigDecimal taxaProduto41) {
        this.taxaProduto41 = taxaProduto41;
    }


    /**
     * Gets the taxaProduto43 value for this ProdutosTaxaType.
     * 
     * @return taxaProduto43
     */
    public java.math.BigDecimal getTaxaProduto43() {
        return taxaProduto43;
    }


    /**
     * Sets the taxaProduto43 value for this ProdutosTaxaType.
     * 
     * @param taxaProduto43
     */
    public void setTaxaProduto43(java.math.BigDecimal taxaProduto43) {
        this.taxaProduto43 = taxaProduto43;
    }


    /**
     * Gets the taxaSegmentada3Parcelas value for this ProdutosTaxaType.
     * 
     * @return taxaSegmentada3Parcelas
     */
    public java.math.BigDecimal getTaxaSegmentada3Parcelas() {
        return taxaSegmentada3Parcelas;
    }


    /**
     * Sets the taxaSegmentada3Parcelas value for this ProdutosTaxaType.
     * 
     * @param taxaSegmentada3Parcelas
     */
    public void setTaxaSegmentada3Parcelas(java.math.BigDecimal taxaSegmentada3Parcelas) {
        this.taxaSegmentada3Parcelas = taxaSegmentada3Parcelas;
    }


    /**
     * Gets the taxaSegmentada6Parcelas value for this ProdutosTaxaType.
     * 
     * @return taxaSegmentada6Parcelas
     */
    public java.math.BigDecimal getTaxaSegmentada6Parcelas() {
        return taxaSegmentada6Parcelas;
    }


    /**
     * Sets the taxaSegmentada6Parcelas value for this ProdutosTaxaType.
     * 
     * @param taxaSegmentada6Parcelas
     */
    public void setTaxaSegmentada6Parcelas(java.math.BigDecimal taxaSegmentada6Parcelas) {
        this.taxaSegmentada6Parcelas = taxaSegmentada6Parcelas;
    }


    /**
     * Gets the taxaSegmentada12Parcelas value for this ProdutosTaxaType.
     * 
     * @return taxaSegmentada12Parcelas
     */
    public java.math.BigDecimal getTaxaSegmentada12Parcelas() {
        return taxaSegmentada12Parcelas;
    }


    /**
     * Sets the taxaSegmentada12Parcelas value for this ProdutosTaxaType.
     * 
     * @param taxaSegmentada12Parcelas
     */
    public void setTaxaSegmentada12Parcelas(java.math.BigDecimal taxaSegmentada12Parcelas) {
        this.taxaSegmentada12Parcelas = taxaSegmentada12Parcelas;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof ProdutosTaxaType)) return false;
        ProdutosTaxaType other = (ProdutosTaxaType) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.mcc==null && other.getMcc()==null) || 
             (this.mcc!=null &&
              this.mcc.equals(other.getMcc()))) &&
            ((this.taxaProduto40==null && other.getTaxaProduto40()==null) || 
             (this.taxaProduto40!=null &&
              this.taxaProduto40.equals(other.getTaxaProduto40()))) &&
            ((this.taxaProduto41==null && other.getTaxaProduto41()==null) || 
             (this.taxaProduto41!=null &&
              this.taxaProduto41.equals(other.getTaxaProduto41()))) &&
            ((this.taxaProduto43==null && other.getTaxaProduto43()==null) || 
             (this.taxaProduto43!=null &&
              this.taxaProduto43.equals(other.getTaxaProduto43()))) &&
            ((this.taxaSegmentada3Parcelas==null && other.getTaxaSegmentada3Parcelas()==null) || 
             (this.taxaSegmentada3Parcelas!=null &&
              this.taxaSegmentada3Parcelas.equals(other.getTaxaSegmentada3Parcelas()))) &&
            ((this.taxaSegmentada6Parcelas==null && other.getTaxaSegmentada6Parcelas()==null) || 
             (this.taxaSegmentada6Parcelas!=null &&
              this.taxaSegmentada6Parcelas.equals(other.getTaxaSegmentada6Parcelas()))) &&
            ((this.taxaSegmentada12Parcelas==null && other.getTaxaSegmentada12Parcelas()==null) || 
             (this.taxaSegmentada12Parcelas!=null &&
              this.taxaSegmentada12Parcelas.equals(other.getTaxaSegmentada12Parcelas())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getMcc() != null) {
            _hashCode += getMcc().hashCode();
        }
        if (getTaxaProduto40() != null) {
            _hashCode += getTaxaProduto40().hashCode();
        }
        if (getTaxaProduto41() != null) {
            _hashCode += getTaxaProduto41().hashCode();
        }
        if (getTaxaProduto43() != null) {
            _hashCode += getTaxaProduto43().hashCode();
        }
        if (getTaxaSegmentada3Parcelas() != null) {
            _hashCode += getTaxaSegmentada3Parcelas().hashCode();
        }
        if (getTaxaSegmentada6Parcelas() != null) {
            _hashCode += getTaxaSegmentada6Parcelas().hashCode();
        }
        if (getTaxaSegmentada12Parcelas() != null) {
            _hashCode += getTaxaSegmentada12Parcelas().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(ProdutosTaxaType.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "ProdutosTaxaType"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("mcc");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "mcc"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaProduto40");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "taxaProduto40"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaProduto41");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "taxaProduto41"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaProduto43");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "taxaProduto43"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaSegmentada3Parcelas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "taxaSegmentada3Parcelas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaSegmentada6Parcelas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "taxaSegmentada6Parcelas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("taxaSegmentada12Parcelas");
        elemField.setXmlName(new javax.xml.namespace.QName("http://service.cielo.com.br/cadastro/produto/produto/v4/consultarlistataxaprazo", "taxaSegmentada12Parcelas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "decimal"));
        elemField.setMinOccurs(0);
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
