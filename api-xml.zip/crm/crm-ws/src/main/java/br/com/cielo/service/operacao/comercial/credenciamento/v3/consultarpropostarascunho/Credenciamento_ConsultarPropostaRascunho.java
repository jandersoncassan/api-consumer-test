/**
 * Credenciamento_ConsultarPropostaRascunho.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho;

public interface Credenciamento_ConsultarPropostaRascunho extends java.rmi.Remote {
    public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoResponse consultarPropostaRascunho(br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequest parameters, br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType header) throws java.rmi.RemoteException, br.com.cielo.canonico.comum.v1.Fault;
}
