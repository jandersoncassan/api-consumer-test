/**
 * Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta;

public class Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator extends org.apache.axis.client.Service implements br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_Service {

    public Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator() {
    }


    public Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort
    private java.lang.String Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort_address = "http://osbhml.enterprisetrn.corp:8801/operacao/comercial/credenciamento/v3/consultarsolucoescapturaporferramenta";

    public java.lang.String getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortAddress() {
        return Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortWSDDServiceName = "Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort";

    public java.lang.String getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortWSDDServiceName() {
        return Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortWSDDServiceName;
    }

    public void setCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortWSDDServiceName(java.lang.String name) {
        Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortWSDDServiceName = name;
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort(endpoint);
    }

    public br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapBindingStub _stub = new br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapBindingStub(portAddress, this);
            _stub.setPortName(getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortEndpointAddress(java.lang.String address) {
        Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType.class.isAssignableFrom(serviceEndpointInterface)) {
                br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapBindingStub _stub = new br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapBindingStub(new java.net.URL(Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort_address), this);
                _stub.setPortName(getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort".equals(inputPortName)) {
            return getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarsolucaocapturaporferramenta", "Credenciamento_ConsultarSolucaoCapturaPorFerramenta");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://service.cielo.com.br/operacao/comercial/credenciamento/v3/consultarsolucaocapturaporferramenta", "Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("Credenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort".equals(portName)) {
            setCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
