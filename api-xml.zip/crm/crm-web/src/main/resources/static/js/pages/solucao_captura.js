$(function() {
	
	$('#isEntregaMaquina').hide();
	
	//TRATAMENTO PALIATIVO PARA HABILITAR O RECEBA RAPIDO, 
	//NA PROXIMA RELEASE DEVE SER RETIRADO ESSE TRATAMENTO BY @Janderson
	var flagRecebaRapido;
	
	verificarFlagRecebaRapido = function(){
		$.get({ 
			  url : hostContext()+'/getFlagGetIsActiveFast',
			  async: false,
			  dataType: 'text',	
	          contentType: "application/json; charset=utf-8",
			  success : function(data) {
				  flagRecebaRapido = data;
				  if(data == 'S'){$("#regra01").show()}else{$("#regra01").hide()};
			  },
			  error : function(error){
				  console.log("ERRO CONSULTA FLAG RECEBA RAPIDO", error);
				  flagRecebaRapido='N'
			  }
		});
	}
	
	//COMBO LISTA DE FATURAMENTO
	$.get({ 
		  url : hostContext()+'/getListaFaturamento',
		  async: false,
          dataType: 'json',
          contentType: "application/json; charset=utf-8",
		  success : function(data) {
			  
			$('#faturamento').find('option').remove();
			var selectbox = $('#faturamento');
			$('<option>').val(0).text("Selecione").appendTo(selectbox);			
             $.each(data, function (i, d) {
            	 if(d.codigo != 26)
            		 $('<option>').val(d.codigo).text(d.descricao).appendTo(selectbox);
             });             
             $("select[name=faturamento]").selectpicker("refresh");
			 
		  },
		  error : function(error){
			  console.log(error);
		  }
	});

	//COMBO SOLUCAO DE CAPTURA
	$.get({ 
		  url : hostContext()+'/getSolucaoCaptura/'+getCodigoFerramenta(),
		  async: false,
          dataType: 'json',
          contentType: "application/json; charset=utf-8",
		  success : function(data) {
			  
			$('#solCaptura').find('option').remove();
			var selectbox = $('#solCaptura');
			$('<option>').val(0).text("Selecione").appendTo(selectbox);
			
             $.each(data, function (i, d) {
            	 if(d.codigo != 26)
            		 $('<option data-maq="'+d.indEntregaMaquina+'">').val(d.codigo).text(d.descricao.toUpperCase()).appendTo(selectbox);
             });
             
             $("select[name=solCaptura]").selectpicker("refresh");
			 
		  },
		  error : function(error){
			  console.log(error);
		  }
	});
	 
	//CAMPOS HIDE
	initFields = function() {
		$('#planoCieloControle').hide();
		$('#planoAluguelZero').hide();
		$('.pnlTaxas').hide();
		$("#cboQtdadeMaquinas").hide();
		$("#lblQtdadeMaquinas").hide();
		$("#chkVendasArv").prop('checked', false);
	}
	initFields();

	regrasSolucaoHide = function() {
		$("#regra01").hide();
		$("#txArv").hide();
		$("#regra02").hide();
		$("#regra03").hide();
	}
	regrasSolucaoHide();

	var $radiosTpPlano = $("input:radio[name='tpPlano']");
	if ($radiosTpPlano.is(':checked') === false) {
		$radiosTpPlano.filter('[value=1]').prop('checked', true);
		$("#cboQtdadeMaquinas").show();
	}

	$("input:radio[name='diasLiqControle']").prop('disabled', true);

	//CONTROLE DE TAXAS E PRAZOS
	popularTaxasPrazos = function(taxasPrazos) {

		$('.pnlTaxas').show();
		$("#txCredito").text(taxasPrazos.produto40 + "%");
		$("#txDebito").text(taxasPrazos.produto41 + "%");
		$("#credParc3x").text(taxasPrazos.segmentado3Parcelas + "%");
		$("#credParc6x").text(taxasPrazos.segmentado6Parcelas + "%");
		$("#credParc12x").text(taxasPrazos.segmentado12Parcelas + "%");
	}

	obterTaxasPrazos = function(codigoMcc) {
		$.get({
			url : hostContext() + '/getTaxasPrazos/' + codigoMcc,
			dataType : 'json',
			contentType : "application/json; charset=utf-8",
			success : function(data) {
				popularTaxasPrazos(data);
			},
			error : function(error) {
				console.log(error);
			}
		});

	}
	
	popularComboQtdEquipamentos = function(data){
		$('#qtdadeMaquinas').find('option').remove();
		var selectbox = $('#qtdadeMaquinas');	
		$('<option>').val(0).text("Selecione").appendTo(selectbox);
		for(i=1; i<=data; i++){
			$('<option>').val(i).text(i).appendTo(selectbox);
		}
		$('#qtdadeMaquinas').prop('disabled',false);

	}
	

	obterQtdadeEquipamentos = function(codSolucaoCaptura, codigoFerramenta){
		$('#qtdadeMaquinas').prop('disabled',true);
		$.get({
			url : hostContext() + '/getQtdadeEquipamentos/' + codSolucaoCaptura+ '/' +codigoFerramenta,
			dataType : 'json',
			async: false,
			contentType : "application/json; charset=utf-8",
			success : function(data) {
				popularComboQtdEquipamentos(data);
			},
			error : function(error) {
				console.log(error);
				popularComboQtdEquipamentos(10)//CONTIGENCIA POPULAMOS COM 10
			}
		});
		$("select[name=qtdadeMaquinas]").selectpicker("refresh"); 
	}
	
	//POPULAR INFORMAÇÕES DE RESUMO//
	popularInfoResumo = function() {
		$("#descSolCaptura").text($('#solCaptura :selected').text());
		var plano = $("input:radio[name='tpPlano']:checked").data('name');
		$("#descPlano").text($("input:radio[name='tpPlano']:checked").parent('label').text());
		$('#text-qtdade-dias').text('');
		if (plano == 'convencional') { 
			$(".resumo").find('.qtdDias').remove();
			$("#descQtdadeDias").text('');
			$("#descQtdadeDias").after("<div class='qtdDias'><p>Débito em 1 dia</p><p>Crédito em até 30 dias</p><div>");			
			$('#text-qtdade-dias').text('Recebimento de suas vendas');
			
		} else if (plano == 'controle') {
			$("#descQtdadeDias").text('');
			$(".resumo").find('.qtdDias').remove();
			$("#descQtdadeDias").text($("input:radio[name='diasLiqControle']:checked").parent('label').text());
			$('#text-qtdade-dias').text('Em quantos dias deseja receber suas vendas no crédito à vista?');
			
		} else if (plano == 'aluguelZero') {
			$("#descQtdadeDias").text('');
			$(".resumo").find('.qtdDias').remove();
			$('#text-qtdade-dias').text('Recebimento de suas vendas');
			$("#descQtdadeDias").after("<div class='qtdDias'><p>Débito em 01 dia</p><p>Crédito em 02 dias</p><div>");	
			
		} 

	}

	//TRATAMENTO CHANGE RAMO DE ATIVIDADE
	tratarRamoAtividade = function(ramoAtividade) {
		if (ramoAtividade != '0') {
			var solCaptura = $("#solCaptura").val();
			if (solCaptura != '0') {
				if (solCaptura == '18') {//MOBILE
					ramoAtividade = '90000';//FIXO
				}
				else if (solCaptura == '26') {//MPOS - CIELO ZIP
					ramoAtividade = '90001';//FIXO
				}
				obterTaxasPrazos(ramoAtividade);
			}
		} else {
			$('.pnlTaxas').hide();
		}
	}

	$("#ramoAtividade").on("change", function() {
		tratarRamoAtividade($(this).val());
	})

	getMessageApenas01Maquina = function(tipoPlano){
		return tipoPlano == 'controle' ? 'Plano Cielo Controle' : 'Plano Cielo Livre';
	}
	
	changePlanoFaturamento = function(codigoSolucao) {
		var tpPlano = $("input:radio[name='tpPlano']:checked").data('name'); 
		if(codigoSolucao == '26' || tpPlano == 'controle' || tpPlano == 'aluguelZero'){//MPOS - CIELO ZIP || CIELO CONTROLE, PERMITE SOMENTE 01 EQUIPAMENTO
			$("#text-qtdade-maquinas").text(getMessageApenas01Maquina(tpPlano));	
			$("#lblQtdadeMaquinas").show();			
			$("#cboQtdadeMaquinas").hide();
		}else{
			$("#lblQtdadeMaquinas").hide();
			$("#cboQtdadeMaquinas").show();
		}
	}

	checkedPlanoConvencional = function(){
		$("#planoCieloConvencional").show();
		$("input:radio[name='tpPlano'][value=1]").prop('checked', true);
	}
	
	//TRATAMENTO PARA VERIFICAR SE DEVEMOS HABILITAR O PLANO ALUGUEL ZERO
	tratarExibicaoPlanoAluguelZero = function(solucaoCaptura){
		var solucoesPermitidas = ['1','2','18','21','23','25','26'];
		var isSolucaoValida = solucoesPermitidas.indexOf(solucaoCaptura);
		if (isSolucaoValida != -1){
			$("#planoAluguelZero").show();
		}else {
			$("#planoAluguelZero").hide();
		}		
	}
	
	//TRATAMENTO PARA VERIFICAR SE DEVEMOS HABILITAR O PLANO CONTROLE
	tratarExibicaoPlanoControle = function(solucaoCaptura){
		var solucoesPermitidas = ['1','2','3','21','22','23','24','25','26'];
		var isSolucaoValida = solucoesPermitidas.indexOf(solucaoCaptura);
		if (isSolucaoValida != -1){
			$("#planoCieloControle").show();
		}else {
			$("#planoCieloControle").hide();
		}		
	}

	//POR PADRAO SOMENTE PLANO CONVENCIONAL HABILITADO
	exibirPlanoDefault = function(){
		$("#planoCieloControle").hide();
		$("#planoAluguelZero").hide();
		checkedPlanoConvencional();
	}
	
	//TRATAMENTO EXIBIÇÃO DO PLANO CONTROLE
	tratarExibicaoPlanos= function(codigoSolucao, faturamento) {		
		if(codigoSolucao != '0' && faturamento != '0'){
			tratarExibicaoPlanoControle(codigoSolucao);
			tratarExibicaoPlanoAluguelZero(codigoSolucao);
		}else{
			exibirPlanoDefault();
		}
		changePlanoFaturamento(codigoSolucao);
	}

	//TRATAMENTO PARA EXIBICAO DO PLANO CONTROLE | PLANO ALUGUEL ZERO
	tratarPlanoControle = function(field, valor) {
		if (field == 'solucaoCaptura') {
			tratarExibicaoPlanos(valor, $("#faturamento").val());
		} else {
			tratarExibicaoPlanos($("#solCaptura").val(), valor);
		}
	}
	
	tratarExibicaoMposCombo = function(valor){
		$("#solCaptura option[value='26']").remove();	
		var $range= new Array('500','1000','2000','3000','4000','5000');
		if($range.indexOf(valor) != -1){	
			$('#solCaptura').append( '<option value="26">CIELO ZIP</option>' );			
		}
		$("select[name=solCaptura]").selectpicker("refresh");
		checkedPlanoConvencional();		
	}

	$("#faturamento").on("change", function() {
		var valor = $(this).val();
		tratarPlanoControle("faturamento", valor);
		tratarExibicaoMposCombo(valor);
	})

	exibirInfoSolucao = function(codigo) {
		//POS Regras Exibição Taxa
		if (codigo == '1' || codigo == '2' || codigo == '3' || codigo == '18'|| codigo == '25' || codigo == '26') {
			if(flagRecebaRapido == 'S'){$("#regra01").show()};
			$("#regra02").hide();
			$("#regra03").hide();

		} else if (codigo == '19') {
			$("#regra02").show();
			if(flagRecebaRapido == 'S'){$("#regra01").hide()};
			$("#regra03").hide()

		} else if (codigo == '20' || codigo == '0') {
			regrasSolucaoHide();

		} else {
			$("#regra03").show();
			if(flagRecebaRapido == 'S'){$("#regra01").show()};
			$("#regra02").hide();
		}
		tratarPlanoControle("solucaoCaptura", codigo);
	}

	
	tratarSolucaoRamoAtividade = function(solucaoCaptura, ramoAtividade){
		if (solucaoCaptura != '0') {
			var mcc = ramoAtividade;
			if (mcc != '0') {
				if (solucaoCaptura == '18') {//MOBILE
					mcc = '90000';//FIXO
				}
				else if (solCaptura == '26') {//MPOS - CIELO ZIP
					mcc = '90001';//FIXO
				}
				obterTaxasPrazos(mcc);
			}
			//COMBETA QUANTIDADE
			obterQtdadeEquipamentos(solucaoCaptura, getCodigoFerramenta());
			
			//TRATAR ENTREGA MAQUINAS
			tratarEntregaMaquinas($("#solCaptura option:selected" ).attr('data-maq'));
		} else {
			$('.pnlTaxas').hide();
		}
		exibirInfoSolucao(solucaoCaptura);
		popularInfoResumo();
	}
	
	afterTratarMpos = function(){
		$('#planoCieloConvencional').show();
		$("input:radio[name='tpPlano'][value=1]").prop('checked', true);	
		$("input:radio[name='diasLiqControle'][value=2]").prop('checked', false);	
		$("input:radio[name='diasLiqControle']").prop('disabled', true);
		
		$(".rd30dias").show();
	}
	
	tratarSolucaoMpos = function(){
		$('#planoCieloConvencional').hide();
		$("input:radio[name='tpPlano'][value=2]").prop('checked', true);
		$("input:radio[name='diasLiqControle'][value=2]").prop('checked', true);		
		$("input:radio[name='diasLiqControle']").prop('disabled', false);
		$(".rd30dias").hide();		
	}
	
	//TRATAR SOLUÇAO DE CAPTURA
	tratarSolucaoCaptura = function(solucaoCaptura) {
		afterTratarMpos(); 
		if (solucaoCaptura != '0') {
			var mcc = $("#ramoAtividade").val();			
			if (mcc != '0') {
				if (solucaoCaptura == '18') {//MOBILE
					mcc = '90000';//FIXO
				}
				else if(solucaoCaptura == '26') {//MPOS - CIELO ZIP 
					mcc = '90001';//FIXO 
					tratarSolucaoMpos();
				}
				obterTaxasPrazos(mcc);
			}
		} else {
			$('.pnlTaxas').hide();
		}
		exibirInfoSolucao(solucaoCaptura);
		popularInfoResumo();
	}

	//RELEASE 05 - ENTREGA DE MAQUINAS FERRAMENTA FEIRAS
	tratarEntregaMaquinas = function(indEntregaMaquina){
		var codigoFerramenta = getCodigoFerramenta();
		if(indEntregaMaquina == 'S' && codigoFerramenta == '8'){ //FLAG TRUE E FERRAMENTA FEIRAS			
			$('#isEntregaMaquina').show();		
		}else{
			$('#isEntregaMaquina').hide();	
		}
	}
	
	$("#solCaptura").on("change", function() {
		
		var codSolCaptura = $(this).val();
		tratarSolucaoCaptura(codSolCaptura);
		atualizarRascunho('atualizarRascunhoSolCaptura', 'step01');
		//POPULA O COMBO QUANTIDADE DE MAQUINAS <> 0 
		if(codSolCaptura != 0){
			obterQtdadeEquipamentos(codSolCaptura, getCodigoFerramenta());		
		}
		//RELEASE 05 - ENTREGA DE MAQUINAS FERRAMENTA FEIRAS
		var indEntregaMaquina = $(this).find(':selected').attr('data-maq');
		tratarEntregaMaquinas(indEntregaMaquina);
	})

	//TRATAMENTO OPERADORA DE CELULAR GPRS    
	tratarOperadora = function() {
		$("input:checkbox[name='operadora']").each(function() {
			$(this).prop('disabled', false);
		})
		var $check = $("input:checkbox[name='operadora']:checked");
		if ($check.length >= 2) {
			$("input:checkbox[name='operadora']").each(function() {
				if (!$(this).is(":checked")) {
					$(this).prop('disabled', true);
				}
			});
		}
	}

	$("input:checkbox[name='operadora']").on("change", function() {
		tratarOperadora();
	})

	$('#naoInfoOperadora').change(function() {
		if ($(this).is(":checked")) {
			$("input:checkbox[name='operadora']").each(function() {
				$(this).prop('checked', false);
				$(this).prop('disabled', true);
			})
		} else {
			$("input:checkbox[name='operadora']").each(function() {
				$(this).prop('disabled', false);
			})
		}
	});

	//TRATAMENTO TIPO PLANO CONVENCIONAL / CONTROLE / ALUGUEL ZERO
	tratarTipoPlano = function(plano) {
		if (plano == 'controle') {
			$("input:radio[name='diasLiqControle']").prop('disabled', false);

		} else {
			$("input:radio[name='diasLiqControle']").prop('disabled', true);
			exibirInfoSolucao($("#solCaptura").val());
		}
		//CONTROLE E MPOS, QUANTIDADE MAXIMA DE EQUIPAMENTOS 01
		var solCaptura = $("#solCaptura").val();
		if(plano == 'controle' || plano == 'aluguelZero' || solCaptura == '26' ){
			$("#cboQtdadeMaquinas").hide();
			$("#text-qtdade-maquinas").text(getMessageApenas01Maquina(plano));	
			$("#lblQtdadeMaquinas").show();	
			
			//REGRA DEVIDO AO ALUGUEL ZERO NÃO PODER EXIBIR O RR
			$("#regra01").show();
			if(plano == 'aluguelZero'){
				$("#regra01").hide();
			}

		}else{
			$("#cboQtdadeMaquinas").show();
			$("#lblQtdadeMaquinas").hide();
		}
		popularInfoResumo();
	}

	$("input:radio[name='tpPlano']").on("change", function() {
		var plano = $(this).data('name');
		tratarTipoPlano(plano);
	})

	//QTDADE DIAS LIQUIDACAO CONTROLE
	$("input:radio[name='diasLiqControle']").on("change", function() {
		var dias = $(this).val();
		if(dias == 30){
			if(flagRecebaRapido == 'S'){$("#regra01").show()};
		}else{
			if(flagRecebaRapido == 'S'){$("#regra01").hide()};
		}
		popularInfoResumo();
	});

	//TRATAMENTO PARA EXIBICAO NO RESUMO DA QUANTIDADE DE MAQUINAS
	tratarQtdadeMaquinas = function(qtdMaquinas) {
		//COMBO
		$('#qtdadeMaquinas').val(qtdMaquinas);
		$("select[name=qtdadeMaquinas]").selectpicker("refresh");
		
		//RESUMO
		var txt = $('#solCaptura :selected').text();
		if (txt != 'Selecione') {
			$("#descSolCaptura").text(txt + " x " + qtdMaquinas);
		}
	}

	$("#qtdadeMaquinas").on("change", function() {
		tratarQtdadeMaquinas($(this).val());
	});

	//TRATAMENTO PARA EXIBIÇÃO DAS TAXAS DE ARV
	tratarExibicaoTaxasArv = function() {
		if ($("#chkVendasArv").is(':checked')) {
			$("#txArv").show();
		} else {
			$("#txArv").hide();
		}
	}

	$("#chkVendasArv").on("change", function() {
		tratarExibicaoTaxasArv();
	})

	tryNextPage = function(){
		var nmFantasia = $('#nomeFantasia').val();
		$('#nomeFantasia').val(nmFantasia);

	}
	
	
	
	//PRÓXIMA PÁGINA
	nextPageInfoAdicional = function(dataObject) {
		$("#nomeClienteIA").text(dataObject.nome);
		$("#descRamoAtividade").text($('#ramoAtividade :selected').text());
		
		var nmFantasia = $('#nomeFantasia').val();
		var cidComercial = $('#cidadeComercial').val();
		var estadoComercial = $('#estadoComercial').val();
		var cidCorrespondencia = $('#cidadeCorrespondencia').val();
		var estadoCorrespondencia = $('#estadoCorrespondencia').val();

		popularCamposForm(dataObject);
		
		$('#nomeFantasia').val(nmFantasia);
		$('#cidadeComercial').val(cidComercial);
		$('#estadoComercial').val(estadoComercial);
		$('#cidadeCorrespondencia').val(cidCorrespondencia);
		$('#estadoCorrespondencia').val(estadoCorrespondencia);

		afterInitInfoAdicional();
		
		nextPage();		
	}
	
	tratarEmailSolucaoCaptura = function(){
		var solCaptura = $("#solCaptura").val();
		//CASO SOLUCAO IGUAL A MPOS (CIELO ZIP) O EMAIL É OBRIGATÓRIO
		if(solCaptura != '0' &&  solCaptura == '26'){			
			var email = $('#email').val();
			if(email == ''){
				$('#myModalEmail').modal({backdrop: 'static', keyboard: false}); 
				return false;
			}
			return true;
		}
		return true;
	}

	validarEmail = function(email){		
		var reg = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
		if (!reg.test(email)) {
		    $('span[id="message.email.required"]').after('<div class="error"><span style="color: red">Por favor, informe um email válido</span></div>');
		    hideMessageError();
		    return false;
		}
		return true;
	}
	
	$('#btoRequiredEmail').on('click', function(){
		var email = $('#emailTxtRequired').val();		
		var isEmailValido = validarEmail(email);
		
	    if(isEmailValido){
	    	//$('#naoPossuiEmail').val(null);
	    	$('#naoPossuiEmail').prop('checked', false);
	    	$('#email').prop('disabled', false);
	    	$('#email').val(email);
	    	$('#myModalEmail').modal('toggle');
	    	$('#solCapturaSubmit').click();
	    }
	});
	
	//SUBMIT FORM
	$('#solCapturaSubmit').click(function(e) {
		e.preventDefault();
		
		var isNextPage = tratarEmailSolucaoCaptura();		
		if(isNextPage){
		 
			    showLoadPage('S');
					e.preventDefault();
					
					$(this).prop('disabled', true);
			        blockedDoubleClick($(this));
	
					$(".panel-body").find('.error').remove();
					$.post({
						url : hostContext() + 'saveSolucaoCaptura',
						data : $("form[name=formCrm]").serialize(),
						success : function(data) {
							console.log(data);
							if (data.validated) {
								console.log(data.objectModel);
								//ATUALIZAMOS O RASCUNHO
								atualizarRascunho('atualizarRascunhoSolCaptura','step02')
								nextPageInfoAdicional(data.objectModel);
	
							} else {
								$.each(data.errorMessages, function(key, value) {
									$('span[id="message.' + key + '"]').after('<div class="error"><span style="color: red">'+ value + '</span></div>');
								});
								showLoadPage('H');
								hideMessageError();
							}
						}
					});
					setScroll();
			   }
			});

})