$(function() {

	getCodigoFerramenta = function(){
		return $('#codigoFerramenta').val();
	}
	
	$("#smartwizard").on("showStep",
			function(e, anchorObject, stepNumber, stepDirection, stepPosition) {
				if (stepPosition === 'first') {
					$("#prev-btn").addClass('disabled');
				} else if (stepPosition === 'final') {
					$("#next-btn").addClass('disabled');
				} else {
					$("#prev-btn").removeClass('disabled');
					$("#next-btn").removeClass('disabled');
				}
				
			});
	
	$('#smartwizard').smartWizard({
		selected : 0,
		theme : 'arrows'		
	});

	hostContext = function(){
		var protocol = window.location.protocol;
		var host= window.location.host;
		return protocol+'//'+host+'/'+'crd-crm/';
	}

	//## CUSTOMIZACAO WIZARD ##
	$(".sw-btn-prev").hide();
	$(".sw-btn-next").hide();
	
	hideMessageError = function(){
		setTimeout(function() {
			$('.error').fadeOut('600');
		}, 7000);
	}

	showLoadPage = function(action){
		if(action == 'H' ? $(".loader").hide() : $(".loader").show());
	}
	//#ATUALIZAR PROPOSTA RASCUNHO
	atualizarRascunho = function(method, step){
		
		$(".panel-body").find('.error').remove();
		$.post({
			url : hostContext()+method+'/'+step,
			data : $("form[name=formCrm]").serialize(),
			dataType: 'text',			
			success : function(data) {
				console.log("Atualizacao SUCESSO!")
			},
			error :function(error){
				console.log("Atualizacao ERRO!");
			}
		});
	}

	tratarOperadoras=function(data){
		$.each(data, function(key, value) {
			$('input:checkbox[name="operadora"][value="'+value+'"]').prop("checked", true);
		});
	}
	
	//ATUALIZA OS CAMPOS DO FORM
	popularCamposForm = function(object){
		popularHorarioFuncionamento();
		$.each(object, function(key, value){
			if(key == 'operadora'){
				tratarOperadoras(value);
				return true;
			}
			$('#'+key).val(value);
		});
		//ATUALIZAMOS A COMBETA DE SOLUCAO DE CAPTURA
		$("select[name=solCaptura]").selectpicker("refresh");
	}
	
	sendMessageParent = function(){
		window.parent.postMessage("next-prev", "*");
	}
	
	btoSubmitAction = function(){		
		 $('#clienteSubmit').prop('disabled', false);
		 $('#infoAdicionalSubmit').prop('disabled', false);
	}
	
	$(".back").click(function(){
		$(".sw-btn-prev").click();
		btoSubmitAction();
		sendMessageParent();
	})
	
	nextPage = function(){
		$(".sw-btn-next").click();
		sendMessageParent();
	}
	
	//ZEROS A ESQUERDDA DEVIDO A OPERAÇÃO DA CAIXA
   leftPad = function(str, size) {
	   str = str.toString();
	   return str.length < size ? leftPad("0" + str) : str;
	}

	setScroll = function(){
		 window.scrollTo(0,0);
	}
	setScroll();
	
	blockedDoubleClick = function(el){
		 setTimeout(function(){
			 el.prop('disabled', false); 
		 }, 4000);
	}
	
	
	//RAMOS DE ATIVIDADES
	popularRamosAtividades = function(tipoPessoa, codigoFerramenta, ramoAtividade){	
		$.get({ 
			  url : hostContext()+'/getRamosAtividades/'+tipoPessoa+'/'+codigoFerramenta,
			  async: false,
	          dataType: 'json',
	          contentType: "application/json; charset=utf-8",
			  success : function(data) {
				  
				$('#ramoAtividade').find('option').remove();
				var selectbox = $('#ramoAtividade');
				$('<option>').val(0).text("Selecione").appendTo(selectbox);
				
                 $.each(data, function (i, d) {
                     $('<option>').val(d.pk.codigo).text(d.pk.codigo+' - '+d.descricao).appendTo(selectbox);
                 });
                 $('#ramoAtividade').val(ramoAtividade);
                 $("select[name=ramoAtividade]").selectpicker("refresh");
              
 			  },
			  error : function(error){
				  console.log(error);
			  }
		});
	}
	
	//SOLUCAO DE CAPTURA
    afterInitSolucao = function(qtdMaquinas){
    	setScroll();showLoadPage('H');
    	//PALIATIVO DEVE SER REMOVIDO NA PROXIMA RELEASE
    	verificarFlagRecebaRapido();
    	//FATURAMENTO
    	tratarPlanoControle("faturamento", $("#faturamento").val());
    	//SOLUCAO E RAMOS DE ATIVIDADE
    	tratarSolucaoRamoAtividade($("#solCaptura").val(), $("#ramoAtividade").val());
    	//TRATAR OPERADORA GPRS
    	tratarOperadora();
     	//TRATAR TIPO DE PLANO CONVENCIONAL/CONTROLE
    	var tipoPlano = $("input:radio[name='tpPlano']:checked").data('name');
    	tratarTipoPlano(tipoPlano);
    	//TRATAR QTDADE MAQUINAS RESUMO 
    	tratarQtdadeMaquinas(qtdMaquinas);
    	//TRATAR EXIBIÇÃO DAS TAXAS DE ARV
    	tratarExibicaoTaxasArv();
    	//MPOS
    	tratarExibicaoMposCombo($("#faturamento").val())

     }
	
    //popular info conta
    infoConta = function(tipoConta, banco){ 
	    if(tipoConta != '99' && banco != null){
	    	obterListaBancos(tipoConta)
	    	$('input:radio[name="tipoConta"][value="'+tipoConta+'"]').prop("checked", true);
	    	$('#banco').val(banco)
	    	
	    }
    }
    
	//INFORMAÇÕES ADICIONAIS
	afterInitInfoAdicional = function(){
		setScroll();showLoadPage('H');
		var tipoPessoa = $("#rdPF").is(':checked') ? 'F' : 'J';
		//TRATAR TIPO PESSOA E ENDEREÇO
		tratarTipoPessoaEndereco();
		//TRATAR HORARIO FUNCIONAMENTO
	    popularHorarioFuncionamento();
	    //TRATAR MCC RESTRITO
		tratarMccRestrito($('#ramoAtividade').val(), tipoPessoa);
    	//TRATAR EXIBICAO DE ENTREGA DE MAQUINAS
    	tratarExibicaoEntMaquinas();
    	//TIPO DE CONTA
    	tratarContaCorrente(tipoPessoa, $('#banco').val());
    	//TRATAR OPERACAO BANCO CAIXA
    	tratarOperacaoCaixa();
	}
	
	//DADOS CONTRATACAO
	afterInitDadosContratacao = function(){
		setScroll();showLoadPage('H');
		var tipoPessoa = $("#rdPF").is(':checked') ? 'F' : 'J';
		//BOTAO FINALIZAR
		tratarBtoFinished();
		//DADOS DO DONO
		popularDadosDono(tipoPessoa);
		//SOLUCAO CAPTURA
		popularSolucaoCaptura();
		//POPULAR ESTABELECIMENTO
		popularEstabelecimento(tipoPessoa);
		//POPULAR DOMICILIO
		popularDomicilioBancario(tipoPessoa);
	}
	
	
	
/*	function disableLoadF5(e){
	 if(((e.which || e.keyCode)>=112 && (e.which || e.keyCode)<=123) || 
			 e.keyCode == 37  || e.keyCode == 39){
		 e.preventDefault();		 
	 }
	} 
	$(document).on("keydown", disableLoadF5);
*/ 

	
})