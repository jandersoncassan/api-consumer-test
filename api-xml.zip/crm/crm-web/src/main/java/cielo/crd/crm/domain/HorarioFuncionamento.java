package cielo.crd.crm.domain;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TBCRDCRM_HORARIO_FUNCIONAMENTO")
public class HorarioFuncionamento implements Serializable{

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private HorarioFuncionamentoPk pk;
	
	private String descricao;

	/**
	 * @return the pk
	 */
	public HorarioFuncionamentoPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(HorarioFuncionamentoPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
