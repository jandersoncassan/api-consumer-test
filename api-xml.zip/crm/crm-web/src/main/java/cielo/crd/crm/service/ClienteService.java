package cielo.crd.crm.service;

import cielo.crd.crm.model.CrmCredenciamentoDto;

/**
 * Interface responsavel pelos serviços de consulta cliente OSB
 * 
 * @author @Cielo/SA
 * @since 1.0.0
 */
public interface ClienteService {

	/**
	 * Método responsavel por verificar se o CPF / CNPJ é válido
	 * 
	 * @param cpfCnpj
	 * @return
	 */
	 boolean validarCpfCnpj(String cpfCnpj, String tipoPessoa);
	
	/**
	 * Método responsavel por verificar a existencia de cliente no SEC
	 * 
	 * @param cpfCnpj
	 * @param tipoPessoa
	 * @return
	 */
	String verificarExistenciaCliente(String cpfCnpj, String tipoPessoa);
	
	/**
	 * Método responsavel por obter os dados da proposta rascunho
	 * 
	 * @param tipoPessoa
	 * @param cpfCnpj
	 * @param codigoFerramenta
	 * @return 
	 */
	CrmCredenciamentoDto obterPropostaRascunho(String tipoPessoa, String cpfCnpj, Integer codigoFerramenta);
	
	/**
	 * Método responsavel por atualizar as informações de rascunho
	 * 
	 * @param rascunho
	 * @param step
	 * @return 
	 */
	String atualizarPropostaRascunho(CrmCredenciamentoDto rascunho, String step);
	
}
