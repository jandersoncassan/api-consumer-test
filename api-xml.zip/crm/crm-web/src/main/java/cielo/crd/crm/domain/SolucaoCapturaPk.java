package cielo.crd.crm.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class SolucaoCapturaPk implements Serializable{

	private static final long serialVersionUID = 1L;

	private Integer codigoFerramenta;
	
	private Integer codigoSolucao;

	/**
	 * @return the codigoFerramenta
	 */
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}

	/**
	 * @param codigoFerramenta the codigoFerramenta to set
	 */
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
	}

	/**
	 * @return the codigoSolucao
	 */
	public Integer getCodigoSolucao() {
		return codigoSolucao;
	}

	/**
	 * @param codigoSolucao the codigoSolucao to set
	 */
	public void setCodigoSolucao(Integer codigoSolucao) {
		this.codigoSolucao = codigoSolucao;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigoFerramenta == null) ? 0 : codigoFerramenta.hashCode());
		result = prime * result + ((codigoSolucao == null) ? 0 : codigoSolucao.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SolucaoCapturaPk other = (SolucaoCapturaPk) obj;
		if (codigoFerramenta == null) {
			if (other.codigoFerramenta != null)
				return false;
		} else if (!codigoFerramenta.equals(other.codigoFerramenta))
			return false;
		if (codigoSolucao == null) {
			if (other.codigoSolucao != null)
				return false;
		} else if (!codigoSolucao.equals(other.codigoSolucao))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SolucaoCapturaPk [codigoFerramenta=" + codigoFerramenta + ", codigoSolucao=" + codigoSolucao + "]";
	}
	
	
}
