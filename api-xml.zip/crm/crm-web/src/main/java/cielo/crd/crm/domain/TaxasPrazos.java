package cielo.crd.crm.domain;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TBCRDCRM_TAXAS_PRAZOS")
public class TaxasPrazos implements Serializable{

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private TaxasPrazosPk pk;

	private String produto40;
	
	private String produto41;
	
	private String produto43;
	
	private String segmentado3Parcelas;
	
	private String segmentado6Parcelas;

	private String segmentado12Parcelas;

	/**
	 * @return the pk
	 */
	public TaxasPrazosPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(TaxasPrazosPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the produto40
	 */
	public String getProduto40() {
		return produto40;
	}

	/**
	 * @param produto40 the produto40 to set
	 */
	public void setProduto40(String produto40) {
		this.produto40 = produto40;
	}

	/**
	 * @return the produto41
	 */
	public String getProduto41() {
		return produto41;
	}

	/**
	 * @param produto41 the produto41 to set
	 */
	public void setProduto41(String produto41) {
		this.produto41 = produto41;
	}

	/**
	 * @return the produto43
	 */
	public String getProduto43() {
		return produto43;
	}

	/**
	 * @param produto43 the produto43 to set
	 */
	public void setProduto43(String produto43) {
		this.produto43 = produto43;
	}

	/**
	 * @return the segmentado3Parcelas
	 */
	public String getSegmentado3Parcelas() {
		return segmentado3Parcelas;
	}

	/**
	 * @param segmentado3Parcelas the segmentado3Parcelas to set
	 */
	public void setSegmentado3Parcelas(String segmentado3Parcelas) {
		this.segmentado3Parcelas = segmentado3Parcelas;
	}

	/**
	 * @return the segmentado6Parcelas
	 */
	public String getSegmentado6Parcelas() {
		return segmentado6Parcelas;
	}

	/**
	 * @param segmentado6Parcelas the segmentado6Parcelas to set
	 */
	public void setSegmentado6Parcelas(String segmentado6Parcelas) {
		this.segmentado6Parcelas = segmentado6Parcelas;
	}

	/**
	 * @return the segmentado12Parcelas
	 */
	public String getSegmentado12Parcelas() {
		return segmentado12Parcelas;
	}

	/**
	 * @param segmentado12Parcelas the segmentado12Parcelas to set
	 */
	public void setSegmentado12Parcelas(String segmentado12Parcelas) {
		this.segmentado12Parcelas = segmentado12Parcelas;
	}


}
