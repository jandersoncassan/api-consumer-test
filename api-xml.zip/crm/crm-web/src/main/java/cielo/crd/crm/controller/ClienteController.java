package cielo.crd.crm.controller;

import static cielo.crd.crm.utils.CrdCrmUtils.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.CrmJsonResponse;
import cielo.crd.crm.service.ClienteService;
import cielo.crd.crm.utils.CrdCrmUtils;

@Controller
public class ClienteController {

	private static final Logger LOG = LoggerFactory.getLogger(ClienteController.class);
	
	private static final String EMAIL_PATTERN = "^[\\w\\.-]+@([\\w\\-]+\\.)+[A-Z]{2,4}$";

	private int countErrors;
	
	@Autowired
	private ClienteService clienteService;

	@GetMapping(value = "/verificarExistenciaCliente/{cpfCnpj}/{tipoPessoa}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String verificarExistenciaCliente(@PathVariable("cpfCnpj") String cpfCnpj, @PathVariable("tipoPessoa") String tipoPessoa) {
		LOG.info("VERIFICAR EXISTENCIA CLIENTE NO SEC : {} : {}", tipoPessoa, cpfCnpj);
		try {
			return (clienteService.verificarExistenciaCliente(cpfCnpj, tipoPessoa));

		} catch (RuntimeException ex) {
			LOG.error("OCORREU UM ERRO AO VERIFICAR A EXISTENCIA CLIENTE");
			return CrdCrmUtils.ERROR;
		}
	}

	@GetMapping(value = "/obterPropostaRascunho/{tpPessoa}/{cpfCnpj}/{codigoFerramenta}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public CrmCredenciamentoDto obterPropostaRascunho(@PathVariable("tpPessoa") String tipoPessoa,
													  @PathVariable("cpfCnpj") String cpfCnpj,
													  @PathVariable("codigoFerramenta") Integer codigoFerramenta) {
		LOG.info("CONSULTA PROPOSTA RASCUNHO CRD : {}|{}|{}", tipoPessoa, cpfCnpj, codigoFerramenta);
		try {
			return clienteService.obterPropostaRascunho(tipoPessoa, cpfCnpj, codigoFerramenta);

		} catch (RuntimeException ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A PROPOSTA RASCUNHO");
			return null;
		}
	}

	@PostMapping(value = "/atualizarRascunhoCliente/{step}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String atualizaPropostaRascunho(@ModelAttribute CrmCredenciamentoDto crmDto,
										   @PathVariable("step") String step) {
		LOG.info("ATUALIZAR PROPOSTA RASCUNHO CLIENTE : {} : {}", crmDto.getNumeroProposta(), step);
		try {
			clienteService.atualizarPropostaRascunho(crmDto, step);
			return CrdCrmUtils.SUCESSO;
				
		} catch (RuntimeException ex) {
			LOG.error("OCORREU UM ERRO NA ATUALIZACAO DA PROPOSTA RASCUNHO CLIENTE {}", step);
			return "ERROR";
		}

	}

	@PostMapping(value = "/saveCliente", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public CrmJsonResponse<CrmCredenciamentoDto> saveCliente(@ModelAttribute @Valid CrmCredenciamentoDto crmDto,
			BindingResult result, Model model) {
		LOG.info("VALIDAR CAMPOS NEXT PAGE CLIENTE : {}", crmDto.getNumeroProposta());
		
		countErrors = ZERO;
		CrmJsonResponse<CrmCredenciamentoDto> response = new CrmJsonResponse<CrmCredenciamentoDto>();
		Map<String, String> messageFields = validadorCamposCliente(crmDto, result);
		
		if(null == messageFields) {
			response.setValidated(true);
			response.setObjectModel(crmDto);

		}else {
			response.setValidated(false);
			response.setErrorMessages(messageFields);
		}
		return response;
	}
	
	/**
	 * Método responsavel por efetuar as validações campos obrigatórios
	 * 
	 * @param crmDto
	 * @param result
	 */
	private Map<String, String> validadorCamposCliente(CrmCredenciamentoDto crmDto, BindingResult result) {
		
		Map<String, String> errors = result.getFieldErrors().stream().collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage));
		List<String> fieldsExclude = new ArrayList<String>();
		//CELULAR
		if(StringEmptyOrNull(crmDto.getDddCelular()) && StringEmptyOrNull(crmDto.getDddCelular())) {
			fieldsExclude.add("dddCelular"); fieldsExclude.add("telCelular");
		}
		//EMAIL
		if(null != crmDto.getNaoPossuiEmail()) {
			fieldsExclude.add("email");
		}
		//PROPRIETARIOS	
		if(crmDto.getTpPessoa().equals(PESSOA_FISICA)){
			
			fieldsExclude.add("nomeSegundoProp");fieldsExclude.add("cpfSegundoProp");fieldsExclude.add("dtNascSegundoProp");
			fieldsExclude.add("nomeTerceiroProp");fieldsExclude.add("cpfTerceiroProp");fieldsExclude.add("dtNascTerceiroProp");
			
		}else {
			//PROPRIETARIO 2
			if(StringEmptyOrNull(crmDto.getNomeSegundoProp()) && StringEmptyOrNull(crmDto.getCpfSegundoProp()) && StringEmptyOrNull(crmDto.getDtNascSegundoProp())) {
				fieldsExclude.add("nomeSegundoProp");fieldsExclude.add("cpfSegundoProp");fieldsExclude.add("dtNascSegundoProp");
			}
			if(StringEmptyOrNull(crmDto.getNomeTerceiroProp()) && StringEmptyOrNull(crmDto.getCpfTerceiroProp()) && StringEmptyOrNull(crmDto.getDtNascTerceiroProp())) {
				fieldsExclude.add("nomeTerceiroProp");fieldsExclude.add("cpfTerceiroProp");fieldsExclude.add("dtNascTerceiroProp");
			}

		}
		if(!fieldsExclude.isEmpty()) {
			//EXCLUI AS MENSAGENS DE ERRO
			cleanMessageErrors(errors, fieldsExclude);
		}
		//FIELDS VIEW CLIENTE
		List<String> fieldsCliente = Arrays.asList("nome","cpf","dtNascimento","dddPrincipal","telPrincipal", "dddCelular","telCelular","email",
												"nomeSegundoProp", "dtNascSegundoProp", "cpfSegundoProp","nomeTerceiroProp","dtNascTerceiroProp", "cpfTerceiroProp");

		errors.forEach((f,m) -> {if(fieldsCliente.contains(f)) {countErrors++;}});
		//NAO POSSUI ERROS
		if(countErrors == ZERO ) {
			// EMAIL VALIDO
			if(null == crmDto.getNaoPossuiEmail()){
				Pattern pattern = Pattern.compile(EMAIL_PATTERN, Pattern.CASE_INSENSITIVE);
				Matcher matcher = pattern.matcher(crmDto.getEmail());
	            if (!matcher.matches()) {
	            	errors.put("email", "Email inválido");
	            	countErrors ++;
	            }
			}
			//CPF PROPRIETARIO PJ
			if(crmDto.getTpPessoa().equals(PESSOA_JURIDICA)) {
				if(!isCpfValido(StringUtils.leftPad(crmDto.getCpf(),11,ZERO_S))) {
					errors.put("cpf", "CPF inválido");
					countErrors ++;
				}
				//SEGUNDO PROPRIETARIO
				if(!StringEmptyOrNull(crmDto.getCpfSegundoProp())){
					if(!isCpfValido(StringUtils.leftPad(crmDto.getCpfSegundoProp(),11,ZERO_S))) {
						errors.put("cpfSegundoProp", "CPF inválido");
						countErrors ++;
					}
				}
				//TERCEIRO PROPRIETARIO
				if(!StringEmptyOrNull(crmDto.getCpfTerceiroProp())){
					if(!isCpfValido(StringUtils.leftPad(crmDto.getCpfTerceiroProp(),11,ZERO_S))) {
						errors.put("cpfTerceiroProp", "CPF inválido");
						countErrors ++;
					}
				}
			}
		}			
		return countErrors == ZERO ? null : errors;
	}
}


