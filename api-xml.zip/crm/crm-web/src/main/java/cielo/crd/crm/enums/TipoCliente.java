package cielo.crd.crm.enums;

import static cielo.crd.crm.utils.CrdCrmUtils.*;
/**
 * Classe ENUM para tratamento de cliente existente
 * @author @Cielo SA
 * @since Release 04 - Sprint 03
 * @version 1.0.0
 */
public enum TipoCliente {

	NAO_CADASTRADO("N"), 
	CLIENTE_EXISTENTE("S"),
	CLIENTE_MULTIVAN("M");
	
	private String indicadorTipoCliente;
	
	private TipoCliente(String indicadorTipoCliente) {
		this.indicadorTipoCliente = indicadorTipoCliente;
	}
	
	/**
	 * Método responsavel por verificar se o cliente é valido (NAO_CADASTRADO || CLIENTE_MULTIVAN)
	 * @param indicador
	 * @return Boolean
	 */
	public static String isClienteValido(String indicador) {
		for(TipoCliente tipo : TipoCliente.values()) {
			if(indicador.equals(tipo.indicadorTipoCliente)) {
				return (indicador.equals("N") || indicador.equals("M") ? CLIENTE_NAO_EXISTE : CLIENTE_EXISTE);
			}
		}
		return CLIENTE_EXISTE;
	}
}
