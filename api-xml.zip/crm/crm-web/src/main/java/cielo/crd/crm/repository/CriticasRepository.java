package cielo.crd.crm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.Criticas;


@Repository
public interface CriticasRepository extends JpaRepository<Criticas, Long>{
	
}
