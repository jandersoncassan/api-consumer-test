package cielo.crd.crm.service.impl;

import static cielo.crd.crm.utils.CrdCrmUtils.*;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.rpc.ServiceException;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucaoCapturaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.SolucoesCaptura;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoResponseType;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.NumeroLogicoType;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.OperadoraType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.BancoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CriticaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DadosProprietarioType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.DomiciliosBancarios;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EnderecoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.EstabelecimentoComercialType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.TelefoneType;
import cielo.crd.crm.domain.Criticas;
import cielo.crd.crm.enums.Ferramenta;
import cielo.crd.crm.enums.StatusCredenciamento;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.CrmJsonResponse;
import cielo.crd.crm.model.InfoEquipamentos;
import cielo.crd.crm.model.Operadora;
import cielo.crd.crm.model.Equipamento;
import cielo.crd.crm.repository.CriticasRepository;
import cielo.crd.crm.service.DadosContratacaoService;
import cielo.crd.crm.service.osb.CrdCrmServicesOsb;

/**
 * Classe de serviço responsavel pelas efetivação do credenciamento do cliente
 * 
 * @author @Cielo SA
 * @since 1.0.0
 */
@Service
public class DadosContratacaoServiceImpl implements DadosContratacaoService {

	private static final Logger LOG = LoggerFactory.getLogger(DadosContratacaoServiceImpl.class);

	@Autowired
	private CrdCrmServicesOsb servicesOsb;

	@Autowired
	private CriticasRepository criticasRepository;

	@Override
	public CrmJsonResponse<CrmCredenciamentoDto> efetivarCredenciamento(CrmCredenciamentoDto proposta) {
		LOG.info("EFETIVANDO CREDENCIAMENTO DO CLIENTE {}", proposta.getNumeroProposta());
		try {
			CredenciarClienteRequest request = new CredenciarClienteRequest();
			request.setCodigoFerramenta(proposta.getCodigoFerramenta());
			request.setLoginUsuario(proposta.getUsuarioCentral());
			if (Ferramenta.isSmart(proposta.getCodigoFerramenta())) {
				request.setCodigoTipoPerfilSmart(proposta.getCodPerfilSmart());
			}
			popularDadosEstabelecimento(request, proposta);
			popularSolucaoCaptura(request, proposta);

			CredenciarClienteResponse response = servicesOsb.credenciarCliente(request);

			return tratarCredenciamentoResponse(proposta, response);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("ERRO CREDENCIAR CLIENTE {} : {}", proposta.getNumeroProposta(), ex);
			throw new RuntimeException("ERRO EFETIVACAO CREDENCIAMENTO");
		}

	}

	/**
	 * Método responsavel por popular as informações do estabelecimento
	 * 
	 * @param request
	 * @param proposta
	 */
	private void popularDadosEstabelecimento(CredenciarClienteRequest request, CrmCredenciamentoDto proposta) {

		LOG.info("POPULAR DADOS ESTABELECIMENTO CREDENCIAR CLIENTE ");
		EstabelecimentoComercialType estabelecimento = new EstabelecimentoComercialType();

		String tipoPessoa = proposta.getTpPessoa();
		estabelecimento.setCodigoTipoPessoa(tipoPessoa);
		if (tipoPessoa.equals(PESSOA_FISICA)) {
			estabelecimento.setNumeroCpfCnpj(Long.valueOf(onlyNumber(proposta.getCpf())));
			estabelecimento.setNomeRazaoSocial(proposta.getNome());
		} else {
			estabelecimento.setNumeroCpfCnpj(Long.valueOf(onlyNumber(proposta.getCnpj())));
			estabelecimento.setNomeRazaoSocial(proposta.getRazaoSocial());
			estabelecimento.setNomeFantasia(proposta.getNomeFantasia());
		}
		estabelecimento.setCodigoAfiliador(proposta.getCodigoProducao());
		estabelecimento.setNomePlaqueta(tratarNomePlaqueta(proposta.getNomePlaqueta()));
		estabelecimento.setCodigoRamoAtividade(proposta.getRamoAtividade());
		estabelecimento.setValorMedioFaturamento(BigDecimal.valueOf(proposta.getFaturamento()));

		if (null != proposta.getArv())
			estabelecimento.setTaxaArv(new BigDecimal(proposta.getTxArv()));
		
		estabelecimento.setCodigoTipoPlanoCielo(proposta.getTpPlano());
		
		
		estabelecimento.setQuantidadeDiasLiquidacao(proposta.getTpPlano().equals(PLANO_CIELO_LIVRE)	? DOIS 
				: Optional.ofNullable(proposta.getDiasLiqControle()).orElse(ZERO));//SE FOR ALUGUEL ZERO PASSAMOS 02 FIXO

		popularProprietarios(proposta, estabelecimento, tipoPessoa);
		popularTelefones(proposta, estabelecimento);
		popularEndereco(proposta, estabelecimento);
		popularDomicilio(proposta, estabelecimento);

		request.setEstabelecimentoComercial(estabelecimento);

	}

	/**
	 * Tratamento campo Nome Plaqueta
	 * 
	 * @param nomePlaqueta
	 * @return
	 */
	private String tratarNomePlaqueta(String nomePlaqueta) {
		if (nomePlaqueta.contains(",")) {
			nomePlaqueta = nomePlaqueta.split(",")[0];
		}
		return nomePlaqueta;
	}

	/**
	 * Método responsavel por popular as informações de proprietários
	 * 
	 * @param proposta
	 * @param estabelecimento
	 * @param tipoPessoa
	 */
	private void popularProprietarios(CrmCredenciamentoDto proposta, EstabelecimentoComercialType estabelecimento,
			String tipoPessoa) {
		LOG.info("POPULAR DADOS PROPRIETARIOS CREDENCIAR CLIENTE ");
		List<DadosProprietarioType> proprietarios = new ArrayList<>();

		DadosProprietarioType proprietario = new DadosProprietarioType();

		popularProprietarios(proprietario, proposta.getNome(), proposta.getCpf(), proposta.getDtNascimento(),
				proprietarios);

		if (tipoPessoa.equals(PESSOA_JURIDICA)) {
			if (!proposta.getNomeSegundoProp().isEmpty() && !proposta.getCpfSegundoProp().isEmpty()
					&& proposta.getDtNascSegundoProp() != null) {

				DadosProprietarioType proprietario2 = new DadosProprietarioType();
				popularProprietarios(proprietario2, proposta.getNomeSegundoProp(), proposta.getCpfSegundoProp(),
						proposta.getDtNascSegundoProp(), proprietarios);
			}

			if (!proposta.getNomeTerceiroProp().isEmpty() && !proposta.getCpfTerceiroProp().isEmpty()
					&& proposta.getDtNascTerceiroProp() != null) {
				DadosProprietarioType proprietario3 = new DadosProprietarioType();

				popularProprietarios(proprietario3, proposta.getNomeTerceiroProp(), proposta.getCpfTerceiroProp(),
						proposta.getDtNascTerceiroProp(), proprietarios);
			}
		}

		DadosProprietarioType[] arrayProprietarios = new DadosProprietarioType[proprietarios.size()];

		estabelecimento.setProprietarios(proprietarios.toArray(arrayProprietarios));

	}

	/**
	 * Método responsavel por popular as informações de proprietários
	 * 
	 * @param proprietario2
	 * @param nomeSegundoProp
	 * @param cpfSegundoProp
	 * @param dtNascimento
	 * @param proprietarios
	 */
	private void popularProprietarios(DadosProprietarioType proprietario, String nomeSegundoProp, String cpfSegundoProp,
			String dtNascimento, List<DadosProprietarioType> proprietarios) {

		proprietario.setNome(nomeSegundoProp);
		proprietario.setNumeroCpf(onlyNumber(cpfSegundoProp));
		proprietario.setDataNascimento(dateToStringApi(dtNascimento));
		proprietarios.add(proprietario);
	}

	/**
	 * Método responsavel porpopular as informações de telefone do cliente
	 * 
	 * @param proposta
	 * @param estabelecimento
	 */
	private void popularTelefones(CrmCredenciamentoDto proposta, EstabelecimentoComercialType estabelecimento) {
		LOG.info("POPULAR DADOS TELEFONES ");

		estabelecimento.setEmailContato(proposta.getEmail());

		List<TelefoneType> telefones = new ArrayList<>();
		TelefoneType telefoneComercial = new TelefoneType();
		TelefoneType telefoneCelular = new TelefoneType();

		// TELEFONES
		if (null != proposta.getDddCelular() && !proposta.getDddCelular().isEmpty()) {
			popularTelefone(telefoneComercial, TEL_COMERCIAL, proposta.getDddPrincipal(), proposta.getTelPrincipal(),
					telefones);
			popularTelefone(telefoneCelular, TEL_CELULAR, proposta.getDddCelular(), proposta.getTelCelular(),
					telefones);

		} else if (null == proposta.getDddCelular() || proposta.getDddCelular().isEmpty()) {
			popularTelefone(telefoneComercial, TEL_COMERCIAL, proposta.getDddPrincipal(), proposta.getTelPrincipal(),
					telefones);
		}
		TelefoneType[] arrayTelefones = new TelefoneType[telefones.size()];
		estabelecimento.setTelefonesEstabelecimento(telefones.toArray(arrayTelefones));
	}

	/**
	 * Método responsavel por popular as informações de Telefone Comercial
	 * 
	 * @param telefoneComercial
	 * @param dddCelular
	 * @param telCelular
	 * @param telefones
	 */
	private void popularTelefone(TelefoneType telefone, int tipo, String dddCelular, String telCelular,
			List<TelefoneType> telefones) {
		telefone.setTipoTelefone(tipo);
		telefone.setNumeroDDD(Integer.valueOf(onlyNumber(dddCelular)));
		telefone.setNumeroTelefone(onlyNumber(telCelular));

		telefones.add(telefone);
	}

	/**
	 * Método responsavel por popular as informações de endereço do cliente
	 * 
	 * @param estabelecimento
	 * @param rascunho
	 */
	private void popularEndereco(CrmCredenciamentoDto proposta, EstabelecimentoComercialType estabelecimento) {

		List<EnderecoType> listaEnderecos = new ArrayList<>();
		if (null != proposta.getEndPrincMsmCorresp()) {
			createEnderecoIdem(proposta, listaEnderecos);
		} else {
			createEnderecos(proposta, listaEnderecos);
		}
		EnderecoType[] enderecos = new EnderecoType[listaEnderecos.size()];
		estabelecimento.setEnderecosEstabelecimento(listaEnderecos.toArray(enderecos));
	}

	/**
	 * Método responsavel por popular as informações de Endereco
	 * 
	 * @param rascunho
	 * @param tipoEndereco
	 */
	private void createEnderecoIdem(CrmCredenciamentoDto rascunho, List<EnderecoType> listaEnderecos) {
		String[] infoEndereco = getInfoEndereco(rascunho, END_COMERCIAL);
		listaEnderecos.add(createEndereco(END_COMERCIAL, infoEndereco[CEP], infoEndereco[LOGRADOURO],
				infoEndereco[NUMERO], infoEndereco[COMPLEMENTO], infoEndereco[CIDADE], infoEndereco[SIGLA]));
		listaEnderecos.add(createEndereco(END_CORRESPONDENCIA, infoEndereco[CEP], infoEndereco[LOGRADOURO],
				infoEndereco[NUMERO], infoEndereco[COMPLEMENTO], infoEndereco[CIDADE], infoEndereco[SIGLA]));
	}

	/**
	 * Método responsavel por popular as informações de Endereco
	 * 
	 * @param rascunho
	 * @param tipoEndereco
	 * @param sigla
	 * @param cidade
	 * @param complemento
	 * @param numero
	 * @param logradouro
	 * @param cep
	 */
	private EnderecoType createEndereco(int tipoEndereco, String cep, String logradouro, String numero,
			String complemento, String cidade, String sigla) {
		EnderecoType endereco = new EnderecoType();
		endereco.setTipoEndereco(tipoEndereco);
		endereco.setNumeroCEP(cep.equals(STRING_EMPTY) ? ZERO : Integer.valueOf(cep.replaceAll("[^0-9]", "")));
		endereco.setNomeLogradouro(logradouro);
		endereco.setNumeroLogradouro(numero);
		endereco.setDescricaoComplementoEndereco(complemento);
		// endereco.setNomeBairro(STRING_EMPTY);//NÃO EXISTE ESSA INFORMAÇÃO NO SEC
		endereco.setNomeCidade(cidade);
		endereco.setSiglaEstado(sigla);
		return endereco;
	}

	/**
	 * Método responsave por obter as informações de endereço
	 * 
	 * @param rascunho
	 * @param tipoEndereco
	 * @return
	 */
	private String[] getInfoEndereco(CrmCredenciamentoDto rascunho, int tipoEndereco) {

		String cep = tipoEndereco == END_COMERCIAL ? rascunho.getCepComercial() : rascunho.getCepCorrespondencia();
		String logradouro = tipoEndereco == END_COMERCIAL ? rascunho.getLogradouroComercial()
				: rascunho.getLogradouroCorrespondencia();
		String numero = tipoEndereco == END_COMERCIAL ? rascunho.getNumeroComercial()
				: rascunho.getNumeroCorrespondencia();
		String complemento = tipoEndereco == END_COMERCIAL ? rascunho.getComplementoComercial()
				: rascunho.getComplementoCorrespondencia();
		String cidade = tipoEndereco == END_COMERCIAL ? rascunho.getCidadeComercial()
				: rascunho.getCidadeCorrespondencia();
		String sigla = tipoEndereco == END_COMERCIAL ? rascunho.getEstadoComercial()
				: rascunho.getEstadoCorrespondencia();

		return new String[] { cep, logradouro, numero, complemento, cidade, sigla };
	}

	/**
	 * Método responsavel por criar endereco comercial e correspondecia
	 * 
	 * @param rascunho
	 * @param listaEnderecos
	 */
	private void createEnderecos(CrmCredenciamentoDto rascunho, List<EnderecoType> listaEnderecos) {
		String[] infoEndComercial = getInfoEndereco(rascunho, END_COMERCIAL);
		String[] infoEndCorrespondencia = getInfoEndereco(rascunho, END_CORRESPONDENCIA);
		listaEnderecos.add(createEndereco(END_COMERCIAL, infoEndComercial[CEP], infoEndComercial[LOGRADOURO],
				infoEndComercial[NUMERO], infoEndComercial[COMPLEMENTO], infoEndComercial[CIDADE],
				infoEndComercial[SIGLA]));
		listaEnderecos.add(createEndereco(END_CORRESPONDENCIA, infoEndCorrespondencia[CEP],
				infoEndCorrespondencia[LOGRADOURO], infoEndCorrespondencia[NUMERO], infoEndCorrespondencia[COMPLEMENTO],
				infoEndCorrespondencia[CIDADE], infoEndCorrespondencia[SIGLA]));
	}

	/**
	 * Método responsavel por popular as informações de Domicilio Bancario
	 * 
	 * @param estabelecimento
	 * @param rascunho
	 */
	private void popularDomicilio(CrmCredenciamentoDto rascunho, EstabelecimentoComercialType estabelecimento) {
		BancoType banco = new BancoType();
		banco.setTipoConta(rascunho.getTipoConta());
		banco.setCodigoBanco(rascunho.getBanco());
		banco.setNumeroAgencia(rascunho.getAgencia());
		if (banco.getCodigoBanco().equals(CAIXA_ECONOMICA)) {
			banco.setNumeroContaCorrente(tratarOperacao(banco, rascunho));
		} else
			banco.setNumeroContaCorrente(rascunho.getConta().concat(rascunho.getDigito()));

		DomiciliosBancarios domicilios = new DomiciliosBancarios();
		domicilios.setDomicilioBancario(banco);

		estabelecimento.setDomiciliosBancarios(domicilios);
	}

	/**
	 * Método responsavel por tratar o numero da conta corrente + operacao
	 * 
	 * @param banco
	 * @param rascunho
	 * @return
	 */
	private String tratarOperacao(BancoType banco, CrmCredenciamentoDto rascunho) {
		if (rascunho.getTpPessoa().equals(PESSOA_FISICA)) {
			if (banco.getTipoConta().equals(CONTA_CORRENTE)) {
				return getNumeroConta(OPER_PF_CORRENTE, rascunho.getConta(), rascunho.getDigito());
			} else {
				return getNumeroConta(OPER_PF_POUPANCA, rascunho.getConta(), rascunho.getDigito());
			}
		} else {
			return getNumeroConta(OPER_PJ_CORRENTE, rascunho.getConta(), rascunho.getDigito());
		}
	}

	/**
	 * Formata o numero da conta corrente
	 * 
	 * @param operacao
	 * @param conta
	 * @param digito
	 * @return
	 */
	private String getNumeroConta(String operacao, String conta, String digito) {
		return (operacao.concat(StringUtils.leftPad(conta, 8, ZERO_S).concat(digito)));
	}

	/**
	 * Método responsavel por popular as informações de Solução de Captura
	 * 
	 * @param request
	 * @param rascunho
	 */
	private void popularSolucaoCaptura(CredenciarClienteRequest request, CrmCredenciamentoDto proposta) {
		LOG.info("POPULAR DADOS SOLUCAO CAPTURA");
		SolucoesCaptura solucoes = new SolucoesCaptura();

		SolucaoCapturaType solucaoCaptura = new SolucaoCapturaType();
		solucaoCaptura.setCodigoSolucaoCaptura(proposta.getSolCaptura());
		Optional<String> indEntregaMaquina = Optional.ofNullable(proposta.getIndEntregaMaquina());
		solucaoCaptura.setIndicadorEntregaMaquina(indEntregaMaquina.isPresent() ? Boolean.TRUE : Boolean.FALSE);
		solucaoCaptura.setCodigoPacoteEcommerce(objectNullToString(proposta.getPotencialVendas()));
		solucaoCaptura.setIndicadorPagamentoPorLink(null != proposta.getPagamentoLink() ? Boolean.TRUE : Boolean.FALSE);
		
		solucaoCaptura.setQuantidadeEquipamentos(isQtdadeEquipamentoFixa(proposta.getTpPlano(), proposta.getSolCaptura())? 1: proposta.getQtdadeMaquinas());
		
		solucaoCaptura.setCodigoHorarioFuncionamento(proposta.getCodHorarioAtendimento());
		if (!solucaoCaptura.getCodigoSolucaoCaptura().equals(MOBILE)
				&& !Ferramenta.isFeiras(proposta.getCodigoFerramenta())) {
			solucaoCaptura.setIndicadorAutoServico(
					proposta.getEntregaMaquina().equals(POSTO_ATENDIMENTO) ? Boolean.TRUE : Boolean.FALSE);
		} else {
			solucaoCaptura.setIndicadorAutoServico(Boolean.FALSE);
		}
		if (null != proposta.getOperadora() && !proposta.getOperadora().isEmpty()) {
			int[] operadoras = proposta.getOperadora().stream().mapToInt(i -> i).toArray();
			solucaoCaptura.setOperadoras(operadoras);
		}
		solucoes.setSolucaoCaptura(solucaoCaptura);

		request.setSolucoesCaptura(solucoes);
	}

	@Override
	public InfoEquipamentos obterNumeroLogico(Long numeroProposta) {
		LOG.info("CONSULTAR NUMERO LOGICO - PROPOSTA {}", numeroProposta);
		try {
			ConsultarNumeroLogicoResponseType response = servicesOsb.obterInfoNumeroLogico(numeroProposta);
			return tratarInfoNumeroLogico(response);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("ERRO CONSULTAR NUMERO LOGICO - PROPOSTA {} : {}", numeroProposta, ex);
			throw new RuntimeException("ERRO CONSULTAR NUMERO LOGICO");
		}
	}

	/**
	 * Método responsavel por tratar o response na consulta de numero logico
	 * 
	 * @param response
	 * @return
	 */
	private InfoEquipamentos tratarInfoNumeroLogico(ConsultarNumeroLogicoResponseType response) {
		InfoEquipamentos infoEquipamentos = new InfoEquipamentos();
		infoEquipamentos.setCodigoStatus(response.getStatus());
		infoEquipamentos.setInfoEquipamentos(Arrays.asList(response.getNumerosLogico()).stream()
				.map(info -> popularInfoNumeroLogico(info)).collect(Collectors.toList()));
		return infoEquipamentos;
	}

	/**
	 * Método responsavel por tratar as informações de equipamentos
	 * 
	 * @param info
	 * @return
	 */
	private Equipamento popularInfoNumeroLogico(NumeroLogicoType info) {
		Equipamento equipamento = new Equipamento();
		equipamento.setNumeroLogico(Integer.valueOf(info.getNumero().toString()));
		equipamento.setDigNumLogico(info.getDigito());
		// CODIGO DE ACESSO SOMENTE PARA ENTREGA DE MAQUINA TRUE
		Optional<Integer> codigoAcesso = Optional.ofNullable(info.getCodigoAcesso());
		equipamento.setCodigoAcesso(codigoAcesso.isPresent() ? codigoAcesso.get() : 0);
		// SLA SOMENTE PARA ENTREGA DE MAQUINAS FALSE
		Optional<Calendar> slaIntalacao = Optional.ofNullable(info.getSlaInstalacaoEquipamento());
		equipamento.setSlaInstalacao(
				slaIntalacao.isPresent() ? DateFormatUtils.format(slaIntalacao.get(), "dd/MM/yyyy HH:mm:SS") : "");

		Optional<OperadoraType[]> operadoras = Optional.ofNullable(info.getOperadoras());
		if(operadoras.isPresent())
			equipamento.setListaOperadoras(Arrays.asList(info.getOperadoras()).stream()
					.map(operadora -> popularOperadora(operadora)).collect(Collectors.toList()));

		return equipamento;
	}

	/**
	 * Método responsavel por tratar as informações de operadora de telefonia
	 * 
	 * @param operadoraType
	 * @return
	 */
	private Operadora popularOperadora(OperadoraType operadoraType) {
		Operadora operadora = new Operadora();
		operadora.setCodigo(operadoraType.getCodigo());
		operadora.setDescricao(operadoraType.getDescricao());
		operadora.setTipo(operadoraType.getTipo());
		return operadora;
	}

	/**
	 * Método responsavel por tratar o retorno do credenciamento da proposta
	 * 
	 * @param proposta
	 * @param response
	 */
	private CrmJsonResponse<CrmCredenciamentoDto> tratarCredenciamentoResponse(CrmCredenciamentoDto proposta,
			CredenciarClienteResponse response) {
		LOG.info("TRATAMENTO RETORNO CREDENCIAMENTO PROPOSTA - PROPOSTA {}", proposta.getNumeroProposta());
		CrmJsonResponse<CrmCredenciamentoDto> retorno = new CrmJsonResponse<>();
		String codigoStatus = response.getCodigoStatus();

		if (codigoStatus.equals(StatusCredenciamento.SUCESSO.getCodigo())) {
			proposta.setNumeroEc(response.getNumeroEc());
			retorno.setValidated(true);
		} else {
			retorno.setValidated(false);
			Map<String, String> criticas = new HashMap<>();

			if (codigoStatus.equals(StatusCredenciamento.REJEITADA.getCodigo())) {
				atualizarCriticas(criticas, response.getCriticas());

			} else if (codigoStatus.equals(StatusCredenciamento.REJEITADA_FALHA_SISTEMICA.getCodigo())) {
				atualizarErroSistemico(criticas);
			}
			retorno.setErrorMessages(criticas);
		}
		retorno.setObjectModel(proposta);
		return retorno;
	}

	/**
	 * Atualização das mensagens consistências de negócio
	 * 
	 * @param listaCriticas
	 * @param criticas
	 */
	private void atualizarCriticas(Map<String, String> listaCriticas, CriticaType[] criticas) {
		for (CriticaType critica : Arrays.asList(criticas)) {
			String codigoCritica = critica.getCodigoCritica();
			Criticas entity = criticasRepository.findOne(Long.valueOf(codigoCritica));
			listaCriticas.put(codigoCritica, entity.getDescricaoCentral());
		}
	}

	/**
	 * Atualização da mensagem Erro Sistêmico
	 * 
	 * @param criticas
	 */
	private void atualizarErroSistemico(Map<String, String> criticas) {
		String codigo = StatusCredenciamento.REJEITADA_FALHA_SISTEMICA.getCodigo();
		Criticas entity = criticasRepository.findOne(Long.valueOf(codigo));// ERRO SISTEMICA
		criticas.put(codigo, entity.getDescricaoCentral());
	}

}
