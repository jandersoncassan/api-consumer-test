package cielo.crd.crm.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class SolucaoEquipamentoPk implements Serializable{

	private static final long serialVersionUID = 1L;

	private Long codSolucaoCaptura;
	
	private Integer codigoFerramenta;

	/**
	 * @return the codSolucaoCaptura
	 */
	public Long getCodSolucaoCaptura() {
		return codSolucaoCaptura;
	}

	/**
	 * @param codSolucaoCaptura the codSolucaoCaptura to set
	 */
	public void setCodSolucaoCaptura(Long codSolucaoCaptura) {
		this.codSolucaoCaptura = codSolucaoCaptura;
	}

	/**
	 * @return the codigoFerramenta
	 */
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}

	/**
	 * @param codigoFerramenta the codigoFerramenta to set
	 */
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codSolucaoCaptura == null) ? 0 : codSolucaoCaptura.hashCode());
		result = prime * result + ((codigoFerramenta == null) ? 0 : codigoFerramenta.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SolucaoEquipamentoPk other = (SolucaoEquipamentoPk) obj;
		if (codSolucaoCaptura == null) {
			if (other.codSolucaoCaptura != null)
				return false;
		} else if (!codSolucaoCaptura.equals(other.codSolucaoCaptura))
			return false;
		if (codigoFerramenta == null) {
			if (other.codigoFerramenta != null)
				return false;
		} else if (!codigoFerramenta.equals(other.codigoFerramenta))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SolucaoEquipamentoPk [codSolucaoCaptura=" + codSolucaoCaptura + ", codigoFerramenta=" + codigoFerramenta
				+ "]";
	}
	
	

}
