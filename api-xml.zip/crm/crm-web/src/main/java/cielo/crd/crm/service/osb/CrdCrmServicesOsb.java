package cielo.crd.crm.service.osb;

import java.net.MalformedURLException;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaResponse;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoResponseType;
import br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.ListarBancosResponse;
import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaResponseType;
import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPResponse;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazoResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.ConsultarSolucaoCapturaPorFerramentaResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoRequestType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v4.consultarcliente.ConsultarClienteResponseType;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoResponseType;

/**
 * Interface responsavel pelos metodos de serviço OSB
 * 
 * @author @CieloSA
 * @since 1.0.0
 */
public interface CrdCrmServicesOsb {

	/**
	 * Método responsavel por verificar a exist~encia do cliente no SEC
	 * 
	 * @param cpfCnpj
	 * @return
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	ConsultarClienteResponseType consultarExistenciaCliente(final String cpfCnpj)
			throws RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por obter as informações de proposta rascunho no CRD
	 * 
	 * @param tipoPessoa
	 * @param cpfCnpj
	 * @param codigoFerramenta
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	ConsultarPropostaRascunhoResponse obterPropostaRascunho(final String tipoPessoa, final Long cpfCnpj,
			final Integer codigoFerramenta) throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel por atualizar as informações de rascunho
	 * 
	 * @param request
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	void atualizarPropostaRascunho(final AtualizarDadosParciaisPropostaRascunhoRequest request)
			throws Fault, RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por obter a lista de Ramos de Atividades parametrizadas no
	 * CRD
	 * 
	 * @param tipoPessoa
	 * @param codigoFerramenta
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	ConsultarMccPorTipoPessoaFerramentaResponseType obterListaRamosAtividades(final String tipoPessoa,
			final Integer codigoFerramenta) throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel por devolver a lista de Taxas / Prazos cadastrados no SEC
	 * 
	 * @return
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	ConsultarListaTaxaPrazoResponseType consultarListaTaxas()
			throws RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por obter a lista com os horarios de funcionamento,
	 * tratamento Gtec
	 * 
	 * @return
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	ConsultarHorarioFuncionamentoResponseType obterHorarioFuncionamentoGtec()
			throws RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel pela consulta de CEP
	 * 
	 * @param cep
	 * @return
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	ConsultarCEPResponse consultarCep(final String cep)
			throws Fault, RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por obter a lista de bancos
	 * 
	 * @return
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	ListarBancosResponse obterListaBancos() throws Fault, RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por validar o Domicilio Bancario
	 * 
	 * @param codigoBanco
	 * @param numeroAgencia
	 * @param numeroConta
	 * @param tipoConta
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	ValidarDigitoAgenciaContaResponse validarDomicilioBancario(final String codigoBanco, final String numeroAgencia,
			final String numeroConta, final String tipoConta)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel por verificar se o domicilio bancario existe no cadastrado
	 * no SEC
	 * 
	 * @param codigoBanco
	 * @param numeroAgencia
	 * @param numeroConta
	 * @param tipoConta
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 */
	VerificarExistenciaDomicilioBancarioResponse verificarExistenciaDomicioBancario(final String codigoBanco,
			final String numeroAgencia, final String numeroConta, final String tipoConta)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel por efetivar o credenciamento do cliente
	 * 
	 * @param req
	 * @return
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	CredenciarClienteResponse credenciarCliente(final CredenciarClienteRequest req)
			throws Fault, RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por verificar a geração do numero lógico para a solução
	 * Mobile
	 * 
	 * @param numeroProposta
	 * @return
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	ConsultarNumeroLogicoResponseType obterInfoNumeroLogico(final Long numeroProposta)
			throws RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por obter a lista de soluções de captura equipamentos
	 * (quantidades maximas)
	 * 
	 * @param codigoFerramenta
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws SOAPException
	 * @throws RemoteException
	 */
	ConsultarListaParametrosSolucaoCapturaResponse obterListaSolucaoQtdEquipamentos(final Integer codigoFerramenta)
			throws MalformedURLException, ServiceException, Fault, RemoteException;

	/**
	 * Método responsavel por obter a lista de soluções de captura por ferramenta
	 * 
	 * @param codigoFerramenta
	 * @return
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	ConsultarSolucaoCapturaPorFerramentaResponse obterListaSolucaoCapturaFerramenta(final Integer codigoFerramenta)
			throws Fault, RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por popular a critica de domicilio bancario invalido
	 * 
	 * @param request
	 * @return
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 * @throws ServiceException
	 */
	RegistrarCriticaPropostaRascunhoResponseType popularCriticaContaInvalida(
			RegistrarCriticaPropostaRascunhoRequestType request)
			throws Fault, RemoteException, MalformedURLException, ServiceException;

	/**
	 * Método responsavel por obter a lista de faturamento serviço CRD
	 * @return
	 * @throws ServiceException
	 * @throws Fault
	 * @throws RemoteException
	 * @throws MalformedURLException
	 */
	ConsultarListaFaturamentoResponseType obterListaFaturamento()
			throws ServiceException, Fault, RemoteException, MalformedURLException;
}
