package cielo.crd.crm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.SolucaoEquipamento;

@Repository
public interface SolucaoEquipamentoRepository extends JpaRepository<SolucaoEquipamento, Long> {

	 @Query("SELECT s FROM SolucaoEquipamento s WHERE s.id.codSolucaoCaptura = :codSolucao AND s.id.codigoFerramenta = :codFerramenta") 
	 SolucaoEquipamento findByPk(@Param("codSolucao") Long codSolucao, @Param("codFerramenta") Integer codFerramenta);

}
