package cielo.crd.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.Banco;

@Repository
public interface BancoRepository extends JpaRepository<Banco, Long>{

	@Query("SELECT b FROM Banco b WHERE b.indicadorAtivo = 'S'") 
	List<Banco> getBancosCorrente();
	
	@Query("SELECT b FROM Banco b WHERE b.indicadorAtivo = 'S' AND b.indicadorPoupanca = 'S'") 
	List<Banco> getBancosPoupanca();

}
