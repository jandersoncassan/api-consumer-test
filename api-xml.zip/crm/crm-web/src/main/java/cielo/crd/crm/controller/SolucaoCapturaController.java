package cielo.crd.crm.controller;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cielo.crd.crm.domain.RamoAtividade;
import cielo.crd.crm.domain.TaxasPrazos;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.CrmJsonResponse;
import cielo.crd.crm.model.ItemFaturamento;
import cielo.crd.crm.model.ItemSolucaoCaptura;
import cielo.crd.crm.service.SolucaoCapturaService;
import static cielo.crd.crm.utils.CrdCrmUtils.*;

import static java.util.Comparator.*;

@Controller
public class SolucaoCapturaController {

	private static final Logger LOG = LoggerFactory.getLogger(SolucaoCapturaController.class);

	@Autowired
	private SolucaoCapturaService solucaoCapturaService;

	@GetMapping(value = "/getRamosAtividades/{tpPessoa}/{codigoFerramenta}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<List<RamoAtividade>> obterListaRamosAtividades(@PathVariable("tpPessoa") String tipoPessoa,
																		 @PathVariable("codigoFerramenta") Integer codigoFerramenta) {
		List<RamoAtividade> lista = solucaoCapturaService.obterListaRamosAtividades(tipoPessoa, codigoFerramenta);
		lista.sort(comparing(RamoAtividade::getDescricao));
		return new ResponseEntity<>(lista, HttpStatus.OK);
	}

	@GetMapping(value = "/getListaFaturamento", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<List<ItemFaturamento>> obterListaFaturamento() {
		List<ItemFaturamento> lista = solucaoCapturaService.getListaFaturamento();
		lista.sort(comparing(ItemFaturamento::getCodigo));
		return new ResponseEntity<>(lista, HttpStatus.OK);
	}

	@GetMapping(value = "/getSolucaoCaptura/{codigoFerramenta}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<List<ItemSolucaoCaptura>> obterListaSolucaoCaptura(@PathVariable("codigoFerramenta") Integer codigoFerramenta) {
		List<ItemSolucaoCaptura> lista = solucaoCapturaService.getOpcoesSolucaoCaptura(codigoFerramenta);
		lista.sort(comparing(ItemSolucaoCaptura::getCodigo));
		return new ResponseEntity<>(lista, HttpStatus.OK);
	}

	@GetMapping(value = "/getTaxasPrazos/{codigoMcc}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<TaxasPrazos> obterTaxaPrazo(@PathVariable("codigoMcc") Long codigoMcc) {
		TaxasPrazos taxasPrazos = solucaoCapturaService.obterTaxasPrazos(codigoMcc);
		return new ResponseEntity<>(taxasPrazos, HttpStatus.OK);
	}

	@GetMapping(value = "/getQtdadeEquipamentos/{codSolucaoCaptura}/{codigoFerramenta}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<Integer> obterQtdadeEquipamentos(@PathVariable("codSolucaoCaptura") Integer codSolucaoCaptura,
														   @PathVariable("codigoFerramenta") Integer codigoFerramenta) {
		Integer qtdEquipamentos = solucaoCapturaService.getQtdadeMaximaEquipamentos(codSolucaoCaptura, codigoFerramenta);
		return new ResponseEntity<>(qtdEquipamentos, HttpStatus.OK);
	}

	@PostMapping(value = "/atualizarRascunhoSolCaptura/{step}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String atualizaPropostaRascunho(@ModelAttribute CrmCredenciamentoDto crmDto,
			@PathVariable("step") String step) {
		LOG.info("ATUALIZAR PROPOSTA RASCUNHO SOLUCAO CAPTURA : {} : {}", crmDto.getNumeroProposta(), step);
		try {
			solucaoCapturaService.atualizarPropostaRascunho(crmDto, step);
			return SUCESSO;
		} catch (RuntimeException ex) {
			LOG.error("OCORREU UM ERRO NA ATUALIZACAO DA PROPOSTA RASCUNHO SOLUCAO CAPTURA {}", step);
			return "ERROR";
		}

	}

	@PostMapping(value = "/saveSolucaoCaptura", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public CrmJsonResponse<CrmCredenciamentoDto> saveSolucaoCaptura(@ModelAttribute CrmCredenciamentoDto crmDto, BindingResult result, Model model) {

		LOG.info("VALIDAR CAMPOS NEXT PAGE SOLUCAO CAPTURA : {}", crmDto.getNumeroProposta());

		CrmJsonResponse<CrmCredenciamentoDto> response = new CrmJsonResponse<CrmCredenciamentoDto>();
		validadorCamposCliente(crmDto, result);

		if (result.hasErrors()) {
			Map<String, String> errors = result.getFieldErrors().stream()
					.collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage));

			response.setValidated(false);
			response.setErrorMessages(errors);

		} else {
			response.setValidated(true);
			response.setObjectModel(crmDto);
		}
		return response;
	}

	@GetMapping(value = "/getFlagGetIsActiveFast", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<String> isActiveRecebaRapido() {
		String flag = solucaoCapturaService.isActiveRecebarapido();
		return new ResponseEntity<>(flag, HttpStatus.OK);
	}

	/**
	 * Método responsavel por efetuar as validações campos obrigatórios
	 * 
	 * @param crmDto
	 * @param result
	 */
	private void validadorCamposCliente(CrmCredenciamentoDto crmDto, BindingResult result) {
		//RAMO DE ATIVIDADE
		if (crmDto.getRamoAtividade().equals(OPT_SELECT)) {
			result.addError(new FieldError("crm", "ramoAtividade", "O campo Ramo de Atividade é obrigatório"));
		}
		//FATURAMENTO && DIAS LIQUIDACAO
		if (crmDto.getTpPlano().equals(PLANO_CIELO_CONTROLE)) {
			if(crmDto.getFaturamento().equals(OPT_SELECT)) {
				result.addError(new FieldError("crm", "faturamento", "O campo Faturamento total no mês é obrigatório"));
			}
			if(null == crmDto.getDiasLiqControle()) {
				result.addError(new FieldError("crm", "diasLiqControle", "O campo Dias para liquidação é obrigatório"));
			}
		}
		//SOLUÇÃO CAPTURA
		if (crmDto.getSolCaptura().equals(OPT_SELECT)) {
			result.addError(new FieldError("crm", "solCaptura", "O campo Solução de Captura é obrigatório"));
		}
		
		//QUANTIDADE DE MAQUINAS
		if(!crmDto.getSolCaptura().equals(MOBILE) && !crmDto.getSolCaptura().equals(ECOMMERCE_CHECKOUT) 
				&& !crmDto.getSolCaptura().equals(ECOMMERCE_WEBCSERVICE) && crmDto.getTpPlano().equals(PLANO_CONVENCIONAL) 
				&& !crmDto.getSolCaptura().equals(CIELO_ZIP)){
			
			if(crmDto.getQtdadeMaquinas().equals(OPT_SELECT))
				result.addError(new FieldError("crm", "qtdadeMaquinas", "O campo N° de Máquinas é obrigatório"));
		}
		//PACOTE E-COMMERCE
		if(crmDto.getSolCaptura().equals(ECOMMERCE_CHECKOUT)) {
			if(crmDto.getPotencialVendas().equals(OPT_SELECT))
				result.addError(new FieldError("crm", "potencialVendas", "O campo Pacote e-commerce é obrigatório"));
		}
		//TRATAMENTO OPERADORA LIO
		if(crmDto.getSolCaptura().equals(LIO_BASIC) || crmDto.getSolCaptura().equals(LIO_PLUS) ||
				crmDto.getSolCaptura().equals(LIO_BASIC_V2) || crmDto.getSolCaptura().equals(LIO_PLUS_V2)) {
			if(null != crmDto.getOperadora() && (crmDto.getOperadora().size() > ZERO && crmDto.getOperadora().size() != DOIS))
				result.addError(new FieldError("crm", "operadora", "Favor selecionar 02 operadoras"));
		}
		//TAXA ARV
		if (null != crmDto.getArv()) {
			if(null == crmDto.getTxArv())
				if(null == crmDto.getDiasLiqControle() || (null != crmDto.getDiasLiqControle() && !crmDto.getDiasLiqControle().equals(DOIS)))
					result.addError(new FieldError("crm", "arv", "Favor selecionar a Taxa de Antecipação"));
		}
	}
}
