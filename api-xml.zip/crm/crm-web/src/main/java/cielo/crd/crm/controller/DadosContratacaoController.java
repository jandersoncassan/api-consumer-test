package cielo.crd.crm.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.CrmJsonResponse;
import cielo.crd.crm.model.InfoEquipamentos;
import cielo.crd.crm.service.DadosContratacaoService;


@Controller
public class DadosContratacaoController {

	private static final Logger LOG = LoggerFactory.getLogger(DadosContratacaoController.class);
	@Autowired
	private DadosContratacaoService contratacaoService;
	
	@PostMapping(value = "/credenciar", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public CrmJsonResponse<CrmCredenciamentoDto> credenciar(@ModelAttribute CrmCredenciamentoDto proposta) {
		LOG.info("EFETIVANDO CREDENCIAMENTO DO CLIENTE");
		return contratacaoService.efetivarCredenciamento(proposta);
	}

	@GetMapping(value = "/obterNumeroLogico/{proposta}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<InfoEquipamentos> obterNumeroLogico(@PathVariable("proposta") Long numeroProposta) {
		
		try {		
			InfoEquipamentos infoNumeroLogico = contratacaoService.obterNumeroLogico(numeroProposta);
			return new ResponseEntity<>(infoNumeroLogico, HttpStatus.OK);	
			
		}catch(Exception ex) {
			return new ResponseEntity<>(null, HttpStatus.OK);
		}
	}
	

}
