package cielo.crd.crm.service;

import java.util.List;
import java.util.Optional;

import cielo.crd.crm.domain.Faturamento;
import cielo.crd.crm.domain.RamoAtividade;
import cielo.crd.crm.domain.SolucaoCaptura;
import cielo.crd.crm.domain.SolucaoEquipamento;
import cielo.crd.crm.domain.TaxasPrazos;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.ItemFaturamento;
import cielo.crd.crm.model.ItemSolucaoCaptura;

/**
 * Interface responsavel pelos servicos envolvendo as consistencias de solucao de captura
 * @author @Cielo SA
 * @since 1.0.0
 */
public interface SolucaoCapturaService {

	/**
	 * Método responsavel por obter a lista de Ramos de Atividades
	 * 
	 * @param tipoPessoa
	 * @param codigoFerramenta
	 * @return
	 */
	List<RamoAtividade> obterListaRamosAtividades(final String tipoPessoa, final Integer codigoFerramenta);

	/**
	 * Método responsavel por popular as informações de Ramos de Atividades na tabela embedded 'cache'
	 * 
	 * @param tipoPessoa
	 * @param codigoFerramenta
	 * @return 
	 */
	List<RamoAtividade> getListaRamosAtividadesCrd(final String tipoPessoa, final Integer codigoFerramenta);
	
	/**
	 * Método responsavel por obter a Taxas / Prazos de acordo com o MCC
	 * 
	 * @param codigoMcc
	 * @return
	 */
	TaxasPrazos obterTaxasPrazos(final Long codigoMcc);
	
	/**
	 * Método responsavel por obter a lista de Taxas / Prazo cadastrados no SEC
	 * 
	 * @return
	 */
	Optional<List<TaxasPrazos>> getListaTaxasPrazos();
	
	/**
	 * Método responsavel por atualizar as informações da proposta rascunho
	 * @param crmDto
	 * @param step
	 */
	String atualizarPropostaRascunho(final CrmCredenciamentoDto crmDto, final String step);
	
	/**
	 * Método responsavel por devolver a qtdade máxima de equipamentos para a solução de captura selecionada
	 * @param cosSolucaoCaptura
	 * @return
	 */
	Integer getQtdadeMaximaEquipamentos(final Integer cosSolucaoCaptura, final Integer codigoFerramenta);
	
	/**
	 * Método responsavel por devolver a lista solucação de captura (quantidade maxima de equipamentos)
	 * 
	 * @return
	 */
	Optional<List<SolucaoEquipamento>> obterListaSolucaoEquipamentos(final Integer codigoFerramenta);

	/**
	 * Método responsave por obter a lista de soluções de captura Tabela Interna Cache
	 * @param codigoFerramenta
	 * @return List<SolucaoCaptura>
	 */
	List<ItemSolucaoCaptura> getOpcoesSolucaoCaptura(final Integer codigoFerramenta);
	
	/**
	 * Método responsave por obter a lista de soluções de captura, parametrizadas no CRD
	 * @param codigoFerramenta
	 * @return List<SolucaoCaptura>
	 */
	Optional<List<SolucaoCaptura>> obterListaSolucaoCaptura(final Integer codigoFerramenta);

	/**
	 * Método responsavel pelo expurgo do caching
	 */
	void clearCaching();
	
	/**
	 * TODO Metodo paliativo flag de habilitar o receba rapido
	 * @return
	 */
	String isActiveRecebarapido();

	/**
	 * Método responsavel por obter a lista de faturamento combo
	 * @return
	 */
	List<ItemFaturamento> getListaFaturamento();

	/**
	 * Método responsavel por obter a lista de range de faturamento parametrizados no CRD
	 * @return
	 */
	Optional<List<Faturamento>> obterRangeFaturamento();

}
