package cielo.crd.crm.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import cielo.crd.crm.enums.Ferramenta;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.utils.CrdCrmUtils;

@Controller
public class HomeController {
	
	private static final String PAGE_ERROR="pages/403";
	private static final String HOME = "home";

	@RequestMapping("/")
	public String getPageHome(@RequestParam(value = "usuario") String usuario,
							  @RequestParam(value = "token") String token, 
							  @RequestParam(value = "codigoFerramenta") Integer codigoFerramenta, 
							  @RequestParam(value = "perfilSmart", defaultValue="0") Integer codPerfilSmart, Model model) {
		
		return getTryPageInit(model, usuario, token, codigoFerramenta, codPerfilSmart);
	}

	/**
	 * Método responsavel por direcionar a requisição da chamada
	 * 
	 * @param model
	 * @param usuario
	 * @param token
	 * @return
	 */
	private String getTryPageInit(Model model, String usuario, String token, Integer codigoFerramenta, Integer codPerfilSmart) {
		if (isParamEmptyOrTokenError(usuario, token, codigoFerramenta)) {
			return PAGE_ERROR;
		} else {
			putObjectModel(model, tratarUsuario(usuario), codigoFerramenta, codPerfilSmart);
			return HOME;
		}
	}

	/**
	 * Caso o tamanho do usuário seja > que 8 caracteres, precisamos limitar a 8
	 * 
	 * @param usuario
	 * @return
	 */
	private String tratarUsuario(String usuario) {
		if(usuario.length() > CrdCrmUtils.OITO) {
			usuario = usuario.substring(CrdCrmUtils.ZERO,CrdCrmUtils.OITO);
		}
		return usuario;
	}

	/**
	 * Método responsavel por popular o objeto DTO no model
	 * 
	 * @param model
	 * @param usuario
	 */
	private void putObjectModel(Model model, String usuario, Integer codigoFerramenta, Integer codPerfil) {
		CrmCredenciamentoDto crmDto = new CrmCredenciamentoDto();
		crmDto.setUsuarioCentral(usuario);
		crmDto.setCodigoFerramenta(codigoFerramenta);		
		if(Ferramenta.isSmart(codigoFerramenta))
			crmDto.setCodPerfilSmart(codPerfil);
		
		model.addAttribute("crm", crmDto);
	}
	
	
	/**
	 * Método responsavel por verificar se os parametros foram passados corretamente
	 * 
	 * @param usuario
	 * @param token
	 * @return
	 */
	private boolean isParamEmptyOrTokenError(String usuario, String token, Integer codigoFerramenta) {
		if (usuario.equals(CrdCrmUtils.STRING_EMPTY) || token.equals(CrdCrmUtils.STRING_EMPTY)) {
			return true;
		}else if(!Ferramenta.isFerramentaValida(codigoFerramenta)) {
			return true;
		}else if(!token.equals(CrdCrmUtils.ACCESS_TOKEN)) {
			return true;
		}
		return false;
	}
}
