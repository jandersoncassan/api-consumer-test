package cielo.crd.crm.timer;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import cielo.crd.crm.domain.Banco;
import cielo.crd.crm.domain.Faturamento;
import cielo.crd.crm.domain.HorarioFuncionamento;
import cielo.crd.crm.domain.RamoAtividade;
import cielo.crd.crm.domain.SolucaoCaptura;
import cielo.crd.crm.domain.SolucaoEquipamento;
import cielo.crd.crm.domain.TaxasPrazos;
import cielo.crd.crm.enums.Ferramenta;
import cielo.crd.crm.repository.BancoRepository;
import cielo.crd.crm.repository.FaturamentoRepository;
import cielo.crd.crm.repository.HorarioFuncionamentoRepository;
import cielo.crd.crm.repository.RamoAtividadeRepository;
import cielo.crd.crm.repository.SolucaoCapturaRepository;
import cielo.crd.crm.repository.SolucaoEquipamentoRepository;
import cielo.crd.crm.repository.TaxasPrazosRepository;
import cielo.crd.crm.service.InfoAdicionalService;
import cielo.crd.crm.service.SolucaoCapturaService;
import cielo.crd.crm.utils.CrdCrmUtils;

/**
 * Classe SCHEDULER responsavel por atualizar as listas de Ramos de Atividades e Taxas Prazos
 * 
 * @author @Cielo S/A
 * @since 1.0.0
 */
@Component
@EnableScheduling
public class CrdCrmTimer {

	private static final Logger LOG = LoggerFactory.getLogger(CrdCrmTimer.class);
	
	private static final String TIME_ZONE = "America/Sao_Paulo";
	
	@Autowired
	private SolucaoCapturaService solucaoCapturaService;
	
	@Autowired
	private RamoAtividadeRepository ramoAtividadeRepository;
	
	@Autowired
	private TaxasPrazosRepository taxasPrazosRepository;
	
	@Autowired
	private InfoAdicionalService infoAdicionalService;
	
	@Autowired
	private HorarioFuncionamentoRepository horarioFuncionamentoRepository;
	
	@Autowired
	private SolucaoEquipamentoRepository solucaoEquipamentoRepository;
	
	@Autowired
	private SolucaoCapturaRepository solucaoCapturaRepository;
	
	@Autowired
	private FaturamentoRepository faturamentoRepository;

	@Autowired
	private BancoRepository bancoRepository;

	//CRON '"0 0 * * * *"' A B C D E F  (A: Segundos (0 – 59).	B: Minutos (0 – 59).	C: Horas (0 – 23).	D: Dia (1 – 31).	E: Mês (1 – 12).	F: Dia da semana (0 – 6).
	@Scheduled(cron = "0 0 6 * * *", zone = TIME_ZONE)
	public void atualizarRamosAtividades(){
		LOG.info("EXECUTANDO SCHEDULER RAMOS DE ATIVIDADES"); 
		try {			
			Optional<List<RamoAtividade>> listaRamoAtividade = getListaRamoAtividade();
			if(listaRamoAtividade.isPresent()) {
				//LIMPAMOS A TABELA ANTES DE ATUALIZAR NOVAMENTE
				ramoAtividadeRepository.deleteAll();			
				//POPULAMOS A TABELA NOVAMENTE
				ramoAtividadeRepository.save(listaRamoAtividade.get());
			}
		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO EXECUTAR O SCHEDULER RAMOS DE ATIVIDADES {}", ex);
		}
	}

	@Scheduled(cron = "0 30 6 * * *", zone = TIME_ZONE)
	public void atualizarListaSolucoesequipamentos(){
		LOG.info("EXECUTANDO SCHEDULER LISTA DE SOLUCOES CAPTURA (QUANTIDADE MAXIMA DE EQUIPAMENTOS)");
		try {			
			Optional<List<SolucaoEquipamento>> listaSolucaoEquipamentos = getListaSolucaoEquipamentos();			
			if(listaSolucaoEquipamentos.isPresent()) {				
				//LIMPAMOS A TABELA ANTES DE ATUALIZAR NOVAMENTE
				solucaoEquipamentoRepository.deleteAll();			
				//POPULAMOS A TABELA NOVAMENTE
				solucaoEquipamentoRepository.save(listaSolucaoEquipamentos.get());
			}

		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO EXECUTAR O SCHEDULER LISTA DE SOLUCOES CAPTURA (QUANTIDADE MAXIMA DE EQUIPAMENTOS) {}", ex);
		}
	}
	
	@Scheduled(cron = "0 0 7 * * *", zone = TIME_ZONE)
	public void atualizarTaxasPrazos(){
		LOG.info("EXECUTANDO SCHEDULER TAXAS / PRAZOS");
		try {			
			//OBTEM A LISTA DE PESSOA FISICA
			Optional<List<TaxasPrazos>> lista = solucaoCapturaService.getListaTaxasPrazos();			

			if(lista.isPresent()) {
				//LIMPAMOS A TABELA ANTES DE ATUALIZAR NOVAMENTE
				taxasPrazosRepository.deleteAll();			
				//POPULAMOS A TABELA NOVAMENTE
				taxasPrazosRepository.save(lista.get());
			}
			
		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO EXECUTAR O SCHEDULER TAXAS / PRAZOS {}", ex);
		}
	}

	@Scheduled(cron = "0 30 7 * * *", zone = TIME_ZONE)
	public void atualizarHorarioFuncionamento(){
		LOG.info("EXECUTANDO SCHEDULER HORARIO FUNCIONAMENTO GTEC");
		try {			
			//OBTEM A LISTA DE PESSOA FISICA
			Optional<List<HorarioFuncionamento>> lista = infoAdicionalService.getListaHorariosFuncionamento();			

			if(lista.isPresent()) {
				//LIMPAMOS A TABELA ANTES DE ATUALIZAR NOVAMENTE
				horarioFuncionamentoRepository.deleteAll();			
				//POPULAMOS A TABELA NOVAMENTE
				horarioFuncionamentoRepository.save(lista.get());
			}
			
		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO EXECUTAR O SCHEDULER HORARIO FUNCIONAMENTO GTEC {}", ex);
		}
	}
	
	@Scheduled(cron = "0 0 8 * * *", zone = TIME_ZONE)
	public void atualizarListaSolucoesCaptura(){
		LOG.info("EXECUTANDO SCHEDULER LISTA DE SOLUCOES CAPTURA POR FERRAMENTA");
		try {			
			//OBTEM A LISTA DE SOLUCOES DE CAPTURA
			Optional<List<SolucaoCaptura>> listaSolucaoCaptura = getListaSolucaoCaptura();
			
			if(listaSolucaoCaptura.isPresent()) {
				//LIMPAMOS A TABELA ANTES DE ATUALIZAR NOVAMENTE
				solucaoCapturaRepository.deleteAll();			
				//POPULAMOS A TABELA NOVAMENTE
				solucaoCapturaRepository.save(listaSolucaoCaptura.get());
			}	
			
		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO EXECUTAR O SCHEDULERLISTA DE SOLUCOES CAPTURA POR FERRAMENTA {}", ex);
		}
	}

	@Scheduled(cron = "0 15 8 * * *", zone = TIME_ZONE)
	public void atualizarRangeFaturamento(){
		LOG.info("EXECUTANDO SCHEDULER  RANGE DE FATURAMENTO");
		try {			
			Optional<List<Faturamento>> listaRangeFaturamento = solucaoCapturaService.obterRangeFaturamento();			
			if(listaRangeFaturamento.isPresent()) {				
				//LIMPAMOS A TABELA ANTES DE ATUALIZAR NOVAMENTE
				faturamentoRepository.deleteAll();			
				//POPULAMOS A TABELA NOVAMENTE
				faturamentoRepository.save(listaRangeFaturamento.get());
			}

		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO EXECUTAR O SCHEDULER LISTA DE SOLUCOES CAPTURA (QUANTIDADE MAXIMA DE EQUIPAMENTOS) {}", ex);
		}
	}

	@Scheduled(cron = "0 30 8 * * *", zone = TIME_ZONE)
	public void atualizarListaBancos(){
		LOG.info("EXECUTANDO SCHEDULER LISTA DE BANCOS");
		try {			
			//OBTEM A LISTA DE PESSOA FISICA
			Optional<List<Banco>> lista = infoAdicionalService.getListaBancos();			

			if(lista.isPresent()) {
				//LIMPAMOS A TABELA ANTES DE ATUALIZAR NOVAMENTE
				bancoRepository.deleteAll();			
				//POPULAMOS A TABELA NOVAMENTE
				bancoRepository.save(lista.get());
			}
			
		}catch(Exception ex) {
			LOG.error("OCORREU UM ERRO AO EXECUTAR O SCHEDULER LISTA DE BANCOS {}", ex);
		}
	}
 

	/**
	 * Método responsavel por obter a lista de ramos de atividades
	 * @return
	 */
	private Optional<List<RamoAtividade>> getListaRamoAtividade(){
		
		String[] tipoPessoa = new String[] {CrdCrmUtils.PESSOA_FISICA, CrdCrmUtils.PESSOA_JURIDICA};		
		List<RamoAtividade> listaRamoAtividade = new ArrayList<>();
		
		for (Integer ferramenta : getListaFerramentas()) {			
			for (String tipo : tipoPessoa) {
				Optional<List<RamoAtividade>> listaRamos = Optional.ofNullable(solucaoCapturaService.getListaRamosAtividadesCrd(tipo, ferramenta));
				if(listaRamos.isPresent()) {
					listaRamoAtividade.addAll(listaRamos.get());
				}
			}			
		}		
		return Optional.of(listaRamoAtividade);		
	}
	
	/**
	 * Método responsavel por obter a lista de soluções de captura
	 * @return
	 */
	private Optional<List<SolucaoCaptura>> getListaSolucaoCaptura(){
	
		List<SolucaoCaptura> listaSolucao = new ArrayList<>();	
		
		for (Integer ferramenta : getListaFerramentas()) {			
				Optional<List<SolucaoCaptura>> listaSolucaoCaptura = solucaoCapturaService.obterListaSolucaoCaptura(ferramenta);				
				if(listaSolucaoCaptura.isPresent()) {
					listaSolucao.addAll(listaSolucaoCaptura.get());
				}
			}	
		return Optional.of(listaSolucao);	
	}
	
	/**
	 * Método responsavel por obter a lista de Equipamentos x Solucao Captura
	 * @return
	 */
	private Optional<List<SolucaoEquipamento>> getListaSolucaoEquipamentos(){
		List<SolucaoEquipamento> listaSolucaoEquipamento = new ArrayList<>();	
		
		for (Integer ferramenta : getListaFerramentas()) {			
			Optional<List<SolucaoEquipamento>> listaSolEquipamento = solucaoCapturaService.obterListaSolucaoEquipamentos(ferramenta);				
			if(listaSolEquipamento.isPresent()) {
				listaSolucaoEquipamento.addAll(listaSolEquipamento.get());
			}
		}	
		return Optional.of(listaSolucaoEquipamento);			
	}

	/**
	 * Método responsavel por retornar a lista de ferramentas
	 * @return
	 */
	private List<Integer> getListaFerramentas(){
		return Arrays.asList(Ferramenta.CENTRAL.getCodigo(), Ferramenta.SMART.getCodigo(), Ferramenta.FEIRAS.getCodigo());
	}
}
