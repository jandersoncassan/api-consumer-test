package cielo.crd.crm.domain;

import java.io.Serializable;
import javax.persistence.Embeddable;

@Embeddable
public class RamoAtividadePk implements Serializable{

	private static final long serialVersionUID = 1L;

	private Integer codigoFerramenta;
	
	private String tipoPessoa;

	private Integer codigo;

	/**
	 * @return the codigoFerramenta
	 */
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}

	/**
	 * @param codigoFerramenta the codigoFerramenta to set
	 */
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
	}

	/**
	 * @return the tipoPessoa
	 */
	public String getTipoPessoa() {
		return tipoPessoa;
	}

	/**
	 * @param tipoPessoa the tipoPessoa to set
	 */
	public void setTipoPessoa(String tipoPessoa) {
		this.tipoPessoa = tipoPessoa;
	}

	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}

	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((codigoFerramenta == null) ? 0 : codigoFerramenta.hashCode());
		result = prime * result + ((tipoPessoa == null) ? 0 : tipoPessoa.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RamoAtividadePk other = (RamoAtividadePk) obj;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (codigoFerramenta == null) {
			if (other.codigoFerramenta != null)
				return false;
		} else if (!codigoFerramenta.equals(other.codigoFerramenta))
			return false;
		if (tipoPessoa == null) {
			if (other.tipoPessoa != null)
				return false;
		} else if (!tipoPessoa.equals(other.tipoPessoa))
			return false;
		return true;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "RamoAtividadePk [codigoFerramenta=" + codigoFerramenta + ", tipoPessoa=" + tipoPessoa + ", codigo="
				+ codigo + "]";
	}

	
}
