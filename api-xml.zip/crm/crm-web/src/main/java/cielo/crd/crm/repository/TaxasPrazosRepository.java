package cielo.crd.crm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.TaxasPrazos;

@Repository
public interface TaxasPrazosRepository extends JpaRepository<TaxasPrazos, Long> {

	@Query("SELECT t FROM TaxasPrazos t WHERE t.pk.codigoMcc = :codigoMcc") 
	TaxasPrazos findByCodigoMcc(@Param("codigoMcc") Long codigoMcc);

}
