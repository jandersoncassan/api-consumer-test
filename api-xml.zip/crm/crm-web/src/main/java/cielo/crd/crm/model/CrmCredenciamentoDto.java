package cielo.crd.crm.model;

import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

/**
 * Classe Model representando as telas de credenciamento via CRM
 * @author @Cielo SA
 * @since 1.0.0
 */
public class CrmCredenciamentoDto {
	
	private String usuarioCentral;
	
	private Long numeroProposta;
	
	private Long numeroEc;
	
	private Integer codigoFerramenta;
	
	private Integer codPerfilSmart; 
	
	/* CLIENTE*/
	@NotEmpty(message="O campo Nome Completo é obrigatório")
	private String nome;
	
	@NotEmpty(message="Favor selecionar o Tipo de Pessoa")
	private String tpPessoa;
	
	@NotEmpty(message="O campo CNPJ é obrigatório")
	private String cnpj;
	
	@NotEmpty(message="O campo CPF é obrigatório")
	private String cpf;
	
	@NotEmpty(message="O campo Data Nascimento é obrigatório")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private String dtNascimento;
	
	@NotEmpty(message="O campo DDD é obrigatório")
	private String dddPrincipal;
	
	@NotEmpty(message="O campo Número é obrigatório")
	private String telPrincipal;
	
	@NotEmpty(message="O campo DDD é obrigatório")
	private String dddCelular;
	
	@NotEmpty(message="O campo DDD é obrigatório")
	private String telCelular;
	
	@NotEmpty(message="Favor informar um email para contato")
	private String email;
	
	private String naoPossuiEmail;

	@NotEmpty(message="Favor informar o Nome do proprietario")
	private String nomeSegundoProp;
	
	@NotEmpty(message="Favor informar a Data de Nascimento")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private String dtNascSegundoProp;

	@NotEmpty(message="Favor informar o CPF")
	private String cpfSegundoProp;
	
	@NotEmpty(message="Favor informar o Nome do proprietario")
	private String nomeTerceiroProp;
	
	@NotEmpty(message="Favor informar a Data de Nascimento")
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private String dtNascTerceiroProp;

	@NotEmpty(message="Favor informar o CPF")
	private String cpfTerceiroProp;
	
	private boolean isMaisProprietarios;

	/* SOLUCAO CAPTURA*/
	private Integer ramoAtividade;

	private Integer faturamento;
	
	private Integer solCaptura;
	
	private String indEntregaMaquina;
	
	private String arv;
	
	private String txArv;
	
	private Integer potencialVendas;
	
	private String pagamentoLink;
	
	private List<Integer> operadora;
	
	private Integer tpPlano;
	
	private Integer diasLiqControle;
	
	private Integer qtdadeMaquinas;
	
	//INFO ADICIONAL
	@NotEmpty(message="O campo Nome exibido no comprovante de vendas é obrigatório")
	private String nomePlaqueta;
	
	@NotEmpty(message="O campo Nome Fantasia é obrigatório")
	private String nomeFantasia;
	
	@NotEmpty(message="O campo Dias de Atendimento é obrigatório")
	private String codHorarioAtendimento;
	
	@NotEmpty(message="O campo Razão Social é obrigatório")
	private String razaoSocial;
	
	@NotEmpty(message="O campo CEP é obrigatório")
	private String cepComercial; 
	
	@NotEmpty(message="O campo Endereço é obrigatório")
	private String logradouroComercial; 
	
	@NotEmpty(message="O campo Número é obrigatório")
	private String numeroComercial; 
	
	private String complementoComercial; 
	
	@NotEmpty(message="O campo Cidade é obrigatório")
	private String cidadeComercial; 
	
	@NotEmpty(message="O campo Estado é obrigatório")
	private String estadoComercial; 
	
	private String endPrincMsmCorresp;

	@NotEmpty(message="O campo CEP é obrigatório")
	private String cepCorrespondencia; 
	
	@NotEmpty(message="O campo Endereço é obrigatório")
	private String logradouroCorrespondencia; 
	
	@NotEmpty(message="O campo Número é obrigatório")
	private String numeroCorrespondencia; 
	
	private String complementoCorrespondencia; 
	
	@NotEmpty(message="O campo Cidade é obrigatório")
	private String cidadeCorrespondencia; 
	
	@NotEmpty(message="O campo Estado é obrigatório")
	private String estadoCorrespondencia; 

	@NotEmpty(message="Favor selecionar onde a(s) máquina(s) devem ser entregues")
	private String entregaMaquina;
	
	@NotEmpty(message="Favor selecionar o Tipo de Conta")
	private String tipoConta;
	
	@NotEmpty(message="O campo Banco é obrigatório")
	private String banco;
	
	@NotEmpty(message="O campo Agência é obrigatório")
	private String agencia;
	
	@NotEmpty(message="O campo Conta é obrigatório")
	private String conta;
	
	@NotEmpty(message="O campo Dígito é obrigatório")
	private String digito;

	/* DADOS CONTRATACAO*/	
	private Long codigoProducao;

	/**
	 * @return the usuarioCentral
	 */
	public String getUsuarioCentral() {
		return usuarioCentral;
	}

	/**
	 * @param usuarioCentral the usuarioCentral to set
	 */
	public void setUsuarioCentral(String usuarioCentral) {
		this.usuarioCentral = usuarioCentral;
	}

	/**
	 * @return the numeroProposta
	 */
	public Long getNumeroProposta() {
		return numeroProposta;
	}

	/**
	 * @param numeroProposta the numeroProposta to set
	 */
	public void setNumeroProposta(Long numeroProposta) {
		this.numeroProposta = numeroProposta;
	}

	/**
	 * @return the numeroEc
	 */
	public Long getNumeroEc() {
		return numeroEc;
	}

	/**
	 * @param numeroEc the numeroEc to set
	 */
	public void setNumeroEc(Long numeroEc) {
		this.numeroEc = numeroEc;
	}

	/**
	 * @return the codigoFerramenta
	 */
	public Integer getCodigoFerramenta() {
		return codigoFerramenta;
	}

	/**
	 * @param codigoFerramenta the codigoFerramenta to set
	 */
	public void setCodigoFerramenta(Integer codigoFerramenta) {
		this.codigoFerramenta = codigoFerramenta;
	}

	/**
	 * @return the codPerfilSmart
	 */
	public Integer getCodPerfilSmart() {
		return codPerfilSmart;
	}

	/**
	 * @param codPerfilSmart the codPerfilSmart to set
	 */
	public void setCodPerfilSmart(Integer codPerfilSmart) {
		this.codPerfilSmart = codPerfilSmart;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the tpPessoa
	 */
	public String getTpPessoa() {
		return tpPessoa;
	}

	/**
	 * @param tpPessoa the tpPessoa to set
	 */
	public void setTpPessoa(String tpPessoa) {
		this.tpPessoa = tpPessoa;
	}

	/**
	 * @return the cnpj
	 */
	public String getCnpj() {
		return cnpj;
	}

	/**
	 * @param cnpj the cnpj to set
	 */
	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}

	/**
	 * @return the cpf
	 */
	public String getCpf() {
		return cpf;
	}

	/**
	 * @param cpf the cpf to set
	 */
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	/**
	 * @return the dtNascimento
	 */
	public String getDtNascimento() {
		return dtNascimento;
	}

	/**
	 * @param dtNascimento the dtNascimento to set
	 */
	public void setDtNascimento(String dtNascimento) {
		this.dtNascimento = dtNascimento;
	}

	/**
	 * @return the dddPrincipal
	 */
	public String getDddPrincipal() {
		return dddPrincipal;
	}

	/**
	 * @param dddPrincipal the dddPrincipal to set
	 */
	public void setDddPrincipal(String dddPrincipal) {
		this.dddPrincipal = dddPrincipal;
	}

	/**
	 * @return the telPrincipal
	 */
	public String getTelPrincipal() {
		return telPrincipal;
	}

	/**
	 * @param telPrincipal the telPrincipal to set
	 */
	public void setTelPrincipal(String telPrincipal) {
		this.telPrincipal = telPrincipal;
	}

	/**
	 * @return the dddCelular
	 */
	public String getDddCelular() {
		return dddCelular;
	}

	/**
	 * @param dddCelular the dddCelular to set
	 */
	public void setDddCelular(String dddCelular) {
		this.dddCelular = dddCelular;
	}

	/**
	 * @return the telCelular
	 */
	public String getTelCelular() {
		return telCelular;
	}

	/**
	 * @param telCelular the telCelular to set
	 */
	public void setTelCelular(String telCelular) {
		this.telCelular = telCelular;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return the naoPossuiEmail
	 */
	public String getNaoPossuiEmail() {
		return naoPossuiEmail;
	}

	/**
	 * @param naoPossuiEmail the naoPossuiEmail to set
	 */
	public void setNaoPossuiEmail(String naoPossuiEmail) {
		this.naoPossuiEmail = naoPossuiEmail;
	}

	/**
	 * @return the nomeSegundoProp
	 */
	public String getNomeSegundoProp() {
		return nomeSegundoProp;
	}

	/**
	 * @param nomeSegundoProp the nomeSegundoProp to set
	 */
	public void setNomeSegundoProp(String nomeSegundoProp) {
		this.nomeSegundoProp = nomeSegundoProp;
	}

	/**
	 * @return the dtNascSegundoProp
	 */
	public String getDtNascSegundoProp() {
		return dtNascSegundoProp;
	}

	/**
	 * @param dtNascSegundoProp the dtNascSegundoProp to set
	 */
	public void setDtNascSegundoProp(String dtNascSegundoProp) {
		this.dtNascSegundoProp = dtNascSegundoProp;
	}

	/**
	 * @return the cpfSegundoProp
	 */
	public String getCpfSegundoProp() {
		return cpfSegundoProp;
	}

	/**
	 * @param cpfSegundoProp the cpfSegundoProp to set
	 */
	public void setCpfSegundoProp(String cpfSegundoProp) {
		this.cpfSegundoProp = cpfSegundoProp;
	}

	/**
	 * @return the nomeTerceiroProp
	 */
	public String getNomeTerceiroProp() {
		return nomeTerceiroProp;
	}

	/**
	 * @param nomeTerceiroProp the nomeTerceiroProp to set
	 */
	public void setNomeTerceiroProp(String nomeTerceiroProp) {
		this.nomeTerceiroProp = nomeTerceiroProp;
	}

	/**
	 * @return the dtNascTerceiroProp
	 */
	public String getDtNascTerceiroProp() {
		return dtNascTerceiroProp;
	}

	/**
	 * @param dtNascTerceiroProp the dtNascTerceiroProp to set
	 */
	public void setDtNascTerceiroProp(String dtNascTerceiroProp) {
		this.dtNascTerceiroProp = dtNascTerceiroProp;
	}

	/**
	 * @return the cpfTerceiroProp
	 */
	public String getCpfTerceiroProp() {
		return cpfTerceiroProp;
	}

	/**
	 * @param cpfTerceiroProp the cpfTerceiroProp to set
	 */
	public void setCpfTerceiroProp(String cpfTerceiroProp) {
		this.cpfTerceiroProp = cpfTerceiroProp;
	}

	/**
	 * @return the isMaisProprietarios
	 */
	public boolean isMaisProprietarios() {
		return isMaisProprietarios;
	}

	/**
	 * @param isMaisProprietarios the isMaisProprietarios to set
	 */
	public void setMaisProprietarios(boolean isMaisProprietarios) {
		this.isMaisProprietarios = isMaisProprietarios;
	}

	/**
	 * @return the ramoAtividade
	 */
	public Integer getRamoAtividade() {
		return ramoAtividade;
	}

	/**
	 * @param ramoAtividade the ramoAtividade to set
	 */
	public void setRamoAtividade(Integer ramoAtividade) {
		this.ramoAtividade = ramoAtividade;
	}

	/**
	 * @return the faturamento
	 */
	public Integer getFaturamento() {
		return faturamento;
	}

	/**
	 * @param faturamento the faturamento to set
	 */
	public void setFaturamento(Integer faturamento) {
		this.faturamento = faturamento;
	}

	/**
	 * @return the solCaptura
	 */
	public Integer getSolCaptura() {
		return solCaptura;
	}

	/**
	 * @param solCaptura the solCaptura to set
	 */
	public void setSolCaptura(Integer solCaptura) {
		this.solCaptura = solCaptura;
	}

	/**
	 * @return the indEntregaMaquina
	 */
	public String getIndEntregaMaquina() {
		return indEntregaMaquina;
	}

	/**
	 * @param indEntregaMaquina the indEntregaMaquina to set
	 */
	public void setIndEntregaMaquina(String indEntregaMaquina) {
		this.indEntregaMaquina = indEntregaMaquina;
	}

	/**
	 * @return the arv
	 */
	public String getArv() {
		return arv;
	}

	/**
	 * @param arv the arv to set
	 */
	public void setArv(String arv) {
		this.arv = arv;
	}

	/**
	 * @return the txArv
	 */
	public String getTxArv() {
		return txArv;
	}

	/**
	 * @param txArv the txArv to set
	 */
	public void setTxArv(String txArv) {
		this.txArv = txArv;
	}

	/**
	 * @return the potencialVendas
	 */
	public Integer getPotencialVendas() {
		return potencialVendas;
	}

	/**
	 * @param potencialVendas the potencialVendas to set
	 */
	public void setPotencialVendas(Integer potencialVendas) {
		this.potencialVendas = potencialVendas;
	}

	/**
	 * @return the pagamentoLink
	 */
	public String getPagamentoLink() {
		return pagamentoLink;
	}

	/**
	 * @param pagamentoLink the pagamentoLink to set
	 */
	public void setPagamentoLink(String pagamentoLink) {
		this.pagamentoLink = pagamentoLink;
	}

	/**
	 * @return the operadora
	 */
	public List<Integer> getOperadora() {
		return operadora;
	}

	/**
	 * @param operadora the operadora to set
	 */
	public void setOperadora(List<Integer> operadora) {
		this.operadora = operadora;
	}

	/**
	 * @return the tpPlano
	 */
	public Integer getTpPlano() {
		return tpPlano;
	}

	/**
	 * @param tpPlano the tpPlano to set
	 */
	public void setTpPlano(Integer tpPlano) {
		this.tpPlano = tpPlano;
	}

	/**
	 * @return the diasLiqControle
	 */
	public Integer getDiasLiqControle() {
		return diasLiqControle;
	}

	/**
	 * @param diasLiqControle the diasLiqControle to set
	 */
	public void setDiasLiqControle(Integer diasLiqControle) {
		this.diasLiqControle = diasLiqControle;
	}

	/**
	 * @return the qtdadeMaquinas
	 */
	public Integer getQtdadeMaquinas() {
		return qtdadeMaquinas;
	}

	/**
	 * @param qtdadeMaquinas the qtdadeMaquinas to set
	 */
	public void setQtdadeMaquinas(Integer qtdadeMaquinas) {
		this.qtdadeMaquinas = qtdadeMaquinas;
	}

	/**
	 * @return the nomePlaqueta
	 */
	public String getNomePlaqueta() {
		return nomePlaqueta;
	}

	/**
	 * @param nomePlaqueta the nomePlaqueta to set
	 */
	public void setNomePlaqueta(String nomePlaqueta) {
		this.nomePlaqueta = nomePlaqueta;
	}

	/**
	 * @return the nomeFantasia
	 */
	public String getNomeFantasia() {
		return nomeFantasia;
	}

	/**
	 * @param nomeFantasia the nomeFantasia to set
	 */
	public void setNomeFantasia(String nomeFantasia) {
		this.nomeFantasia = nomeFantasia;
	}

	/**
	 * @return the codHorarioAtendimento
	 */
	public String getCodHorarioAtendimento() {
		return codHorarioAtendimento;
	}

	/**
	 * @param codHorarioAtendimento the codHorarioAtendimento to set
	 */
	public void setCodHorarioAtendimento(String codHorarioAtendimento) {
		this.codHorarioAtendimento = codHorarioAtendimento;
	}

	
	/**
	 * @return the razaoSocial
	 */
	public String getRazaoSocial() {
		return razaoSocial;
	}

	/**
	 * @param razaoSocial the razaoSocial to set
	 */
	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}

	/**
	 * @return the cepComercial
	 */
	public String getCepComercial() {
		return cepComercial;
	}

	/**
	 * @param cepComercial the cepComercial to set
	 */
	public void setCepComercial(String cepComercial) {
		this.cepComercial = cepComercial;
	}

	/**
	 * @return the logradouroComercial
	 */
	public String getLogradouroComercial() {
		return logradouroComercial;
	}

	/**
	 * @param logradouroComercial the logradouroComercial to set
	 */
	public void setLogradouroComercial(String logradouroComercial) {
		this.logradouroComercial = logradouroComercial;
	}

	/**
	 * @return the numeroComercial
	 */
	public String getNumeroComercial() {
		return numeroComercial;
	}

	/**
	 * @param numeroComercial the numeroComercial to set
	 */
	public void setNumeroComercial(String numeroComercial) {
		this.numeroComercial = numeroComercial;
	}

	/**
	 * @return the complementoComercial
	 */
	public String getComplementoComercial() {
		return complementoComercial;
	}

	/**
	 * @param complementoComercial the complementoComercial to set
	 */
	public void setComplementoComercial(String complementoComercial) {
		this.complementoComercial = complementoComercial;
	}

	/**
	 * @return the cidadeComercial
	 */
	public String getCidadeComercial() {
		return cidadeComercial;
	}

	/**
	 * @param cidadeComercial the cidadeComercial to set
	 */
	public void setCidadeComercial(String cidadeComercial) {
		this.cidadeComercial = cidadeComercial;
	}

	/**
	 * @return the estadoComercial
	 */
	public String getEstadoComercial() {
		return estadoComercial;
	}

	/**
	 * @param estadoComercial the estadoComercial to set
	 */
	public void setEstadoComercial(String estadoComercial) {
		this.estadoComercial = estadoComercial;
	}

	/**
	 * @return the endPrincMsmCorresp
	 */
	public String getEndPrincMsmCorresp() {
		return endPrincMsmCorresp;
	}

	/**
	 * @param endPrincMsmCorresp the endPrincMsmCorresp to set
	 */
	public void setEndPrincMsmCorresp(String endPrincMsmCorresp) {
		this.endPrincMsmCorresp = endPrincMsmCorresp;
	}

	/**
	 * @return the cepCorrespondencia
	 */
	public String getCepCorrespondencia() {
		return cepCorrespondencia;
	}

	/**
	 * @param cepCorrespondencia the cepCorrespondencia to set
	 */
	public void setCepCorrespondencia(String cepCorrespondencia) {
		this.cepCorrespondencia = cepCorrespondencia;
	}

	/**
	 * @return the logradouroCorrespondencia
	 */
	public String getLogradouroCorrespondencia() {
		return logradouroCorrespondencia;
	}

	/**
	 * @param logradouroCorrespondencia the logradouroCorrespondencia to set
	 */
	public void setLogradouroCorrespondencia(String logradouroCorrespondencia) {
		this.logradouroCorrespondencia = logradouroCorrespondencia;
	}

	/**
	 * @return the numeroCorrespondencia
	 */
	public String getNumeroCorrespondencia() {
		return numeroCorrespondencia;
	}

	/**
	 * @param numeroCorrespondencia the numeroCorrespondencia to set
	 */
	public void setNumeroCorrespondencia(String numeroCorrespondencia) {
		this.numeroCorrespondencia = numeroCorrespondencia;
	}

	/**
	 * @return the complementoCorrespondencia
	 */
	public String getComplementoCorrespondencia() {
		return complementoCorrespondencia;
	}

	/**
	 * @param complementoCorrespondencia the complementoCorrespondencia to set
	 */
	public void setComplementoCorrespondencia(String complementoCorrespondencia) {
		this.complementoCorrespondencia = complementoCorrespondencia;
	}

	/**
	 * @return the cidadeCorrespondencia
	 */
	public String getCidadeCorrespondencia() {
		return cidadeCorrespondencia;
	}

	/**
	 * @param cidadeCorrespondencia the cidadeCorrespondencia to set
	 */
	public void setCidadeCorrespondencia(String cidadeCorrespondencia) {
		this.cidadeCorrespondencia = cidadeCorrespondencia;
	}

	/**
	 * @return the estadoCorrespondencia
	 */
	public String getEstadoCorrespondencia() {
		return estadoCorrespondencia;
	}

	/**
	 * @param estadoCorrespondencia the estadoCorrespondencia to set
	 */
	public void setEstadoCorrespondencia(String estadoCorrespondencia) {
		this.estadoCorrespondencia = estadoCorrespondencia;
	}

	/**
	 * @return the entregaMaquina
	 */
	public String getEntregaMaquina() {
		return entregaMaquina;
	}

	/**
	 * @param entregaMaquina the entregaMaquina to set
	 */
	public void setEntregaMaquina(String entregaMaquina) {
		this.entregaMaquina = entregaMaquina;
	}


	/**
	 * @return the tipoConta
	 */
	public String getTipoConta() {
		return tipoConta;
	}

	/**
	 * @param tipoConta the tipoConta to set
	 */
	public void setTipoConta(String tipoConta) {
		this.tipoConta = tipoConta;
	}

	/**
	 * @return the banco
	 */
	public String getBanco() {
		return banco;
	}

	/**
	 * @param banco the banco to set
	 */
	public void setBanco(String banco) {
		this.banco = banco;
	}

	/**
	 * @return the agencia
	 */
	public String getAgencia() {
		return agencia;
	}

	/**
	 * @param agencia the agencia to set
	 */
	public void setAgencia(String agencia) {
		this.agencia = agencia;
	}

	/**
	 * @return the conta
	 */
	public String getConta() {
		return conta;
	}

	/**
	 * @param conta the conta to set
	 */
	public void setConta(String conta) {
		this.conta = conta;
	}

	
	/**
	 * @return the digito
	 */
	public String getDigito() {
		return digito;
	}

	/**
	 * @param digito the digito to set
	 */
	public void setDigito(String digito) {
		this.digito = digito;
	}

	/**
	 * @return the codigoProducao
	 */
	public Long getCodigoProducao() {
		return codigoProducao;
	}

	/**
	 * @param codigoProducao the codigoProducao to set
	 */
	public void setCodigoProducao(Long codigoProducao) {
		this.codigoProducao = codigoProducao;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CrmCredenciamentoDto [usuarioCentral=" + usuarioCentral + ", numeroProposta=" + numeroProposta
				+ ", numeroEc=" + numeroEc + ", codigoFerramenta=" + codigoFerramenta + ", codPerfilSmart="
				+ codPerfilSmart + ", nome=" + nome + ", tpPessoa=" + tpPessoa + ", cnpj=" + cnpj + ", cpf=" + cpf
				+ ", dtNascimento=" + dtNascimento + ", dddPrincipal=" + dddPrincipal + ", telPrincipal=" + telPrincipal
				+ ", dddCelular=" + dddCelular + ", telCelular=" + telCelular + ", email=" + email + ", naoPossuiEmail="
				+ naoPossuiEmail + ", nomeSegundoProp=" + nomeSegundoProp + ", dtNascSegundoProp=" + dtNascSegundoProp
				+ ", cpfSegundoProp=" + cpfSegundoProp + ", nomeTerceiroProp=" + nomeTerceiroProp
				+ ", dtNascTerceiroProp=" + dtNascTerceiroProp + ", cpfTerceiroProp=" + cpfTerceiroProp
				+ ", isMaisProprietarios=" + isMaisProprietarios + ", ramoAtividade=" + ramoAtividade + ", faturamento="
				+ faturamento + ", solCaptura=" + solCaptura + ", arv=" + arv + ", txArv=" + txArv
				+ ", potencialVendas=" + potencialVendas + ", pagamentoLink=" + pagamentoLink + ", operadora="
				+ operadora + ", tpPlano=" + tpPlano + ", diasLiqControle=" + diasLiqControle + ", qtdadeMaquinas="
				+ qtdadeMaquinas + ", nomePlaqueta=" + nomePlaqueta + ", nomeFantasia=" + nomeFantasia
				+ ", codHorarioAtendimento=" + codHorarioAtendimento + ", razaoSocial=" + razaoSocial
				+ ", cepComercial=" + cepComercial + ", logradouroComercial=" + logradouroComercial
				+ ", numeroComercial=" + numeroComercial + ", complementoComercial=" + complementoComercial
				+ ", cidadeComercial=" + cidadeComercial + ", estadoComercial=" + estadoComercial
				+ ", endPrincMsmCorresp=" + endPrincMsmCorresp + ", cepCorrespondencia=" + cepCorrespondencia
				+ ", logradouroCorrespondencia=" + logradouroCorrespondencia + ", numeroCorrespondencia="
				+ numeroCorrespondencia + ", complementoCorrespondencia=" + complementoCorrespondencia
				+ ", cidadeCorrespondencia=" + cidadeCorrespondencia + ", estadoCorrespondencia="
				+ estadoCorrespondencia + ", entregaMaquina=" + entregaMaquina + ", tipoConta=" + tipoConta + ", banco="
				+ banco + ", agencia=" + agencia + ", conta=" + conta + ", digito=" + digito + ", codigoProducao="
				+ codigoProducao + "]";
	}


}
