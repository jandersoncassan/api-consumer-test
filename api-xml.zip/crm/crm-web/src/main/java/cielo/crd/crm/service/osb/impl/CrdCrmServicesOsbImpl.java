package cielo.crd.crm.service.osb.impl;

import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.canonico.comum.v1.Fault;
import br.com.cielo.canonico.governancasoa.comum.v1.CieloSoapHeaderType;
import br.com.cielo.canonico.governancasoa.comum.v1.UsuarioType;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_PortType;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_Service;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.Banco_ValidarDigitoAgenciaContaService_ServiceLocator;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaRequest;
import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaResponse;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogico;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoRequestType;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoResponseType;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoSOAPQSService;
import br.com.cielo.service.apoionegocio.tecnologiainformacao.credenciamentoconsultarnumerologico.v2.consultarnumerologico.ConsultarNumeroLogicoSOAPQSServiceLocator;
import br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.BancoType;
import br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.Banco_ListarBancosService;
import br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.Banco_ListarBancosServiceLocator;
import br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.Banco_ListarBancosServicePortType;
import br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.ListarBancosResponse;
import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaService;
import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServiceLocator;
import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.Cliente_consultarMccPorTipoPessoaFerramentaServicePortType;
import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaRequestType;
import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaResponseType;
import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEP;
import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPContractSOAPQSService;
import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPContractSOAPQSServiceLocator;
import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPRequest;
import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPResponse;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazoRequestType;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazoResponseType;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazo_PortType;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazo_Service;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazo_ServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.Credenciamento_AtualizarDadosParciaisPropostaRascunho;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.Credenciamento_AtualizarDadosParciaisPropostaRascunhoService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.Credenciamento_AtualizarDadosParciaisPropostaRascunhoServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoRequestType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoServiceSoapBindingQSService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoServiceSoapBindingQSServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.Credenciamento_ConsultarListaParametrosSolucaoCaptura;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.Credenciamento_ConsultarListaParametrosSolucaoCapturaService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.Credenciamento_ConsultarListaParametrosSolucaoCapturaServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoRequestCodigoTipoPessoa;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.Credenciamento_ConsultarPropostaRascunho;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.Credenciamento_ConsultarPropostaRascunhoService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.Credenciamento_ConsultarPropostaRascunhoServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.ConsultarSolucaoCapturaPorFerramentaRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.ConsultarSolucaoCapturaPorFerramentaResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_Service;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarCliente;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarClienteService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.Credenciamento_CredenciarClienteServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.credenciarcliente.CredenciarClienteResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoRequestType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunho_PortType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunho_Service;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunho_ServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancario;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancarioService;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.Credenciamento_VerificarExistenciaDomicilioBancarioServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v4.consultarcliente.ConsultarCliente;
import br.com.cielo.service.operacao.comercial.credenciamento.v4.consultarcliente.ConsultarClienteContractSOAPQSService;
import br.com.cielo.service.operacao.comercial.credenciamento.v4.consultarcliente.ConsultarClienteContractSOAPQSServiceLocator;
import br.com.cielo.service.operacao.comercial.credenciamento.v4.consultarcliente.ConsultarClienteRequestType;
import br.com.cielo.service.operacao.comercial.credenciamento.v4.consultarcliente.ConsultarClienteResponseType;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamento;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoRequestType;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoResponseType;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoSOAPQSService;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoSOAPQSServiceLocator;
import cielo.crd.crm.repository.ParametrosRepository;
import cielo.crd.crm.service.osb.CrdCrmServicesOsb;
import cielo.crd.crm.utils.CrdCrmUtils;

@Service
public class CrdCrmServicesOsbImpl implements CrdCrmServicesOsb {

	@Autowired
	private ParametrosRepository parametrosRepository;

	/**
	 * Método responsavel por popular as informações de autenticação do servico SOAP
	 * exposto no OSB
	 * 
	 * @return CieloSoapHeaderType
	 */
	private CieloSoapHeaderType buildHeader() {
		UsuarioType user = new UsuarioType();
		user.setId(getValue(CrdCrmUtils.OSB_USER));
		user.setSenha(CrdCrmUtils.decrypt(getValue(CrdCrmUtils.OSB_PASS)));

		CieloSoapHeaderType header = new CieloSoapHeaderType();
		header.setUsuario(user);
		return header;
	}

	/**
	 * Método responsavel por verificar a existencia do cliente
	 * 
	 * @return
	 */
	@Override
	public ConsultarClienteResponseType consultarExistenciaCliente(String cpfCnpj)
			throws RemoteException, MalformedURLException, ServiceException {

		ConsultarClienteContractSOAPQSService ws = new ConsultarClienteContractSOAPQSServiceLocator();
		ConsultarClienteRequestType req = new ConsultarClienteRequestType();
		req.setCpfCpnj(cpfCnpj);
		req.setCodigoVersao(CrdCrmUtils.FLAG_MULTIVAN); // PARAMETRO FIXO PARA ATENDER MULTIVAN
		ConsultarCliente service = ws.getConsultarClienteContractSOAPQSPort(
				new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_CLIENTE)));

		return (service.consultarCliente(buildHeader(), req));

	}

	/**
	 * Método responsave por obter as informações de proposta rascunho no CRD
	 */
	@Override
	public ConsultarPropostaRascunhoResponse obterPropostaRascunho(String tipoPessoa, Long cpfCnpj,
			Integer codigoFerramenta) throws MalformedURLException, ServiceException, Fault, RemoteException {

		Credenciamento_ConsultarPropostaRascunhoService ws = new Credenciamento_ConsultarPropostaRascunhoServiceLocator();

		ConsultarPropostaRascunhoRequest req = new ConsultarPropostaRascunhoRequest();
		req.setCodigoFerramenta(codigoFerramenta);
		req.setCodigoTipoPessoa(ConsultarPropostaRascunhoRequestCodigoTipoPessoa.fromValue(tipoPessoa));
		req.setNumeroCpfCnpj(cpfCnpj);

		Credenciamento_ConsultarPropostaRascunho service = ws
				.getCredenciamento_ConsultarPropostaRascunhoServiceSoapPort(
						new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_PROPOSTA_RASCUNHO)));

		return (service.consultarPropostaRascunho(req, buildHeader()));
	}

	/**
	 * Método responsavel por atualizar as informações de rascunho
	 */
	@Override
	public void atualizarPropostaRascunho(AtualizarDadosParciaisPropostaRascunhoRequest req)
			throws Fault, RemoteException, MalformedURLException, ServiceException {

		Credenciamento_AtualizarDadosParciaisPropostaRascunhoService ws = new Credenciamento_AtualizarDadosParciaisPropostaRascunhoServiceLocator();

		Credenciamento_AtualizarDadosParciaisPropostaRascunho service = ws
				.getCredenciamento_AtualizarDadosParciaisPropostaRascunhoServiceSoapPort(
						new URL(getDomainService(CrdCrmUtils.ENDPOINT_ATUALIZAR_PROPOSTA_RASCUNHO)));
		CrdCrmUtils.deflate("ATUALIZAR PROPOSTA RASCUNHO", req);
		service.atualizarDadosParciaisPropostaRascunho(req, buildHeader());
	}

	/**
	 * Método responsavel por obter a lista de Ramos de Atividades
	 */
	@Override
	public ConsultarMccPorTipoPessoaFerramentaResponseType obterListaRamosAtividades(String tipoPessoa,
			Integer codigoFerramenta) throws MalformedURLException, ServiceException, Fault, RemoteException {

		Cliente_consultarMccPorTipoPessoaFerramentaService ws = new Cliente_consultarMccPorTipoPessoaFerramentaServiceLocator();

		ConsultarMccPorTipoPessoaFerramentaRequestType req = new ConsultarMccPorTipoPessoaFerramentaRequestType();
		req.setCodigoFerramenta(BigInteger.valueOf(codigoFerramenta));
		req.setCodigoTipoPessoa(tipoPessoa);

		Cliente_consultarMccPorTipoPessoaFerramentaServicePortType service = ws
				.getCliente_consultarMccPorTipoPessoaFerramentaServiceSOAPPort(
						new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_RAMOS_ATIVIDADES)));

		return (service.consultarMccPorTipoPessoaFerramenta(req, buildHeader()));
	}

	/**
	 * Método responsavel por consultar a lista de taxas prazo 'SEC'
	 * 
	 */
	@Override
	public ConsultarListaTaxaPrazoResponseType consultarListaTaxas()
			throws RemoteException, MalformedURLException, ServiceException {
		ConsultarListaTaxaPrazo_Service ws = new ConsultarListaTaxaPrazo_ServiceLocator();
		ConsultarListaTaxaPrazo_PortType service = ws
				.getConsultarListaTaxaPrazoSOAP(new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_LISTA_TAXAS)));

		return service.consultarListaTaxaPrazo(buildHeader(), new ConsultarListaTaxaPrazoRequestType());
	}

	/**
	 * Método responsavel por obter a lista de horarios funcionamento, tratamento
	 * Gtec
	 */
	@Override
	public ConsultarHorarioFuncionamentoResponseType obterHorarioFuncionamentoGtec()
			throws RemoteException, MalformedURLException, ServiceException {
		ConsultarHorarioFuncionamentoSOAPQSService ws = new ConsultarHorarioFuncionamentoSOAPQSServiceLocator();
		ConsultarHorarioFuncionamento service = ws.getConsultarHorarioFuncionamentoSOAPQSPort(
				new URL(getDomainService(CrdCrmUtils.ENDPOINT_HORARIO_FUNCIONAMENTO_GTEC)));

		return service.consultarHorarioFuncionamento(buildHeader(), new ConsultarHorarioFuncionamentoRequestType());
	}

	/**
	 * Método responsavel por obter as informações do cep
	 */
	@Override
	public ConsultarCEPResponse consultarCep(String cep)
			throws Fault, RemoteException, MalformedURLException, ServiceException {

		ConsultarCEPContractSOAPQSService ws = new ConsultarCEPContractSOAPQSServiceLocator();
		ConsultarCEPRequest request = new ConsultarCEPRequest();
		request.setNumeroCEP(cep);
		ConsultarCEP service = ws
				.getConsultarCEPContractSOAPQSPort(new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_INFO_CEP)));

		return service.consultarCEP(buildHeader(), request);
	}

	/**
	 * Método responsavel por obter a lista de bancos
	 */
	@Override
	public ListarBancosResponse obterListaBancos()
			throws Fault, RemoteException, MalformedURLException, ServiceException {
		Banco_ListarBancosService ws = new Banco_ListarBancosServiceLocator();
		Banco_ListarBancosServicePortType service = ws.getBanco_ListarBancosServiceSOAPPort(
				new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_LISTA_BANCOS)));
		return service.listarBancos(new BancoType(), buildHeader());
	}

	/**
	 * Método responsavel por validar o Domicilio Bancario
	 */
	@Override
	public ValidarDigitoAgenciaContaResponse validarDomicilioBancario(String codigoBanco, String numeroAgencia,
			String numeroConta, String tipoConta)
			throws MalformedURLException, ServiceException, Fault, RemoteException {

		Banco_ValidarDigitoAgenciaContaService_Service ws = new Banco_ValidarDigitoAgenciaContaService_ServiceLocator();

		ValidarDigitoAgenciaContaRequest req = new ValidarDigitoAgenciaContaRequest();
		req.setCodigoBanco(new BigInteger(codigoBanco));
		req.setNumeroAgencia(new BigInteger(numeroAgencia));
		req.setNumeroConta(numeroConta);
		req.setTipoConta(tipoConta);

		Banco_ValidarDigitoAgenciaContaService_PortType service = ws
				.getBancoSOAP(new URL(getDomainService(CrdCrmUtils.ENDPOINT_VALIDAR_DOMICILIO_BANCARIO)));
		return service.validarDigitoAgenciaConta(req, buildHeader());
	}

	/**
	 * Método responsavel por verificar a existencia do Domicilio bancario
	 */
	@Override
	public VerificarExistenciaDomicilioBancarioResponse verificarExistenciaDomicioBancario(String codigoBanco,
			String numeroAgencia, String numeroConta, String tipoConta)
			throws MalformedURLException, ServiceException, Fault, RemoteException {

		Credenciamento_VerificarExistenciaDomicilioBancarioService ws = new Credenciamento_VerificarExistenciaDomicilioBancarioServiceLocator();

		VerificarExistenciaDomicilioBancarioRequest req = new VerificarExistenciaDomicilioBancarioRequest();
		req.setCodigoBanco(new BigInteger(codigoBanco));
		req.setNumeroAgencia(new BigInteger(numeroAgencia));
		req.setNumeroConta(numeroConta);
		req.setTipoConta(tipoConta);
		Credenciamento_VerificarExistenciaDomicilioBancario service = ws
				.getCredenciamento_VerificarExistenciaDomicilioBancarioServiceSoapPort(
						new URL(getDomainService(CrdCrmUtils.ENDPOINT_EXISTENCIA_DOMICILIO_BANCARIO)));

		return service.verificarExistenciaDomicilioBancario(req, buildHeader());

	}

	/**
	 * Método responsavel pela efetivação do credenciamento do cliente
	 */
	@Override
	public CredenciarClienteResponse credenciarCliente(CredenciarClienteRequest req)
			throws Fault, RemoteException, MalformedURLException, ServiceException {
		Credenciamento_CredenciarClienteService ws = new Credenciamento_CredenciarClienteServiceLocator();

		Credenciamento_CredenciarCliente service = ws.getCredenciamento_CredenciarClienteServiceSoapPort(
				new URL(getDomainService(CrdCrmUtils.ENDPOINT_CREDENCIAR_CLIENTE)));
		CrdCrmUtils.deflate("CREDENCIAR CLIENTE REQUEST : " + req.getEstabelecimentoComercial().getNumeroCpfCnpj(),
				req);
		CredenciarClienteResponse response = service.credenciarCliente(req, buildHeader());
		CrdCrmUtils.deflate("CREDENCIAR CLIENTE RESPONSE : " + req.getEstabelecimentoComercial().getNumeroCpfCnpj(),
				response);
		return response;
	}

	/**
	 * Método responsavel por verificar se o numero lógico ja foi gerado para a
	 * solução de captura 'Mobile'
	 * 
	 * @return
	 * @throws RemoteException
	 * @throws ServiceException
	 * @throws MalformedURLException
	 */
	@Override
	public ConsultarNumeroLogicoResponseType obterInfoNumeroLogico(Long numeroProposta)
			throws RemoteException, MalformedURLException, ServiceException {
		ConsultarNumeroLogicoSOAPQSService ws = new ConsultarNumeroLogicoSOAPQSServiceLocator();

		ConsultarNumeroLogicoRequestType req = new ConsultarNumeroLogicoRequestType();
		req.setCodigoProposta(numeroProposta);

		ConsultarNumeroLogico service = ws.getConsultarNumeroLogicoSOAPQSPort(
				new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_NUMERO_LOGICO)));

		return service.consultarNumeroLogico(buildHeader(), req);
	}

	/**
	 * Método responsavel por obter a lista de soluções de captura equipamentos
	 * (quantidades maximas)
	 * 
	 * @return
	 * 
	 * @return
	 * @throws MalformedURLException
	 * @throws ServiceException
	 * @throws Fault
	 * @throws SOAPException
	 * @throws RemoteException
	 */
	@Override
	public ConsultarListaParametrosSolucaoCapturaResponse obterListaSolucaoQtdEquipamentos(Integer codigoFerramenta)
			throws MalformedURLException, ServiceException, Fault, RemoteException {

		Credenciamento_ConsultarListaParametrosSolucaoCapturaService ws = new Credenciamento_ConsultarListaParametrosSolucaoCapturaServiceLocator();
		ConsultarListaParametrosSolucaoCapturaRequest req = new ConsultarListaParametrosSolucaoCapturaRequest();
		req.setCodigoFerramenta(new BigInteger(codigoFerramenta.toString()));

		Credenciamento_ConsultarListaParametrosSolucaoCaptura service = ws
				.getCredenciamento_ConsultarListaParametrosSolucaoCapturaServiceSoapPort(
						new URL(getDomainService(CrdCrmUtils.ENDPOINT_QUANT_EQUIPAMENTOS)));

		return service.consultarListaParametrosSolucaoCaptura(buildHeader(), req);
	}

	@Override
	public ConsultarSolucaoCapturaPorFerramentaResponse obterListaSolucaoCapturaFerramenta(Integer codigoFerramenta)
			throws Fault, RemoteException, MalformedURLException, ServiceException {

		ConsultarSolucaoCapturaPorFerramentaRequest req = new ConsultarSolucaoCapturaPorFerramentaRequest();
		req.setCodigoFerramenta(new BigInteger(codigoFerramenta.toString()));

		Credenciamento_ConsultarSolucaoCapturaPorFerramenta_Service service = new Credenciamento_ConsultarSolucaoCapturaPorFerramenta_ServiceLocator();

		Credenciamento_ConsultarSolucaoCapturaPorFerramenta_PortType ws = service
				.getCredenciamento_ConsultarSolucaoCapturaPorFerramentaSoapPort(
						new URL(getDomainService(CrdCrmUtils.ENDPOINT_SOLUCAO_CAPTURA_FERRAMENTA)));

		return ws.consultarSolucaoCapturaPorFerramenta(buildHeader(), req);
	}

	@Override
	public RegistrarCriticaPropostaRascunhoResponseType popularCriticaContaInvalida(
			RegistrarCriticaPropostaRascunhoRequestType request)
			throws Fault, RemoteException, MalformedURLException, ServiceException {

		RegistrarCriticaPropostaRascunho_Service service = new RegistrarCriticaPropostaRascunho_ServiceLocator();

		RegistrarCriticaPropostaRascunho_PortType ws = service.getRegistrarCriticaPropostaRascunhoSoapPort(
				new URL(getDomainService(CrdCrmUtils.ENDPOINT_CRITICAR_CONTA_INVALIDA)));
		
		return ws.registrarCriticaPropostaRascunho(buildHeader(), request);
	}

	@Override
	public ConsultarListaFaturamentoResponseType obterListaFaturamento() throws ServiceException, Fault, RemoteException, MalformedURLException {
		
		ConsultarListaFaturamentoRequestType request = new ConsultarListaFaturamentoRequestType();
		ConsultarListaFaturamentoServiceSoapBindingQSService service = new ConsultarListaFaturamentoServiceSoapBindingQSServiceLocator();
		
		ConsultarListaFaturamentoService ws = service.getConsultarListaFaturamentoServiceSoapBindingQSPort(
				new URL(getDomainService(CrdCrmUtils.ENDPOINT_CONSULTAR_LISTA_FATURAMENTO)));
		
		return ws.consultarListaFaturamentoService(buildHeader(), request);		
	}

	/**
	 * Método responsavel por popular as informações de domain + endpoint
	 * 
	 * @param endpoint
	 * @return
	 */
	private String getDomainService(String endpoint) {
		String osbDomain = getValue(CrdCrmUtils.OSB_DOMAIN);
		return osbDomain.concat(getValue(endpoint));
	}

	/**
	 * Método responsavel por obter as informações dos parametros na base de dados
	 * h2
	 * 
	 * @param key
	 * @return
	 */
	private String getValue(String key) {
		return parametrosRepository.findByKey(key);
	}


}
