package cielo.crd.crm.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.HorarioFuncionamento;


@Repository
public interface HorarioFuncionamentoRepository extends JpaRepository<HorarioFuncionamento, Long>{

}
