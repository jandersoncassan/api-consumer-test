/**
 * 
 */
package cielo.crd.crm.model;

import java.util.List;

/**
 * Classe model responsavel pelas informações de numero logico equipamentos
 * @author @Cielo SA
 * @since RL05 - Sprint 02 Smart Entrega de Maquinas
 * @version 1.0.0
 */
public class InfoEquipamentos {

	private Integer codigoStatus;
	
	private List<Equipamento> infoEquipamentos;

	/**
	 * @return the codigoStatus
	 */
	public Integer getCodigoStatus() {
		return codigoStatus;
	}

	/**
	 * @param codigoStatus the codigoStatus to set
	 */
	public void setCodigoStatus(Integer codigoStatus) {
		this.codigoStatus = codigoStatus;
	}

	/**
	 * @return the infoEquipamentos
	 */
	public List<Equipamento> getInfoEquipamentos() {
		return infoEquipamentos;
	}

	/**
	 * @param infoEquipamentos the infoEquipamentos to set
	 */
	public void setInfoEquipamentos(List<Equipamento> infoEquipamentos) {
		this.infoEquipamentos = infoEquipamentos;
	}


}
