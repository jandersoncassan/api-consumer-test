package cielo.crd.crm.domain;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class TaxasPrazosPk implements Serializable{

	private static final long serialVersionUID = 1L;

	private Long codigoMcc;

	/**
	 * @return the codigoMcc
	 */
	public Long getCodigoMcc() {
		return codigoMcc;
	}

	/**
	 * @param codigoMcc the codigoMcc to set
	 */
	public void setCodigoMcc(Long codigoMcc) {
		this.codigoMcc = codigoMcc;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((codigoMcc == null) ? 0 : codigoMcc.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!(obj instanceof TaxasPrazosPk))
			return false;
		TaxasPrazosPk other = (TaxasPrazosPk) obj;
		if (codigoMcc == null) {
			if (other.codigoMcc != null)
				return false;
		} else if (!codigoMcc.equals(other.codigoMcc))
			return false;
		return true;
	}

	
}
