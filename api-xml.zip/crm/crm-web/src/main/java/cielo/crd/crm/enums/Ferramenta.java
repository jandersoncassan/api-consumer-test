package cielo.crd.crm.enums;

public enum Ferramenta {

	CENTRAL(4), SMART(7), FEIRAS(8);
	
	private Integer codigo;
	
	private Ferramenta(Integer codigo) {
		this.codigo = codigo;
	}

	/**
	 * Método responsavel por verificar se trata-se de um codigo de ferramenta válida
	 * @param codigo
	 * @return
	 */
	public static Boolean isFerramentaValida(Integer codigo) {
		for(Ferramenta ferramenta : Ferramenta.values()) {
			if(ferramenta.getCodigo().equals(codigo)) {
				return Boolean.TRUE;
			}
		}
		return Boolean.FALSE;
	}
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	
	/**
	 * Método responsavel por verificar se trata-se da ferramenta smart
	 * @param codigo
	 * @return
	 */
	public static Boolean isSmart(Integer codigo) {		
		return SMART.getCodigo().equals(codigo);
	}

	/**
	 * Método responsavel por verificar se trata-se da ferramenta feiras
	 * @param codigo
	 * @return
	 */
	public static Boolean isFeiras(Integer codigo) {		
		return FEIRAS.getCodigo().equals(codigo);
	}

}
