package cielo.crd.crm.controller;

import static cielo.crd.crm.utils.CrdCrmUtils.*;
import static java.util.Comparator.comparing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPResponse;
import cielo.crd.crm.domain.Banco;
import cielo.crd.crm.domain.HorarioFuncionamento;
import cielo.crd.crm.enums.Ferramenta;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.CrmJsonResponse;
import cielo.crd.crm.service.InfoAdicionalService;

@Controller
public class InfoAdicionalController {

	private static final Logger LOG = LoggerFactory.getLogger(InfoAdicionalController.class);

	private int countErrors;
	
	@Autowired
	private InfoAdicionalService infoAdicionalService;

	@GetMapping(value = "/getHorariosFuncionamento", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<List<HorarioFuncionamento>> obterListaHorariosFuncionamento() {
		List<HorarioFuncionamento> lista = infoAdicionalService.obterListaHorarioFuncionamento();
		lista.sort(comparing(HorarioFuncionamento::getDescricao));
		return new ResponseEntity<>(lista, HttpStatus.OK);
	}

	@GetMapping(value = "/consultarCep/{cep}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<ConsultarCEPResponse> consultarCep(@PathVariable("cep") String cep) {
		ConsultarCEPResponse infoCep = infoAdicionalService.consultarCep(cep);
		return new ResponseEntity<>(infoCep, HttpStatus.OK);
	}

	@PostMapping(value = "/atualizarInfoAdicional/{step}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public String atualizaPropostaRascunho(@ModelAttribute CrmCredenciamentoDto crmDto,
			@PathVariable("step") String step) {
		LOG.info("ATUALIZAR PROPOSTA RASCUNHO INFO ADICIONAL : {} : {}", crmDto.getNumeroProposta(), step);
		try {
			infoAdicionalService.atualizarPropostaRascunho(crmDto, step);
			return SUCESSO;
		} catch (RuntimeException ex) {
			LOG.error("OCORREU UM ERRO NA ATUALIZACAO DA PROPOSTA RASCUNHO INFO ADICIONAL {}", step);
			return "ERROR";
		}
	}

	@GetMapping(value = "/getListaBancos/{tipoConta}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<List<Banco>> obterListaBancos(@PathVariable("tipoConta") Integer tipoConta) {
		List<Banco> lista = infoAdicionalService.obterListaBancos(tipoConta);
//		lista.sort(Comparator.comparing(Banco::getDescricao));
		return new ResponseEntity<>(lista, HttpStatus.OK);
	}

	@PostMapping(value = "/criticarDomicilioBancario", 
				produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<String[]> atualizaPropostaRascunho(@RequestParam("cpfCnpj") String cpfCnpj, 
															@RequestParam("tipoPessoa") String tipoPessoa,
															@RequestParam("numeroProposta") Long numeroProposta,
															@RequestParam("banco") String banco, 
															@RequestParam("agencia") String agencia,
															@RequestParam("conta") String conta,
															@RequestParam("tipoConta") String tipoConta) {
		
		LOG.info("CRITICAR DOMICILIO BANCARIO");
		try {
			String[] response = infoAdicionalService.criticarContaInvalida(cpfCnpj, tipoPessoa, numeroProposta, banco, agencia, conta, tipoConta);
			return new ResponseEntity<>(response, HttpStatus.OK);
		
		} catch (RuntimeException ex) {
			LOG.error("OCORREU UM ERRO ao CRITICAR DOMICILIO BANCARIO {}", ex);
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
	}

	@GetMapping(value = "/validarVerificarDomicilioBancario/{codigoBanco}/{numeroAgencia}/{numeroConta}/{tipoConta}", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public ResponseEntity<Integer> validarVerificarDomicilioBancario(@PathVariable("codigoBanco") String codigoBanco, @PathVariable("numeroAgencia") String numeroAgencia,
			@PathVariable("numeroConta") String numeroConta, @PathVariable("tipoConta") String tipoConta) {
		
		Integer codigoValidacao = ZERO;
	
		try {
			codigoValidacao = infoAdicionalService.validarDomicilioBancario(codigoBanco, numeroAgencia, numeroConta, tipoConta);
		
			if(codigoValidacao.equals(DOMICILIO_SUCESSO)) {
				
				try {
					boolean verificarExistenciaDomicilioBancario = infoAdicionalService.verificarExistenciaDomicilioBancario(codigoBanco, numeroAgencia, numeroConta, tipoConta);
					if(verificarExistenciaDomicilioBancario) {
						codigoValidacao = DOMICILIO_EXISTE;
					}
				}catch(Exception ex) {
					codigoValidacao = FALHA_EXISTENCIA_DOMICILIO;
				}
			}
		}catch(Exception ex) {
			codigoValidacao = FALHA_VALIDACAO_DIGITO_DOMICILIO;
		}
		return new ResponseEntity<>(codigoValidacao, HttpStatus.OK);
	}

	@PostMapping(value = "/saveInfoAdicional", produces = { MediaType.APPLICATION_JSON_VALUE })
	@ResponseBody
	public CrmJsonResponse<CrmCredenciamentoDto> saveInfoAdicional(@ModelAttribute @Valid CrmCredenciamentoDto crmDto, BindingResult result) {
		LOG.info("VALIDAR CAMPOS NEXT PAGE CLIENTE : {}", crmDto.getNumeroProposta());
		
		countErrors = ZERO;
		CrmJsonResponse<CrmCredenciamentoDto> response = new CrmJsonResponse<CrmCredenciamentoDto>();
		Map<String, String> messageFields = validadorCamposCliente(crmDto, result);
		
		if(null == messageFields) {
			response.setValidated(true);
			response.setObjectModel(crmDto);

		}else {
			response.setValidated(false);
			response.setErrorMessages(messageFields);
		}
		return response;
	}

	/**
	 * Método responsavel por validar os campos obrigatórios
	 * 
	 * @param crmDto
	 * @param result
	 */
	private  Map<String, String> validadorCamposCliente(CrmCredenciamentoDto crmDto, BindingResult result) {
		
		Map<String, String> errors = result.getFieldErrors().stream().collect(Collectors.toMap(FieldError::getField, FieldError::getDefaultMessage));
		List<String> fieldsExclude = new ArrayList<String>();

		if(crmDto.getTpPessoa().equals(PESSOA_FISICA)) {
			fieldsExclude.add("nomeFantasia");fieldsExclude.add("razaoSocial");
		}
		//MESMO ENDERECO COMERCIAL CORRESPONDENCIA
		if(null != crmDto.getEndPrincMsmCorresp() ||
				//NAO CHECKED MESMO ENDERECO, POREM NÃO PREENCHEU OS CAMPOS CORRESPONDENCIA (NÃO OBRIGATORIO)
				(StringEmptyOrNull(crmDto.getCepCorrespondencia()) && StringEmptyOrNull(crmDto.getLogradouroCorrespondencia()) && StringEmptyOrNull(crmDto.getNumeroCorrespondencia()) &&
				StringEmptyOrNull(crmDto.getComplementoCorrespondencia()) && StringEmptyOrNull(crmDto.getCidadeCorrespondencia()) && StringEmptyOrNull(crmDto.getEstadoCorrespondencia()))) {

			fieldsExclude.add("cepCorrespondencia");fieldsExclude.add("logradouroCorrespondencia");fieldsExclude.add("numeroCorrespondencia");
			fieldsExclude.add("cidadeCorrespondencia");fieldsExclude.add("estadoCorrespondencia");
		}
		//MOBILE NÃO HÁ INSTALAÇÃO
		if(crmDto.getSolCaptura().equals(MOBILE) || Ferramenta.isFeiras(crmDto.getCodigoFerramenta())) {			
				fieldsExclude.add("codHorarioAtendimento");fieldsExclude.add("entregaMaquina");			
		}
		
		if(!fieldsExclude.isEmpty()) {
			//EXCLUI AS MENSAGENS DE ERRO
			cleanMessageErrors(errors, fieldsExclude);
		}
		//FIELDS VIEW CLIENTE
		List<String> fieldsCliente = Arrays.asList("nomePlaqueta","nomeFantasia","codHorarioAtendimento","razaoSocial","cepComercial", "logradouroComercial","numeroComercial","cidadeComercial",
													"estadoComercial", "cepCorrespondencia", "logradouroCorrespondencia","numeroCorrespondencia","cidadeCorrespondencia", "estadoCorrespondencia",
													"entregaMaquina", "tipoConta", "banco","agencia","conta", "digito");

		errors.forEach((f,m) -> {if(fieldsCliente.contains(f)) {countErrors++;}});

		return countErrors == ZERO ? null : errors;
		
	}

}
