package cielo.crd.crm.model;

/**
 * Model responsavel pela representação do objeto na combo "Soluções de Captura"
 * @author @Cielo SA
 * @since Release 05 - Ofertas
 * @version 1.0.0
 */
public class ItemSolucaoCaptura {

	private Integer codigo;
	private String nome;
	private String descricao;
	private String indEntregaMaquina;
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}
	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	/**
	 * @return the indEntregaMaquina
	 */
	public String getIndEntregaMaquina() {
		return indEntregaMaquina;
	}
	/**
	 * @param indEntregaMaquina the indEntregaMaquina to set
	 */
	public void setIndEntregaMaquina(String indEntregaMaquina) {
		this.indEntregaMaquina = indEntregaMaquina;
	}

	
	
}
