package cielo.crd.crm.model;

import java.util.Map;

public class CrmJsonResponse<T> {

	private T objectModel;
	private boolean validated;
	private Map<String, String> errorMessages;
	
	/**
	 * @return the objectModel
	 */
	public T getObjectModel() {
		return objectModel;
	}
	/**
	 * @param objectModel the objectModel to set
	 */
	public void setObjectModel(T objectModel) {
		this.objectModel = objectModel;
	}
	/**
	 * @return the validated
	 */
	public boolean isValidated() {
		return validated;
	}
	/**
	 * @param validated the validated to set
	 */
	public void setValidated(boolean validated) {
		this.validated = validated;
	}
	/**
	 * @return the errorMessages
	 */
	public Map<String, String> getErrorMessages() {
		return errorMessages;
	}
	/**
	 * @param errorMessages the errorMessages to set
	 */
	public void setErrorMessages(Map<String, String> errorMessages) {
		this.errorMessages = errorMessages;
	}
	
	
}
