package cielo.crd.crm.model;

/**
 * Classe model responsavel pelo response do monitor check
 * @author @Cielo SA
 * @since Release 04
 */
public class MonitoCheck {
	
	private Integer statusCode;
	private String mensagem;

	public MonitoCheck(Integer statusCode, String mensagem) {
		this.statusCode = statusCode;
		this.mensagem = mensagem;
	}

	/**
	 * @return the statusCode
	 */
	public Integer getStatusCode() {
		return statusCode;
	}

	/**
	 * @param statusCode the statusCode to set
	 */
	public void setStatusCode(Integer statusCode) {
		this.statusCode = statusCode;
	}

	/**
	 * @return the mensagem
	 */
	public String getMensagem() {
		return mensagem;
	}

	/**
	 * @param mensagem the mensagem to set
	 */
	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	
	
}
