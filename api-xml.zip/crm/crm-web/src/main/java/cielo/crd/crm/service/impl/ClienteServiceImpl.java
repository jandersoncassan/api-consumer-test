package cielo.crd.crm.service.impl;

import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.xml.rpc.ServiceException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialTypeCodigoTipoPessoa;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.BancoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.ConsultarPropostaRascunhoResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.DadosProprietarioType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.EnderecoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.EstabelecimentoComercialType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.PropostaRascunhoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.SolucaoCapturaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarpropostarascunho.TelefoneType;
import br.com.cielo.service.operacao.comercial.credenciamento.v4.consultarcliente.ConsultarClienteResponseType;
import cielo.crd.crm.enums.Ferramenta;
import cielo.crd.crm.enums.TipoCliente;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.service.ClienteService;
import cielo.crd.crm.service.osb.CrdCrmServicesOsb;
import cielo.crd.crm.utils.CrdCrmUtils;

import static cielo.crd.crm.utils.CrdCrmUtils.*;

/**
 * Classe de serviço responsavel pelas implementações e consistências de Cliente
 * @author @Cielo SA
 * @since 1.0.0
 */
@Service
public class ClienteServiceImpl implements ClienteService {

	private static final Logger LOG = LoggerFactory.getLogger(ClienteServiceImpl.class);

	@Autowired
	private CrdCrmServicesOsb servicesOsb;

	/**
	 * Método responsavel por verificar se o cliente existe no SEC
	 */
	@Override
	public String verificarExistenciaCliente(String cpfCnpj, String tipoPessoa) {
		LOG.info("VERIFICAR EXISTENCIA CLIENTE");
		if (validarCpfCnpj(cpfCnpj, tipoPessoa)) {
			try {
				 ConsultarClienteResponseType response = servicesOsb.consultarExistenciaCliente(cpfCnpj);
				 String indicadorCliente = response.getIndicadorClienteCadastrado();
				 LOG.info("CLIENTE EXITE ? : {}",  indicadorCliente);
				 
				 Optional<String> tipoIndicador = Optional.ofNullable(indicadorCliente);
				 if(tipoIndicador.isPresent() && !tipoIndicador.get().isEmpty()) {					
					return TipoCliente.isClienteValido(indicadorCliente);
				 }
				 return CLIENTE_EXISTE;

			} catch (RemoteException | MalformedURLException | ServiceException ex) {
				LOG.error("ERRO CONSULTA EXISTENCIA CLIENTE SEC :  {}", cpfCnpj);
				throw new RuntimeException("ERRO CONSULTA EXISTENCIA CLIENTE SEC : {} ", ex);
			}
		}
		return CPF_CNPJ_INVALIDO;
	}

	/**
	 * Método responsavel por validar se o CPF / CNPJ é valido
	 */
	@Override
	public boolean validarCpfCnpj(String cpfCnpj, String tipoPessoa) {
		LOG.info("VALIDAR CPF / CNPJ {} : {}", tipoPessoa, cpfCnpj);		
		if (tipoPessoa.equals(PESSOA_FISICA)) {
			return (isCpfValido(StringUtils.leftPad(cpfCnpj, 11, "0")));
		}
		return (isCnpjValido(StringUtils.leftPad(cpfCnpj, 14, "0")));
	}

	@Override
	public CrmCredenciamentoDto obterPropostaRascunho(String tipoPessoa, String cpfCnpj, Integer codigoFerramenta) {
		LOG.info("OBTER PROPOSTA RASCUNHO");
		try {
			ConsultarPropostaRascunhoResponse propostaRascunho = servicesOsb.obterPropostaRascunho(tipoPessoa,
					Long.valueOf(cpfCnpj), codigoFerramenta);
			 CrdCrmUtils.deflate("RASCUNHO", propostaRascunho);
			return tratarPropostaRascunho(propostaRascunho.getPropostaRascunho(), codigoFerramenta);

		} catch (NumberFormatException | MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("ERRO CONSULTA PROPOSTA RASCUNHO : {} : {} ", cpfCnpj, ex);
			throw new RuntimeException("ERRO CONSULTA PROPOSTA RASCUNHO");
		}

	}

	/**
	 * Método responsavel por atualizar as informações de rascunho
	 */
	@Override
	public String atualizarPropostaRascunho(CrmCredenciamentoDto rascunho, String step) {
		LOG.info("ATUALIZAR PROPOSTA RASCUNHO CLIENTE {}", step);
		try {
			AtualizarDadosParciaisPropostaRascunhoRequest request = new AtualizarDadosParciaisPropostaRascunhoRequest();
			request.setCodigoFerramenta(rascunho.getCodigoFerramenta());
			request.setNumeroProposta(rascunho.getNumeroProposta());
			request.setLoginUsuario(rascunho.getUsuarioCentral());			
			if(Ferramenta.isSmart(rascunho.getCodigoFerramenta())) {				
				request.setCodigoTipoPerfilSmart(rascunho.getCodPerfilSmart());
			}
			popularDadosEstabelecimento(request, rascunho, step);

			servicesOsb.atualizarPropostaRascunho(request);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("ERRO ATUALIZACAO DE PROPOSTA RASCUNHO  {} : {}", rascunho.getNumeroProposta(), ex);
			throw new RuntimeException("ERRO ATUALIZACAO DE PROPOSTA RASCUNHO");
		}
		return SUCESSO;
	}

	/**
	 * Método responsavel por atualizar as informações do Estabelecimento Comercial
	 * 
	 * @param request
	 * @param rascunho
	 * @param step
	 */
	private void popularDadosEstabelecimento(AtualizarDadosParciaisPropostaRascunhoRequest request,	CrmCredenciamentoDto rascunho, String step) {
		LOG.info("POPULAR DADOS ESTABELECIMENTO ");
		String tipoPessoa = rascunho.getTpPessoa();
		br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimento = new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType();
		estabelecimento.setCodigoTipoPessoa(EstabelecimentoComercialTypeCodigoTipoPessoa.fromValue(tipoPessoa));

		estabelecimento.setNumeroCpfCnpj(Long.valueOf(onlyNumber(tipoPessoa.equals(PESSOA_FISICA) ? rascunho.getCpf() : rascunho.getCnpj())));
		estabelecimento.setNomeRazaoSocial(rascunho.getNome());
		estabelecimento.setNomeFantasia(rascunho.getNome());
		estabelecimento.setNomePlaqueta(rascunho.getNome());
		
		if(!step.endsWith("01")) {
			popularProprietarios(rascunho, estabelecimento, tipoPessoa);
			popularTelefones(rascunho, estabelecimento);
		}

		request.setEstabelecimentoComercial(estabelecimento);
	}

	/**
	 * Método responsavel por popular as informações de Telefones do Estabelecimento
	 * 
	 * @param rascunho
	 * @param step
	 * @param estabelecimento
	 */
	private void popularTelefones(CrmCredenciamentoDto rascunho,
			br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimento) {
		LOG.info("POPULAR DADOS TELEFONES ");
		
		estabelecimento.setEmailContato(rascunho.getEmail());
		
			List<br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType> telefones = new ArrayList<>();

			br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType telefoneComercial = 
					new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType();

			br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType telefoneCelular = 
					new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType();
			
			// TELEFONES
			if (null != rascunho.getDddCelular() && !rascunho.getDddCelular().isEmpty()) {
				
				popularTelefone(telefoneComercial, TEL_COMERCIAL, rascunho.getDddPrincipal(), rascunho.getTelPrincipal(), telefones);
				popularTelefone(telefoneCelular, TEL_CELULAR, rascunho.getDddCelular(), rascunho.getTelCelular(), telefones);

			} else if (null == rascunho.getDddCelular() || rascunho.getDddCelular().isEmpty()) {
				popularTelefone(telefoneComercial, TEL_COMERCIAL, rascunho.getDddPrincipal(),rascunho.getTelPrincipal(), telefones);
			} 
			br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType[] arrayTelefones = 
					new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType[telefones.size()];

			estabelecimento.setTelefonesEstabelecimento(telefones.toArray(arrayTelefones));
	}

	/**
	 * Método responsavel por popular as informações de Telefone Comercial
	 * 
	 * @param telefoneComercial
	 * @param dddCelular
	 * @param telCelular
	 * @param telefones
	 */
	private void popularTelefone(
			br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType telefone,
			int tipo, String dddCelular, String telCelular,
			List<br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.TelefoneType> telefones) {

		telefone.setTipoTelefone(tipo);
		telefone.setNumeroDDD(Integer.valueOf(onlyNumber(dddCelular)));
		telefone.setNumeroTelefone(telCelular.replaceAll("-", ""));

		telefones.add(telefone);
	}

	/**
	 * Método responsavel por popular as informações de Proprietarios
	 * 
	 * @param request
	 * @param rascunho
	 * @param step
	 * @param estabelecimento
	 * @param tipoPessoa
	 */
	private void popularProprietarios(CrmCredenciamentoDto rascunho,
			br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType estabelecimento,
			String tipoPessoa) {
		LOG.info("POPULAR DADOS PROPRIETARIOS ");
		List<br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType> proprietarios = new ArrayList<>();

		br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType proprietario = new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType();

		popularProprietarios(proprietario, rascunho.getNome(), rascunho.getCpf(), rascunho.getDtNascimento(),
				proprietarios);

		if (tipoPessoa.equals(PESSOA_JURIDICA)) {
			if (!rascunho.getNomeSegundoProp().isEmpty() && !rascunho.getCpfSegundoProp().isEmpty() && rascunho.getDtNascSegundoProp() != null) {

				br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType proprietario2 = 
						new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType();
				
				popularProprietarios(proprietario2, rascunho.getNomeSegundoProp(), rascunho.getCpfSegundoProp(),
						rascunho.getDtNascSegundoProp(), proprietarios);
			}

			if (!rascunho.getNomeTerceiroProp().isEmpty() && !rascunho.getCpfTerceiroProp().isEmpty() && rascunho.getDtNascTerceiroProp() != null) {
				br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType proprietario3 = 
						new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType();

				popularProprietarios(proprietario3, rascunho.getNomeTerceiroProp(), rascunho.getCpfTerceiroProp(), rascunho.getDtNascTerceiroProp(), proprietarios);
			}
		}

		br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType[] arrayProprietarios = 
				new br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType[proprietarios.size()];

		estabelecimento.setProprietarios(proprietarios.toArray(arrayProprietarios));
	}

	/**
	 * Método responsavel por popular as informações de proprietários
	 * 
	 * @param proprietario2
	 * @param nomeSegundoProp
	 * @param cpfSegundoProp
	 * @param dtNascimento
	 * @param proprietarios
	 */
	private void popularProprietarios(
			br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType proprietario,
			String nomeSegundoProp, String cpfSegundoProp, String dtNascimento,
			List<br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.DadosProprietarioType> proprietarios) {

		proprietario.setNome(nomeSegundoProp);
		proprietario.setNumeroCpf(onlyNumber(cpfSegundoProp));
		proprietario.setDataNascimento(stringToDate(dtNascimento));

		proprietarios.add(proprietario);
	}

	/**
	 * Método responsavel por efetuar o match das informações da proposta rascunho
	 * 
	 * @param propostaRascunhoType
	 */
	private CrmCredenciamentoDto tratarPropostaRascunho(PropostaRascunhoType propostaRascunho, Integer codigoFerramenta) {
		LOG.info("TRATAR DADOS PROPOSTA RASCUNHO ");
		CrmCredenciamentoDto crmDto = new CrmCredenciamentoDto();
		crmDto.setNumeroProposta(propostaRascunho.getNumeroProposta());
		crmDto.setCodigoFerramenta(codigoFerramenta);
		popularDadosEstabelecComercial(propostaRascunho.getEstabelecimentoComercial(), crmDto);
		popularSolucaoCaptura(propostaRascunho.getSolucoesCaptura(), crmDto);
		return crmDto;
	}

	/**
	 * Método responsavel por popular as informações do Estabelecimento Comercial
	 * 
	 * @param estabelecimentoComercial
	 * @param crmDto
	 * @param solucaoCaptura
	 * @param infoAdicional
	 */
	private void popularDadosEstabelecComercial(EstabelecimentoComercialType estabelecimentoComercial,
			CrmCredenciamentoDto crmDto) {
		LOG.info("TRATAR DADOS ESTABELECIMENTO COMERCIAL");
		crmDto.setTpPessoa(objectNullToString(estabelecimentoComercial.getCodigoTipoPessoa().getValue()));
		if (crmDto.getTpPessoa().equals(PESSOA_FISICA)) {
			crmDto.setCpf(objectNullToString(estabelecimentoComercial.getNumeroCpfCnpj()));
		} else {
			crmDto.setCnpj(objectNullToString(estabelecimentoComercial.getNumeroCpfCnpj()));
		}
		// estabelecimentoComercial.getNumeroEc();
		crmDto.setNome(estabelecimentoComercial.getNomeRazaoSocial());
		// estabelecimentoComercial.getIndicadorMicroEmpreendedorIndividual();
		// estabelecimentoComercial.getNumeroInscricaoEstadual();
		crmDto.setNomePlaqueta(estabelecimentoComercial.getNomeRazaoSocial());
		// estabelecimentoComercial.getNomePessoaContato();
		crmDto.setEmail(objectNullToString(estabelecimentoComercial.getEmailContato()));
		crmDto.setRamoAtividade(objectNullToInteger(estabelecimentoComercial.getCodigoRamoAtividade()));
		crmDto.setFaturamento(objectNullToInteger(estabelecimentoComercial.getValorMedioFaturamento()));
		// estabelecimentoComercial.getCodigoAfiliador();
		// estabelecimentoComercial.getindEstabComercialMigrado;
		// estabelecimentoComercial.getIndicadorCadastroDuplicado();
		// estabelecimentoComercial.gdataAtivacaoEstabComercial;
		crmDto.setTpPlano(objectNullToInteger(estabelecimentoComercial.getCodigoTipoPlanoCielo()));
		crmDto.setDiasLiqControle(objectNullToInteger(estabelecimentoComercial.getQuantidadeDiasLiquidacao()));
		// estabelecimentoComercial.gindicadorPagamentoLink;
		// estabelecimentoComercial.getCodigoTipoModalidadePagamento();
		// estabelecimentoComercial.gcodOperadora;

		popularDomicilioBancario(estabelecimentoComercial.getDomiciliosBancarios(), crmDto);
		popularTelefones(estabelecimentoComercial.getTelefonesEstabelecimento(), crmDto);
		popularEnderecos(estabelecimentoComercial.getEnderecosEstabelecimento(), crmDto);
		popularProprietarios(estabelecimentoComercial.getProprietarios(), crmDto);

	}

	/**
	 * Método responsavel por popular as informações de Domicilio Bancario
	 * 
	 * @param domiciliosBancarios
	 * @param crmDto
	 * @param infoAdicional
	 */
	private void popularDomicilioBancario(BancoType[] domiciliosBancarios, CrmCredenciamentoDto crmDto) {
		LOG.info("TRATAR DADOS DOMICILIO BANCARIO ");
		if (null != domiciliosBancarios) {
			String tipoConta = domiciliosBancarios[0].getTipoConta();
			crmDto.setTipoConta(tipoConta.equals(STRING_EMPTY) ? "99": tipoConta);
			
			String banco = domiciliosBancarios[0].getCodigoBanco();
			crmDto.setBanco(banco.equals(STRING_EMPTY) ? ZERO_S: banco);
			
			crmDto.setAgencia(domiciliosBancarios[0].getNumeroAgencia());
			String contaCompleta = domiciliosBancarios[0].getNumeroContaCorrente();
			
			String conta = contaCompleta.substring(0, contaCompleta.length()-1);
			
			if(crmDto.getBanco().equals(CAIXA_ECONOMICA)) {
				conta = contaCompleta.substring(contaCompleta.length()-9, contaCompleta.length()-1);
			}
			String digito = contaCompleta.substring(contaCompleta.length()-1);
			
			crmDto.setConta(conta);
			crmDto.setDigito(digito);
		}
	}

	/**
	 * Método responsavel por popular as informações de Telefone
	 * 
	 * @param telefonesEstabelecimento
	 * @param cliente
	 */
	private void popularTelefones(TelefoneType[] telefonesEstabelecimento, CrmCredenciamentoDto crmDto) {
		LOG.info("TRATAR DADOS TELEFONES ");
		if (null != telefonesEstabelecimento) {
			for (int i = 0; i < telefonesEstabelecimento.length; i++) {
				Integer tipoTelefone = telefonesEstabelecimento[i].getTipoTelefone();
				if (tipoTelefone.equals(2)) {
					// 2 COMERCIAL
					crmDto.setDddPrincipal(telefonesEstabelecimento[i].getNumeroDDD().toString());
					crmDto.setTelPrincipal(telefonesEstabelecimento[i].getNumeroTelefone());
				} else if (tipoTelefone.equals(3)) {
					// 3 CELULAR
					crmDto.setDddCelular(telefonesEstabelecimento[i].getNumeroDDD().toString());
					crmDto.setTelCelular(telefonesEstabelecimento[i].getNumeroTelefone());
				}
			}
		}
	}

	/**
	 * Método responsavel por popular as informações de Endereço
	 * 
	 * @param enderecosEstabelecimento
	 * @param infoAdicional
	 */
	private void popularEnderecos(EnderecoType[] enderecosEstabelecimento, CrmCredenciamentoDto crmDto) {
		LOG.info("TRATAR DADOS ENDERECOS ");
		if (null != enderecosEstabelecimento) {
			for (int i = 0; i < enderecosEstabelecimento.length; i++) {
				Integer tipoEndereco = enderecosEstabelecimento[i].getTipoEndereco();
				if (tipoEndereco.equals(2)) {
					// 2-COMERCIAL
					crmDto.setLogradouroComercial(enderecosEstabelecimento[i].getNomeLogradouro());
					crmDto.setComplementoComercial(enderecosEstabelecimento[i].getDescricaoComplementoEndereco());
					crmDto.setNumeroComercial(enderecosEstabelecimento[i].getNumeroLogradouro());
					crmDto.setCidadeComercial(enderecosEstabelecimento[i].getNomeCidade());
					crmDto.setEstadoComercial(enderecosEstabelecimento[i].getSiglaEstado());
					crmDto.setCepComercial(enderecosEstabelecimento[i].getNumeroCEP().toString());

				} else if (tipoEndereco.equals(3)) {
					// 3-CORRESPONDECIA
					crmDto.setLogradouroCorrespondencia(enderecosEstabelecimento[i].getNomeLogradouro());
					crmDto.setComplementoCorrespondencia(enderecosEstabelecimento[i].getDescricaoComplementoEndereco());
					crmDto.setNumeroCorrespondencia(enderecosEstabelecimento[i].getNumeroLogradouro());
					crmDto.setCidadeCorrespondencia(enderecosEstabelecimento[i].getNomeCidade());
					crmDto.setEstadoCorrespondencia(enderecosEstabelecimento[i].getSiglaEstado());
					crmDto.setCepCorrespondencia(enderecosEstabelecimento[i].getNumeroCEP().toString());
				}
				// enderecosEstabelecimento[i].getNomeBairro();
			}
		}
	}

	/**
	 * Método responsavel por popular as informações de Proprietários
	 * 
	 * @param proprietarios
	 * @param cliente
	 */
	private void popularProprietarios(DadosProprietarioType[] proprietarios, CrmCredenciamentoDto crmDto) {
		LOG.info("TRATAR DADOS PROPRIETARIOS ");
		if (null != proprietarios) {
			// PROPRIETARIO 01
			crmDto.setNome(proprietarios[0].getNome());
			crmDto.setCpf(proprietarios[0].getNumeroCpf());
			crmDto.setDtNascimento(dateToString(proprietarios[0].getDataNascimento()));

			if (crmDto.getTpPessoa().equals(PESSOA_JURIDICA)) {
				if (proprietarios.length > 1) {
					// PROPRIETARIO 02
					crmDto.setNomeSegundoProp(proprietarios[1].getNome());
					crmDto.setCpfSegundoProp(proprietarios[1].getNumeroCpf());
					crmDto.setDtNascSegundoProp(dateToString(proprietarios[1].getDataNascimento()));
					crmDto.setMaisProprietarios(true);
				}
				if (proprietarios.length > 2) {
					// PROPRIETARIO 03
					crmDto.setNomeTerceiroProp(proprietarios[2].getNome());
					crmDto.setCpfTerceiroProp(proprietarios[2].getNumeroCpf());
					crmDto.setDtNascTerceiroProp(dateToString(proprietarios[2].getDataNascimento()));
					crmDto.setMaisProprietarios(true);
				}
			}
		}
	}

	/**
	 * Método responsavel por popular as informações de solução de captura
	 * 
	 * @param solucoesCaptura
	 * @param crmDto
	 * @param solucaoCaptura
	 * @param infoAdicional
	 */
	private void popularSolucaoCaptura(SolucaoCapturaType[] solucoesCaptura, CrmCredenciamentoDto crmDto) {
		LOG.info("TRATAR DADOS SOLUCAO CAPTURA ");
		if (null != solucoesCaptura && solucoesCaptura.length > 0) {
			crmDto.setSolCaptura(objectNullToInteger(solucoesCaptura[0].getCodigoSolucaoCaptura()));
			crmDto.setQtdadeMaquinas(objectNullToInteger(solucoesCaptura[0].getQuantidadeEquipamentos()));
			crmDto.setPotencialVendas(objectNullToInteger(solucoesCaptura[0].getCodigoPacoteEcommerce()));
			crmDto.setPagamentoLink(solucoesCaptura[0].getIndicadorPagamentoPorLink() ? "S" : "N");
			crmDto.setCodHorarioAtendimento(objectNullToString(solucoesCaptura[0].getCodigoHorarioFuncionamento()));
			List<Integer> listaOperadoras = new ArrayList<>();
			if (null != solucoesCaptura[0].getOperadoras()) {
				for (int solucao : solucoesCaptura[0].getOperadoras()) {
					listaOperadoras.add(solucao);
				}
			}
			crmDto.setOperadora(listaOperadoras);
		}else {
			crmDto.setSolCaptura(OPT_SELECT);
			crmDto.setQtdadeMaquinas(OPT_SELECT);
		}
	}
}
