package cielo.crd.crm.model;

/**
 * Classe model responsavel pelo tratarmento dos itens da combo de faturamento
 * @author @Cielo SA
 * @since Release 05 - Sprint 02
 * @version 1.0.0
 */
public class ItemFaturamento {

	private Integer codigo;
	private String descricao;
	
	/**
	 * @return the codigo
	 */
	public Integer getCodigo() {
		return codigo;
	}
	/**
	 * @param codigo the codigo to set
	 */
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}
	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	
	
}
