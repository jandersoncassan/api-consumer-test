package cielo.crd.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.Config;
import java.lang.String;

@Repository
public interface ParametrosRepository extends JpaRepository<Config, Long>{

	 List<Config> findAll();
	 
	 @Query("SELECT t.value FROM Config t WHERE t.key = :key") 
	 String findByKey(@Param("key") String key);
}
