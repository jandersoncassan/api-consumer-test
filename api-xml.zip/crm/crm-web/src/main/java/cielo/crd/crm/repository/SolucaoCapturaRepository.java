package cielo.crd.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.SolucaoCaptura;

@Repository
public interface SolucaoCapturaRepository extends JpaRepository<SolucaoCaptura, Long> {

	 @Query("SELECT s FROM SolucaoCaptura s WHERE s.id.codigoFerramenta = :codigoFerramenta") 
	 List<SolucaoCaptura> getListaSolucoesCaptura(@Param("codigoFerramenta") Integer codigoFerramenta);
}
