package cielo.crd.crm.service.impl;

import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.rpc.ServiceException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.ConsultarMccPorTipoPessoaFerramentaResponseType;
import br.com.cielo.service.cadastro.cliente.cliente.v6.consultarmccportipopessoaferramenta.DadosMccType;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ConsultarListaTaxaPrazoResponseType;
import br.com.cielo.service.cadastro.produto.produto.v4.consultarlistataxaprazo.ProdutosTaxaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialTypeCodigoTipoPessoa;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.ConsultarListaFaturamentoResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistafaturamento.FaturamentoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.ConsultarListaParametrosSolucaoCapturaResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.ConsultarSolucaoCapturaPorFerramentaResponse;
import cielo.crd.crm.domain.Faturamento;
import cielo.crd.crm.domain.RamoAtividade;
import cielo.crd.crm.domain.RamoAtividadePk;
import cielo.crd.crm.domain.SolucaoCaptura;
import cielo.crd.crm.domain.SolucaoCapturaPk;
import cielo.crd.crm.domain.SolucaoEquipamento;
import cielo.crd.crm.domain.SolucaoEquipamentoPk;
import cielo.crd.crm.domain.TaxasPrazos;
import cielo.crd.crm.domain.TaxasPrazosPk;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.ItemFaturamento;
import cielo.crd.crm.model.ItemSolucaoCaptura;
import cielo.crd.crm.repository.FaturamentoRepository;
import cielo.crd.crm.repository.ParametrosRepository;
import cielo.crd.crm.repository.RamoAtividadeRepository;
import cielo.crd.crm.repository.SolucaoCapturaRepository;
import cielo.crd.crm.repository.SolucaoEquipamentoRepository;
import cielo.crd.crm.repository.TaxasPrazosRepository;
import cielo.crd.crm.service.SolucaoCapturaService;
import cielo.crd.crm.service.osb.CrdCrmServicesOsb;

import static cielo.crd.crm.utils.CrdCrmUtils.*;

/**
 * Classe de serviço responsavel pelas implementações e consistências de Solução
 * de Captura
 * 
 * @author @Cielo SA
 * @since 1.0.0
 */
@Service
public class SolucaoCapturaServiceImpl implements SolucaoCapturaService {

	private static final Logger LOG = LoggerFactory.getLogger(SolucaoCapturaServiceImpl.class);

	@Autowired
	private CrdCrmServicesOsb servicesOsb;

	@Autowired
	private RamoAtividadeRepository ramoAtividadeRepository;

	@Autowired
	private TaxasPrazosRepository taxasPrazosRepository;

	@Autowired
	private SolucaoEquipamentoRepository solucaoEquipamentoRepository;

	@Autowired
	private SolucaoCapturaRepository solucaoCapturaRepository;

	@Autowired
	private FaturamentoRepository faturamentoRepository;

	@Autowired
	private ParametrosRepository config;

	@Caching(evict = {  @CacheEvict(value = "ramoAtividade", allEntries = true),
						@CacheEvict(value = "rangeFaturamento", allEntries = true),
						@CacheEvict(value = "solucaoCaptura", allEntries = true),
						@CacheEvict(value = "qtdadeEquipamentos", allEntries = true) 
					 })
	public void clearCaching() {
	}

	/**
	 * TODO método paliativo, na proxima release retirar essa implementação
	 * By @Janderson
	 */
	public String isActiveRecebarapido() {
		return config.findByKey("isGetActiveFast");
	}

	@Cacheable("ramoAtividade")
	@Override
	public List<RamoAtividade> obterListaRamosAtividades(String tipoPessoa, Integer codigoFerramenta) {
		LOG.info("CONSULTANDO RAMOS DE ATIVIDADES TIPO DE PESSOA {}", tipoPessoa);
		try {
			return ramoAtividadeRepository.findAllByTpPessoa(tipoPessoa, codigoFerramenta);

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO CONSULTAR RAMOS DE ATIVIDADES {}", ex);
			throw new RuntimeException();
		}
	}

	@Override
	public List<RamoAtividade> getListaRamosAtividadesCrd(String tipoPessoa, Integer codigoFerramenta) {
		LOG.info("GET LISTA RAMOS DE ATIVIDADES CRD {}", tipoPessoa);
		try {
			ConsultarMccPorTipoPessoaFerramentaResponseType listaRamosAtividades = servicesOsb
					.obterListaRamosAtividades(tipoPessoa, codigoFerramenta);
			return Arrays.asList(listaRamosAtividades.getListaMcc()).stream()
					.map(ramo -> popularLista(tipoPessoa, codigoFerramenta, ramo)).collect(Collectors.toList());

		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A LISTA DE RAMOS DE ATIVIDADES CRD {}", ex);
			throw new RuntimeException();
		}
	}

	/**
	 * Método responsavel por popular as informações do Ramos de Atividade
	 * 
	 * @param tpPessoa
	 * @param mcc
	 * @return
	 */
	private RamoAtividade popularLista(String tpPessoa, Integer codigoFerramenta, DadosMccType mcc) {
		RamoAtividadePk pk = new RamoAtividadePk();
		pk.setCodigoFerramenta(codigoFerramenta);
		pk.setTipoPessoa(tpPessoa);
		pk.setCodigo(mcc.getIdentificador().intValue());

		RamoAtividade ramoAtividade = new RamoAtividade();
		ramoAtividade.setPk(pk);
		ramoAtividade.setDescricao(mcc.getDescricao());

		return ramoAtividade;
	}

	@Override
	public TaxasPrazos obterTaxasPrazos(Long codigoMcc) {
		LOG.info("CONSULTANDO TAXAS PRAZOS MCC {}", codigoMcc);
		try {

			return taxasPrazosRepository.findByCodigoMcc(codigoMcc);

		} catch (Exception ex) {
			LOG.error("ocorreu um erro na consulta de taxa mcc {}", ex);
			throw new RuntimeException();
		}

	}

	@Override
	public Optional<List<TaxasPrazos>> getListaTaxasPrazos() {
		LOG.info("OBTER A LISTA DE TAXAS E PRAZOS SEC VIA SERVICO OSB");
		try {
			ConsultarListaTaxaPrazoResponseType listaTaxasPrazo = servicesOsb.consultarListaTaxas();

			Optional<ProdutosTaxaType[]> lista = Optional.ofNullable(listaTaxasPrazo.getListaProdutos());

			if (lista.isPresent()) {
				return Optional.of(Arrays.asList(listaTaxasPrazo.getListaProdutos()).stream()
						.map(taxaPrazo -> popularTaxaPrazo(taxaPrazo)).collect(Collectors.toList()));
			}

			return Optional.ofNullable(null);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A LISTA DE TAXAS PRAZOS SEC VIA SERVICO OSB {}", ex);
			throw new RuntimeException();
		}

	}

	/**
	 * Método responsavel por popular o obeto Taxas / Prazos
	 * 
	 * @param taxa
	 * @return
	 */
	private TaxasPrazos popularTaxaPrazo(ProdutosTaxaType taxa) {
		TaxasPrazosPk pk = new TaxasPrazosPk();
		pk.setCodigoMcc(Long.valueOf(taxa.getMcc()));
		TaxasPrazos taxasPrazo = new TaxasPrazos();
		taxasPrazo.setPk(pk);
		taxasPrazo.setProduto40(bigdecimalToString(taxa.getTaxaProduto40()));
		taxasPrazo.setProduto41(bigdecimalToString(taxa.getTaxaProduto41()));
		taxasPrazo.setProduto43(bigdecimalToString(taxa.getTaxaProduto43()));
		taxasPrazo.setSegmentado3Parcelas(bigdecimalToString(taxa.getTaxaSegmentada3Parcelas()));
		taxasPrazo.setSegmentado6Parcelas(bigdecimalToString(taxa.getTaxaSegmentada6Parcelas()));
		taxasPrazo.setSegmentado12Parcelas(bigdecimalToString(taxa.getTaxaSegmentada12Parcelas()));
		return taxasPrazo;
	}

	/**
	 * Formato de valores que devem ser apresentados na tela o SEC devolve 00278 o
	 * OSB transforma em BigDecimal ? (278.00) o correto é 2.78
	 * 
	 * @param valor
	 * @return
	 */
	private String bigdecimalToString(BigDecimal valor) {
		String[] vls = valor.toString().split("\\.");
		return vls[0].substring(0, 1).concat(".").concat(vls[0].substring(1));
	}

	@Cacheable("solucaoCaptura")
	@Override
	public List<ItemSolucaoCaptura> getOpcoesSolucaoCaptura(Integer codigoFerramenta) {
		LOG.info("CONSULTANDO LISTA DE ITENS COMBO SOLUCAO DE CAPTURA {}", codigoFerramenta);
		try {
			List<SolucaoCaptura> listaSolucoesCaptura = solucaoCapturaRepository
					.getListaSolucoesCaptura(codigoFerramenta);

			List<ItemSolucaoCaptura> listaItens = listaSolucoesCaptura.stream()
					.map(solucao -> popularInfoSolucao(solucao)).collect(Collectors.toList());
			return listaItens;

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO CONSULTAR LISTA DE ITENS COMBO SOLUCAO DE CAPTURA {}", ex);
			throw new RuntimeException();
		}
	}

	@Override
	public Optional<List<SolucaoCaptura>> obterListaSolucaoCaptura(Integer codigoFerramenta) {
		LOG.info("OBTER A LISTA DE SOLUCAO DE CAPTURA POR FERRAMENTA VIA SERVICO OSB");
		try {
			ConsultarSolucaoCapturaPorFerramentaResponse listaSolucoes = servicesOsb
					.obterListaSolucaoCapturaFerramenta(codigoFerramenta);

			Optional<br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.SolucaoCapturaType[]> lista = Optional
					.ofNullable(listaSolucoes.getSolucoesCaptura());

			if (lista.isPresent()) {
				return Optional.of(Arrays.asList(lista.get()).stream()
						.map(solucao -> popularInfoSolucao(solucao, codigoFerramenta)).collect(Collectors.toList()));
			}

			return Optional.ofNullable(null);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A LISTA DE TAXAS PRAZOS SEC VIA SERVICO OSB {}", ex);
			throw new RuntimeException();
		}
	}

	@Cacheable("rangeFaturamento")
	@Override
	public List<ItemFaturamento> getListaFaturamento() {
		LOG.info("CONSULTANDO LISTA DE ITENS COMBO FATURAMENTO");
		try {
			List<Faturamento> listaRangeFaturamento = faturamentoRepository.findAll();

			return listaRangeFaturamento.stream().map(range -> popularInfoFaturamento(range))
					.collect(Collectors.toList());

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO CONSULTAR LISTA DE ITENS COMBO FATURAMENTO {}", ex);
			throw new RuntimeException();
		}
	}

	/**
	 * Método responsavel por popular a lista de itens de faturamento
	 * 
	 * @param range
	 * @return
	 */
	private ItemFaturamento popularInfoFaturamento(Faturamento range) {
		ItemFaturamento itemFaturamento = new ItemFaturamento();
		itemFaturamento.setCodigo(Integer.valueOf(range.getCodigo().toString()));
		itemFaturamento.setDescricao(range.getDescricao());
		return itemFaturamento;
	}

	/**
	 * Método responsavel por popular as informações de itens da combo de solução de
	 * captura
	 * 
	 * @param solucao
	 * @return
	 */
	private SolucaoCaptura popularInfoSolucao(
			br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarsolucaocapturaporferramenta.SolucaoCapturaType solucaoType,
			Integer codigoFerramenta) {

		SolucaoCapturaPk pk = new SolucaoCapturaPk();
		pk.setCodigoFerramenta(codigoFerramenta);
		pk.setCodigoSolucao(solucaoType.getCodigoSolucaoCaptura());

		SolucaoCaptura item = new SolucaoCaptura();
		item.setPk(pk);
		item.setNome(solucaoType.getNome());
		item.setDescricao(solucaoType.getDescricao());
		item.setIndEntregaMaquina(solucaoType.getIndicadorEntregaMaquina() ? "S" : "N");
		return item;
	}

	/**
	 * Método responsavel por popular as informações de itens da combo de solução de
	 * captura
	 * 
	 * @param solucao
	 * @return
	 */
	private ItemSolucaoCaptura popularInfoSolucao(SolucaoCaptura solucao) {
		ItemSolucaoCaptura item = new ItemSolucaoCaptura();
		item.setCodigo(solucao.getPk().getCodigoSolucao());
		item.setNome(solucao.getNome());
		item.setDescricao(solucao.getDescricao());
		item.setIndEntregaMaquina(solucao.getIndEntregaMaquina());
		return item;
	}

	@Override
	public String atualizarPropostaRascunho(CrmCredenciamentoDto rascunho, String step) {
		LOG.info("ATUALIZAR PROPOSTA RASCUNHO");
		try {
			AtualizarDadosParciaisPropostaRascunhoRequest request = new AtualizarDadosParciaisPropostaRascunhoRequest();
			request.setCodigoFerramenta(rascunho.getCodigoFerramenta());
			request.setNumeroProposta(rascunho.getNumeroProposta());
			popularDadosEstabelecimento(request, rascunho);
			popularSolucaoCaptura(request, rascunho);
			servicesOsb.atualizarPropostaRascunho(request);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("ERRO ATUALIZACAO DE PROPOSTA RASCUNHO  {} : {}", rascunho.getNumeroProposta(), ex);
			throw new RuntimeException("ERRO ATUALIZACAO DE PROPOSTA RASCUNHO");
		}
		return SUCESSO;

	}

	/**
	 * Método responsavel por popular as informações do estabelecimento
	 * 
	 * @param request
	 * @param rascunho
	 */
	private void popularDadosEstabelecimento(AtualizarDadosParciaisPropostaRascunhoRequest request,
			CrmCredenciamentoDto rascunho) {
		String tipoPessoa = rascunho.getTpPessoa();
		EstabelecimentoComercialType estabelecimento = new EstabelecimentoComercialType();
		estabelecimento.setCodigoTipoPessoa(EstabelecimentoComercialTypeCodigoTipoPessoa.fromValue(tipoPessoa));

		if (tipoPessoa.equals(PESSOA_FISICA)) {
			estabelecimento.setNumeroCpfCnpj(Long.valueOf(onlyNumber(rascunho.getCpf())));
		} else {
			estabelecimento.setNumeroCpfCnpj(Long.valueOf(onlyNumber(rascunho.getCnpj())));
		}
		estabelecimento.setCodigoRamoAtividade(rascunho.getRamoAtividade());
		estabelecimento.setValorMedioFaturamento(BigDecimal.valueOf(rascunho.getFaturamento()));

		if (null != rascunho.getArv())
			estabelecimento.setTaxaArv(new BigDecimal(rascunho.getTxArv()));

		estabelecimento.setCodigoTipoPlanoCielo(rascunho.getTpPlano());
		estabelecimento.setQuantidadeDiasLiquidacao(rascunho.getTpPlano().equals(PLANO_CIELO_LIVRE)	? DOIS 
				: Optional.ofNullable(rascunho.getDiasLiqControle()).orElse(ZERO));//SE FOR ALUGUEL ZERO PASSAMOS 02 FIXO

		request.setEstabelecimentoComercial(estabelecimento);
	}

	/**
	 * Método responsavel por popular as informações de Solução de Captura
	 * 
	 * @param request
	 * @param rascunho
	 */
	private void popularSolucaoCaptura(AtualizarDadosParciaisPropostaRascunhoRequest request,
			CrmCredenciamentoDto rascunho) {

		SolucaoCapturaType[] solucoes = new SolucaoCapturaType[UM];

		SolucaoCapturaType solucaoCaptura = new SolucaoCapturaType();
		solucaoCaptura.setCodigoSolucaoCaptura(rascunho.getSolCaptura());
		Optional<String> indEntregaMaquina = Optional.ofNullable(rascunho.getIndEntregaMaquina());
		solucaoCaptura.setIndicadorEntregaMaquina(indEntregaMaquina.isPresent() ? Boolean.TRUE : Boolean.FALSE);
		solucaoCaptura.setCodigoPacoteEcommerce(objectNullToString(rascunho.getPotencialVendas()));
		solucaoCaptura.setIndicadorPagamentoPorLink(null != rascunho.getPagamentoLink() ? Boolean.TRUE : Boolean.FALSE);
		
		solucaoCaptura.setQuantidadeEquipamentos(isQtdadeEquipamentoFixa(rascunho.getTpPlano(), rascunho.getSolCaptura())? 1: rascunho.getQtdadeMaquinas());

		if (null != rascunho.getOperadora() && !rascunho.getOperadora().isEmpty()) {
			int[] operadoras = rascunho.getOperadora().stream().mapToInt(i -> i).toArray();
			solucaoCaptura.setOperadoras(operadoras);
		}
		solucoes[0] = solucaoCaptura;

		request.setSolucoesCaptura(solucoes);
	}

	/**
	 * Método responsavel por obter a quantidade de equipamentos permitidos para a
	 * solução de captura
	 */
	@Cacheable("qtdadeEquipamentos")
	@Override
	public Integer getQtdadeMaximaEquipamentos(Integer codSolucaoCaptura, Integer codigoFerramenta) {
		LOG.info("OBTER A QUANTIDADE DE EQUIPAMENTOS PERMITIDOS PARA A SOLUCAO DE CAPTURA {}", codSolucaoCaptura);
		try {
			Optional<SolucaoEquipamento> solucaoEquipamento = Optional.ofNullable(
					solucaoEquipamentoRepository.findByPk(Long.valueOf(codSolucaoCaptura), codigoFerramenta));
			return (solucaoEquipamento.isPresent() ? solucaoEquipamento.get().getQtdadeMaxima() : UM);

		} catch (Exception ex) {
			LOG.error("ERRO OBTER A QUANTIDADE DE EQUIPAMENTOS PERMITIDOS PARA A SOLUCAO DE CAPTURA {} - {}",
					codSolucaoCaptura, ex);
			throw new RuntimeException();
		}
	}

	/**
	 * Método responsavel por devolver a lista solucação de captura (quantidade
	 * maxima de equipamentos)
	 */
	@Override
	public Optional<List<SolucaoEquipamento>> obterListaSolucaoEquipamentos(Integer codigoFerramenta) {
		LOG.info("GET LISTA SOLUCAO DE CAPTURA (QUANTIDADE MAXIMA DE EQUIPAMENTOS)");
		try {
			ConsultarListaParametrosSolucaoCapturaResponse response = servicesOsb
					.obterListaSolucaoQtdEquipamentos(codigoFerramenta);
			Optional<br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.SolucaoCapturaType[]> listaSolucoesEquipamentos = Optional
					.ofNullable(response.getSolucoesCaptura());
			// POPULAMOS AS INFORMAÇÕES NA LISTA
			if (listaSolucoesEquipamentos.isPresent()) {
				List<SolucaoEquipamento> listaSolucao = Arrays.asList(listaSolucoesEquipamentos.get()).stream()
						.map(solucao -> popularInfoSolucaoEquipamento(solucao, codigoFerramenta))
						.collect(Collectors.toList());
				return Optional.of(listaSolucao);
			}
			// CASO NÃO RETORNE NENHUM ELEMENTO
			return Optional.ofNullable(null);

		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A LISTA DE RAMOS DE ATIVIDADES CRD {}", ex);
			throw new RuntimeException();
		}
	}

	/**
	 * Método responsavel por popular as informações de Solução Equipamento
	 * 
	 * @param solucaoType
	 * @return
	 */
	private SolucaoEquipamento popularInfoSolucaoEquipamento(
			br.com.cielo.service.operacao.comercial.credenciamento.v3.consultarlistaparametrossolucaocaptura.SolucaoCapturaType solucaoType,
			Integer codigoFerramenta) {

		SolucaoEquipamentoPk pk = new SolucaoEquipamentoPk();
		pk.setCodigoFerramenta(codigoFerramenta);
		pk.setCodSolucaoCaptura(Long.valueOf(solucaoType.getCodigoSolucaoCaptura()));

		SolucaoEquipamento solucao = new SolucaoEquipamento();
		solucao.setId(pk);
		solucao.setQtdadeMaxima(solucaoType.getQuantidadeMaximaPermitida());
		solucao.setIndicadorMei(solucaoType.getIndicadorMei() ? "S" : "N");
		return solucao;
	}

	/**
	 * Método responsavel por devolver a lista range de faturamento
	 */
	@Override
	public Optional<List<Faturamento>> obterRangeFaturamento() {
		LOG.info("OBTER A LISTA DE RANGE DE FATURAMENTO");
		try {
			ConsultarListaFaturamentoResponseType listaResponse = servicesOsb.obterListaFaturamento();
			Optional<FaturamentoType[]> rangesFaturamento = Optional.ofNullable(listaResponse.getFaturamentos());
			if (rangesFaturamento.isPresent()) {
				List<Faturamento> listaFaturamento = Arrays.asList(rangesFaturamento.get()).stream()
						.map(range -> populaInfoRangeFaturamento(range)).collect(Collectors.toList());
				return Optional.of(listaFaturamento);
			}
			// CASO NÃO RETORNE NENHUM ELEMENTO
			return Optional.ofNullable(null);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO AO OOBTER A LISTA DE RANGE DE FATURAMENTO CRD {}", ex);
			throw new RuntimeException();
		}
	}

	/**
	 * Método responsavel por popular o range de faturamento
	 * 
	 * @param range
	 * @return
	 */
	private Faturamento populaInfoRangeFaturamento(FaturamentoType range) {
		Faturamento faturamento = new Faturamento();
		faturamento.setCodigo(Long.valueOf(range.getCodigo()));
		faturamento.setDescricao(range.getDescricao());
		return faturamento;
	}

}
