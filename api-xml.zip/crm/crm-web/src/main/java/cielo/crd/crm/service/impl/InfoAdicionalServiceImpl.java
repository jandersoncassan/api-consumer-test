package cielo.crd.crm.service.impl;

import static cielo.crd.crm.utils.CrdCrmUtils.*;

import java.net.MalformedURLException;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.xml.rpc.ServiceException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.stereotype.Service;

import br.com.cielo.service._interface.banco.banco.v2.validarDigitoAgenciaConta.ValidarDigitoAgenciaContaResponse;
import br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.ListarBancosResponse;
import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPResponse;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.AtualizarDadosParciaisPropostaRascunhoRequest;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.BancoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EnderecoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.EstabelecimentoComercialTypeCodigoTipoPessoa;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.atualizardadosparciaispropostarascunho.SolucaoCapturaType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.CampoType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoRequestType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.registrarcriticapropostarascunho.RegistrarCriticaPropostaRascunhoResponseType;
import br.com.cielo.service.operacao.comercial.credenciamento.v3.verificarExistenciaDomicilioBancario.VerificarExistenciaDomicilioBancarioResponse;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.ConsultarHorarioFuncionamentoResponseType;
import br.com.cielo.service.operacao.logistica.equipamento.v5.consultarhorariofuncionamento.HorarioType;
import cielo.crd.crm.domain.Banco;
import cielo.crd.crm.domain.BancoPk;
import cielo.crd.crm.domain.HorarioFuncionamento;
import cielo.crd.crm.domain.HorarioFuncionamentoPk;
import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.repository.BancoRepository;
import cielo.crd.crm.repository.HorarioFuncionamentoRepository;
import cielo.crd.crm.service.InfoAdicionalService;
import cielo.crd.crm.service.osb.CrdCrmServicesOsb;

/**
 * Classe de serviço responsavel pelas implementações e consistências de
 * Informações Adicionais
 * 
 * @author @Cielo SA
 * @since 1.0.0
 */
@Service
public class InfoAdicionalServiceImpl implements InfoAdicionalService {

	private static final Logger LOG = LoggerFactory.getLogger(InfoAdicionalServiceImpl.class);
	
	final Integer BANCO=5, AGENCIA=4, CONTA=3, TIPO_CONTA=20; //DOMINIOS FIXOS 'CRITICA DOMICILIO BANCARIO' (TBCRDR_CMPO_CRDN)	

	@Autowired
	private HorarioFuncionamentoRepository horarioFuncionamentoRepository;

	@Autowired
	private BancoRepository bancoRepository;

	@Autowired
	private CrdCrmServicesOsb servicesOsb;

	@Caching(evict = {
		    @CacheEvict(value= "horarioFuncionamento", allEntries = true),
		    @CacheEvict(value="listaBancos", allEntries = true)
	})
	public void clearCaching() {}
	
	@Cacheable("horarioFuncionamento")
	@Override
	public List<HorarioFuncionamento> obterListaHorarioFuncionamento() {
		LOG.info("OBTER LISTA DE HORARIOS FUNCIONAMENTO GTEC");
		try {
			return horarioFuncionamentoRepository.findAll();

		} catch (Exception ex) {
			LOG.error("OCORREU UM ERRO AO OBTER A LISTA DE HORARIOS DE FUNCIONAMENTO CACHE {}", ex);
			throw new RuntimeException();
		}
	}

	/**
	 * Método responsavel por obter a lista de horarios de funcionamento via serviço
	 * OSB
	 * 
	 * @return
	 */
	@Override
	public Optional<List<HorarioFuncionamento>> getListaHorariosFuncionamento() {
		try {
			ConsultarHorarioFuncionamentoResponseType response = servicesOsb.obterHorarioFuncionamentoGtec();

			Optional<HorarioType[]> lista = Optional.ofNullable(response.getListaHorarios());

			if (lista.isPresent()) {
				return Optional.of(Arrays.asList(response.getListaHorarios()).stream().map(h -> popularHorario(h))
						.collect(Collectors.toList()));
			}
			return Optional.ofNullable(null);

		} catch (RemoteException | MalformedURLException | ServiceException e) {
			LOG.error("OCORREU UM ERRO AO CONSULTAR A LISTA DE HORARIOS FUNCIONAMENTO GTEC {}", e);
			throw new RuntimeException();
		}
	}

	/**
	 * Método responsavel por popular as informações de horario
	 * 
	 * @param horarioType
	 * @return
	 */
	private HorarioFuncionamento popularHorario(HorarioType horarioType) {
		HorarioFuncionamentoPk pk = new HorarioFuncionamentoPk();
		pk.setCodigo(horarioType.getCodigo());
		HorarioFuncionamento horario = new HorarioFuncionamento();
		horario.setPk(pk);
		horario.setDescricao(horarioType.getDescricao());
		return horario;
	}

	/**
	 * Método responsavel pela consulta de cep
	 * 
	 * @return
	 */
	@Override
	public ConsultarCEPResponse consultarCep(String cep) {
		LOG.info("EFETUANDO A CONSULTA DE CEP : {}", cep);
		try {
			return servicesOsb.consultarCep(cep);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("OCORREU UM ERRO NA CONSULTA DE CEP {}", ex);
			throw new RuntimeException();
		}
	}

	@Override
	public String atualizarPropostaRascunho(CrmCredenciamentoDto rascunho, String step) {
		LOG.info("ATUALIZAR PROPOSTA RASCUNHO");
		try {
			AtualizarDadosParciaisPropostaRascunhoRequest request = new AtualizarDadosParciaisPropostaRascunhoRequest();
			request.setCodigoFerramenta(rascunho.getCodigoFerramenta());
			request.setNumeroProposta(rascunho.getNumeroProposta());
			popularDadosEstabelecimento(request, rascunho);
			popularSolucaoCaptura(request, rascunho);
			servicesOsb.atualizarPropostaRascunho(request);

		} catch (RemoteException | MalformedURLException | ServiceException ex) {
			LOG.error("ERRO ATUALIZACAO DE PROPOSTA RASCUNHO  {} : {}", rascunho.getNumeroProposta(), ex);
			throw new RuntimeException("ERRO ATUALIZACAO DE PROPOSTA RASCUNHO");
		}
		return SUCESSO;
	}

	/**
	 * Método responsavel por popular as informações do estabelecimento
	 * 
	 * @param request
	 * @param rascunho
	 */
	private void popularDadosEstabelecimento(AtualizarDadosParciaisPropostaRascunhoRequest request,
			CrmCredenciamentoDto rascunho) {
		String tipoPessoa = rascunho.getTpPessoa();
		EstabelecimentoComercialType estabelecimento = new EstabelecimentoComercialType();
		estabelecimento.setCodigoTipoPessoa(EstabelecimentoComercialTypeCodigoTipoPessoa.fromValue(tipoPessoa));

		if (tipoPessoa.equals(PESSOA_FISICA)) {
			estabelecimento.setNumeroCpfCnpj(Long.valueOf(onlyNumber(rascunho.getCpf())));
			estabelecimento.setNomeRazaoSocial(rascunho.getNome());
		} else {
			estabelecimento.setNumeroCpfCnpj(Long.valueOf(onlyNumber(rascunho.getCnpj())));
			estabelecimento.setNomeRazaoSocial(rascunho.getRazaoSocial());
			estabelecimento.setNomeFantasia(rascunho.getNomeFantasia());
		}
		estabelecimento.setNomePlaqueta(rascunho.getNomePlaqueta());

		popularEndereco(estabelecimento, rascunho);
		popularDomicilio(estabelecimento, rascunho);
		request.setEstabelecimentoComercial(estabelecimento);

	}

	/**
	 * Método responsavel por popular as informações de Domicilio Bancario
	 * 
	 * @param estabelecimento
	 * @param rascunho
	 */
	private void popularDomicilio(EstabelecimentoComercialType estabelecimento, CrmCredenciamentoDto rascunho) {

		if (null != rascunho.getTipoConta() && !rascunho.getTipoConta().isEmpty()) {
			BancoType banco = new BancoType();
			banco.setTipoConta(rascunho.getTipoConta());
			banco.setCodigoBanco(rascunho.getBanco().equals(ZERO_S) ? STRING_EMPTY : rascunho.getBanco());
			banco.setNumeroAgencia(rascunho.getAgencia());
			if (null != banco.getCodigoBanco() && banco.getCodigoBanco().equals(CAIXA_ECONOMICA)) {
				banco.setNumeroContaCorrente(tratarOperacao(banco, rascunho));
			} else
				banco.setNumeroContaCorrente(rascunho.getConta().concat(rascunho.getDigito()));

			BancoType[] bancos = new BancoType[UM];
			bancos[0] = banco;
			estabelecimento.setDomiciliosBancarios(bancos);
		}

	}

	/**
	 * Método responsavel por tratar o numero da conta corrente + operacao
	 * 
	 * @param banco
	 * @param rascunho
	 * @return
	 */
	private String tratarOperacao(BancoType banco, CrmCredenciamentoDto rascunho) {
		if (rascunho.getTpPessoa().equals(PESSOA_FISICA)) {
			if (banco.getTipoConta().equals(CONTA_CORRENTE)) {
				return getNumeroConta(OPER_PF_CORRENTE, rascunho.getConta(), rascunho.getDigito());
			} else {
				return getNumeroConta(OPER_PF_POUPANCA, rascunho.getConta(), rascunho.getDigito());
			}
		} else {
			return getNumeroConta(OPER_PJ_CORRENTE, rascunho.getConta(), rascunho.getDigito());
		}
	}

	/**
	 * Formata o numero da conta corrente
	 * 
	 * @param operacao
	 * @param conta
	 * @param digito
	 * @return
	 */
	private String getNumeroConta(String operacao, String conta, String digito) {
		return (operacao.concat(StringUtils.leftPad(conta, 9, ZERO_S).concat(digito)));
	}

	/**
	 * Método responsavel por popular as informações de endereço do cliente
	 * 
	 * @param estabelecimento
	 * @param rascunho
	 */
	private void popularEndereco(EstabelecimentoComercialType estabelecimento, CrmCredenciamentoDto rascunho) {

		List<EnderecoType> listaEnderecos = new ArrayList<>();
		if (null != rascunho.getEndPrincMsmCorresp()) {
			createEnderecoIdem(rascunho, listaEnderecos);
		} else {
			createEnderecos(rascunho, listaEnderecos);
		}
		EnderecoType[] enderecos = new EnderecoType[listaEnderecos.size()];
		estabelecimento.setEnderecosEstabelecimento(listaEnderecos.toArray(enderecos));
	}

	/**
	 * Método responsavel por criar endereco comercial e correspondecia
	 * 
	 * @param rascunho
	 * @param listaEnderecos
	 */
	private void createEnderecos(CrmCredenciamentoDto rascunho, List<EnderecoType> listaEnderecos) {
		String[] infoEndComercial = getInfoEndereco(rascunho, END_COMERCIAL);
		String[] infoEndCorrespondencia = getInfoEndereco(rascunho, END_CORRESPONDENCIA);
		listaEnderecos.add(createEndereco(END_COMERCIAL, infoEndComercial[CEP], infoEndComercial[LOGRADOURO],
				infoEndComercial[NUMERO], infoEndComercial[COMPLEMENTO], infoEndComercial[CIDADE],
				infoEndComercial[SIGLA]));
		listaEnderecos.add(createEndereco(END_CORRESPONDENCIA, infoEndCorrespondencia[CEP],
				infoEndCorrespondencia[LOGRADOURO], infoEndCorrespondencia[NUMERO], infoEndCorrespondencia[COMPLEMENTO],
				infoEndCorrespondencia[CIDADE], infoEndCorrespondencia[SIGLA]));
	}

	/**
	 * Método responsavel por popular as informações de Endereco
	 * 
	 * @param rascunho
	 * @param tipoEndereco
	 */
	private void createEnderecoIdem(CrmCredenciamentoDto rascunho, List<EnderecoType> listaEnderecos) {
		String[] infoEndereco = getInfoEndereco(rascunho, END_COMERCIAL);
		listaEnderecos.add(createEndereco(END_COMERCIAL, infoEndereco[CEP], infoEndereco[LOGRADOURO],
				infoEndereco[NUMERO], infoEndereco[COMPLEMENTO], infoEndereco[CIDADE], infoEndereco[SIGLA]));
		listaEnderecos.add(createEndereco(END_CORRESPONDENCIA, infoEndereco[CEP], infoEndereco[LOGRADOURO],
				infoEndereco[NUMERO], infoEndereco[COMPLEMENTO], infoEndereco[CIDADE], infoEndereco[SIGLA]));
	}

	/**
	 * Método responsavel por popular as informações de Endereco
	 * 
	 * @param rascunho
	 * @param tipoEndereco
	 * @param sigla
	 * @param cidade
	 * @param complemento
	 * @param numero
	 * @param logradouro
	 * @param cep
	 */
	private EnderecoType createEndereco(int tipoEndereco, String cep, String logradouro, String numero,
			String complemento, String cidade, String sigla) {
		EnderecoType endereco = new EnderecoType();
		endereco.setTipoEndereco(tipoEndereco);
		endereco.setNumeroCEP(Integer.valueOf(cep.replaceAll("[^0-9]", "")));
		endereco.setNomeLogradouro(logradouro);
		endereco.setNumeroLogradouro(numero);
		endereco.setDescricaoComplementoEndereco(complemento);
		// endereco.setNomeBairro(STRING_EMPTY);//NÃO EXISTE ESSA INFORMAÇÃO NO SEC
		endereco.setNomeCidade(cidade);
		endereco.setSiglaEstado(sigla);
		return endereco;
	}

	/**
	 * Método responsave por obter as informações de endereço
	 * 
	 * @param rascunho
	 * @param tipoEndereco
	 * @return
	 */
	private String[] getInfoEndereco(CrmCredenciamentoDto rascunho, int tipoEndereco) {

		String cep = tipoEndereco == END_COMERCIAL ? rascunho.getCepComercial() : rascunho.getCepCorrespondencia();
		String logradouro = tipoEndereco == END_COMERCIAL ? rascunho.getLogradouroComercial()
				: rascunho.getLogradouroCorrespondencia();
		String numero = tipoEndereco == END_COMERCIAL ? rascunho.getNumeroComercial()
				: rascunho.getNumeroCorrespondencia();
		String complemento = tipoEndereco == END_COMERCIAL ? rascunho.getComplementoComercial()
				: rascunho.getComplementoCorrespondencia();
		String cidade = tipoEndereco == END_COMERCIAL ? rascunho.getCidadeComercial()
				: rascunho.getCidadeCorrespondencia();
		String sigla = tipoEndereco == END_COMERCIAL ? rascunho.getEstadoComercial()
				: rascunho.getEstadoCorrespondencia();

		return new String[] { cep, logradouro, numero, complemento, cidade, sigla };
	}

	/**
	 * Método responsavel por popular as informações de Solução de Captura
	 * 
	 * @param request
	 * @param rascunho
	 */
	private void popularSolucaoCaptura(AtualizarDadosParciaisPropostaRascunhoRequest request,
			CrmCredenciamentoDto rascunho) {

		SolucaoCapturaType[] solucoes = new SolucaoCapturaType[UM];

		SolucaoCapturaType solucaoCaptura = new SolucaoCapturaType();
		solucaoCaptura.setCodigoHorarioFuncionamento(rascunho.getCodHorarioAtendimento());
		solucaoCaptura.setCodigoSolucaoCaptura(rascunho.getSolCaptura());
		if (!solucaoCaptura.getCodigoSolucaoCaptura().equals(MOBILE))
			solucaoCaptura.setIndicadorAutoServico(
					rascunho.getEntregaMaquina().equals(POSTO_ATENDIMENTO) ? Boolean.TRUE : Boolean.FALSE);
		solucoes[0] = solucaoCaptura;

		request.setSolucoesCaptura(solucoes);

	}

	@Cacheable("listaBancos")
	@Override
	public List<Banco> obterListaBancos(Integer tipoConta) {
		if (tipoConta.equals(CORRENTE)) {
			return bancoRepository.getBancosCorrente();
		}
		return bancoRepository.getBancosPoupanca();
	}

	/**
	 * Método responsavel por obter a lista de Bancos
	 * 
	 * @return
	 */
	@Override
	public Optional<List<Banco>> getListaBancos() {
		try {
			ListarBancosResponse response = servicesOsb.obterListaBancos();
			Optional<br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.BancoType[]> lista = Optional
					.ofNullable(response.getBancos());

			if (lista.isPresent()) {
				return Optional.of(Arrays.asList(response.getBancos()).stream().map(b -> popularBanco(b))
						.collect(Collectors.toList()));
			}

			return Optional.ofNullable(null);

		} catch (RemoteException | MalformedURLException | ServiceException e) {
			LOG.error("OCORREU UM ERRO AO CONSULTAR A LISTA DE HORARIOS FUNCIONAMENTO GTEC {}", e);
			throw new RuntimeException();
		}
	}

	private Banco popularBanco(br.com.cielo.service.cadastro.Banco.Banco.v2.ListarBancos.BancoType bancoType) {
		BancoPk pk = new BancoPk();
		pk.setCodigo(bancoType.getCodigo());
		pk.setDescricao(bancoType.getNomeBacen());
		Banco banco = new Banco();
		banco.setPk(pk);
		banco.setDescResumida(bancoType.getNomeResumido());
		banco.setIndicadorAtivo(bancoType.getIndicadorAtivo());
		banco.setIndicadorPoupanca(bancoType.getIndicadorPermiteContaPoupanca());
		return banco;
	}

	@Override
	public Integer validarDomicilioBancario(String codigoBanco, String numeroAgencia, String numeroConta,
			String tipoConta) {
		LOG.info("VALIDAR DOMICILIO BANCARIO {}",
				codigoBanco.concat(" " + numeroAgencia).concat(" " + numeroConta).concat(" " + tipoConta));
		try {

			ValidarDigitoAgenciaContaResponse response = servicesOsb.validarDomicilioBancario(codigoBanco,
					numeroAgencia, numeroConta, tipoConta);
			return tratarRetornoValidacao(response);

		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("ERRO VALIDACAO DOMICILIO BANCARIO {}", ex);
			throw new RuntimeException();
		}

	}

	/**
	 * Método responsavel pela validação de domicilio bancario
	 * 
	 * @return
	 */
	@Override
	public boolean verificarExistenciaDomicilioBancario(String codigoBanco, String numeroAgencia, String numeroConta,
			String tipoConta) {
		LOG.info("VALIDAR EXISTENCIA DOMICILIO BANCARIO {}",
				codigoBanco.concat(" " + numeroAgencia).concat(" " + numeroConta).concat(" " + tipoConta));
		try {
			VerificarExistenciaDomicilioBancarioResponse response = servicesOsb
					.verificarExistenciaDomicioBancario(codigoBanco, numeroAgencia, numeroConta, tipoConta);
			return response.isIndicadorExisteDomicilioBancario();

		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("ERRO VALIDAR EXISTENCIA DOMICILIO BANCARIO {}", ex);
			throw new RuntimeException();
		}
	}

	/**
	 * Tratamento do retorno de validação de Domicilio Bancario
	 * 
	 * @param response
	 * @return
	 */
	private Integer tratarRetornoValidacao(ValidarDigitoAgenciaContaResponse response) {
		if (response.isIndicadorDigitoValido()) {
			return ZERO;// SUCESSO CONTA VALIDA
		}
		// 13-BANCO NAO ASSOCIADO | 14-BANCO INVALIDO | 15- AGENCIA INVALIDA | 16 -
		// CONTA CORRENTE INVALIDA
		return response.getCodigoStatusProcessamento().intValue();
	}

	/**
	 * Método responsavel por
	 */
	@Override
	public String[] criticarContaInvalida(String cpfCnpj, String tipoPessoa, Long numeroProposta,
			String banco, String agencia, String conta, String tipoConta) {
		
		LOG.info("CRITICAR CONTA INVALIDA ( PROPOSTA : {} )", numeroProposta);

		try {
			RegistrarCriticaPropostaRascunhoRequestType request = new RegistrarCriticaPropostaRascunhoRequestType();
			request.setCpfCnpj(Long.valueOf(onlyNumber(cpfCnpj)));
			request.setTipoPessoa(tipoPessoa);
			request.setNumeroProposta(numeroProposta);
			request.setCodigoCritica(8); //FIXO, VALIDACAO DE DOMICILIO BANCARIO
			request.setCamposCriticados(popularCamposCritica(new String[] {banco, agencia, conta, tipoConta}));

			RegistrarCriticaPropostaRascunhoResponseType response = servicesOsb.popularCriticaContaInvalida(request);
			return new String[]{response.getCodigoStatus().toString(), response.getDescricaoStatus()};

		} catch (MalformedURLException | RemoteException | ServiceException ex) {
			LOG.error("ERRO CRITICAR CONTA INVALIDA {}", ex);
			throw new RuntimeException();
		}
	}

	/**
	 * 
	 * @param banco
	 * @param agencia
	 * @param conta
	 * @param tipoConta
	 */
	private CampoType[] popularCamposCritica(String [] infoDomicilio) {
		
		final Integer BANCO=5, AGENCIA=4, CONTA=3, TIPO_CONTA=20;//DOMINIOS FIXOS, CONTIDOS NA BASE DE DADOS CRD (TBCRDR_CMPO_CRDN)		
		Integer[] campos = new Integer[] {BANCO, AGENCIA, CONTA, TIPO_CONTA}; 
		
		CampoType [] listaCampoType = new CampoType[QUATRO];//	QUANTIDADE DE PARAMETROS, FIXO	
		for(int i=0; i< QUATRO; i++) {			
			listaCampoType[i] = createCampoType(campos[i], infoDomicilio[i]);
		}		
		return listaCampoType;
	}
	
	/**
	 * Método responsavel por popualr as informações do campo type
	 * @param codigoCampo
	 * @param valor
	 * @return
	 */
	private CampoType createCampoType(Integer codigoCampo, String valor) {
		return new CampoType(codigoCampo, valor);
	}

}
