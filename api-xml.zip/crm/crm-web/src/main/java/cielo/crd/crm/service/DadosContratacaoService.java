package cielo.crd.crm.service;

import cielo.crd.crm.model.CrmCredenciamentoDto;
import cielo.crd.crm.model.CrmJsonResponse;
import cielo.crd.crm.model.InfoEquipamentos;

/**
 * Interface responsavel pela efetivação do credenciamento do cliente via OSB
 * 
 * @author @Cielo/SA
 * @since 1.0.0
 */
public interface DadosContratacaoService {

	/**
	 * Método responsavel pela efetivação do credenciamento do cliente
	 * @param proposta
	 * @return  CrmJsonResponse<CrmCredenciamentoDto>
	 */
	CrmJsonResponse<CrmCredenciamentoDto> efetivarCredenciamento(CrmCredenciamentoDto proposta);
	
	/**
	 * Método responsavel por obter o numero Lógico 
	 * @param numeroProposta
	 * @return
	 */
	InfoEquipamentos obterNumeroLogico(Long numeroProposta);
}
