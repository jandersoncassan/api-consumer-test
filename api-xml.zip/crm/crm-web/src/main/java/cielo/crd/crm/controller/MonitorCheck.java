package cielo.crd.crm.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cielo.crd.crm.model.MonitoCheck;
import cielo.crd.crm.repository.ParametrosRepository;
import cielo.crd.crm.service.InfoAdicionalService;
import cielo.crd.crm.service.SolucaoCapturaService;

@RestController
@RequestMapping("/service/check")
@CrossOrigin("*")
public class MonitorCheck {

	private static final Logger LOG = LoggerFactory.getLogger(MonitorCheck.class);
	
	private static final String CACHE_SOLUCAO_CAPTURA = "solucaoCaptura";
	
	private static final String CACHE_INFO_ADICIONAIS = "infoAdicionais";
	
	@Autowired
	private SolucaoCapturaService solucaoCapturaService;
	
	@Autowired
	private InfoAdicionalService infoAdicionalService;
	
	@Autowired
	private ParametrosRepository config;
	
	private static final String ATIVO = "S";
	
	@GetMapping(produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<MonitoCheck> isActiveApplication(){
		try {
			String isActive = config.findByKey("active");
			if(isActive.equals(ATIVO)) {
				//HTTP 200
				return new ResponseEntity<>(new MonitoCheck(200, "Ambiente disponivel"), HttpStatus.OK);
			}
			//HTTP 500 - PARAMETRIZADO A FLAG COMO N
			return new ResponseEntity<>(new MonitoCheck(500, "Ambiente indisponivel"), HttpStatus.INTERNAL_SERVER_ERROR);

		}catch(Throwable ex) {
			//HTTP 500 ERROR NA CONSULTA DA FLAG
			return new ResponseEntity<>(new MonitoCheck(500, "Ambiente indisponivel"), HttpStatus.INTERNAL_SERVER_ERROR);
		}		
	}
	
	@GetMapping(value="/cleanCache/{function}", produces = { MediaType.APPLICATION_JSON_VALUE })
	public ResponseEntity<String> cleanEhCache(@PathVariable("function") String function){

		LOG.info("EXECUTANDO CLEAN EHCACHE CRD-CRM ... FUNCTION {}", function);		
		
		if(function.equals(CACHE_SOLUCAO_CAPTURA)) {
			solucaoCapturaService.clearCaching();
			
		}else if(function.equals(CACHE_INFO_ADICIONAIS)) {			
			infoAdicionalService.clearCaching();
			
		}else {
			LOG.info("CACHE NAO MAPEADO ... FUNCTION {}", function);
			return new ResponseEntity<>("EXPURGO CACHE NAO EXECUTADO", HttpStatus.METHOD_NOT_ALLOWED);
		}		
		return new ResponseEntity<>("EXPURGO CACHE SUCESSO !", HttpStatus.OK);
		
	}
}
