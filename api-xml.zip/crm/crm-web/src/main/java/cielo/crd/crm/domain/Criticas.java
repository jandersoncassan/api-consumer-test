package cielo.crd.crm.domain;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TBCRDCRM_CRITICAS")
public class Criticas {

	@Id
	private Long codigoCritica;
	
	private String descricaoCrd;
	
	private String descricaoCentral;

	/**
	 * @return the codigoCritica
	 */
	public Long getCodigoCritica() {
		return codigoCritica;
	}

	/**
	 * @param codigoCritica the codigoCritica to set
	 */
	public void setCodigoCritica(Long codigoCritica) {
		this.codigoCritica = codigoCritica;
	}

	/**
	 * @return the descricaoCrd
	 */
	public String getDescricaoCrd() {
		return descricaoCrd;
	}

	/**
	 * @param descricaoCrd the descricaoCrd to set
	 */
	public void setDescricaoCrd(String descricaoCrd) {
		this.descricaoCrd = descricaoCrd;
	}

	/**
	 * @return the descricaoCentral
	 */
	public String getDescricaoCentral() {
		return descricaoCentral;
	}

	/**
	 * @param descricaoCentral the descricaoCentral to set
	 */
	public void setDescricaoCentral(String descricaoCentral) {
		this.descricaoCentral = descricaoCentral;
	}
	
	
}
