package cielo.crd.crm.domain;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TBCRDCRM_SOLUCAO_EQUIPAMENTO")
public class SolucaoEquipamento implements Serializable{

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SolucaoEquipamentoPk id;

	private Integer qtdadeMaxima;
	
	private String indicadorMei;

	/**
	 * @return the id
	 */
	public SolucaoEquipamentoPk getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(SolucaoEquipamentoPk id) {
		this.id = id;
	}

	/**
	 * @return the qtdadeMaxima
	 */
	public Integer getQtdadeMaxima() {
		return qtdadeMaxima;
	}

	/**
	 * @param qtdadeMaxima the qtdadeMaxima to set
	 */
	public void setQtdadeMaxima(Integer qtdadeMaxima) {
		this.qtdadeMaxima = qtdadeMaxima;
	}

	/**
	 * @return the indicadorMei
	 */
	public String getIndicadorMei() {
		return indicadorMei;
	}

	/**
	 * @param indicadorMei the indicadorMei to set
	 */
	public void setIndicadorMei(String indicadorMei) {
		this.indicadorMei = indicadorMei;
	}

	
}
