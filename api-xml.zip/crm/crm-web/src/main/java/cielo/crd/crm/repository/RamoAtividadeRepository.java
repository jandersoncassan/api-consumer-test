package cielo.crd.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import cielo.crd.crm.domain.RamoAtividade;

@Repository
public interface RamoAtividadeRepository extends JpaRepository<RamoAtividade, Long> {

	@Query("SELECT r FROM RamoAtividade r WHERE r.pk.tipoPessoa = :tpPessoa AND r.pk.codigoFerramenta = :codigoFerramenta")
	List<RamoAtividade> findAllByTpPessoa(@Param("tpPessoa") String tpPessoa,
			@Param("codigoFerramenta") Integer codigoFerramenta);

}
