package cielo.crd.crm.model;

import java.util.List;

public class Equipamento {

 	private Integer numeroLogico;
    private Integer digNumLogico;
    private String slaInstalacao;
    private Integer codigoAcesso;

    private List<Operadora> listaOperadoras;

	/**
	 * @return the numeroLogico
	 */
	public Integer getNumeroLogico() {
		return numeroLogico;
	}

	/**
	 * @param numeroLogico the numeroLogico to set
	 */
	public void setNumeroLogico(Integer numeroLogico) {
		this.numeroLogico = numeroLogico;
	}

	/**
	 * @return the digNumLogico
	 */
	public Integer getDigNumLogico() {
		return digNumLogico;
	}

	/**
	 * @param digNumLogico the digNumLogico to set
	 */
	public void setDigNumLogico(Integer digNumLogico) {
		this.digNumLogico = digNumLogico;
	}

	/**
	 * @return the slaInstalacao
	 */
	public String getSlaInstalacao() {
		return slaInstalacao;
	}

	/**
	 * @param slaInstalacao the slaInstalacao to set
	 */
	public void setSlaInstalacao(String slaInstalacao) {
		this.slaInstalacao = slaInstalacao;
	}

	/**
	 * @return the codigoAcesso
	 */
	public Integer getCodigoAcesso() {
		return codigoAcesso;
	}

	/**
	 * @param codigoAcesso the codigoAcesso to set
	 */
	public void setCodigoAcesso(Integer codigoAcesso) {
		this.codigoAcesso = codigoAcesso;
	}

	/**
	 * @return the listaOperadoras
	 */
	public List<Operadora> getListaOperadoras() {
		return listaOperadoras;
	}

	/**
	 * @param listaOperadoras the listaOperadoras to set
	 */
	public void setListaOperadoras(List<Operadora> listaOperadoras) {
		this.listaOperadoras = listaOperadoras;
	}
    
    
}
