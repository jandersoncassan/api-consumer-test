package cielo.crd.crm.domain;

import java.io.Serializable;

import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TBCRDCRM_SOLUCAO_CAPTURA_FERRAMENTA")
public class SolucaoCaptura implements Serializable{

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private SolucaoCapturaPk pk;
	
	private String nome;
	
	private String descricao;
	
	private String indEntregaMaquina;

	/**
	 * @return the pk
	 */
	public SolucaoCapturaPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(SolucaoCapturaPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the nome
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * @param nome the nome to set
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	/**
	 * @return the descricao
	 */
	public String getDescricao() {
		return descricao;
	}

	/**
	 * @param descricao the descricao to set
	 */
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	/**
	 * @return the indEntregaMaquina
	 */
	public String getIndEntregaMaquina() {
		return indEntregaMaquina;
	}

	/**
	 * @param indEntregaMaquina the indEntregaMaquina to set
	 */
	public void setIndEntregaMaquina(String indEntregaMaquina) {
		this.indEntregaMaquina = indEntregaMaquina;
	}


}
