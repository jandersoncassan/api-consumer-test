package cielo.crd.crm.service;

import java.util.List;
import java.util.Optional;

import br.com.cielo.service.cadastro.endereco.endereco.v2.consultarcep.ConsultarCEPResponse;
import cielo.crd.crm.domain.Banco;
import cielo.crd.crm.domain.HorarioFuncionamento;
import cielo.crd.crm.model.CrmCredenciamentoDto;

/**
 * Interface responsavel pelos serviços de informações adicionais OSB
 * 
 * @author @Cielo/SA
 * @since 1.0.0
 */
public interface InfoAdicionalService {

	/**
	 * Método responsavel por obter a lista de horarios funcionamento cache
	 * @return
	 */
	List<HorarioFuncionamento> obterListaHorarioFuncionamento();
	
	
	/**
	 * Método responsavel por obter a lista de horarios de funcionamento gtec via OSB
	 * 
	 * @return
	 */
	Optional<List<HorarioFuncionamento>> getListaHorariosFuncionamento();
	
	/**
	 * Metodo responsavel pela consulta de cep OSB
	 * 
	 * @param cep
	 * @return
	 */
	ConsultarCEPResponse consultarCep(String cep);

	/**
	 * Método responsavel por obter a lista de bancos
	 * 
	 * @return
	 */
	Optional<List<Banco>> getListaBancos();

	/**
	 * Método responsavel por atualizar a proposta rascunho
	 * 
	 * @param rascunho
	 * @param step
	 * @return
	 */
	String atualizarPropostaRascunho(CrmCredenciamentoDto rascunho, String step);

	/**
	 * Método responsavel por obter a lista de bancos de acordo com o tipo de conta Corrente | Poupança
	 * 
	 * @param tipoConta
	 * @return
	 */
	List<Banco> obterListaBancos(Integer tipoConta);
	
	/**
	 * Método responsavel por validar o Domicilio Bancario
	 * 
	 * @param codigoBanco
	 * @param numeroAgencia
	 * @param numeroConta
	 * @param tipoConta
	 * @return
	 */
	Integer validarDomicilioBancario(String codigoBanco, String numeroAgencia, String numeroConta, String tipoConta);

	/**
	 * Método responsavel por verificar se o Domicilio Bancario já existe no SEC
	 * 
	 * @param codigoBanco
	 * @param numeroAgencia
	 * @param numeroConta
	 * @param tipoConta
	 * @return
	 */
	boolean verificarExistenciaDomicilioBancario(String codigoBanco, String numeroAgencia, String numeroConta, String tipoConta);
	
	/**
	 * Método responsavel por efetivar a critica de domicilio bancario
	 * 
	 * @param cpfCnpj
	 * @param tipoPessoa
	 * @param numeroProposta
	 * @param banco
	 * @param agencia
	 * @param conta
	 * @param tipoConta
	 * @return
	 */
	String[] criticarContaInvalida(String cpfCnpj, String tipoPessoa, Long numeroProposta, String banco, String agencia, String conta, String tipoConta);
	
	/**
	 * Método responsavel pelo expurgo do caching
	 */
	void clearCaching();
}
