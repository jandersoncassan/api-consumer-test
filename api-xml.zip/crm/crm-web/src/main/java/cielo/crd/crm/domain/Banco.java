package cielo.crd.crm.domain;

import java.io.Serializable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="TBCRDCRM_BANCO")
public class Banco implements Serializable{

	private static final long serialVersionUID = 1L;

	@EmbeddedId
	private BancoPk pk;
	
	private String descResumida;
	
	private String indicadorAtivo;
	
	private String indicadorPoupanca;

	/**
	 * @return the pk
	 */
	public BancoPk getPk() {
		return pk;
	}

	/**
	 * @param pk the pk to set
	 */
	public void setPk(BancoPk pk) {
		this.pk = pk;
	}

	/**
	 * @return the descResumida
	 */
	public String getDescResumida() {
		return descResumida;
	}

	/**
	 * @param descResumida the descResumida to set
	 */
	public void setDescResumida(String descResumida) {
		this.descResumida = descResumida;
	}

	/**
	 * @return the indicadorAtivo
	 */
	public String getIndicadorAtivo() {
		return indicadorAtivo;
	}

	/**
	 * @param indicadorAtivo the indicadorAtivo to set
	 */
	public void setIndicadorAtivo(String indicadorAtivo) {
		this.indicadorAtivo = indicadorAtivo;
	}

	/**
	 * @return the indicadorPoupanca
	 */
	public String getIndicadorPoupanca() {
		return indicadorPoupanca;
	}

	/**
	 * @param indicadorPoupanca the indicadorPoupanca to set
	 */
	public void setIndicadorPoupanca(String indicadorPoupanca) {
		this.indicadorPoupanca = indicadorPoupanca;
	}

	
}
