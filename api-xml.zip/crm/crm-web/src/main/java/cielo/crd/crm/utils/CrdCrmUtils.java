package cielo.crd.crm.utils;


import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;


public class CrdCrmUtils {

	private static final Logger LOG = LoggerFactory.getLogger(CrdCrmUtils.class);
	
	private static final ObjectMapper objectMapper = new ObjectMapper();

	public static final String STRING_EMPTY = "";	
	public static final String FLAG_INDICADOR_MEI = "N"; // POR PADRAO PASSAMOS N
	
	public static final Integer OPT_SELECT = 0;	
	public static final Integer PLANO_CONVENCIONAL = 1;	
	public static final Integer PLANO_CIELO_CONTROLE = 2;	
	public static final Integer PLANO_CIELO_LIVRE = 3;
	
	public static final Integer MOBILE = 18;	
	public static final Integer ECOMMERCE_CHECKOUT = 19;	
	public static final Integer ECOMMERCE_WEBCSERVICE = 20;	
	
	public static final Integer LIO_BASIC = 21;	
	public static final Integer LIO_PLUS = 22;	
	public static final Integer LIO_BASIC_V2 = 23;	
	public static final Integer LIO_PLUS_V2 = 24;	
	
	public static final Integer CIELO_ZIP = 26;

	
	public static final String PESSOA_FISICA="F";
	public static final String PESSOA_JURIDICA = "J";
	
	public static final String CLIENTE_EXISTE = "Y";
	public static final String CLIENTE_NAO_EXISTE = "N";
	public static final String CPF_CNPJ_INVALIDO = "I";
	
	public static final String SUCESSO = "S";
	public static final String ERROR = "E";
	
	public static final int TEL_COMERCIAL = 2;
	public static final int TEL_CELULAR = 3;
	public static final int END_COMERCIAL = 2;
	public static final int END_CORRESPONDENCIA = 3;
	public static final int END_COMERCIAL_E_CORRESPONDENCIA = 4;
	
	public static final int CEP = 0;
	public static final int LOGRADOURO = 1;
	public static final int NUMERO = 2;
	public static final int COMPLEMENTO = 3;
	public static final int CIDADE = 4;
	public static final int SIGLA = 5;
	
	public static final int CORRENTE = 0;
	public static final int POUPANCA = 2;
	public static final String POSTO_ATENDIMENTO = "2";
	public static final String CAIXA_ECONOMICA = "104";
	
	public static final String CONTA_CORRENTE = "0";
	public static final String CONTA_POUPANCA = "2";
	
	public static final String OPER_PF_CORRENTE = "1";
	public static final String OPER_PF_POUPANCA = "13";
	public static final String OPER_PJ_CORRENTE = "3";
	
	public static final int DOMICILIO_SUCESSO = 0;
	public static final int DOMICILIO_EXISTE = 99;
	
	public static final int FALHA_VALIDACAO_DIGITO_DOMICILIO = 100;
	public static final int FALHA_EXISTENCIA_DOMICILIO = 101;
	

	//CREDENCIAIS OSB
	public static final String OSB_USER ="osb.user";
	public static final String OSB_PASS ="osb.pass";
	
	//ENDPOITS
	public static final String OSB_DOMAIN="osb.domain";
	public static final String ENDPOINT_CONSULTAR_CLIENTE="endpoint.consultar.cliente";
	public final static String ENDPOINT_CONSULTAR_PROPOSTA_RASCUNHO="endpoint.consultar.proposta.rascunho";
	public final static String ENDPOINT_ATUALIZAR_PROPOSTA_RASCUNHO="endpoint.atualizar.proposta.rascunho";
	public final static String ENDPOINT_CREDENCIAR_CLIENTE = "endpoint.credenciar.cliente";	
	public final static String ENDPOINT_CONSULTAR_RAMOS_ATIVIDADES="endpoint.consultar.ramos.atividades";
	public final static String ENDPOINT_CONSULTAR_LISTA_TAXAS = "endpoint.consultar.lista.taxas";
	public final static String ENDPOINT_HORARIO_FUNCIONAMENTO_GTEC = "endpoint.horario.funcionamento.gtec";
	public final static String ENDPOINT_CONSULTAR_INFO_CEP = "endpoint.consultar.info.cep";
	public final static String ENDPOINT_CONSULTAR_LISTA_BANCOS = "endpoint.consultar.lista.bancos";
	public final static String ENDPOINT_VALIDAR_DOMICILIO_BANCARIO = "endpoint.validar.domicilio.bancario";
	public final static String ENDPOINT_EXISTENCIA_DOMICILIO_BANCARIO = "endpoint.existencia.domicilio.bancario";
	public final static String ENDPOINT_CONSULTAR_NUMERO_LOGICO = "endpoint.consultar.numero.logico";
	public final static String ENDPOINT_QUANT_EQUIPAMENTOS = "endpoint.consultar.qtdade.equipamentos";
	public final static String ENDPOINT_SOLUCAO_CAPTURA_FERRAMENTA = "endpoint.lista.solucao.captura.ferramenta";
	public final static String ENDPOINT_CRITICAR_CONTA_INVALIDA = "endpoint.critica.conta.invalida";
	public final static String ENDPOINT_CONSULTAR_LISTA_FATURAMENTO = "endpoint.consultar.lista.faturamento";

	//PESO CPF / CNPJ
    private static final int[] PESO_CPF = {11, 10, 9, 8, 7, 6, 5, 4, 3, 2};
    private static final int[] PESO_CNPJ = {6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2};
    
    //NUMEROS
    public static final String ZERO_S = "0";
    public static final int ZERO = 0;
    public static final int UM = 1;
    public static final int DOIS = 2;
    public static final int QUATRO = 4;
    public static final int OITO = 8;
    private static final int NOVE = 9;
    public static final int ONZE = 11;
    private static final int DOZE = 12;
    
    /* TOKEN DE ACESSO ATRAVES DO DASH*/
    public static final String ACCESS_TOKEN = "WXKYRCRMTOKEN1A2B3W!UTHA";
    private static final String BEFORE_CRYPTO="#c48jKxH";
    private static final String AFTER_CRYPTO="*#$APP$@1u6t23Wq";
    
    /* FLAG PARA TRATAMENTO MULTIVAN NA CONSULTA DE CLIENTE EXISTENTE */
    public static final String FLAG_MULTIVAN = "R3";
    
	/**
	 * Método responsavel por limpar as mensagens de erro
	 * 
	 * @param errors
	 * @param fieldsExclude
	 */
	public static void cleanMessageErrors(Map<String, String> errors, List<String> fieldsExclude) {
		Iterator<String> it = errors.keySet().iterator();
		while (it.hasNext()) {
			String key = it.next();
			for (String message : fieldsExclude) {			
				if (key.equals(message)) {
					it.remove();
				}
			}
		}
	}

	/**
	 * Método responsavel por verificar se o objeto é nulo
	 * 
	 * @param str
	 * @return
	 */
	public static boolean objectIsNull(Object obj) {
		return (null == obj);
	}
	
	/**
	 * Método responsavel por verificar se a String é nula ou vazia
	 * 
	 * @param str
	 * @return
	 */
	public static boolean StringEmptyOrNull(String str) {
		return (objectIsNull(str) || str.isEmpty());
	}
	
	/**
	 * Metoto responsavel por verificar se o objeto é nula e retorna uma String vazia
	 * 
	 * @param obj
	 * @return
	 */
	public static String objectNullToString(Object obj) {
		return (objectIsNull(obj) ? STRING_EMPTY : obj.toString());
	}

	/**
	 * Metoto responsavel por verificar se o objeto é nula e retorna uma String vazia
	 * 
	 * @param obj
	 * @return
	 */
	public static Integer objectNullToInteger(Object obj) {
		if(objectIsNull(obj)) {
			return ZERO;
		}else if(obj instanceof BigDecimal) {
				return ((BigDecimal)obj).intValue();
		}else {
			return (Integer)obj;
		}
	}
	
	/**
	 * Método responsavel por remover os caracteres especiais da String
	 * 
	 * @param data
	 * @return
	 */
	public static String onlyNumber(String data) {
		if(null == data) {
			return "0";
		}
		return data.replaceAll("[^0-9]", "");
	}

	/**
	 * Metodo responsavel por converter date to string
	 * 
	 * @param data
	 * @return
	 */
	public static String dateToString(Date data) {
		if(null == data) {
			return STRING_EMPTY;
		}
		SimpleDateFormat sdfr = new SimpleDateFormat("dd/MM/yyyy");
		return (sdfr.format(data));
	}
	
	/**
	 * Metodo responsavel por converter date to string
	 * 
	 * @param data
	 * @return
	 */
	public static Date stringToDate(String data) {		
		SimpleDateFormat sdfr = new SimpleDateFormat("dd/MM/yyyy");
		try {
			return (sdfr.parse(data));
		} catch (ParseException e) {
			LOG.error("ERRO AO FORMATAR A STRING TO DATE : {}", data);
			return null;
		}
	}

	/**
	 * Método responsavel por converter o Date para String
	 * @param date
	 * @return String
	 */
	public static String dateToStringApi(String data){		
		Date date = stringToDate(data);
		String DATE_FORMAT_NOW = "yyyy-MM-dd";
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
		return sdf.format(date);
	}

	  /**
     * Método responsável por calcular o dígito do cpf ou cnpj de acordo com a regra do módulo 11.
     * @param cpfCnpj : CPF ou CNPJ
     * @param peso : vetor de peso do cpf ou cnpj.
     * @return digito calculado
     */
    private static int calcularDigito(final String cpfCnpj, final int[] peso) {

        int soma = 0;
        for (int indice = cpfCnpj.length() - 1, digito; indice >= 0; indice--) {
            digito = Integer.parseInt(cpfCnpj.substring(indice, indice + 1));
            soma += digito * peso[peso.length - cpfCnpj.length() + indice];
        }
        soma = ONZE - soma % ONZE;
        return soma > NOVE ? 0 : soma;
    }

    /**
     * Método responsável por validar se o CPF possui uma sequencia de numeros repetidos
     * @param cpf - Número do CPF
     * @return resultado da verificação
     */
    private static boolean cpfNumerosRepetidos(final String cpf) {

        if (cpf == null || cpf.matches("^(0{11}|1{11}|2{11}|3{11}|4{11}|5{11}|6{11}|7{11}|8{11}|9{11})$")) {
            return true;
        }
        return false;
    }

    /**
     * Método responsável por validar se o CNPJ possui uma sequencia de numeros repetidos
     * @param cnpj - Número do CNPJ
     * @return resultado da verificação
     */
    private static boolean cnpjNumerosRepetidos(final String cnpj) {

        if (cnpj == null || cnpj.matches("^(0{14}|1{14}|2{14}|3{14}|4{14}|5{14}|6{14}|7{14}|8{14}|9{14})$")) {
            return true;
        }
        return false;
    }

    /**
     * Método responsável por validar o dígito do CPF informado.
     * @param cpf : CPF que será validado
     * @return True ou False
     */
    public static boolean isCpfValido(String cpf) {
    	cpf = cpf.replaceAll("[^0-9]","");  
    	if(cpfNumerosRepetidos(cpf)) {
    		return false;
    	}
        Integer digito1 = calcularDigito(cpf.substring(ZERO, NOVE), PESO_CPF);
        Integer digito2 = calcularDigito(cpf.substring(0, NOVE) + digito1, PESO_CPF);
        return cpf.equals(cpf.substring(ZERO, NOVE) + digito1.toString() + digito2.toString());
    }

    /**
     * Método responsável por validar o dígito do CNPJ informado.
     * @param cnpj : CNPJ que será validado
     * @return TRUE ou FALSE
     */
    public static boolean isCnpjValido(String cnpj) {
    	cnpj = cnpj.replaceAll("[^0-9]","");  
        if(cnpjNumerosRepetidos(cnpj)) {
        	return false;
        }
        Integer digito1 = calcularDigito(cnpj.substring(ZERO, DOZE), PESO_CNPJ);
        Integer digito2 = calcularDigito(cnpj.substring(ZERO, DOZE) + digito1, PESO_CNPJ);
        return cnpj.equals(cnpj.substring(ZERO, DOZE) + digito1.toString() + digito2.toString());
    }

    /**
     * Método responsavel por gerar o json
     * 
     * @param object
     * @return byte[]
     * @throws IllegalArgumentException
     */
    public static byte[] deflate(String operacao, Object object) throws IllegalArgumentException {

        byte[] bytes = null;
        String json = objectToString(object);
        bytes = json.getBytes();
        printLog(operacao, new String(bytes));
        return bytes;
    }
    
    /**
     * Método responsavel por devolver o json do object proposta
     * 
     * @param object
     * @return
     */
    public static String objectToString(Object object) {
    	try {
			return objectMapper.writeValueAsString(object);
		} catch (JsonProcessingException e) {
			LOG.error("ERRO AO TRANSFORMAR O OBJECT PROPOSTA EM JSON : {}", e);
			return STRING_EMPTY;
		}
    }

    /**
     * Print das informações de log
     * 
     * @param operacao
     * @param mensagem
     */
    private static void printLog(String operacao, String mensagem) {
        LOG.info("-=-=-=-=-=-=-=-=>".concat(operacao).concat(" PAYLOAD : {}"), mensagem);
    }

    /**
     * M
     * @param valueEncoder
     * @return
     * @throws UnsupportedEncodingException
     */
    public static String decrypt(String valueEncoder){
    	try {
	    	byte[] decodeBytes = Base64.getDecoder().decode(valueEncoder.replace(BEFORE_CRYPTO,"").replace(AFTER_CRYPTO, ""));
	    	return (new String(decodeBytes, "UTF-8")); 
	    	
    	}catch(UnsupportedEncodingException ex) {
    		LOG.error("OCORREU UM ERRO AO DECRYPTOGRAFAR O VALUE_ENCODER");
    		return null;
    	}
    }
    
	
	/**
	 * Método responsavel por verificar se a quantidade de equipamentos é no maximo 1
	 * @param rascunho
	 * @return
	 */
	public static Boolean isQtdadeEquipamentoFixa(Integer tipoPlano, Integer  solucaoCaptura) {
		Optional<Integer> codTipoPlano = Optional.ofNullable(tipoPlano);
		Optional<Integer> codSolucaoCaptura = Optional.ofNullable(solucaoCaptura);
		
		//PLANO CIELO CONTROLE | PLANO CIELO LIVRE
		if(codTipoPlano.isPresent()) {
			if(codTipoPlano.get().equals(PLANO_CIELO_CONTROLE) || codTipoPlano.get().equals(PLANO_CIELO_LIVRE)) {
				return Boolean.TRUE;
			}
		}//SOLUCAO DE CAPTURA CIELO ZIP
		if(codSolucaoCaptura.isPresent() && codSolucaoCaptura.get().equals(CIELO_ZIP)) {
			return Boolean.TRUE;
		}
		return Boolean.FALSE;
	}


}

